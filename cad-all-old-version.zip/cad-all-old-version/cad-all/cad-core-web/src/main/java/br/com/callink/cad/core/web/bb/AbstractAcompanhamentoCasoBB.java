package br.com.callink.gbo.core.web.bb;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;

import br.com.callink.gbo.pojo.Atendente;
import br.com.callink.gbo.pojo.Caso;
import br.com.callink.gbo.pojo.ConfiguracaoFila;
import br.com.callink.gbo.pojo.Equipe;
import br.com.callink.gbo.pojo.EquipeFila;
import br.com.callink.gbo.pojo.Status;
import br.com.callink.gbo.service.IAtendenteService;
import br.com.callink.gbo.service.ICasoService;
import br.com.callink.gbo.service.IConfiguracaoFilaService;
import br.com.callink.gbo.service.IEquipeFilaService;
import br.com.callink.gbo.service.IEquipeService;
import br.com.callink.gbo.service.IStatusService;
import br.com.callink.gbo.service.exception.ServiceException;
import br.com.callink.gbo.util.Constantes;

/**
 * 
 * @author Rafael Peres dos santos
 */
public abstract class AbstractAcompanhamentoCasoBB<T extends Caso> extends GboGenericCrud<Caso, ICasoService> {

    private static final String FINALIZADO_FORA_DO_PRAZO = "Finalizado Fora do Prazo";
	private static final String FINALIZADO_DENTRO_DO_PRAZO = "Finalizado dentro do Prazo";
	private static final String PENDENTE_DENTRO_DO_PRAZO = "Pendente dentro do Prazo";
	private static final String PENDENTE_FORA_DO_PRAZO = "Pendente Fora do Prazo";
	private static final long serialVersionUID = 1L;
    private Integer sla;
    private Integer idExterno;
    private Date dataInicio;
    private Date dataFim;
    private Date dataInicioFechamento;
    private Date dataFimFechamento;
    private Integer hora;
    private Integer minuto;
    private Integer horaMaior;
    private Integer minutoMaior;
    private List<Status> statusList;
    private List<ConfiguracaoFila> configuracaoFilaList;
    private List<Atendente> atendenteList;
    private List<Equipe> equipeList;
    private List<ConfiguracaoFila> configuracaoFilaSelecionadoList;
    private List<Status> statusSelecionadoList;
    private List<Atendente> atendenteSelecionadoList;
    private List<Equipe> equipeSelecionadoList;
    private boolean selecionaTodosConfiguracaoFila;
    private boolean selecionaTodosStatus;
    private boolean selecionaTodosAtendente;
    private boolean selecionaTodosEquipe;
    private ConfiguracaoFila configuracaoFilaSelecionado;
    private List<String> configuracaoFilaNomeSelecionadoList;
    private List<String> statusNomeSelecionadoList;
    private List<String> atendenteNomeSelecionadoList;
    private List<String> equipeNomeSelecionadoList;
    private Caso caso;
    private Integer casosDentroPrazo;
    private Integer casosForaPrazo;
    private Integer casosAbertos;
    private Integer casosFechados;
    private String graficoPrincipal;
    private String graficoPendente;
    private String graficoFinalizado;
    private Boolean mostraSumarizado;
    private String contextPath;
    private Character flagRechamadoConsulta; //S = Sim, N = Não e T = Todos

    //Controle das Grids dos modais para melhor renderização no IE 7
    private boolean flagMostraGridEquipe;
    private boolean flagMostraGridFila;
    private boolean flagMostraGridAnalista;
    private boolean flagMostraGridStatus;
    
    @EJB
    private IStatusService statusService;
    @EJB
    private IAtendenteService atendenteService;
    @EJB
    private IConfiguracaoFilaService configuracaoFilaService;
    @EJB
    private IEquipeService equipeService;
    @EJB
    private IEquipeFilaService equipeFilaService;
    
    @PostConstruct
    public void init() {
    	caso = new Caso();
        configuracaoFilaSelecionadoList = new ArrayList<ConfiguracaoFila>();
        statusSelecionadoList = new ArrayList<Status>();
        atendenteSelecionadoList = new ArrayList<Atendente>();
        flagRechamadoConsulta = 'T';
        mostraSumarizado = Boolean.FALSE;
    }
    
    public void mostraGridStatus() {
        if (statusList == null) {
            try {
                this.statusList = statusService.findAll("Status.NOME");
            } catch (ServiceException e) {
            	logger.error(e);
                error(e);
            }
        }
        
        flagMostraGridStatus = Boolean.TRUE;
    }
    
    public void mostraGridAnalista() {
        if (atendenteList == null) {
            try {
                atendenteList = atendenteService.findAll("Atendente.LOGIN");
            } catch (ServiceException e) {
            	logger.error(e);
                error(e);
            }
        }
        
        flagMostraGridAnalista = Boolean.TRUE;
    }
    
    public void mostraGridFila() {
        if (configuracaoFilaList == null) {
            try {
                this.configuracaoFilaList = configuracaoFilaService.findAll("ConfiguracaoFila.NOME");
            } catch (ServiceException e) {
            	logger.error(e);
                error(e);
            }
        }
    	
        flagMostraGridFila = Boolean.TRUE;
    }
    
    public void mostraGridEquipe() {
        try {
            if (equipeList == null) {
                setEquipeList(equipeService.findAtivos());
            }
        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }
    	
        flagMostraGridEquipe = Boolean.TRUE;
    }
    
    public abstract void escondeGridEspecialista();
    
    public void escondeGrids() {
        escondeGridEspecialista();
        
        flagMostraGridEquipe = Boolean.FALSE;
        flagMostraGridFila = Boolean.FALSE;
        flagMostraGridAnalista = Boolean.FALSE;
        flagMostraGridStatus = Boolean.FALSE;
    }

    public void selecionaTodosFilas() {

        for (ConfiguracaoFila item : getConfiguracaoFilaList()) {
            if (selecionaTodosConfiguracaoFila == Boolean.TRUE) {
                item.setSelecionado(Boolean.TRUE);
            } else {
                item.setSelecionado(Boolean.FALSE);
            }
            marcaDesmarcaFila(item);
        }
    }

    public void marcaDesmarcaFila(ConfiguracaoFila configuracaoFila) {
        if (configuracaoFila != null && configuracaoFila.getSelecionado() != null) {

            if (getConfiguracaoFilaSelecionadoList() == null) {
                setConfiguracaoFilaSelecionadoList(new ArrayList<ConfiguracaoFila>());
            }
            if (configuracaoFila.getSelecionado()) {
                if (!getConfiguracaoFilaNomeSelecionadoList().contains(configuracaoFila.getNome())) {
                    getConfiguracaoFilaNomeSelecionadoList().add(configuracaoFila.getNome());
                    getConfiguracaoFilaSelecionadoList().add(configuracaoFila);
                }

            } else {
                if (getConfiguracaoFilaNomeSelecionadoList().contains(
                        configuracaoFila.getNome())) {
                    getConfiguracaoFilaNomeSelecionadoList().remove(configuracaoFila.getNome());
                    getConfiguracaoFilaSelecionadoList().remove(configuracaoFila);
                }

            }
            if (getAtendenteSelecionadoList() != null) {
                getAtendenteSelecionadoList().clear();
                getAtendenteNomeSelecionadoList().clear();
            }
        }
    }

    public String getFilasSelecionadas() {

        if (configuracaoFilaNomeSelecionadoList == null
                || configuracaoFilaNomeSelecionadoList.toString().equals(
                Constantes.LISTA_STRING_VAZIA)) {
            return "";
        }
        return configuracaoFilaNomeSelecionadoList.toString();
    }

    public void selecionaTodosStatus() {
        for (Status item : getStatusList()) {
            if (selecionaTodosStatus == Boolean.TRUE) {
                item.setSelecionado(Boolean.TRUE);
            } else {
                item.setSelecionado(Boolean.FALSE);
            }
            marcaDesmarcaStatus(item);
        }
    }

    public void marcaDesmarcaStatus(Status status) {
        if (status != null && status.getSelecionado() != null
                && status.getSelecionado() != null) {

            if (getStatusSelecionadoList() == null) {
                setStatusSelecionadoList(new ArrayList<Status>());
            }

            if (status.getSelecionado()) {
                if (!getStatusNomeSelecionadoList().contains(status.getNome())) {
                    getStatusSelecionadoList().add(status);
                    getStatusNomeSelecionadoList().add(status.getNome());
                }

            } else {
                if (getStatusNomeSelecionadoList().contains(status.getNome())) {
                    getStatusSelecionadoList().remove(status);
                    getStatusNomeSelecionadoList().remove(status.getNome());
                }
            }
        }
    }

    public String getStatusSelecionados() {
        if (statusNomeSelecionadoList == null
                || statusNomeSelecionadoList.toString().equals(
                Constantes.LISTA_STRING_VAZIA)) {
            return "";
        }
        return statusNomeSelecionadoList.toString();
    }

    public void buscaFilas() {
        try {
            if (getEquipeSelecionadoList() != null && !equipeSelecionadoList.isEmpty()) {
                buscaFilaPorEquipe();
            } else {
                setConfiguracaoFilaList(configuracaoFilaService.findAll("ConfiguracaoFila.NOME"));
            }
            mostraGridFila();
        } catch (ServiceException ex) {
        	logger.error(ex);
        	error(ex);
            //Logger.getLogger(AbstractAcompanhamentoCasoBB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void buscaFilaPorEquipe() {
        try {
            if (getEquipeSelecionadoList() != null && !equipeSelecionadoList.isEmpty()) {

                List<EquipeFila> equipeFilaList = equipeFilaService.buscaPorEquipeList(equipeSelecionadoList);
                if (configuracaoFilaList == null) {
                    setConfiguracaoFilaList(new ArrayList<ConfiguracaoFila>());
                }
                getConfiguracaoFilaList().clear();

                configuraEquipeFila(equipeFilaList);
            }
        } catch (ServiceException e) {
        	logger.error(e);
            error(e);
        }
    }

	private void configuraEquipeFila(List<EquipeFila> equipeFilaList) {
		for (ConfiguracaoFila configuracaoFila : getConfiguracaoFilaSelecionadoList()) {
		    ConfiguracaoFila filaARemover = null;
		    for (EquipeFila equipeFila : equipeFilaList) {
		        if (equipeFila.getConfiguracaoFila().equals(configuracaoFila)) {
		            filaARemover = equipeFila.getConfiguracaoFila();
		            break;
		        }
		    }
		    if (filaARemover != null) {
		        getConfiguracaoFilaSelecionadoList().remove(filaARemover);
		        getConfiguracaoFilaNomeSelecionadoList().remove(filaARemover.getNome());

		    }

		}

		for (EquipeFila equipeFila : equipeFilaList) {
		    ConfiguracaoFila cf = equipeFila.getConfiguracaoFila();
		    getConfiguracaoFilaList().add(cf);
		    if (configuracaoFilaSelecionadoList.contains(cf)) {
		        cf.setSelecionado(Boolean.TRUE);
		    }
		}
	}

    public void buscaAtendentes() {
        try {
            if (getConfiguracaoFilaSelecionadoList() != null && !getConfiguracaoFilaSelecionadoList().isEmpty()) {
                buscaAtendentePorFila();
            } else if (getEquipeSelecionadoList() != null && !getEquipeSelecionadoList().isEmpty()) {
                buscaAtendentePorEquipe();
            } else {
                setAtendenteList(atendenteService.findAll("Atendente.LOGIN"));
            }
            mostraGridAnalista();
        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }
    }

    public void buscaAtendentePorFila() {
        try {
            if (getAtendenteSelecionadoList() != null && !getAtendenteSelecionadoList().isEmpty()) {

                List<Atendente> atendentes = atendenteService.buscaPorConfiguracaoFilaList(getConfiguracaoFilaSelecionadoList());
                if (atendenteList == null) {
                    setAtendenteList(new ArrayList<Atendente>());
                }
                atendenteList.clear();

                configuraAtendente(atendentes);
            }
        } catch (ServiceException e) {
        	logger.error(e);
            error(e);
        }
    }

	private void configuraAtendente(List<Atendente> atendentes) {
		if (atendentes != null && !atendentes.isEmpty()) {
		    
		    setAtendenteList(atendentes);

		    for (Iterator<Atendente> it = atendenteSelecionadoList.iterator(); it.hasNext();) {
		        Atendente atendente = it.next();
		        if (!atendentes.contains(atendente)) {
		            it.remove();
		        }
		    }

		    for (Atendente atendente : atendentes) {
		        if (atendenteSelecionadoList.contains(atendente)) {
		            atendente.setSelecionado(Boolean.TRUE);
		        }
		    }
		}
	}

    public void buscaAtendentePorEquipe() {
        try {
            setAtendenteList(atendenteService.buscaPorEquipeList(equipeSelecionadoList));
        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }

    }

    public void selecionaTodosEquipe() {
        for (Equipe item : getEquipeList()) {
            if (selecionaTodosEquipe == Boolean.TRUE) {
                item.setSelecionado(Boolean.TRUE);
            } else {
                item.setSelecionado(Boolean.FALSE);
            }
            marcaDesmarcaEquipe(item);
        }
    }

    public void marcaDesmarcaEquipe(Equipe equipe) {
        if (equipe != null && equipe.getSelecionado() != null
                && equipe.getSelecionado() != null) {
            marcaDesmEquipe(equipe);
        }
    }

	private void marcaDesmEquipe(Equipe equipe) {
		if (getEquipeNomeSelecionadoList() == null) {
		    setEquipeNomeSelecionadoList(new ArrayList<String>());
		}
		if (getEquipeSelecionadoList() == null) {
		    setEquipeSelecionadoList(new ArrayList<Equipe>());
		}
		if (equipe.getSelecionado()) {
		    if (!getEquipeNomeSelecionadoList().contains(equipe.getNome())) {
		        getEquipeNomeSelecionadoList().add(equipe.getNome());
		        getEquipeSelecionadoList().add(equipe);
		    }

		} else {
		    if (getEquipeNomeSelecionadoList().contains(equipe.getNome())) {
		        getEquipeNomeSelecionadoList().remove(equipe.getNome());
		        getEquipeSelecionadoList().remove(equipe);
		    }
		}
		if (getConfiguracaoFilaSelecionadoList() != null) {
		    getConfiguracaoFilaSelecionadoList().clear();
		    getConfiguracaoFilaNomeSelecionadoList().clear();
		}
		if (getAtendenteSelecionadoList() != null) {
		    getAtendenteSelecionadoList().clear();
		    getAtendenteNomeSelecionadoList().clear();
		}
	}

    public String getEquipeSelecionados() {
        if (equipeNomeSelecionadoList == null
                || equipeNomeSelecionadoList.toString().equals(
                Constantes.LISTA_STRING_VAZIA)) {
            return "";
        }
        return equipeNomeSelecionadoList.toString();
    }

    public void limpaAtendentes() {
        setSelecionaTodosAtendente(Boolean.FALSE);
        selecionaTodosAtendentes();
    }

    public void selecionaTodosAtendentes() {
        for (Atendente item : getAtendenteList()) {
            if (selecionaTodosAtendente == Boolean.TRUE) {
                item.setSelecionado(Boolean.TRUE);
            } else {
                item.setSelecionado(Boolean.FALSE);
            }
            marcaDesmarcaAtendente(item);
        }
    }

    public void marcaDesmarcaAtendente(Atendente atendente) {
        if (atendente != null && atendente.getSelecionado() != null) {

            if (atendente.getSelecionado()) {
                if (!getAtendenteNomeSelecionadoList().contains(
                        atendente.getLogin())) {
                    getAtendenteNomeSelecionadoList().add(atendente.getLogin());
                    getAtendenteSelecionadoList().add(atendente);
                }
            } else {
                if (getAtendenteNomeSelecionadoList().contains(
                        atendente.getLogin())) {
                    getAtendenteNomeSelecionadoList().remove(
                            atendente.getLogin());
                    getAtendenteSelecionadoList().remove(atendente);
                }
            }
        }
    }

    public String getAtendentesSelecionados() {
        if (atendenteNomeSelecionadoList == null
                || atendenteNomeSelecionadoList.toString().equals(
                Constantes.LISTA_STRING_VAZIA)) {
            return "";
        }
        return atendenteNomeSelecionadoList.toString();
    }

    public abstract String filtrar();

    public final Integer getSla() {
        return sla;
    }

    public final void setSla(Integer sla) {
        this.sla = sla;
    }

    public final Integer getIdCaso() {
        return caso.getIdCaso();
    }

    public final void setIdCaso(Integer idCaso) {
        caso.setIdCaso(idCaso);
    }

    public final Integer getIdExterno() {
        return idExterno;
    }

    public final void setIdExterno(Integer idExterno) {
        this.idExterno = idExterno;
    }

    public final Date getDataInicio() {
        return dataInicio != null ? new Date(dataInicio.getTime()) : null;
    }

    public final void setDataInicio(Date dataInicio) {
        this.dataInicio = dataInicio != null ? new Date(dataInicio.getTime()) : null;
    }

    public final Date getDataFim() {
        return dataFim != null ? new Date(dataFim.getTime()) : null;
    }

    public final void setDataFim(Date dataFim) {
        this.dataFim = dataFim != null ? new Date(dataFim.getTime()) : null;
    }

    /**
     * COMBOS
     */
    public List<Status> getStatusList() {
        return statusList;
    }

    public void setStatusList(List<Status> statusList) {
        this.statusList = statusList;
    }

    public void geraGrafico(List<Caso> casoList) {
        setCasosDentroPrazo(0);
        setCasosForaPrazo(0);
        setCasosAbertos(0);
        setCasosFechados(0);
        Map<String, Integer> mapGrafico = new HashMap<String, Integer>();
        Map<String, Integer> mapGraficoPendente = new HashMap<String, Integer>();
        Map<String, Integer> mapGraficoFinalizado = new HashMap<String, Integer>();

        for (Caso casoItem : casoList) {
            if (!casoItem.getFlagFinalizado()) {
                contaCasoAberto(mapGraficoPendente, casoItem);
            }

            if (casoItem.getFlagFinalizado()) {
                contaCasoFechado(mapGraficoFinalizado, casoItem);
            }

            if (mapGrafico.containsKey(casoItem.getStatus().getNome())) {
                Integer valor = mapGrafico.get(casoItem.getStatus().getNome());
                valor++;
                mapGrafico.put(casoItem.getStatus().getNome(), valor);
            } else {
                mapGrafico.put(casoItem.getStatus().getNome(), 1);
            }
        }

        graficoPrincipal = "";
        StringBuilder string = new StringBuilder();
        StringBuilder pendente = new StringBuilder();
        StringBuilder finalizado = new StringBuilder();
        Boolean proximo = false;

        preparaGrafico(mapGrafico, mapGraficoPendente, mapGraficoFinalizado, string, pendente, finalizado, proximo);
        
        mostraSumarizado = true;
        graficoPrincipal = string.toString();
        graficoPendente = pendente.toString();
        graficoFinalizado = finalizado.toString();
    }

	private void preparaGrafico(Map<String, Integer> mapGrafico,
			Map<String, Integer> mapGraficoPendente,
			Map<String, Integer> mapGraficoFinalizado, StringBuilder string,
			StringBuilder pendente, StringBuilder finalizado, Boolean proximo) {
		for (Map.Entry<String, Integer> candidatoEntry : mapGrafico.entrySet()) {
            if (proximo) {
                string.append(";");
            }

            string.append(candidatoEntry.getKey());
            string.append(",");
            string.append(candidatoEntry.getValue());
            proximo = true;
        }
        proximo = false;
        for (Map.Entry<String, Integer> candidatoEntry : mapGraficoPendente.entrySet()) {
            if (proximo) {
                pendente.append(";");
            }

            pendente.append(candidatoEntry.getKey());
            pendente.append(",");
            pendente.append(candidatoEntry.getValue());
            proximo = true;
        }
        proximo = false;
        for (Map.Entry<String, Integer> candidatoEntry : mapGraficoFinalizado.entrySet()) {
            if (proximo) {
                finalizado.append(";");
            }

            finalizado.append(candidatoEntry.getKey());
            finalizado.append(",");
            finalizado.append(candidatoEntry.getValue());
            proximo = true;
        }
	}

	private void contaCasoFechado(Map<String, Integer> mapGraficoFinalizado,
			Caso casoItem) {
		casosFechados++;
		if (casoItem.getIconeSla().equals(Constantes.ICONE_ATRASADO)) {
		    casosForaPrazo++;
		    if (mapGraficoFinalizado.containsKey(FINALIZADO_FORA_DO_PRAZO)) {
		        Integer valor = mapGraficoFinalizado.get(FINALIZADO_FORA_DO_PRAZO);
		        valor++;
		        mapGraficoFinalizado.put(FINALIZADO_FORA_DO_PRAZO,
		                valor);
		    } else {
		        mapGraficoFinalizado.put(FINALIZADO_FORA_DO_PRAZO, 1);
		    }
		} else {
		    casosDentroPrazo++;
		    if (mapGraficoFinalizado.containsKey(FINALIZADO_DENTRO_DO_PRAZO)) {
		        Integer valor = mapGraficoFinalizado.get(FINALIZADO_DENTRO_DO_PRAZO);
		        valor++;
		        mapGraficoFinalizado.put(FINALIZADO_DENTRO_DO_PRAZO,
		                valor);
		    } else {
		        mapGraficoFinalizado.put(FINALIZADO_DENTRO_DO_PRAZO,
		                1);
		    }
		}
	}

	private void contaCasoAberto(Map<String, Integer> mapGraficoPendente,
			Caso casoItem) {
		casosAbertos++;
		if (casoItem.getIconeSla().equals(Constantes.ICONE_ATRASADO)) {
		    casosForaPrazo++;
		    if (mapGraficoPendente.containsKey(PENDENTE_FORA_DO_PRAZO)) {
		        Integer valor = mapGraficoPendente.get(PENDENTE_FORA_DO_PRAZO);
		        valor++;
		        mapGraficoPendente.put(PENDENTE_FORA_DO_PRAZO, valor);
		    } else {
		        mapGraficoPendente.put(PENDENTE_FORA_DO_PRAZO, 1);
		    }
		} else {
		    casosDentroPrazo++;
		    if (mapGraficoPendente.containsKey(PENDENTE_DENTRO_DO_PRAZO)) {
		        Integer valor = mapGraficoPendente.get(PENDENTE_DENTRO_DO_PRAZO);
		        valor++;
		        mapGraficoPendente.put(PENDENTE_DENTRO_DO_PRAZO,
		                valor);
		    } else {
		        mapGraficoPendente.put(PENDENTE_DENTRO_DO_PRAZO, 1);
		    }
		}
	}

    public final List<ConfiguracaoFila> getConfiguracaoFilaList() {

        return configuracaoFilaList;
    }

    public final void setConfiguracaoFilaList(
            List<ConfiguracaoFila> configuracaoFilaList) {
        this.configuracaoFilaList = configuracaoFilaList;
    }

    public final List<Atendente> getAtendenteList() {
        return atendenteList;
    }

    public final void setAtendenteList(List<Atendente> atendenteList) {
        this.atendenteList = atendenteList;
    }

    public final void setCaso(Caso caso) {
        this.caso = caso;
    }

    public final Caso getCaso() {
        return caso;
    }

    public void setCasosDentroPrazo(Integer casosDentroPrazo) {
        this.casosDentroPrazo = casosDentroPrazo;
    }

    public Integer getCasosDentroPrazo() {
        return casosDentroPrazo;
    }

    public void setCasosForaPrazo(Integer casosForaPrazo) {
        this.casosForaPrazo = casosForaPrazo;
    }

    public Integer getCasosForaPrazo() {
        return casosForaPrazo;
    }

    public void setGraficoPrincipal(String graficoPrincipal) {
        this.graficoPrincipal = graficoPrincipal;
    }

    public String getGraficoPrincipal() {
        return graficoPrincipal;
    }

    public void setMostraSumarizado(Boolean mostraSumarizado) {
        this.mostraSumarizado = mostraSumarizado;
    }

    public Boolean getMostraSumarizado() {
        return mostraSumarizado;
    }

    public void setCasosAbertos(Integer casosAbertos) {
        this.casosAbertos = casosAbertos;
    }

    public Integer getCasosAbertos() {
        return casosAbertos;
    }

    public void setCasosFechados(Integer casosFechados) {
        this.casosFechados = casosFechados;
    }

    public Integer getCasosFechados() {
        return casosFechados;
    }

    public void setGraficoPendente(String graficoPendente) {
        this.graficoPendente = graficoPendente;
    }

    public String getGraficoPendente() {
        return graficoPendente;
    }

    public void setGraficoFinalizado(String graficoFinalizado) {
        this.graficoFinalizado = graficoFinalizado;
    }

    public String getGraficoFinalizado() {
        return graficoFinalizado;
    }

    public final String getContextPath() {
        return contextPath;
    }

    public final void setContextPath(String contextPath) {
        this.contextPath = contextPath;
    }

    public final List<ConfiguracaoFila> getConfiguracaoFilaSelecionadoList() {
        return configuracaoFilaSelecionadoList;
    }

    public final void setConfiguracaoFilaSelecionadoList(
            List<ConfiguracaoFila> configuracaoFilaSelecionadoList) {
        this.configuracaoFilaSelecionadoList = configuracaoFilaSelecionadoList;
    }

    public final List<Status> getStatusSelecionadoList() {
        return statusSelecionadoList;
    }

    public final void setStatusSelecionadoList(
            List<Status> statusSelecionadoList) {
        this.statusSelecionadoList = statusSelecionadoList;
    }

    public final List<Atendente> getAtendenteSelecionadoList() {
        return atendenteSelecionadoList;
    }

    public final void setAtendenteSelecionadoList(
            List<Atendente> atendenteSelecionadoList) {
        this.atendenteSelecionadoList = atendenteSelecionadoList;
    }

    public final Integer getHora() {
        return hora;
    }

    public final void setHora(Integer hora) {
        this.hora = hora;
    }

    public final Integer getMinuto() {
        return minuto;
    }

    public final void setMinuto(Integer minuto) {
        this.minuto = minuto;
    }

    public final List<String> getConfiguracaoFilaNomeSelecionadoList() {

        if (configuracaoFilaNomeSelecionadoList == null) {
            configuracaoFilaNomeSelecionadoList = new ArrayList<String>();
        }
        return configuracaoFilaNomeSelecionadoList;
    }

    public final void setConfiguracaoFilaNomeSelecionadoList(
            List<String> configuracaoFilaNomeSelecionadoList) {
        this.configuracaoFilaNomeSelecionadoList = configuracaoFilaNomeSelecionadoList;
    }

    public final boolean isSelecionaTodosConfiguracaoFila() {
        return selecionaTodosConfiguracaoFila;
    }

    public final void setSelecionaTodosConfiguracaoFila(
            boolean selecionaTodosConfiguracaoFila) {
        this.selecionaTodosConfiguracaoFila = selecionaTodosConfiguracaoFila;
    }

    public final List<String> getStatusNomeSelecionadoList() {
        if (statusNomeSelecionadoList == null) {
            statusNomeSelecionadoList = new ArrayList<String>();
        }
        return statusNomeSelecionadoList;
    }

    public final void setStatusNomeSelecionadoList(
            List<String> statusNomeSelecionadoList) {
        this.statusNomeSelecionadoList = statusNomeSelecionadoList;
    }

    public final List<String> getAtendenteNomeSelecionadoList() {
        if (atendenteNomeSelecionadoList == null) {
            atendenteNomeSelecionadoList = new ArrayList<String>();
        }
        return atendenteNomeSelecionadoList;
    }

    public final void setAtendenteNomeSelecionadoList(
            List<String> atendenteNomeSelecionadoList) {
        this.atendenteNomeSelecionadoList = atendenteNomeSelecionadoList;
    }

    public final ConfiguracaoFila getConfiguracaoFilaSelecionado() {
        return configuracaoFilaSelecionado;
    }

    public final boolean isSelecionaTodosStatus() {
        return selecionaTodosStatus;
    }

    public final void setSelecionaTodosStatus(boolean selecionaTodosStatus) {
        this.selecionaTodosStatus = selecionaTodosStatus;
    }

    public final boolean isSelecionaTodosAtendente() {
        return selecionaTodosAtendente;
    }

    public final void setSelecionaTodosAtendente(boolean selecionaTodosAtendente) {
        this.selecionaTodosAtendente = selecionaTodosAtendente;
    }

    public final List<String> getEquipeNomeSelecionadoList() {
        return equipeNomeSelecionadoList;
    }

    public final void setEquipeNomeSelecionadoList(List<String> equipeNomeSelecionadoList) {
        this.equipeNomeSelecionadoList = equipeNomeSelecionadoList;
    }

    public final List<Equipe> getEquipeSelecionadoList() {
        return equipeSelecionadoList;
    }

    public final void setEquipeSelecionadoList(List<Equipe> equipeSelecionadoList) {
        this.equipeSelecionadoList = equipeSelecionadoList;
    }

    public final boolean isSelecionaTodosEquipe() {
        return selecionaTodosEquipe;
    }

    public final void setSelecionaTodosEquipe(boolean selecionaTodosEquipe) {
        this.selecionaTodosEquipe = selecionaTodosEquipe;
    }

    public final List<Equipe> getEquipeList() {
        return equipeList;
    }

    public final void setEquipeList(List<Equipe> equipeList) {
        this.equipeList = equipeList;
    }

    public boolean isFlagMostraGridAnalista() {
        return flagMostraGridAnalista;
    }

    public void setFlagMostraGridAnalista(boolean flagMostraGridAnalista) {
        this.flagMostraGridAnalista = flagMostraGridAnalista;
    }

    public boolean isFlagMostraGridEquipe() {
        return flagMostraGridEquipe;
    }

    public void setFlagMostraGridEquipe(boolean flagMostraGridEquipe) {
        this.flagMostraGridEquipe = flagMostraGridEquipe;
    }

    public boolean isFlagMostraGridFila() {
        return flagMostraGridFila;
    }

    public void setFlagMostraGridFila(boolean flagMostraGridFila) {
        this.flagMostraGridFila = flagMostraGridFila;
    }

    public boolean isFlagMostraGridStatus() {
        return flagMostraGridStatus;
    }

    public void setFlagMostraGridStatus(boolean flagMostraGridStatus) {
        this.flagMostraGridStatus = flagMostraGridStatus;
    }

	public Date getDataInicioFechamento() {
		return dataInicioFechamento != null ? new Date(dataInicioFechamento.getTime()) : null;
	}

	public void setDataInicioFechamento(Date dataInicioFechamento) {
		this.dataInicioFechamento = dataInicioFechamento != null ? new Date(dataInicioFechamento.getTime()) : null;
	}

	public Date getDataFimFechamento() {
		return dataFimFechamento != null ? new Date(dataFimFechamento.getTime()) : null;
	}

	public void setDataFimFechamento(Date dataFimFechamento) {
		this.dataFimFechamento = dataFimFechamento != null ? new Date(dataFimFechamento.getTime()) : null;
	}

	public Integer getHoraMaior() {
		return horaMaior;
	}

	public void setHoraMaior(Integer horaMaior) {
		this.horaMaior = horaMaior;
	}

	public Integer getMinutoMaior() {
		return minutoMaior;
	}

	public void setMinutoMaior(Integer minutoMaior) {
		this.minutoMaior = minutoMaior;
	}

	public Character getFlagRechamadoConsulta() {
		return flagRechamadoConsulta;
	}

	public void setFlagRechamadoConsulta(Character flagRechamadoConsulta) {
		this.flagRechamadoConsulta = flagRechamadoConsulta;
	}
}
