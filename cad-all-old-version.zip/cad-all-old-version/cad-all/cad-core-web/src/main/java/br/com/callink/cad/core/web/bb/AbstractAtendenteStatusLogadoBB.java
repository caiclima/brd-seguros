package br.com.callink.gbo.core.web.bb;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.model.SelectItem;

import br.com.callink.gbo.core.web.bb.util.JSFUtil;
import br.com.callink.gbo.pojo.Atendente;
import br.com.callink.gbo.pojo.AtendenteStatus;
import br.com.callink.gbo.pojo.ParametroGBO;
import br.com.callink.gbo.service.IAtendenteService;
import br.com.callink.gbo.service.IAtendenteStatusService;
import br.com.callink.gbo.service.IParametroGBOService;
import br.com.callink.gbo.service.IStatusAtendenteService;
import br.com.callink.gbo.service.exception.ServiceException;
import br.com.callink.gbo.util.Constantes;

/**
 * Classe abstrata para auxiliar no tratamento dos status do atendente. Cada expecialização pode 
 * ter suas próprias regras para retornar ou pausar um atendimento.
 * @author brunomt
 */
public abstract class AbstractAtendenteStatusLogadoBB<T extends AtendenteStatus, SERVICE extends IAtendenteStatusService> extends GboGenericCrud<T, SERVICE> implements Serializable {
	
	private static final long serialVersionUID = -5715931879149327954L;
	
	private Boolean flagControleStatusGBO;
    private List<AtendenteStatus> atendenteStatusList;
    private AtendenteStatus atendenteStatusSelecionado;
    private int mostraModal;
    private int pausado;
    
    @EJB
    private IAtendenteService atendenteService;
    @EJB
    private IStatusAtendenteService statusAtendenteService;
    @EJB
    private IAtendenteStatusService atendenteStatusService;
    @EJB
    private IParametroGBOService parametroGBOService;
    
    @PostConstruct
    public void init() {
    	mostraModal = 0;
        pausado = 0;
    }
    
    public void alteraAtendenteStatus() {
        try {
            if (atendenteStatusSelecionado != null && atendenteStatusSelecionado.getIdAtendenteStatus() != null) {
                mostraModal = 1;
                verificaAtendenteCaso();
            }
            
            if (atendenteStatusSelecionado != null && atendenteStatusSelecionado.getIdAtendenteStatus() != null && pausado == 0) {
                
                Atendente atendente = atendenteService.findByLogin(getUserInfo().getUserLogin());
                if (atendente != null && atendente.getIdAtendente() != null) {
                	statusAtendenteService.salvarNovoStatusAtendendimento(null, atendente, atendenteStatusSelecionado, Boolean.TRUE);
                    pausado = 1;
                }
            } 
        } catch (Exception ex) {
        	logger.error(ex);
            error(ex);
        }
    }
    
    public abstract void retornarAtendimento();

    public List<SelectItem> getAtendenteStatusList() {
        if (atendenteStatusList == null) {
            try {
                atendenteStatusList = atendenteStatusService.buscaAtendenteStatusPausado();
            } catch (ServiceException ex) {
            	logger.error(ex);
                error(ex);
            }
        }
        
        return JSFUtil.toSelectItemConsulta(atendenteStatusList);
    }

    public void setAtendenteStatusList(List<AtendenteStatus> atendenteStatusList) {
        this.atendenteStatusList = atendenteStatusList;
    }

    public AtendenteStatus getAtendenteStatusSelecionado() {
        return atendenteStatusSelecionado;
    }

    public void setAtendenteStatusSelecionado(AtendenteStatus atendenteStatusSelecionado) {
        this.atendenteStatusSelecionado = atendenteStatusSelecionado;
    }

    public int getMostraModal() {
        return mostraModal;
    }

    public void setMostraModal(int mostraModal) {
        this.mostraModal = mostraModal;
    }

    public int getPausado() {
        return pausado;
    }

    public void setPausado(int pausado) {
        this.pausado = pausado;
    }

    public Boolean getFlagControleStatusGBO() {
        if (flagControleStatusGBO == null) {
            ParametroGBO param = null;
            try {
                param = parametroGBOService.findByParam(Constantes.FLAG_CONTROLE_STATUS);
            } catch (ServiceException ex) {
            	logger.error(ex);
                error(ex);
            }
            if (param != null && param.getValor() != null) {            
                flagControleStatusGBO = Boolean.valueOf(param.getValor());
            } else {
                flagControleStatusGBO = true;
            }
        }
        return flagControleStatusGBO;
    }

    public void setFlagControleStatusGBO(Boolean flagControleStatusGBO) {
        this.flagControleStatusGBO = flagControleStatusGBO;
    }

    public abstract void verificaAtendenteCaso() throws ServiceException;
}
