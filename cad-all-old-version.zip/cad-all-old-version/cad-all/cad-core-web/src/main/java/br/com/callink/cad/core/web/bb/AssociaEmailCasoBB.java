package br.com.callink.gbo.core.web.bb;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.apache.commons.lang.StringUtils;

import br.com.callink.gbo.core.web.bb.util.BundleHelper;
import br.com.callink.gbo.pojo.Caso;
import br.com.callink.gbo.pojo.Email;
import br.com.callink.gbo.service.ICasoService;
import br.com.callink.gbo.service.IEmailService;
import br.com.callink.gbo.service.exception.ServiceException;
import br.com.callink.gbo.service.exception.ValidationException;

/**
 * 
 * @author Ednaldo Caic [ednaldo@swb.com.br]
 * @since 22/03/2012
 */
@ManagedBean
@ViewScoped
public class AssociaEmailCasoBB extends GboGenericCrud<Email, IEmailService> {

    private static final long serialVersionUID = 1L;
    
    private List<Caso> casoList;
    private Caso casoSelecionado;
    private String manifestacao;
    private boolean exibeBotao;
    
    @EJB
    private IEmailService emailService;
    @EJB
    private ICasoService casoService;
    
    @PostConstruct
    public void init() {
    	try {
    		setPojo(new Email());
            setCasoSelecionado(new Caso());
            setPojos(getService().findEmailsSemCaso());
        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }
    }

    @Override
    public void novo() {
        setPojo(new Email());
        setCasoSelecionado(new Caso());
        setExibeBotao(Boolean.FALSE);
    }

    @Override
    public String salvar() {
        try {
            if(casoSelecionado == null){
                error("Campo Obrigat\u00F3rio : Caso");
                return "";
            }
            
            getService().associaEmailCaso(getPojo(), casoSelecionado, getUserInfo().getUserLogin());
            info(BundleHelper.getMessage("MSG_Save_Success", "bundleGbo"));
            
            setManifestacao("");
            getCasoList().clear();
            novo();
            filtrar();
            
        } catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException ex) {
			logger.error(ex);
            error(ex);
        }
        return "";
    }
    
    @Override
    public String filtrar() {
        try {
            setPojos(getService().findEmailsSemCaso());
        } catch (ServiceException ex) {
        	logger.error(ex);
            error("Erro ao buscar email que não possui caso associado.");
        }
        return "";
        
    }
    
    public void buscaCasos(){
        try {
            Caso caso = new Caso();
            if(StringUtils.isBlank(manifestacao)){
                error("Campo Obrigat\u00F3rio : Caso");
                return ;
            }
                if(casoList == null){
                    setCasoList(new ArrayList<Caso>());
                }
                
                caso.setIdExterno(manifestacao);
                
                getCasoList().clear();
                getCasoList().add(casoService.load(caso));
                
        }catch (ServiceException ex) {
			logger.error(ex);
            error(ex);
        }
    }
    
    public void selecionaCaso(Caso caso){
        setCasoSelecionado(caso);
        setExibeBotao(Boolean.TRUE);
    }
    
    public void retiraEmailLista(Email email) {
    	try {
    		getService().updateFlagDesativado(email);
    		filtrar();
    	} catch (Exception e) {
    		logger.error(e);
    		error(e);
		}
    }
    
    public void limpaCasoSelecionado(){
        setCasoSelecionado(new Caso());
        setExibeBotao(Boolean.FALSE);
        setManifestacao(null);
        if(getCasoList() == null){
            setCasoList(new ArrayList<Caso>());
        }
        getCasoList().clear();
    }
    
    public void mostraEmail(Email email){
        setPojo(email);
    }
    
    public void visualizaCasoSau(Caso caso){
        
    }
    

    public final List<Caso> getCasoList() {
        return casoList;
    }

    public final void setCasoList(List<Caso> casoList) {
        this.casoList = casoList;
    }

    public final Caso getCasoSelecionado() {
        return casoSelecionado;
    }

    public final void setCasoSelecionado(Caso casoSelecionado) {
        this.casoSelecionado = casoSelecionado;
    }

    public final String getManifestacao() {
        return manifestacao;
    }

    public final void setManifestacao(String manifestacao) {
        this.manifestacao = manifestacao;
    }

    public final boolean isExibeBotao() {
        return exibeBotao;
    }

    public final void setExibeBotao(boolean exibeBotao) {
        this.exibeBotao = exibeBotao;
    }
    
    @Override
	protected IEmailService getService() {
		return emailService;
	}
}
