/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.gbo.core.web.bb;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import br.com.callink.gbo.pojo.AssociaGrupoEmail;
import br.com.callink.gbo.pojo.EnderecoEmail;
import br.com.callink.gbo.pojo.GrupoEmail;
import br.com.callink.gbo.service.IAssociaGrupoEmailService;
import br.com.callink.gbo.service.IEnderecoEmailService;
import br.com.callink.gbo.service.IGrupoEmailService;
import br.com.callink.gbo.service.exception.ServiceException;
import br.com.callink.gbo.service.exception.ValidationException;


@ManagedBean
@ViewScoped
public class AssociaGrupoEmailBB extends GboGenericCrud<AssociaGrupoEmail, IAssociaGrupoEmailService> {

    private static final long serialVersionUID = 5670454269978023306L;
    private List<EnderecoEmail> enderecoEmailList;
    private List<GrupoEmail> grupoEmailList;
    
    @EJB
    private IAssociaGrupoEmailService associaGrupoEmailService;
    @EJB
    private IEnderecoEmailService enderecoEmailService;
    @EJB
    private IGrupoEmailService grupoEmailService;

    @PostConstruct
    public void init() {
    	setPojo(new AssociaGrupoEmail(new EnderecoEmail(), new GrupoEmail()));
    	limpar();
    }
    
    private void limpar() {
        novo();
    }

    @Override
    public String salvar() {
        try {
        	if (getPojo().getGrupoEmail() == null || getPojo().getGrupoEmail().getDescricao() == null
        			|| "".equals(getPojo().getGrupoEmail().getDescricao())
        			|| getPojo().getEnderecoEmail() == null || getPojo().getEnderecoEmail().getDescricao() == null
        			|| "".equals(getPojo().getEnderecoEmail().getDescricao())) {
        		handlerException(new ServiceException("Os campos Departamento e Endereço Email devem ser preenchidos."));
        	} else {
	        	getPojo().getEnderecoEmail().getDescricao();
	            getService().save(getPojo());
	            novo();
	            filtrar();
        	}
        } catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException ex) {
			logger.error(ex);
            error(ex);
        }
        return null;
    }
    
    public void filtrarEnderecoEmail() {
        try {
            EnderecoEmail endereco = getPojo().getEnderecoEmail();
            endereco.setFlagAtivo(Boolean.TRUE);
            enderecoEmailList = enderecoEmailService.findByExample(endereco, "EnderecoEmail.DESCRICAO");
        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }
    }

    public void filtrarGrupoEmail() {
        try {
            GrupoEmail grupoEmail = getPojo().getGrupoEmail();
            grupoEmail.setFlagAtivo(Boolean.TRUE);
            grupoEmailList = grupoEmailService.findByExample(grupoEmail, "GrupoEmail.DESCRICAO");
        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }
    }

    @Override
    public void novo() {
        setPojo(new AssociaGrupoEmail(new EnderecoEmail(), new GrupoEmail()));
        try {
            this.enderecoEmailList = enderecoEmailService.findAtivos("EnderecoEmail.DESCRICAO");
            this.grupoEmailList = grupoEmailService.findAtivos("GrupoEmail.DESCRICAO");
            setPojos(getService().findByGrupoEmailEnderecoEmail(new GrupoEmail(), new EnderecoEmail()));
        } catch (ServiceException e) {
        	logger.error(e);
            error(e);
        }
    }

    @Override
    public String filtrar() {
        try {
            GrupoEmail grupoEmail = getPojo().getGrupoEmail();
            EnderecoEmail enderecoEmail = getPojo().getEnderecoEmail();
            setPojos(getService().findByGrupoEmailEnderecoEmail(grupoEmail, enderecoEmail));
        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }
        return null;
    }
    
    public String excluir(AssociaGrupoEmail associaGrupoEmail) {
        try {
            getService().delete(associaGrupoEmail);
            filtrar();
        } catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException ex) {
			logger.error(ex);
            error(ex);
        }
        return null;
    }

    public List<EnderecoEmail> getEnderecoEmailList() {
        return enderecoEmailList;
    }

    public void setEnderecoEmailList(List<EnderecoEmail> enderecoEmailList) {
        this.enderecoEmailList = enderecoEmailList;
    }

    public List<GrupoEmail> getGrupoEmailList() {
        return grupoEmailList;
    }

    public void setGrupoEmailList(List<GrupoEmail> grupoEmailList) {
        this.grupoEmailList = grupoEmailList;
    }

    public void setEnderecoEmail(EnderecoEmail enderecoEmail) {
        getPojo().setEnderecoEmail(enderecoEmail);
    }

    public void setGrupoEmail(GrupoEmail grupoEmail) {
        getPojo().setGrupoEmail(grupoEmail);
    }
    
    @Override
	protected IAssociaGrupoEmailService getService() {
		return associaGrupoEmailService;
	}
}
