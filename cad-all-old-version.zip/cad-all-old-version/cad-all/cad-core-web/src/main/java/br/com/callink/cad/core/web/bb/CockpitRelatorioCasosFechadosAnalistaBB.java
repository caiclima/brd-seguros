package br.com.callink.gbo.core.web.bb;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import br.com.callink.gbo.pojo.RelatorioCasosFechados;
import br.com.callink.gbo.repository.to.CasoFechadoTO;
import br.com.callink.gbo.service.IRelatorioCasosFechadosService;
import br.com.callink.gbo.service.impl.RelatorioCasosFechadosService;


/**
 *
 * @author brunomt
 */
@ManagedBean
@ViewScoped
public class CockpitRelatorioCasosFechadosAnalistaBB extends GboGenericCrud<RelatorioCasosFechados, IRelatorioCasosFechadosService> {
	
	private static final long serialVersionUID = 1L;
	
	private List<CasoFechadoTO> casosFechadosList;
    private CasoFechadoTO casoTotal;
	private String equipeSelecionada;
	
	@EJB
	private IRelatorioCasosFechadosService relatorioCasosFechadosService;
	
	@PostConstruct
    public void init() {
		equipeSelecionada = (String) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("equipeSelecionada");
		retornaCasosFechados();
	}
	
	public void retornaCasosFechados() {
		try {
			casosFechadosList = relatorioCasosFechadosService.retornaCasosFechados(1, RelatorioCasosFechadosService.POR_ANALISTA, equipeSelecionada);
            casoTotal = relatorioCasosFechadosService.retornaTotal(casosFechadosList);
		} catch (Exception e) {
			logger.error(e);
			error("Erro ao buscar os casos fechados.");
		}
	}
	
	@Override
	public void novo() {
		setPojo(new RelatorioCasosFechados());
	}
	
	public List<CasoFechadoTO> getCasosFechadosList() {
		return casosFechadosList;
	}

	public void setCasosFechadosList(List<CasoFechadoTO> casosFechadosList) {
		this.casosFechadosList = casosFechadosList;
	}

    public CasoFechadoTO getCasoTotal() {
        return casoTotal;
    }

    public void setCasoTotal(CasoFechadoTO casoTotal) {
        this.casoTotal = casoTotal;
    }
	
    @Override
	protected IRelatorioCasosFechadosService getService() {
		return relatorioCasosFechadosService;
	}

}
