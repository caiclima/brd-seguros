package br.com.callink.gbo.core.web.bb;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import br.com.callink.gbo.pojo.RelatorioCasosFechados;
import br.com.callink.gbo.repository.to.CasoFechadoTO;
import br.com.callink.gbo.service.IRelatorioCasosFechadosService;
import br.com.callink.gbo.service.impl.RelatorioCasosFechadosService;


/**
 *
 * @author brunomt
 */
@ManagedBean
@ViewScoped
public class CockpitRelatorioCasosFechadosBB extends GboGenericCrud<RelatorioCasosFechados, IRelatorioCasosFechadosService> {
	
	private static final long serialVersionUID = 1L;
	
	private List<CasoFechadoTO> casosFechadosList;
    private CasoFechadoTO casoTotal;
    
    @EJB
    private IRelatorioCasosFechadosService relatorioCasosFechadosService;
    
	@PostConstruct
    public void init() {
		retornaCasosFechados();
	}
	
	public void retornaCasosFechados() {
		try {
			casosFechadosList = relatorioCasosFechadosService.retornaCasosFechados(1, RelatorioCasosFechadosService.POR_HORA, null);
            casoTotal = relatorioCasosFechadosService.retornaTotal(casosFechadosList);
		} catch (Exception e) {
			logger.error(e);
			error("Erro ao buscar os casos fechados.");
		}
	}
	
	@Override
	public void novo() {
		setPojo(new RelatorioCasosFechados());
	}

	public List<CasoFechadoTO> getCasosFechadosList() {
		return casosFechadosList;
	}

	public void setCasosFechadosList(List<CasoFechadoTO> casosFechadosList) {
		this.casosFechadosList = casosFechadosList;
	}

    public CasoFechadoTO getCasoTotal() {
        return casoTotal;
    }

    public void setCasoTotal(CasoFechadoTO casoTotal) {
        this.casoTotal = casoTotal;
    }
	
    @Override
	protected IRelatorioCasosFechadosService getService() {
		return relatorioCasosFechadosService;
	}

}
