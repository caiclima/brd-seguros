/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.gbo.core.web.bb;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import br.com.callink.gbo.pojo.Atendente;
import br.com.callink.gbo.pojo.ConfiguracaoFila;
import br.com.callink.gbo.pojo.Equipe;
import br.com.callink.gbo.pojo.EquipeFila;
import br.com.callink.gbo.pojo.ParametroGBO;
import br.com.callink.gbo.pojo.StatusAtendente;
import br.com.callink.gbo.repository.MensagemToolbar;
import br.com.callink.gbo.repository.MetasUphCache;
import br.com.callink.gbo.repository.RelatorioDiv;
import br.com.callink.gbo.repository.RelatorioStatusAtendente;
import br.com.callink.gbo.repository.to.CabMetaTO;
import br.com.callink.gbo.repository.to.MetaFilaTO;
import br.com.callink.gbo.service.IAtendenteService;
import br.com.callink.gbo.service.IConfiguracaoFilaService;
import br.com.callink.gbo.service.IEquipeFilaService;
import br.com.callink.gbo.service.IEquipeService;
import br.com.callink.gbo.service.IGboToolbarBusinessAppService;
import br.com.callink.gbo.service.IParametroGBOService;
import br.com.callink.gbo.service.IStatusAtendenteService;
import br.com.callink.gbo.service.exception.ServiceException;
import br.com.callink.gbo.service.repository.ControleStatusAtendentes;
import br.com.callink.gbo.util.Constantes;
import br.com.callink.gbo.util.DateUtils;


/**
 *
 * @author brunomt
 */
@ManagedBean
@ViewScoped
public class CockpitStatusAtendenteBB extends GboGenericCrud<StatusAtendente, IStatusAtendenteService> {

	private static final long serialVersionUID = 1L;
	
	private boolean flagIniciaBAppToolbar;
	
	private boolean selecionaTodosConfiguracaoFila;
    private boolean selecionaTodosAtendente;
    private boolean selecionaTodosEquipe;
    private List<Atendente> atendenteSelecionadoList;
    private List<Equipe> equipeSelecionadoList;
    private List<ConfiguracaoFila> configuracaoFilaList;
    private List<Atendente> atendenteList;
    private List<Equipe> equipeList;
    private List<ConfiguracaoFila> configuracaoFilaSelecionadoList;
    private ConfiguracaoFila configuracaoFilaSelecionado;
    private List<String> configuracaoFilaNomeSelecionadoList;
    private List<String> atendenteNomeSelecionadoList;
    private List<String> equipeNomeSelecionadoList;
    private String valorDiv;
    private String coresDivs;
    private List<StatusAtendente> statusAtendenteList;
    private List<StatusAtendente> statusAtendenteListFilter;
    private List<RelatorioDiv> relatorioDivs;
    private Integer totalAtendentes;
    private List<MetaFilaTO> listMetaFilaTo;
    
    List<Integer> listIdStatusAtendentesSelecionados = null;
    
    private RelatorioStatusAtendente relatorioStatusAtendente;
    
    private MensagemToolbar mensagemToolbar;
    
    @EJB
    private IStatusAtendenteService statusAtendenteService;
    @EJB
    private IParametroGBOService parametroGBOService;
    @EJB
    private IGboToolbarBusinessAppService gboToolbarBusinessAppService;
    @EJB
    private IAtendenteService atendenteService;
    @EJB
    private IConfiguracaoFilaService configuracaoFilaService;
    @EJB
    private IEquipeFilaService equipeFilaService;
    @EJB
    private IEquipeService equipeService;
    
    @PostConstruct
    public void init() {
    	configuracaoFilaSelecionadoList = new ArrayList<ConfiguracaoFila>();
        atendenteSelecionadoList = new ArrayList<Atendente>();
        equipeSelecionadoList = new ArrayList<Equipe>();
        
        mensagemToolbar = new MensagemToolbar();
        
        verificaFlagIniciaBappToolbar();
    }
    
    private void verificaFlagIniciaBappToolbar() {
    	try {
    		ParametroGBO parametroGBO = parametroGBOService.findByParam(Constantes.FLAG_INICIA_BAPP_TOOLBAR);
    		setFlagIniciaBAppToolbar(Boolean.valueOf(parametroGBO.getValor()));
    	} catch (Exception e) {
    		logger.error(e);
    		//Logger.getLogger(AbstractAcompanhamentoCasoBB.class.getName()).log(Level.SEVERE, null, e);
		}
    }
    
    public String filtrar() {
        try {
            statusAtendenteList = ControleStatusAtendentes.getMapStatusAtendente(configuracaoFilaSelecionadoList, atendenteSelecionadoList, equipeSelecionadoList, getService().getDataBanco());
            
            statusAtendenteListFilter = ControleStatusAtendentes.getFilterMapStatusAtendenteOrder(statusAtendenteList, getListIdStatusAtendentesSelecionados(), "LOGIN");
                     
            geraGrafico();
        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }
        return "";
    }
    
	public void mostraUph(String login) {
		try {
			
			CabMetaTO cabMetaTO = MetasUphCache.montaListaByUser(login);
			
			if(cabMetaTO!= null){
				listMetaFilaTo = cabMetaTO.getListaMetaFilaTO();
			}
		} catch (Exception e) {
			logger.error(e);
			handlerException(e);
		}
	}
	
	private void limpaMensagemToolbar() {
		mensagemToolbar = new MensagemToolbar();
	}
	
	public void setLoginMensagemToolbar(String login) {
		limpaMensagemToolbar();
		getMensagemToolbar().setUsuarioSSORemetente(login);
	}
	
	public void setEquipeMensagemToolbar() {
		limpaMensagemToolbar();
		getMensagemToolbar().setEquipeAtendentes(equipeSelecionadoList);
	}
	
	public void setAnalistaAtendentesMensagemToolbar() {
		limpaMensagemToolbar();
		getMensagemToolbar().setAnalistasAtendentes(atendenteSelecionadoList);
	}
	
	public void enviaMensagemToolbar(){
		try {
			String loginUsuario = getUserInfo().getUserLogin();
			
			getMensagemToolbar().setUsuarioSSOEmitente(loginUsuario);
		
			gboToolbarBusinessAppService.enviaMensagemToolbar(mensagemToolbar);
			
			limpaMensagemToolbar();
			
			info("Mensagem enviada com sucesso.");
		} catch (ServiceException e) {
			logger.error(e);
			error(e);
		}
	}
	
	public void enviaMensagemToolbarPorEquipe() {
		try {
			String loginUsuario = getUserInfo().getUserLogin();
			
			getMensagemToolbar().setUsuarioSSOEmitente(loginUsuario);
			
			if(equipeSelecionadoList != null && !equipeSelecionadoList.isEmpty()) {
				List<Atendente> listAtendentes = atendenteService.buscaPorEquipeList(equipeSelecionadoList);
				
				getMensagemToolbar().setAnalistasAtendentes(listAtendentes);
				
				if(getMensagemToolbar().getAnalistasAtendentes() != null && 
						!getMensagemToolbar().getAnalistasAtendentes().isEmpty()) {
					
					gboToolbarBusinessAppService.enviaMensagemToolbarAtendentes(getMensagemToolbar());
				}
			} else {
				throw new ServiceException("Nenhuma equipe selecionada.");
			}
			
			limpaMensagemToolbar();
			info("Mensagem enviada com sucesso.");
		} catch (ServiceException e) {
			logger.error(e);
			error(e);
		}
	}
	public void enviaMensagemToolbarPorAnalista() {
		try {
			String loginUsuario = getUserInfo().getUserLogin();
			
			getMensagemToolbar().setUsuarioSSOEmitente(loginUsuario);
			
			if(getMensagemToolbar().getAnalistasAtendentes() != null && 
					!getMensagemToolbar().getAnalistasAtendentes().isEmpty()) {
				
				gboToolbarBusinessAppService.enviaMensagemToolbarAtendentes(getMensagemToolbar());
			} else {
				throw new ServiceException("Nenhum analista selecionado.");
			}
			
			limpaMensagemToolbar();
			info("Mensagem enviada com sucesso.");
		} catch (Exception e) {
			logger.error(e);
			error(e);
		}
		
	}

    public void selecionaTodosFilas() {

        for (ConfiguracaoFila item : getConfiguracaoFilaList()) {
            if (selecionaTodosConfiguracaoFila == Boolean.TRUE) {
                item.setSelecionado(Boolean.TRUE);
            } else {
                item.setSelecionado(Boolean.FALSE);
            }
            marcaDesmarcaFila(item);
        }
    }

    public void marcaDesmarcaFila(ConfiguracaoFila configuracaoFila) {
        if (configuracaoFila != null && configuracaoFila.getSelecionado() != null) {

            if (getConfiguracaoFilaSelecionadoList() == null) {
                setConfiguracaoFilaSelecionadoList(new ArrayList<ConfiguracaoFila>());
            }
            if (configuracaoFila.getSelecionado()) {
                if (!getConfiguracaoFilaNomeSelecionadoList().contains(configuracaoFila.getNome())) {
                    getConfiguracaoFilaNomeSelecionadoList().add(configuracaoFila.getNome());
                    getConfiguracaoFilaSelecionadoList().add(configuracaoFila);
                }

            } else {
                if (getConfiguracaoFilaNomeSelecionadoList().contains(
                        configuracaoFila.getNome())) {
                    getConfiguracaoFilaNomeSelecionadoList().remove(configuracaoFila.getNome());
                    getConfiguracaoFilaSelecionadoList().remove(configuracaoFila);
                }

            }
            if (getAtendenteSelecionadoList() != null) {
                getAtendenteSelecionadoList().clear();
                getAtendenteNomeSelecionadoList().clear();
            }
        }
    }

    public String getFilasSelecionadas() {

        if (configuracaoFilaNomeSelecionadoList == null
                || configuracaoFilaNomeSelecionadoList.toString().equals(
                Constantes.LISTA_STRING_VAZIA)) {
            return "";
        }
        return configuracaoFilaNomeSelecionadoList.toString();
    }

    public void buscaFilas() {
        try {
            if (getEquipeSelecionadoList() != null && !equipeSelecionadoList.isEmpty()) {
                buscaFilaPorEquipe();
            } else {
                setConfiguracaoFilaList(configuracaoFilaService.findAll());
            }
        } catch (ServiceException ex) {
        	logger.error(ex);
            //Logger.getLogger(AbstractAcompanhamentoCasoBB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void buscaFilaPorEquipe() {
        try {
            if (getEquipeSelecionadoList() != null && !equipeSelecionadoList.isEmpty()) {

                List<EquipeFila> equipeFilaList = equipeFilaService.buscaPorEquipeList(equipeSelecionadoList);
                if (configuracaoFilaList == null) {
                    setConfiguracaoFilaList(new ArrayList<ConfiguracaoFila>());
                }
                getConfiguracaoFilaList().clear();

                for (ConfiguracaoFila configuracaoFila : getConfiguracaoFilaSelecionadoList()) {
                    ConfiguracaoFila filaARemover = null;
                    for (EquipeFila equipeFila : equipeFilaList) {
                        if (equipeFila.getConfiguracaoFila().equals(configuracaoFila)) {
                            filaARemover = equipeFila.getConfiguracaoFila();
                            break;
                        }
                    }
                    if (filaARemover != null) {
                    	
                        getConfiguracaoFilaSelecionadoList().remove(filaARemover);
                        getConfiguracaoFilaNomeSelecionadoList().remove(filaARemover.getNome());

                    }

                }

                for (EquipeFila equipeFila : equipeFilaList) {
                    ConfiguracaoFila cf = equipeFila.getConfiguracaoFila();
                    getConfiguracaoFilaList().add(cf);
                    if (configuracaoFilaSelecionadoList.contains(cf)) {
                        cf.setSelecionado(Boolean.TRUE);
                    }
                }
            }
        } catch (ServiceException e) {
        	logger.error(e);
            error(e);
        }
    }

    public void buscaAtendentes() {
        try {
            if (getConfiguracaoFilaSelecionadoList() != null && !getConfiguracaoFilaSelecionadoList().isEmpty()) {
                buscaAtendentePorFila();
            } else if (getEquipeSelecionadoList() != null && !getEquipeSelecionadoList().isEmpty()) {
                buscaAtendentePorEquipe();
            } else {
                setAtendenteList(atendenteService.findAtivos());
            }
        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }
    }

    public void buscaAtendentePorFila() {
        try {
            if (getAtendenteSelecionadoList() != null && !getAtendenteSelecionadoList().isEmpty()) {

                List<Atendente> atendentes = atendenteService.buscaPorConfiguracaoFilaList(getConfiguracaoFilaSelecionadoList());
                if (atendenteList == null) {
                    setAtendenteList(new ArrayList<Atendente>());
                }
                atendenteList.clear();

                if (atendentes != null && !atendentes.isEmpty()) {

                    setAtendenteList(atendentes);

                    for (Iterator<Atendente> it = atendenteSelecionadoList.iterator(); it.hasNext();) {
                        Atendente atendente = it.next();
                        if (!atendentes.contains(atendente)) {
                            it.remove();
                        }
                    }

                    for (Atendente atendente : atendentes) {
                        if (atendenteSelecionadoList.contains(atendente)) {
                            atendente.setSelecionado(Boolean.TRUE);
                        }
                    }
                }
            }
        } catch (ServiceException e) {
        	logger.error(e);
            error(e);
        }
    }

    public void buscaAtendentePorEquipe() {
        try {
            setAtendenteList(atendenteService.buscaPorEquipeList(equipeSelecionadoList));
        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }

    }

    public void selecionaTodosEquipe() {
        for (Equipe item : getEquipeList()) {
            if (selecionaTodosEquipe == Boolean.TRUE) {
                item.setSelecionado(Boolean.TRUE);
            } else {
                item.setSelecionado(Boolean.FALSE);
            }
            marcaDesmarcaEquipe(item);
        }
    }

    public void marcaDesmarcaEquipe(Equipe equipe) {
        if (equipe != null && equipe.getSelecionado() != null
                && equipe.getSelecionado() != null) {
            if (getEquipeNomeSelecionadoList() == null) {
                setEquipeNomeSelecionadoList(new ArrayList<String>());
            }
            if (getEquipeSelecionadoList() == null) {
                setEquipeSelecionadoList(new ArrayList<Equipe>());
            }
            if (equipe.getSelecionado()) {
                if (!getEquipeNomeSelecionadoList().contains(equipe.getNome())) {
                    getEquipeNomeSelecionadoList().add(equipe.getNome());
                    getEquipeSelecionadoList().add(equipe);
                }

            } else {
                if (getEquipeNomeSelecionadoList().contains(equipe.getNome())) {
                    getEquipeNomeSelecionadoList().remove(equipe.getNome());
                    getEquipeSelecionadoList().remove(equipe);
                }
            }
            if (getConfiguracaoFilaSelecionadoList() != null) {
                getConfiguracaoFilaSelecionadoList().clear();
                getConfiguracaoFilaNomeSelecionadoList().clear();
            }
            if (getAtendenteSelecionadoList() != null) {
                getAtendenteSelecionadoList().clear();
                getAtendenteNomeSelecionadoList().clear();
            }
        }
    }

    public String getEquipeSelecionados() {
        if (equipeNomeSelecionadoList == null
                || equipeNomeSelecionadoList.toString().equals(
                Constantes.LISTA_STRING_VAZIA)) {
            return "";
        }
        return equipeNomeSelecionadoList.toString();
    }

    public void limpaAtendentes() {
        setSelecionaTodosAtendente(Boolean.FALSE);
        selecionaTodosAtendentes();
    }

    public void selecionaTodosAtendentes() {
        for (Atendente item : getAtendenteList()) {
            if (selecionaTodosAtendente == Boolean.TRUE) {
                item.setSelecionado(Boolean.TRUE);
            } else {
                item.setSelecionado(Boolean.FALSE);
            }
            marcaDesmarcaAtendente(item);
        }
    }

    public void marcaDesmarcaAtendente(Atendente atendente) {
        if (atendente != null && atendente.getSelecionado() != null) {

            if (atendente.getSelecionado()) {
                if (!getAtendenteNomeSelecionadoList().contains(
                        atendente.getLogin())) {
                    getAtendenteNomeSelecionadoList().add(atendente.getLogin());
                    getAtendenteSelecionadoList().add(atendente);
                }
            } else {
                if (getAtendenteNomeSelecionadoList().contains(
                        atendente.getLogin())) {
                    getAtendenteNomeSelecionadoList().remove(
                            atendente.getLogin());
                    getAtendenteSelecionadoList().remove(atendente);
                }
            }
        }
    }

    public String getAtendentesSelecionados() {
        if (atendenteNomeSelecionadoList == null
                || atendenteNomeSelecionadoList.toString().equals(
                Constantes.LISTA_STRING_VAZIA)) {
            return "";
        }
        return atendenteNomeSelecionadoList.toString();
    }

    public final List<Atendente> getAtendenteList() {
        if (atendenteList == null) {
            try {
                atendenteList = atendenteService.findAll();
            } catch (ServiceException e) {
                error(e);
            }
        }
        return atendenteList;
    }
    
    private void geraGrafico() {
        Map<String, RelatorioDiv> mapGrafico = new HashMap<String, RelatorioDiv>();
        for (StatusAtendente statusAtendenteRel : statusAtendenteList) {
            if (mapGrafico.containsKey(statusAtendenteRel.getIdAtendenteStatus().getNomeStatus())) {
                RelatorioDiv relatorioDiv = mapGrafico.get(statusAtendenteRel.getIdAtendenteStatus().getNomeStatus());
                relatorioDiv.setIdStatus(statusAtendenteRel.getIdAtendenteStatus().getIdAtendenteStatus());
                
                if(getListIdStatusAtendentesSelecionados() != null &&
                		getListIdStatusAtendentesSelecionados().contains(statusAtendenteRel.getIdAtendenteStatus().getIdAtendenteStatus())) {
                	relatorioDiv.setSelecionado(Boolean.TRUE);
                }
                
                Integer valor = relatorioDiv.getValor();
                valor++;
                
                relatorioDiv.setValor(valor);
                mapGrafico.put(statusAtendenteRel.getIdAtendenteStatus().getNomeStatus(), relatorioDiv);
            } else {
                RelatorioDiv relatorioDiv = new RelatorioDiv();
                relatorioDiv.setIdStatus(statusAtendenteRel.getIdAtendenteStatus().getIdAtendenteStatus());
                relatorioDiv.setCor(statusAtendenteRel.getIdAtendenteStatus().getCorStatus());
                relatorioDiv.setValor(Integer.valueOf(1));
                relatorioDiv.setNomeStatus(statusAtendenteRel.getIdAtendenteStatus().getNomeStatus());
                
                if(getListIdStatusAtendentesSelecionados() != null &&
                		getListIdStatusAtendentesSelecionados().contains(statusAtendenteRel.getIdAtendenteStatus().getIdAtendenteStatus())) {
                	relatorioDiv.setSelecionado(Boolean.TRUE);
                }
                mapGrafico.put(statusAtendenteRel.getIdAtendenteStatus().getNomeStatus(), relatorioDiv);
            }
        }
        
        StringBuilder string = new StringBuilder();
        StringBuilder cores = new StringBuilder();
        Boolean proximo = false;
        totalAtendentes = 0;
        setRelatorioDivs(new ArrayList<RelatorioDiv>());
        for (Map.Entry<String, RelatorioDiv> candidatoEntry : mapGrafico.entrySet()) {
            if (proximo) {
                string.append(";");
            }

            string.append(candidatoEntry.getKey());
            string.append(",");
            string.append(candidatoEntry.getValue().getValor());
            
            if (proximo) {
                cores.append(";");
                cores.append(candidatoEntry.getValue().getCor());
            } else {
                cores.append(candidatoEntry.getValue().getCor());
            } 
            
            getRelatorioDivs().add(candidatoEntry.getValue());    
            totalAtendentes = totalAtendentes + candidatoEntry.getValue().getValor();
            
            proximo = true;
        }
        
        if (getRelatorioDivs() != null && !getRelatorioDivs().isEmpty()) {
            Collections.sort(getRelatorioDivs(), new Comparator<RelatorioDiv>() {  
                public int compare(RelatorioDiv o1, RelatorioDiv o2) {  
                    return o1.getValor().compareTo(o2.getValor());  
                }  
            }); 
        }
        
        valorDiv = string.toString();
        coresDivs = cores.toString();
    }
    
    public void filtraStatusAtendentesListForRelatorioDivs(RelatorioDiv relatorioDiv) {
    		
    	if(getListIdStatusAtendentesSelecionados() == null) {
    		setListIdStatusAtendentesSelecionados(new ArrayList<Integer>());
    	}
    	
    	if(relatorioDiv != null) {
    		if(relatorioDiv.isSelecionado()) {
    			getListIdStatusAtendentesSelecionados().add(relatorioDiv.getIdStatus());
    		} else {
    			if(getListIdStatusAtendentesSelecionados().contains(relatorioDiv.getIdStatus())) {
    				getListIdStatusAtendentesSelecionados().remove(relatorioDiv.getIdStatus());
    			}
    		}
    	}
    	
    	if(getListIdStatusAtendentesSelecionados() == null || getListIdStatusAtendentesSelecionados().isEmpty()) {
    		statusAtendenteListFilter = ControleStatusAtendentes.getFilterMapStatusAtendenteOrder(statusAtendenteList, getListIdStatusAtendentesSelecionados(), "LOGIN");
    	} else {
    		statusAtendenteListFilter = ControleStatusAtendentes.getFilterMapStatusAtendenteOrder(statusAtendenteList, getListIdStatusAtendentesSelecionados(), "TEMPO_STATUS");
    	}
    	
    }
    
    public void geraRelatorioStatusAtendente(Atendente atendente){
    	
    	try {
    		
    		Date dataAtual = new Date();
	    	//IStatusAtendenteService statusAtendenteService = (IStatusAtendenteService) BeanFactory.getInstance().getBean("statusAtendenteService");
	    	List<StatusAtendente> listStatusAtendentes = statusAtendenteService.buscaStatusAtendenteByAtendente(atendente, DateUtils.addFirstTimeInDate(dataAtual), DateUtils.addLastTimeInDate(dataAtual));
	    	relatorioStatusAtendente = ControleStatusAtendentes.getRelatorioStatusAtendente(atendente, listStatusAtendentes, dataAtual);
    	
    	} catch (Exception e) {
    		logger.error(e);
			error(e);
		}
    }

    public final void setAtendenteList(List<Atendente> atendenteList) {
        this.atendenteList = atendenteList;
    }

    public final List<ConfiguracaoFila> getConfiguracaoFilaSelecionadoList() {
        return configuracaoFilaSelecionadoList;
    }

    public final void setConfiguracaoFilaSelecionadoList(
            List<ConfiguracaoFila> configuracaoFilaSelecionadoList) {
        this.configuracaoFilaSelecionadoList = configuracaoFilaSelecionadoList;
    }

    public final List<Atendente> getAtendenteSelecionadoList() {
        return atendenteSelecionadoList;
    }

    public final void setAtendenteSelecionadoList(
            List<Atendente> atendenteSelecionadoList) {
        this.atendenteSelecionadoList = atendenteSelecionadoList;
    }

    public final List<String> getConfiguracaoFilaNomeSelecionadoList() {

        if (configuracaoFilaNomeSelecionadoList == null) {
            configuracaoFilaNomeSelecionadoList = new ArrayList<String>();
        }
        return configuracaoFilaNomeSelecionadoList;
    }

    public final void setConfiguracaoFilaNomeSelecionadoList(
            List<String> configuracaoFilaNomeSelecionadoList) {
        this.configuracaoFilaNomeSelecionadoList = configuracaoFilaNomeSelecionadoList;
    }

    public final boolean isSelecionaTodosConfiguracaoFila() {
        return selecionaTodosConfiguracaoFila;
    }

    public final void setSelecionaTodosConfiguracaoFila(
            boolean selecionaTodosConfiguracaoFila) {
        this.selecionaTodosConfiguracaoFila = selecionaTodosConfiguracaoFila;
    }

    public final List<String> getAtendenteNomeSelecionadoList() {
        if (atendenteNomeSelecionadoList == null) {
            atendenteNomeSelecionadoList = new ArrayList<String>();
        }
        return atendenteNomeSelecionadoList;
    }

    public final void setAtendenteNomeSelecionadoList(
            List<String> atendenteNomeSelecionadoList) {
        this.atendenteNomeSelecionadoList = atendenteNomeSelecionadoList;
    }

    public final ConfiguracaoFila getConfiguracaoFilaSelecionado() {
        return configuracaoFilaSelecionado;
    }

    public final boolean isSelecionaTodosAtendente() {
        return selecionaTodosAtendente;
    }

    public final void setSelecionaTodosAtendente(boolean selecionaTodosAtendente) {
        this.selecionaTodosAtendente = selecionaTodosAtendente;
    }

    public final List<String> getEquipeNomeSelecionadoList() {
        return equipeNomeSelecionadoList;
    }

    public final void setEquipeNomeSelecionadoList(List<String> equipeNomeSelecionadoList) {
        this.equipeNomeSelecionadoList = equipeNomeSelecionadoList;
    }

    public final List<Equipe> getEquipeSelecionadoList() {
        return equipeSelecionadoList;
    }

    public final void setEquipeSelecionadoList(List<Equipe> equipeSelecionadoList) {
        this.equipeSelecionadoList = equipeSelecionadoList;
    }

    public final boolean isSelecionaTodosEquipe() {
        return selecionaTodosEquipe;
    }

    public final void setSelecionaTodosEquipe(boolean selecionaTodosEquipe) {
        this.selecionaTodosEquipe = selecionaTodosEquipe;
    }

    public final List<Equipe> getEquipeList() {
        try {
            if (equipeList == null) {
                setEquipeList(equipeService.findAtivos());
            }
        } catch (ServiceException ex) {
            error(ex);
        }
        return equipeList;
    }

    public final void setEquipeList(List<Equipe> equipeList) {
        this.equipeList = equipeList;
    }

    public final List<ConfiguracaoFila> getConfiguracaoFilaList() {
        if (configuracaoFilaList == null) {
            try {
                this.configuracaoFilaList = configuracaoFilaService.findAll();
            } catch (ServiceException e) {
            	logger.error(e);
                error(e);
            }
        }
        return configuracaoFilaList;
    }

    public final void setConfiguracaoFilaList(
            List<ConfiguracaoFila> configuracaoFilaList) {
        this.configuracaoFilaList = configuracaoFilaList;
    }

    public List<StatusAtendente> getStatusAtendenteList() {
        return statusAtendenteList;
    }

    public void setStatusAtendenteList(List<StatusAtendente> statusAtendenteList) {
        this.statusAtendenteList = statusAtendenteList;
    }

	public List<StatusAtendente> getStatusAtendenteListFilter() {
		return statusAtendenteListFilter;
	}

	public void setStatusAtendenteListFilter(List<StatusAtendente> statusAtendenteListFilter) {
		this.statusAtendenteListFilter = statusAtendenteListFilter;
	}

	public String getValorDiv() {
        return valorDiv;
    }

    public void setValorDiv(String valorDiv) {
        this.valorDiv = valorDiv;
    }

    public String getCoresDivs() {
        return coresDivs;
    }

    public void setCoresDivs(String coresDivs) {
        this.coresDivs = coresDivs;
    }

    

    public List<RelatorioDiv> getRelatorioDivs() {
        return relatorioDivs;
    }

    public void setRelatorioDivs(List<RelatorioDiv> relatorioDivs) {
        this.relatorioDivs = relatorioDivs;
    }

    public List<Integer> getListIdStatusAtendentesSelecionados() {
		return listIdStatusAtendentesSelecionados;
	}

	public void setListIdStatusAtendentesSelecionados(List<Integer> listIdStatusAtendentesSelecionados) {
		this.listIdStatusAtendentesSelecionados = listIdStatusAtendentesSelecionados;
	}

	public Integer getTotalAtendentes() {
        return totalAtendentes;
    }

    public void setTotalAtendentes(Integer totalAtendentes) {
        this.totalAtendentes = totalAtendentes;
    }

	public List<MetaFilaTO> getListMetaFilaTo() {
		return listMetaFilaTo;
	}

	public void setListMetaFilaTo(List<MetaFilaTO> listMetaFilaTo) {
		this.listMetaFilaTo = listMetaFilaTo;
	}

	public MensagemToolbar getMensagemToolbar() {
		return mensagemToolbar;
	}

	public void setMensagemToolbar(MensagemToolbar mensagemToolbar) {
		this.mensagemToolbar = mensagemToolbar;
	}

	/**
	 * @return the flagIniciaBAppToolbar
	 */
	public boolean isFlagIniciaBAppToolbar() {
		return flagIniciaBAppToolbar;
	}

	/**
	 * @param flagIniciaBAppToolbar the flagIniciaBAppToolbar to set
	 */
	public void setFlagIniciaBAppToolbar(boolean flagIniciaBAppToolbar) {
		this.flagIniciaBAppToolbar = flagIniciaBAppToolbar;
	}

	public RelatorioStatusAtendente getRelatorioStatusAtendente() {
		return relatorioStatusAtendente;
	}

	public void setRelatorioStatusAtendente(RelatorioStatusAtendente relatorioStatusAtendente) {
		this.relatorioStatusAtendente = relatorioStatusAtendente;
	}
	
	@Override
	protected IStatusAtendenteService getService() {
		return statusAtendenteService;
	}

	@Override
	public void novo() {
		setPojo(new StatusAtendente());
	}
	
}
