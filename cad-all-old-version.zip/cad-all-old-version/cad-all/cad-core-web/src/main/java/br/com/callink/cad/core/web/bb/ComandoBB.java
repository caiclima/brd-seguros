package br.com.callink.gbo.core.web.bb;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import br.com.callink.gbo.pojo.Comando;
import br.com.callink.gbo.pojo.ParametroComando;
import br.com.callink.gbo.pojo.Status;
import br.com.callink.gbo.service.IComandoService;
import br.com.callink.gbo.service.IParametroComandoService;
import br.com.callink.gbo.service.IStatusService;
import br.com.callink.gbo.service.exception.ServiceException;
import br.com.callink.gbo.service.exception.ValidationException;

/**
 * 
 * @author brunomt [brunoam@swb.com.br]
 * 
 */
@ManagedBean
@ViewScoped
public final class ComandoBB extends GboGenericCrud<Comando, IComandoService> {

    private static final long serialVersionUID = 1L;
    private List<Status> listaStatus;
    private String renderNovoEdit;
    private List<ParametroComando> listParametroComando;
    private ParametroComando parametroComando;
    
    @EJB
    private IParametroComandoService parametroComandoService;
    @EJB
    private IComandoService comandoService;
    @EJB
    private IStatusService statusService;

    @PostConstruct
    public void init() {
    	novo();
        novoParametroComando();
    }

    @Override
    public String salvar() {
        getPojo().setLoginUsuario(getLoginUsuario());
        String ret = super.salvar();
        if (getPojo().getIdComando() != null) {
            novo();
            //filtrar("nome");
            try {
				setPojos(getService().findByExample(getPojo(), "Comando.NOME"));
			} catch (ServiceException e) {
				logger.error(e);
				error(e);
			}
        }
        return ret;
    }

    public String excluir(Comando comando) {
        try {
            getService().delete(comando);
            filtrar();

        } catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException ex) {
			logger.error(ex);
            error(ex);
        }
        return null;
    }

    @Override
    public String filtrar() {
        try {

            Comando comando = getPojo();
            
            boolean statusNull = comando.getStatus() == null || comando.getStatus().getIdStatus() == null;

            if (statusNull) {
                comando.setStatus(null);
            }
            
            setPojos(comandoService.findByExample(getPojo(), "Comando.NOME"));
            
            if (statusNull) {
                comando.setStatus(new Status());
            }
            
        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }
        return null;
    }

    public void alterar(Comando comando) {
        setPojo(comando);
    }

    @Override
    public void novo() {
        setPojo(new Comando());

        try {
            setPojos(getService().findByExample(getPojo(), "Comando.NOME"));
        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }
        
        getPojo().setStatus(new Status());
        getPojo().setFlagAtivo(Boolean.TRUE);
        renderNovoEdit = "panelSelecionaStatus";
    }

    public void filtrarStatus() {
        try {
            if (getPojo().getIdComando() == null) {
                renderNovoEdit = "panelSelecionaStatus";
            } else {
                renderNovoEdit = "modalEditarComandoPanel";
            }

            Status status = getPojo().getStatus();
            listaStatus = statusService.findByExample(status, "Status.NOME");

        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }
    }

    public void salvarParametroComando() {
        try {
            parametroComando.setLoginUsuario(getLoginUsuario());
            parametroComandoService.saveOrUpdate(parametroComando);
            if (parametroComando.getIdParametroComando() != null) {
                novoParametroComando();
                buscaParametros(getPojo());
            }
        } catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException ex) {
			logger.error(ex);
            error(ex);
        }
    }

    public void excluirParametroComando(ParametroComando parametroComando) {
        try {

            parametroComandoService.delete(parametroComando);
            if (parametroComando.getIdParametroComando() != null) {
                novoParametroComando();
                buscaParametros(getPojo());
            }
        } catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException ex) {
			logger.error(ex);
            error(ex);
        }
    }

    public void novoParametroComando() {
        parametroComando = new ParametroComando();
    }

    public void buscaParametros(Comando comando) {
        try {
            parametroComando.setComando(comando);
            setPojo(comando);
            setListParametroComando(parametroComandoService.buscaPorComando(getPojo()));
        } catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException e) {
			logger.error(e);
            error(e);
        }
    }

    public void limpaListaStatus() {
        listaStatus = new ArrayList<Status>();
    }

    public void limpaStatus() {
        setStatus(new Status());
    }

    public void setStatus(Status status) {
        this.getPojo().setStatus(status);
        limpaListaStatus();
    }

    public List<Status> getListaStatus() {
        return listaStatus;
    }

    public void setListaStatus(List<Status> listaStatus) {
        this.listaStatus = listaStatus;
    }

    public String getRenderNovoEdit() {
        return renderNovoEdit;
    }

    public void setRenderNovoEdit(String renderNovoEdit) {
        this.renderNovoEdit = renderNovoEdit;
    }

    public List<ParametroComando> getListParametroComando() {
        return listParametroComando;
    }

    public void setListParametroComando(List<ParametroComando> listParametroComando) {
        this.listParametroComando = listParametroComando;
    }

    public ParametroComando getParametroComando() {
        return parametroComando;
    }

    public void setParametroComando(ParametroComando parametroComando) {
        this.parametroComando = parametroComando;
    }
    
    @Override
	protected IComandoService getService() {
		return comandoService;
	}
}
