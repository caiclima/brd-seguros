package br.com.callink.gbo.core.web.bb;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.apache.commons.collections.CollectionUtils;

import br.com.callink.gbo.pojo.Caso;
import br.com.callink.gbo.pojo.ConfiguracaoFila;
import br.com.callink.gbo.service.ICasoService;
import br.com.callink.gbo.service.IConfiguracaoFilaService;
import br.com.callink.gbo.service.exception.ServiceException;
import br.com.callink.gbo.service.exception.ValidationException;

/**
 * 
 * @author brunomt [brunoam@swb.com.br]
 * 
 */
@ManagedBean
@ViewScoped
public class ConfiguracaoFilaBB extends GboGenericCrud<ConfiguracaoFila, IConfiguracaoFilaService> {
	private static final long serialVersionUID = 1L;

	private ConfiguracaoFila configuracaoFilaFind;
	
	@EJB
	private IConfiguracaoFilaService configuracaoFilaService;
	@EJB
	private ICasoService casoService;
	
	private Boolean ativaPrioridade;

	@PostConstruct
    public void init() {
		setPojo(new ConfiguracaoFila());
		limparTela();
	}

	public void novaTela() {
		novo();
	}

	public void limparTela() {
		configuracaoFilaFind = new ConfiguracaoFila();
		configuracaoFilaFind.setFlagAtivo(Boolean.TRUE);
		pesquisar();
		ativaPrioridade = false;
	}

	public void pesquisar() {
		ativaPrioridade = false;
		try {
			setPojos(configuracaoFilaService.findByExample(configuracaoFilaFind, "ConfiguracaoFila.NOME"));
		} catch (ServiceException e) {
			logger.error(e);
			error(e);
		}
	}

	public void retornaFilasAtivasPrioridade() throws ServiceException {
		ativaPrioridade = true;
		setPojos(configuracaoFilaService.buscaFilaAtivaPorPrioridade());
	}

	@Override
	public String salvar() {
		getPojo().setLoginUsuario(getLoginUsuario());
		String ret = super.salvar();
		if (getPojo().getIdConfiguracaoFila() != null) {
			novo();
			pesquisar();
		}
		return ret;
	}

	public String testeFiltrosFila() {
		try {
			List<Caso> casoList = casoService
					.buscaCasosFiltroPorFilaSemAtendente(getPojo());
			validaCasoList(casoList);
		} catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException e) {
			logger.error(e);
			error(e);
		}
		return null;
	}

	/**
	 * @param casoList
	 */
	private void validaCasoList(List<Caso> casoList) {
		if (CollectionUtils.isEmpty(casoList)) {
			info("Query executada com sucesso, por\u00E9m n\u00E3o foi retornado nenhum caso.");
		} else {
			info("Query executada com sucesso. Foram retornados "
					+ casoList.size() + " casos.");
		}
	}

	public void testeOrderFila() {
		try {
			List<Caso> casoList = casoService
					.buscaCasosOrdernadosPorFilaSemAtendente(getPojo(), 1);
			validaCasoList(casoList);
		} catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException e) {
			logger.error(e);
			error(e);
		}
	}

	public void diminuirPrioridade(ConfiguracaoFila configuracaoFila) {
		try {
			configuracaoFilaService.diminuirPrioridade(configuracaoFila, getLoginUsuario());
			retornaFilasAtivasPrioridade();
		} catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException e) {
			logger.error(e);
			error(e);
		}
	}

	public void aumentarPrioridade(ConfiguracaoFila configuracaoFila) {
		try {
			configuracaoFilaService.aumentarPrioridade(configuracaoFila, getLoginUsuario());
			retornaFilasAtivasPrioridade();
		} catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException e) {
			logger.error(e);
			error(e);
		}
	}

	public void alterar(ConfiguracaoFila configuracaoFila) {
		setPojo(configuracaoFila);
	}

	public String excluir(ConfiguracaoFila configuracaoFila) {
		try {
			configuracaoFilaService.inativar(configuracaoFila, getLoginUsuario());
		} catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException e) {
			logger.error(e);
			error(e);
		}
		return null;
	}

	public void setConfiguracaoFilaFind(ConfiguracaoFila configuracaoFilaFind) {
		this.configuracaoFilaFind = configuracaoFilaFind;
	}

	public ConfiguracaoFila getConfiguracaoFilaFind() {
		return configuracaoFilaFind;
	}

	public void setAtivaPrioridade(Boolean ativaPrioridade) {
		this.ativaPrioridade = ativaPrioridade;
	}

	public Boolean getAtivaPrioridade() {
		return ativaPrioridade;
	}

	@Override
	public void novo() {
		setPojo(new ConfiguracaoFila());
	}

	@Override
	protected IConfiguracaoFilaService getService() {
		return configuracaoFilaService;
	}

}
