/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.gbo.core.web.bb;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.apache.commons.lang.StringUtils;

import br.com.callink.gbo.pojo.EnderecoEmail;
import br.com.callink.gbo.service.IEnderecoEmailService;
import br.com.callink.gbo.service.exception.ServiceException;
import br.com.callink.gbo.service.exception.ValidationException;

/**
 *
 * @author Luiz Gustavo (luizgf@swb.com.br)
 */
@ManagedBean
@ViewScoped
public class EnderecoEmailBB extends GboGenericCrud<EnderecoEmail, IEnderecoEmailService> {
    
	private static final long serialVersionUID = 1L;
	
	@EJB
	private IEnderecoEmailService enderecoEmailService;
	
	@PostConstruct
    public void init() {
		try {
			setPojo(new EnderecoEmail());
			setPojos(getService().findAtivos("EnderecoEmail.DESCRICAO"));
            getPojo().setFlagAtivo(Boolean.TRUE);
		} catch (ServiceException ex) {
			logger.error(ex);
			error(ex);
		}
	}
	
	@Override
	public void novo() {
        setPojo(new EnderecoEmail());
		getPojo().setFlagAtivo(Boolean.TRUE);
	}

	@Override
	public String salvar() {
		try {
			validaCampos();
			super.salvar();
			novo();
			findAll();
		} catch (ServiceException ex) {
			logger.error(ex);
			error(ex);
		}
		return null;
	}
        
    private void validaCampos() throws ServiceException {
        if (StringUtils.isBlank(getPojo().getDescricao())) {
            throw new ServiceException("A descrição não pode ser vazia.");
        }
        if (StringUtils.isBlank(getPojo().getEnderecoEmail())) {
            throw new ServiceException("O endereço não pode ser vazio.");
        }
    }

	public void alteraValorPojo(EnderecoEmail enderecoEmail) {
		super.setPojo(enderecoEmail);
	}

	public String excluir(EnderecoEmail enderecoEmail) {
		try {
			getService().delete(enderecoEmail);
			filtrar();

		}catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException ex) {
			logger.error(ex);
			error("Não foi possivel excluir este endereço de email. Verifique se ele está associado a algum departamento antes de excluir.");
		}
		return null;
	}
	
	public void findAll() {
		try {
			setPojos(getService().findByExample(getPojo(), "EnderecoEmail.DESCRICAO"));
		} catch (ServiceException e) {
			logger.error(e);
			error(e);
		}
	}
	
	@Override
	protected IEnderecoEmailService getService() {
		return enderecoEmailService;
	}
}
