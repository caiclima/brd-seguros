package br.com.callink.gbo.core.web.bb;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;

import br.com.callink.gbo.core.web.bb.util.JSFUtil;
import br.com.callink.gbo.pojo.Atendente;
import br.com.callink.gbo.pojo.ConfiguracaoFila;
import br.com.callink.gbo.pojo.Equipe;
import br.com.callink.gbo.pojo.EquipeFila;
import br.com.callink.gbo.pojo.Perfil;
import br.com.callink.gbo.service.IAtendenteService;
import br.com.callink.gbo.service.IConfiguracaoFilaService;
import br.com.callink.gbo.service.IEquipeFilaService;
import br.com.callink.gbo.service.IEquipeService;
import br.com.callink.gbo.service.IPerfilService;
import br.com.callink.gbo.service.exception.ServiceException;
import br.com.callink.gbo.service.exception.ValidationException;

/**
 * 
 * @author Ednaldo Caic [ednaldo@swb.com.br]
 * 
 */
@ManagedBean
@ViewScoped
public class EquipeAssociacoesBB extends GboGenericCrud<Equipe, IEquipeService> {
	private static final long serialVersionUID = 1L;

	private Equipe equipe;

	private Atendente atendente;

	private List<Atendente> atendenteList;
	private List<EquipeFila> equipeFilaList;

	private List<Atendente> atendenteSemEquipeList;
	private List<EquipeFila> equipeFilaPodeAddList;

	private List<Perfil> perfilList;
	private List<Equipe> equipeList;
	
	@EJB
	private IEquipeService equipeService;
	@EJB
	private IAtendenteService atendenteService;
	@EJB
	private IEquipeFilaService equipeFilaService;
	@EJB
	private IConfiguracaoFilaService configuracaoFilaService;
	@EJB
	private IPerfilService perfilService;

	@PostConstruct
    public void init() {
		equipe = (Equipe) FacesContext.getCurrentInstance()
				.getExternalContext().getSessionMap().get("equipe");
		novoAtendente();

		filtrar();
	}

	@Override
	public String filtrar() {

		if (equipe != null) {

			Atendente atendenteParam = new Atendente();
			atendenteParam.setEquipe(equipe);
			try {
				setAtendenteList(atendenteService.findByExampleAll(
						atendenteParam));

				setEquipeFilaList(equipeFilaService
						.buscaEquipeFilaListByEquipeEConfiguracaoFilaTudo(
								equipe, null));

			} catch (ServiceException e) {
				logger.error(e);
				error("Erro ao buscar atendentes e filas da equipe selecionada!");
			}
		}

		return "";
	}
	
	@Override
	public void novo() {
		setPojo(new Equipe());
	}

	@Override
	public String salvar() {
		setPojo(equipe);
		return  super.salvar();
	}

	public void alterar(Equipe equipe) {
		setPojo(equipe);
	}

	public String excluir(Equipe equipe) {
		try {
			getService().inativar(equipe);
		} catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException e) {
			logger.error(e);
			error(e);
		}
		return null;
	}

	public void buscaAtendentesSemEquipe() {
		try {
			setAtendenteSemEquipeList(atendenteService
					.buscaAtivosQueNaoPossuemFila());
			if (getAtendenteSemEquipeList() == null
					|| getAtendenteSemEquipeList().isEmpty()) {
				setAtendenteSemEquipeList(new ArrayList<Atendente>());
			}
		} catch (ServiceException e) {
			logger.error(e);
			error(e);
		}
	}

	public void associarAtendente() {
		for (Atendente atendenteItem : atendenteSemEquipeList) {
			if (atendenteItem.getSelecionado()) {
				atendenteItem.setEquipe(getEquipe());
				saveAtendente(atendenteItem);
			}
		}
		filtrar();
	}

	public void desassociarAtendente(Atendente atendente) {
		atendente.setEquipe(null);
		saveAtendente(atendente);
		filtrar();
	}

	public void cadastrarAtendente() {
		saveAtendente(atendente);
		filtrar();
	}
	
	public void novoAtendente(){
		setAtendente(new Atendente());
		getAtendente().setFlagAtivo(Boolean.TRUE);
	}

	public void saveAtendente(Atendente atendente) {
		try {
			if (atendente != null) {
				if (atendente.getPK() != null) {
					atendenteService.update(atendente);
				} else {
					atendenteService.save(atendente);
				}
			}
		} catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException e) {
			logger.error(e);
			error("Erro ao salvar/atualizar Atendente. " + e.getMessage());
		}
	}
	
	public String voltarEquipe() {
		return "/pages/cadastro/equipe.xhtml?faces-redirect=true";
	}

	public void buscaConfiguracaoFilaPodeSerAssociado() {
		try {

			setEquipeFilaPodeAddList(new ArrayList<EquipeFila>());

			List<ConfiguracaoFila> configuracaoFilaList = configuracaoFilaService
					.buscaQueAindaNaoForamAdicionadosByEquipe(equipe);

			if (configuracaoFilaList != null && !configuracaoFilaList.isEmpty()) {

				for (ConfiguracaoFila configuracaoFila : configuracaoFilaList) {
					EquipeFila equipeFila = new EquipeFila();
					equipeFila.setConfiguracaoFila(configuracaoFila);
					getEquipeFilaPodeAddList().add(equipeFila);
				}
			}
		} catch (ServiceException e) {
			logger.error(e);
			error(e);
		}
	}

	public void associaFilaEquipe() {

		try {
			for (EquipeFila equipeFila : equipeFilaPodeAddList) {
				if (equipeFila.getConfiguracaoFila().getSelecionado()) {
					equipeFila.setEquipe(getEquipe());
					equipeFila.setConfiguracaoFila(equipeFila
							.getConfiguracaoFila());
					equipeFilaService.save(equipeFila);
				}
			}
			filtrar();
		} catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException e) {
			logger.error(e);
			error(e.getMessage());
		}
	}

	public void desassociaFilaEquipe(EquipeFila equipeFila) {
		try {
			equipeFilaService.delete(equipeFila);
			filtrar();
		} catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException e) {
			logger.error(e);
			error("Erro ao desassociar Equipe/Fila");
		}
	}

	public final List<Atendente> getAtendenteList() {
		return atendenteList;
	}

	public final void setAtendenteList(List<Atendente> atendenteList) {
		this.atendenteList = atendenteList;
	}

	public final Equipe getEquipe() {
		return equipe;
	}

	public final void setEquipe(Equipe equipe) {
		this.equipe = equipe;
	}

	public final List<Atendente> getAtendenteSemEquipeList() {
		return atendenteSemEquipeList;
	}

	public final void setAtendenteSemEquipeList(
			List<Atendente> atendenteSemEquipeList) {
		this.atendenteSemEquipeList = atendenteSemEquipeList;
	}

	public final List<EquipeFila> getEquipeFilaList() {
		return equipeFilaList;
	}

	public final void setEquipeFilaList(List<EquipeFila> equipeFilaList) {
		this.equipeFilaList = equipeFilaList;
	}

	public final List<EquipeFila> getEquipeFilaPodeAddList() {
		return equipeFilaPodeAddList;
	}

	public final void setEquipeFilaPodeAddList(
			List<EquipeFila> equipeFilaPodeAddList) {
		this.equipeFilaPodeAddList = equipeFilaPodeAddList;
	}

	public final Atendente getAtendente() {
		return atendente;
	}

	public final void setAtendente(Atendente atendente) {
		this.atendente = atendente;
	}

	public final List<SelectItem> getPerfilList() {

		try {
			if (perfilList == null || perfilList.isEmpty()) {
				perfilList = perfilService.findAtivos();
			}
		} catch (ServiceException e) {
			logger.error(e);
			error("Erro ao buscar Lista de Perfis.");
		}
		return JSFUtil.toSelectItemConsulta(perfilList);
	}

	public final void setPerfilList(List<Perfil> perfilList) {
		this.perfilList = perfilList;
	}

	public final List<SelectItem> getEquipeList() {
		try {
			if (equipeList == null || equipeList.isEmpty()) {
				equipeList = getService().findAtivos();
			}
		} catch (ServiceException e) {
			logger.error(e);
			error("Erro ao buscar Lista de Equipes.");
		}
		return JSFUtil.toSelectItemConsulta(equipeList);	}

	public final void setEquipeList(List<Equipe> equipeList) {
		this.equipeList = equipeList;
	}
	
	@Override
	protected IEquipeService getService() {
		return equipeService;
	}

}
