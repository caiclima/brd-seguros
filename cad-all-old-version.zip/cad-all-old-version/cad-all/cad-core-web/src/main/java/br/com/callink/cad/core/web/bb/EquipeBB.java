package br.com.callink.gbo.core.web.bb;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import br.com.callink.gbo.pojo.Atendente;
import br.com.callink.gbo.pojo.ConfiguracaoFila;
import br.com.callink.gbo.pojo.Equipe;
import br.com.callink.gbo.service.IEquipeService;
import br.com.callink.gbo.service.exception.ServiceException;
import br.com.callink.gbo.service.exception.ValidationException;

/**
 * 
 * @author brunomt [brunoam@swb.com.br]
 * 
 */
@ManagedBean
@ViewScoped
public class EquipeBB extends GboGenericCrud<Equipe, IEquipeService> {

    private static final long serialVersionUID = 1L;
    private List<Atendente> atendenteList;
    private List<ConfiguracaoFila> configuracaoFilaList;
    
    @EJB
    private IEquipeService equipeService;

    @PostConstruct
    public void init() {
		try {
			setPojo(new Equipe());
			setPojos(getService().findByExample(getPojo(), "Equipe.NOME"));
            getPojo().setFlagAtivo(Boolean.TRUE);
		} catch (Exception ex) {
			logger.error(ex);
            error(ex);
        }
    }

    @Override
    public String salvar() {
        String ret = super.salvar();
        if (getPojo().getIdEquipe() != null) {
            novo();
            filtrar();
        }
        return ret;
    }

    @Override
    public String filtrar() {
        try {
            setPojos(getService().findByExample(getPojo(), "Equipe.NOME"));
        } catch (ServiceException e) {
        	logger.error(e);
            error(e);
        }
        return null;
    }

    @Override
    public void novo() {
        setPojo(new Equipe());
        try {
            setPojos(getService().findAll());
            getPojo().setFlagAtivo(Boolean.TRUE);            
        } catch (ServiceException e) {
        	logger.error(e);
            error(e);
        }
    }

    public void alterar(Equipe equipe) {
        setPojo(equipe);
    }

    public String excluir(Equipe equipe) {
        try {
            try {
				getService().inativar(equipe);
			} catch (ValidationException e) {
				error(e.getMessage());
			}
        } catch (ServiceException e) {
        	logger.error(e);
            error(e);
        }
        return null;
    }

    public String selecionaEquipe(Equipe equipe) {
        FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("equipe", equipe);
        return "/faces/cadastros/equipe_associacoes.xhtml?faces-redirect=true";
    }

    public void associarAtendente(Atendente atendente) {
    }

    public void desassociarAtendente(Atendente atendente) {
    }

    public final List<Atendente> getAtendenteList() {
        return atendenteList;
    }

    public final void setAtendenteList(List<Atendente> atendenteList) {
        this.atendenteList = atendenteList;
    }

    public final List<ConfiguracaoFila> getConfiguracaoFilaList() {
        return configuracaoFilaList;
    }

    public final void setConfiguracaoFilaList(
            List<ConfiguracaoFila> configuracaoFilaList) {
        this.configuracaoFilaList = configuracaoFilaList;
    }
    
    @Override
	protected IEquipeService getService() {
		return equipeService;
	}
}
