/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.gbo.core.web.bb;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import br.com.callink.gbo.pojo.ConfiguracaoFila;
import br.com.callink.gbo.pojo.Equipe;
import br.com.callink.gbo.pojo.EquipeFila;
import br.com.callink.gbo.service.IConfiguracaoFilaService;
import br.com.callink.gbo.service.IEquipeFilaService;
import br.com.callink.gbo.service.IEquipeService;
import br.com.callink.gbo.service.exception.ServiceException;
import br.com.callink.gbo.service.exception.ValidationException;

/**
 *
 * @author Ednaldo Caic [ednaldo@swb.com.br]
 * @since 18/01/2012
 */
@ManagedBean
@ViewScoped
public class EquipeFilaBB extends GboGenericCrud<EquipeFila, IEquipeFilaService> {

	private static final long serialVersionUID = 3920851711954262785L;
	
    private EquipeFila equipeFila;
    private List<EquipeFila> equipeFilaList;
    private List<Equipe> equipeList;
    private List<ConfiguracaoFila> configuracaoFilaList;
    
    @EJB
    private IEquipeFilaService equipeFilaService;
    @EJB
    private IEquipeService equipeService;
    @EJB
    private IConfiguracaoFilaService configuracaoFilaService;

    @PostConstruct
    public void init() {
    	novo();
    }

    @Override
    public String salvar() {
        try {
            getService().save(equipeFila);
            filtrar();
        } catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException ex) {
			logger.error(ex);
            error(ex);
        }
        return "";
    }

    public String excluir(EquipeFila equipeFila) {
        try {
            getService().delete(equipeFila);
            filtrar();
        } catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException ex) {
			logger.error(ex);
            error(ex);
        }
        return null;
    }

    public void filtrarEquipes() {
        try {
        	Equipe equipe = equipeFila.getEquipe();
            equipeList = equipeService.findByExample(equipe);

        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }
    }

    public void filtrarFilas() {
        try {
        	ConfiguracaoFila configuracaoFila = equipeFila.getConfiguracaoFila();
            configuracaoFilaList = configuracaoFilaService.findByExample(configuracaoFila);

        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }
    }

    @Override
    public void novo() {
        equipeFila = new EquipeFila(new Equipe(), new ConfiguracaoFila());
    }

    @Override
    public String filtrar() {
        try {
        	
        	Equipe equipe = equipeFila.getEquipe();
        	ConfiguracaoFila configuracaoFila = equipeFila.getConfiguracaoFila();

        	equipeFilaList = (List<EquipeFila>) getService().buscaEquipeFilaListByEquipeEConfiguracaoFilaTudo(equipe, configuracaoFila);
        	
        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }
        return null;

    }

	public final EquipeFila getEquipeFila() {
		return equipeFila;
	}

	public final void setEquipeFila(EquipeFila equipeFila) {
		this.equipeFila = equipeFila;
	}

	public final List<EquipeFila> getEquipeFilaList() {
		return equipeFilaList;
	}

	public final void setEquipeFilaList(List<EquipeFila> equipeFilaList) {
		this.equipeFilaList = equipeFilaList;
	}

	public final List<Equipe> getEquipeList() {
		return equipeList;
	}

	public final void setEquipeList(List<Equipe> equipeList) {
		this.equipeList = equipeList;
	}

	public final List<ConfiguracaoFila> getConfiguracaoFilaList() {
		return configuracaoFilaList;
	}

	public final void setConfiguracaoFilaList(
			List<ConfiguracaoFila> configuracaoFilaList) {
		this.configuracaoFilaList = configuracaoFilaList;
	}
	
	public final void setEquipe(Equipe equipe){
		equipeFila.setEquipe(equipe);
	}
	public final void setConfiguracaoFila(ConfiguracaoFila configuracaoFila){
		equipeFila.setConfiguracaoFila(configuracaoFila);
	}
	
	@Override
	protected IEquipeFilaService getService() {
		return equipeFilaService;
	}

}
