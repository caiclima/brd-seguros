/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.gbo.core.web.bb;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import br.com.callink.gbo.pojo.Feriado;
import br.com.callink.gbo.service.IFeriadoService;
import br.com.callink.gbo.service.exception.ServiceException;
import br.com.callink.gbo.service.exception.ValidationException;

/**
 *
 * @author Rogério Moreira de Andrade. [rogeriom@swb.com.br]
 */
@ManagedBean
@ViewScoped
public class FeriadoBB extends GboGenericCrud<Feriado, IFeriadoService> {

    private static final long serialVersionUID = 1L;
    
    @EJB
    private IFeriadoService feriadoService;

    
    @PostConstruct
    public void init() {
		novo();
    }

    @Override
    public String filtrar() {
        try {
            setPojos(getService().findByExample(getPojo()));
        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }
        return null;
    }

    @Override
    public void novo() {
        setPojo(new Feriado());
        try {
            setPojos(getService().findAll());
        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }
    }

    @Override
    public String salvar() {
        getPojo().setLoginUsuario(getLoginUsuario());
        String ret = super.salvar();
        if (getPojo().getIdFeriado() != null) {
            novo();
            filtrar();
        }
        return ret;
    }

    public String excluir(Feriado feriado) {
        try {
            getService().delete(feriado);
            filtrar();

        } catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException ex) {
			logger.error(ex);
            error(ex);
        }
        return null;
    }
    
    @Override
	protected IFeriadoService getService() {
		return feriadoService;
	}
}
