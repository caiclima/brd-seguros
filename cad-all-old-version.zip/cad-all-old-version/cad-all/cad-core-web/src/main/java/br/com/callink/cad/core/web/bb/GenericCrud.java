/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.gbo.core.web.bb;

import java.io.Serializable;
import java.util.Locale;
import java.util.Map;

import javax.faces.FactoryFinder;
import javax.faces.application.Application;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.lifecycle.Lifecycle;
import javax.faces.lifecycle.LifecycleFactory;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

import br.com.callink.gbo.service.exception.ValidationException;

/**
 *
 * @author ubuntu
 */
public abstract class GenericCrud implements Serializable {

    private static final long serialVersionUID = -88305665617606L;
    protected Logger logger = Logger.getLogger(getClass());
    private Boolean showGlobalMessage;
	private Object[] responseObj;
	
	public Boolean getShowGlobalMessage() {
		return showGlobalMessage;
	}

	public void setShowGlobalMessage(Boolean showGlobalMessage) {
		this.showGlobalMessage = showGlobalMessage;
	}

	public Object[] getResponseObj() {
		return responseObj;
	}

	public void setResponseObj(Object[] responseObj) {
		this.responseObj = responseObj;
	}
	
    protected Application getApplication() {
        return FacesContext.getCurrentInstance().getApplication();
    }

    protected ExternalContext getExternalContext() {
        return FacesContext.getCurrentInstance().getExternalContext();
    }

    protected FacesContext getFacesContext() {
        return FacesContext.getCurrentInstance();
    }

    protected Map getApplicationMap() {
        return getExternalContext().getApplicationMap();
    }

    protected Map getRequestMap() {
        return getExternalContext().getRequestMap();
    }

    protected Map getSessionMap() {
        return getExternalContext().getSessionMap();
    }

    protected String getUsuarioLogado() {
        return (String) getSessionMap().get("userLogin");
    }

    protected String getUsuarioHost() {
        return (String) getSessionMap().get("userHost");
    }

    protected Locale getLocale() {
		return getFacesContext().getViewRoot().getLocale();
	}

	/*protected void setLocale(Locale locale) {
		getFacesContext().getViewRoot().setLocale(locale);
		getSessionBean().setLocale(locale);
	}

	public RequestBean getRequestBean() {
		return (RequestBean) getBean("RequestBean");
	}

	public SessionBean getSessionBean() {
		return (SessionBean) getBean("SessionBean");
	}

	public ApplicationBean getApplicationBean() {
		return (ApplicationBean) getBean("ApplicationBean");
	}*/
    
	public Object getBean(String name) {
	    FacesContext facesContext = getFacesContext();
	    return facesContext.getApplication().getELResolver().getValue(facesContext.getELContext(), null, name);
	}
	
    protected Lifecycle getLifecycle() {
        String lifecycleId = getExternalContext().getInitParameter("javax.faces.LIFECYCLE_ID");

        if (lifecycleId == null || lifecycleId.length() == 0) {
            lifecycleId = LifecycleFactory.DEFAULT_LIFECYCLE;
        }
        LifecycleFactory lifecycleFactory = (LifecycleFactory) FactoryFinder.getFactory(FactoryFinder.LIFECYCLE_FACTORY);
        return lifecycleFactory.getLifecycle(lifecycleId);
    }
    
    protected void log(String message) {
        FacesContext context = FacesContext.getCurrentInstance();
        if (context != null) {
            getExternalContext().log(message);
        } else {
            logger.info(message);
        }
    }

    protected void log(String message, Throwable throwable) {
        FacesContext context = FacesContext.getCurrentInstance();
        if (context != null) {
            getExternalContext().log(message, throwable);
        } else {
            logger.info(message, throwable);
        }
    }

    protected void info(String summary) {
        logger.info(summary);
        getFacesContext().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, summary, null));
    }

    protected void info(Exception exception) {
        info(exception.getMessage());
    }

    protected void info(UIComponent component, String summary) {
        logger.info(summary);
        getFacesContext().addMessage(component.getClientId(getFacesContext()),
                new FacesMessage(FacesMessage.SEVERITY_INFO, summary, null));
    }

    protected void info(UIComponent component, Exception exception) {
        info(component, exception.getLocalizedMessage());
    }

    protected void warn(String summary) {
        logger.warn(summary);
        getFacesContext().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, summary, null));
    }

    protected void warn(Exception exception) {
        warn(exception.getMessage());
    }

    protected void warn(UIComponent component, String summary) {
        logger.warn(summary);
        getFacesContext().addMessage(component.getClientId(getFacesContext()),
                new FacesMessage(FacesMessage.SEVERITY_WARN, summary, null));
    }

    protected void warn(UIComponent component, Exception exception) {
        warn(component, exception.getLocalizedMessage());
    }

    protected void error(String summary) {
        logger.error(summary);
        getFacesContext().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, summary, null));
    }

    protected void validationError(ValidationException exception) {
        logger.error(exception);
        for (String mensagem : exception.getErros()) {
            getFacesContext().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, mensagem, null));
        }
    }

    protected void error(Exception exception) {
        logger.error(exception);
        error(exception.getMessage());
    }

    protected void error(UIComponent component, String summary) {
        logger.error(summary);
        getFacesContext().addMessage(component.getClientId(getFacesContext()),
                new FacesMessage(FacesMessage.SEVERITY_ERROR, summary, null));
    }

    protected HttpServletRequest getRequest() {
        return (HttpServletRequest) getExternalContext().getRequest();
    }

    protected void error(UIComponent component, Exception exception) {
        logger.error(exception);
        error(component, exception.getLocalizedMessage());
    }

    protected void fatal(String summary) {
        logger.fatal(summary);
        getFacesContext().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, summary, null));
    }

    protected void fatal(Exception exception) {
        logger.error(exception);
        fatal(exception.getMessage());
    }

    protected void fatal(UIComponent component, String summary) {
        logger.fatal(summary);
        getFacesContext().addMessage(component.getClientId(getFacesContext()),
                new FacesMessage(FacesMessage.SEVERITY_FATAL, summary, null));
    }

    protected void fatal(UIComponent component, Exception exception) {
        logger.error(exception);
        fatal(component, exception.getLocalizedMessage());
    }
    
    protected void handlerException(Throwable throwable) {
        setShowGlobalMessage(Boolean.TRUE);

        if (throwable.getCause() != null) {
            handlerException(throwable.getCause());
        } else {

            if (throwable instanceof Exception) {

                warn("Favor informe " + ((Exception)throwable).getMessage());
            } else if (throwable instanceof Exception) {
                warn(throwable.getMessage());
            } else if (throwable instanceof Exception) {
                error(throwable.getMessage());
            } else  {
                fatal((Exception) throwable);
            } 
        }
    }
}
