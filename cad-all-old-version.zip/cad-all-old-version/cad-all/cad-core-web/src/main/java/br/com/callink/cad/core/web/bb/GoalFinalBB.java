package br.com.callink.gbo.core.web.bb;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.model.SelectItem;

import br.com.callink.gbo.core.web.bb.util.JSFUtil;
import br.com.callink.gbo.enumeration.ImagesnMetaEnum;
import br.com.callink.gbo.pojo.GoalFinal;
import br.com.callink.gbo.service.IGoalFinalService;
import br.com.callink.gbo.service.exception.ServiceException;
import br.com.callink.gbo.service.exception.ValidationException;

@ManagedBean
@ViewScoped
public class GoalFinalBB extends GboGenericCrud<GoalFinal, IGoalFinalService> {

	private static final long serialVersionUID = 754098939982259881L;
	private List<GoalFinal> goalsAtivos;
	private List<GoalFinal> goalsAntigos;
	private List<GoalFinal> goalsNovos;
	private List<GoalFinal> listHistoricoGoals;
	private List<String> listImagens;
	
	@EJB
	private IGoalFinalService goalFinalService;

	@PostConstruct
    public void init() {
		novo();
		buscarGoalsAtivos();
	}
	
	public void buscarGoalsAtivos() {
		try {
			setPojos(getService().buscaGoalsAtivos());
			buscaFilas();
		} catch (ServiceException e) {
			logger.error(e);
			handlerException(e);
		}
	}
	
	public void buscarHistoricoGoals() {
		try {
			listHistoricoGoals = getService().buscaHistoricoGoals();
			buscaFilas();
		} catch (ServiceException e) {
			logger.error(e);
			handlerException(e);
		}
	}

	
	private void buscaFilas() {
		
		if(listImagens == null){
			listImagens = new ArrayList<String>();
		}
	
        if(listImagens.size() == 0) {
            for(ImagesnMetaEnum image: ImagesnMetaEnum.values() ) {
            	listImagens.add(image.getDescricao());
            }
        }
    }
	
	
	public String salvar() {
		getPojo().setLoginUsuario(getLoginUsuario());
		try {
			
			List<GoalFinal> listaVerificaRange = getService().buscaGoalsAtivos();
			
			if (listaVerificaRange == null) {
				listaVerificaRange = new ArrayList<GoalFinal>();
			}
			
			listaVerificaRange.add(getPojo());
			
			if (getService().validaRangeGoalFinal(listaVerificaRange)) {
				getService().saveGoal(getPojo());
				if (getPojo().getIdGoalFinal() != null) {
					novo();
					filtrar();
					info("Cadastrado com sucesso");
				}
			} else {
				mensagemErroRangeInvalido();	
			}
		} catch (ServiceException e) {
			logger.error(e);
			handlerException(e);
		}
		
		return "";
	}

	public String excluir(GoalFinal goalFinal) {
        try {
            getService().delete(goalFinal);
            filtrar();

        } catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException ex) {
			logger.error(ex);
            error(ex);
        }
        return null;
    }
	    
    public void alterar(GoalFinal goalFinal) {
    	try {
			goalsAtivos = getService().buscaGoalsAtivos();
			setPojo(goalFinal);
    	} catch (ServiceException e) {
    		logger.error(e);
    		handlerException(e);
    	}
    }
    
    
    public void validaListaEdit(GoalFinal goalFinal) {
    	
    	if(goalsAtivos.contains(goalFinal)) {
    		GoalFinal goalAux = goalsAtivos.get(goalsAtivos.indexOf(goalFinal));
    		
    		if(goalsAntigos.contains(goalAux)) {
    			goalsAntigos.remove(goalAux);
    			goalsAntigos.add(goalAux);
    		} else {
    			goalsAntigos.add(goalAux);
    		}
    	}
    	
    	goalsNovos.add(goalFinal);
    	
    }
    		
    public void editarGoalFinal() {
    	try {
    		if (getService().validaRangeGoalFinal(goalsAtivos)) {
    			getService().editarGoalFinal(goalsAtivos);
    			
    			buscarGoalsAtivos();
    			novo();
        	} else {
				mensagemErroRangeInvalido();
        	}
    	} catch (Exception ex) {
    		logger.error(ex);
    		handlerException(ex);
    	}
    }

	private void mensagemErroRangeInvalido() throws ServiceException {
		throw new ServiceException("O intervalo entre os Goals não são válidos.");
	}
   
	public final List<GoalFinal> getGoalsAtivos() {
		return goalsAtivos;
	}

	public final void setGoalsAtivos(List<GoalFinal> goalsAtivos) {
		this.goalsAtivos = goalsAtivos;
	}

	public final List<GoalFinal> getGoalsAntigos() {
		return goalsAntigos;
	}

	public final void setGoalsAntigos(List<GoalFinal> goalsAntigos) {
		this.goalsAntigos = goalsAntigos;
	}

	public final List<GoalFinal> getGoalsNovos() {
		return goalsNovos;
	}

	public final void setGoalsNovos(List<GoalFinal> goalsNovos) {
		this.goalsNovos = goalsNovos;
	}
	
	public List<SelectItem> getListImagens() {
        return JSFUtil.toSelectItemConsulta(listImagens);
    }

    public void setListImagens(List<String> listImagens) {
        this.listImagens = listImagens;
    }

	public List<GoalFinal> getListHistoricoGoals() {
		return listHistoricoGoals;
	}

	public void setListHistoricoGoals(List<GoalFinal> listHistoricoGoals) {
		this.listHistoricoGoals = listHistoricoGoals;
	}

	@Override
	public void novo() {
		setPojo(new GoalFinal());
	}

	@Override
	protected IGoalFinalService getService() {
		return goalFinalService;
	}
		
}
