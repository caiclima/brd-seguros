/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.gbo.core.web.bb;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.apache.commons.lang.StringUtils;

import br.com.callink.gbo.pojo.AssociaGrupoEmail;
import br.com.callink.gbo.pojo.EnderecoEmail;
import br.com.callink.gbo.pojo.GrupoEmail;
import br.com.callink.gbo.service.IAssociaGrupoEmailService;
import br.com.callink.gbo.service.IEnderecoEmailService;
import br.com.callink.gbo.service.IGrupoEmailService;
import br.com.callink.gbo.service.exception.ServiceException;
import br.com.callink.gbo.service.exception.ValidationException;

/**
 *
 * @author Luiz Gustavo (luizgf@swb.com.br)
 */
@ManagedBean
@ViewScoped
public final class GrupoEmailBB extends GboGenericCrud<GrupoEmail, IGrupoEmailService> {

    private static final long serialVersionUID = 1L;
    private List<EnderecoEmail> enderecoEmailList;
    private List<EnderecoEmail> enderecoEmailSelecionado;
    private EnderecoEmail enderecoEmail;
    private Boolean selecionaTodosEmails;
    
    @EJB
    private IGrupoEmailService grupoEmailService;
    @EJB
    private IEnderecoEmailService enderecoEmailService;
    @EJB
    private IAssociaGrupoEmailService associaGrupoEmailService;
    
    @PostConstruct
    public void init() {
    	try {
    		setPojo(new GrupoEmail());
            setPojos(getService().findByExample(getPojo(), "GrupoEmail.DESCRICAO"));
            getPojo().setFlagAtivo(Boolean.TRUE);
            
            novo();
        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }
    }

    @Override
    public void novo() {
        
        try {
            setPojo(new GrupoEmail());
            getPojo().setFlagAtivo(Boolean.TRUE);
            enderecoEmailSelecionado = new ArrayList<EnderecoEmail>();
            novoAssociaEmail();
            setPojos(grupoEmailService.findAll());
            
        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }
        
    }

    public void novoAssociaEmail() {
        try {
            setSelecionaTodosEmails(Boolean.FALSE);
            enderecoEmail = new EnderecoEmail();
            enderecoEmailList = enderecoEmailService.findAtivos("EnderecoEmail.DESCRICAO");
            ordenaLista();
        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }

    }
    
    @Override
    public String salvar() {
        try {
            validaCampos();
            super.salvar();
            novo();
            setPojos(getService().findByExample(getPojo(), "GrupoEmail.DESCRICAO"));
        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }
        return null;
    }

    private void validaCampos() throws ServiceException {
        if (StringUtils.isBlank(getPojo().getDescricao())) {
            throw new ServiceException("Campo descriçao não pode ser vazio!");
        }
    }

    public void alteraValorPojo(GrupoEmail grupoEmail) {
        super.setPojo(grupoEmail);
    }

    public String excluir(GrupoEmail grupoEmail) {
        try {
            getService().delete(grupoEmail);
            filtrar();

        } catch (ValidationException e) {
			error(e.getMessage());
		}catch (Exception ex) {
			logger.error(ex);
            error("Não foi possivel excluir este Grupo. Verifique se não há emails associados a ele antes de fazer a exclusão.");
        }
        return null;
    }
    
    public void excluir(EnderecoEmail enderecoEmail) {
        enderecoEmailSelecionado.remove(enderecoEmail);
        if (enderecoEmailList != null && enderecoEmailList.contains(enderecoEmail)) {
            Integer index = enderecoEmailList.indexOf(enderecoEmail);
            if (index >= 0) {
                EnderecoEmail end = enderecoEmailList.get(index);
                end.setSelecionado(Boolean.FALSE);
            }
        }

    }

    public void findAll() {
        try {
            setPojos(grupoEmailService.findAtivos("GrupoEmail.DESCRICAO"));
        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }
    }
    
    public void selecionaEmails() {
        if (enderecoEmailSelecionado == null) {
            enderecoEmailSelecionado = new ArrayList<EnderecoEmail>();
        }

        for (EnderecoEmail item : enderecoEmailList) {
            if (item.isSelecionado() && !enderecoEmailSelecionado.contains(item)) {
                enderecoEmailSelecionado.add(item);
            } else {
                if (!item.isSelecionado() && enderecoEmailSelecionado.contains(item)) {
                    enderecoEmailSelecionado.remove(item);
                }
            }
        }
    }
    
    public void filtrarEmails() {
        if (enderecoEmailSelecionado == null) {
            enderecoEmailSelecionado = new ArrayList<EnderecoEmail>();
        }
        try {
            enderecoEmailList = enderecoEmailService.findByExample(enderecoEmail, "EnderecoEmail.DESCRICAO");
            
            for (EnderecoEmail item : enderecoEmailList) {
                if (enderecoEmailSelecionado.contains(item)) {
                    item.setSelecionado(Boolean.TRUE);
                }
            }
            
        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }
    }
    
    public void salvarEmailsDepartamento() {
        try {
            associaGrupoEmailService.saveGrupoEmails(getPojo(), enderecoEmailSelecionado);
            novo();
        } catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException ex) {
			logger.error(ex);
            error(ex);
        }
    }
    
    public void selecionaTodosEmails() {
        if (selecionaTodosEmails) {
            for (EnderecoEmail item : enderecoEmailList) {
                if (!enderecoEmailSelecionado.contains(item)) {
                    item.setSelecionado(Boolean.TRUE);
                    enderecoEmailSelecionado.add(item);
                }
            }
        } else {
            for (EnderecoEmail item : enderecoEmailList) {
                if (enderecoEmailSelecionado.contains(item)) {
                    item.setSelecionado(Boolean.FALSE);
                    enderecoEmailSelecionado.remove(item);
                }
            }
        }
    }
    
    public void verificaEmailsGrupo(GrupoEmail grupoEmail) {
         try {
            novoAssociaEmail();
            enderecoEmailSelecionado = new ArrayList<EnderecoEmail>();
            
            AssociaGrupoEmail associaGrupoEmail = new AssociaGrupoEmail();
            associaGrupoEmail.setGrupoEmail(grupoEmail);
            List<AssociaGrupoEmail> associaGrupoEmails = associaGrupoEmailService.findByExample(associaGrupoEmail);
            if (associaGrupoEmails != null) {
                for (AssociaGrupoEmail item : associaGrupoEmails) {
                    enderecoEmailSelecionado.add(enderecoEmailService.findByPk(item.getEnderecoEmail()));
                }
            }
            
            filtrarEmails();
            alteraValorPojo(grupoEmail);
        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }
    }

    public List<EnderecoEmail> getEnderecoEmailList() {
        return enderecoEmailList;
    }

    public void setEnderecoEmailList(List<EnderecoEmail> enderecoEmailList) {
        this.enderecoEmailList = enderecoEmailList;
    }

    public List<EnderecoEmail> getEnderecoEmailSelecionado() {
        return enderecoEmailSelecionado;
    }

    public void setEnderecoEmailSelecionado(List<EnderecoEmail> enderecoEmailSelecionado) {
        this.enderecoEmailSelecionado = enderecoEmailSelecionado;
    }

    public EnderecoEmail getEnderecoEmail() {
        return enderecoEmail;
    }

    public void setEnderecoEmail(EnderecoEmail enderecoEmail) {
        this.enderecoEmail = enderecoEmail;
    }

    public Boolean getSelecionaTodosEmails() {
        return selecionaTodosEmails;
    }

    public void setSelecionaTodosEmails(Boolean selecionaTodosEmails) {
        this.selecionaTodosEmails = selecionaTodosEmails;
    }

    private void ordenaLista() {
        Collections.sort(enderecoEmailList, new Comparator() {  
            public int compare(Object o1, Object o2) {  
                EnderecoEmail e1 = (EnderecoEmail) o1;  
                EnderecoEmail e2 = (EnderecoEmail) o2;  
                return e1.getDescricao().compareTo(e2.getDescricao());  
            }  
        });
    }

	@Override
	protected IGrupoEmailService getService() {
		return grupoEmailService;
	}
    
}
