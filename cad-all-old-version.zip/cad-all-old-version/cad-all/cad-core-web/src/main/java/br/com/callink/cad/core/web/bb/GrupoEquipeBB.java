/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.gbo.core.web.bb;

import br.com.callink.gbo.pojo.ConfiguracaoFila;
import br.com.callink.gbo.pojo.Equipe;
import br.com.callink.gbo.pojo.GrupoEquipe;
import br.com.callink.gbo.pojo.GrupoEquipeFila;
import br.com.callink.gbo.service.IConfiguracaoFilaService;
import br.com.callink.gbo.service.IEquipeService;
import br.com.callink.gbo.service.IGrupoEquipeFilaService;
import br.com.callink.gbo.service.IGrupoEquipeService;
import br.com.callink.gbo.service.exception.ServiceException;
import br.com.callink.gbo.service.exception.ValidationException;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

/**
 *
 * @author Rogerio
 */
@ManagedBean
@ViewScoped
public class GrupoEquipeBB extends GboGenericCrud<GrupoEquipe, IGrupoEquipeService> {

    private static final long serialVersionUID = 1L;
    private List<Equipe> equipeList;
    private List<GrupoEquipeFila> grupoFilaList;
    private Boolean selecionaTodosEquipe;
    @EJB
    private IGrupoEquipeService IGrupoEquipeService;
    @EJB
    private IConfiguracaoFilaService configuracaoFilaService;
    @EJB
    private IGrupoEquipeFilaService grupoEquipeFilaService;
    @EJB
    private IEquipeService equipeService;
    
    @PostConstruct
    public void init() {
    	try {
    		novo();
            setPojos(getService().findAll());
            if (equipeList == null) {
                setEquipeList(equipeService.findAtivos());
            }
        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }
    }

    public void selecionaTodosEquipe() {
        for (Equipe item : getEquipeList()) {
            if (selecionaTodosEquipe) {
                item.setSelecionado(Boolean.TRUE);
            } else {
                item.setSelecionado(Boolean.FALSE);
            }
        }
    }

    public void buscaConfiguracaoFilaPodeSerAssociado() {
        try {

            setGrupoFilaList(new ArrayList<GrupoEquipeFila>());

            List<ConfiguracaoFila> configuracaoFilaList = configuracaoFilaService.buscaFilaAtivaPorPrioridade();

            if (configuracaoFilaList != null && !configuracaoFilaList.isEmpty()) {

                for (ConfiguracaoFila configuracaoFila : configuracaoFilaList) {
                    GrupoEquipeFila grupoEquipeFila = new GrupoEquipeFila();
                    grupoEquipeFila.setConfiguracaoFila(configuracaoFila);
                    if (podeAddConfiguracaoFila(configuracaoFila)) {
                        getGrupoFilaList().add(grupoEquipeFila);
                    }
                }
            }
        } catch (ServiceException e) {
        	logger.error(e);
            error(e);
        }
    }

    private boolean podeAddConfiguracaoFila(ConfiguracaoFila configuracaoFila) {
        if (getPojo().getGrupoEquipeFilaList() != null) {
            for (GrupoEquipeFila gf : getPojo().getGrupoEquipeFilaList()) {
                if (gf.getConfiguracaoFila().equals(configuracaoFila)) {
                    return false;
                }
            }
        }
        return true;
    }

    public void associaFilaGrupo() {
        try {
            if (getPojo().getGrupoEquipeFilaList() == null) {
                getPojo().setGrupoEquipeFilaList(new ArrayList<GrupoEquipeFila>());
            }
            for (GrupoEquipeFila gfl : grupoFilaList) {
                if (gfl.getConfiguracaoFila().getSelecionado()) {
                    gfl.setIdGrupoEquipe(getPojo());
                    grupoEquipeFilaService.save(gfl);
                    getPojo().getGrupoEquipeFilaList().add(gfl);
                }
            }
        } catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException e) {
			logger.error(e);
            error(e);
        }
    }

    public void removeFilaGrupo(GrupoEquipeFila grupoFila) {
        try {
        	grupoEquipeFilaService.delete(grupoFila);
            getPojo().getGrupoEquipeFilaList().remove(grupoFila);
        } catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException e) {
			logger.error(e);
            error(e);
        }

    }

    public String excluir(GrupoEquipe equipe) {
        try {
            getService().delete(equipe);
            setPojos(getService().findAll());
        } catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException e) {
			logger.error(e);
            error(e);
        }
        return null;
    }

    @Override
    public String salvar() {
        try {
            getService().saveOrUpdate(getPojo());
            setPojos(getService().findAll());
            setPojo(new GrupoEquipe());
        } catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException e) {
			logger.error(e);
            error(e);
        }
        return null;
    }

    public void associarEquipe() {
        try {
            getService().associaEquipeFila(getPojo(), equipeList);
            info("Associa\u00E7\u00E3o de filas concluida com sucesso.");
        } catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException e) {
			logger.error(e);
            error(e);
        }

    }

    public void limpaGrupoEquipe() {
        setPojo(new GrupoEquipe());
    }

    public void editar(GrupoEquipe equipe) {
        try {
            equipe.setGrupoEquipeFilaList(grupoEquipeFilaService.grupoEquipeFilaList(equipe));
        } catch (ServiceException e) {
        	logger.error(e);
            error(e);
        }
        setPojo(equipe);
    }

    public List<Equipe> getEquipeList() {
        return equipeList;
    }

    public void setEquipeList(List<Equipe> equipeList) {
        this.equipeList = equipeList;
    }

    public List<GrupoEquipeFila> getGrupoFilaList() {
        return grupoFilaList;
    }

    public void setGrupoFilaList(List<GrupoEquipeFila> grupoFilaList) {
        this.grupoFilaList = grupoFilaList;
    }

    public Boolean getSelecionaTodosEquipe() {
        return selecionaTodosEquipe;
    }

    public void setSelecionaTodosEquipe(Boolean selecionaTodosEquipe) {
        this.selecionaTodosEquipe = selecionaTodosEquipe;
    }

	@Override
	public void novo() {
		setPojo(new GrupoEquipe());
	}

	@Override
	protected IGrupoEquipeService getService() {
		return IGrupoEquipeService;
	}
}
