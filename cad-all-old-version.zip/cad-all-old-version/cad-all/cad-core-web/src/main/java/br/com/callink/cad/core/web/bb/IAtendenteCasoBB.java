/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.gbo.core.web.bb;

import br.com.callink.gbo.pojo.Caso;
import java.util.Map;

/**
 *
 * @author Rogério Moreira de Andrade
 */
public interface IAtendenteCasoBB {
    
   void solicitaCaso();

   void atualizaLista();
   
    /**
     * Adiciona parametros para execução de um comando. Verificar em cada comando quais parametros são necessários para 
     * execução do mesmo.
     */
   Map<String, Object> getParamsGBO(); 
   
   Caso getCaso();
}
