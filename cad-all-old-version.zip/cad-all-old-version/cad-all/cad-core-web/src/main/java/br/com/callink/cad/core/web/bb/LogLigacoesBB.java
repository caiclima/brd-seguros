package br.com.callink.gbo.core.web.bb;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import br.com.callink.gbo.pojo.Atendente;
import br.com.callink.gbo.pojo.LogLigacoes;
import br.com.callink.gbo.service.IAtendenteService;
import br.com.callink.gbo.service.ILogLigacoesService;
import br.com.callink.gbo.service.exception.ServiceException;
import br.com.callink.gbo.util.Constantes;

/**
 * 
 * @author jose_araujo
 *
 */
@ManagedBean
@ViewScoped
public class LogLigacoesBB extends GboGenericCrud<LogLigacoes,ILogLigacoesService> {

    private static final long serialVersionUID = 1L;

    private String idCaso;
    private Date dataInicio;
    private Date dataFim;
    private List<String> atendenteNomeSelecionadoList;
    private List<Atendente> atendenteList;
    private List<Atendente> atendenteSelecionadoList;
    private String flagEntrante;
    private boolean selecionaTodosAtendente;
    private boolean flagMostraGridAnalista;
    @EJB
    private ILogLigacoesService logLigacoesService;
    @EJB
    private IAtendenteService atendenteService;
    
    @PostConstruct
    public void init() {
    	atendenteSelecionadoList = new ArrayList<Atendente>();
    }
    
    public void buscaLogs() {
    	try {
    		setPojos(getService().findByFilters(idCaso, flagEntrante, dataInicio, dataFim, atendenteSelecionadoList));
    		
    	} catch (Exception e) {
    		logger.error(e);
    		error(e);
		}
    }

	/**
	 * @return the idCaso
	 */
	public String getIdCaso() {
		return idCaso;
	}

	/**
	 * @param idCaso the idCaso to set
	 */
	public void setIdCaso(String idCaso) {
		this.idCaso = idCaso;
	}

	/**
	 * @return the dataInicio
	 */
	public Date getDataInicio() {
		return dataInicio;
	}

	/**
	 * @param dataInicio the dataInicio to set
	 */
	public void setDataInicio(Date dataInicio) {
		this.dataInicio = dataInicio;
	}

	/**
	 * @return the dataFim
	 */
	public Date getDataFim() {
		return dataFim;
	}

	/**
	 * @param dataFim the dataFim to set
	 */
	public void setDataFim(Date dataFim) {
		this.dataFim = dataFim;
	}

	/**
	 * @return the atendenteNomeSelecionadoList
	 */
	public List<String> getAtendenteNomeSelecionadoList() {
        if (atendenteNomeSelecionadoList == null) {
            atendenteNomeSelecionadoList = new ArrayList<String>();
        }
        return atendenteNomeSelecionadoList;
	}

	/**
	 * @param atendenteNomeSelecionadoList the atendenteNomeSelecionadoList to set
	 */
	public void setAtendenteNomeSelecionadoList(
			List<String> atendenteNomeSelecionadoList) {
		this.atendenteNomeSelecionadoList = atendenteNomeSelecionadoList;
	}

	/**
	 * @return the atendenteSelecionadoList
	 */
	public List<Atendente> getAtendenteSelecionadoList() {
		return atendenteSelecionadoList;
	}

	/**
	 * @param atendenteSelecionadoList the atendenteSelecionadoList to set
	 */
	public void setAtendenteSelecionadoList(List<Atendente> atendenteSelecionadoList) {
		this.atendenteSelecionadoList = atendenteSelecionadoList;
	}

	/**
	 * @return the flagEntrante
	 */
	public String getFlagEntrante() {
		return flagEntrante;
	}

	/**
	 * @param flagEntrante the flagEntrante to set
	 */
	public void setFlagEntrante(String flagEntrante) {
		this.flagEntrante = flagEntrante;
	}

    public final void setSelecionaTodosAtendente(boolean selecionaTodosAtendente) {
        this.selecionaTodosAtendente = selecionaTodosAtendente;
    }
	
    public void limpaAtendentes() {
        setSelecionaTodosAtendente(Boolean.FALSE);
        selecionaTodosAtendentes();
    }

    public void selecionaTodosAtendentes() {
        for (Atendente item : getAtendenteList()) {
            if (selecionaTodosAtendente == Boolean.TRUE) {
                item.setSelecionado(Boolean.TRUE);
            } else {
                item.setSelecionado(Boolean.FALSE);
            }
            marcaDesmarcaAtendente(item);
        }
    }

    public void marcaDesmarcaAtendente(Atendente atendente) {
        if (atendente != null && atendente.getSelecionado() != null) {

            if (atendente.getSelecionado()) {
                if (!getAtendenteNomeSelecionadoList().contains(
                        atendente.getLogin())) {
                    getAtendenteNomeSelecionadoList().add(atendente.getLogin());
                    getAtendenteSelecionadoList().add(atendente);
                }
            } else {
                if (getAtendenteNomeSelecionadoList().contains(
                        atendente.getLogin())) {
                    getAtendenteNomeSelecionadoList().remove(
                            atendente.getLogin());
                    getAtendenteSelecionadoList().remove(atendente);
                }
            }
        }
    }

    public String getAtendentesSelecionados() {
        if (atendenteNomeSelecionadoList == null
                || atendenteNomeSelecionadoList.toString().equals(
                Constantes.LISTA_STRING_VAZIA)) {
            return "";
        }
        return atendenteNomeSelecionadoList.toString();
    }
    
    public final List<Atendente> getAtendenteList() {
        if (atendenteList == null) {
            try {
                atendenteList = atendenteService.findAll("LOGIN");
            } catch (ServiceException e) {
            	logger.error(e);
                error(e);
            }
        }
        return atendenteList;
    }

    public final void setAtendenteList(List<Atendente> atendenteList) {
        this.atendenteList = atendenteList;
    }

    public void buscaAtendentes() {
        try {
            setAtendenteList(atendenteService.findAll("LOGIN"));
            mostraGridAnalista();
        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }
    }

    public void mostraGridAnalista() {
        flagMostraGridAnalista = Boolean.TRUE;
    }

	/**
	 * @return the flagMostraGridAnalista
	 */
	public boolean isFlagMostraGridAnalista() {
		return flagMostraGridAnalista;
	}

	/**
	 * @param flagMostraGridAnalista the flagMostraGridAnalista to set
	 */
	public void setFlagMostraGridAnalista(boolean flagMostraGridAnalista) {
		this.flagMostraGridAnalista = flagMostraGridAnalista;
	}

	/**
	 * @return the selecionaTodosAtendente
	 */
	public boolean isSelecionaTodosAtendente() {
		return selecionaTodosAtendente;
	}
	
    public void escondeGrids() {
        flagMostraGridAnalista = Boolean.FALSE;
    }

	@Override
	public void novo() {
		setPojo(new LogLigacoes());
	}

	@Override
	protected ILogLigacoesService getService() {
		return logLigacoesService;
	}
    
}
