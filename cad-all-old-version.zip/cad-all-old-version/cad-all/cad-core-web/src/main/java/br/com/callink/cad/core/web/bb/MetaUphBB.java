/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.gbo.core.web.bb;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.model.SelectItem;

import br.com.callink.gbo.core.web.bb.util.JSFUtil;
import br.com.callink.gbo.enumeration.ImagesnMetaEnum;
import br.com.callink.gbo.pojo.CabUph;
import br.com.callink.gbo.pojo.ConfiguracaoFila;
import br.com.callink.gbo.pojo.MetaUph;
import br.com.callink.gbo.service.ICabUphService;
import br.com.callink.gbo.service.IConfiguracaoFilaService;
import br.com.callink.gbo.service.IMetaUphService;
import br.com.callink.gbo.service.exception.ServiceException;
import br.com.callink.gbo.service.exception.ValidationException;

/**
 *
 * @author swb.miller
 */
@ManagedBean
@ViewScoped
public class MetaUphBB extends GboGenericCrud<CabUph, ICabUphService> {

    private static final long serialVersionUID = 1L;
    private List<MetaUph> listMetas;
    private List<MetaUph> listMetasEdit;
    private List<ConfiguracaoFila> listFila;
    private List<String> listImagens;
    private MetaUph metaUph;
    private CabUph cabUphNovo;
    private List<CabUph> listaHistoricoMeta = new ArrayList<CabUph>();
    
    @EJB
    private IMetaUphService metaUphService;
    @EJB
    private ICabUphService cabUphService;
    @EJB
    private IConfiguracaoFilaService configuracaoFilaService;

    @PostConstruct
    public void init() {
    	try {
    		setPojo(new CabUph());
            buscaFilas();
            limpaListaMetas();
            limpaMeta();
            
            setPojos(getService().findCabUphList(null, null, null));
        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }
    }

    @Override
    public String salvar() {
        String ret = "";
        try {
            if (validaCampos()) {
                getPojo().setLogiUsuario(getLoginUsuario());
                getService().salvaMetasParametrizadas(listMetas, getPojo());
                setPojos(getService().findCabUphList(null,null,null));
                setPojo(new CabUph());
                limpaListaMetas();
                info("Metas salvo com sucesso");
            } else {
                setErrorMessage("Campos obrigatorios nao foram preenchidos.");
            }
        } catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException e) {
			logger.error(e);
            handlerException(e);
        }
        return ret;
    }
    
    public String salvarEdicao() {
        String ret = "";
        try {
                cabUphNovo.setLogiUsuario(getLoginUsuario());
                getService().salvaMetasParametrizadas(listMetasEdit, cabUphNovo);
                setPojos(getService().findCabUphList(null,null,null));
                setPojo(new CabUph());
                cabUphNovo = new CabUph();
                limpaListaMetas();
                info("Metas salvo com sucesso");
        } catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException e) {
			logger.error(e);
            handlerException(e);
        }
        return ret;
    }
    
    
    public void editaMeta() {
        try {
            if (validaCamposEdicao()) {
            	getService().salvaNovaMetaParametrizada(listMetas, getPojo(), cabUphNovo);
            } else {
                setErrorMessage("Campos obrigatorios nao foram preenchidos.");
            }
        } catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException e) {
			logger.error(e);
            handlerException(e);
        }
    }
    

    @Override
    public void novo() {
        try {
            setPojo(new CabUph());
            buscaFilas();
            limpaListaMetas();
            limpaMeta();
            setPojos(getService().findAll());
        } catch (ServiceException e) {
        	logger.error(e);
            error(e);
        }
    } 
    
    
    public void pesquisar() {
    	try {
    		setPojos(getService().findCabUphList(getPojo().getDescricao(), getPojo().getConfiguracaoFila(), getPojo().getMeta()));
    	} catch (Exception e) {
    		logger.error(e);
			error(e);
		}
    }
    
    public void salvarMetas() {
    	if (metaUph.getDescricao() == null || metaUph.getGoal() == null || metaUph.getMeta() == null
    			|| metaUph.getNomeImagem() == null || "".equals(metaUph.getDescricao())
    			|| metaUph.getGoal() < 0 || metaUph.getMeta() < 0 || "".equals(metaUph.getNomeImagem())) {
    		handlerException(new Exception("Favor preencher todos os campos."));
    	} else {
            listMetas.add(metaUph);
            limpaMeta();
    	}
    }
    
    public void salvarMetasEdit() {
        listMetasEdit.add(metaUph);
        limpaMeta();
    }
    
    public void deletaMeta(MetaUph meta) {
        listMetas.remove(meta);
    }
    
    public void deletaMetaEdit(MetaUph meta) {
        listMetasEdit.remove(meta);
    }

    public void excluir(MetaUph meta) {
        try {
            metaUphService.delete(meta);
            filtrar();
        } catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException ex) {
			logger.error(ex);
            error(ex);
        }
    }

    private boolean validaCampos() {
        if (listMetas.isEmpty()) {
            return false;
        }

        if (getPojo().getConfiguracaoFila() == null) {
            return false;
        }

        return true;
    }
    
    private boolean validaCamposEdicao() {
        if (listMetas.isEmpty()) {
            return false;
        }

        if (cabUphNovo.getConfiguracaoFila() == null) {
            return false;
        }

        return true;
    }
    
    public void alterar(CabUph metaEdicao) {
        try {
            
            cabUphNovo = new CabUph();
            cabUphNovo.setDataFinal(metaEdicao.getDataFinal()); 
            cabUphNovo.setDataInicial(metaEdicao.getDataInicial()); 
            cabUphNovo.setDescricao(metaEdicao.getDescricao());
            cabUphNovo.setConfiguracaoFila(configuracaoFilaService.findByPk(metaEdicao.getConfiguracaoFila()));
            cabUphNovo.setLogiUsuario(metaEdicao.getLogiUsuario());
            cabUphNovo.setConfiguracaoFila(metaEdicao.getConfiguracaoFila());
            cabUphNovo.setMeta(metaEdicao.getMeta());
            
            setPojo(metaEdicao);
            listMetasEdit = metaUphService.findMetaByCabUph(metaEdicao);
            for(MetaUph meta:listMetasEdit) {
                meta.setIdCabUph(null);
                meta.setIdMetaUph(null);
            }
            
        } catch (ServiceException e) {
        	logger.error(e);
            handlerException(e);
        }
    }

    private void buscaFilas() {
        try {
            listFila = configuracaoFilaService.findAtivos("nome");
            if(listImagens == null) {
            	listImagens = new ArrayList<String>();
            }
            if(listImagens.size() == 0) {
	            for(ImagesnMetaEnum image: ImagesnMetaEnum.values() ) {
	            	listImagens.add(image.getDescricao());
	            }
            }
            
        } catch (ServiceException ex) {
        	logger.error(ex);
            //Logger.getLogger(MetaUphBB.class.getName()).log(Level.SEVERE, null, ex);
            error(ex);
        }
    }
    
    public void visualizaHistoricoMeta(ConfiguracaoFila configuracaoFila) {
    	listaHistoricoMeta = new ArrayList<CabUph>();
    	try {
    		listaHistoricoMeta = getService().findLlistByConfFila(configuracaoFila);
    	} catch (Exception ex) {
    		logger.error(ex);
    		error(ex);
    	}
    }

    public void limpaListaMetas() {
        listMetas = new ArrayList<MetaUph>();
        listMetasEdit = new ArrayList<MetaUph>();
    }

    public void limpaMeta() {
        metaUph = new MetaUph();
    }

    public  List<MetaUph> getListMetas() {
        return listMetas;
    }

    public  void setListMetas(List<MetaUph> listMetas) {
        this.listMetas = listMetas;
    }

    public List<SelectItem> getListFila() {
        return JSFUtil.toSelectItemConsulta(listFila);
    }

    public void setListFila(List<ConfiguracaoFila> listFila) {
        this.listFila = listFila;
    }
 
    public List<SelectItem> getListImagens() {
        return JSFUtil.toSelectItemConsulta(listImagens);
    }

    public void setListImagens(List<String> listImagens) {
        this.listImagens = listImagens;
    }

    public MetaUph getMetaUph() {
        if(metaUph  == null) {
            return new MetaUph();
        }
        return metaUph;
    }

    public void setMetaUph(MetaUph metaUph) {
        this.metaUph = metaUph;
    }
    
    public CabUph getCabUphNovo() {
    	if(cabUphNovo == null) {
    		return new CabUph();
    	}
        return cabUphNovo;
    }

    public void setCabUphNovo(CabUph cabUphNovo) {
        this.cabUphNovo = cabUphNovo;
    }

	public List<CabUph> getListaHistoricoMeta() {
		return listaHistoricoMeta;
	}

	public void setListaHistoricoMeta(List<CabUph> listaHistoricoMeta) {
		this.listaHistoricoMeta = listaHistoricoMeta;
	}
    
	public List<MetaUph> getListMetasEdit() {
		return listMetasEdit;
	}

	public void setListMetasEdit(List<MetaUph> listMetasEdit) {
		this.listMetasEdit = listMetasEdit;
	}

	@Override
	protected ICabUphService getService() {
		return cabUphService;
	}
}
