package br.com.callink.gbo.core.web.bb;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import br.com.callink.gbo.pojo.ParametroGBO;
import br.com.callink.gbo.service.IParametroGBOService;
import br.com.callink.gbo.service.exception.ServiceException;
import br.com.callink.gbo.service.exception.ValidationException;

/**
 * 
 * @author brunomt [brunoam@swb.com.br]
 * 
 */
@ManagedBean
@ViewScoped
public class ParametroBB extends GboGenericCrud<ParametroGBO, IParametroGBOService> {
	private static final long serialVersionUID = 1L;

	@EJB
	private IParametroGBOService parametroGBOService;
	
	@PostConstruct
    public void init() {
		try {
			novo();
            setPojos(getService().findAll());
        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }
	}
	
    @Override
    public String salvar() {
    	getPojo().setLoginUsuario(getLoginUsuario());
        String ret = super.salvar();
        novo();
        filtrar();
        return ret;
    }

	public String excluir(ParametroGBO parametro) {
        try {
            getService().delete(parametro);
            filtrar();

        } catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException ex) {
			logger.error(ex);
            error(ex);
        }
        return null;
    }
    
    public void alterar(ParametroGBO parametroGBO) {
    	setPojo(parametroGBO);
    }

	@Override
	public void novo() {
		setPojo(new ParametroGBO());
	}

	@Override
	protected IParametroGBOService getService() {
		return parametroGBOService;
	}
	
}
