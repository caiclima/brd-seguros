package br.com.callink.gbo.core.web.bb;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import br.com.callink.gbo.pojo.Comando;
import br.com.callink.gbo.pojo.ParametroComando;
import br.com.callink.gbo.service.IParametroComandoService;
import br.com.callink.gbo.service.exception.ServiceException;
import br.com.callink.gbo.service.exception.ValidationException;

/**
 * 
 * @author brunomt [brunoam@swb.com.br]
 * 
 */
@ManagedBean
@ViewScoped
public class ParametroComandoBB extends GboGenericCrud<ParametroComando, IParametroComandoService> {
	private static final long serialVersionUID = 1L;

	private Comando comandoSelecionado;
	
	@EJB
	private IParametroComandoService parametroComandoService;

    @Override
    public String salvar() {
    	getPojo().setLoginUsuario(getLoginUsuario());
        String ret = super.salvar();
        if (getPojo().getIdParametroComando() != null) {
        	novo();
        	buscaParametros();
        }
        return ret;
    }

	public String excluir(ParametroComando parametroComando) {
        try {
            getService().delete(parametroComando);
            buscaParametros();

        } catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException ex) {
			logger.error(ex);
            error(ex);
        }
        return null;
    }
    
    public void buscaParametros() {
    	try {
			setPojos(getService().buscaPorComando(comandoSelecionado));
		} catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException e) {
			logger.error(e);
			error(e);
		}
    }
    
    public void alterar(ParametroComando parametroComando) {
    	setPojo(parametroComando);
    }
	
	public void setComandoSelecionado(Comando comandoSelecionado) {
		getPojo().setComando(comandoSelecionado);
		this.comandoSelecionado = comandoSelecionado;
	}

	public Comando getComandoSelecionado() {
		return comandoSelecionado;
	}

	@Override
	public void novo() {
		setPojo(new ParametroComando());
	}

	@Override
	protected IParametroComandoService getService() {
		return parametroComandoService;
	}
	
}
