package br.com.callink.gbo.core.web.bb;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import br.com.callink.gbo.pojo.Perfil;
import br.com.callink.gbo.service.IPerfilService;
import br.com.callink.gbo.service.exception.ServiceException;
import br.com.callink.gbo.service.exception.ValidationException;

/**
 * 
 * @author brunomt [brunoam@swb.com.br]
 * 
 */
@ManagedBean
@ViewScoped
public class PerfilBB extends GboGenericCrud<Perfil, IPerfilService> {
	
	private static final long serialVersionUID = 1L;
	
	@EJB
	private IPerfilService perfilService;
	
	@PostConstruct
    public void init() {
		try {
			novo();
            setPojos(getService().findAll());
        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }
	}
	
	public void findAll() {
        try {
            setPojos(getService().findAll());
        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }
	}
	
    @Override
    public String salvar() {
        String ret = super.salvar();
        if (getPojo().getIdPerfil() != null) {
	        novo();
	        findAll();
        }
        return ret;
    }

	public String excluir(Perfil perfil) {
        try {
            getService().delete(perfil);
            findAll();

        } catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException ex) {
			logger.error(ex);
            error(ex);
        }
        return null;
    }
    
    public void alterar(Perfil perfil) {
    	setPojo(perfil);
    }

	@Override
	public void novo() {
		setPojo(new Perfil());
	}

	@Override
	protected IPerfilService getService() {
		return perfilService;
	}
	
}
