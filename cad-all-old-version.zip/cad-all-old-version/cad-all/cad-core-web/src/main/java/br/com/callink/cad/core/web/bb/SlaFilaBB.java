/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.gbo.core.web.bb;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.model.SelectItem;

import br.com.callink.gbo.core.web.bb.util.BundleHelper;
import br.com.callink.gbo.core.web.bb.util.JSFUtil;
import br.com.callink.gbo.pojo.Caso;
import br.com.callink.gbo.pojo.ConfiguracaoFila;
import br.com.callink.gbo.pojo.SlaFila;
import br.com.callink.gbo.service.ICasoService;
import br.com.callink.gbo.service.IConfiguracaoFilaService;
import br.com.callink.gbo.service.ISlaFilaService;
import br.com.callink.gbo.service.exception.ServiceException;
import br.com.callink.gbo.service.exception.ValidationException;

/**
 *
 * @author swb.miller
 */
@ManagedBean
@ViewScoped
public class SlaFilaBB extends GboGenericCrud<SlaFila, ISlaFilaService> {

    private static final long serialVersionUID = 1L;
    
    private List<ConfiguracaoFila> listFila;
    private SlaFila slaFilaNova;
    private Boolean alterarCasosExistente = false;
    private List<SlaFila> listaHistoricoSla = new ArrayList<SlaFila>();
    
    @EJB
    private ISlaFilaService slaFilaService;
    @EJB
    private ICasoService casoService;
    @EJB
    private IConfiguracaoFilaService configuracaoFilaService;
    
    @PostConstruct
    public void init() {
    	novo();
    	buscarTodosSlas();
    }

	private void buscarTodosSlas() {
		try {
            listFila = new ArrayList<ConfiguracaoFila>();
            buscaFilas();
            setPojos(getService().findAllSlafila());
        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }
	}

    @Override
    public String salvar() {
    	StringBuffer erros = new StringBuffer();
    	boolean existeErro = false;
    	String ret = "";
    	erros.append("Informar");
        getPojo().setDataInicial(new Date(System.currentTimeMillis()));
        
        if (getPojo().getConfiguracaoFila() == null || getPojo().getConfiguracaoFila().getIdConfiguracaoFila() == null
        		|| getPojo().getConfiguracaoFila().getIdConfiguracaoFila() < 1) {
        	erros.append(" Filas,");
        	existeErro = true;
        }
        if (getPojo().getDescricao() == null || "".equals(getPojo().getDescricao())) {
        	erros.append(" Nome,");
        	existeErro = true;
        }
        if (getPojo().getSla() == null || getPojo().getSla() < 1) {
        	erros.append(" SLA!");
        	existeErro = true;
        }
        if (existeErro) {
        	error(erros.toString());
        } else {
        	try {
        		//Verifica se foi solicitado a alteração dos casos ativos.
                if (this.alterarCasosExistente) {
                	alterarCasosAtivosParaNovaSLA(getPojo());
                }
        		
                getService().save(getPojo());
		        
	            novo();
	            
	            this.alterarCasosExistente = false;
	            
                setPojos(getService().findAllSlafila());	  
                
		        info(BundleHelper.getMessage("MSG_Save_Success", "bundleGbo"));

            } catch (ServiceException ex) {
            	logger.error(ex);
                //Logger.getLogger(SlaFilaBB.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        return ret;
    }

    public String excluir(SlaFila slaFila) {
        try {
            getService().delete(slaFila);
            try {
                setPojos(getService().findAllSlafila());
            } catch (ServiceException ex) {
            	logger.error(ex);
                //Logger.getLogger(SlaFilaBB.class.getName()).log(Level.SEVERE, null, ex);
            }

        } catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException ex) {
			logger.error(ex);
            error(ex);
        }
        return null;
    }

    public void alterar(SlaFila slaFila) {
        slaFilaNova = new SlaFila();
        slaFilaNova.setDataFinal(slaFila.getDataFinal());
        slaFilaNova.setDataInicial(slaFila.getDataInicial());
        slaFilaNova.setDescricao(slaFila.getDescricao());
        slaFilaNova.setConfiguracaoFila(slaFila.getConfiguracaoFila());
        slaFilaNova.setSla(slaFila.getSla());
        setPojo(slaFila);
    }
    
    public void salvaEdicao() {
        try {
        	slaFilaNova = getService().saveLogSlaFila(getPojo(), slaFilaNova);
            
            //Verifica se foi solicitado a alteração dos casos ativos.
            if (this.alterarCasosExistente) {
            	alterarCasosAtivosParaNovaSLA(slaFilaNova);
            }
            
            buscarTodosSlas();
        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
            //Logger.getLogger(SlaFilaBB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void buscaFilas() {
        try {
            listFila = configuracaoFilaService.findAtivos("nome");
        } catch (ServiceException ex) {
        	logger.error(ex);
            //Logger.getLogger(SlaFilaBB.class.getName()).log(Level.SEVERE, null, ex);
            error(ex);
        }
    }
    
    /**
     * Altera o SLA para os casos ativos de uma determinada configuração.
     * @param slaFila
     */
	private void alterarCasosAtivosParaNovaSLA(SlaFila slaFila) {
    	try {
    		List<Caso> casoAlteracao = casoService.buscaCasosAtivosPorConfiguracaoFila(slaFila.getConfiguracaoFila());
    		
    		//Verifica se foi retornado ao menos um caso
    		if (casoAlteracao != null && casoAlteracao.size() > 0) {
    			for (Caso caso : casoAlteracao) {
    				caso.setSlaFila(slaFila);
    				casoService.update(caso);
    			}
    		}
    		
    	} catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException ex) {
			logger.error(ex);
    		error("Erro ao alterar Casos abertos com o SLA antigo.");
    	}
    }
	
	/**
	 * Pesquisar sla fila
	 */
	public void pesquisar() {
    	try {
    		
    		if (getPojo().getSla() == null || getPojo().getSla() < 1) {
    			getPojo().setSla(null);
    		}
    		
    		setPojos(getService().findSlaFilaList(
    				getPojo().getConfiguracaoFila(), getPojo().getSla(), getPojo().getDescricao()));
    	} catch (Exception e) {
    		logger.error(e);
			error(e);
		}
	}
	
	/**
	 * Visualizar histórico de sla fila por configuração
	 * 
	 * @param configuracao
	 */
	public void visualizarHistoricoSla(ConfiguracaoFila configuracao) {
		try {
			this.listaHistoricoSla = getService().findSlaFilaByConfFila(configuracao);
		} catch (Exception ex) {
			logger.error(ex);
			error(ex);
		}
	}
	
	public void editarSla(SlaFila slaFila) {
		SlaFila slaFilaAlteracao = new SlaFila();
		
		try {
			slaFilaAlteracao.setConfiguracaoFila(slaFila.getConfiguracaoFila());
			slaFilaAlteracao.setDataFinal(null);
			slaFilaAlteracao.setDataInicial(new Date(System.currentTimeMillis()));
			slaFilaAlteracao.setDescricao(slaFila.getDescricao());
			slaFilaAlteracao.setSla(slaFila.getSla());
			
			getService().save(slaFilaAlteracao);
			
			visualizarHistoricoSla(slaFila.getConfiguracaoFila());
		} catch (Exception ex) {
			logger.error(ex);
			error("Erro ao editar sla");
			handlerException(ex);
		}
	}
    
    public List<SelectItem> getListFila() {
        return JSFUtil.toSelectItemConsulta(listFila);
    }

    public void setListFila(List<ConfiguracaoFila> listFila) {
        this.listFila = listFila;
    }
    public SlaFila getSlaFilaNova() {
        if(slaFilaNova == null) {
            return new SlaFila();
        }
        return slaFilaNova;
    }

    public void setSlaFilaNova(SlaFila slaFilaNova) {
        this.slaFilaNova = slaFilaNova;
    }
    
    /**
	 * @return the alterarCasosExistente
	 */
	public Boolean getAlterarCasosExistente() {
		return alterarCasosExistente;
	}

	/**
	 * @param alterarCasosExistente the alterarCasosExistente to set
	 */
	public void setAlterarCasosExistente(Boolean alterarCasosExistente) {
		this.alterarCasosExistente = alterarCasosExistente;
	}

	public List<SlaFila> getListaHistoricoSla() {
		return listaHistoricoSla;
	}

	public void setListaHistoricoSla(List<SlaFila> listaHistoricoSla) {
		this.listaHistoricoSla = listaHistoricoSla;
	}

	@Override
	public void novo() {
		setPojo(new SlaFila());
	}

	@Override
	protected ISlaFilaService getService() {
		return slaFilaService;
	}
}
