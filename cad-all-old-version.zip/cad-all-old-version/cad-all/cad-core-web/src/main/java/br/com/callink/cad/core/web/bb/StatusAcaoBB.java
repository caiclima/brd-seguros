/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.gbo.core.web.bb;

import br.com.callink.gbo.pojo.Acao;
import br.com.callink.gbo.pojo.Status;
import br.com.callink.gbo.pojo.StatusAcao;
import br.com.callink.gbo.service.IAcaoService;
import br.com.callink.gbo.service.IStatusService;
import br.com.callink.gbo.service.exception.ServiceException;
import br.com.callink.gbo.service.exception.ValidationException;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

/**
 *
 * @author Rogério Moreira de Andrade. [rogeriom@swb.com.br]
 */
@ManagedBean
@ViewScoped
public class StatusAcaoBB extends GboGenericCrud<Status, IStatusService> {

	private static final long serialVersionUID = 5670454269978023306L;
	
	private StatusAcao statusAcao;
    private List<StatusAcao> statusAcaoList;
    private List<Acao> listaAcao;
    private List<Status> listaStatus;
    
    @EJB
    private IStatusService statusService;
    @EJB
    private IAcaoService acaoService;

    @PostConstruct
    public void init() {
    	novo();
    }

    @Override
    public String salvar() {
        try {
        	getService().associa(statusAcao);
            filtrar();
        } catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException ex) {
			logger.error(ex);
            error(ex);
        }
        return null;
    }

    public void excluir(StatusAcao statusAcao) {
        try {
        	getService().excluiAssociacao(statusAcao);
            filtrar();
        } catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException ex) {
			logger.error(ex);
            error(ex);
        }
    }

    public void filtrarAcao() {
        try {
            Acao acao = statusAcao.getIdAcao();
            acao.setFlagAtivo(Boolean.TRUE);
            listaAcao = acaoService.findByExample(acao, "Acao.NOME");
        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }
    }

    public void filtrarStatus() {
        try {
            Status status = statusAcao.getIdStatus();
            status.setFlagAtivo(Boolean.TRUE);
            listaStatus = getService().findByExample(status, "Status.NOME");

        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }
    }

    @Override
    public void novo() {
        this.statusAcao = new StatusAcao(new Status(), new Acao());
        this.statusAcaoList = new ArrayList<StatusAcao>();
        this.listaAcao = new ArrayList<Acao>();
        this.listaStatus = new ArrayList<Status>();
        
        try {
			statusAcaoList = getService().findAllStatusAcao();
	    } catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException e) {
			logger.error(e);
			error(e);
        }
        
    }

    @Override
    public String filtrar() {
        try {
            Acao acao = statusAcao.getIdAcao();
            Status status = statusAcao.getIdStatus();
            boolean isAcao = acao != null && acao.getIdAcao() != null;
            boolean isStatus = status != null && status.getIdStatus() != null;

            if (isAcao && !isStatus) {
                statusAcaoList = getService().findByAcao(acao);
            } else if (!isAcao && isStatus) {
                statusAcaoList = getService().findByStatus(status);
            } else if (isAcao && isStatus) {
                statusAcaoList = getService().find(acao, status);
            } else {
                statusAcaoList = getService().findAllStatusAcao();
            }
        } catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException ex) {
			logger.error(ex);
            error(ex);
        }
        return null;

    }

    public void setAcao(Acao acao) {
        this.statusAcao.setIdAcao(acao);
    }

    public void setStatus(Status status) {
        this.statusAcao.setIdStatus(status);
    }

    public List<StatusAcao> getStatusAcaoList() {
        return statusAcaoList;
    }

    public void setStatusAcaoList(List<StatusAcao> statusAcaoList) {
        this.statusAcaoList = statusAcaoList;
    }

    public StatusAcao getStatusAcao() {
        return statusAcao;
    }

    public void setStatusAcao(StatusAcao statusAcao) {
        this.statusAcao = statusAcao;
    }

    public List<Acao> getListaAcao() {
        return listaAcao;
    }

    public void setListaAcao(List<Acao> listaAcao) {
        this.listaAcao = listaAcao;
    }

    public List<Status> getListaStatus() {
        return listaStatus;
    }

    public void setListaStatus(List<Status> listaStatus) {
        this.listaStatus = listaStatus;
    }

	@Override
	protected IStatusService getService() {
		return statusService;
	}
}
