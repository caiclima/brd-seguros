/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.gbo.core.web.bb;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import br.com.callink.gbo.pojo.Status;
import br.com.callink.gbo.service.IStatusService;
import br.com.callink.gbo.service.exception.ServiceException;

/**
 *
 * @author Rogerio
 */
@ManagedBean
@ViewScoped
public class StatusBB extends GboGenericCrud<Status, IStatusService> {

    private static final long serialVersionUID = 1L;
    @EJB
    private IStatusService statusService;
    
    @PostConstruct
    public void init() {
    	setPojo(new Status());
        atualiza();
    }
    
    @Override
    public String salvar() {
        getPojo().setLoginUsuario(getLoginUsuario());
        String ret = super.salvar();
        if (getPojo().getPK() != null) {
            atualiza();
        }
        return ret;
    }

    public String excluir(Status status) {
        try {
            getService().delete(status);
            atualiza();

        } catch (Exception ex) {
        	logger.error(ex);
            error(ex);
        }
        return null;
    }

    @Override
    public String filtrar() {
        try {
            setPojos(getService().findByExample(getPojo(), "Status.NOME"));
        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }
        return null;
    }

    @Override
    public void novo() {
        try {
        	setPojo(new Status());
            setPojos(getService().findByExample(getPojo(), "Status.NOME"));
        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }
    }

    public void alterar(Status status) {
        setPojo(status);
    }

    private void atualiza() {
        try {
            setPojos(getService().findByExample(getPojo(), "Status.NOME"));
            getPojo().setFlagAtivo(Boolean.TRUE);
        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }
    }

	@Override
	protected IStatusService getService() {
		return statusService;
	}
}
