package br.com.callink.gbo.core.web.bb;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import br.com.callink.gbo.pojo.TipoAcao;
import br.com.callink.gbo.service.ITipoAcaoService;
import br.com.callink.gbo.service.exception.ServiceException;
import br.com.callink.gbo.service.exception.ValidationException;

/**
 * 
 * @author brunomt [brunoam@swb.com.br]
 * 
 */
@ManagedBean
@ViewScoped
public class TipoAcaoBB  extends GboGenericCrud<TipoAcao, ITipoAcaoService> {
	
	private static final long serialVersionUID = 1L;
	@EJB
	private ITipoAcaoService tipoAcaoService;
	
	@PostConstruct
    public void init() {
		setPojo(new TipoAcao());
		getPojo().setFlagAtivo(Boolean.TRUE);
		filtrar();
    }
	
    @Override
    public String salvar() {
        String ret = super.salvar();
        if (getPojo().getIdTipoAcao()!= null) {
	        novo();
	        filtrar();
        }
        return ret;
    }
    
    @Override
    public String filtrar() {
        try {
            setPojos(getService().findByExample(getPojo(), "TipoAcao.NOME"));
        } catch (ServiceException e) {
        	logger.error(e);
            error(e);
        }
        return null;
    }
    
    @Override
    public void novo() {
        try {
        	setPojo(new TipoAcao());
            setPojos(getService().findByExample(getPojo(), "TipoAcao.NOME"));
        } catch (ServiceException e) {
        	logger.error(e);
            error(e);
        }
    }

    public void alterar(TipoAcao tipoAcao) {
    	setPojo(tipoAcao);
    }
    
    public String excluir(TipoAcao tipoAcao) {
    	try {
    		getService().inativar(tipoAcao);
		} catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException e) {
			logger.error(e);
			error(e);
		}
    	return null;
    }    
    
	public void findAll() {
		try {
			setPojos(getService().findByExample(null, "TipoAcao.NOME"));
		} catch (ServiceException ex) {
			logger.error(ex);
			error(ex);
		}
	}

	@Override
	protected ITipoAcaoService getService() {
		return tipoAcaoService;
	}
}
