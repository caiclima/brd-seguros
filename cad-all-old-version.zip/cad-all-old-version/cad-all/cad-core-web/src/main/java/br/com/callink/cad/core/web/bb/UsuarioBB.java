package br.com.callink.gbo.core.web.bb;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.servlet.http.HttpSession;

import br.com.callink.sso.authlib.ws.session.WsSsoSession;

/**
 *
 * @author brunomt
 */
@ManagedBean
@SessionScoped
public class UsuarioBB extends GenericCrud {
	
	private static final long serialVersionUID = 303728699810536485L;
	private transient WsSsoSession wsSsoSession;
    private transient  HttpSession session;
    
    public UsuarioBB() {
        session = (HttpSession) getFacesContext().getExternalContext()
				.getSession(false);
        wsSsoSession = (WsSsoSession) session.getAttribute("ssoSession");
    }
    
    public String getLogin() {
        return wsSsoSession.getUserInfo().getUserLogin();
    }
    
}
