package br.com.callink.gbo.core.web.bb.caso.acao;

import java.util.Map;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.apache.commons.lang.StringUtils;

import br.com.callink.gbo.core.web.bb.GboGenericCrud;
import br.com.callink.gbo.core.web.bb.IAtendenteCasoBB;
import br.com.callink.gbo.engine.command.ICommandScreen;
import br.com.callink.gbo.engine.command.executor.IExecutorCommandService;
import br.com.callink.gbo.pojo.Caso;
import br.com.callink.gbo.service.ICasoService;
import br.com.callink.gbo.service.exception.ServiceException;
import br.com.callink.gbo.service.exception.ValidationException;

@ManagedBean
@ViewScoped
public class CancelaCasoBB extends GboGenericCrud<Caso, ICasoService> implements ICommandScreen {

	private static final long serialVersionUID = 1654532044105070574L;
	private String observacao;

    @EJB
    private IExecutorCommandService executor;
	
	@Override
	public void execute() {
		try {
			if (validaSave()) {
                    	
                IAtendenteCasoBB atendenteCasoBB = (IAtendenteCasoBB) getSessionMap().get("atendenteCasoBB");
				Map<String, Object> parametros = atendenteCasoBB.getParamsGBO();
				parametros.put("observacao", getObservacao());
				parametros.put("grupoAnexo", getGrupoAnexo());
				executor.execute(parametros);
				atendenteCasoBB.atualizaLista();
				cleanData();
			}
		} catch (ValidationException e) {
        	error(e.getMessage());
		} catch (ServiceException ex) {
			logger.error(ex);
			error(ex);
		}
	}

	private boolean validaSave() {

		boolean valido = Boolean.TRUE;

		if (StringUtils.isBlank(getObservacao())) {
			error("Campo Observa\u00E7\u00E3o \u00E9 obrigat\u00F3rio.");
			valido = Boolean.FALSE;
		}
		return valido;
	}

	@Override
	public void cleanData() {
		this.setObservacao(null);
                limpaAnexos();
	}

	public void setObservacao(String observacao) {
		this.observacao = observacao;
	}

	public String getObservacao() {
		return observacao;
	}

	@Override
	public void novo() {
		
	}

	@Override
	protected ICasoService getService() {
		return null;
	}

}
