/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.gbo.core.web.bb.caso.acao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.apache.commons.lang.StringUtils;

import br.com.callink.gbo.core.web.bb.GboGenericCrud;
import br.com.callink.gbo.core.web.bb.IAtendenteCasoBB;
import br.com.callink.gbo.engine.command.ICommandScreen;
import br.com.callink.gbo.engine.command.executor.IExecutorCommandService;
import br.com.callink.gbo.pojo.Email;
import br.com.callink.gbo.pojo.GrupoEmail;
import br.com.callink.gbo.service.IAssociaGrupoEmailService;
import br.com.callink.gbo.service.IEmailService;
import br.com.callink.gbo.service.IGrupoEmailService;
import br.com.callink.gbo.service.exception.ServiceException;
import br.com.callink.gbo.service.exception.ValidationException;

/**
 *
 * @author Luiz Gustavo F. (luizgf@swb.com.br)
 */
@ManagedBean
@ViewScoped
public class EnviaEmailBB extends GboGenericCrud<Email, IEmailService> implements ICommandScreen {

    private static final long serialVersionUID = 1654532044105070574L;
    private String conteudo;
    private List<GrupoEmail> grupos;
    private GrupoEmail grupoEmail;
    private String destinatarios;
    /**Destinatarios incluidos manualmente na tela*/
    private String inclusaoDestinatarioManual;
    
    @EJB
    private IExecutorCommandService executor;
    @EJB
    private IGrupoEmailService grupoEmailService;
    @EJB
    private IAssociaGrupoEmailService associaGrupoEmailService;
    
    @PostConstruct
    public void init() {
    	conteudo = new String();
        grupos = null;
        grupoEmail = new GrupoEmail();
        destinatarios = new String();
    }
    
    private void carregaGrupos() {
        try {
            grupos = grupoEmailService.findAtivos("GrupoEmail.DESCRICAO");
        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }
    }

    
    @Override
    public void cleanData() {
        conteudo = null;
        if (grupos != null) {
            grupos.clear();
        }
        grupos = null;
        destinatarios = new String();
        inclusaoDestinatarioManual = new String();
    }

    @Override
    public void execute() {
        try {
            validaEmail();
            IAtendenteCasoBB atendenteCasoBB = (IAtendenteCasoBB) getSessionMap().get("atendenteCasoBB");
            Map<String, Object> parametros = atendenteCasoBB.getParamsGBO();
            Email email = new Email();
            email.setListaDestinatarios(getDestinatariosSelecionados());
            email.setDestinatarioParaExibicao(destinatarios);
            email.setConteudo(conteudo);
            email.setGrupoAnexo(getGrupoAnexo());
            
            //Verifica se foi incluido algum destinatario manualmente
            if(this.inclusaoDestinatarioManual != null && !this.inclusaoDestinatarioManual.equals("")) {
            	validaInclusaoDestinatarioManual();
            	
            	email.setDestinatario(this.inclusaoDestinatarioManual);
            }
            
            parametros.put("email", email);
            executor.execute(parametros);
            info("Email enviado. Acompanhe o andamento na aba de Emails.");
            atendenteCasoBB.atualizaLista();
            cleanData();
        } catch (ValidationException e) {
        	error(e.getMessage());
		} catch (ServiceException ex) {
			logger.error(ex);
            error(ex);
        }
    }

    private void validaEmail() throws ServiceException {
        if (StringUtils.isBlank(conteudo)) {
            throw new ServiceException("O conteudo do email deve ser preenchido.");
        }
        if (StringUtils.isBlank(destinatarios)) {
            throw new ServiceException("Nenhum destinatário foi selecionado.");
        }
    }
    
    /**
     * Verifica se os emails incluido manualmente como destinatários estão válidos
     * 
     * @throws ServiceException
     */
    private void validaInclusaoDestinatarioManual() throws ServiceException {
		Pattern p = Pattern.compile("^[_a-z0-9-]+(\\.[_a-z0-9-]+)*@[a-z0-9-]+(\\.[a-z0-9-]+)*(\\.[a-z]{2,4})$");
		this.inclusaoDestinatarioManual = this.inclusaoDestinatarioManual.replace(";", ",");
    	String[] destinatariosManual = this.inclusaoDestinatarioManual.split(",");
    	
    	//Verifica se o objeto destinatariosManual contem informação
    	if (destinatariosManual != null && destinatariosManual.length > 0) {
    		for (String destinatario : destinatariosManual) {
        		Matcher matcher = p.matcher(destinatario.toString().replace(" ", ""));
        		if (!matcher.matches()) {
        			throw new ServiceException("Email informado nos destinatários manual é inválido.");
        		}
    		}
    	}
    }

    public String getConteudo() {
        return conteudo;
    }

    public void setConteudo(String conteudo) {
        this.conteudo = conteudo;
    }

    
    public List<GrupoEmail> getGrupos() {
        if (grupos == null) {
            carregaGrupos();
        }
        return grupos;
    }

    public void atualizaDestinatarios() {
        try {
            destinatarios = associaGrupoEmailService.getDestinatariosFromListaGrupoEmail(getDestinatariosSelecionados(),Boolean.TRUE);
            //Verifica se foi adicionado algum destinatario de grupo
            if (this.destinatarios == null || "".equals(this.destinatarios)) {
            	this.destinatarios = this.inclusaoDestinatarioManual;
            } else {
            	this.destinatarios = this.destinatarios + ", " + this.inclusaoDestinatarioManual;
            }
        } catch (ValidationException e) {
        	error(e.getMessage());
		} catch (ServiceException ex) {
			logger.error(ex);
            error(ex);
        }
    }

    public GrupoEmail getGrupoEmail() {
        return grupoEmail;
    }

    public void setGrupoEmail(GrupoEmail grupoEmail) {
        this.grupoEmail = grupoEmail;
    }

    public String getDestinatarios() {
        return destinatarios;
    }

    public void setDestinatarios(String destinatarios) {
        this.destinatarios = destinatarios;
    }
    
    public List<GrupoEmail> getDestinatariosSelecionados() {
        List<GrupoEmail> ret = new ArrayList<GrupoEmail>();
        if (grupos == null || grupos.isEmpty()) {
            return ret;
        }
        for (GrupoEmail grupo : grupos) {
            if (grupo.getSelecionado() != null && grupo.getSelecionado()) {
                ret.add(grupo);
            }
        }
        return ret;
    }


	/**
	 * @return the inclusaoDestinatarioManual
	 */
	public String getInclusaoDestinatarioManual() {
		return inclusaoDestinatarioManual;
	}


	/**
	 * @param inclusaoDestinatarioManual the inclusaoDestinatarioManual to set
	 */
	public void setInclusaoDestinatarioManual(String inclusaoDestinatarioManual) {
		this.inclusaoDestinatarioManual = inclusaoDestinatarioManual;
	}


	@Override
	public void novo() {
		// TODO Auto-generated method stub
		
	}


	@Override
	protected IEmailService getService() {
		// TODO Auto-generated method stub
		return null;
	}
    
}
