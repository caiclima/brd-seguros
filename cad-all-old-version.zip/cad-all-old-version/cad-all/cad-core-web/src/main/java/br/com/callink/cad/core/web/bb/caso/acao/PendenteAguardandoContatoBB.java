package br.com.callink.gbo.core.web.bb.caso.acao;

import java.util.Map;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.apache.commons.lang.StringUtils;

import br.com.callink.gbo.core.web.bb.GboGenericCrud;
import br.com.callink.gbo.core.web.bb.IAtendenteCasoBB;
import br.com.callink.gbo.engine.command.ICommandScreen;
import br.com.callink.gbo.engine.command.executor.IExecutorCommandService;
import br.com.callink.gbo.pojo.Agendamento;
import br.com.callink.gbo.pojo.Caso;
import br.com.callink.gbo.service.ICasoService;
import br.com.callink.gbo.service.exception.ServiceException;
import br.com.callink.gbo.service.exception.ValidationException;

@ManagedBean
@ViewScoped
public class PendenteAguardandoContatoBB extends GboGenericCrud<Caso, ICasoService> implements
		ICommandScreen {

	private static final long serialVersionUID = 1654532044105070574L;
	private String observacao;
	private Agendamento agendamento;
	
	@EJB
	private IExecutorCommandService executor;

	@PostConstruct
    public void init() {
		cleanData();
	}

	public String getObservacao() {
		return observacao;
	}

	public void setObservacao(String observacao) {
		this.observacao = observacao;
	}

	@Override
	public void execute() {
		try {

			if (validaSave()) {
                            
                IAtendenteCasoBB atendenteCasoBB = (IAtendenteCasoBB) getSessionMap().get("atendenteCasoBB");
				Map<String, Object> parametros = atendenteCasoBB.getParamsGBO();

				parametros.put("observacao", getObservacao());
				getAgendamento().setDescricao(getObservacao());
				parametros.put("agendamento", getAgendamento());
				parametros.put("grupoAnexo", getGrupoAnexo());
				executor.execute(parametros);
				atendenteCasoBB.atualizaLista();

				cleanData();
			}
		} catch (ValidationException e) {
        	error(e.getMessage());
		} catch (ServiceException e) {
			logger.error(e);
			error(e);
		}
	}

	private boolean validaSave()  {

		boolean valido = Boolean.TRUE;
		
		try {

			if (StringUtils.isBlank(getObservacao())) {
				error("Campo Observa\u00E7\u00E3o \u00E9 obrigat\u00F3rio.");
				valido = Boolean.FALSE;
			}
			if (getAgendamento() == null || getAgendamento().getDataAgendamento() == null) {
				error("Campo Agendamento \u00E9 obrigat\u00F3rio.");
				valido = Boolean.FALSE;
			}
			
			if (agendamento.getDataAgendamento().getTime() < getService().getDataBanco()
					.getTime()) {
				error("Data do agendamento deve ser maior do que a data Atual.");
				valido = Boolean.FALSE;
			}
			
		} catch (ServiceException e) {
			logger.error(e);
			error("Erro ao buscar datas.");
		}
		return valido;
	}

	@Override
	public void cleanData() {
		this.observacao = null;
		this.agendamento = new Agendamento();
                limpaAnexos();
	}

	public Agendamento getAgendamento() {
		return agendamento;
	}

	public void setAgendamento(Agendamento agendamento) {
		this.agendamento = agendamento;
	}

	@Override
	public void novo() {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected ICasoService getService() {
		// TODO Auto-generated method stub
		return null;
	}
}
