/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.gbo.core.web.bb.caso.acao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import br.com.callink.gbo.core.web.bb.GboGenericCrud;
import br.com.callink.gbo.core.web.bb.IAtendenteCasoBB;
import br.com.callink.gbo.engine.command.executor.IExecutorCommandService;
import br.com.callink.gbo.pojo.Acao;
import br.com.callink.gbo.pojo.Email;
import br.com.callink.gbo.pojo.GrupoEmail;
import br.com.callink.gbo.service.IAcaoService;
import br.com.callink.gbo.service.IAssociaGrupoEmailService;
import br.com.callink.gbo.service.IEmailService;
import br.com.callink.gbo.service.IGrupoEmailService;
import br.com.callink.gbo.service.exception.ServiceException;
import br.com.callink.gbo.service.exception.ValidationException;
import br.com.callink.gbo.util.Constantes;
import br.com.callink.gbo.util.EmailUtils;
import br.com.callink.gbo.util.PropertieUtils;

/**
 *
 * @author Luiz Gustavo F. (luizgf@swb.com.br)
 */
@ManagedBean
@ViewScoped
public class RespondeEmailBB extends GboGenericCrud<Email, IEmailService> {

	private static final long serialVersionUID = 4206828278334943465L;
	
	private String conteudo;
    private Email pai;
    private List<GrupoEmail> destinatariosAdicionais;
    private String destinatariosAdicionaisExibicao;
    
    @EJB
    private IExecutorCommandService executorCommandService;
    @EJB
    private IAssociaGrupoEmailService associaGrupoEmailService;
    @EJB
    private IGrupoEmailService grupoEmailService;
    @EJB
    private IAcaoService acaoService;

    @PostConstruct
    public void init() {
    	conteudo = "";
        pai = new Email();
        destinatariosAdicionais = new ArrayList<GrupoEmail>();
        destinatariosAdicionaisExibicao = "";
    }

    public void responderEmail(Email email) {
        this.pai = email;
        this.conteudo = EmailUtils.anexaHistoricoEmail(email);
        try {
            destinatariosAdicionais = grupoEmailService.findAtivos("descricao");
        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }
    }

    public void cleanData() {
        conteudo = "";
        pai = new Email();
        destinatariosAdicionais = new ArrayList<GrupoEmail>();
        destinatariosAdicionaisExibicao = "";
    }

    public void responder() {
        try {
            IAtendenteCasoBB atendenteCasoBB = (IAtendenteCasoBB) getSessionMap().get("atendenteCasoBB");
            String nomeAcaoResponder = PropertieUtils.getPropertieByArquivoAndChave(
            Constantes.CAMINHO_ARQUIVO_PROPERTIES_CONFIGURACAO_TELA,
            Constantes.NOME_ARQUIVO_PROPERTIE,
            Constantes.CHAVE_NOME_ACAO_ENVIAR_EMAIL);
            Acao acao = new Acao();
            acao.setNome(nomeAcaoResponder);
            acao = acaoService.findByNome(acao);
            if (acao == null) {
                error("Erro : N\u00E3o foi poss\u00EDvel responder o email, pois n\u00E3o foi encontrado uma A\u00E7\u00E3o correspondente.");
                return;
            }


            Map<String, Object> parametros = new HashMap<String, Object>();
            parametros.put("caso", atendenteCasoBB.getCaso());
            parametros.put("acao", acao);

            Email email = new Email();
            email.setConteudo(conteudo);
            email.setGrupoAnexo(getGrupoAnexo());
            email.setDestinatario(pai.getRemetente());
            email.setDestinatarioParaExibicao(pai.getRemetente() + Constantes.ESPACO + destinatariosAdicionaisExibicao);
            email.setPai(pai);

            List<GrupoEmail> destinatariosSelecionados = getDestinatariosSelecionados();

            if (!destinatariosSelecionados.isEmpty()) {
                email.setListaDestinatarios(destinatariosSelecionados);
            }

            parametros.put("email", email);

            executorCommandService.execute(parametros);
            info("Email respondido com sucesso.");

        } catch (ValidationException e) {
        	error(e.getMessage());
		} catch (ServiceException ex) {
			logger.error(ex);
            error(ex);
        }
    }

    public String getConteudo() {
        return conteudo;
    }

    public void setConteudo(String conteudo) {
        this.conteudo = conteudo;
    }

    public Email getPai() {
        return pai;
    }

    public void setPai(Email pai) {
        this.pai = pai;
    }

    public List<GrupoEmail> getDestinatariosAdicionais() {
        return destinatariosAdicionais;
    }

    public void setDestinatariosAdicionais(List<GrupoEmail> destinatariosAdicionais) {
        this.destinatariosAdicionais = destinatariosAdicionais;
    }

    public List<GrupoEmail> getDestinatariosSelecionados() {
        List<GrupoEmail> ret = new ArrayList<GrupoEmail>();
        if (destinatariosAdicionais == null || destinatariosAdicionais.isEmpty()) {
            return ret;
        }
        for (GrupoEmail grupo : destinatariosAdicionais) {
            if (grupo.getSelecionado() != null && grupo.getSelecionado()) {
                ret.add(grupo);
            }
        }
        return ret;
    }

    public void atualizaDestinatarios() {
        try {
            destinatariosAdicionaisExibicao = associaGrupoEmailService.getDestinatariosFromListaGrupoEmail(getDestinatariosSelecionados(), Boolean.TRUE);
        } catch (ValidationException e) {
        	error(e.getMessage());
		} catch (ServiceException ex) {
			logger.error(ex);
            error(ex);
        }
    }

    public String getDestinatariosAdicionaisExibicao() {
        return destinatariosAdicionaisExibicao;
    }

    public void setDestinatariosAdicionaisExibicao(String destinatariosAdicionaisExibicao) {
        this.destinatariosAdicionaisExibicao = destinatariosAdicionaisExibicao;
    }

	@Override
	public void novo() {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected IEmailService getService() {
		// TODO Auto-generated method stub
		return null;
	}
}
