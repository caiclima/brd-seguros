package br.com.callink.gbo.core.web.bb.converter;

import java.util.Map;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

/**
 *
 * Classe DefaultConverter
 *
 * @author Felipe A. Braga<br> felipea@swb.com.br<br> SWB Soluções Integradas -
 * www.swb.com.br<br> 06/09/2012
 */
@FacesConverter(value = "defaultConverter")
public class DefaultConverter implements Converter {

    @Override
    public Object getAsObject(FacesContext context, UIComponent component, String value) {
        if (value != null) {
            Map<String, Object> map = component.getAttributes();
            return map.get(value);
        }
        return null;
    }

    @Override
    public String getAsString(FacesContext context, UIComponent component, Object value) {
        if (value != null) {
            component.getAttributes().put(value.toString(), value);
            return value.toString();
        }
        return null;
    }
}
