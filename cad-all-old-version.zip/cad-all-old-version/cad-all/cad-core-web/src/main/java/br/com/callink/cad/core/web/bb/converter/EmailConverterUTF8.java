/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.gbo.core.web.bb.converter;

import java.io.UnsupportedEncodingException;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

/**
 *
 * @author brunomt
 */
@FacesConverter(value="emailConverterUTF8")
public class EmailConverterUTF8 implements Converter {

    @Override
    public Object getAsObject(FacesContext fc, UIComponent uic, String string) {
        return string;
    }

    @Override
    public String getAsString(FacesContext fc, UIComponent uic, Object o) {
        try {
            return new String(o.toString().getBytes("UTF-8"), "UTF-8");
        } catch (UnsupportedEncodingException ex) {
            return o.toString();
        }
    }
    
}
