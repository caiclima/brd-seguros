package br.com.callink.gbo.core.web.bb.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import br.com.callink.gbo.util.StringHelper;

@FacesConverter(value = "StringConverter")
public class StringConverter implements Converter {

	public Object getAsObject(FacesContext facesContext, UIComponent uiComponent, String string) {
		if (StringHelper.isNullOrEmpty(string)) {
			return null;
		} else {
			return string.replace("'", "").replace("\"", "");
		}
	}

	public String getAsString(FacesContext facesContext, UIComponent uiComponent, Object string) {
		if (string == null) {
			return null;
		} else {
			return string.toString().replace("'", "").replace("\"", "").trim();
		}
	}
}
