package br.com.callink.gbo.core.web.bb.util;

import java.util.ArrayList;
import java.util.List;

import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

public final class JSFUtil {

	private JSFUtil() {}
	
	public static FacesContext getFacesContext() {
		return FacesContext.getCurrentInstance();
	}

	public static HttpSession getSession(){
		return (HttpSession) getFacesContext().getExternalContext().getSession(false);
	}
	
	public static HttpServletRequest getRequest(){
		return (HttpServletRequest) getFacesContext().getExternalContext().getRequest();
	}
	
	public static ServletContext getServletContext(){
		return (ServletContext) getFacesContext().getExternalContext().getContext();
	}
	
	@SuppressWarnings("rawtypes")
	public static List<SelectItem> toSelectItem(final List itens) {
		List<SelectItem> retorno = new ArrayList<SelectItem>();
		if (itens != null) {
			for (Object item: itens) {
				SelectItem selectItem = new SelectItem(item, item.toString());
				retorno.add(selectItem);
			}
		}
		return retorno;
	}
	
	@SuppressWarnings("rawtypes")
	public static List<SelectItem> toSelectItemConsulta(final List itens) {
		List<SelectItem> retorno = new ArrayList<SelectItem>();
		if (itens != null) {
			retorno.add(new SelectItem(null, ""));
			for (Object item: itens) {
				SelectItem selectItem = new SelectItem(item, item.toString());
				retorno.add(selectItem);
			}
		}
		return retorno;
	}
	
	
}
