
/**
 * Esta deve ser invocada apos o show() em um popup, 
 * devido a um bug sombra abaixo do popup no internet explorer 7
 */
function fixModalCss() {
	var divModalToFixCss = jQuery('div.rf-pp-cntr');

	if (divModalToFixCss != null) {
		divModalToFixCss.removeClass('div.rf-pp-cntr');
	}
}