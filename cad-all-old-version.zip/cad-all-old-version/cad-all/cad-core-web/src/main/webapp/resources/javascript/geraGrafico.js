function geraGrafico(data,divPrint) {
	var dataVar = data.value.split(';');
	var arrayGrafico = new Array();
	var arrayData = new Array();
	var i;

	for (i = 0; i < dataVar.length; i++) {
		var arrayVar = dataVar[i].split(',');
		arrayData[i] = new Array(2);
		arrayData[i][0] = arrayVar[0];
		arrayData[i][1] = parseInt(arrayVar[1]);
	}
	var plot1 = jQuery.jqplot(divPrint, [ arrayData ], {
		seriesDefaults : {
			// Make this a pie chart.
			renderer : jQuery.jqplot.PieRenderer,
			rendererOptions : {
				// Put data labels on the pie slices.
				// By default, labels show the percentage of the slice.
				showDataLabels : true
			}
		},
		legend : {
			show : true,
			location : 'e'
		}
	});
};

function geraGraficoCorIgual(data,cor,divPrint) {
	var dataVar = data.value.split(';');
        var corSplit = cor.value.split(';');
	var arrayData = new Array();
	var i;

	for (i = 0; i < dataVar.length; i++) {
		var arrayVar = dataVar[i].split(',');
		arrayData[i] = new Array(2);
		arrayData[i][0] = arrayVar[0];
		arrayData[i][1] = parseInt(arrayVar[1]);
	}
        if (corSplit != "") {
	var plot1 = jQuery.jqplot(divPrint, [ arrayData ], {
            seriesColors: corSplit,
    
		seriesDefaults : {
			// Make this a pie chart.
			renderer : jQuery.jqplot.PieRenderer,
			rendererOptions : {
				// Put data labels on the pie slices.
				// By default, labels show the percentage of the slice.
				showDataLabels : true
			}
		},
		legend : {
			show : true,
			location : 'e'
		}
	});
        }
};