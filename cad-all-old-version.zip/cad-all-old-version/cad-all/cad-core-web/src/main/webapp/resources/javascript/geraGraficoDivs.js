function geraGraficoDivs(divs, data) {
    var divsSplit = divs.value.split(';');
    var valoresDivsSplit = data.value.split('#');
    
    var i;
    for (i = 0 ; i < divsSplit.length; i++) {
        var dataVar = valoresDivsSplit[i].split(';');
        var arrayData = new Array();
        var j;
        
        for (j = 0; j < dataVar.length; j++) {
		var arrayVar = dataVar[j].split(',');
		arrayData[j] = new Array(2);
		arrayData[j][0] = arrayVar[0];
		arrayData[j][1] = parseInt(arrayVar[1]);
	}
        
        var plot1 = jQuery.jqplot(divsSplit[i], [ arrayData ], {
		seriesDefaults : {
			// Make this a pie chart.
			renderer : jQuery.jqplot.PieRenderer,
			rendererOptions : {
				// Put data labels on the pie slices.
				// By default, labels show the percentage of the slice.
				showDataLabels : true
			}
		},
		legend : {
			show : true,
			location : 'e'
		}
	});
        
    }
};