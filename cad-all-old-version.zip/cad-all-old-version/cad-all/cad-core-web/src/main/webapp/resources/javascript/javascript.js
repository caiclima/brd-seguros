function getBody(){
    return document.body;
}

function getObjectById(objectId){
    return document.getElementById(objectId);
}

function showObject(objectId){
    getObjectById(objectId).style.display = 'block';
}

function hideObject(objectId){
    getObjectById(objectId).style.display = 'none';
}

function showHideObject(objectId){
    if(getObjectById(objectId).style.display == 'block'){
        hideObject(objectId)
    }else{
        showObject(objectId)
    }
}

function createObject(objectType){
    return document.createElement(objectType);
}

function existObject(objectId){
    if(getObjectById(objectId) == null){
        return false;
    }else{
        return true;
    }
}

var moveLeftSize = 0;
var moveTopSize  = 0;
function moveObject(evt,objectId){
    if(evt.clientX - moveLeftSize > 0){		
        getObjectById(objectId).style.left = eval(evt.clientX - moveLeftSize)+'px';
    }

    if(evt.clientY - moveTopSize > 0){
        getObjectById(objectId).style.top = eval(evt.clientY - moveTopSize)+'px';
    }
}

function deactivateMoveObject(){
    getBody().setAttribute('onmousemove',null);
    getBody().setAttribute('onmouseup',null);
}

function activeMoveObject(evt,objectId){   	
    getBody().setAttribute('onmousemove','moveObject(event,"'+objectId+'")');
    getBody().setAttribute('onmouseup','deactivateMoveObject()');

    moveLeftSize = eval(evt.clientX - getDimessionObject(objectId).left);
    moveTopSize  = eval(evt.clientY - getDimessionObject(objectId).top);
}

function getDimessionObject(objectId){
    return {
        left   : getObjectById(objectId).offsetLeft, 
        top    : getObjectById(objectId).offsetTop,
        width  : getObjectById(objectId).offsetWidth,
        height : getObjectById(objectId).offsetHeight
    }
}

function debug(msg){
    if(!existObject(MASK.id)){
        var debug = createObject('DIV');
        debug.setAttribute('id','debug');
        getBody().appendChild(debug);
        showObject('debug');
    }

    getObjectById('debug').innerHTML += msg + '<br>';
}

var PANEL_WINDOW = {
    show : function(windowId){
        MASK.show(windowId);
        showObject(windowId);
		
        with(getObjectById(windowId).style){
            left = ((MASK.width(windowId)  - getDimessionObject(windowId).width  ) / 2)+'px';
            top  = ((MASK.height(windowId) - getDimessionObject(windowId).height ) / 2)+'px';
            }
    },
    hide : function(windowId){	
        hideObject(windowId);
        MASK.hide(windowId);
    },
    move : function(evt,windowId){
        activeMoveObject(evt,windowId);
    }
}

var MASK = {
    id   : 'divMask',
    show : function(objectLinked){
        if(!existObject(MASK.id + objectLinked)){
            var divMask = createObject('DIV');
            divMask.setAttribute('id',MASK.id + objectLinked);
            divMask.setAttribute('class','mask');	
            getBody().appendChild(divMask);
        }
        showObject(MASK.id + objectLinked);
        
        with(getObjectById(MASK.id + objectLinked).style){
            position        =   'absolute';
            top             =   '0%';
            left            =   '0%';
            width           =   '100%';
            height          =   '100%';
            backgroundColor =   '#EFEFEF';
            opacity         =   '0.4';
            filter          =   'alpha(opacity=40)';
            zIndex          =   '999';
        }
    },
    hide : function(objectLinked){
        hideObject(MASK.id + objectLinked);
    },
    height : function(objectLinked){
        return getDimessionObject(MASK.id + objectLinked).height;
    },
    width : function(objectLinked){
        return getDimessionObject(MASK.id + objectLinked).width;
    }
}

function callback(objectCallback){

    if(objectCallback != null){

        if(objectCallback[1] != null){
            alert(objectCallback[1]);
        }

        if(objectCallback[0] != null && objectCallback[0] == true){
            window.opener.closePopup();
            window.close();
            window.close();
        }
    }
}


function Limpar(valor) {
    var result = "";
    var aux;
    for (var i=0; i < valor.length; i++) {
        aux = "0123456789".indexOf(valor.substring(i, i+1));
        if (aux>=0) {
            result += aux;
        }
    }
    return result;
}

function format(object, mask){
   
    //DEFINE MAXLENGTH
    object.setAttribute('maxlength',mask.length);

    //RECUPERA VALOR DO CAMPO REMOVENDO CARACTERES DIFERENTE DE [0123456789]
    valueFormat = object.value.replace(/\D/gi,'');

    //FORMATA
    for (index = 0; index < mask.length; index++) {
        if (index < valueFormat.length) {
            if (mask.charAt(index) != '#' && mask.charAt(index) != valueFormat.charAt(index)) {
                valueFormat = valueFormat.substring(0,index) + mask.charAt(index) + valueFormat.substring(index,valueFormat.length);
            }
        }else{
            //EVITAR PROCESSAMENTO DESNECESSÁRIO
            break;
        }
    }

    //FAZ COM QUE O RECEBA UM VALOR DE ACORDO COM O TAMANHO DA MASCARA
    if(valueFormat.length > mask.length){
        valueFormat = valueFormat.substring(0,mask.length);
    }   
    object.value = valueFormat;

    //SETA CURSOR DO MOUSE SEMPRE NO FIM DO CAMPO
    object.selectionStart = object.value.length;
    object.selectionEnd = object.value.length;
}

function formatCpf(src){
    format(src, '###.###.###-##');
}

function formatCnpj(src){
    format(src, '##.###.###/####-##');
}

function formatCep(src){
    format(src, '##.###-###');
}

function formatDate(src){
    format(src, '##/##/####');
}

function formatTelefone(src){
    format(src, '(##) ####-####');
}