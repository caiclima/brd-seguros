var segundos = 0;
var minutos = 0;
var horas = 0;
var functionRecalcularTempoTelaAberta;
var idCampoMostraTempoTelaAberta = null;
var idPanelGroupTempoTelaAberta = null;

function getTempoTelaAbertaFormatado() {
	return (horas < 10 ? ('0' + horas) : horas) + ':'
			+ (minutos < 10 ? ('0' + minutos) : minutos) + ':'
			+ (segundos < 10 ? ('0' + segundos) : segundos);
}

// recalcula tempo tela aberta e mostra
function recalcularTempoTelaAberta() {
	document.getElementById(idCampoMostraTempoTelaAberta).innerHTML = getTempoTelaAbertaFormatado();

	if (segundos < 59) {
		segundos++;
	} else {
		segundos = 0;

		if (minutos < 59) {
			minutos++;
		} else {
			minutos = 0;
			horas = horas < 24 ? (horas + 1) : 0;
		}
	}

	functionRecalcularTempoTelaAberta = setTimeout(
			"recalcularTempoTelaAberta()", 1000);
}

function pararMostrarTempoTelaAberta() {
	if (functionRecalcularTempoTelaAberta != null) {
		clearTimeout(functionRecalcularTempoTelaAberta);
	}

	try {
		document.getElementById(idCampoMostraTempoTelaAberta).innerHTML = '';
	} catch (exIgnored) {
	}

	try {
		document.getElementById(idPanelGroupTempoTelaAberta).style.visibility = 'hidden';
	} catch (exIgnored) {
	}

	horas = 0;
	minutos = 0;
	segundos = 0;
}

function mostrarTempoTelaAberta(idCmpMostraTempoTelaAberta,
		idPnlGroupTempoTelaAberta) {
	idCampoMostraTempoTelaAberta = idCmpMostraTempoTelaAberta;
	idPanelGroupTempoTelaAberta = idPnlGroupTempoTelaAberta;

	pararMostrarTempoTelaAberta();

	try {
		document.getElementById(idPanelGroupTempoTelaAberta).style.visibility = 'visible';
	} catch (exIgnored) {
	}

	recalcularTempoTelaAberta();
}
