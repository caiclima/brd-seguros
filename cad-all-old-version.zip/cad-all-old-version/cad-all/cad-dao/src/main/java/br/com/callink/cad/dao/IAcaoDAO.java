/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.dao;

import java.util.List;

import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.pojo.AcaoComando;
import br.com.callink.cad.pojo.Comando;
import br.com.callink.cad.sau.exception.DataException;

/**
 * 
 * @author Rogério Moreira de Andrade. [rogeriom@swb.com.br]
 */
public interface IAcaoDAO extends IGenericCadDAO<Acao>{

	void associa(AcaoComando acaoComando) throws DataException;

	void associa(List<AcaoComando> acaoComando) throws DataException;

	void excluiAssociacao(AcaoComando acaoComando) throws DataException;

	List<AcaoComando> findByComando(Comando comando) throws DataException;

	List<AcaoComando> findByAcao(Acao acao) throws DataException;

	List<AcaoComando> find(Acao acao, Comando comando) throws DataException;

	List<AcaoComando> findAllAcaoComando() throws DataException;

	List<AcaoComando> findAllAcaoComandoAtivos() throws DataException;

	List<AcaoComando> findByAcaoAcaoComandoAtivos(Acao acao) throws DataException;

	List<AcaoComando> findAcaoComando(Acao acao, Comando comando) throws DataException;

	/**
	 * Retorna uma Acao pelo nome
	 * @param acao
	 * @return Acao
	 * @throws DataException
	 */
	Acao findByNome(Acao acao) throws DataException;
	
	List<Acao> findByExample(Acao example, String order) throws DataException;
	
}
