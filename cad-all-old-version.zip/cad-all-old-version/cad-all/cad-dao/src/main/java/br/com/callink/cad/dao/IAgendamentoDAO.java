package br.com.callink.cad.dao;

import java.util.List;

import br.com.callink.cad.pojo.Agendamento;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.sau.exception.DataException;

/**
 *
 * @author Rogério Moreira de Andrade. [rogeriom@swb.com.br]
 */
public interface IAgendamentoDAO extends IGenericCadDAO<Agendamento>{

	/**
	 * Busca um List de Agendamento pelo {@link Caso}
	 * @param caso
	 * @return List<Agendamento> 
	 * @throws DataException
	 */
	List<Agendamento> buscaPeloCaso(Caso caso) throws DataException;

	/**
	 * Busca um List de Agendamento ativos pelo {@link Caso} 
	 * @param caso
	 * @return List<Agendamento>
	 * @throws DataException
	 */
	List<Agendamento> buscaAtivosPeloCaso(Caso caso) throws DataException;
	
}
