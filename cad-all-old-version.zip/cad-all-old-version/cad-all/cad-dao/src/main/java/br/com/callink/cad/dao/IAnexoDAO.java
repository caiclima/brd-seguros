package br.com.callink.cad.dao;

import java.util.List;

import br.com.callink.cad.pojo.Anexo;
import br.com.callink.cad.pojo.GrupoAnexo;
import br.com.callink.cad.sau.exception.DataException;

/**
 * 
 * @author Ednaldo Caic [ednaldo@swb.com.br]
 */
public interface IAnexoDAO extends IGenericCadDAO<Anexo> {
    
    List<Anexo> buscaPorGrupoAnexo(GrupoAnexo grupoAnexo) throws DataException;

}
