/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.dao;

import java.util.List;

import br.com.callink.cad.pojo.AssociaGrupoEmail;
import br.com.callink.cad.pojo.EnderecoEmail;
import br.com.callink.cad.pojo.GrupoEmail;
import br.com.callink.cad.sau.exception.DataException;

/**
 *
 * @author Luiz Gustavo (luizgf@swb.com.br)
 */
public interface IAssociaGrupoEmailDAO extends IGenericCadDAO<AssociaGrupoEmail>{
    
    /**
     * 
     * @param grupoEmail
     * @param enderecoEmail
     * @return
     * @throws DataException 
     */
    List<AssociaGrupoEmail> findByGrupoEmailEnderecoEmail(GrupoEmail grupoEmail,EnderecoEmail enderecoEmail) throws DataException;
    
    /**
     * 
     * @param grupoEmail
     * @throws DataException 
     */
    void deletaAssociacoes(GrupoEmail grupoEmail) throws DataException;
    
    List<AssociaGrupoEmail> findByExample(AssociaGrupoEmail example, String order) throws DataException;
    
}
