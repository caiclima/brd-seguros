/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.dao;

import java.util.List;

import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.pojo.Equipe;
import br.com.callink.cad.sau.exception.DataException;

/**
 *
 * @author Rogério Moreira de Andrade. [rogeriom@swb.com.br]
 */
public interface IAtendenteDAO extends IGenericCadDAO<Atendente>{

	/**
	 * Retorna o Atendente pelo login
	 * @param login
	 * @return
	 * @throws DataException
	 */
	Atendente findByLogin(String login) throws DataException;

	/**
	 * Retorna um List de Atendente pela {@link configuracaoFila}
	 * @param configuracaoFila
	 * @return List<Atendente>
	 * @throws DataException
	 */
	List<Atendente> buscaPorFila(ConfiguracaoFila configuracaoFila) throws DataException;

	/**
	 * Retorna todos os atendentes ativos que nao estao associados a equipe
	 * @return List<Atendente>
	 * @throws DataException
	 */
	List<Atendente> buscaAtivosQueNaoPossuemFila() throws DataException;
        
	/**
	 * Retorna o Supervisor do Atendente passado pelo parametro;
         * 
	 * @param Atendente
         * @param idPerfilSupervisor
	 * @return Atendente
	 * @throws DataException
	 */
        Atendente findSupervisor(Atendente atendente, Integer idPerfilSupervisor) throws DataException;
        
        /**
         * Retorna todos os atendentes vinculados a uma fila
         * @param configuracaoFilaList
         * @return
         * @throws DataException 
         */
        List<Atendente> buscaPorConfiguracaoFilaList(List<ConfiguracaoFila> configuracaoFilaList) throws DataException ;
        
        /**
         * Retorna todos os Atendentes vinculados a @link{equipeList}
         * @param equipeList
         * @return
         * @throws DataException 
         */
        List<Atendente> buscaPorEquipeList(List<Equipe> equipeList) throws DataException ;

        /**
         * 
         * @param equipe
         * @return
         * @throws DataException
         */
		List<Atendente> buscaAtendentesPorEquipe(Equipe equipe)
				throws DataException;
		
		List<Atendente> findAll(String order) throws DataException;

		/**
		 * @param idsAtendentes
		 * @return
		 * @throws DataException
		 */
		List<Atendente> findByPkIn(List<Integer> idsAtendentes) throws DataException;
		
}
