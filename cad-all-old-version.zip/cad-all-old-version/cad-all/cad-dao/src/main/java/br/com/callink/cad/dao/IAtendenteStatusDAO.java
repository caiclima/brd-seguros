package br.com.callink.cad.dao;

import java.util.List;

import br.com.callink.cad.pojo.AtendenteStatus;
import br.com.callink.cad.sau.exception.DataException;

/**
 * 
 * @author Bruno Alves [brunoam@swb.com.br]
 */
public interface IAtendenteStatusDAO extends IGenericCadDAO<AtendenteStatus>{

    /**
     * 
     * @return
     * @throws DataException 
     */
    List<AtendenteStatus> buscaAtendenteStatusPausado() throws DataException;

    /**
     * Busca o atendenteStatus pelo id Toolbar
     * @param idStatusToolbar
     * @return
     * @throws DataException
     */
	List<AtendenteStatus> buscaAtendenteStatusIdToolbar(Integer idStatusToolbar) throws DataException;
	
	List<AtendenteStatus> findByExample(AtendenteStatus example, String order) throws DataException;
	
}
