/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.dao;

import java.util.List;

import br.com.callink.cad.pojo.AtendimentoCaso;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.sau.exception.DataException;

/**
 *
 * @author Rogério Moreira de Andrade. [rogeriom@swb.com.br]
 */
public interface IAtendimentoCasoDAO extends IGenericCadDAO<AtendimentoCaso>{

	/**
	 * Busca todos os AtendimentoCaso pelo Caso
	 * @param caso
	 * @return List<AtendimentoCaso>
	 * @throws DataException 
	 */
	List<AtendimentoCaso> findAtendimentoCasoByCaso(Caso caso) throws DataException;

	/**
	 * Busca a última marcação do caso.
	 * @param atendimentoCaso
	 * @return
	 * @throws DataException
	 */
	Integer findUltimaMarcacaoCaso(AtendimentoCaso atendimentoCaso) throws DataException;
	
}
