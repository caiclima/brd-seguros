/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.dao;

import java.util.List;

import br.com.callink.cad.pojo.CabUph;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.sau.exception.DataException;

/**
 *
 * @author swb.miller
 */
public interface ICabUphDAO extends IGenericCadDAO<CabUph>{
    
    /**
     * busca lista de metas de acordo com uma fila 
     */
    List<CabUph> findLlistByConfFila(ConfiguracaoFila fila) throws DataException;
    

    
    /**
     * 
     * @param fila
     * @return
     * @throws DataException
     */
	CabUph findUltimaMetaConfigura(ConfiguracaoFila fila) throws DataException;

	/**
	 * 
	 * @param descricao
	 * @param fila
	 * @param meta
	 * @return
	 * @throws DataException
	 */
	List<CabUph> findCabUphList(String descricao, ConfiguracaoFila fila,
			Double meta) throws DataException;
	
}
