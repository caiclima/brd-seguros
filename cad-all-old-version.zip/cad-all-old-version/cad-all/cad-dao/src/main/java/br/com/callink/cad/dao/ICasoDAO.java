package br.com.callink.cad.dao;

import java.util.Date;
import java.util.List;

import javax.xml.rpc.ServiceException;

import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.pojo.Status;
import br.com.callink.cad.repository.to.AtendenteCasoStatusTO;
import br.com.callink.cad.sau.exception.DataException;

/**
 * 
 * @author brunomt [brunoam@swb.com.br]
 *
 */
public interface ICasoDAO extends IGenericCadDAO<Caso>{
	
	void flush();

	/**
	 * Busca todos os Caso ativos 
	 * @return
	 * @throws DataException
	 */
	List<Caso> findCasoAtivos() throws DataException;
	
	/**
	 * Busca todos os casos que estejam nos filtros e ordenados pelo cadastro da fila.
	 * 
	 * @param fromCaso (será o from da consulta)
	 * @param sqlWhere (será o where da consulta)
	 * @return
	 * @throws DataException
	 */
	List<Caso> buscaCasosFiltroPorFilaSemAtendente(String fromCaso, String sqlWhere) throws DataException;
	
	/**
	 * Busca todos os casos que estejam nos filtros e ordenados pelo cadastro da fila. Com parametro de TOP
	 * 
	 * 
	 * @param fromCaso (será o from da consulta)
	 * @param sqlWhere (será o where da consulta)
	 * @return
	 * @throws DataException
	 */
	List<Caso> buscaCasosFiltroPorFilaSemAtendente(String fromCaso, String sqlWhere, Integer top) throws DataException;
	
	/**
	 * Busca os casos ordenados pela fila
	 * 
	 * @param casoTabela
	 * @param confFila
	 * @param quantidadeCasos
	 * @param sqlOrder (será o order da consulta)
	 * @return
	 * @throws DataException
	 */
	List<Caso> buscaCasosOrdernadosPorFilaSemAtendente(String casoTabela, String sqlOrder, ConfiguracaoFila confFila, Integer quantidadeCasos) throws DataException;
	
	
	
	/**
	 * Busca todos os casos ativos de um atendente.
	 * @param atendente
	 * @return
	 * @throws DataException
	 */
	List<Caso> buscaTodosCasosAtivosAtendente(Atendente atendente) throws DataException;
	
	/**
	 * Retira a fila de todos os casos que não estão em atendimento, ou seja, que não tem nenhum atendente vinculado
	 * @param configuracaoFila
	 * @throws DataException
	 */
	void retiraFilaCaso(ConfiguracaoFila configuracaoFila) throws DataException;

	/**
	 * Busca todos os cados ativos pela {@link ConfiguracaoFila}
	 * @param configuracaoFila
	 * @return List<Caso>
	 * @throws DataException
	 */
	List<Caso> buscaCasosAtivosPorConfiguracaoFila(ConfiguracaoFila configuracaoFila) throws DataException;
	
	/**
	 * Busca todos os casos agendados ordenados por data.
	 * @param atendente
	 * @return
	 * @throws DataException
	 */
	List<Caso> buscaCasoAgendado(Atendente atendente) throws DataException;

	/**
	 * Busca todos os casos por {@link Status}
	 * @param status
	 * @return List<Caso> 
	 * @throws DataException
	 */
	List<Caso> buscaPorStatus(Status status) throws DataException;

	/**
	 * Busca todos os casos agendados de uma ConfiguracaoFila.
	 * @param configuracaoFila
	 * @return
	 * @throws DataException
	 */
	List<Caso> buscaProximoCasoAgendadoFila(List<ConfiguracaoFila> configuracaoFilaList) throws DataException;
        
        /**
         * Busca todos os casos que estão sendo atendidos por analistas.
         * 
         * @return
         * @throws DataException 
         */
        List<Caso> buscaCasoEmAtendimento() throws DataException;
        
        /**
         * Carrega o Caso pelo idExterno ou pelo idCaso
         * @param caso
         * @return
         * @throws DataException 
         */
        Caso load(Caso caso) throws DataException;

        /**
         * 
         * @param idAtendente
         * @param idFila
         * @param dataInicial
         * @param dataFinal
         * @return
         * @throws DataException
         */
		Integer quantidadeCasosFechados(Integer idAtendente, Integer idFila,
				Date dataInicial, Date dataFinal) throws DataException;

		/**
		 * Busca todos os casos que precisam ser reclassificados após a reabertura.
		 * @return
		 * @throws DataException
		 */
		List<Caso> buscaCasoReclassificaReabertura() throws DataException;

		/**
		 * Busca todos os casos em atendimento de um determinado atendente.
		 * @param atendente
		 * @return
		 * @throws DataException
		 */
		List<Caso> findCasoEmAtendimento(Atendente atendente) throws DataException;
		
		/**
	     * Atualiza flagEmAtendimento para false por uma determinada lista de atendentes
	     * 
	     * @param listaAtendente
	     * @throws DataException
	     */
		void atualizaFlagEmAtendimentoParaFalse(List<Atendente> listaAtendente) throws DataException;
		

		/**
		 * Retorna se os casos em atendimento para um atendente. (Normalmente deve ser retornado apenas um caso) 
		 * @param loginAtendente
		 * @return
		 * @throws ServiceException
		 */
		List<Caso> atendentePossuiCasoEmAtendimento(Atendente atendente) throws DataException;

		/**
		 * Valida se o Caso esta sendo processado pelo SPA
		 * @param caso
		 * @param tabelaImportacaoCaso 
		 * @return boolean
		 * @throws DataException
		 */
		boolean validaSeCasoEstaSendoProcessadoPeloSpa(Caso caso, String tabelaImportacaoCaso) throws DataException;
		
		/**
		 * Busca os casos que tem seu SLA finalizado no dia atual
		 * @return
		 */
		List<Caso> buscaCasosSLAFimDia() throws DataException;
		
		/**
		 * Busca todos os casos com SLA FIM na data informada
		 * @param data
		 * @return
		 * @throws DataException
		 */
		List<Caso> buscaCasosSLAFimDia(Date dataBusca) throws DataException;

		/**
		 * @return
		 * @throws DataException
		 */
		List<AtendenteCasoStatusTO> buscarQuantidadeCasosAtendidosPorStatus() throws DataException;

	/**
	 * @param atendente
	 * @param tbcasoespecialista
	 * @param sqlWhere
	 * @param idCaso
	 * @return
	 * @throws DataException
	 */
	List<Caso> buscarTodosCasosPendentesDoCliente(Atendente atendente, String tbcasoespecialista, String sqlWhere, Integer idCaso) throws DataException;
	
	/**
	 * Busca Caso por IdExterno
	 * @return
	 */
	Caso buscarCasoPorIdExterno(String idExterno) throws DataException;

	/**
	 * Busca Casos que não possuem data de vencimento de sla de casos fechados ou abertos
	 * @param casosFechados
	 * @return
	 */
	List<Caso> buscarCasoSemVencimentoSlaByFinalizado(Boolean casosFinalizados) throws DataException;

	/**
	 * Atualiza os campos de dataVencimentoSla e SlaMinutos
	 * @param caso
	 * @return
	 */
	void atualizarDataVencimentoSla(Caso caso) throws DataException;

	List<String> buscaColunasTabelaCaso() throws DataException;
		
}
