package br.com.callink.cad.dao;

import java.util.List;

import br.com.callink.cad.pojo.ConfiguracaoEmail;
import br.com.callink.cad.sau.exception.DataException;



public interface IConfiguracaoEmailDAO extends IGenericCadDAO<ConfiguracaoEmail>  {
	List<ConfiguracaoEmail> findByExample(ConfiguracaoEmail example,  String order) throws DataException;
	List<ConfiguracaoEmail> findAll(String order) throws DataException;
	List<ConfiguracaoEmail> findByIds(List<Integer> ids) throws DataException;
}
