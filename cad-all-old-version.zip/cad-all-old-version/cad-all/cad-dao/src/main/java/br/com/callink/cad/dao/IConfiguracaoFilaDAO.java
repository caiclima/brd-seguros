package br.com.callink.cad.dao;

import java.util.List;

import javax.xml.rpc.ServiceException;

import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.sau.exception.DataException;

/**
 * 
 * @author brunomt [brunoam@swb.com.br]
 *
 */
public interface IConfiguracaoFilaDAO extends IGenericCadDAO<ConfiguracaoFila>{
	
	/**
	 * Insere um caso em uma determinada fila.
	 * 
	 * @param caso
	 * @param configuracaoFila
	 * @throws DataException
	 */
	void insereCasoFila(Caso caso, ConfiguracaoFila configuracaoFila) throws DataException;
	
	/**
	 * Busca todas as filas ordenadas
	 * @return
	 * @throws ServiceException
	 */
	List<ConfiguracaoFila> buscaFilaPorPrioridade() throws DataException;
	
	/**
	 * Busca todas as filas ordenadas.
	 * @return
	 * @throws DataException
	 */
	List<ConfiguracaoFila> buscaFilaAtivaPorPrioridade() throws DataException;
	
	/**
	 * Busca as filas que precisam de build por prioridade.
	 * @return
	 * @throws DataException
	 */
	List<ConfiguracaoFila> buscaFilaBuildPorPrioridade() throws DataException;
	
	/**
	 * Remove todos os casos de uma fila que esta necessitando de fazer build.
	 * @param configuracaoFilas
	 * @throws DataException
	 */
	void removeCasosClassificacaoFila(ConfiguracaoFila configuracaoFila) throws DataException;
	
	/**
	 * Retorna a fila de menor prioridade.
	 * @return
	 * @throws DataException
	 */
	ConfiguracaoFila buscaMaiorFilaMenorPrioridade() throws DataException;
	
	/**
	 * Remove da tb_fila_classificao_caso o caso pelo id_caso e id_configuracao_fila do caso
	 * @param caso
	 * @throws DataException
	 */
	void removeFilaClassificaoCaso(Caso caso) throws DataException;

	List<ConfiguracaoFila> findByExample(ConfiguracaoFila configuracaoFila,String order) throws DataException;
	
	List<ConfiguracaoFila> findAll(String order) throws DataException;
	
}
