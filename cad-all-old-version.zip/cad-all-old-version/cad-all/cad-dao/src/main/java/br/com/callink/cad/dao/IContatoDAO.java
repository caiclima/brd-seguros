package br.com.callink.cad.dao;

import br.com.callink.cad.pojo.ContatoTelefone;

public interface IContatoDAO extends IGenericCadDAO<ContatoTelefone> {

}
