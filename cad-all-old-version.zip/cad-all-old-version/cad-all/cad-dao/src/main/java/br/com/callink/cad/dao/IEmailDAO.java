/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.dao;

import java.util.Date;
import java.util.List;

import javax.xml.rpc.ServiceException;

import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.Email;
import br.com.callink.cad.sau.exception.DataException;

/**
 *
 * @author Luiz Gustavo (luizgf@swb.com.br)
 */
public interface IEmailDAO extends IGenericCadDAO<Email>{
    
	/**
	 * Busca todos os e-mails do caso
	 * @param caso
	 * @return
	 * @throws DataException
	 */
    List<Email> findEmailsFromCaso(Caso caso) throws DataException;

     /**
     * 
     * @param email
     * @throws ServiceException 
     */
    void updateFlagLido(Email email) throws DataException;
    
    /**
     * Busca os Emails sem caso que ainda não foram desativados.
     * @return
     * @throws DataException
     */
    List<Email> findEmailsSemCaso() throws DataException;

    /**
     * Destiva o e-mail do caso.
     * @param email
     * @throws DataException
     */
	void updateFlagDesativado(Email email) throws DataException;

	/**
	 * Busca todos os e-mails do caso de acordo com o flag envio (enviados ou recebidos)
	 * @param caso
	 * @return
	 * @throws DataException
	 */
	List<Email> findEmailsFromCasoByFlagEnvio(Caso caso, Boolean flagEnvio) throws DataException;

	List<Email> findEmailsSemCasoByExample(Email email, Date dataInicio, Date dataFim) throws DataException;
	
}
