/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.dao;

import java.util.List;

import br.com.callink.cad.pojo.EmailGrupoEmail;
import br.com.callink.cad.sau.exception.DataException;


/**
 *
 * @author Luiz Gustavo F. (luizgf@swb.com.br)
 */
public interface IEmailGrupoEmailDAO extends IGenericCadDAO<EmailGrupoEmail>{

	List<EmailGrupoEmail> findByExample(EmailGrupoEmail example, String order)
			throws DataException;
 
}
