/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.dao;

import java.util.List;

import br.com.callink.cad.pojo.Equipe;
import br.com.callink.cad.sau.exception.DataException;

/**
 *
 * @author Rogério Moreira de Andrade. [rogeriom@swb.com.br]
 */
public interface IEquipeDAO extends IGenericCadDAO<Equipe>{

	/**
	 * Retorna todas as equipes ativas.
	 * @return
	 * @throws DataException
	 */
    List<Equipe> findAtivos() throws DataException;
    
    List<Equipe> findByExample(Equipe example, String order) throws DataException;
    
}
