package br.com.callink.cad.dao;

import java.util.List;

import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.pojo.Equipe;
import br.com.callink.cad.pojo.EquipeFila;
import br.com.callink.cad.sau.exception.DataException;

/**
 * 
 * @author brunomt
 *
 */
public interface IEquipeFilaDAO extends IGenericCadDAO<EquipeFila>{
	/**
	 * Busca as filas ordenadas pela prioridade das mesmas.
	 * @return
	 * @throws DataException
	 */
	List<EquipeFila> buscaEquipeFilaPelaPrioridade(Equipe equipe) throws DataException;

	/**
	 * Salva um List de EquipeFila
	 * @param equipeFilaList
	 * @throws DataException
	 */
	void saveList(List<EquipeFila> equipeFilaList) throws DataException;

	/**
	 * Retorna EquipeFila unico pela {@link equipe} e {@link configuracaoFila}
	 * @param equipe
	 * @param configuracaoFila
	 * @return EquipeFila
	 * @throws DataException
	 */
	EquipeFila buscaByEquipeAndConfiguracaoFila(Equipe equipe, ConfiguracaoFila configuracaoFila) throws DataException;

	/**
	 * Retorna uma lista de EquipeFila pelo {@link equipe} e {@link configuracaoFila}
	 * @param equipe
	 * @param configuracaoFila
	 * @return
	 * @throws DataException 
	 */
	List<EquipeFila> buscaByEquipeFilaListByEquipeEConfiguracaoFila(Equipe equipe, ConfiguracaoFila configuracaoFila) throws DataException;
        
        /**
         * Busca Todas as EquipeFila Pelo {@link equipeList}
         * @param equipeList
         * @return
         * @throws DataException 
         */
        List<EquipeFila> buscaPorEquipeList(List<Equipe> equipeList) throws DataException;

        /**
         * 
         * @param equipe
         * @return
         * @throws DataException
         */
		List<EquipeFila> findFilasByEquipe(Equipe equipe) throws DataException;
        /**
         * Exclui a assiciação de equipes com filas
         * @param equipe
         * @throws DataException
         */
        void limpaEquipeFila(Equipe equipe) throws DataException;
        
}
