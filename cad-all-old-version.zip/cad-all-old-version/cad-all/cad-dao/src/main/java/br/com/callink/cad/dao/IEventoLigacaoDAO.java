package br.com.callink.cad.dao;

import java.util.List;
import br.com.callink.cad.pojo.EventoLigacao;
import br.com.callink.cad.sau.exception.DataException;

public interface IEventoLigacaoDAO extends IGenericCadDAO<EventoLigacao> {

	/**
	 * @param pojo
	 * @return
	 * @throws DataException
	 */
	List<EventoLigacao> findAtivosExceto(EventoLigacao pojo) throws DataException;

	List<EventoLigacao> findByEvento(EventoLigacao eventoLigacao) throws DataException;

}
