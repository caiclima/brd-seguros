/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.dao;

import java.util.Date;

import br.com.callink.cad.pojo.Feriado;
import br.com.callink.cad.sau.exception.DataException;


/**
 *
 * @author Ednaldo Caic [ednaldo@swb.com.br]
 * @since 26/12/2011
 */
public interface IFeriadoDAO extends IGenericCadDAO<Feriado>{
	
	public Boolean isFeriado(Date date) throws DataException;
    
}
