package br.com.callink.cad.dao;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;

import br.com.callink.cad.sau.exception.DataException;

/**
 * 
 * @author marco
 * 
 * @param <T>
 */
public interface IGenericCadDAO<T> extends Serializable{

	/**
	 * Localiza todos os objetos do tipo T.
	 * 
	 * @return Colecao de objetos do tipo T.
	 * @throws DataException
	 */
	List<T> findAll() throws DataException;

	/**
	 * Salva um objeto do tipo T.
	 * 
	 * @param object
	 *            o objeto a ser salvo
	 * @throws DataException
	 */
	void save(final T object) throws DataException;

	/**
	 * Atualiza o objeto do tipo T.
	 * 
	 * @param object
	 *            o objeto a ser atualizado
	 * @throws DataException
	 *             LanÃƒÂ§ada quando a validacao nao ocorre com sucesso.
	 */
	void update(final T object) throws DataException;

	/**
	 * Salva o objeto do tipo T enviado, verificando se o mesmo possui a
	 * Annotation: javax.persistence.Id.class capturando o seu valor realizando
	 * a chamada do metodo save (id == null) ou update(id != null).
	 * 
	 * @param object
	 * @throws DataException
	 */
	void saveOrUpdate(final T object) throws DataException;

	/**
	 * Verifica se o objeto enviado possui a Annotation:
	 * javax.persistence.Id.class capturando o seu valor.
	 * 
	 * @param object
	 * @return boolean 
	 * @throws Exception
	 */
	boolean possuiIdComValor(T object) throws Exception;

	/**
	 * Exclui o objeto do tipo T.
	 * 
	 * @param object
	 *            o objeto a ser excluido
	 * @throws DataException
	 *             LanÃƒÂ§ada quando a validacao nao ocorre com sucesso.
	 */
	void delete(final T object) throws DataException;

	/**
	 * Carrega o objeto do tipo T.
	 * 
	 * @param object
	 *            objeto do tipo T com o atributo ID setado.
	 * @return o objeto do tipo T com todos os atributos preenchidos.
	 * @throws DataException
	 */
	T findByPk(Object object) throws DataException;

	/**
	 * Carrega os objetos com propriedades iguais Ã s que foram passadas no
	 * objeto de exemplo.
	 * 
	 * @param object
	 * @return
	 * @throws DataException
	 */
	List<T> findByExample(T object) throws DataException;
	
	/**
	 * Carrega os objetos com propriedades iguais Ã s que foram passadas no
	 * objeto de exemplo ordenadas.
	 * 
	 * @param object
	 * @return
	 * @throws DataException
	 */
	List<T> findByExample(T object, String order) throws DataException;

	/**
	 * Carrega os objetos conforme query e os paramentros enviados.
	 * 
	 * @param query
	 * @param params
	 * @return List&lt;T&gt;
	 * @throws DataException
	 */
	List<T> findByNamedQuery(final String query, Object... params) throws DataException;

	/**
	 * Carrega os objetos conforme query e os paramentros enviados.
	 * 
	 * @param name
	 * @param params
	 * @return List&lt;T&gt;
	 */
	List<T> findByNamedQueryAndNamedParams(final String name, final Map<String, ? extends Object> params)
			throws DataException;
	
	
	/**
	 * Busca os ativos, caso tenha a coluna FLG_ATIVO
	 * @param order
	 * @return
	 * @throws DataException
	 */
	List<T> findAtivos(String order) throws DataException;
	
	
	/**
	 * Busca os ativos, caso tenha a coluna FLG_ATIVO
	 * @param order
	 * @return
	 * @throws DataException
	 */
	List<T> findAtivos() throws DataException;
	
	
	/**
	 * retorna a data do banco
	 * @return
	 * @throws DataException
	 */
	Date getDataBanco() throws DataException;
	
}
