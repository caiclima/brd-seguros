package br.com.callink.cad.dao;

import java.util.List;

import br.com.callink.cad.pojo.GoalFinal;
import br.com.callink.cad.sau.exception.DataException;

public interface IGoalFinalDAO extends IGenericCadDAO<GoalFinal>{

	/**
	 * 
	 * @return
	 * @throws DataException
	 */
	List<GoalFinal> buscaGoalsAtivos() throws DataException;

	/**
	 * Atualiza dataFinal do GoalFinal por id
	 * 
	 * @param id
	 * @throws DataException
	 */
	void updateDataFinalPorId(Integer id) throws DataException;

	/**
	 * Buscar histórico de goals
	 * @return
	 * @throws DataException
	 */
	List<GoalFinal> buscaHistoricoGoals() throws DataException;
	
}
