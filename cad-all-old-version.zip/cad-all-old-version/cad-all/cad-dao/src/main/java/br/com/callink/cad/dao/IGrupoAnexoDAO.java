package br.com.callink.cad.dao;

import br.com.callink.cad.pojo.GrupoAnexo;
import br.com.callink.cad.sau.exception.DataException;

/**
 * 
 * @author Ednaldo Caic [ednaldo@swb.com.br]
 */
public interface IGrupoAnexoDAO extends IGenericCadDAO<GrupoAnexo>{

	/**
	 * Busca um GrupoAnexo pelo nome
	 * @param nome
	 * @return
	 * @throws DataException
	 */
	GrupoAnexo buscaPorNome(String nome) throws DataException;
	
}
