/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.dao;

import java.util.List;

import br.com.callink.cad.pojo.GrupoEmail;
import br.com.callink.cad.sau.exception.DataException;


/**
 *
 * @author Luiz Gustavo (luizgf@swb.com.br)
 */
public interface IGrupoEmailDAO extends IGenericCadDAO<GrupoEmail>{
	
	List<GrupoEmail> findByExample(GrupoEmail example, String order) throws DataException;
	
	List<GrupoEmail> findAll(String order) throws DataException;
	
}
