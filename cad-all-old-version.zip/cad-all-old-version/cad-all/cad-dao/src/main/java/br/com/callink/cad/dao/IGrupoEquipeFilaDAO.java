/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.dao;

import java.util.List;

import br.com.callink.cad.pojo.GrupoEquipe;
import br.com.callink.cad.pojo.GrupoEquipeFila;
import br.com.callink.cad.sau.exception.DataException;

/**
 *
 * @author Rogerio
 */
public interface IGrupoEquipeFilaDAO extends IGenericCadDAO<GrupoEquipeFila>{

    /**
     *
     * @param grupoEquipe
     * @return
     * @throws DataException
     */
    List<GrupoEquipeFila> grupoEquipeFilaList(GrupoEquipe grupoEquipe) throws DataException;
    /**
     * 
     * @param equipe
     * @throws DataException 
     */
    void limpaGrupoEquipeFila(GrupoEquipe equipe) throws DataException;
}
