package br.com.callink.cad.dao;

import br.com.callink.cad.pojo.HistoricoDadosCaso;


public interface IHistoricoDadosCasoDAO extends IGenericCadDAO<HistoricoDadosCaso>{

}
