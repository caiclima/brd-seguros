/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.dao;

import br.com.callink.cad.pojo.HistoricoGbo;


/**
*
* @author Ednaldo Caic [ednaldo@swb.com.br]
* @since 03/01/2012
*/
public interface IHistoricoGboDAO extends IGenericCadDAO<HistoricoGbo>{

}
