package br.com.callink.cad.dao;

import java.util.Date;
import java.util.List;

import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.Log;
import br.com.callink.cad.pojo.Status;
import br.com.callink.cad.sau.exception.DataException;

public interface ILogDAO extends IGenericCadDAO<Log>{

    List<Log> findHistorico(Caso caso) throws DataException;
    
    List<Log> findHistoricoEmail(Caso caso) throws DataException;

	Integer countLogByCasoAndData(Caso caso, Date dataInicial, Date dataFinal)throws DataException;
	
	Integer countLogByCasoAndDataAndStatus(Caso caso, Date dataInicial, Date dataFinal, List<Status> statusList)throws DataException;
	
	/**
	 * Busca todos os logs do caso
	 * @param caso
	 * @return
	 * @throws DataException
	 */
    List<Log> findLogsFromCaso(Caso caso, Date dataAlteracao) throws DataException;
    
}
