package br.com.callink.cad.dao;

import java.util.Date;
import java.util.List;
import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.LogLigacoes;
import br.com.callink.cad.sau.exception.DataException;

public interface ILogLigacoesDAO extends IGenericCadDAO<LogLigacoes>{

	/**
	 * Busca log por callID e data final vazia
	 * @param callID
	 * @return List<LogLigacoes>
	 * @throws DataException
	 */
	List<LogLigacoes> findByCallIDAndDateEndNull(String callID) throws DataException;

	/**
	 * Busca log por userSSO(login) e callID null e data final vazia
	 * @param userSSO
	 * @return List<LogLigacoes>
	 * @throws DataException
	 */
	List<LogLigacoes> findByCallIdNullForUserSSO(String userSSO, String telefone) throws DataException;

	/**
	 * Busca os log ligações por filtro
	 * @param idCaso
	 * @param flagEntrante
	 * @param inicio
	 * @param fim
	 * @param atendenteList
	 * @return
	 * @throws DataException
	 */
	List<LogLigacoes> findByFilters(String idCaso, String flagEntrante,	Date inicio, Date fim, List<Atendente> atendenteList) throws DataException;

	List<LogLigacoes> findByUserSSOTelefone(String userSSO, String telefone) throws DataException;
	
	/**
	 * @param caso
	 * @return
	 * @throws DataException
	 */
	Boolean existeTentativaDeContatoPorCaso(Caso caso) throws DataException;

	/**
	 * @param caso
	 * @param data
	 * @return
	 * @throws DataException
	 */
	Boolean existeTentativaDeContatoParaTodosTelefonesPorCasoEData(Caso caso, Date data) throws DataException;

	/**
	 * @param caso
	 * @return
	 * @throws DataException
	 */
	Boolean existeContatoComSucessoPorCaso(Caso caso) throws DataException;

	/**
	 * @param caso
	 * @param telefone
	 * @return
	 * @throws DataException
	 */
	Boolean existeTentativaDeContatoParaTodosOutrosTelefonesPorCaso(Caso caso, String telefone) throws DataException;

	/**
	 * @param telefone
	 * @param data
	 * @return
	 * @throws DataException
	 */
	Integer findQtdTentativaDeContatoPorTelefoneEData(String telefone, Date data) throws DataException;
}
