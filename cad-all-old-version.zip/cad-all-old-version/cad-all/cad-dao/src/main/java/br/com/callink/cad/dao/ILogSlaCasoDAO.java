package br.com.callink.cad.dao;

import java.util.List;

import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.LogSlaCaso;
import br.com.callink.cad.sau.exception.DataException;

public interface ILogSlaCasoDAO extends IGenericCadDAO<LogSlaCaso> {

	List<LogSlaCaso> findLogSlaByCaso(Caso caso) throws DataException;
	
}
