package br.com.callink.cad.dao;

import br.com.callink.cad.pojo.LogTask;


public interface ILogTaskDAO extends IGenericCadDAO<LogTask>{

}
