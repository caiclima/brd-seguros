/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.dao;

import java.util.List;

import br.com.callink.cad.pojo.CabUph;
import br.com.callink.cad.pojo.MetaUph;
import br.com.callink.cad.sau.exception.DataException;

/**
 *
 * @author swb.miller
 */
public interface IMetaUphDAO extends IGenericCadDAO<MetaUph>{
    
    List<MetaUph>  findMetaByCabUph(CabUph cab) throws  DataException;
    
}
