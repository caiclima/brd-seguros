/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.dao;

import br.com.callink.cad.pojo.ParametroComando;


/**
 *
 * @author Rogério Moreira de Andrade. [rogeriom@swb.com.br]
 */
public interface IParametroComandoDAO extends IGenericCadDAO<ParametroComando>{

}
