package br.com.callink.cad.dao;

import java.util.List;

import br.com.callink.cad.pojo.ParametroGBO;
import br.com.callink.cad.sau.exception.DataException;

public interface IParametroGBODAO extends IGenericCadDAO<ParametroGBO>{
	
	/**
	 * Busca o parametro pela chave.
	 * @param key
	 * @return
	 * @throws DataException
	 */
	ParametroGBO findByParam(String key) throws DataException;

	/**
	 * @param key
	 * @return
	 * @throws DataException
	 */
	List<ParametroGBO> findParamStartsWithKey(String key)  throws DataException;

	/**
	 * @param key
	 * @return
	 * @throws DataException
	 */
	List<ParametroGBO> findByParam(String... key) throws DataException;
	
}
