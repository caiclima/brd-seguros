package br.com.callink.cad.dao;

import java.util.List;

import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.ReaberturaCaso;
import br.com.callink.cad.sau.exception.DataException;

public interface IReaberturaCasoDAO extends IGenericCadDAO<ReaberturaCaso>{
    
    /**
     * Busca as reaberturas pelo Caso.
     * @param caso
     * @return
     * @throws DataException 
     */
    List<ReaberturaCaso> findByCaso(Caso caso) throws DataException; 
    
}
