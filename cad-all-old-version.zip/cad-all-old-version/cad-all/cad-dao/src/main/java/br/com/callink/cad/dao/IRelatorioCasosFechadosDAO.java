package br.com.callink.cad.dao;

import java.util.Date;
import java.util.List;

import br.com.callink.cad.pojo.RelatorioCasosFechados;
import br.com.callink.cad.sau.exception.DataException;

public interface IRelatorioCasosFechadosDAO extends IGenericCadDAO<RelatorioCasosFechados>{

	/**
	 * Retorna os casos fechados do dia infomado.
	 * @param dataBusca
	 * @return
	 * @throws DataException
	 */
	List<RelatorioCasosFechados> buscaCasosFechadosDia(Date dataBusca) throws DataException;
	
	/**
	 * Busca os casos fechados na data atual
	 * @return
	 * @throws DataException
	 */
	List<RelatorioCasosFechados> buscaCasosFechadosDia() throws DataException;

	/**
	 * Limpa os dados gerados para o dia atual.
	 * @throws DataException
	 */
	void limpaDiaAtual(Date dataAtual)  throws DataException;
	
}
