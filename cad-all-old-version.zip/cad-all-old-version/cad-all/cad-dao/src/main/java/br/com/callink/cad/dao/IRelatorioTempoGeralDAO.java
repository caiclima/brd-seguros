package br.com.callink.cad.dao;

import java.util.Date;
import java.util.List;

import br.com.callink.cad.pojo.RelatorioTempoGeral;
import br.com.callink.cad.sau.exception.DataException;

public interface IRelatorioTempoGeralDAO extends IGenericCadDAO<RelatorioTempoGeral>{

	/**
	 * Retorna os casos fechados do dia infomado.
	 * @param dataBusca
	 * @return
	 * @throws DataException
	 */
	void geraRelatorioTempoGeral(Date dataIncial) throws DataException;

	/**
	 * Limpa os dados gerados para o dia atual.
	 * @throws DataException
	 */
	void limpaDiaAtual(Date dataAtual)  throws DataException;
	
	
	
	/**
	 * Busca a ultima data do relatorio de tempo geral
	 * 
	 * @return
	 * @throws DataException
	 */
	Date findUltimaHoraRelatorioTempoGeral() throws DataException;
	
	/**
	 * 
	 * findListRelatorioTempoGeral
	 * @param mes
	 * @param ano
	 * @param idEquipe
	 * @return
	 * @throws DataException
	 */
	List<RelatorioTempoGeral> findListRelatorioTempoGeral(int mes, int ano, int idEquipe) throws DataException;
	
}
