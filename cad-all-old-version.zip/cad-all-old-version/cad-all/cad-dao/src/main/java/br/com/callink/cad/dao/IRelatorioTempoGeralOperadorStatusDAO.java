package br.com.callink.cad.dao;

import java.util.Date;
import java.util.List;
import java.util.Map;

import br.com.callink.cad.pojo.RelatorioTempoGeralOperadorStatus;
import br.com.callink.cad.sau.exception.DataException;

public interface IRelatorioTempoGeralOperadorStatusDAO extends IGenericCadDAO<RelatorioTempoGeralOperadorStatus> {

	/**
	 * Retorna os casos fechados do dia infomado por operador de todos status.
	 * @param dataBusca
	 * @return
	 * @throws DataException
	 */
	void geraRelatorioTempoGeralOperador(Date dataIncial) throws DataException;

	Date findUltimaHoraRelatorioTempoGeralOperador() throws DataException;

	List<RelatorioTempoGeralOperadorStatus> buscaTodosTemposStatusOperador(String dataRelatorio, Integer idEquipe) throws DataException; 


}
