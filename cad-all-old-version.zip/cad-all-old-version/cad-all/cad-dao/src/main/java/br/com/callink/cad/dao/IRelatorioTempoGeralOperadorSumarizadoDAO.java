package br.com.callink.cad.dao;

import java.util.List;
import java.util.Map;

import br.com.callink.cad.pojo.RelatorioTempoGeralOperadorStatus;
import br.com.callink.cad.pojo.RelatorioTempoGeralOperadorSumarizado;
import br.com.callink.cad.sau.exception.DataException;

public interface IRelatorioTempoGeralOperadorSumarizadoDAO extends IGenericCadDAO<RelatorioTempoGeralOperadorSumarizado> {

	List<RelatorioTempoGeralOperadorSumarizado> buscaTodosTemposStatusSumarizadosPorOperador(String dataRelatorio, Integer idEquipe) throws DataException;

}
