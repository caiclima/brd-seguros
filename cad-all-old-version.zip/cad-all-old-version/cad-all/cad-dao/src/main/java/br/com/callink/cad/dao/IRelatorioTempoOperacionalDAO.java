package br.com.callink.cad.dao;

import java.util.Date;
import java.util.List;

import br.com.callink.cad.pojo.RelatorioTempoOperacional;
import br.com.callink.cad.sau.exception.DataException;

/**
 *
 * @author brunomt
 */
public interface IRelatorioTempoOperacionalDAO extends IGenericCadDAO<RelatorioTempoOperacional>{
    
    /**
     * 
     * @param data1
     * @param data2
     * @return
     * @throws DataException 
     */
    List<RelatorioTempoOperacional> retornaLoginsUsuariosSSO(Date data1, Date data2, Integer idSupervisor, String linkedServerName) throws DataException;
    
    /**
     * 
     * @throws DataException 
     */
    void limpaRelatorioAnterior() throws DataException;

}
