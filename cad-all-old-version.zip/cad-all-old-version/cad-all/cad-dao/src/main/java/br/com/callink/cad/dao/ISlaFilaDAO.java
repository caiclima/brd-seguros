/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.dao;

import java.util.List;

import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.pojo.SlaFila;
import br.com.callink.cad.sau.exception.DataException;

/**
 *
 * @author miller
 */
public interface ISlaFilaDAO extends IGenericCadDAO<SlaFila>{
    
    /**
     * Busca sla de acordo com a fila
     * 
     * @param conf
     * @return
     * @throws DataException 
     */
    List<SlaFila> findSlaFilaByConfFila(ConfiguracaoFila conf) throws DataException;
    
    /**
     * busca todas sla com join na tabela de 
     * 
     * @return
     * @throws DataExceptio 
     */
    List<SlaFila> findAllSlafila() throws DataException;
    
    /**
     * Busca sla de acordo com a fila e que a data final estja vazia
     * 
     * @param fila
     * @return
     * @throws DataException
     */
    List<SlaFila> findSlaFilaByConfFilaAndDataFimNull(ConfiguracaoFila fila) throws DataException;
    
    /**
     * Busca sla fila por parametros passados pelo usuário na tela.
     * 
     * @param configFila
     * @param sla
     * @param descricao
     * @return
     * @throws DataException
     */
	List<SlaFila> findSlaFilaList(ConfiguracaoFila configFila, Integer sla,
			String descricao) throws DataException;


}
