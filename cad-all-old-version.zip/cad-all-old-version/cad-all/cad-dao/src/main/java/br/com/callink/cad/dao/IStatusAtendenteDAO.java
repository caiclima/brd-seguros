package br.com.callink.cad.dao;

import java.util.Date;
import java.util.List;

import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.AtendenteStatus;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.pojo.Equipe;
import br.com.callink.cad.pojo.StatusAtendente;
import br.com.callink.cad.sau.exception.DataException;

/**
 *
 * @author brunomt
 */
public interface IStatusAtendenteDAO extends IGenericCadDAO<StatusAtendente> {

    /**
     * Busca a ultima marcação para o Atendente;
     * @param atendente
     * @return 
     */
    Integer buscaUltimoStatusAtendente(Atendente atendente) throws DataException;
    
    /**
     * Busca todos os status Atendente do dia.
     * @param data1
     * @param data2
     * @return
     * @throws DataException 
     */
    List<StatusAtendente> buscaTodosStatusAtendenteEntreDatas(Date dataInicio, Date dataFim) throws DataException;

    /**
     * 
     * @param fila
     * @param equipe
     * @param atendente
     * @param dataInicial
     * @param dataFinal
     * @return
     * @throws DataException
     */
	List<StatusAtendente> buscaStatusAtendenteByUserEquipe(ConfiguracaoFila fila, Equipe equipe, Atendente atendente,
			Date dataInicial, Date dataFinal) throws DataException;
	
	/**
     * 
     * @param atendente
     * @param dataInicial
     * @param dataFinal
     * @return
     * @throws DataException
     */
	List<StatusAtendente> buscaStatusAtendenteByAtendente(Atendente atendente, Date dataInicial, 
			Date dataFinal) throws DataException;

	/**
	 * Finaliza os status que não tem data fim a mais de 9horas;
	 * @throws DataException
	 */
	void finalizaStatusAtendenteSemDataFim() throws DataException;

	/**
	 * Busca todos os atendentes que estão com um status x aberto.
	 * @param atendenteStatus
	 * @param tempoSegundos
	 * @return
	 * @throws DataException
	 */
	List<StatusAtendente> buscaStatusAtendenteByStatus(AtendenteStatus atendenteStatus, Integer tempoSegundos) throws DataException;

}
