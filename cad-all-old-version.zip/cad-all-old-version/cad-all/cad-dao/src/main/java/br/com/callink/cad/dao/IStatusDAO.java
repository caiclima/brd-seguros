package br.com.callink.cad.dao;

import java.util.List;

import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.pojo.Status;
import br.com.callink.cad.pojo.StatusAcao;
import br.com.callink.cad.sau.exception.DataException;

/**
 * 
 * @author brunomt [brunoam@swb.com.br]
 *
 */
public interface IStatusDAO extends IGenericCadDAO<Status>{

	/**
	 * 
	 * @param statusAcao
	 * @throws DataException
	 */
    void associa(StatusAcao statusAcao) throws DataException;

    /**
     * 
     * @param statusAcao
     * @throws DataException
     */
    void associa(List<StatusAcao> statusAcao) throws DataException;

    /**
     * 
     * @param statusAcao
     * @throws DataException
     */
    void excluiAssociacao(StatusAcao statusAcao) throws DataException;

    /**
     * 
     * @param status
     * @return
     * @throws DataException
     */
    List<StatusAcao> findByStatus(Status status) throws DataException;

    /**
     * 
     * @param acao
     * @return
     * @throws DataException
     */
    List<StatusAcao> findByAcao(Acao acao) throws DataException;

    /**
     * 
     * @param acao
     * @param status
     * @return
     * @throws DataException
     */
    List<StatusAcao> find(Acao acao, Status status) throws DataException;

    /**
     * 
     * @return
     * @throws DataException
     */
    List<StatusAcao> findAllStatusAcao() throws DataException;

    /**
     * Retorna o Status pelo nome
     * @param nomeStatus
     * @return
     * @throws DataException
     */
	Status findStatusByNomeStatus(String nomeStatus) throws DataException;
	
	List<Status> findAll(String order) throws DataException;
	
	List<Status> findByExample(Status example, String order) throws DataException;

	/**
	 * @param st
	 * @return
	 * @throws DataException
	 */
	List<Status> findByPkIn(List<Integer> st) throws DataException;
	
	/**
	 * @param nomes
	 * @return
	 * @throws DataException
	 */
	List<Status> findByNomes(List<String> nomes) throws DataException;
	
	/**
	 * @param nomes
	 * @return
	 * @throws DataException
	 */
	List<Status> findExcludeByNomes(List<String> nomes) throws DataException;

}
