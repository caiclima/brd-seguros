/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.dao;

import br.com.callink.cad.pojo.TelaGbo;
import br.com.callink.cad.sau.exception.DataException;

/**
*
* @author Ednaldo Caic [ednaldo@swb.com.br]
* @since 03/01/2012
*/
public interface ITelaGboDAO extends IGenericCadDAO<TelaGbo>{

	/**
	 * Retorna a tela pelo nome da tela passado.
	 * @param nomeTela
	 * @return TelaGbo
	 * @throws DataException
	 */
	TelaGbo findByNomeTela(String nomeTela) throws DataException;

}
