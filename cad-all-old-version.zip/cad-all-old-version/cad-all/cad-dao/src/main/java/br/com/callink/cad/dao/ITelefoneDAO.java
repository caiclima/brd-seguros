/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.dao;

import java.util.List;

import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.Telefone;
import br.com.callink.cad.sau.exception.DataException;


/**
 *
 * @author Rogério Moreira de Andrade. [rogeriom@swb.com.br]
 */
public interface ITelefoneDAO extends IGenericCadDAO<Telefone>{

	List<Telefone> buscaTelefoneCaso(Caso caso) throws DataException;

	/**
	 * @param telefoneList
	 * @return
	 */
	List<Telefone> findTelefonesNaoTabulados(List<Telefone> telefoneList) throws DataException;

	/**
	 * @param caso
	 * @return
	 * @throws DataException
	 */
	Boolean existeContatoNaoTabulado(Caso caso) throws DataException;

	void deletarTelefonesAusentes(List<Telefone> telefones) throws DataException;

	void deletarTelefonesCaso(Caso caso) throws DataException;

}
