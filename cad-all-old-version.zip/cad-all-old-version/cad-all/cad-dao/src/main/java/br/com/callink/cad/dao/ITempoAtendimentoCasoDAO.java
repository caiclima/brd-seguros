package br.com.callink.cad.dao;

import java.util.List;

import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.TempoAtendimentoCaso;
import br.com.callink.cad.sau.exception.DataException;

/**
 * 
 * @author brunomt
 *
 */
public interface ITempoAtendimentoCasoDAO extends IGenericCadDAO<TempoAtendimentoCaso>{

	/**
	 * Busca a última marcação do atendente.
	 * @param atendente
	 * @return
	 * @throws DataException
	 * @throws br.com.callink.cad.sau.exception.DataException 
	 */
	Integer findUltimaMarcacaoAtendente(Atendente atendente) throws DataException;

	List<TempoAtendimentoCaso> findByCaso(Caso caso) throws DataException;

}
