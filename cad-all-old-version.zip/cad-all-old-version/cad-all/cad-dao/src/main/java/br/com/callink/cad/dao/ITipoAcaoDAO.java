package br.com.callink.cad.dao;

import java.util.List;

import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.pojo.AcaoTipoAcao;
import br.com.callink.cad.pojo.Status;
import br.com.callink.cad.pojo.TipoAcao;
import br.com.callink.cad.sau.exception.DataException;

/**
 * 
 * @author brunomt [brunoam@swb.com.br]
 *
 */
public interface ITipoAcaoDAO extends IGenericCadDAO<TipoAcao>{

	/**
	 * Associa Ação com TipoAção
	 * @param acaoTipoAcao
	 * @throws DataException
	 */
	void associa(AcaoTipoAcao acaoTipoAcao) throws DataException;

	/**
	 * Exclui uma associação
	 * @param acaoTipoAcao
	 * @throws DataException
	 */
	void excluiAssociacao(AcaoTipoAcao acaoTipoAcao) throws DataException;

	/**
	 * Busca AcaoTipoAcao pelo filtro informado.
	 * @param acao
	 * @param tipoAcao
	 * @return
	 * @throws DataException
	 */
	List<AcaoTipoAcao> find(Acao acao, TipoAcao tipoAcao) throws DataException;

	/**
	 * Busca todos os AcaoTipoAcao
	 * @return
	 * @throws DataException
	 */
	List<AcaoTipoAcao> findAllAcaoTipoAcao() throws DataException;

	/**
	 * Busca todos os tiposAção relacionados a ação que possuem o status informado.
	 * @param status
	 * @return
	 * @throws DataException
	 */
	List<TipoAcao> findTipoAcaoPeloStatus(Status status) throws DataException;
	
	List<TipoAcao> findByExample(TipoAcao example, String order) throws DataException;

}
