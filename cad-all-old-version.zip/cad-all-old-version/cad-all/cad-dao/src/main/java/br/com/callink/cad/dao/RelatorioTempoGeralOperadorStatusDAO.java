package br.com.callink.cad.dao;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import br.com.callink.cad.dao.impl.GenericCadDAO;
import br.com.callink.cad.pojo.RelatorioTempoGeralOperadorStatus;
import br.com.callink.cad.sau.exception.DataException;

public class RelatorioTempoGeralOperadorStatusDAO extends GenericCadDAO<RelatorioTempoGeralOperadorStatus> implements IRelatorioTempoGeralOperadorStatusDAO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2745202182753097323L;
	
	private final static String PROCEDURE = "PROC_RELATORIO_GERAL_OPERADOR ";
	private final static String EXECUTE = " exec ";
	private final static String DATA_EXECUCAO = " @Pdata_execucao ";
	

	public RelatorioTempoGeralOperadorStatusDAO() {
		super(RelatorioTempoGeralOperadorStatus.class);
	}

	@Override
	public void geraRelatorioTempoGeralOperador(Date dataIncial) throws DataException {

		CallableStatement cs = null;
		PreparedStatement stmt = null;
		try {
			if (dataIncial == null) {
				
				throw new DataException("Obrigatorio informar a data inicial");
			}

			StringBuilder sql = new StringBuilder();
			sql.append(EXECUTE + PROCEDURE + DATA_EXECUCAO +" = '"+new java.sql.Timestamp(dataIncial.getTime()).toString()+"' " );
	        
	        cs = getConnection().prepareCall(sql.toString());
	        cs.execute();
	        
		} catch (Exception e) {
			throw new DataException("Erro ao buscar os casos fechados no dia atual",e);
		} finally {
			try {
				if(cs != null) {
					cs.close();
				}
				close(null);
			} catch (Exception e) {
				throw new DataException(e);
			}
		}

	}

	@Override
	public Date findUltimaHoraRelatorioTempoGeralOperador() throws DataException {
		
		ResultSet resultSet = null;
		PreparedStatement stmt = null;
		
		try {
			
			StringBuilder string = new StringBuilder(SELECT)
			  						   .append(" max(convert(datetime, RelatorioTempoGeralOperadorStatus.data, 103)) as maxDate ")
			  						   .append(FROM).append(RelatorioTempoGeralOperadorStatus.getSqlFromRelatorioTempoGeralOperadorStatus());
			
			stmt = getPreparedStatement(string.toString());
			stmt.execute();
			
			resultSet = stmt.getResultSet();

			while (resultSet.next()) {
				return resultSet.getDate("maxDate");
			}
			return null;
		} catch (Exception e) {
			throw new DataException("Erro ao buscar RelatorioTempoGeralOperadorStatus por data.", e);
		} finally {
			close(resultSet);
		}
	}
	
	@Override
	public List<RelatorioTempoGeralOperadorStatus> buscaTodosTemposStatusOperador(String dataRelatorio, Integer idEquipe) throws DataException {
		
		ResultSet resultSet = null;
		PreparedStatement stmt = null;
				
		try {
			
		  StringBuilder sql = new StringBuilder(SELECT)
			  .append(RelatorioTempoGeralOperadorStatus.getSqlCamposRelatorioTempoGeralOperadorStatus())
			  .append(FROM).append(RelatorioTempoGeralOperadorStatus.getSqlFromRelatorioTempoGeralOperadorStatus())
			  .append(WHERE_1_1)
			  .append(" AND ")
			  .append(" convert(varchar(10), RelatorioTempoGeralOperadorStatus.data, 103) = convert(varchar(10), ? , 103) ");
			  
			  if (idEquipe != null && idEquipe != 0) {
				  sql.append(" AND ")
				  .append(" RelatorioTempoGeralOperadorStatus.id_equipe = ? ");
			  }
		  
		  	sql.append(ORDER_BY).append("RelatorioTempoGeralOperadorStatus.login_atendente");
		  
		  
		    stmt = getPreparedStatement(sql.toString());
		    stmt.setString(1, dataRelatorio);
		    
		    if (idEquipe != null && idEquipe != 0) {
		    	stmt.setInt(2, idEquipe);
		    }
			
		    stmt.execute();
			resultSet = stmt.getResultSet();

			List<RelatorioTempoGeralOperadorStatus> listaRelatorioTempoGeralOperadorStatus = new ArrayList<RelatorioTempoGeralOperadorStatus>();
			
			while (resultSet.next()) {
				RelatorioTempoGeralOperadorStatus relatorioTempoGeralOperadorStatus = RelatorioTempoGeralOperadorStatus.getRelatorioTempoGeralOperadorStatusByResultSet(resultSet);
				listaRelatorioTempoGeralOperadorStatus.add(relatorioTempoGeralOperadorStatus);
			}
			
			return listaRelatorioTempoGeralOperadorStatus;
	        
		} catch (Exception e) {
			throw new DataException("Erro ao buscar os casos fechados no dia atual",e);
		}
		
	}
	
}
