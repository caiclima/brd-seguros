package br.com.callink.cad.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import br.com.callink.cad.dao.impl.GenericCadDAO;
import br.com.callink.cad.pojo.RelatorioTempoGeralOperadorStatus;
import br.com.callink.cad.pojo.RelatorioTempoGeralOperadorSumarizado;
import br.com.callink.cad.sau.exception.DataException;

public class RelatorioTempoGeralOperadorSumarizadoDAO extends GenericCadDAO<RelatorioTempoGeralOperadorSumarizado> implements IRelatorioTempoGeralOperadorSumarizadoDAO {
	
	/**
	 * Autor:  Hermano Flávio de Moura
	 */
	private static final long serialVersionUID = -4231807853415615302L;

	public RelatorioTempoGeralOperadorSumarizadoDAO() {
		super(RelatorioTempoGeralOperadorSumarizado.class);
	}

	@Override
	public List<RelatorioTempoGeralOperadorSumarizado>  buscaTodosTemposStatusSumarizadosPorOperador(String dataRelatorio, Integer idEquipe) throws DataException {
		
		ResultSet resultSet = null;
		PreparedStatement stmt = null;
				
		try {
			
		  StringBuilder sql = new StringBuilder(SELECT)
			  .append(RelatorioTempoGeralOperadorSumarizado.getSqlCamposRelatorioTempoGeralOperadorSumarizado())
			  .append(FROM).append(RelatorioTempoGeralOperadorSumarizado.getSqlFromRelatorioTempoGeralOperadorSumarizado())
			  .append(WHERE_1_1)
			  .append(" AND ")
			  .append(" convert(varchar(10), RelatorioTempoGeralOperadorSumarizado.data, 103) = convert(varchar(10), ? , 103) ");
		  		
		  		if (equipeEnviada(idEquipe)) {
		  			sql.append(" AND ").append(" RelatorioTempoGeralOperadorSumarizado.id_equipe = ? ");
		  		}
		  		
				sql.append(ORDER_BY).append("RelatorioTempoGeralOperadorSumarizado.login_atendente");
		  
		    stmt = getPreparedStatement(sql.toString());
		    stmt.setString(1, dataRelatorio);
		    
		    if (equipeEnviada(idEquipe)){
		    	stmt.setInt(2, idEquipe);
		    }
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			List<RelatorioTempoGeralOperadorSumarizado> listaRelatorioStatusSumarizado = new ArrayList<RelatorioTempoGeralOperadorSumarizado>();

			while (resultSet.next()) {
				RelatorioTempoGeralOperadorSumarizado relatorioTempoGeralOperadorSumarizado = RelatorioTempoGeralOperadorSumarizado.getRelatorioTempoGeralOperadorSumarizadoByResultSet(resultSet);
				listaRelatorioStatusSumarizado.add(relatorioTempoGeralOperadorSumarizado);
			}
			
			return listaRelatorioStatusSumarizado;
	        
		} catch (Exception e) {
			throw new DataException("Erro ao buscar os casos fechados no dia atual",e);
		}
		
	}

	private boolean equipeEnviada(Integer equipe) {
		if (equipe != null ) {
			return true;
		} else {
			return false;
		}
	}


}
