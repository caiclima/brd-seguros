/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;

import br.com.callink.cad.dao.IAcaoDAO;
import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.pojo.AcaoComando;
import br.com.callink.cad.pojo.Comando;
import br.com.callink.cad.pojo.Util.DateUtil;
import br.com.callink.cad.sau.exception.DataException;

/**
 * 
 * @author Rogério Moreira de Andrade. [rogeriom@swb.com.br]
 */
public class AcaoDAO extends GenericCadDAO<Acao> implements IAcaoDAO {

	private static final long serialVersionUID = -3731307177918823394L;

	public AcaoDAO() {
		super(Acao.class);
	}
	
	@Override
	public void associa(AcaoComando acaoComando) throws DataException {
		try {
			Query query = getEntityManager().createNativeQuery("INSERT INTO tb_acao_comando (id_acao, id_comando) VALUES (:acao, :comando)");
            query.setParameter("acao", acaoComando.getAcao().getIdAcao());
            query.setParameter("comando", acaoComando.getComando().getIdComando());
            query.executeUpdate();
		} catch (Exception ex) {
			throw new DataException(ex);
		}
	}

	@Override
	public void associa(List<AcaoComando> acaoComando) throws DataException {
		for (AcaoComando associa : acaoComando) {
			associa(associa);
		}
	}

	@Override
	public void excluiAssociacao(AcaoComando acaoComando) throws DataException {
		try {
            Query query = getEntityManager().createNativeQuery("delete from tb_acao_comando where id_acao = :acao and id_comando = :comando");
            query.setParameter("acao", acaoComando.getAcao().getIdAcao());
            query.setParameter("comando", acaoComando.getComando().getIdComando());
            query.executeUpdate();
        } catch (Exception ex) {
            throw new DataException(ex);
        }
	}

	@Override
	public List<AcaoComando> findByComando(Comando comando) throws DataException {
		return findAcaoComando(null, comando);
	}

	@Override
	public List<AcaoComando> findByAcao(Acao acao) throws DataException {
		return findAcaoComando(acao, null);
	}

	@Override
	public List<AcaoComando> find(Acao acao, Comando comando) throws DataException {
		return findAcaoComando(acao, comando);
	}

	@Override
	public List<AcaoComando> findAllAcaoComando() throws DataException {
		return findAcaoComando(null, null);
	}

	@Override
	public List<AcaoComando> findAllAcaoComandoAtivos() throws DataException {
		return getAcaoComandoAtivos(null);
	}

	@Override
	public List<AcaoComando> findByAcaoAcaoComandoAtivos(Acao acao) throws DataException {
		return getAcaoComandoAtivos(acao);
	}

	private List<AcaoComando> getAcaoComandoAtivos(Acao acao) throws DataException {
		List<AcaoComando> acoesComando = new ArrayList<AcaoComando>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder();
			select.append(SELECT);
			select.append(AcaoComando.getSqlCamposAcaoComando());
			select.append(", ");
			select.append(Acao.getSqlCamposAcao());
			select.append(", ");
			select.append(Comando.getSqlCamposComando());
			select.append(FROM);
			select.append(AcaoComando.getSqlFromAcaoComando());
			select.append(", ");
			select.append(Acao.getSqlFromAcao());
			select.append(", ");
			select.append(Comando.getSqlFromComando());
			select.append(WHERE_1_1);
	
			if (acao != null) {
				select.append(" AND Acao.id_acao = ? ");
			}
	
			select.append(" AND Acao.id_acao = AcaoComando.id_acao AND Comando.id_comando = AcaoComando.id_comando ");
			select.append(" AND Acao.flag_ativo = 1 and Comando.flag_ativo = 1 ");
			select.append(" ORDER BY AcaoComando.id_acao_comando ASC ");
	
			stmt = getPreparedStatement(select.toString());
			
			if (acao != null) {
				stmt.setInt(1, acao.getIdAcao());
			}
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null) {
				while (resultSet.next()) {
					AcaoComando acaoComando = AcaoComando.getAcaoComandoByResultSet(resultSet);
					acaoComando.setAcao(Acao.getAcaoByResultSet(resultSet));
					acaoComando.setComando(Comando.getComandoByResultSet(resultSet));
					acoesComando.add(acaoComando);
				}
			}
		} catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		return acoesComando;
	}

	@Override
	public List<AcaoComando> findAcaoComando(Acao acao, Comando comando) throws DataException {
		List<AcaoComando> acoesComando = new ArrayList<AcaoComando>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(AcaoComando.getSqlCamposAcaoComando())
				.append(FROM)
				.append(AcaoComando.getSqlFromAcaoComando())
				.append(WHERE_1_1);

			boolean isAcao = acao != null && acao.getIdAcao() != null;
			boolean isComando = comando != null && comando.getIdComando() != null;

			if (isAcao && !isComando) {
				select.append(" AND AcaoComando.ID_ACAO = ? ");
			} else if (!isAcao && isComando) {
				select.append(" AND AcaoComando.ID_COMANDO = ? ");
			} else if (isAcao && isComando) {
				select.append(" AND AcaoComando.ID_ACAO = ? ");
				select.append(" AND AcaoComando.ID_COMANDO = ? ");
			}
			select.append(" ORDER BY AcaoComando.ID_ACAO_COMANDO ");
			
			stmt = getPreparedStatement(select.toString());
			
			if (isAcao && !isComando) {
				stmt.setInt(1, acao.getIdAcao());
			} else if (!isAcao && isComando) {
				stmt.setInt(1, comando.getIdComando());
			} else if (isAcao && isComando) {
				stmt.setInt(1, acao.getIdAcao());
				stmt.setInt(2, comando.getIdComando());
			}
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					AcaoComando acaoComando = AcaoComando.getAcaoComandoByResultSet(resultSet);
					acoesComando.add(acaoComando);
				}
			}
		} catch (SQLException ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return acoesComando;
	}
	
	@Override
	public Acao findByNome(Acao acao) throws DataException{
		Acao result = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Acao.getSqlCamposAcao())
				.append(FROM)
				.append(Acao.getSqlFromAcao())
				.append(" WHERE Acao.NOME = ? ");
			
			stmt = getPreparedStatement(select.toString());
			stmt.setString(1, acao.getNome());
			stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null && resultSet.next()) {
				result = Acao.getAcaoByResultSet(resultSet);
			}
		} catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		return result;
	}
	
	@Override
	public List<Acao> findAtivos(String order) throws DataException {
		List<Acao> acoes = new ArrayList<Acao>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Acao.getSqlCamposAcao())
				.append(FROM)
				.append(Acao.getSqlFromAcao())
				.append(WHERE)
				.append(" Acao.FLAG_ATIVO = 1 ");

			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					Acao acao = Acao.getAcaoByResultSet(resultSet);
					acoes.add(acao);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return acoes;
	}
	
	@Override
	public Acao findByPk(Object id) throws DataException {
		Acao result = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Acao.getSqlCamposAcao())
				.append(FROM)
				.append(Acao.getSqlFromAcao())
				.append(" WHERE Acao.ID_ACAO = ? ");
			
			stmt = getPreparedStatement(select.toString());
			
			Acao acao = (Acao) id;
			
			stmt.setInt(1, acao.getIdAcao());
			
			stmt.execute();
			
			resultSet = stmt.getResultSet();
			if (resultSet != null && resultSet.next()) {
				result = Acao.getAcaoByResultSet(resultSet);
			}
		} catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		return result;
	}
	
	@Override
	public List<Acao> findByExample(Acao example) throws DataException {
		return findByExample(example, null);
	}
	
	@Override
	public List<Acao> findByExample(Acao example, String order) throws DataException {
		List<Acao> acoes = new ArrayList<Acao>();
		int index = 0;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Acao.getSqlCamposAcao())
				.append(FROM)
				.append(Acao.getSqlFromAcao())
				.append(WHERE_1_1);

			if (example.getIdAcao() != null) {
				select.append(" AND Acao.ID_ACAO = ? ");
			}
			if (example.getNome() != null && !example.getNome().isEmpty()) {
				select.append(" AND Acao.NOME like ? ");
			}
			if (example.getDataCriacao() != null) {
				select.append(" AND Acao.DATA_CRIACAO BETWEEN ? AND ? ");
			}
			if (example.getDescricao() != null && !example.getDescricao().isEmpty()) {
				select.append(" AND Acao.DESCRICAO = ? ");
			}
			if (example.getFlagAtivo() != null) {
				select.append(" AND Acao.FLAG_ATIVO = ? ");
			}
			if (example.getUrlPage() != null && !example.getUrlPage().isEmpty()) {
				select.append(" AND Acao.URL_PAGE = ? ");
			}
			if (example.getLoginUsuario() != null && !example.getLoginUsuario().isEmpty()) {
				select.append(" AND Acao.LOGIN_USUARIO = ? ");
			}
			
			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			if (example.getIdAcao() != null) {
				stmt.setInt(++index, example.getIdAcao());
			}
			if (example.getNome() != null && !example.getNome().isEmpty()) {
				stmt.setString(++index, new StringBuilder(example.getNome()).append("%").toString());
			}
			if (example.getDataCriacao() != null) {
				Date dataInicio = DateUtil.dataInicioDia(example.getDataCriacao());
				Date dataFim = DateUtil.dataFimDia(example.getDataCriacao());
				stmt.setDate(++index, new java.sql.Date(dataInicio.getTime()));
				stmt.setDate(++index, new java.sql.Date(dataFim.getTime()));
			}
			if (example.getDescricao() != null && !example.getDescricao().isEmpty()) {
				stmt.setString(++index, example.getDescricao());
			}
			if (example.getFlagAtivo() != null) {
				stmt.setBoolean(++index, example.getFlagAtivo());
			}
			if (example.getUrlPage() != null && !example.getUrlPage().isEmpty()) {
				stmt.setString(++index, example.getUrlPage());
			}
			if (example.getLoginUsuario() != null && !example.getLoginUsuario().isEmpty()) {
				stmt.setString(++index, example.getLoginUsuario());
			}
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					Acao acao = Acao.getAcaoByResultSet(resultSet);
					acoes.add(acao);
				}
			}
		} catch (SQLException ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return acoes;
	}
	
}
