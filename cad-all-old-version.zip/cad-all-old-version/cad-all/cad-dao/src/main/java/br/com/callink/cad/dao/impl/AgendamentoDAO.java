package br.com.callink.cad.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.com.callink.cad.dao.IAgendamentoDAO;
import br.com.callink.cad.pojo.Agendamento;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.sau.exception.DataException;

/**
 *
 * @author Rogério Moreira de Andrade. [rogeriom@swb.com.br]
 */
public class AgendamentoDAO extends GenericCadDAO<Agendamento> implements IAgendamentoDAO {

	private static final long serialVersionUID = 135536824132905896L;

	public AgendamentoDAO() {
		super(Agendamento.class);
	}
	
	@Override
	public List<Agendamento> buscaPeloCaso(Caso caso) throws DataException{
		List<Agendamento> list = new ArrayList<Agendamento>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Agendamento.getSqlCamposAgendamento())
				.append(FROM)
				.append(Agendamento.getSqlFromAgendamento())
				.append(" WHERE Agendamento.ID_CASO = ? ")
				.append(" ORDER BY Agendamento.DATA_CADASTRO DESC ");

			stmt = getPreparedStatement(select.toString());

			stmt.setInt(1, caso.getIdCaso());

			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					Agendamento agendamento = Agendamento.getAgendamentoByResultSet(resultSet);
					list.add(agendamento);
				}
			}
		} catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		return list;
	}
	
	@Override
	public List<Agendamento> buscaAtivosPeloCaso(Caso caso) throws DataException{
		List<Agendamento> list = new ArrayList<Agendamento>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Agendamento.getSqlCamposAgendamento())
				.append(FROM)
				.append(Agendamento.getSqlFromAgendamento())
				.append(" WHERE Agendamento.ID_CASO = ? ")
				.append(" AND Agendamento.FLAG_ATIVO = 1 ")
				.append(" ORDER BY Agendamento.DATA_CADASTRO DESC ");

			stmt = getPreparedStatement(select.toString());

			stmt.setInt(1, caso.getIdCaso());

			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					Agendamento agendamento = Agendamento.getAgendamentoByResultSet(resultSet);
					list.add(agendamento);
				}
			}
		} catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		return list;
	}
	
	@Override
	public List<Agendamento> findAtivos(String order) throws DataException {
		List<Agendamento> agendamentos = new ArrayList<Agendamento>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Agendamento.getSqlCamposAgendamento())
				.append(FROM)
				.append(Agendamento.getSqlFromAgendamento())
				.append(WHERE)
				.append(" Agendamento.FLAG_ATIVO = 1 ");

			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					Agendamento agendamento = Agendamento.getAgendamentoByResultSet(resultSet);
					agendamentos.add(agendamento);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return agendamentos;
	}
	
	@Override
	public Agendamento findByPk(Object id) throws DataException {
		Agendamento result = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Agendamento.getSqlCamposAgendamento())
				.append(", ")
				.append(Caso.getSqlCamposCaso())
				.append(FROM)
				.append(Agendamento.getSqlFromAgendamento())
				.append(INNER_JOIN).append(Caso.getSqlFromCaso())
				.append(" ON Agendamento.ID_CASO = Caso.ID_CASO ")
				.append(" WHERE Agendamento.ID_AGENDAMENTO = ? ");
			
			stmt = getPreparedStatement(select.toString());
			
			Agendamento agendamento = (Agendamento) id;
			
			stmt.setInt(1, agendamento.getIdAgendamento());
			
			stmt.execute();
			
			resultSet = stmt.getResultSet();
			if (resultSet != null && resultSet.next()) {
				result = Agendamento.getAgendamentoByResultSet(resultSet);
				result.setCaso(Caso.getCasoByResultSet(resultSet));
			}
		} catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		return result;
	}
}
