package br.com.callink.cad.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.com.callink.cad.dao.IAnexoDAO;
import br.com.callink.cad.pojo.Anexo;
import br.com.callink.cad.pojo.GrupoAnexo;
import br.com.callink.cad.sau.exception.DataException;

/**
 * 
 * @author Ednaldo Caic [ednando@swb.com.br]
 */
public class AnexoDAO extends GenericCadDAO<Anexo> implements IAnexoDAO {

	private static final long serialVersionUID = 679148651908579540L;

	public AnexoDAO() {
		super(Anexo.class);
	}
	
	@Override
    public List<Anexo> buscaPorGrupoAnexo(GrupoAnexo grupoAnexo) throws DataException{
		List<Anexo> list = new ArrayList<Anexo>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Anexo.getSqlCamposAnexo())
				.append(FROM)
				.append(Anexo.getSqlFromAnexo())
				.append(" WHERE Anexo.ID_GRUPO_ANEXO = ? ");

			stmt = getPreparedStatement(select.toString());

			stmt.setInt(1, grupoAnexo.getIdGrupoAnexo());

			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					Anexo anexo = Anexo.getAnexoByResultSet(resultSet);
					list.add(anexo);
				}
			}
		} catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		return list;
    }
	
	@Override
	public Anexo findByPk(Object id) throws DataException {
		Anexo result = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Anexo.getSqlCamposAnexo())
				.append(", ")
				.append(GrupoAnexo.getSqlCamposGrupoAnexo())
				.append(FROM)
				.append(Anexo.getSqlFromAnexo())
				.append(LEFT_JOIN).append(GrupoAnexo.getSqlFromGrupoAnexo())
				.append(" ON Anexo.ID_GRUPO_ANEXO = GrupoAnexo.ID_GRUPO_ANEXO ")
				.append(" WHERE Anexo.ID_ANEXO = ? ");
			
			stmt = getPreparedStatement(select.toString());
			
			Anexo anexo = (Anexo) id;
			
			stmt.setInt(1, anexo.getIdAnexo());
			
			stmt.execute();
			
			resultSet = stmt.getResultSet();
			if (resultSet != null && resultSet.next()) {
				result = Anexo.getAnexoByResultSet(resultSet);
				result.setGrupoAnexo(GrupoAnexo.getGrupoAnexoByResultSet(resultSet));
			}
		} catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		return result;
	}
    
}
