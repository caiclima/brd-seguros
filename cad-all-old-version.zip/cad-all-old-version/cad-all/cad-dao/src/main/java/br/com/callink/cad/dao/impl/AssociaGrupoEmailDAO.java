package br.com.callink.cad.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import br.com.callink.cad.dao.IAssociaGrupoEmailDAO;
import br.com.callink.cad.pojo.AssociaGrupoEmail;
import br.com.callink.cad.pojo.EnderecoEmail;
import br.com.callink.cad.pojo.GrupoEmail;
import br.com.callink.cad.sau.exception.DataException;

/**
 *
 * @author Luiz Gustavo (luizgf@swb.com.br)
 */
public class AssociaGrupoEmailDAO extends GenericCadDAO<AssociaGrupoEmail> implements IAssociaGrupoEmailDAO {

	private static final long serialVersionUID = 7929523424839321832L;

	public AssociaGrupoEmailDAO() {
		super(AssociaGrupoEmail.class);
	}
	
    @Override
    public void save(AssociaGrupoEmail grupoEmail) throws DataException {
        try {
            super.save(grupoEmail);
        } catch (DataException ex) {
            throw new DataException("Não foi possivel salvar esta associaçao.",ex);
        }
    }
    
	@Override
    public List<AssociaGrupoEmail> findByGrupoEmailEnderecoEmail(GrupoEmail grupoEmail, EnderecoEmail enderecoEmail) throws DataException {
    	List<AssociaGrupoEmail> list = new ArrayList<AssociaGrupoEmail>();
    	int index = 0;
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(AssociaGrupoEmail.getSqlCamposAssociaGrupoEmail())
				.append(",")
				.append(GrupoEmail.getSqlCamposGrupoEmail())
				.append(",")
				.append(EnderecoEmail.getSqlCamposEnderecoEmail())
				.append(FROM)
				.append(AssociaGrupoEmail.getSqlFromAssociaGrupoEmail())
				.append(INNER_JOIN).append(GrupoEmail.getSqlFromGrupoEmail())
				.append(" ON (AssociaGrupoEmail.ID_GRUPO_EMAIL = GrupoEmail.ID_GRUPO_EMAIL) ")
				.append(INNER_JOIN).append(EnderecoEmail.getSqlFromEnderecoEmail())
				.append(" ON (AssociaGrupoEmail.ID_ENDERECO_EMAIL = EnderecoEmail.ID_ENDERECO_EMAIL) ")
				.append(WHERE_1_1);

			if (grupoEmail != null && grupoEmail.getIdGrupoEmail() != null) {
				select.append(" AND AssociaGrupoEmail.ID_GRUPO_EMAIL = ? ");
			}
			if (enderecoEmail != null && enderecoEmail.getIdEnderecoEmail() != null) {
				select.append(" AND AssociaGrupoEmail.ID_ENDERECO_EMAIL = ? ");
			}
			
			stmt = getPreparedStatement(select.toString());
			
			if (grupoEmail != null && grupoEmail.getIdGrupoEmail() != null) {
				stmt.setInt(++index, grupoEmail.getIdGrupoEmail());
			}
			if (enderecoEmail != null && enderecoEmail.getIdEnderecoEmail() != null) {
				stmt.setInt(++index, enderecoEmail.getIdEnderecoEmail());
			}
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					AssociaGrupoEmail associaGrupoEmail = AssociaGrupoEmail.getAssociaGrupoEmailByResultSet(resultSet);
					associaGrupoEmail.setGrupoEmail(GrupoEmail.getGrupoEmailByResultSet(resultSet));
					associaGrupoEmail.setEnderecoEmail(EnderecoEmail.getEnderecoEmailByResultSet(resultSet));
					list.add(associaGrupoEmail);
				}
			}
		} catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		return list;
    }
    
    @Override
    public void deletaAssociacoes(GrupoEmail grupoEmail) throws DataException {
    	try {
            Query query = getEntityManager().createNativeQuery("delete from tb_associa_grupo_email where id_grupo_email =  :grupoEmail");
            query.setParameter("grupoEmail", grupoEmail.getIdGrupoEmail());
            query.executeUpdate();
        } catch (Exception ex) {
            throw new DataException(ex);
        }
    }
    
    @Override
    public AssociaGrupoEmail findByPk(Object id) throws DataException {
    	AssociaGrupoEmail result = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(AssociaGrupoEmail.getSqlCamposAssociaGrupoEmail())
				.append(", ")
				.append(EnderecoEmail.getSqlCamposEnderecoEmail())
				.append(", ")
				.append(GrupoEmail.getSqlCamposGrupoEmail())
				.append(FROM)
				.append(AssociaGrupoEmail.getSqlFromAssociaGrupoEmail())
				.append(LEFT_JOIN).append(EnderecoEmail.getSqlFromEnderecoEmail())
				.append(" ON AssociaGrupoEmail.ID_ENDERECO_EMAIL = EnderecoEmail.ID_ENDERECO_EMAIL ")
				.append(LEFT_JOIN).append(GrupoEmail.getSqlFromGrupoEmail())
				.append(" ON AssociaGrupoEmail.ID_GRUPO_EMAIL = GrupoEmail.ID_GRUPO_EMAIL ")
				.append(" WHERE AssociaGrupoEmail.ID_ASSOCIA_GRUPO_EMAIL = ? ");
			
			stmt = getPreparedStatement(select.toString());
			
			AssociaGrupoEmail associaGrupoEmail = (AssociaGrupoEmail) id;
			
			stmt.setInt(1, associaGrupoEmail.getIdAssociaGrupoEmail());
			
			stmt.execute();
			
			resultSet = stmt.getResultSet();
			if (resultSet != null && resultSet.next()) {
				result = AssociaGrupoEmail.getAssociaGrupoEmailByResultSet(resultSet);
				result.setEnderecoEmail(EnderecoEmail.getEnderecoEmailByResultSet(resultSet));
				result.setGrupoEmail(GrupoEmail.getGrupoEmailByResultSet(resultSet));
			}
		} catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		return result;
	}
    
    @Override
	public List<AssociaGrupoEmail> findByExample(AssociaGrupoEmail example) throws DataException {
		return findByExample(example, null);
	}
	
	@Override
	public List<AssociaGrupoEmail> findByExample(AssociaGrupoEmail example, String order) throws DataException {
		List<AssociaGrupoEmail> associacoesGrupoEmail = new ArrayList<AssociaGrupoEmail>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		int index = 0;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(AssociaGrupoEmail.getSqlCamposAssociaGrupoEmail())
				.append(", ")
				.append(EnderecoEmail.getSqlCamposEnderecoEmail())
				.append(", ")
				.append(GrupoEmail.getSqlCamposGrupoEmail())
				.append(FROM)
				.append(AssociaGrupoEmail.getSqlFromAssociaGrupoEmail())
				.append(LEFT_JOIN).append(EnderecoEmail.getSqlFromEnderecoEmail())
				.append(" ON AssociaGrupoEmail.ID_ENDERECO_EMAIL = EnderecoEmail.ID_ENDERECO_EMAIL ")
				.append(LEFT_JOIN).append(GrupoEmail.getSqlFromGrupoEmail())
				.append(" ON AssociaGrupoEmail.ID_GRUPO_EMAIL = GrupoEmail.ID_GRUPO_EMAIL ")
				.append(WHERE_1_1);

			if(example!= null){
			
				if (example.getIdAssociaGrupoEmail() != null) {
					select.append(" AND AssociaGrupoEmail.ID_ASSOCIA_GRUPO_EMAIL = ? ");
				}
				if (example.getEnderecoEmail() != null && example.getEnderecoEmail().getIdEnderecoEmail() != null) {
					select.append(" AND AssociaGrupoEmail.ID_ENDERECO_EMAIL = ? ");
				}
				if (example.getGrupoEmail() != null && example.getGrupoEmail().getIdGrupoEmail() != null) {
					select.append(" AND AssociaGrupoEmail.ID_GRUPO_EMAIL = ? ");
				}
			}
			
			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			if(example!= null){
			
				if (example.getIdAssociaGrupoEmail() != null) {
					stmt.setInt(++index, example.getIdAssociaGrupoEmail());
				}
				if (example.getEnderecoEmail() != null && example.getEnderecoEmail().getIdEnderecoEmail() != null) {
					stmt.setInt(++index, example.getEnderecoEmail().getIdEnderecoEmail());
				}
				if (example.getGrupoEmail() != null && example.getGrupoEmail().getIdGrupoEmail() != null) {
					stmt.setInt(++index, example.getGrupoEmail().getIdGrupoEmail());
				}
			}
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					AssociaGrupoEmail associaGrupoEmail = AssociaGrupoEmail.getAssociaGrupoEmailByResultSet(resultSet);
					associaGrupoEmail.setEnderecoEmail(EnderecoEmail.getEnderecoEmailByResultSet(resultSet));
					associaGrupoEmail.setGrupoEmail(GrupoEmail.getGrupoEmailByResultSet(resultSet));
					associacoesGrupoEmail.add(associaGrupoEmail);
				}
			}
		} catch (SQLException ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return associacoesGrupoEmail;
	}
    
}
