/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import br.com.callink.cad.dao.IAtendenteDAO;
import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.pojo.Equipe;
import br.com.callink.cad.pojo.EquipeFila;
import br.com.callink.cad.pojo.Perfil;
import br.com.callink.cad.pojo.Util.DateUtil;
import br.com.callink.cad.sau.exception.DataException;

/**
 *
 * @author Rogério Moreira de Andrade. [rogeriom@swb.com.br]
 */
public class AtendenteDAO extends GenericCadDAO<Atendente> implements IAtendenteDAO {

	private static final long serialVersionUID = -3027080156872925172L;

	public AtendenteDAO() {
		super(Atendente.class);
	}
	
    @Override
    public Atendente findByLogin(String login) throws DataException {
    	Atendente atendente = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Atendente.getSqlCamposAtendente())
				.append(",")
				.append(Equipe.getSqlEquipe())
				.append(FROM)
				.append(Atendente.getSqlFromAtendente())
				.append(LEFT_JOIN).append(Equipe.getSqlFromEquipe())
				.append(" ON (Atendente.ID_EQUIPE = Equipe.ID_EQUIPE) ")
				.append(" WHERE Atendente.LOGIN = ? ");

			stmt = getPreparedStatement(select.toString());

			stmt.setString(1, login);

			stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null && resultSet.next()) {
				atendente = Atendente.getAtendenteByResultSet(resultSet);
				atendente.setEquipe(Equipe.getEquipeByResultSet(resultSet));
			}
		} catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		return atendente;
    }

    @Override
    public List<Atendente> buscaPorFila(ConfiguracaoFila configuracaoFila) throws DataException {
    	List<Atendente> atendenteList = new ArrayList<Atendente>();
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
    	try {
            StringBuilder sql = new StringBuilder()
            	.append(SELECT)
            	.append(Atendente.getSqlCamposAtendente())
            	.append(FROM)
                .append(ConfiguracaoFila.getSqlFromConfiguracaoFila())
                .append(", ")
                .append(EquipeFila.getSqlFromEquipeFila())
                .append(", ")
                .append(Equipe.getSqlFromEquipe())
                .append(", ")
                .append(Atendente.getSqlFromAtendente())
                .append(" where ConfiguracaoFila.id_configuracao_fila = EquipeFila.id_configuracao_fila ")
                .append(" 		and Equipe.id_equipe = EquipeFila.id_equipe")
                .append(" 		and Atendente.id_equipe = Equipe.id_equipe")
                .append(" 		and ConfiguracaoFila.id_configuracao_fila = ? order by Atendente.login asc");

            stmt = getPreparedStatement(sql.toString());
			
			stmt.setInt(1, configuracaoFila.getIdConfiguracaoFila());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null) {
				while (resultSet.next()) {
					Atendente atendente = Atendente.getAtendenteByResultSet(resultSet);
					atendenteList.add(atendente);
				}
			}
        } catch (Exception e) {
            throw new DataException(e);
        } finally {
        	super.close(resultSet);
        }
    	return atendenteList;
    }

    @Override
    public List<Atendente> buscaAtivosQueNaoPossuemFila() throws DataException {
    	List<Atendente> atendenteList = new ArrayList<Atendente>();
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
    	try {
            StringBuilder sql = new StringBuilder()
            	.append(SELECT)
            	.append(Atendente.getSqlCamposAtendente())
            	.append(",")
            	.append(Perfil.getSqlCamposPerfil())
            	.append(FROM)
            	.append(Atendente.getSqlFromAtendente())
            	.append(INNER_JOIN).append(Perfil.getSqlFromPerfil())
            	.append(" ON (Atendente.ID_PERFIL = Perfil.ID_PERFIL) ")
            	.append(WHERE).append(" Atendente.FLAG_ATIVO = 1 ")
                .append(" AND Atendente.ID_EQUIPE is null ")
                .append(" ORDER BY Atendente.LOGIN ");

            stmt = getPreparedStatement(sql.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null) {
				while (resultSet.next()) {
					Atendente atendente = Atendente.getAtendenteByResultSet(resultSet);
					atendente.setPerfil(Perfil.getPerfilByResultSet(resultSet));
					atendenteList.add(atendente);
				}
			}
        } catch (Exception e) {
            throw new DataException(e);
        } finally {
        	super.close(resultSet);
        }
    	return atendenteList;
    }

    @Override
    public Atendente findSupervisor(Atendente atendente, Integer idPerfilSupervisor) throws DataException {
        Atendente atendenteResult = null;
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
    	try {
            StringBuilder sql = new StringBuilder(SELECT)
            	.append(Atendente.getSqlCamposAtendente())
            	.append(",")
            	.append(Equipe.getSqlEquipe())
            	.append(",")
            	.append(Perfil.getSqlCamposPerfil())
            	.append(FROM)
            	.append(Atendente.getSqlFromAtendente())
            	.append(INNER_JOIN).append(Equipe.getSqlFromEquipe())
            	.append(" ON (Atendente.ID_EQUIPE = Equipe.ID_EQUIPE) ")
            	.append(INNER_JOIN).append(Perfil.getSqlFromPerfil())
            	.append(" ON (Atendente.ID_PERFIL = Perfil.ID_PERFIL) ")
            	.append(WHERE).append(" Atendente.ID_EQUIPE = ? AND Atendente.ID_PERFIL = ? ");

            stmt = getPreparedStatement(sql.toString());
            
            stmt.setInt(1, atendente.getEquipe().getIdEquipe());
            stmt.setInt(2, idPerfilSupervisor);
			
            stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null && resultSet.next()) {
				atendenteResult = Atendente.getAtendenteByResultSet(resultSet);
				atendenteResult.setEquipe(Equipe.getEquipeByResultSet(resultSet));
				atendenteResult.setPerfil(Perfil.getPerfilByResultSet(resultSet));
			}
        } catch (Exception e) {
            throw new DataException(e);
        } finally {
        	super.close(resultSet);
        }
    	return atendenteResult;
    }
    
    @Override
    public List<Atendente> buscaPorConfiguracaoFilaList(List<ConfiguracaoFila> configuracaoFilaList) throws DataException {
        List<Atendente> atendenteList = new ArrayList<Atendente>();
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
    	try {
            StringBuilder sql = new StringBuilder()
            	.append(SELECT)
            	.append(Atendente.getSqlCamposAtendente())
            	.append(",").append(Equipe.getSqlEquipe())
            	.append(",").append(EquipeFila.getSqlCamposEquipeFila())
            	.append(FROM).append(Atendente.getSqlFromAtendente())
                .append(INNER_JOIN).append(Equipe.getSqlFromEquipe())
                .append(" ON Atendente.ID_EQUIPE = Equipe.ID_EQUIPE ")
                .append(INNER_JOIN).append(EquipeFila.getSqlFromEquipeFila())
                .append(" ON Equipe.ID_EQUIPE = EquipeFila.ID_EQUIPE ")
                .append(WHERE_1_1);
            
            StringBuilder configFilaIn = new StringBuilder();
            for (int i = 0; i < configuracaoFilaList.size(); i++) {
            	if (i != 0) {
            		configFilaIn.append(", ");
            	}
            	configFilaIn.append(configuracaoFilaList.get(i).getIdConfiguracaoFila());
            }
            
            sql.append(String.format(" AND EquipeFila.ID_CONFIGURACAO_FILA in (%s) ", configFilaIn.toString()))
               .append(" ORDER BY Atendente.LOGIN ");

            stmt = getPreparedStatement(sql.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null) {
				while (resultSet.next()) {
					Atendente atendente = Atendente.getAtendenteByResultSet(resultSet);
					Equipe equipe = Equipe.getEquipeByResultSet(resultSet);
					atendente.setEquipe(equipe);
					atendenteList.add(atendente);
				}
			}
        } catch (Exception e) {
            throw new DataException(e);
        } finally {
        	super.close(resultSet);
        }
    	return atendenteList;
    }
    
    @Override
    public List<Atendente> buscaPorEquipeList(List<Equipe> equipeList) throws DataException {
    	List<Atendente> atendenteList = new ArrayList<Atendente>();
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
    	try {
            StringBuilder sql = new StringBuilder()
            	.append(SELECT)
            	.append(Atendente.getSqlCamposAtendente())
            	.append(", ")
            	.append(Equipe.getSqlEquipe())
            	.append(FROM)
            	.append(Atendente.getSqlFromAtendente())
                .append(INNER_JOIN).append(Equipe.getSqlFromEquipe())
                .append(" ON Atendente.ID_EQUIPE = Equipe.ID_EQUIPE ")
                .append(WHERE_1_1);
            
            StringBuilder equipeIn = new StringBuilder();
            for (int i = 0; i < equipeList.size(); i++) {
            	if (i != 0) {
            		equipeIn.append(", ");
            	}
            	equipeIn.append(equipeList.get(i).getIdEquipe());
            }
            
            sql.append(String.format("   AND Atendente.ID_EQUIPE in (%s) ", equipeIn.toString()))
               .append(" ORDER BY Atendente.LOGIN ");

            stmt = getPreparedStatement(sql.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null) {
				while (resultSet.next()) {
					Atendente atendente = Atendente.getAtendenteByResultSet(resultSet);
					atendente.setEquipe(Equipe.getEquipeByResultSet(resultSet));
					atendenteList.add(atendente);
				}
			}
        } catch (Exception e) {
            throw new DataException(e);
        } finally {
        	super.close(resultSet);
        }
    	return atendenteList;
    }
    
    
	@Override
    public List<Atendente> buscaAtendentesPorEquipe(Equipe equipe) throws DataException {
		List<Atendente> atendenteList = new ArrayList<Atendente>();
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
    	try {
            StringBuilder sql = new StringBuilder()
            	.append(SELECT)
            	.append(Atendente.getSqlCamposAtendente())
            	.append(", ")
            	.append(Equipe.getSqlEquipe())
            	.append(FROM)
            	.append(Atendente.getSqlFromAtendente())
                .append(INNER_JOIN).append(Equipe.getSqlFromEquipe())
                .append(" ON Atendente.ID_EQUIPE = Equipe.ID_EQUIPE ")
                .append(" WHERE Atendente.ID_EQUIPE = ? ")
                .append(" ORDER BY Atendente.NOME ");

            stmt = getPreparedStatement(sql.toString());
            
            stmt.setInt(1, equipe.getIdEquipe());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null) {
				while (resultSet.next()) {
					Atendente atendente = Atendente.getAtendenteByResultSet(resultSet);
					atendente.setEquipe(Equipe.getEquipeByResultSet(resultSet));
					atendenteList.add(atendente);
				}
			}
        } catch (Exception e) {
            throw new DataException(e);
        } finally {
        	super.close(resultSet);
        }
    	return atendenteList;
    }
	
	@Override
	public List<Atendente> findAtivos(String order) throws DataException {
		List<Atendente> atendentes = new ArrayList<Atendente>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Atendente.getSqlCamposAtendente())
				.append(FROM)
				.append(Atendente.getSqlFromAtendente())
				.append(WHERE)
				.append(" Atendente.FLAG_ATIVO = 1 ");

			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					Atendente atendente = Atendente.getAtendenteByResultSet(resultSet);
					atendentes.add(atendente);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return atendentes;
	}
	
	@Override
	public List<Atendente> findByExample(Atendente example) throws DataException {
		List<Atendente> atendentes = new ArrayList<Atendente>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		int index = 0;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Atendente.getSqlCamposAtendente())
				.append(FROM)
				.append(Atendente.getSqlFromAtendente())
				.append(WHERE_1_1);

			if (example.getIdAtendente() != null) {
				select.append(" AND Atendente.ID_ATENDENTE = ? ");
			}
			if (example.getLogin() != null && !example.getLogin().isEmpty()) {
				select.append(" AND Atendente.LOGIN like ? ");
			}
			if (example.getDataCriacao() != null) {
				select.append(" AND Atendente.DATA_CRIACAO BETWEEN ? AND ? ");
			}
			if (example.getFlagAtivo() != null) {
				select.append(" AND Atendente.FLAG_ATIVO = ? ");
			}
			if (example.getPerfil() != null && example.getPerfil().getIdPerfil() != null) {
				select.append(" AND Atendente.ID_PERFIL = ? ");
			}
			if (example.getEquipe() != null && example.getEquipe().getIdEquipe() != null) {
				select.append(" AND Atendente.ID_EQUIPE = ? ");
			}
			if (example.getNome() != null && !example.getNome().isEmpty()) {
				select.append(" AND Atendente.NOME like ? ");
			}
			if (example.getTelefone() != null && !example.getTelefone().isEmpty()) {
				select.append(" AND Atendente.TELEFONE = ? ");
			}
			if (example.getRamal() != null && !example.getRamal().isEmpty()) {
				select.append(" AND Atendente.RAMAL = ? ");
			}
			if (example.getFax() != null && !example.getFax().isEmpty()) {
				select.append(" AND Atendente.FAX = ? ");
			}
			if (example.getIdTelefonia() != null && !example.getIdTelefonia().isEmpty()) {
				select.append(" AND Atendente.ID_TELEFONIA = ? ");
			}
			
			stmt = getPreparedStatement(select.toString());
			
			if (example.getIdAtendente() != null) {
				stmt.setInt(++index, example.getIdAtendente());
			}
			if (example.getLogin() != null && !example.getLogin().isEmpty()) {
				stmt.setString(++index, new StringBuilder(example.getLogin()).append("%").toString());
			}
			if (example.getDataCriacao() != null) {
				Date dataInicio = DateUtil.dataInicioDia(example.getDataCriacao());
				Date dataFim = DateUtil.dataFimDia(example.getDataCriacao());
				stmt.setDate(++index, new java.sql.Date(dataInicio.getTime()));
				stmt.setDate(++index, new java.sql.Date(dataFim.getTime()));
			}
			if (example.getFlagAtivo() != null) {
				stmt.setBoolean(++index, example.getFlagAtivo());
			}
			if (example.getPerfil() != null && example.getPerfil().getIdPerfil() != null) {
				stmt.setInt(++index, example.getPerfil().getIdPerfil());
			}
			if (example.getEquipe() != null && example.getEquipe().getIdEquipe() != null) {
				stmt.setInt(++index, example.getEquipe().getIdEquipe());
			}
			if (example.getNome() != null && !example.getNome().isEmpty()) {
				stmt.setString(++index, new StringBuilder(example.getNome()).append("%").toString());
			}
			if (example.getTelefone() != null && !example.getTelefone().isEmpty()) {
				stmt.setString(++index,example.getTelefone());
			}
			if (example.getRamal() != null && !example.getRamal().isEmpty()) {
				stmt.setString(++index,example.getRamal());
			}
			if (example.getFax() != null && !example.getFax().isEmpty()) {
				stmt.setString(++index, example.getFax());
			}
			if (example.getIdTelefonia() != null && !example.getIdTelefonia().isEmpty()) {
				stmt.setString(++index, example.getIdTelefonia());
			}
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					Atendente atendente = Atendente.getAtendenteByResultSet(resultSet);
					atendentes.add(atendente);
				}
			}
		} catch (SQLException ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return atendentes;
	}
	
	@Override
	public Atendente findByPk(Object id) throws DataException {
		Atendente result = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Atendente.getSqlCamposAtendente())
				.append(", ")
				.append(Perfil.getSqlCamposPerfil())
				.append(", ")
				.append(Equipe.getSqlEquipe())
				.append(FROM)
				.append(Atendente.getSqlFromAtendente())
				.append(INNER_JOIN).append(Perfil.getSqlFromPerfil())
				.append(" ON Atendente.ID_PERFIL = Perfil.ID_PERFIL ")
				.append(LEFT_JOIN).append(Equipe.getSqlFromEquipe())
				.append(" ON Atendente.ID_EQUIPE = Equipe.ID_EQUIPE ")
				.append(" WHERE Atendente.ID_ATENDENTE = ? ");
			
			stmt = getPreparedStatement(select.toString());
			
			Atendente atendente = (Atendente) id;
			
			stmt.setInt(1, atendente.getIdAtendente());
			
			stmt.execute();
			
			resultSet = stmt.getResultSet();
			if (resultSet != null && resultSet.next()) {
				result = Atendente.getAtendenteByResultSet(resultSet);
				result.setPerfil(Perfil.getPerfilByResultSet(resultSet));
				result.setEquipe(Equipe.getEquipeByResultSet(resultSet));
			}
		} catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		return result;
	}
	
	@Override
	public List<Atendente> findAll() throws DataException {
		return findAll(null);
	}
	
	@Override
	public List<Atendente> findAll(String order) throws DataException {
		List<Atendente> atendentes = new ArrayList<Atendente>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Atendente.getSqlCamposAtendente())
				.append(FROM)
				.append(Atendente.getSqlFromAtendente());

			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					Atendente atendente = Atendente.getAtendenteByResultSet(resultSet);
					atendentes.add(atendente);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return atendentes;
	}

	@Override
	public List<Atendente> findByPkIn(List<Integer> idsAtendentes) throws DataException {
		List<Atendente> lst = new ArrayList<Atendente>();
		ResultSet resultSet = null;
		PreparedStatement stmt = null;
		
		try {
			
			StringBuilder string = new StringBuilder(SELECT).append(Atendente.getSqlCamposAtendente()).append(FROM).append(Atendente.getSqlFromAtendente()).append(WHERE)
					.append(String.format(" Atendente.ID_ATENDENTE in (%s) ",idsAtendentes.toString().substring(1, idsAtendentes.toString().length()-1)));

			stmt = getPreparedStatement(string.toString());
			stmt.execute();
			
			resultSet = stmt.getResultSet();

			Atendente atendente;
			while (resultSet.next()) {
				atendente = Atendente.getAtendenteByResultSet(resultSet);
				lst.add(atendente);
			}
			return lst;
		} catch (Exception e) {
			throw new DataException("Erro ao buscar Status pelo id.", e);
		} finally {
			close(resultSet);
		}
	}
    
}
