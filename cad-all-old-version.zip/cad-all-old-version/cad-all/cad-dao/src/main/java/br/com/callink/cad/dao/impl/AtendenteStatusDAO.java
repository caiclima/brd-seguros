package br.com.callink.cad.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import br.com.callink.cad.dao.IAtendenteStatusDAO;
import br.com.callink.cad.pojo.AtendenteStatus;
import br.com.callink.cad.pojo.Util.DateUtil;
import br.com.callink.cad.sau.exception.DataException;

/**
 *
 * @author brunomt
 */
public class AtendenteStatusDAO extends GenericCadDAO<AtendenteStatus> implements IAtendenteStatusDAO {

	private static final long serialVersionUID = 8287154337114503666L;

	public AtendenteStatusDAO() {
		super(AtendenteStatus.class);
	}
	
    @Override
    public List<AtendenteStatus> buscaAtendenteStatusPausado() throws DataException {
        List<AtendenteStatus> atendenteStatusList = new ArrayList<AtendenteStatus>();
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
    	try {
            StringBuilder sql = new StringBuilder()
            	.append(SELECT)
            	.append(AtendenteStatus.getSqlCamposAtendenteStatus())
            	.append(FROM)
                .append(AtendenteStatus.getSqlFromAtendenteStatus())
                .append(WHERE_1_1)
                .append(" AND FLAG_ATIVO = 1 ")
                .append(" AND PAUSA_ATENDIMENTO = 1 ");

            stmt = getPreparedStatement(sql.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null) {
				while (resultSet.next()) {
					AtendenteStatus atendenteStatus = AtendenteStatus.getAtendenteStatusByResultSet(resultSet);
					atendenteStatusList.add(atendenteStatus);
				}
			}
        } catch (Exception e) {
            throw new DataException("Erro ao buscar os AtendenteStatus abertos.", e);
        } finally {
        	super.close(resultSet);
        }
    	return atendenteStatusList;
    }
    
    public List<AtendenteStatus> buscaAtendenteStatusIdToolbar(Integer idStatusToolbar) throws DataException {
    	List<AtendenteStatus> atendenteStatusList = new ArrayList<AtendenteStatus>();
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
    	try {
            StringBuilder sql = new StringBuilder()
            	.append(SELECT)
            	.append(AtendenteStatus.getSqlCamposAtendenteStatus())
            	.append(FROM)
                .append(AtendenteStatus.getSqlFromAtendenteStatus())
                .append(WHERE_1_1)
                .append(" AND ID_STATUS_TOOLBAR = ? ");

            stmt = getPreparedStatement(sql.toString());
            
            stmt.setInt(1, idStatusToolbar);
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null) {
				while (resultSet.next()) {
					AtendenteStatus atendenteStatus = AtendenteStatus.getAtendenteStatusByResultSet(resultSet);
					atendenteStatusList.add(atendenteStatus);
				}
			}
        } catch (Exception e) {
            throw new DataException("Erro ao buscar os AtendenteStatus abertos.", e);
        } finally {
        	super.close(resultSet);
        }
    	return atendenteStatusList;
    }
    
    @Override
    public AtendenteStatus findByPk(Object id) throws DataException {
    	AtendenteStatus result = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(AtendenteStatus.getSqlCamposAtendenteStatus())
				.append(FROM)
				.append(AtendenteStatus.getSqlFromAtendenteStatus())
				.append(" WHERE AtendenteStatus.ID_ATENDENTE_STATUS = ? ");
			
			stmt = getPreparedStatement(select.toString());
			
			AtendenteStatus atendenteStatus = (AtendenteStatus) id;
			
			stmt.setInt(1, atendenteStatus.getIdAtendenteStatus());
			
			stmt.execute();
			
			resultSet = stmt.getResultSet();
			if (resultSet != null && resultSet.next()) {
				result = AtendenteStatus.getAtendenteStatusByResultSet(resultSet);
			}
		} catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		return result;
	}
    
    @Override
	public List<AtendenteStatus> findByExample(AtendenteStatus example) throws DataException {
		return findByExample(example, null);
	}
	
	@Override
	public List<AtendenteStatus> findByExample(AtendenteStatus example, String order) throws DataException {
		List<AtendenteStatus> atendentesStatus = new ArrayList<AtendenteStatus>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		int index = 0;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(AtendenteStatus.getSqlCamposAtendenteStatus())
				.append(FROM)
				.append(AtendenteStatus.getSqlFromAtendenteStatus())
				.append(WHERE_1_1);

			if (example.getIdAtendenteStatus() != null) {
				select.append(" AND AtendenteStatus.ID_ATENDENTE_STATUS = ? ");
			}
			if (example.getNomeStatus() != null && !example.getNomeStatus().isEmpty()) {
				select.append(" AND AtendenteStatus.NOME_STATUS like ? ");
			}
			if (example.getDataCadastro() != null) {
				select.append(" AND AtendenteStatus.DATA_CADASTRO BETWEEN ? AND ? ");
			}
			if (example.getFlagAtivo() != null) {
				select.append(" AND AtendenteStatus.FLAG_ATIVO = ? ");
			}
			if (example.getPausaAtendimento() != null) {
				select.append(" AND AtendenteStatus.PAUSA_ATENDIMENTO = ? ");
			}
			if (example.getCorStatus() != null && !example.getCorStatus().isEmpty()) {
				select.append(" AND AtendenteStatus.COR_STATUS = ? ");
			}
			if (example.getIdStatusToolbar() != null && example.getIdStatusToolbar() != 0) {
				select.append(" AND AtendenteStatus.ID_STATUS_TOOLBAR = ? ");
			}
			
			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			if (example.getIdAtendenteStatus() != null) {
				stmt.setInt(++index, example.getIdAtendenteStatus());
			}
			if (example.getNomeStatus() != null && !example.getNomeStatus().isEmpty()) {
				stmt.setString(++index, new StringBuilder(example.getNomeStatus()).append("%").toString() );
			}
			if (example.getDataCadastro() != null) {
				Date dataInicio = DateUtil.dataInicioDia(example.getDataCadastro());
				Date dataFim = DateUtil.dataFimDia(example.getDataCadastro());
				stmt.setDate(++index, new java.sql.Date(dataInicio.getTime()));
				stmt.setDate(++index, new java.sql.Date(dataFim.getTime()));
			}
			if (example.getFlagAtivo() != null) {
				stmt.setBoolean(++index, example.getFlagAtivo());
			}
			if (example.getPausaAtendimento() != null) {
				stmt.setBoolean(++index, example.getPausaAtendimento());
			}
			if (example.getCorStatus() != null && !example.getCorStatus().isEmpty()) {
				stmt.setString(++index,example.getCorStatus());
			}
			if (example.getIdStatusToolbar() != null && example.getIdStatusToolbar() != 0) {
				stmt.setInt(++index, example.getIdStatusToolbar());
			}
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					AtendenteStatus atendenteStatus = AtendenteStatus.getAtendenteStatusByResultSet(resultSet);
					atendentesStatus.add(atendenteStatus);
				}
			}
		} catch (SQLException ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return atendentesStatus;
	}
    
}
