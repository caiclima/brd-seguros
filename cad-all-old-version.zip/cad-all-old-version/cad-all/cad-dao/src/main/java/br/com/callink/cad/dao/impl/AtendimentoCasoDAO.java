/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.com.callink.cad.dao.IAtendimentoCasoDAO;
import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.AtendimentoCaso;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.pojo.Status;
import br.com.callink.cad.sau.exception.DataException;

/**
 *
 * @author Ednaldo Caic [ednaldo@swb.com.br]
 * @since 26/12/2011
 */
public class AtendimentoCasoDAO extends GenericCadDAO<AtendimentoCaso> implements IAtendimentoCasoDAO {

	private static final long serialVersionUID = 5933011020715730789L;

	public AtendimentoCasoDAO() {
		super(AtendimentoCaso.class);
	}
	
	@Override
	public List<AtendimentoCaso> findAtendimentoCasoByCaso(Caso caso) throws DataException {
		List<AtendimentoCaso> atendimentoCasoList = new ArrayList<AtendimentoCaso>();
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
    	try {
            StringBuilder sql = new StringBuilder()
            	.append(SELECT)
            	.append(AtendimentoCaso.getSqlCamposAtendimentoCaso())
            	.append(", ")
            	.append(Caso.getSqlCamposCaso())
            	.append(FROM)
                .append(AtendimentoCaso.getSqlFromAtendimentoCaso())
                .append(INNER_JOIN).append(Caso.getSqlFromCaso())
                .append("  ON AtendimentoCaso.ID_CASO = Caso.ID_CASO ")
                .append(WHERE)
                .append("  Caso.ID_CASO = ? ")
                .append(" ORDER BY AtendimentoCaso.DATA_MARCACAO ");

            stmt = getPreparedStatement(sql.toString());
            
            stmt.setInt(1, caso.getIdCaso());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null) {
				while (resultSet.next()) {
					AtendimentoCaso atendimentoCaso = AtendimentoCaso.getAtendimentoCasoByResultSet(resultSet);
					atendimentoCaso.setCaso(Caso.getCasoByResultSet(resultSet));
					atendimentoCasoList.add(atendimentoCaso);
				}
			}
        } catch (Exception e) {
            throw new DataException(e);
        } finally {
        	super.close(resultSet);
        }
    	return atendimentoCasoList;
	}

	@Override
	public Integer findUltimaMarcacaoCaso(AtendimentoCaso atendimentoCaso) throws DataException {
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		Integer marcacao = null;
		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" select max(id_atendimento_caso) marcacao from tb_atendimento_caso with(nolock) where id_caso = ? ");
			
			stmt = getPreparedStatement(sql.toString());
            
            stmt.setInt(1, atendimentoCaso.getCaso().getIdCaso());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null && resultSet.next()) {
				marcacao = resultSet.getInt("marcacao");
			}
		} catch (Exception e) {
			throw new DataException("Erro ao buscar a marcação. ",e);
		} finally {
			super.close(resultSet);
		}
		return marcacao;
	}
	
	@Override
	public AtendimentoCaso findByPk(Object id) throws DataException {
		AtendimentoCaso result = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(AtendimentoCaso.getSqlCamposAtendimentoCaso())
				.append(", ")
				.append(Caso.getSqlCamposCaso())
				.append(", ")
				.append(Status.getSqlCamposStatus())
				.append(", ")
				.append(ConfiguracaoFila.getSqlCamposConfiguracaoFila())
				.append(", ")
				.append(Atendente.getSqlCamposAtendente())
				.append(FROM)
				.append(AtendimentoCaso.getSqlFromAtendimentoCaso())
				.append(INNER_JOIN).append(Caso.getSqlFromCaso())
				.append(" ON AtendimentoCaso.ID_CASO = Caso.ID_CASO ")
				.append(INNER_JOIN).append(Status.getSqlFromStatus())
				.append(" ON AtendimentoCaso.ID_STATUS = Status.ID_STATUS ")
				.append(INNER_JOIN).append(ConfiguracaoFila.getSqlFromConfiguracaoFila())
				.append(" ON AtendimentoCaso.ID_CONFIGURACAO_FILA = ConfiguracaoFila.ID_CONFIGURACAO_FILA ")
				.append(LEFT_JOIN).append(Atendente.getSqlFromAtendente())
				.append(" ON AtendimentoCaso.ID_ATENDENTE = Atendente.ID_ATENDENTE ")
				.append(" WHERE AtendimentoCaso.ID_ATENDIMENTO_CASO = ? ");
			
			stmt = getPreparedStatement(select.toString());
			
			AtendimentoCaso atendimentoCaso = (AtendimentoCaso) id;
			
			stmt.setInt(1, atendimentoCaso.getIdAtendimentoCaso());
			
			stmt.execute();
			
			resultSet = stmt.getResultSet();
			if (resultSet != null && resultSet.next()) {
				result = AtendimentoCaso.getAtendimentoCasoByResultSet(resultSet);
				result.setCaso(Caso.getCasoByResultSet(resultSet));
				result.setStatus(Status.getStatusByResultSet(resultSet));
				result.setConfiguracaoFila(ConfiguracaoFila.getConfiguracaoFilaByResultSet(resultSet));
				result.setAtendente(Atendente.getAtendenteByResultSet(resultSet));
			}
		} catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		return result;
	}
	
}
