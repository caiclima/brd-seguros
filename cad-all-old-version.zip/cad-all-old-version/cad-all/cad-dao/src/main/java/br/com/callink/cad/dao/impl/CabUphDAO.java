/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.com.callink.cad.dao.ICabUphDAO;
import br.com.callink.cad.pojo.CabUph;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.sau.exception.DataException;

/**
 *
 * @author swb.miller
 */
public class CabUphDAO extends GenericCadDAO<CabUph> implements ICabUphDAO {

	private static final long serialVersionUID = 5570901269305766524L;

	public CabUphDAO() {
		super(CabUph.class);
	}
	
	@Override
    public List<CabUph> findLlistByConfFila(ConfiguracaoFila fila) throws DataException {
        List<CabUph> cabUphList = new ArrayList<CabUph>();
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
    	try {
            StringBuilder sql = new StringBuilder()
            	.append(SELECT)
            	.append(CabUph.getSqlCamposCabUph())
            	.append(", ")
            	.append(ConfiguracaoFila.getSqlCamposConfiguracaoFila())
            	.append(FROM)
                .append(CabUph.getSqlFromCabUph())
                .append(INNER_JOIN).append(ConfiguracaoFila.getSqlFromConfiguracaoFila())
                .append(" ON CabUph.ID_CONFIGURACAO_FILA = ConfiguracaoFila.ID_CONFIGURACAO_FILA ")
                .append(WHERE)
                .append(" ConfiguracaoFila.ID_CONFIGURACAO_FILA = ? ")
                .append(" ORDER BY CabUph.ID_CAB_UPH DESC ");

            stmt = getPreparedStatement(sql.toString());
            stmt.setInt(1, fila.getIdConfiguracaoFila());
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					CabUph cabUph = CabUph.getCabUphByResultSet(resultSet);
					cabUph.setConfiguracaoFila(ConfiguracaoFila.getConfiguracaoFilaByResultSet(resultSet));
					cabUphList.add(cabUph);
				}
			}
        } catch (Exception e) {
            throw new DataException(e);
        } finally {
        	super.close(resultSet);
        }
    	return cabUphList;
    }

    @Override
    public List<CabUph> findCabUphList(String descricao, ConfiguracaoFila fila, Double meta) throws DataException {
    	List<CabUph> cabUphList = new ArrayList<CabUph>();
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
		int index = 0;
    	try {
            StringBuilder sql = new StringBuilder()
            	.append(SELECT)
            	.append(CabUph.getSqlCamposCabUph())
            	.append(", ")
            	.append(ConfiguracaoFila.getSqlCamposConfiguracaoFila())
            	.append(FROM)
                .append(CabUph.getSqlFromCabUph())
                .append(INNER_JOIN).append(ConfiguracaoFila.getSqlFromConfiguracaoFila())
                .append(" ON CabUph.ID_CONFIGURACAO_FILA = ConfiguracaoFila.ID_CONFIGURACAO_FILA ")
                .append(WHERE)
                .append(" CabUph.DATA_FINAL is null ");

            if (fila != null) {
            	sql.append(" AND ConfiguracaoFila.ID_CONFIGURACAO_FILA = ? ");
            }
            if (descricao != null && !descricao.isEmpty()) {
            	sql.append(" AND CabUph.DESCRICAO like ? ");
            }
            if (meta != null  && meta.doubleValue() != 0) {
            	sql.append(" AND CabUph.META = ? ");
            }
            sql.append(" ORDER BY CabUph.ID_CAB_UPH DESC ");
            
            stmt = getPreparedStatement(sql.toString());
            
            if (fila != null) {
            	stmt.setInt(++index, fila.getIdConfiguracaoFila());
            }
            if (descricao != null && !descricao.isEmpty()) {
            	stmt.setString(++index, new StringBuilder("%").append(descricao).append("%").toString());
            }
            if (meta != null  && meta.doubleValue() != 0) {
            	stmt.setDouble(++index, meta.doubleValue());
            }
            
			stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null) {
				while (resultSet.next()) {
					CabUph cabUph = CabUph.getCabUphByResultSet(resultSet);
					cabUph.setConfiguracaoFila(ConfiguracaoFila.getConfiguracaoFilaByResultSet(resultSet));
					cabUphList.add(cabUph);
				}
			}
        } catch (Exception e) {
            throw new DataException(e);
        } finally {
        	super.close(resultSet);
        }
    	return cabUphList;
    }
    
    @Override
    public CabUph findUltimaMetaConfigura(ConfiguracaoFila fila) throws DataException {
    	CabUph cabUphResult = null;
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
    	try {
            StringBuilder sql = new StringBuilder()
            	.append(SELECT)
            	.append(CabUph.getSqlCamposCabUph())
            	.append(FROM)
                .append(CabUph.getSqlFromCabUph())
                .append(" WHERE CabUph.ID_CONFIGURACAO_FILA = ? ")
                .append(" AND CabUph.DATA_FINAL is null ")
                .append(" ORDER BY CabUph.DATA_INICIAL DESC ");

            stmt = getPreparedStatement(sql.toString());
            
            stmt.setInt(1, fila.getIdConfiguracaoFila());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null && resultSet.next()) {
				cabUphResult = CabUph.getCabUphByResultSet(resultSet);
			}
        } catch (Exception e) {
            throw new DataException("Erro ao buscar ultima configura de meta", e);
        } finally {
        	super.close(resultSet);
        }
    	return cabUphResult;
    }
    
    @Override
    public CabUph findByPk(Object id) throws DataException {
    	CabUph result = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(CabUph.getSqlCamposCabUph())
				.append(", ")
				.append(ConfiguracaoFila.getSqlCamposConfiguracaoFila())
				.append(FROM)
				.append(CabUph.getSqlFromCabUph())
				.append(INNER_JOIN).append(ConfiguracaoFila.getSqlFromConfiguracaoFila())
				.append(" ON CabUph.ID_CONFIGURACAO_FILA = ConfiguracaoFila.ID_CONFIGURACAO_FILA ")
				.append(" WHERE CabUph.ID_CAB_UPH = ? ");
			
			stmt = getPreparedStatement(select.toString());
			
			CabUph cabUph = (CabUph) id;
			
			stmt.setInt(1, cabUph.getIdCabUph());
			
			stmt.execute();
			
			resultSet = stmt.getResultSet();
			if (resultSet != null && resultSet.next()) {
				result = CabUph.getCabUphByResultSet(resultSet);
				result.setConfiguracaoFila(ConfiguracaoFila.getConfiguracaoFilaByResultSet(resultSet));
			}
		} catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		return result;
	}
    
}
