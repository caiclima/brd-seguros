package br.com.callink.cad.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.persistence.Query;

import br.com.callink.cad.dao.ICasoDAO;
import br.com.callink.cad.pojo.Agendamento;
import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.pojo.Equipe;
import br.com.callink.cad.pojo.SlaFila;
import br.com.callink.cad.pojo.Status;
import br.com.callink.cad.pojo.Util.DateUtil;
import br.com.callink.cad.repository.to.AtendenteCasoStatusTO;
import br.com.callink.cad.repository.to.CasoStatusTO;
import br.com.callink.cad.sau.exception.DataException;

/**
 * 
 * @author brunomt [brunoam@swb.com.br]
 * 
 */
public class CasoDAO extends GenericCadDAO<Caso> implements ICasoDAO {

	private static final long serialVersionUID = 2374547808348733733L;

	public CasoDAO() {
		super(Caso.class);
	}
	
	@Override
	public List<Caso> findCasoAtivos() throws DataException {
		List<Caso> casoList = new ArrayList<Caso>();
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
    	try {
            StringBuilder sql = new StringBuilder()
            	.append(SELECT)
            	.append(Caso.getSqlCamposCaso())
            	.append(", ")
            	.append(Status.getSqlCamposStatus())
            	.append(FROM)
                .append(Caso.getSqlFromCaso())
                .append(INNER_JOIN).append(Status.getSqlFromStatus())
                .append(" ON Caso.ID_STATUS = Status.ID_STATUS ")
                .append(WHERE)
                .append(" AND Status.FLAG_CONTA_SLA = 1 ");

            stmt = getPreparedStatement(sql.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null) {
				while (resultSet.next()) {
					Caso caso = Caso.getCasoByResultSet(resultSet);
					caso.setStatus(Status.getStatusByResultSet(resultSet));
					casoList.add(caso);
				}
			}
        } catch (Exception e) {
            throw new DataException(e);
        } finally {
        	super.close(resultSet);
        }
    	return casoList;
	}
	
	@Override
	public List<Caso> buscaCasosFiltroPorFilaSemAtendente(String fromCaso, String sqlWhere) throws DataException {
		List<Caso> casoList = new ArrayList<Caso>();
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder sql = new StringBuilder();
			sql.append(SELECT);
			sql.append(Caso.getSqlCamposCaso());
			sql.append(FROM);
			sql.append(fromCaso);
			sql.append(" ");
			
			if (sqlWhere != null && !sqlWhere.isEmpty()) {
				sql.append(WHERE);
				sql.append(sqlWhere);
			}
	
			stmt = getPreparedStatement(sql.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null) {
				while (resultSet.next()) {
					Caso caso = Caso.getCasoByResultSet(resultSet);
					casoList.add(caso);
				}
			}
		} catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		return casoList;
	}
	
	@Override
	public List<Caso> buscaCasosFiltroPorFilaSemAtendente(String fromCaso, String sqlWhere, Integer top) throws DataException {
		List<Caso> casoList = new ArrayList<Caso>();
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder sql = new StringBuilder();
			sql.append(SELECT);
			sql.append(" TOP "). append(top).append(" ");
			sql.append(Caso.getSqlCamposCaso());
			sql.append(FROM);
			sql.append(fromCaso);
			sql.append(" ");
			
			if (sqlWhere != null && !sqlWhere.isEmpty()) {
				sql.append(WHERE);
				sql.append(sqlWhere);
			}
	
			stmt = getPreparedStatement(sql.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null) {
				while (resultSet.next()) {
					Caso caso = Caso.getCasoByResultSet(resultSet);
					casoList.add(caso);
				}
			}
		} catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		return casoList;
	}

	@Override
	public List<Caso> buscaTodosCasosAtivosAtendente(Atendente atendente)
			throws DataException {
		List<Caso> casoList = new ArrayList<Caso>();
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
    	try {
            StringBuilder sql = new StringBuilder()
            	.append(SELECT)
            	.append(Caso.getSqlCamposCaso())
            	.append(FROM)
                .append(Caso.getSqlFromCaso())
                .append(WHERE)
                .append(" Caso.ID_ATENDENTE = ? ")
                .append(" AND Caso.FLAG_FINALIZADO = 0 ")
                .append(" AND (Caso.FLAG_RECLASSIFICA_REABERTURA = 0 ")
                .append(" OR Caso.FLAG_RECLASSIFICA_REABERTURA is null) ");

            stmt = getPreparedStatement(sql.toString());
            stmt.setInt(1, atendente.getIdAtendente());
			stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null) {
				while (resultSet.next()) {
					Caso caso = Caso.getCasoByResultSet(resultSet);
					casoList.add(caso);
				}
			}
        } catch (Exception e) {
            throw new DataException("Erro ao consultar os casos ativos para o atendente.", e);
        } finally {
        	super.close(resultSet);
        }
    	return casoList;
	}

	@Override
	public void retiraFilaCaso(ConfiguracaoFila configuracaoFila) throws DataException {
		Query query = getEntityManager().createNativeQuery(" update tb_caso set id_configuracao_fila = null, flag_classifica = 1 where id_configuracao_fila = :idConfigFila and id_atendente is null and flag_finalizado = 0 ");
        query.setParameter("idConfigFila", configuracaoFila.getIdConfiguracaoFila());
        query.executeUpdate();
	}

	@Override
	public List<Caso> buscaCasosOrdernadosPorFilaSemAtendente(String casoTabela, String sqlOrder, ConfiguracaoFila confFila, Integer quantidadeCasos) throws DataException {
		List<Caso> casoList = new ArrayList<Caso>();
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder string = new StringBuilder();
			string.append(" select TOP  "); 
			string.append(quantidadeCasos == null || quantidadeCasos.equals(0) ? 1 : quantidadeCasos);
			string.append(Caso.getSqlCamposCaso());
			string.append(" from tb_caso Caso with(nolock) , tb_fila_classificacao_caso f with(nolock), ");
			string.append(casoTabela);
			string.append(" casoespecialista with(nolock) ");
			string.append(" where f.id_configuracao_fila = ? ");
			string.append(" and f.id_caso = Caso.id_caso and Caso.id_configuracao_fila = f.id_configuracao_fila ");
			string.append(" and (Caso.FLAG_RECLASSIFICA_REABERTURA = 0 or Caso.FLAG_RECLASSIFICA_REABERTURA is null) ");
			string.append(" and Caso.id_caso = casoespecialista.id_caso and Caso.id_atendente is null and Caso.flag_finalizado = 0");
	        string.append(" and Caso.id_caso not in (SELECT ag.id_caso FROM tb_agendamento ag with(nolock) where ag.flag_ativo = 1 ) ");
			string.append(" order by ");
			if (sqlOrder != null && !sqlOrder.isEmpty()) {
				string.append(sqlOrder);
			} else {
				string.append(" caso.data_abertura asc ");
			}
	
			stmt = getPreparedStatement(string.toString());
            
            stmt.setInt(1, confFila.getIdConfiguracaoFila());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null) {
				while (resultSet.next()) {
					Caso caso = Caso.getCasoByResultSet(resultSet);
					casoList.add(caso);
				}
			}
        } catch (Exception e) {
            throw new DataException(e);
        } finally {
        	super.close(resultSet);
        }
    	return casoList;
	}
	
	@Override
	public List<Caso> buscaCasosAtivosPorConfiguracaoFila(ConfiguracaoFila configuracaoFila) throws DataException{
		List<Caso> casoList = new ArrayList<Caso>();
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
    	try {
            StringBuilder sql = new StringBuilder()
            	.append(SELECT)
            	.append(Caso.getSqlCamposCaso())
            	.append(FROM)
                .append(Caso.getSqlFromCaso())
                .append(WHERE)
                .append(" Caso.ID_CONFIGURACAO_FILA = ? ")
                .append(" AND Caso.FLAG_FINALIZADO = 0 ")
                .append(" AND (Caso.FLAG_RECLASSIFICA_REABERTURA = 0 ")
                .append("   OR Caso.FLAG_RECLASSIFICA_REABERTURA is null) ");

            stmt = getPreparedStatement(sql.toString());
            
            stmt.setInt(1, configuracaoFila.getIdConfiguracaoFila());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null) {
				while (resultSet.next()) {
					Caso caso = Caso.getCasoByResultSet(resultSet);
					casoList.add(caso);
				}
			}
        } catch (Exception e) {
            throw new DataException(e);
        } finally {
        	super.close(resultSet);
        }
    	return casoList;
	}
	
	@Override
	public List<Caso> buscaCasoReclassificaReabertura() throws DataException {
		List<Caso> casoList = new ArrayList<Caso>();
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
    	try {
            StringBuilder sql = new StringBuilder()
            	.append(SELECT)
            	.append(Caso.getSqlCamposCaso())
            	.append(FROM)
                .append(Caso.getSqlFromCaso())
                .append(WHERE)
                .append(" Caso.FLAG_FINALIZADO = 0 ")
                .append(" AND Caso.FLAG_RECLASSIFICA_REABERTURA = 1 ");

            stmt = getPreparedStatement(sql.toString());
            
			stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null) {
				while (resultSet.next()) {
					Caso caso = Caso.getCasoByResultSet(resultSet);
					casoList.add(caso);
				}
			}
        } catch (Exception e) {
            throw new DataException(e);
        } finally {
        	super.close(resultSet);
        }
    	return casoList;
	}

	@Override
	public List<Caso> buscaProximoCasoAgendadoFila(List<ConfiguracaoFila> configuracaoFilaList) throws DataException {
		List<Caso> casoList = new ArrayList<Caso>();
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
    	try {
            StringBuilder sql = new StringBuilder()
            	.append(SELECT)
            	.append(Caso.getSqlCamposCaso())
            	.append(", ")
            	.append(ConfiguracaoFila.getSqlCamposConfiguracaoFila())
            	.append(FROM)
                .append(Caso.getSqlFromCaso())
                .append(INNER_JOIN).append(Agendamento.getSqlFromAgendamento())
                .append(" ON Caso.ID_CASO = Agendamento.ID_CASO ")
                .append(LEFT_JOIN).append(ConfiguracaoFila.getSqlFromConfiguracaoFila())
                .append(" ON Caso.ID_CONFIGURACAO_FILA = ConfiguracaoFila.ID_CONFIGURACAO_FILA ")
                .append(WHERE_1_1);
            
            StringBuilder configFilaIn = new StringBuilder();
            for (int i = 0; i < configuracaoFilaList.size(); i++) {
            	if (i != 0) {
            		configFilaIn.append(", ");
            	}
            	configFilaIn.append(configuracaoFilaList.get(i).getIdConfiguracaoFila());
            }
            
            sql.append(String.format("   AND Caso.ID_CONFIGURACAO_FILA in (%s) ", configFilaIn.toString()));
            
            sql.append("   AND Caso.FLAG_FINALIZADO = 0 ");
            sql.append("   AND Caso.ID_ATENDENTE is null ");
            sql.append("   AND (Caso.FLAG_RECLASSIFICA_REABERTURA = 0 ");
            sql.append("   OR Caso.FLAG_RECLASSIFICA_REABERTURA is null) ");
            sql.append("   AND Agendamento.FLAG_ATIVO = 1 ");
            sql.append("   AND Agendamento.DATA_AGENDAMENTO <= ? ");
            sql.append(" ORDER BY Agendamento.DATA_AGENDAMENTO ");

            stmt = getPreparedStatement(sql.toString());
            
            stmt.setString(1, DateUtil.convertDateStringWithHour(getDataBanco()));
            
			stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null) {
				while (resultSet.next()) {
					Caso caso = Caso.getCasoByResultSet(resultSet);
					caso.setConfiguracaoFila(ConfiguracaoFila.getConfiguracaoFilaByResultSet(resultSet));
					casoList.add(caso);
				}
			}
        } catch (Exception e) {
            throw new DataException(e);
        } finally {
        	super.close(resultSet);
        }
    	return casoList;
	}
	
	
	@Override
	public List<Caso> buscaCasoAgendado(Atendente atendente) throws DataException {
		List<Caso> casoList = new ArrayList<Caso>();
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
    	try {
            StringBuilder sql = new StringBuilder()
            	.append(SELECT)
            	.append(Caso.getSqlCamposCaso())
            	.append(", ")
            	.append(ConfiguracaoFila.getSqlCamposConfiguracaoFila())
            	.append(FROM)
                .append(Caso.getSqlFromCaso())
                .append(INNER_JOIN).append(Agendamento.getSqlFromAgendamento())
                .append(" ON Caso.ID_CASO = Agendamento.ID_CASO ")
                .append(LEFT_JOIN).append(ConfiguracaoFila.getSqlFromConfiguracaoFila())
                .append(" ON Caso.ID_CONFIGURACAO_FILA = ConfiguracaoFila.ID_CONFIGURACAO_FILA ")
                .append(WHERE_1_1)
                .append("   AND Caso.FLAG_FINALIZADO = 0 ")
                .append("   AND Caso.ID_ATENDENTE = ? ")
                .append("   AND (Caso.FLAG_RECLASSIFICA_REABERTURA = 0 ")
                .append("   OR Caso.FLAG_RECLASSIFICA_REABERTURA is null) ")
                .append("   AND Agendamento.FLAG_ATIVO = 1 ")
                .append("   AND Agendamento.DATA_AGENDAMENTO <= ? ")
                .append(" ORDER BY Agendamento.DATA_AGENDAMENTO ");

            stmt = getPreparedStatement(sql.toString());
            
            stmt.setInt(1, atendente.getIdAtendente());
            stmt.setString(2, DateUtil.convertDateStringWithHour(getDataBanco()));
            
			stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null) {
				while (resultSet.next()) {
					Caso caso = Caso.getCasoByResultSet(resultSet);
					caso.setConfiguracaoFila(ConfiguracaoFila.getConfiguracaoFilaByResultSet(resultSet));
					casoList.add(caso);
				}
			}
        } catch (Exception e) {
            throw new DataException("Erro ao buscar o caso pelo atendente. ", e);
        } finally {
        	super.close(resultSet);
        }
    	return casoList;
	}
	
	@Override
	public List<Caso> buscaPorStatus(Status status) throws DataException{
		List<Caso> casoList = new ArrayList<Caso>();
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
    	try {
            StringBuilder sql = new StringBuilder()
            	.append(SELECT)
            	.append(Caso.getSqlCamposCaso())
            	.append(FROM)
                .append(Caso.getSqlFromCaso());
            
            if (status != null) {
            	sql.append(WHERE)
            	   .append(" Caso.ID_STATUS = ? ");
            }

            stmt = getPreparedStatement(sql.toString());
            
            if (status != null) {
            	stmt.setInt(1, status.getIdStatus());
            }
            
			stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null) {
				while (resultSet.next()) {
					Caso caso = Caso.getCasoByResultSet(resultSet);
					casoList.add(caso);
				}
			}
        } catch (Exception e) {
            throw new DataException(e);
        } finally {
        	super.close(resultSet);
        }
    	return casoList;
	}

    @Override
    public List<Caso> buscaCasoEmAtendimento() throws DataException {
        List<Caso> casoList = new ArrayList<Caso>();
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
    	try {
            StringBuilder sql = new StringBuilder()
            	.append(SELECT)
            	.append(Caso.getSqlCamposCaso())
            	.append(FROM)
                .append(Caso.getSqlFromCaso())
                .append(WHERE)
                .append(" Caso.FLAG_FINALIZADO = 0 ")
                .append(" AND Caso.ID_ATENDENTE is not null ")
                .append(" AND (Caso.FLAG_RECLASSIFICA_REABERTURA = 0 ")
                .append(" OR Caso.FLAG_RECLASSIFICA_REABERTURA is null) ");

            stmt = getPreparedStatement(sql.toString());
            
			stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null) {
				while (resultSet.next()) {
					Caso caso = Caso.getCasoByResultSet(resultSet);
					casoList.add(caso);
				}
			}
        } catch (Exception e) {
            throw new DataException("Erro ao buscar os casos em atendimento.", e);
        } finally {
        	super.close(resultSet);
        }
    	return casoList;
    }
    
    @Override
    public Caso load(Caso caso) throws DataException {
    	Caso casoResult = null;
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
    	try {
            StringBuilder sql = new StringBuilder()
            	.append(SELECT)
            	.append(Caso.getSqlCamposCaso())
            	.append(", ")
            	.append(Atendente.getSqlCamposAtendente())
            	.append(", ")
            	.append(Status.getSqlCamposStatus())
            	.append(", ")
            	.append(ConfiguracaoFila.getSqlCamposConfiguracaoFila())
            	.append(FROM)
                .append(Caso.getSqlFromCaso())
                .append(LEFT_JOIN).append(Atendente.getSqlFromAtendente())
                .append("  ON Caso.ID_ATENDENTE = Atendente.ID_ATENDENTE ")
                .append(LEFT_JOIN).append(Status.getSqlFromStatus())
                .append("  ON Caso.ID_STATUS = Status.ID_STATUS ")
                .append(LEFT_JOIN).append(ConfiguracaoFila.getSqlFromConfiguracaoFila())
                .append("  ON Caso.ID_CONFIGURACAO_FILA = ConfiguracaoFila.ID_CONFIGURACAO_FILA ");

            if (caso.getPK() != null) {
                sql.append(WHERE).append(" Caso.ID_CASO = ? ");
            } else if (caso.getIdExterno() != null) {
            	sql.append(WHERE).append(" Caso.ID_EXTERNO = ? ");
            } else {
                return new Caso();
            }
            
            stmt = getPreparedStatement(sql.toString());
            
            if (caso.getPK() != null) {
            	stmt.setInt(1, caso.getPK());
            } else if (caso.getIdExterno() != null) {
            	stmt.setString(1, caso.getIdExterno());
            }
            
			stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null && resultSet.next()) {
				casoResult = Caso.getCasoByResultSet(resultSet);
				casoResult.setAtendente(Atendente.getAtendenteByResultSet(resultSet));
				casoResult.setStatus(Status.getStatusByResultSet(resultSet));
				casoResult.setConfiguracaoFila(ConfiguracaoFila.getConfiguracaoFilaByResultSet(resultSet));
			}
        } catch (Exception e) {
            throw new DataException(e);
        } finally {
        	super.close(resultSet);
        }
    	return casoResult;
    }
    
    @Override
	public Integer quantidadeCasosFechados(Integer idAtendente, Integer idFila, Date dataInicial, Date dataFinal) throws DataException {
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
		Integer casos = 0;
		int index = 0;
    	try {
			
    		StringBuilder string = new StringBuilder();
			string.append(" select count(*) casosFechados from tb_caso with (nolock) where flag_finalizado = 1 ");
			
			if (idAtendente != null && idAtendente != 0) {
				string.append(" and id_atendente = ? ");
			}
			if (idFila != null && idFila != 0) {
				string.append(" and id_configuracao_fila = ? ");
			}
			if (dataInicial != null && dataFinal != null) {
				string.append(" and data_encerramento > ? and data_encerramento < ? ");
			}
			
			stmt = getPreparedStatement(string.toString());
			
			if (idAtendente != null && idAtendente != 0) {
				stmt.setInt(++index, idAtendente);
			}
			if (idFila != null && idFila != 0) {
				stmt.setInt(++index, idFila);
			}
			if (dataInicial != null && dataFinal != null) {
				stmt.setTimestamp(++index, new java.sql.Timestamp(dataInicial.getTime()));
				stmt.setTimestamp(++index, new java.sql.Timestamp(dataFinal.getTime()));
			}
			
			stmt.execute();
			resultSet = stmt.getResultSet();
            
            if (resultSet != null) {
            	while (resultSet.next()) {
            		casos = resultSet.getInt("casosFechados");
            	}
            }
            
        } catch (Exception e) {
			throw new DataException(e);
		} finally {
            super.close(resultSet);
        }
		return casos;
	}
    
    @Override
	public List<Caso> findCasoEmAtendimento(Atendente atendente) throws DataException {
    	List<Caso> casoList = new ArrayList<Caso>();
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
    	try {
            StringBuilder sql = new StringBuilder()
            	.append(SELECT)
            	.append(Caso.getSqlCamposCaso())
            	.append(FROM)
                .append(Caso.getSqlFromCaso())
                .append(WHERE)
                .append(" Caso.FLAG_EM_ATENDIMENTO = 1 ")
                .append(" AND Caso.ID_ATENDENTE = ? ");

            stmt = getPreparedStatement(sql.toString());
            
            stmt.setInt(1, atendente.getIdAtendente());
            
            stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null) {
				while (resultSet.next()) {
					Caso caso = Caso.getCasoByResultSet(resultSet);
					casoList.add(caso);
				}
			}
        } catch (Exception e) {
            throw new DataException(e);
        } finally {
        	super.close(resultSet);
        }
    	return casoList;
	}
    
    @Override
    public void atualizaFlagEmAtendimentoParaFalse(List<Atendente> listaAtendente) throws DataException {
    	if (listaAtendente != null && listaAtendente.size() > 0) {
    		StringBuilder idsAtendente = new StringBuilder();
            for (int i = 0; i < listaAtendente.size(); i++) {
            	if (i != 0) {
            		idsAtendente.append(", ");
            	}
            	idsAtendente.append(listaAtendente.get(i).getIdAtendente());
            }
			Query query = getEntityManager().createNativeQuery(String.format(" update tb_caso set flag_em_atendimento = 0 where flag_em_atendimento = 1 and id_atendente in(%s) ", idsAtendente));
	        query.executeUpdate();
    	}
    }
    
    @Override
	public List<Caso> atendentePossuiCasoEmAtendimento(Atendente atendente) throws DataException{
        List<Caso> casoList = new ArrayList<Caso>();
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
    	try {
            StringBuilder sql = new StringBuilder()
            	.append(SELECT)
            	.append(Caso.getSqlCamposCaso())
            	.append(FROM)
                .append(Caso.getSqlFromCaso())
                .append(WHERE)
                .append(" Caso.FLAG_EM_ATENDIMENTO = 1 ")
                .append(" AND Caso.ID_ATENDENTE = ? ");

            stmt = getPreparedStatement(sql.toString());
            
            stmt.setInt(1, atendente.getIdAtendente());
            
            stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null) {
				while (resultSet.next()) {
					Caso caso = Caso.getCasoByResultSet(resultSet);
					casoList.add(caso);
				}
			}
        } catch (Exception e) {
            throw new DataException("Erro ao buscar os casos em atendimento", e);
        } finally {
        	super.close(resultSet);
        }
    	return casoList;
    }
    
    @Override
	public boolean validaSeCasoEstaSendoProcessadoPeloSpa(Caso caso, String tabelaImportacaoCaso) throws DataException {
		if (caso == null || caso.getIdExterno() == null) {
			throw new DataException("Caso Nulo");
		}
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		String manifestacao = null;
		try {
			StringBuilder string = new StringBuilder();
			string.append("  SELECT  importCaso.manifestacao as MANIFESTACAO ")
					.append(" FROM ? importCaso with(nolock) ")
					.append(" WHERE importCaso.manifestacao = ? ");
	
			stmt = getPreparedStatement(string.toString());
	        
	        stmt.setString(1, tabelaImportacaoCaso);
	        stmt.setString(2, caso.getIdExterno());
	
	        stmt.execute();
			resultSet = stmt.getResultSet();
			if(resultSet != null) {
				while (resultSet.next()) {
					manifestacao = resultSet.getString("MANIFESTACAO");
				}
			}
		} catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		if (manifestacao == null || manifestacao.trim().isEmpty()) {
			return Boolean.FALSE;
		} else {
			return Boolean.TRUE;
		}
	}

	@Override
	public List<Caso> buscaCasosSLAFimDia() throws DataException {
		try {
			Calendar dataInicio = new GregorianCalendar(Calendar.getInstance().get(Calendar.YEAR), Calendar.getInstance().get(Calendar.MONTH), Calendar.getInstance().get(Calendar.DAY_OF_MONTH), Integer.valueOf(0), Integer.valueOf(1));
	        Calendar dataFim = new GregorianCalendar(Calendar.getInstance().get(Calendar.YEAR), Calendar.getInstance().get(Calendar.MONTH), Calendar.getInstance().get(Calendar.DAY_OF_MONTH), Integer.valueOf(23), Integer.valueOf(59));
	        
			return retornaCasoFimSLA(dataInicio, dataFim);
		} catch (Exception e) {
			throw new DataException("Erro ao buscar os casos fechados no dia atual",e);
		}
	}

	@Override
	public List<Caso> buscaCasosSLAFimDia(Date dataBusca) throws DataException {
		try {
			if (dataBusca == null) {
				dataBusca = new Date();
			}
			
			Calendar dataConsulta = new GregorianCalendar();
			dataConsulta.setTime(dataBusca);
			
			Calendar dataInicio = new GregorianCalendar(dataConsulta.get(Calendar.YEAR), dataConsulta.get(Calendar.MONTH), dataConsulta.get(Calendar.DAY_OF_MONTH), Integer.valueOf(0), Integer.valueOf(1));
	        Calendar dataFim = new GregorianCalendar(dataConsulta.get(Calendar.YEAR), dataConsulta.get(Calendar.MONTH), dataConsulta.get(Calendar.DAY_OF_MONTH), Integer.valueOf(23), Integer.valueOf(59));
	        
			return retornaCasoFimSLA(dataInicio, dataFim);
		} catch (Exception e) {
			throw new DataException("Erro ao buscar os casos fechados no dia atual",e);
		}
	}
	
	private List<Caso> retornaCasoFimSLA(Calendar dataInicio, Calendar dataFim) throws DataException {
		List<Caso> casoList = new ArrayList<Caso>();
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
    	try {
            StringBuilder sql = new StringBuilder()
            	.append(SELECT)
            	.append(Caso.getSqlCamposCaso())
            	.append(", ")
            	.append(ConfiguracaoFila.getSqlCamposConfiguracaoFila())
            	.append(", ")
            	.append(Atendente.getSqlCamposAtendente())
            	.append(", ")
            	.append(Equipe.getSqlEquipe())
            	.append(FROM)
                .append(Caso.getSqlFromCaso())
                .append(INNER_JOIN).append(ConfiguracaoFila.getSqlFromConfiguracaoFila())
                .append("  ON Caso.ID_CONFIGURACAO_FILA = ConfiguracaoFila.ID_CONFIGURACAO_FILA ")
                .append(LEFT_JOIN).append(Atendente.getSqlFromAtendente())
                .append("  ON Caso.ID_ATENDENTE = Atendente.ID_ATENDENTE ")
                .append(INNER_JOIN).append(Equipe.getSqlFromEquipe())
                .append("  ON Atendente.ID_EQUIPE = Equipe.ID_EQUIPE ")
                .append(WHERE)
                .append(" Caso.FLAG_FINALIZADO = 1 ")
                .append(" AND Caso.DATA_ENCERRAMENTO between ? and ? ");

            stmt = getPreparedStatement(sql.toString());
            
            stmt.setString(1, DateUtil.convertDateStringWithHour(dataInicio.getTime()));
            stmt.setString(2, DateUtil.convertDateStringWithHour(dataFim.getTime()));
            
            stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null) {
				while (resultSet.next()) {
					Caso caso = Caso.getCasoByResultSet(resultSet);
					caso.setConfiguracaoFila(ConfiguracaoFila.getConfiguracaoFilaByResultSet(resultSet));
					Atendente atendente = Atendente.getAtendenteByResultSet(resultSet);
					atendente.setEquipe(Equipe.getEquipeByResultSet(resultSet));
					caso.setAtendente(atendente);
					casoList.add(caso);
				}
			}
        } catch (Exception e) {
            throw new DataException("Erro ao buscar os casos fechados no dia atual", e);
        } finally {
        	super.close(resultSet);
        }
    	return casoList;
	}
	
	@Override
	public Caso findByPk(Object id) throws DataException {
		Caso result = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Caso.getSqlCamposCaso())
				.append(", ")
				.append(Status.getSqlCamposStatus())
				.append(", ")
				.append(ConfiguracaoFila.getSqlCamposConfiguracaoFila())
				.append(", ")
				.append(Atendente.getSqlCamposAtendente())
				.append(FROM)
				.append(Caso.getSqlFromCaso())
				.append(INNER_JOIN).append(Status.getSqlFromStatus())
				.append(" ON Caso.ID_STATUS = Status.ID_STATUS ")
				.append(LEFT_JOIN).append(ConfiguracaoFila.getSqlFromConfiguracaoFila())
				.append(" ON Caso.ID_CONFIGURACAO_FILA = ConfiguracaoFila.ID_CONFIGURACAO_FILA ")
				.append(LEFT_JOIN).append(Atendente.getSqlFromAtendente())
				.append(" ON Caso.ID_ATENDENTE = Atendente.ID_ATENDENTE ")
				.append(" WHERE Caso.ID_CASO = ? ");
			
			stmt = getPreparedStatement(select.toString());
			Caso caso = (Caso) id;
			stmt.setInt(1, caso.getIdCaso());
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null && resultSet.next()) {
				result = Caso.getCasoByResultSet(resultSet);
				result.setStatus(Status.getStatusByResultSet(resultSet));
				result.setConfiguracaoFila(ConfiguracaoFila.getConfiguracaoFilaByResultSet(resultSet));
				result.setAtendente(Atendente.getAtendenteByResultSet(resultSet));
			}
		} catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		return result;
	}

	@Override
	public void flush() {
		this.getEntityManager().flush();
	}
	
	@Override
	public List<AtendenteCasoStatusTO> buscarQuantidadeCasosAtendidosPorStatus() throws DataException {
		List<AtendenteCasoStatusTO> ret = new ArrayList<AtendenteCasoStatusTO>();
		
		ResultSet resultSet = null;
		PreparedStatement ps = null;
		try {
			StringBuilder sbr = new StringBuilder("SELECT ");
			sbr.append(" atendente.id_atendente as id_atendente, status.id_status as id_status, count(caso.id_caso) as quantidade ");
			sbr.append(" FROM tb_caso caso with(nolock), tb_atendente atendente with(nolock), tb_status status with(nolock) ");
			sbr.append(" WHERE caso.id_atendente = atendente.id_atendente ");
			sbr.append(" AND caso.id_status = status.id_status ");
			sbr.append(" group by all atendente.id_atendente , status.id_status  ");
			sbr.append(" order by atendente.id_atendente asc  ");
			
			ps = getPreparedStatement(sbr.toString());
			ps.execute();
			resultSet = ps.getResultSet();
			if (resultSet != null) {
				while (resultSet.next()) {
					AtendenteCasoStatusTO atdCaso = new AtendenteCasoStatusTO();
					atdCaso.setIdAtendente(resultSet.getInt("id_atendente"));
					
					if(ret.contains(atdCaso)){
						atdCaso = ret.get(ret.indexOf(atdCaso));
						
						CasoStatusTO to = new CasoStatusTO();
						to.setIdStatus(resultSet.getInt("id_status"));
						to.setQuantidadeCasosAtendidos(resultSet.getInt("quantidade"));
						
						atdCaso.getListCasos().add(to);
						
					}else{
						atdCaso.setListCasos(new ArrayList<CasoStatusTO>());
						
						CasoStatusTO to = new CasoStatusTO();
						to.setIdStatus(resultSet.getInt("id_status"));
						to.setQuantidadeCasosAtendidos(resultSet.getInt("quantidade"));
						
						atdCaso.getListCasos().add(to);
						ret.add(atdCaso);
					}
				}
			}

		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return ret;
	}

	@Override
	public List<Caso> buscarTodosCasosPendentesDoCliente(Atendente atendente, String tbcasoespecialista, String sqlWhere, Integer idCaso) throws DataException {
		List<Caso> ret = new ArrayList<Caso>();
		
		ResultSet resultSet = null;
		PreparedStatement ps = null;
		try {
			final String subQuery = "(SELECT id_configuracao_fila FROM tb_equipe_fila where id_equipe = (SELECT id_equipe FROM tb_atendente where id_atendente = ?))";
			
			StringBuilder sbr = new StringBuilder()
					.append(SELECT)
					.append(Caso.getSqlCamposCaso())
					.append(", ")
					.append(ConfiguracaoFila.getSqlCamposConfiguracaoFila())
					.append(FROM)
					.append(Caso.getSqlFromCaso())
					.append(INNER_JOIN).append(tbcasoespecialista).append(" casoespecialista with(nolock) ")
					.append("  ON Caso.ID_CASO = casoespecialista.ID_CASO ")
					.append(LEFT_JOIN).append(ConfiguracaoFila.getSqlFromConfiguracaoFila())
					.append(" ON Caso.ID_CONFIGURACAO_FILA = ConfiguracaoFila.ID_CONFIGURACAO_FILA ")
					.append(sqlWhere)
					.append(" AND Caso.ID_CONFIGURACAO_FILA in ").append(subQuery)
					.append(" AND Caso.flag_finalizado = 0 and Caso.id_atendente is null ");
			
			ps = getPreparedStatement(sbr.toString());
			ps.setInt(1, idCaso);
			ps.setInt(2, atendente.getIdAtendente());
			ps.execute();
			
			resultSet = ps.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					Caso result = Caso.getCasoByResultSet(resultSet);
					ret.add(result);
				}
			}

		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return ret;
	}

	@Override
	@SuppressWarnings("unchecked")
	public Caso buscarCasoPorIdExterno(String idExterno) throws DataException {
		try {
			String sql = "SELECT caso FROM Caso AS caso WHERE caso.idExterno = :idExterno ";
	
			Query query = getEntityManager().createQuery(sql.toString());
			query.setParameter("idExterno", idExterno);
			List<Caso> casos = query.getResultList();
			
			return casos == null || casos.isEmpty() ? 
					null : casos.get(0);
			
		} catch (Exception e) {
	            throw new DataException("Erro ao buscar os caso por IdExterno", e);
        } 
	}
	
	@Override
	public List<Caso> buscarCasoSemVencimentoSlaByFinalizado(Boolean casosFinalizados) throws DataException {
		List<Caso> casoList = new ArrayList<Caso>();
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
    	try {
            StringBuilder sql = new StringBuilder()
            	.append(SELECT)
            	.append(Caso.getSqlCamposCaso())
            	.append(", ")
            	.append(SlaFila.getSqlCamposSlaFila())
            	.append(FROM)
                .append(Caso.getSqlFromCaso())
                .append(INNER_JOIN).append(SlaFila.getSqlFromSlaFila())
                .append(" ON Caso.ID_SLA_FILA = SlaFila.ID_SLA_FILA ")
                .append(WHERE)
                .append(" Caso.DATA_VENCIMENTO_SLA is null and Caso.FLAG_FINALIZADO = ? ");

            stmt = getPreparedStatement(sql.toString());
			stmt.setBoolean(1, casosFinalizados);
			stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null) {
				while (resultSet.next()) {
					Caso caso = Caso.getCasoByResultSet(resultSet);
					caso.setSlaFila(SlaFila.getSlaFilaByResultSet(resultSet));
					casoList.add(caso);
				}
			}
        } catch (Exception e) {
            throw new DataException(e);
        } finally {
        	super.close(resultSet);
        }
    	return casoList;
	}
	
	@Override
	public void atualizarDataVencimentoSla(Caso caso) throws DataException {
		try {
			Query query = getEntityManager().createNativeQuery(" update tb_caso set data_vencimento_sla = :dtVencSla where id_caso = :idcaso ");
	        query.setParameter("dtVencSla", caso.getDataVencimentoSla());
	        query.setParameter("idcaso", caso.getIdCaso());
	        query.executeUpdate();
		} catch (Exception e) {
			throw new DataException("Erro ao atualizar data de vencimento de sla do caso.", e);
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<String> buscaColunasTabelaCaso() throws DataException {
		StringBuilder sql = new StringBuilder("SELECT COLUNAS.NAME AS COLUNA FROM SYSOBJECTS AS TABELAS, SYSCOLUMNS AS COLUNAS ");
		sql.append(" WHERE TABELAS.ID = COLUNAS.ID AND TABELAS.NAME = 'tb_caso' GROUP BY COLUNAS.NAME"); 
				
		Query query = getEntityManager().createNativeQuery(sql.toString());		
			
		return (List<String>) query.getResultList();
	}
}
