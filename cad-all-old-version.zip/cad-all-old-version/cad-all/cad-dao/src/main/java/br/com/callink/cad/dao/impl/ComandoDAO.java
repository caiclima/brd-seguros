/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.com.callink.cad.dao.IComandoDAO;
import br.com.callink.cad.pojo.Comando;
import br.com.callink.cad.pojo.Status;
import br.com.callink.cad.sau.exception.DataException;

/**
 *
 * @author Rogério Moreira de Andrade. [rogeriom@swb.com.br]
 */
public class ComandoDAO extends GenericCadDAO<Comando> implements IComandoDAO {

	private static final long serialVersionUID = -3186002951939988027L;

	public ComandoDAO() {
		super(Comando.class);
	}
	
	public List<Comando> findByExample(Comando comando, String order) throws DataException {
		List<Comando> comandoList = new ArrayList<Comando>();
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
		int index = 0;
    	try {
            StringBuilder sql = new StringBuilder()
            	.append(SELECT)
            	.append(Comando.getSqlCamposComando())
            	.append(",").append(Status.getSqlCamposStatus())
            	.append(FROM)
                .append(Comando.getSqlFromComando())
                .append(LEFT_JOIN).append(Status.getSqlFromStatus())
                .append(" ON Comando.ID_STATUS = Status.ID_STATUS ")
                .append(WHERE_1_1);

            if (comando != null) {
    			if (comando.getNome() != null && !comando.getNome().isEmpty()) {
    				sql.append(" AND Comando.NOME like ? ");
    			}
    			if (comando.getFlagAtivo() != null) {
    				sql.append(" AND Comando.FLAG_ATIVO = ? ");
    			}
    			if (comando.getDescricao() != null && !comando.getDescricao().isEmpty()) {
    				sql.append(" AND Comando.DESCRICAO = ? ");
    			}
    			if (comando.getBeanName() != null && !comando.getBeanName().isEmpty()) {
    				sql.append(" AND Comando.BEAN_NAME = ? ");
    			}
    		}
            
            stmt = getPreparedStatement(sql.toString());
            
            if (comando != null) {
    			if (comando.getNome() != null && !comando.getNome().isEmpty()) {
    				stmt.setString(++index, new StringBuilder(comando.getNome()).append("%").toString());
    			}
    			if (comando.getFlagAtivo() != null) {
    				stmt.setBoolean(++index, comando.getFlagAtivo());
    			}
    			if (comando.getDescricao() != null && !comando.getDescricao().isEmpty()) {
    				stmt.setString(++index, comando.getDescricao());
    			}
    			if (comando.getBeanName() != null && !comando.getBeanName().isEmpty()) {
    				stmt.setString(++index, comando.getBeanName());
    			}
    		}
            
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					Comando cmd = Comando.getComandoByResultSet(resultSet);
					cmd.setStatus(Status.getStatusByResultSet(resultSet));
					comandoList.add(cmd);
				}
			}
        } catch (Exception e) {
            throw new DataException("Erro ao buscar os comandos", e);
        } finally {
        	super.close(resultSet);
        }
    	return comandoList;
	}
	
	@Override
	public List<Comando> findAtivos(String order) throws DataException {
		List<Comando> comandos = new ArrayList<Comando>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Comando.getSqlCamposComando())
				.append(FROM)
				.append(Comando.getSqlFromComando())
				.append(WHERE)
				.append(" Comando.FLAG_ATIVO = 1 ");

			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					Comando comando = Comando.getComandoByResultSet(resultSet);
					comandos.add(comando);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return comandos;
	}
	
	@Override
	public Comando findByPk(Object id) throws DataException {
		Comando result = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Comando.getSqlCamposComando())
				.append(", ")
				.append(Status.getSqlCamposStatus())
				.append(FROM)
				.append(Comando.getSqlFromComando())
				.append(LEFT_JOIN).append(Status.getSqlFromStatus())
				.append(" ON Comando.ID_STATUS = Status.ID_STATUS ")
				.append(" WHERE Comando.ID_COMANDO = ? ");
			
			stmt = getPreparedStatement(select.toString());
			Comando comando = (Comando) id;
			stmt.setInt(1, comando.getIdComando());
			stmt.execute();
			resultSet = stmt.getResultSet();

			if (resultSet != null && resultSet.next()) {
				result = Comando.getComandoByResultSet(resultSet);
				result.setStatus(Status.getStatusByResultSet(resultSet));
			}
		} catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		return result;
	}
	
	@Override
	public List<Comando> findAll() throws DataException {
		List<Comando> comandos = new ArrayList<Comando>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Comando.getSqlCamposComando())
				.append(FROM)
				.append(Comando.getSqlFromComando());
			
			stmt = getPreparedStatement(select.toString());
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					Comando comando = Comando.getComandoByResultSet(resultSet);
					comandos.add(comando);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return comandos;
	}
	
	@Override
	public List<Comando> findByExample(Comando example) throws DataException {
		return findByExample(example, null);
	}
	
}
