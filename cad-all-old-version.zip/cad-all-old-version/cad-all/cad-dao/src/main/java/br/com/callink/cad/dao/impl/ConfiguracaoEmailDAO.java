package br.com.callink.cad.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.dao.IConfiguracaoEmailDAO;
import br.com.callink.cad.pojo.ConfiguracaoEmail;
import br.com.callink.cad.pojo.Util.DateUtil;
import br.com.callink.cad.sau.exception.DataException;

public class ConfiguracaoEmailDAO extends GenericCadDAO<ConfiguracaoEmail> implements IConfiguracaoEmailDAO {

	private static final long serialVersionUID = -6008946612819538896L;

	public ConfiguracaoEmailDAO() {
		super(ConfiguracaoEmail.class);
	}
	
	@Override
    public List<ConfiguracaoEmail> findAll() throws DataException {
		return this.findAll(null);
	}
	
	@Override
    public List<ConfiguracaoEmail> findAll(String order) throws DataException {
    	
    	ResultSet result = null;
        PreparedStatement stmt = null;
    	List<ConfiguracaoEmail> list = new ArrayList<ConfiguracaoEmail>();
    	
    	try {
        	
        	StringBuilder select = new StringBuilder(SELECT)
        	.append(ConfiguracaoEmail.getSqlCamposConfiguracaoEmail())
        	.append(FROM).append(ConfiguracaoEmail.getSqlFromConfiguracaoEmail());
        	
        	if(StringUtils.isNotBlank(order)){
        		select.append(String.format(" ORDER BY %s ", order));
        	}
        	
        	stmt = getPreparedStatement(select.toString());
        	stmt.execute();
            result = stmt.getResultSet();
            
            if(result!= null){		
				while (result.next()) {
					ConfiguracaoEmail configuracaoEmail = ConfiguracaoEmail.getConfiguracaoEmailByResultSet(result);
					list.add(configuracaoEmail);
				}
			}
            
        	return list;
    	} catch (Exception ex) {
            throw new DataException(ex);
        } finally {
        	super.close(result);
        }
    }
	
	public List<ConfiguracaoEmail> findByExample(ConfiguracaoEmail example) throws DataException {
		return this.findByExample(example, null);
	}
	
	@Override
    public List<ConfiguracaoEmail> findByExample(ConfiguracaoEmail example,  String order) throws DataException {
    	
    	ResultSet result = null;
        PreparedStatement stmt = null;
    	List<ConfiguracaoEmail> list = new ArrayList<ConfiguracaoEmail>();
    	int index =0;
    	
    	try {
        	
        	StringBuilder select = new StringBuilder(SELECT)
        	.append(ConfiguracaoEmail.getSqlCamposConfiguracaoEmail())
        	.append(FROM).append(ConfiguracaoEmail.getSqlFromConfiguracaoEmail())
        	.append(WHERE_1_1);
        	
        	if(example!= null){
        		
        		if(example.getIdConfiguracaoEmail()!= null){
        			select.append(" AND ConfiguracaoEmail.ID_CONFIGURACAO_EMAIL = ? ");
        		}
        		if(StringUtils.isNotBlank(example.getEmail())){
        			select.append(" AND ConfiguracaoEmail.EMAIL like ? ");
        		}
        		if(StringUtils.isNotBlank(example.getSenha())){
        			select.append(" AND ConfiguracaoEmail.SENHA = ? ");
        		}
        		if(StringUtils.isNotBlank(example.getSmtp())){
        			select.append(" AND ConfiguracaoEmail.SMTP = ? ");
        		}
        		if(StringUtils.isNotBlank(example.getPop())){
        			select.append(" AND ConfiguracaoEmail.POP = ? ");
        		}
        		if(StringUtils.isNotBlank(example.getFolder())){
        			select.append(" AND ConfiguracaoEmail.FOLDER = ? ");
        		}
        		if(StringUtils.isNotBlank(example.getProtocolStore())){
        			select.append(" AND ConfiguracaoEmail.PROTOCOL_STORE = ? ");
        		}
        		if(example.getPorta() != null && example.getPorta() > 0){
        			select.append(" AND ConfiguracaoEmail.PORTA = ? ");
        		}
        		if(example.getDataCriacao()!= null){
        			select.append(" AND ConfiguracaoEmail.DATA_CRIACAO BETWEEN ? AND ? ");
        		}
        		if(example.getFlagAtivo()!= null){
        			select.append(" AND ConfiguracaoEmail.FLAG_ATIVO = ? ");
        		}
        		if(example.getFlagPrincipal()!= null){
        			select.append(" AND ConfiguracaoEmail.FLAG_PRINCIPAL = ? ");
        		}
        		
        	}
        	
        	if(StringUtils.isNotBlank(order)){
        		select.append(String.format(" ORDER BY %s ", order));
        	}
        	
        	stmt = getPreparedStatement(select.toString());
        	
        	if(example!= null){
        		
        		if(example.getIdConfiguracaoEmail()!= null){
        			stmt.setInt(++index, example.getIdConfiguracaoEmail());
        		}
        		if(StringUtils.isNotBlank(example.getEmail())){
        			stmt.setString(++index, new StringBuilder(example.getEmail()).append("%").toString());
        		}
        		if(StringUtils.isNotBlank(example.getSenha())){
        			stmt.setString(++index, new StringBuilder(example.getSenha()).toString());
        		}
        		if(StringUtils.isNotBlank(example.getSmtp())){
        			stmt.setString(++index, new StringBuilder(example.getSmtp()).toString());
        		}
        		if(StringUtils.isNotBlank(example.getPop())){
        			stmt.setString(++index, new StringBuilder(example.getPop()).toString());
        		}
        		if(StringUtils.isNotBlank(example.getFolder())){
        			stmt.setString(++index, new StringBuilder(example.getFolder()).toString());
        		}
        		if(StringUtils.isNotBlank(example.getProtocolStore())){
        			stmt.setString(++index, new StringBuilder(example.getProtocolStore()).toString());
        		}
        		if(example.getPorta() != null  && example.getPorta() > 0){
        			stmt.setInt(++index, example.getPorta());
        		}
        		if(example.getDataCriacao()!= null){
        			Date dataInicio = DateUtil.dataInicioDia(example.getDataCriacao());
					Date dataFinal =  DateUtil.dataFimDia(example.getDataCriacao());	
        			stmt.setDate(++index, new java.sql.Date(dataInicio.getTime()));
        			stmt.setDate(++index, new java.sql.Date(dataFinal.getTime()));
        		}
        		if(example.getFlagAtivo()!= null){
        			stmt.setBoolean(++index, example.getFlagAtivo());
        		}
        		if(example.getFlagPrincipal()!= null){
        			stmt.setBoolean(++index, example.getFlagPrincipal());
        		}
        	}
        	
        	
        	stmt.execute();
            result = stmt.getResultSet();
            
            if(result!= null){		
				while (result.next()) {
					ConfiguracaoEmail configuracaoEmail = ConfiguracaoEmail.getConfiguracaoEmailByResultSet(result);
					list.add(configuracaoEmail);
				}
			}
            
        	return list;
    	} catch (Exception ex) {
            throw new DataException(ex);
        } finally {
        	super.close(result);
        }
    }
	
	@Override
    public ConfiguracaoEmail findByPk(Object id) throws DataException {
    	
    	ResultSet result = null;
        PreparedStatement stmt = null;
    	
    	try {
        	
        	StringBuilder select = new StringBuilder(SELECT)
        	.append(ConfiguracaoEmail.getSqlCamposConfiguracaoEmail())
        	.append(FROM).append(ConfiguracaoEmail.getSqlFromConfiguracaoEmail())
        	.append(WHERE).append(" ConfiguracaoEmail.ID_CONFIGURACAO_EMAIL = ? ");
        	
        	ConfiguracaoEmail configuracaoEmail = (ConfiguracaoEmail) id;
        	stmt = getPreparedStatement(select.toString());
        	stmt.setInt(1, configuracaoEmail.getIdConfiguracaoEmail());
        	stmt.execute();
            result = stmt.getResultSet();
            
            if(result!= null){		
				while (result.next()) {
					configuracaoEmail = ConfiguracaoEmail.getConfiguracaoEmailByResultSet(result);
				}
			}
            
        	return configuracaoEmail;
    	} catch (Exception ex) {
            throw new DataException(ex);
        } finally {
        	super.close(result);
        }
    }
	
	@Override
    public List<ConfiguracaoEmail> findByIds(List<Integer> ids) throws DataException {
    	
    	ResultSet result = null;
        PreparedStatement stmt = null;
        List<ConfiguracaoEmail> list = new ArrayList<ConfiguracaoEmail>();
    	try {
    		String parameters = StringUtils.join(ids.iterator(),","); 
        	StringBuilder select = new StringBuilder(SELECT)
        	.append(ConfiguracaoEmail.getSqlCamposConfiguracaoEmail())
        	.append(FROM).append(ConfiguracaoEmail.getSqlFromConfiguracaoEmail())
        	.append(WHERE).append(String.format(" ConfiguracaoEmail.ID_CONFIGURACAO_EMAIL in (%s) ", parameters)).append(" And ConfiguracaoEmail.FLAG_ATIVO = 1 ");
        	
        	stmt = getPreparedStatement(select.toString());
        	
        	stmt.execute();
            result = stmt.getResultSet();
            
            if(result!= null){		
				while (result.next()) {
					list.add(ConfiguracaoEmail.getConfiguracaoEmailByResultSet(result));
				}
			}
            
        	return list;
    	} catch (Exception ex) {
            throw new DataException(ex);
        } finally {
        	super.close(result);
        }
    }

	@Override
	public List<ConfiguracaoEmail> findAtivos(String order) throws DataException {
		
		ResultSet result = null;
        PreparedStatement stmt = null;
    	List<ConfiguracaoEmail> list = new ArrayList<ConfiguracaoEmail>();
    	
    	try {
        	
        	StringBuilder select = new StringBuilder(SELECT)
        	.append(ConfiguracaoEmail.getSqlCamposConfiguracaoEmail())
        	.append(FROM).append(ConfiguracaoEmail.getSqlFromConfiguracaoEmail())
        	.append(WHERE).append(" ConfiguracaoEmail.FLAG_ATIVO = 1 ");
        	
        	if(StringUtils.isNotBlank(order)){
        		select.append(String.format(" ORDER BY %s ", order));
        	}
        	
        	stmt = getPreparedStatement(select.toString());
        	stmt.execute();
            result = stmt.getResultSet();
            
            if(result!= null){		
				while (result.next()) {
					ConfiguracaoEmail configuracaoEmail = ConfiguracaoEmail.getConfiguracaoEmailByResultSet(result);
					list.add(configuracaoEmail);
				}
			}
            
        	return list;
    	} catch (Exception ex) {
            throw new DataException(ex);
        } finally {
        	super.close(result);
        }
	}

	@Override
	public List<ConfiguracaoEmail> findAtivos() throws DataException {
		return this.findAtivos(null);
	}
	
}
