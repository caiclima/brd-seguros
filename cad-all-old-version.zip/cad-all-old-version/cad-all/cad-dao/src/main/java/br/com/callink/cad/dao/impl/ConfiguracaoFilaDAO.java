package br.com.callink.cad.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;

import br.com.callink.cad.dao.IConfiguracaoFilaDAO;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.pojo.Util.DateUtil;
import br.com.callink.cad.sau.exception.DataException;
/**
 * 
 * @author brunomt [brunoam@swb.com.br]
 *
 */
public class ConfiguracaoFilaDAO extends GenericCadDAO<ConfiguracaoFila> implements IConfiguracaoFilaDAO {

	private static final long serialVersionUID = 3882453267974927580L;

	public ConfiguracaoFilaDAO() {
		super(ConfiguracaoFila.class);
	}
	
	@Override
	public void insereCasoFila(Caso caso, ConfiguracaoFila configuracaoFila) throws DataException {
		Query query = getEntityManager().createNativeQuery(" insert into tb_fila_classificacao_caso (id_configuracao_fila,id_caso) values (:idConfigFila, :idCaso) ");
        query.setParameter("idConfigFila", configuracaoFila.getIdConfiguracaoFila());
        query.setParameter("idCaso", caso.getIdCaso());
        query.executeUpdate();
	}

	@Override
	public List<ConfiguracaoFila> buscaFilaAtivaPorPrioridade() throws DataException {
		List<ConfiguracaoFila> configuracaoFilaList = new ArrayList<ConfiguracaoFila>();
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
    	try {
            StringBuilder sql = new StringBuilder()
            	.append(SELECT)
            	.append(ConfiguracaoFila.getSqlCamposConfiguracaoFila())
            	.append(FROM)
                .append(ConfiguracaoFila.getSqlFromConfiguracaoFila())
                .append(WHERE)
                .append(" ConfiguracaoFila.FLAG_ATIVO = 1 ")
                .append(" AND ConfiguracaoFila.PRIORIDADE is not null ")
                .append(" ORDER BY ConfiguracaoFila.PRIORIDADE ");

            stmt = getPreparedStatement(sql.toString());
            
			stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null) {
				while (resultSet.next()) {
					ConfiguracaoFila configuracaoFila = ConfiguracaoFila.getConfiguracaoFilaByResultSet(resultSet);
					configuracaoFilaList.add(configuracaoFila);
				}
			}
        } catch (Exception e) {
            throw new DataException("Falha ao buscar filas ativas.", e);
        } finally {
        	super.close(resultSet);
        }
    	return configuracaoFilaList;
	}

	@Override
	public List<ConfiguracaoFila> buscaFilaBuildPorPrioridade()	throws DataException {
		List<ConfiguracaoFila> configuracaoFilaList = new ArrayList<ConfiguracaoFila>();
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
    	try {
            StringBuilder sql = new StringBuilder()
            	.append(SELECT)
            	.append(ConfiguracaoFila.getSqlCamposConfiguracaoFila())
            	.append(FROM)
                .append(ConfiguracaoFila.getSqlFromConfiguracaoFila())
                .append(WHERE)
                .append(" ConfiguracaoFila.FLAG_BUILD = 1 ")
                .append(" AND ConfiguracaoFila.FLAG_ATIVO = 1 ")
                .append(" ORDER BY ConfiguracaoFila.PRIORIDADE ");

            stmt = getPreparedStatement(sql.toString());
            
			stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null) {
				while (resultSet.next()) {
					ConfiguracaoFila configuracaoFila = ConfiguracaoFila.getConfiguracaoFilaByResultSet(resultSet);
					configuracaoFilaList.add(configuracaoFila);
				}
			}
        } catch (Exception e) {
            throw new DataException("Falha ao buscar filas por build.", e);
        } finally {
        	super.close(resultSet);
        }
    	return configuracaoFilaList;
	}

	@Override
	public void removeCasosClassificacaoFila(ConfiguracaoFila configuracaoFila) throws DataException {
		Query query = getEntityManager().createNativeQuery(" delete from tb_fila_classificacao_caso where id_configuracao_fila = :idConfigFila ");
        query.setParameter("idConfigFila", configuracaoFila.getIdConfiguracaoFila());
        query.executeUpdate();
	}
	
	@Override
	public void removeFilaClassificaoCaso(Caso caso) throws DataException {
		if (caso == null || caso.getIdCaso() == null) {
			throw new DataException("O caso não pode ser nulo ou estar com id nulo");
		}
		Query query = getEntityManager().createNativeQuery(" delete from tb_fila_classificacao_caso where id_caso = :idCaso ");
        query.setParameter("idCaso", caso.getIdCaso());
        query.executeUpdate();
	}

	@Override
	public List<ConfiguracaoFila> buscaFilaPorPrioridade() throws DataException {
		List<ConfiguracaoFila> configuracaoFilaList = new ArrayList<ConfiguracaoFila>();
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
    	try {
            StringBuilder sql = new StringBuilder()
            	.append(SELECT)
            	.append(ConfiguracaoFila.getSqlCamposConfiguracaoFila())
            	.append(FROM)
                .append(ConfiguracaoFila.getSqlFromConfiguracaoFila())
                .append(" ORDER BY ConfiguracaoFila.PRIORIDADE ");

            stmt = getPreparedStatement(sql.toString());
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					ConfiguracaoFila configuracaoFila = ConfiguracaoFila.getConfiguracaoFilaByResultSet(resultSet);
					configuracaoFilaList.add(configuracaoFila);
				}
			}
        } catch (Exception e) {
            throw new DataException("Falha ao buscar filas ativas.", e);
        } finally {
        	super.close(resultSet);
        }
    	return configuracaoFilaList;
	}

	@Override
	public ConfiguracaoFila buscaMaiorFilaMenorPrioridade()	throws DataException {
		List<ConfiguracaoFila> configuracaoFilaList = new ArrayList<ConfiguracaoFila>();
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
    	try {
            StringBuilder sql = new StringBuilder()
            	.append(SELECT)
            	.append(ConfiguracaoFila.getSqlCamposConfiguracaoFila())
            	.append(FROM)
                .append(ConfiguracaoFila.getSqlFromConfiguracaoFila())
                .append(WHERE)
                .append(" ConfiguracaoFila.FLAG_ATIVO = 1 ")
                .append(" AND ConfiguracaoFila.PRIORIDADE is not null ")
                .append(" ORDER BY ConfiguracaoFila.PRIORIDADE DESC ");

            stmt = getPreparedStatement(sql.toString());
            
			stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null) {
				while (resultSet.next()) {
					ConfiguracaoFila configuracaoFila = ConfiguracaoFila.getConfiguracaoFilaByResultSet(resultSet);
					configuracaoFilaList.add(configuracaoFila);
				}
			}
        } catch (Exception e) {
            throw new DataException("Falha ao buscar filas por build.", e);
        } finally {
        	super.close(resultSet);
        }
    	return configuracaoFilaList != null && !configuracaoFilaList.isEmpty() ? configuracaoFilaList.get(0) : null;
	}
	
	@Override
	public ConfiguracaoFila findByPk(Object id) throws DataException {
		ConfiguracaoFila result = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(ConfiguracaoFila.getSqlCamposConfiguracaoFila())
				.append(FROM)
				.append(ConfiguracaoFila.getSqlFromConfiguracaoFila())
				.append(" WHERE ConfiguracaoFila.ID_CONFIGURACAO_FILA = ? ");
			
			stmt = getPreparedStatement(select.toString());
			ConfiguracaoFila configuracaoFila = (ConfiguracaoFila) id;
			stmt.setInt(1, configuracaoFila.getIdConfiguracaoFila());
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null && resultSet.next()) {
				result = ConfiguracaoFila.getConfiguracaoFilaByResultSet(resultSet);
			}
		} catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		return result;
	}

	@Override
	public List<ConfiguracaoFila> findAtivos(String order) throws DataException {
		List<ConfiguracaoFila> list = new ArrayList<ConfiguracaoFila>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(ConfiguracaoFila.getSqlCamposConfiguracaoFila())
				.append(FROM)
				.append(ConfiguracaoFila.getSqlFromConfiguracaoFila())
				.append(WHERE)
				.append(" ConfiguracaoFila.FLAG_ATIVO = 1 ");

			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					ConfiguracaoFila conf = ConfiguracaoFila.getConfiguracaoFilaByResultSet(resultSet);
					list.add(conf);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return list;
	}
	
	@Override
	public List<ConfiguracaoFila> findByExample(ConfiguracaoFila configuracaoFila) throws DataException {
		return findByExample(configuracaoFila, null);
	}
	
	
	@Override
	public List<ConfiguracaoFila> findByExample(ConfiguracaoFila configuracaoFila, String order) throws DataException {
		List<ConfiguracaoFila> list = new ArrayList<ConfiguracaoFila>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		int index = 0;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(ConfiguracaoFila.getSqlCamposConfiguracaoFila())
				.append(FROM)
				.append(ConfiguracaoFila.getSqlFromConfiguracaoFila())
				.append(WHERE_1_1);
			
			
			if(configuracaoFila != null){
				
				if(configuracaoFila.getIdConfiguracaoFila() != null ){
					select.append(" AND ConfiguracaoFila.ID_CONFIGURACAO_FILA = ? ");
				}	
				if(configuracaoFila.getNome()!= null && !configuracaoFila.getNome().isEmpty()){
					select.append(" AND ConfiguracaoFila.NOME = ? ");
				}
				if(configuracaoFila.getDataCriacao()!= null){
					select.append(" AND ConfiguracaoFila.DATA_CRIACAO BETWEEN ? AND ? ");
				}
				if(configuracaoFila.getFlagAtivo() != null){
					select.append(" AND ConfiguracaoFila.FLAG_ATIVO = ? ");
				}
				if(configuracaoFila.getDescricao()!= null && !configuracaoFila.getDescricao().isEmpty()){
					select.append(" AND ConfiguracaoFila.DESCRICAO = ? ");
				}
				if(configuracaoFila.getFlagBuild()!= null){
					select.append(" AND ConfiguracaoFila.FLAG_BUILD = ? ");
				}
				if(configuracaoFila.getPrioridade()!= null){
					select.append(" AND ConfiguracaoFila.PRIORIDADE = ? ");
				}
				if(configuracaoFila.getLoginUsuario()!= null && !configuracaoFila.getLoginUsuario().isEmpty()){
					select.append(" AND ConfiguracaoFila.LOGIN_USUARIO = ? ");
				}
				if(configuracaoFila.getDataAlteracao()!= null){
					select.append(" AND ConfiguracaoFila.DATA_ALTERACAO BETWEEN ? AND ? ");
				}
				if(configuracaoFila.getSqlWhere()!= null && !configuracaoFila.getSqlWhere().isEmpty()){
					select.append(" AND ConfiguracaoFila.SQL_WHERE = ? ");
				}
				if(configuracaoFila.getSqlOrder()!= null && !configuracaoFila.getSqlOrder().isEmpty()){
					select.append(" AND ConfiguracaoFila.SQL_ORDER = ? ");
				}
				if(configuracaoFila.getFlagBloqueiaCasoImportacao()!= null){
					select.append(" AND ConfiguracaoFila.FLAG_BLOQUEIA_CASO_IMPORTACAO = ? ");
				}
			}
			
			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			if(configuracaoFila != null){
				
				if(configuracaoFila.getIdConfiguracaoFila() != null ){
					stmt.setInt(++index, configuracaoFila.getIdConfiguracaoFila());
				}	
				if(configuracaoFila.getNome()!= null && !configuracaoFila.getNome().isEmpty()){
					stmt.setString(++index, configuracaoFila.getNome());
				}
				if(configuracaoFila.getDataCriacao()!= null){
					Date dataInicio = DateUtil.dataInicioDia(configuracaoFila.getDataCriacao());
					Date dataFim = DateUtil.dataFimDia(configuracaoFila.getDataCriacao());
					stmt.setDate(++index, new java.sql.Date(dataInicio.getTime()));
					stmt.setDate(++index, new java.sql.Date(dataFim.getTime()));
				}
				if(configuracaoFila.getFlagAtivo() != null){
					stmt.setBoolean(++index, configuracaoFila.getFlagAtivo());
				}
				if(configuracaoFila.getDescricao()!= null && !configuracaoFila.getDescricao().isEmpty()){
					stmt.setString(++index, configuracaoFila.getDescricao());
				}
				if(configuracaoFila.getFlagBuild()!= null){
					stmt.setBoolean(++index, configuracaoFila.getFlagBuild());
				}
				if(configuracaoFila.getPrioridade()!= null){
					stmt.setInt(++index, configuracaoFila.getPrioridade());
				}
				if(configuracaoFila.getLoginUsuario()!= null && !configuracaoFila.getLoginUsuario().isEmpty()){
					stmt.setString(++index, configuracaoFila.getLoginUsuario());
				}
				if(configuracaoFila.getDataAlteracao()!= null){
					Date dataInicio = DateUtil.dataInicioDia(configuracaoFila.getDataAlteracao());
					Date dataFim = DateUtil.dataFimDia(configuracaoFila.getDataAlteracao());
					stmt.setDate(++index, new java.sql.Date(dataInicio.getTime()));
					stmt.setDate(++index, new java.sql.Date(dataFim.getTime()));
				}
				if(configuracaoFila.getSqlWhere()!= null && !configuracaoFila.getSqlWhere().isEmpty()){
					stmt.setString(++index, configuracaoFila.getSqlWhere());
				}
				if(configuracaoFila.getSqlOrder()!= null && !configuracaoFila.getSqlOrder().isEmpty()){
					stmt.setString(++index, configuracaoFila.getSqlOrder());
				}
				if(configuracaoFila.getFlagBloqueiaCasoImportacao()!= null){
					stmt.setBoolean(++index, configuracaoFila.getFlagBloqueiaCasoImportacao());
				}
			}
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					ConfiguracaoFila conf = ConfiguracaoFila.getConfiguracaoFilaByResultSet(resultSet);
					list.add(conf);
				}
			}
		} catch (SQLException ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return list;
	}
	
	@Override
	public List<ConfiguracaoFila> findAll() throws DataException {
		return findAll(null);
	}
	
	@Override
	public List<ConfiguracaoFila> findAll(String order) throws DataException {
		List<ConfiguracaoFila> configuracoesFila = new ArrayList<ConfiguracaoFila>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(ConfiguracaoFila.getSqlCamposConfiguracaoFila())
				.append(FROM)
				.append(ConfiguracaoFila.getSqlFromConfiguracaoFila());

			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					ConfiguracaoFila configuracaoFila = ConfiguracaoFila.getConfiguracaoFilaByResultSet(resultSet);
					configuracoesFila.add(configuracaoFila);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return configuracoesFila;
	}
	
}
