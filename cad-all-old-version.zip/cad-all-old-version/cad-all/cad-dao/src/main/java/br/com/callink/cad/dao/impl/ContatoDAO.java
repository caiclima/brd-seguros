package br.com.callink.cad.dao.impl;

import br.com.callink.cad.dao.IContatoDAO;
import br.com.callink.cad.pojo.ContatoTelefone;

public class ContatoDAO extends GenericCadDAO<ContatoTelefone> implements IContatoDAO {

	private static final long serialVersionUID = -467633090256331877L;

	public ContatoDAO() {
		super(ContatoTelefone.class);
	}
}
