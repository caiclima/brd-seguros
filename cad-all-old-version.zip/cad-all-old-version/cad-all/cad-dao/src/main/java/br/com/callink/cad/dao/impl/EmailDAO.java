/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;

import br.com.callink.cad.dao.IEmailDAO;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.Email;
import br.com.callink.cad.pojo.GrupoAnexo;
import br.com.callink.cad.pojo.GrupoEmail;
import br.com.callink.cad.pojo.Log;
import br.com.callink.cad.pojo.Util.DateUtil;
import br.com.callink.cad.sau.exception.DataException;

/**
 *
 * @author Luiz Gustavo (luizgf@swb.com.br)
 */
public class EmailDAO extends GenericCadDAO<Email> implements IEmailDAO {
    
	private static final long serialVersionUID = 8088337113567953530L;

	public EmailDAO() {
		super(Email.class);
	}
	
    @Override
    public List<Email> findEmailsFromCaso(Caso caso) throws DataException {
    	List<Email> emailList = new ArrayList<Email>();
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
    	try {
            StringBuilder sql = new StringBuilder()
            	.append(SELECT)
            	.append(Email.getSqlCamposEmail())
            	.append(FROM)
                .append(Log.getSqlFromLog())
                .append(INNER_JOIN).append(Email.getSqlFromEmail())
                .append(" ON Log.ID_EMAIL = Email.ID_EMAIL ")
                .append(WHERE_1_1)
                .append("  AND Log.ID_CASO = ? ");

            stmt = getPreparedStatement(sql.toString());
            
            stmt.setInt(1, caso.getIdCaso());
            
			stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null) {
				while (resultSet.next()) {
					Email email = Email.getEmailByResultSet(resultSet);
					emailList.add(email);
				}
			}
        } catch (Exception e) {
            throw new DataException(e);
        } finally {
        	super.close(resultSet);
        }
    	return emailList;
    }

    @Override
    public void updateFlagLido(Email email) throws DataException {
        try {
            Query query = getEntityManager().createNativeQuery(" update tb_email set flag_lido = 1 where id_email = :idEmail ");
            query.setParameter("idEmail", email.getIdEmail());
            query.executeUpdate();
        } catch (Exception ex) {
            throw new DataException("Erro ao realizar update no flag lido.",ex);
        }
    }
    
    @Override
    public void updateFlagDesativado(Email email) throws DataException {
        try {
            Query query = getEntityManager().createNativeQuery(" update tb_email set FLAG_DESATIVADO = 1 where id_email = :idEmail ");
            query.setParameter("idEmail", email.getIdEmail());
            query.executeUpdate();
        } catch (Exception ex) {
            throw new DataException("Erro ao realizar update no flag desativado.",ex);
        }
    }

	@Override
	public List<Email> findEmailsSemCaso() throws DataException {
		List<Email> emailList = new ArrayList<Email>();
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder string = new StringBuilder();
			string.append(SELECT)
				.append(Email.getSqlCamposEmail())
				.append(FROM)
				.append(Email.getSqlFromEmail())
				.append(WHERE)
				.append(" Email.FLAG_POSSUI_CASO = 0 and (Email.FLAG_DESATIVADO = 0 or Email.FLAG_DESATIVADO is null)");

            stmt = getPreparedStatement(string.toString());
            
			stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null) {
				while (resultSet.next()) {
					Email email = Email.getEmailByResultSet(resultSet);
					emailList.add(email);
				}
			}
		} catch (Exception e) {
			throw new DataException("Erro ao buscar os e-mails sem caso", e);
		} finally {
			super.close(resultSet);
		}
		return emailList;
	}
	
	@Override
	public List<Email> findByExample(Email example) throws DataException {
		List<Email> emails = new ArrayList<Email>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		int index = 0;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Email.getSqlCamposEmail())
				.append(FROM)
				.append(Email.getSqlFromEmail())
				.append(WHERE_1_1);

			if (example.getIdEmail() != null) {
				select.append(" AND Email.ID_EMAIL = ? ");
			}
			if (example.getAssunto() != null && !example.getAssunto().isEmpty()) {
				select.append(" AND Email.ASSUNTO = ? ");
			}
			if (example.getRemetente() != null) {
				select.append(" AND Email.REMETENTE = ? ");
			}
			if (example.getDestinatario() != null && !example.getDestinatario().isEmpty()) {
				select.append(" AND Email.DESTINATARIO = ? ");
			}
			if (example.getConteudo() != null && !example.getConteudo().isEmpty()) {
				select.append(" AND Email.CONTEUDO = ? ");
			}
			if (example.getDataEnvio() != null) {
				select.append(" AND Email.DATA_ENVIO BETWEEN ? AND ? ");
			}
			if (example.getFlagEnvioPendente() != null) {
				select.append(" AND Email.FLAG_ENVIO_PENDENTE = ? ");
			}
			if (example.getFlagErroEnvio() != null) {
				select.append(" AND Email.FLAG_ERRO_ENVIO = ? ");
			}
			if (example.getFlagEnvio() != null) {
				select.append(" AND Email.FLAG_ENVIO = ? ");
			}
			if (example.getFlagPossuiCaso() != null) {
				select.append(" AND Email.FLAG_POSSUI_CASO = ? ");
			}
			if (example.getFlagLido() != null) {
				select.append(" AND Email.FLAG_LIDO = ? ");
			}
			if (example.getFlagDesativado() != null) {
				select.append(" AND Email.FLAG_DESATIVADO = ? ");
			}
			if (example.getGrupoEmail() != null && example.getGrupoEmail().getIdGrupoEmail() != null) {
				select.append(" AND Email.ID_GRUPO_EMAIL = ? ");
			}
			if (example.getGrupoAnexo() != null && example.getGrupoAnexo().getIdGrupoAnexo() != null) {
				select.append(" AND Email.ID_GRUPO_ANEXO = ? ");
			}
			if (example.getPai() != null && example.getPai().getIdEmail() != null) {
				select.append(" AND Email.ID_PAI = ? ");
			}
			if (example.getDestinatarioParaExibicao() != null && !example.getDestinatarioParaExibicao().isEmpty()) {
				select.append(" AND Email.DESTINATARIO_PARA_EXIBICAO = ? ");
			}
			
			stmt = getPreparedStatement(select.toString());
			
			if (example.getIdEmail() != null) {
				stmt.setInt(++index, example.getIdEmail());
			}
			if (example.getAssunto() != null && !example.getAssunto().isEmpty()) {
				stmt.setString(++index, example.getAssunto());
			}
			if (example.getRemetente() != null) {
				stmt.setString(++index, example.getRemetente());
			}
			if (example.getDestinatario() != null && !example.getDestinatario().isEmpty()) {
				stmt.setString(++index, example.getDestinatario());
			}
			if (example.getConteudo() != null && !example.getConteudo().isEmpty()) {
				stmt.setString(++index, example.getConteudo());
			}
			if (example.getDataEnvio() != null) {
				Date dataInicio = DateUtil.dataInicioDia(example.getDataEnvio());
				Date dataFim = DateUtil.dataFimDia(example.getDataEnvio());
				stmt.setDate(++index,  new java.sql.Date(dataInicio.getTime()));
				stmt.setDate(++index, new java.sql.Date(dataFim.getTime()));
			}
			if (example.getFlagEnvioPendente() != null) {
				stmt.setBoolean(++index, example.getFlagEnvioPendente());
			}
			if (example.getFlagErroEnvio() != null) {
				stmt.setBoolean(++index, example.getFlagErroEnvio());
			}
			if (example.getFlagEnvio() != null) {
				stmt.setBoolean(++index, example.getFlagEnvio());
			}
			if (example.getFlagPossuiCaso() != null) {
				stmt.setBoolean(++index, example.getFlagPossuiCaso());
			}
			if (example.getFlagLido() != null) {
				stmt.setBoolean(++index, example.getFlagLido());
			}
			if (example.getFlagDesativado() != null) {
				stmt.setBoolean(++index, example.getFlagDesativado());
			}
			if (example.getGrupoEmail() != null && example.getGrupoEmail().getIdGrupoEmail() != null) {
				stmt.setInt(++index, example.getGrupoEmail().getIdGrupoEmail() );
			}
			if (example.getGrupoAnexo() != null && example.getGrupoAnexo().getIdGrupoAnexo() != null) {
				stmt.setInt(++index, example.getGrupoAnexo().getIdGrupoAnexo());
			}
			if (example.getPai() != null && example.getPai().getIdEmail() != null) {
				stmt.setInt(++index,example.getPai().getIdEmail());
			}
			if (example.getDestinatarioParaExibicao() != null && !example.getDestinatarioParaExibicao().isEmpty()) {
				stmt.setString(++index, example.getDestinatarioParaExibicao());
			}
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					Email email = Email.getEmailByResultSet(resultSet);
					emails.add(email);
				}
			}
		} catch (SQLException ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return emails;
	}
	
	@Override
	public Email findByPk(Object id) throws DataException {
		Email result = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Email.getSqlCamposEmail())
				.append(", ")
				.append(GrupoEmail.getSqlCamposGrupoEmail())
				.append(", ")
				.append(GrupoAnexo.getSqlCamposGrupoAnexo())
				.append(", ")
				
				.append(" \nEmailPai.ID_EMAIL as 'EmailPai.ID_EMAIL',")
				.append(" \nEmailPai.ASSUNTO as 'EmailPai.ASSUNTO',")
				.append(" \nEmailPai.REMETENTE as 'EmailPai.REMETENTE',")
			    .append(" \nEmailPai.DESTINATARIO as 'EmailPai.DESTINATARIO',")
			    .append(" \nEmailPai.CONTEUDO as 'EmailPai.CONTEUDO',")
			    .append(" \nEmailPai.DATA_ENVIO as 'EmailPai.DATA_ENVIO',")
			    .append(" \nEmailPai.FLAG_ENVIO_PENDENTE as 'EmailPai.FLAG_ENVIO_PENDENTE',")
			    .append(" \nEmailPai.FLAG_ERRO_ENVIO as 'EmailPai.FLAG_ERRO_ENVIO',")
			    .append(" \nEmailPai.FLAG_ENVIO as 'EmailPai.FLAG_ENVIO',")
			    .append(" \nEmailPai.FLAG_POSSUI_CASO as 'EmailPai.FLAG_POSSUI_CASO',")
			    .append(" \nEmailPai.FLAG_LIDO as 'EmailPai.FLAG_LIDO',")
			    .append(" \nEmailPai.FLAG_DESATIVADO as 'EmailPai.FLAG_DESATIVADO',")
			    .append(" \nEmailPai.ID_GRUPO_EMAIL as 'EmailPai.ID_GRUPO_EMAIL',")
			    .append(" \nEmailPai.ID_GRUPO_ANEXO as 'EmailPai.ID_GRUPO_ANEXO',")
			    .append(" \nEmailPai.ID_PAI as 'EmailPai.ID_PAI',")
			    .append(" \nEmailPai.destinatario_para_exibicao as 'EmailPai.DESTINATARIO_PARA_EXIBICAO'")
				
				.append(FROM)
				.append(Email.getSqlFromEmail())
				.append(LEFT_JOIN).append(GrupoEmail.getSqlFromGrupoEmail())
				.append(" ON Email.ID_GRUPO_EMAIL = GrupoEmail.ID_GRUPO_EMAIL ")
				.append(LEFT_JOIN).append(GrupoAnexo.getSqlFromGrupoAnexo())
				.append(" ON Email.ID_GRUPO_ANEXO = GrupoAnexo.ID_GRUPO_ANEXO ")
				.append(LEFT_JOIN).append(" TB_Email AS EmailPai with(nolock)  ")
				.append(" ON Email.ID_PAI = EmailPai.ID_EMAIL ")
				.append(" WHERE Email.ID_EMAIL = ? ");
			
			stmt = getPreparedStatement(select.toString());
			Email email = (Email) id;
			stmt.setInt(1, email.getIdEmail());
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null && resultSet.next()) {
				result = Email.getEmailByResultSet(resultSet);
				result.setGrupoEmail(GrupoEmail.getGrupoEmailByResultSet(resultSet));
				result.setGrupoAnexo(GrupoAnexo.getGrupoAnexoByResultSet(resultSet));
				
				Email emailPai = new Email();
				emailPai.setIdEmail(resultSet.getInt("EmailPai.ID_EMAIL"));
				emailPai.setAssunto(resultSet.getString("EmailPai.ASSUNTO"));
				emailPai.setRemetente(resultSet.getString("EmailPai.REMETENTE"));
				emailPai.setDestinatario(resultSet.getString("EmailPai.DESTINATARIO"));
	            String texto = null;
	            texto = resultSet.getString("EmailPai.CONTEUDO");
	            emailPai.setConteudo(texto);

	            emailPai.setDataEnvio(resultSet.getTimestamp("EmailPai.DATA_ENVIO"));
	            emailPai.setFlagEnvioPendente(resultSet.getBoolean("EmailPai.FLAG_ENVIO_PENDENTE"));
	            emailPai.setFlagErroEnvio(resultSet.getBoolean("EmailPai.FLAG_ERRO_ENVIO"));
	            emailPai.setFlagEnvio(resultSet.getBoolean("EmailPai.FLAG_ENVIO"));
	            emailPai.setFlagPossuiCaso(resultSet.getBoolean("EmailPai.FLAG_POSSUI_CASO"));
	            emailPai.setFlagLido(resultSet.getBoolean("EmailPai.FLAG_LIDO"));
	            emailPai.setFlagDesativado(resultSet.getBoolean("EmailPai.FLAG_DESATIVADO"));
	            GrupoEmail grupoEmail = new GrupoEmail();
	            grupoEmail.setIdGrupoEmail(resultSet.getInt("EmailPai.ID_GRUPO_EMAIL") == 0 ? null : resultSet.getInt("EmailPai.ID_GRUPO_EMAIL"));
	            emailPai.setGrupoEmail(grupoEmail);

	            GrupoAnexo grupoAnexo = new GrupoAnexo();
	            grupoAnexo.setIdGrupoAnexo(resultSet.getInt("EmailPai.ID_GRUPO_ANEXO") == 0 ? null : resultSet.getInt("EmailPai.ID_GRUPO_ANEXO"));
	            emailPai.setGrupoAnexo(grupoAnexo);

	            emailPai.setDestinatarioParaExibicao(resultSet.getString("EmailPai.DESTINATARIO_PARA_EXIBICAO"));
	            
	            result.setPai(emailPai);
			}
		} catch (SQLException e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		return result;
	}
	
	@Override
    public List<Email> findEmailsFromCasoByFlagEnvio(Caso caso, Boolean flagEnvio) throws DataException {
    	List<Email> emailList = new ArrayList<Email>();
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
    	try {
            StringBuilder sql = new StringBuilder()
            	.append(SELECT)
            	.append(Email.getSqlCamposEmail())
            	.append(FROM)
                .append(Log.getSqlFromLog())
                .append(INNER_JOIN).append(Email.getSqlFromEmail())
                .append(" ON Log.ID_EMAIL = Email.ID_EMAIL ")
                .append(WHERE_1_1)
                .append("  AND Log.ID_CASO = ? ")
                .append("  AND Email.FLAG_ENVIO = ? ");

            stmt = getPreparedStatement(sql.toString());
            
            stmt.setInt(1, caso.getIdCaso());
            stmt.setInt(2, ((flagEnvio) ? 1 : 0));
            
			stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null) {
				while (resultSet.next()) {
					Email email = Email.getEmailByResultSet(resultSet);
					emailList.add(email);
				}
			}
        } catch (Exception e) {
            throw new DataException(e);
        } finally {
        	super.close(resultSet);
        }
    	return emailList;
    }
	
	@Override
	public List<Email> findEmailsSemCasoByExample(Email example, Date dataInicio, Date dataFim) throws DataException {
		List<Email> emailList = new ArrayList<Email>();
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
		
		try {
			StringBuilder select = new StringBuilder();
			select.append(SELECT)
				.append(Email.getSqlCamposEmail())
				.append(FROM)
				.append(Email.getSqlFromEmail())
				.append(WHERE)
				.append(" Email.FLAG_POSSUI_CASO = 0 and (Email.FLAG_DESATIVADO = 0 or Email.FLAG_DESATIVADO is null)");
			
			String whereClause = buildWhereClause(example, dataInicio, dataFim);
			select.append(whereClause);
			
            stmt = getPreparedStatement(select.toString());
            setParameters(stmt, example, dataInicio, dataFim);
            
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					Email email = Email.getEmailByResultSet(resultSet);
					emailList.add(email);
				}
			}
		} catch (Exception e) {
			throw new DataException("Erro ao buscar os e-mails sem caso", e);
		} finally {
			super.close(resultSet);
		}
		return emailList;
	}

	private void setParameters(PreparedStatement stmt, Email example, Date dataInicio, Date dataFim) throws SQLException {
		int index = 0;
		
		if(example.getRemetente() != null && !"".equals(example.getRemetente().trim())){
			stmt.setString(++index, "%"+example.getRemetente()+"%");
		}
		
		if(example.getDestinatario() != null && !"".equals(example.getDestinatario().trim())){
			stmt.setString(++index, "%"+example.getDestinatario()+"%");
		}
		
		if(example.getAssunto() != null && !"".equals(example.getAssunto().trim())){
			stmt.setString(++index, "%"+example.getAssunto()+"%");
		}
		
		if(dataInicio != null){
			stmt.setString(++index,formatDate(dataInicio, "yyyy/MM/dd '00:00:00'"));
		}
		
		if(dataFim != null){
			stmt.setString(++index, formatDate(dataFim, "yyyy/MM/dd '23:59:59'"));
		}		
	}

	private String buildWhereClause(Email example, Date dataInicio, Date dataFim) {
		StringBuilder whereClause = new StringBuilder();
		
		if(example.getRemetente() != null && !"".equals(example.getRemetente().trim())){
			whereClause.append(" AND Email.remetente like ? ");
		}
		
		if(example.getDestinatario() != null && !"".equals(example.getDestinatario().trim())){
			whereClause.append(" AND Email.destinatario like ? ");
		}
		
		if(example.getAssunto() != null && !"".equals(example.getAssunto().trim())){
			whereClause.append(" AND Email.assunto like ? ");
		}
		
		if(dataInicio != null){
			whereClause.append(" AND Email.data_envio >= ? ");
		}
		
		if(dataFim != null){
			whereClause.append(" AND Email.data_envio <= ? ");
		}
		
		return whereClause.toString();
	}
	
	public String formatDate(Date date, String pattern){
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		return sdf.format(date);
	}
    
}
