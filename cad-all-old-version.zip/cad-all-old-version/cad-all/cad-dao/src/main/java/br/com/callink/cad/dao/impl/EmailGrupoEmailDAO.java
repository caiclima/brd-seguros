/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import br.com.callink.cad.dao.IEmailGrupoEmailDAO;
import br.com.callink.cad.pojo.Email;
import br.com.callink.cad.pojo.EmailGrupoEmail;
import br.com.callink.cad.pojo.GrupoEmail;
import br.com.callink.cad.pojo.Util.DateUtil;
import br.com.callink.cad.sau.exception.DataException;

/**
 *
 * @author Luiz Gustavo F. (luizgf@swb.com.br)
 */
public class EmailGrupoEmailDAO extends GenericCadDAO<EmailGrupoEmail> implements IEmailGrupoEmailDAO {
	
	private static final long serialVersionUID = -8388902015298017258L;

	public EmailGrupoEmailDAO() {
		super(EmailGrupoEmail.class);
	}
	
	@Override
	public EmailGrupoEmail findByPk(Object id) throws DataException {
		EmailGrupoEmail result = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(EmailGrupoEmail.getSqlCamposEmailGrupoEmail())
				.append(", ")
				.append(Email.getSqlCamposEmail())
				.append(", ")
				.append(GrupoEmail.getSqlCamposGrupoEmail())
				.append(FROM)
				.append(EmailGrupoEmail.getSqlFromEmailGrupoEmail())
				.append(LEFT_JOIN).append(Email.getSqlFromEmail())
				.append(" ON EmailGrupoEmail.ID_EMAIL = Email.ID_EMAIL ")
				.append(LEFT_JOIN).append(GrupoEmail.getSqlFromGrupoEmail())
				.append(" ON EmailGrupoEmail.ID_GRUPO_EMAIL = GrupoEmail.ID_GRUPO_EMAIL ")
				.append(" WHERE EmailGrupoEmail.ID_EMAIL_GRUPO_EMAIL = ? ");
			
			stmt = getPreparedStatement(select.toString());
			
			EmailGrupoEmail emailGrupoEmail = (EmailGrupoEmail) id;
			
			stmt.setInt(1, emailGrupoEmail.getIdEmailGrupoEmail());
			
			stmt.execute();
			
			resultSet = stmt.getResultSet();
			if (resultSet != null && resultSet.next()) {
				result = EmailGrupoEmail.getEmailGrupoEmailByResultSet(resultSet);
				result.setEmail(Email.getEmailByResultSet(resultSet));
				result.setGrupoEmail(GrupoEmail.getGrupoEmailByResultSet(resultSet));
			}
		} catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		return result;
	}
	
	@Override
	public List<EmailGrupoEmail> findByExample(EmailGrupoEmail example) throws DataException {
		return findByExample(example, null);
	}
	
	@Override
	public List<EmailGrupoEmail> findByExample(EmailGrupoEmail example, String order) throws DataException {
		List<EmailGrupoEmail> emailGruposEmail = new ArrayList<EmailGrupoEmail>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		int index =0;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(EmailGrupoEmail.getSqlCamposEmailGrupoEmail())
				.append(FROM)
				.append(EmailGrupoEmail.getSqlFromEmailGrupoEmail())
				.append(WHERE_1_1);

			if(example!=null){
			
				if(example.getIdEmailGrupoEmail() != null ){
					select.append(" AND EmailGrupoEmail.ID_EMAIL_GRUPO_EMAIL = ? ");
				}
				if(example.getEmail()!= null && example.getEmail().getIdEmail()!= null){
					select.append(" AND EmailGrupoEmail.ID_EMAIL = ? ");
				}
				if(example.getGrupoEmail()!= null && example.getGrupoEmail().getIdGrupoEmail()!= null){
					select.append(" AND EmailGrupoEmail.ID_GRUPO_EMAIL = ? ");
				}
			}
			
			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			if(example!=null){
				
				if (example.getIdEmailGrupoEmail() != null) {
					stmt.setInt(++index, example.getIdEmailGrupoEmail());
				}
				if (example.getEmail()!= null && example.getEmail().getIdEmail()!= null) {
					stmt.setInt(++index, example.getEmail().getIdEmail());
				}
				if (example.getGrupoEmail()!= null && example.getGrupoEmail().getIdGrupoEmail()!= null) {
					stmt.setInt(++index, example.getGrupoEmail().getIdGrupoEmail());
				}
			}
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					EmailGrupoEmail emailGrupoEmail = EmailGrupoEmail.getEmailGrupoEmailByResultSet(resultSet);
					emailGruposEmail.add(emailGrupoEmail);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return emailGruposEmail;
	}
	
}
