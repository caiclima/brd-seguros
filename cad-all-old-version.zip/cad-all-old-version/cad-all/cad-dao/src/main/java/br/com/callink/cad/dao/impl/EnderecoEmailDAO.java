/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import br.com.callink.cad.dao.IEnderecoEmailDAO;
import br.com.callink.cad.pojo.EnderecoEmail;
import br.com.callink.cad.pojo.Util.DateUtil;
import br.com.callink.cad.sau.exception.DataException;

/**
 *
 * @author Luiz Gustavo (luizgf@swb.com.br)
 */
public class EnderecoEmailDAO extends GenericCadDAO<EnderecoEmail> implements IEnderecoEmailDAO {
	
	private static final long serialVersionUID = 7993000223742069726L;

	public EnderecoEmailDAO() {
		super(EnderecoEmail.class);
	}
	
	@Override
	public EnderecoEmail findByPk(Object id) throws DataException {
		EnderecoEmail result = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(EnderecoEmail.getSqlCamposEnderecoEmail())
				.append(FROM)
				.append(EnderecoEmail.getSqlFromEnderecoEmail())
				.append(" WHERE EnderecoEmail.ID_ENDERECO_EMAIL = ? ");
			
			stmt = getPreparedStatement(select.toString());
			
			EnderecoEmail enderecoEmail = (EnderecoEmail) id;
			
			stmt.setInt(1, enderecoEmail.getIdEnderecoEmail());
			
			stmt.execute();
			
			resultSet = stmt.getResultSet();
			if (resultSet != null && resultSet.next()) {
				result = EnderecoEmail.getEnderecoEmailByResultSet(resultSet);
			}
		} catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		return result;
	}
	
	@Override
	public List<EnderecoEmail> findByExample(EnderecoEmail example) throws DataException {
		return findByExample(example, null);
	}
	
	@Override
	public List<EnderecoEmail> findByExample(EnderecoEmail example, String order) throws DataException {
		List<EnderecoEmail> enderecoEmails = new ArrayList<EnderecoEmail>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		int index = 0;
		
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(EnderecoEmail.getSqlCamposEnderecoEmail())
				.append(FROM)
				.append(EnderecoEmail.getSqlFromEnderecoEmail())
				.append(WHERE_1_1);

			if (example.getIdEnderecoEmail() != null) {
				select.append(" AND EnderecoEmail.ID_ENDERECO_EMAIL = ? ");
			}
			if (example.getDescricao() != null && !example.getDescricao().isEmpty()) {
				select.append(" AND EnderecoEmail.DESCRICAO like ? ");
			}
			if (example.getEnderecoEmail() != null && !example.getEnderecoEmail().isEmpty()) {
				select.append(" AND EnderecoEmail.ENDERECO_EMAIL like ? ");
			}
			if (example.getFlagAtivo() != null) {
				select.append(" AND EnderecoEmail.FLAG_ATIVO = ? ");
			}
			if (example.getDataCriacao() != null) {
				select.append(" AND EnderecoEmail.DATA_CRIACAO BETWEEN ? AND ? ");
			}
			
			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			if (example.getIdEnderecoEmail() != null) {
				stmt.setInt(++index, example.getIdEnderecoEmail());
			}
			if (example.getDescricao() != null && !example.getDescricao().isEmpty()) {
				stmt.setString(++index,  new StringBuilder(example.getDescricao()).append("%").toString() );
			}
			if (example.getEnderecoEmail() != null && !example.getEnderecoEmail().isEmpty()) {
				stmt.setString(++index, new StringBuilder(example.getEnderecoEmail()).append("%").toString() );
			}
			if (example.getFlagAtivo() != null) {
				stmt.setBoolean(++index, example.getFlagAtivo());
			}
			if (example.getDataCriacao() != null) {
				Date dataInicio = DateUtil.dataInicioDia(example.getDataCriacao());
				Date dataFim = DateUtil.dataFimDia(example.getDataCriacao());
				stmt.setDate(++index, new java.sql.Date(dataInicio.getTime()));
				stmt.setDate(++index, new java.sql.Date(dataFim.getTime()));
			}
					
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					EnderecoEmail enderecoEmail = EnderecoEmail.getEnderecoEmailByResultSet(resultSet);
					enderecoEmails.add(enderecoEmail);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return enderecoEmails;
	}
	
	@Override
	public List<EnderecoEmail> findAtivos(String order) throws DataException {
		List<EnderecoEmail> enderecosEmail = new ArrayList<EnderecoEmail>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(EnderecoEmail.getSqlCamposEnderecoEmail())
				.append(FROM)
				.append(EnderecoEmail.getSqlFromEnderecoEmail())
				.append(WHERE)
				.append(" EnderecoEmail.FLAG_ATIVO = 1 ");

			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					EnderecoEmail enderecoEmail = EnderecoEmail.getEnderecoEmailByResultSet(resultSet);
					enderecosEmail.add(enderecoEmail);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return enderecosEmail;
	}
	
}

