/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import br.com.callink.cad.dao.IEquipeDAO;
import br.com.callink.cad.pojo.Equipe;
import br.com.callink.cad.pojo.Util.DateUtil;
import br.com.callink.cad.sau.exception.DataException;

/**
 *
 * @author Rogério Moreira de Andrade. [rogeriom@swb.com.br]
 */
public class EquipeDAO extends GenericCadDAO<Equipe> implements IEquipeDAO {

	private static final long serialVersionUID = -8866690592349643226L;

	public EquipeDAO() {
		super(Equipe.class);
	}
	
	@Override
	public List<Equipe> findAtivos() throws DataException {
		return findAtivos(null);
	}
	
    @Override
    public List<Equipe> findAtivos(String order) throws DataException {
    	List<Equipe> equipeList = new ArrayList<Equipe>();
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
    	try {
            StringBuilder sql = new StringBuilder()
            	.append(SELECT)
            	.append(Equipe.getSqlEquipe())
            	.append(FROM)
                .append(Equipe.getSqlFromEquipe())
                .append(WHERE)
                .append(" Equipe.FLAG_ATIVO = 1 ");
            
            if (order != null && !order.isEmpty()) {
            	sql.append(String.format(" ORDER BY %s ", order));
			}

            stmt = getPreparedStatement(sql.toString());
            
			stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null) {
				while (resultSet.next()) {
					Equipe equipe = Equipe.getEquipeByResultSet(resultSet);
					equipeList.add(equipe);
				}
			}
        } catch (Exception e) {
            throw new DataException(e);
        } finally {
        	super.close(resultSet);
        }
    	return equipeList;
    }
    
    @Override
    public Equipe findByPk(Object id) throws DataException {
    	Equipe result = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Equipe.getSqlEquipe())
				.append(FROM)
				.append(Equipe.getSqlFromEquipe())
				.append(" WHERE Equipe.ID_EQUIPE = ? ");
			
			stmt = getPreparedStatement(select.toString());
			
			Equipe equipe = (Equipe) id;
			
			stmt.setInt(1, equipe.getIdEquipe());
			
			stmt.execute();
			
			resultSet = stmt.getResultSet();
			if (resultSet != null && resultSet.next()) {
				result = Equipe.getEquipeByResultSet(resultSet);
			}
		} catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		return result;
	}
    
    @Override
	public List<Equipe> findByExample(Equipe example) throws DataException {
		return findByExample(example, null);
	}
	
	@Override
	public List<Equipe> findByExample(Equipe example, String order) throws DataException {
		List<Equipe> equipes = new ArrayList<Equipe>();
		int index = 0;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Equipe.getSqlEquipe())
				.append(FROM)
				.append(Equipe.getSqlFromEquipe())
				.append(WHERE_1_1);

			if(example!= null){
			
				if (example.getIdEquipe() != null) {
					select.append(" AND Equipe.ID_EQUIPE = ? ");
				}
				if (example.getNome() != null && !example.getNome().isEmpty()) {
					select.append(" AND Equipe.NOME like ? ");
				}
				if (example.getDataCriacao() != null) {
					select.append(" AND Equipe.DATA_CRIACAO BETWEEN ? AND ? ");
				}
				if (example.getFlagAtivo() != null) {
					select.append(" AND Equipe.FLAG_ATIVO = ? ");
				}
				if (example.getFlagPrioridade() != null) {
					select.append(" AND Equipe.FLAG_PRIORIDADE = ? ");
				}
			}
			
			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			if(example!= null){
			
				if (example.getIdEquipe() != null) {
					stmt.setInt(++index, example.getIdEquipe());
				}
				if (example.getNome() != null && !example.getNome().isEmpty()) {
					stmt.setString(++index, new StringBuilder(example.getNome()).append("%").toString());
				}
				if (example.getDataCriacao() != null) {
					Date dataInicio = DateUtil.dataInicioDia(example.getDataCriacao());
					Date dataFim = DateUtil.dataFimDia(example.getDataCriacao());
					stmt.setDate(++index, new java.sql.Date(dataInicio.getTime()));
					stmt.setDate(++index, new java.sql.Date(dataFim.getTime()));
				}
				if (example.getFlagAtivo() != null) {
					stmt.setBoolean(++index, example.getFlagAtivo());
				}
				if (example.getFlagPrioridade() != null) {
					stmt.setBoolean(++index, example.getFlagPrioridade());
				}
			}
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					Equipe equipe = Equipe.getEquipeByResultSet(resultSet);
					equipes.add(equipe);
				}
			}
		} catch (SQLException ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return equipes;
	}
    	
}
