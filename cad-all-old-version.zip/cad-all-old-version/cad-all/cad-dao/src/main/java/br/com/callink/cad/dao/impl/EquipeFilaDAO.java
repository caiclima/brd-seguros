package br.com.callink.cad.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.Query;
import br.com.callink.cad.dao.IEquipeFilaDAO;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.pojo.Equipe;
import br.com.callink.cad.pojo.EquipeFila;
import br.com.callink.cad.sau.exception.DataException;

public class EquipeFilaDAO extends GenericCadDAO<EquipeFila> implements IEquipeFilaDAO {

	private static final long serialVersionUID = 1337314899937185921L;

	public EquipeFilaDAO() {
		super(EquipeFila.class);
	}
	
    @Override
    public void saveList(List<EquipeFila> equipeFilaList) throws DataException {
        for (EquipeFila equipeFila : equipeFilaList) {
            super.save(equipeFila);
        }
    }

    @Override
    public List<EquipeFila> buscaEquipeFilaPelaPrioridade(Equipe equipe) throws DataException {
    	List<EquipeFila> equipeFilaList = new ArrayList<EquipeFila>();
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder string = new StringBuilder()
			.append(SELECT)
        	.append(EquipeFila.getSqlCamposEquipeFila())
        	.append(", ")
            .append(ConfiguracaoFila.getSqlCamposConfiguracaoFila())
        	.append(FROM)
            .append(EquipeFila.getSqlFromEquipeFila())
            .append(INNER_JOIN).append(ConfiguracaoFila.getSqlFromConfiguracaoFila())
            .append(" ON EquipeFila.ID_CONFIGURACAO_FILA = ConfiguracaoFila.ID_CONFIGURACAO_FILA ")
            .append(WHERE_1_1)
	        .append(" and EquipeFila.id_equipe = ? order by EquipeFila.quantidade_caso_fila DESC ");
			
	        stmt = getPreparedStatement(string.toString());
	        stmt.setInt(1, equipe.getIdEquipe());
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					EquipeFila equipeFila = EquipeFila.getEquipeFilaByResultSet(resultSet);
					equipeFila.setConfiguracaoFila(ConfiguracaoFila.getConfiguracaoFilaByResultSet(resultSet));
					equipeFilaList.add(equipeFila);
				}
			}
		} catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
        return equipeFilaList;
    }

    @Override
    public EquipeFila buscaByEquipeAndConfiguracaoFila(Equipe equipe, ConfiguracaoFila configuracaoFila) throws DataException {
    	EquipeFila equipeFilaResult = null;
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
    	try {
            StringBuilder sql = new StringBuilder()
            	.append(SELECT)
            	.append(EquipeFila.getSqlCamposEquipeFila())
            	.append(FROM)
                .append(EquipeFila.getSqlFromEquipeFila())
                .append(WHERE)
                .append(" EquipeFila.ID_EQUIPE = ? ")
                .append(" AND EquipeFila.ID_CONFIGURACAO_FILA = ? ");

            stmt = getPreparedStatement(sql.toString());
            
            stmt.setInt(1, equipe.getIdEquipe());
            stmt.setInt(2, configuracaoFila.getIdConfiguracaoFila());
            
			stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null && resultSet.next()) {
				equipeFilaResult = EquipeFila.getEquipeFilaByResultSet(resultSet);
			}
        } catch (Exception e) {
            throw new DataException(e);
        } finally {
        	super.close(resultSet);
        }
    	return equipeFilaResult;
    }

    @Override
    public List<EquipeFila> buscaByEquipeFilaListByEquipeEConfiguracaoFila(Equipe equipe, ConfiguracaoFila configuracaoFila) throws DataException {
    	List<EquipeFila> equipeFilaList = new ArrayList<EquipeFila>();
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
		int index = 0;
    	try {
            StringBuilder sql = new StringBuilder()
            	.append(SELECT)
            	.append(EquipeFila.getSqlCamposEquipeFila())
            	.append(FROM)
                .append(EquipeFila.getSqlFromEquipeFila())
                .append(WHERE_1_1);
            
            if (equipe != null && equipe.getPK() != null) {
            	sql.append(" AND EquipeFila.ID_EQUIPE = ? ");
            }
            if (configuracaoFila != null && configuracaoFila.getPK() != null) {
            	sql.append(" AND EquipeFila.ID_CONFIGURACAO_FILA = ? ");
            }
            sql.append(" ORDER BY EquipeFila.QUANTIDADE_CASO_FILA DESC ");

            stmt = getPreparedStatement(sql.toString());
            
            if (equipe != null && equipe.getPK() != null) {
            	stmt.setInt(++index, equipe.getPK());
            }
            if (configuracaoFila != null && configuracaoFila.getPK() != null) {
            	stmt.setInt(++index, configuracaoFila.getPK());
            }
            
			stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null) {
				while (resultSet.next()) {
					EquipeFila equipeFila = EquipeFila.getEquipeFilaByResultSet(resultSet);
					equipeFilaList.add(equipeFila);
				}
			}
        } catch (Exception e) {
            throw new DataException(e);
        } finally {
        	super.close(resultSet);
        }
    	return equipeFilaList;
    }

    @Override
    public List<EquipeFila> buscaPorEquipeList(List<Equipe> equipeList) throws DataException {
    	List<EquipeFila> equipeFilaList = new ArrayList<EquipeFila>();
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
    	try {
            StringBuilder sql = new StringBuilder()
            	.append(SELECT)
            	.append(EquipeFila.getSqlCamposEquipeFila())
            	.append(", ")
            	.append(Equipe.getSqlEquipe())
            	.append(", ")
            	.append(ConfiguracaoFila.getSqlCamposConfiguracaoFila())
            	.append(FROM)
                .append(EquipeFila.getSqlFromEquipeFila())
                .append(INNER_JOIN).append(Equipe.getSqlFromEquipe())
                .append(" ON EquipeFila.ID_EQUIPE = Equipe.ID_EQUIPE ")
                .append(INNER_JOIN).append(ConfiguracaoFila.getSqlFromConfiguracaoFila())
                .append(" ON EquipeFila.ID_CONFIGURACAO_FILA = ConfiguracaoFila.ID_CONFIGURACAO_FILA ")
                .append(WHERE_1_1);

            StringBuilder equipeIn = new StringBuilder();
            for (int i = 0; i < equipeList.size(); i++) {
            	if (i != 0) {
            		equipeIn.append(", ");
            	}
            	equipeIn.append(equipeList.get(i).getIdEquipe());
            }
            
            sql.append(String.format(" AND EquipeFila.ID_EQUIPE in (%s) ", equipeIn.toString()));
            
            stmt = getPreparedStatement(sql.toString());
            
			stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null) {
				while (resultSet.next()) {
					EquipeFila equipeFila = EquipeFila.getEquipeFilaByResultSet(resultSet);
					equipeFila.setEquipe(Equipe.getEquipeByResultSet(resultSet));
					equipeFila.setConfiguracaoFila(ConfiguracaoFila.getConfiguracaoFilaByResultSet(resultSet));
					equipeFilaList.add(equipeFila);
				}
			}
        } catch (Exception e) {
            throw new DataException(e);
        } finally {
        	super.close(resultSet);
        }
    	return equipeFilaList;
    }
    
	@Override
    public List<EquipeFila> findFilasByEquipe(Equipe equipe) throws DataException {
		List<EquipeFila> equipeFilaList = new ArrayList<EquipeFila>();
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
    	try {
            StringBuilder sql = new StringBuilder()
            	.append(SELECT)
            	.append(EquipeFila.getSqlCamposEquipeFila())
            	.append(", ")
            	.append(Equipe.getSqlEquipe())
            	.append(", ")
            	.append(ConfiguracaoFila.getSqlCamposConfiguracaoFila())
            	.append(FROM)
                .append(EquipeFila.getSqlFromEquipeFila())
                .append(INNER_JOIN).append(Equipe.getSqlFromEquipe())
                .append(" ON EquipeFila.ID_EQUIPE = Equipe.ID_EQUIPE ")
                .append(INNER_JOIN).append(ConfiguracaoFila.getSqlFromConfiguracaoFila())
                .append(" ON EquipeFila.ID_CONFIGURACAO_FILA = ConfiguracaoFila.ID_CONFIGURACAO_FILA  ")
                .append(WHERE_1_1)
                .append(" AND EquipeFila.ID_EQUIPE = ? ");

            stmt = getPreparedStatement(sql.toString());
            
            stmt.setInt(1, equipe.getIdEquipe());
            
			stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null) {
				while (resultSet.next()) {
					EquipeFila equipeFila = EquipeFila.getEquipeFilaByResultSet(resultSet);
					equipeFila.setEquipe(Equipe.getEquipeByResultSet(resultSet));
					equipeFila.setConfiguracaoFila(ConfiguracaoFila.getConfiguracaoFilaByResultSet(resultSet));
					equipeFilaList.add(equipeFila);
				}
			}
        } catch (Exception e) {
            throw new DataException(e);
        } finally {
        	super.close(resultSet);
        }
    	return equipeFilaList;
    } 
    
    @Override
    public void limpaEquipeFila(Equipe equipe) throws DataException {
        Query query = getEntityManager().createNativeQuery(" delete from TB_EQUIPE_FILA where id_equipe = :idEquipe ");
        query.setParameter("idEquipe", equipe.getIdEquipe());
        query.executeUpdate();
    }   
    
    @Override
    public List<EquipeFila> findByExample(EquipeFila example) throws DataException {
		List<EquipeFila> equipeFilas = new ArrayList<EquipeFila>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		int index=0;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(EquipeFila.getSqlCamposEquipeFila())
				.append(FROM)
				.append(EquipeFila.getSqlFromEquipeFila())
				.append(WHERE_1_1);

			if(example!=null){
			
				if (example.getIdEquipeFila() != null) {
					select.append(" AND EquipeFila.ID_EQUIPE_FILA = ? ");
				}
				if (example.getQuantidadeCasoAtendido() != null) {
					select.append(" AND EquipeFila.QUANTIDADE_CASO_ATENDIDO = ? ");
				}
				if (example.getQuantidadeCasoFila() != null) {
					select.append(" AND EquipeFila.QUANTIDADE_CASO_FILA = ? ");
				}
				if (example.getEquipe() != null && example.getEquipe().getIdEquipe() != null) {
					select.append(" AND EquipeFila.ID_EQUIPE = ? ");
				}
				if (example.getConfiguracaoFila() != null && example.getConfiguracaoFila().getIdConfiguracaoFila() != null) {
					select.append(" AND EquipeFila.ID_CONFIGURACAO_FILA = ? ");
				}
			}
			
			stmt = getPreparedStatement(select.toString());
			
			if(example!=null){
			
				if (example.getIdEquipeFila() != null) {
					stmt.setInt(++index, example.getIdEquipeFila());
				}
				if (example.getQuantidadeCasoAtendido() != null) {
					stmt.setInt(++index, example.getQuantidadeCasoAtendido());
				}
				if (example.getQuantidadeCasoFila() != null) {
					stmt.setInt(++index, example.getQuantidadeCasoFila());
				}
				if (example.getEquipe() != null && example.getEquipe().getIdEquipe() != null) {
					stmt.setInt(++index, example.getEquipe().getIdEquipe());
				}
				if (example.getConfiguracaoFila() != null && example.getConfiguracaoFila().getIdConfiguracaoFila() != null) {
					stmt.setInt(++index, example.getConfiguracaoFila().getIdConfiguracaoFila());
				}
			}
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					EquipeFila equipeFila = EquipeFila.getEquipeFilaByResultSet(resultSet);
					equipeFilas.add(equipeFila);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return equipeFilas;
	}
    
    @Override
    public EquipeFila findByPk(Object id) throws DataException {
    	EquipeFila result = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(EquipeFila.getSqlCamposEquipeFila())
				.append(", ")
				.append(Equipe.getSqlEquipe())
				.append(", ")
				.append(ConfiguracaoFila.getSqlCamposConfiguracaoFila())
				.append(FROM)
				.append(EquipeFila.getSqlFromEquipeFila())
				.append(INNER_JOIN).append(Equipe.getSqlFromEquipe())
				.append(" ON EquipeFila.ID_EQUIPE = Equipe.ID_EQUIPE ")
				.append(INNER_JOIN).append(ConfiguracaoFila.getSqlFromConfiguracaoFila())
				.append(" ON EquipeFila.ID_CONFIGURACAO_FILA = ConfiguracaoFila.ID_CONFIGURACAO_FILA ")
				.append(" WHERE EquipeFila.ID_EQUIPE_FILA = ? ");
			
			stmt = getPreparedStatement(select.toString());
			
			EquipeFila equipeFila = (EquipeFila) id;
			
			stmt.setInt(1, equipeFila.getIdEquipeFila());
			
			stmt.execute();
			
			resultSet = stmt.getResultSet();
			if (resultSet != null && resultSet.next()) {
				result = EquipeFila.getEquipeFilaByResultSet(resultSet);
				result.setEquipe(Equipe.getEquipeByResultSet(resultSet));
				result.setConfiguracaoFila(ConfiguracaoFila.getConfiguracaoFilaByResultSet(resultSet));
			}
		} catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		return result;
	}
    
}
