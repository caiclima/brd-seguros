package br.com.callink.cad.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.apache.commons.lang.StringUtils;
import br.com.callink.cad.dao.IEventoLigacaoDAO;
import br.com.callink.cad.pojo.EventoLigacao;
import br.com.callink.cad.pojo.Util.DateUtil;
import br.com.callink.cad.sau.exception.DataException;

public class EventoLigacaoDAO extends GenericCadDAO<EventoLigacao> implements IEventoLigacaoDAO {

	private static final long serialVersionUID = -467633090256331877L;

	public EventoLigacaoDAO() {
		super(EventoLigacao.class);
	}

    @Override
    public List<EventoLigacao> findByExample(EventoLigacao example) throws DataException {
        
    	if (example == null) {
            return null;
        }

    	ResultSet result = null;
        PreparedStatement stmt = null;
    	List<EventoLigacao> list = new ArrayList<EventoLigacao>();
    	int index =0;
    	
    	try {
        	StringBuilder select = new StringBuilder(SELECT)
        	.append(" EventoLigacao.ID_EVENTO_LIGACAO AS 'EventoLigacao.ID_EVENTO_LIGACAO',")
        	.append(" EventoLigacao.NOME AS 'EventoLigacao.NOME',")
            .append(" EventoLigacao.DATA_CRIACAO AS 'EventoLigacao.DATA_CRIACAO',")
            .append(" EventoLigacao.FLAG_ATIVO AS 'EventoLigacao.FLAG_ATIVO',")
            .append(" EventoLigacao.FLAG_SUCESSO AS 'EventoLigacao.FLAG_SUCESSO',")
            .append(" EventoLigacaoJoin.ID_EVENTO_LIGACAO AS 'EventoLigacaoJoin.ID_EVENTO_LIGACAO',")
        	.append(" EventoLigacaoJoin.NOME AS 'EventoLigacaoJoin.NOME',")
            .append(" EventoLigacaoJoin.DATA_CRIACAO AS 'EventoLigacaoJoin.DATA_CRIACAO',")
            .append(" EventoLigacaoJoin.FLAG_ATIVO AS 'EventoLigacaoJoin.FLAG_ATIVO',")
            .append(" EventoLigacaoJoin.FLAG_SUCESSO AS 'EventoLigacaoJoin.FLAG_SUCESSO'")
        	.append(FROM).append(EventoLigacao.getSqlFromEvento())
        	.append(LEFT_JOIN).append( " TB_EVENTO_LIGACAO AS EventoLigacaoJoin with(nolock) ")
        	.append(" ON (EventoLigacao.ID_EVENTO_LIGACAO_PAI = EventoLigacaoJoin.ID_EVENTO_LIGACAO) ")
        	.append(WHERE_1_1);
        	
    		if(example.getIdEventoLigacao()!= null){
    			select.append(" AND EventoLigacao.ID_EVENTO_LIGACAO = ? ");
    		}
    		if(StringUtils.isNotBlank(example.getNome())){
    			select.append(" AND EventoLigacao.NOME like ? ");
    		}
    		if(example.getDataCriacao()!= null){
    			select.append(" AND EventoLigacao.DATA_CRIACAO BETWEEN ? AND ? ");
    		}
    		if(example.getFlagSucesso()!= null){
    			select.append(" AND EventoLigacao.FLAG_SUCESSO = ? ");
    		}
    		if(example.getFlagAtivo()!= null){
    			select.append(" AND EventoLigacao.FLAG_ATIVO = ? ");
    		}
    		if(example.getEventoPai() != null && example.getEventoPai().getIdEventoLigacao() != null){
    			select.append(" AND EventoLigacao.ID_EVENTO_LIGACAO_PAI = ? ");
    		}
        	
        	stmt = getPreparedStatement(select.toString());
        	
        	if(example.getIdEventoLigacao()!= null){
    			stmt.setInt(++index, example.getIdEventoLigacao());
    		}
    		if(StringUtils.isNotBlank(example.getNome())){
    			stmt.setString(++index, new StringBuilder(example.getNome()).append("%").toString());
    		}
    		if(example.getDataCriacao()!= null){
    			Date dataInicio = DateUtil.dataInicioDia(example.getDataCriacao());
				Date dataFinal =  DateUtil.dataFimDia(example.getDataCriacao());	
    			stmt.setDate(++index, new java.sql.Date(dataInicio.getTime()));
    			stmt.setDate(++index, new java.sql.Date(dataFinal.getTime()));
    		}
    		if(example.getFlagSucesso()!= null){
    			stmt.setBoolean(++index, example.getFlagSucesso());
    		}
    		if(example.getFlagAtivo()!= null){
    			stmt.setBoolean(++index, example.getFlagAtivo());
    		}
    		if(example.getEventoPai() != null && example.getEventoPai().getIdEventoLigacao() != null){
    			stmt.setInt(++index, example.getEventoPai().getIdEventoLigacao());
    		}
        	
        	stmt.execute();
            result = stmt.getResultSet();
            
            if(result!= null){		
				while(result.next()){
					EventoLigacao evento = new EventoLigacao();
	    			evento.setIdEventoLigacao(((Long) result.getObject(1)).intValue());
	    			evento.setNome((String) result.getObject(2));
	    			evento.setDataCriacao((Date) result.getObject(3));
	    			evento.setFlagAtivo((Boolean) result.getObject(4));
	    			evento.setFlagSucesso((Boolean) result.getObject(5));

	    			if(result.getObject(6)!=null){
	    				EventoLigacao eventoPai = new EventoLigacao();
	    				eventoPai.setIdEventoLigacao(((Long) result.getObject(6)).intValue());
	    				eventoPai.setNome((String) result.getObject(7));
	    				eventoPai.setDataCriacao((Date) result.getObject(8));
	    				eventoPai.setFlagAtivo((Boolean) result.getObject(9));
	    				eventoPai.setFlagSucesso((Boolean) result.getObject(10));
	    				evento.setEventoPai(eventoPai);
	    			}
	    			
	    			list.add(evento);
				}
			}

        	return list;
    	} catch (Exception ex) {
            throw new DataException(ex);
        } finally {
        	super.close(result);
        }
    }

    
    @Override
    public EventoLigacao findByPk(Object id) throws DataException {
       
    	ResultSet result = null;
        PreparedStatement stmt = null;
    	
    	try {
        	
        	StringBuilder select = new StringBuilder(SELECT)
        	.append(EventoLigacao.getSqlEvento())
        	.append(FROM).append(EventoLigacao.getSqlFromEvento())
        	.append(WHERE).append(" EventoLigacao.ID_EVENTO_LIGACAO = ? ");

        	stmt = getPreparedStatement(select.toString());
        	EventoLigacao evento = (EventoLigacao) id;
        	stmt.setInt(1,evento.getIdEventoLigacao());
        	stmt.execute();
            result = stmt.getResultSet();
            
            if(result!= null){		
				while (result.next()) {
					evento = EventoLigacao.getEventoByResultSet(result);
				}
			}
            
        	return evento;
    	} catch (Exception ex) {
            throw new DataException(ex);
        } finally {
        	super.close(result);
        }
    }
    
    public List<EventoLigacao> findAtivos() throws DataException {
		return this.findAtivos(null);
	}
	
    @Override
    public List<EventoLigacao> findAtivos(String order) throws DataException {
       
    	ResultSet result = null;
        PreparedStatement stmt = null;
    	List<EventoLigacao> list = new ArrayList<EventoLigacao>();
    	
    	try {
        	
        	StringBuilder select = new StringBuilder(SELECT)
        	.append(EventoLigacao.getSqlEvento())
        	.append(FROM).append(EventoLigacao.getSqlFromEvento())
        	.append(WHERE)
        	.append(" EventoLigacao.FLAG_ATIVO = 1 ");
        	
        	if(StringUtils.isNotBlank(order)){
        		select.append(String.format(" ORDER BY %s ", order));
        	}
        	
        	stmt = getPreparedStatement(select.toString());
        	stmt.execute();
            result = stmt.getResultSet();
            
            if(result!= null){		
				while (result.next()) {
					EventoLigacao evento = EventoLigacao.getEventoByResultSet(result);
					list.add(evento);
				}
			}
            
        	return list;
    	} catch (Exception ex) {
            throw new DataException(ex);
        } finally {
        	super.close(result);
        }
    }

	@Override
	public List<EventoLigacao> findAtivosExceto(EventoLigacao pojo) throws DataException {

    	ResultSet result = null;
        PreparedStatement stmt = null;
    	List<EventoLigacao> list = new ArrayList<EventoLigacao>();
    	
    	try {
        	
        	StringBuilder select = new StringBuilder(SELECT)
        	.append(EventoLigacao.getSqlEvento())
        	.append(FROM).append(EventoLigacao.getSqlFromEvento())
        	.append(WHERE)
        	.append(" EventoLigacao.FLAG_ATIVO = 1 ");
        	
        	if(pojo != null && pojo.getIdEventoLigacao() != null){
        		select.append(" AND EventoLigacao.ID_EVENTO_LIGACAO <> ? ");
        	}
        	
        	stmt = getPreparedStatement(select.toString());
        	
        	if(pojo != null && pojo.getIdEventoLigacao() != null){
        		stmt.setInt(1,pojo.getIdEventoLigacao());
        	}
        	
        	stmt.execute();
            result = stmt.getResultSet();
            
            if(result!= null){		
				while (result.next()) {
					EventoLigacao evento = EventoLigacao.getEventoByResultSet(result);
					list.add(evento);
				}
			}
            
        	return list;
    	} catch (Exception ex) {
            throw new DataException(ex);
        } finally {
        	super.close(result);
        }
	}
	

	@Override
    public List<EventoLigacao> findByEvento(EventoLigacao eventoLigacao) throws DataException {
		ResultSet result = null;
        PreparedStatement stmt = null;
    	List<EventoLigacao> list = new ArrayList<EventoLigacao>();
    	
    	try {
        	
        	StringBuilder select = new StringBuilder(SELECT)
        	.append(EventoLigacao.getSqlEvento())
        	.append(FROM).append(EventoLigacao.getSqlFromEvento());
        	
        	if (eventoLigacao != null && eventoLigacao.getIdEventoLigacao() != null) {
        		select.append(" where ID_EVENTO_LIGACAO_PAI = ").append(eventoLigacao.getIdEventoLigacao()).append(" AND FLAG_ATIVO = 1 ");
        		
        	} else {
        		
        		select.append(" where ID_EVENTO_LIGACAO_PAI is null AND FLAG_ATIVO = 1 ");
        	}
        	
        	select.append(" order by NOME ");
        	
        	stmt = getPreparedStatement(select.toString());
        	stmt.execute();
            result = stmt.getResultSet();
            
            if(result!= null){		
				while (result.next()) {
					EventoLigacao evento = EventoLigacao.getEventoByResultSet(result);
					list.add(evento);
				}
			}
            
        	return list;
    	} catch (Exception ex) {
            throw new DataException(ex);
        } finally {
        	super.close(result);
        }
		
	}
	
    
}
