/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import br.com.callink.cad.dao.IFeriadoDAO;
import br.com.callink.cad.pojo.Feriado;
import br.com.callink.cad.pojo.Util.DateUtil;
import br.com.callink.cad.sau.exception.DataException;

/**
*
* @author Ednaldo Caic [ednaldo@swb.com.br]
* @since 26/12/2011
*/
public class FeriadoDAO extends GenericCadDAO<Feriado> implements IFeriadoDAO{

	private static final long serialVersionUID = 1850483393676875093L;

	public FeriadoDAO() {
		super(Feriado.class);
	}
	
	@Override
	public Feriado findByPk(Object id) throws DataException {
		Feriado result = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Feriado.getSqlCamposFeriado())
				.append(FROM)
				.append(Feriado.getSqlFromFeriado())
				.append(" WHERE Feriado.ID_FERIADO = ? ");
			
			stmt = getPreparedStatement(select.toString());
			
			Feriado feriado = (Feriado) id;
			
			stmt.setInt(1, feriado.getIdFeriado());
			
			stmt.execute();
			
			resultSet = stmt.getResultSet();
			if (resultSet != null && resultSet.next()) {
				result = Feriado.getFeriadoByResultSet(resultSet);
			}
		} catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		return result;
	}
	
	public List<Feriado> findAll() throws DataException{
		
		List<Feriado> list = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Feriado.getSqlCamposFeriado())
				.append(FROM)
				.append(Feriado.getSqlFromFeriado());
			
			stmt = getPreparedStatement(select.toString());
			stmt.execute();
			resultSet = stmt.getResultSet();
			list = new ArrayList<Feriado>();
			if (resultSet != null) {
				while (resultSet.next()) {
					Feriado feriado = Feriado.getFeriadoByResultSet(resultSet);
					list.add(feriado);
				}
			}
		} catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		return list;
	}
	
	@Override
	public List<Feriado> findByExample(Feriado feriado) throws DataException{
		
		List<Feriado> list = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		int index =0;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Feriado.getSqlCamposFeriado())
				.append(FROM)
				.append(Feriado.getSqlFromFeriado())
				.append(WHERE_1_1);
			
			if(feriado!= null){
				
				if(feriado.getIdFeriado()!= null){
					select.append(" AND Feriado.ID_FERIADO = ? ");
				}
				if(feriado.getDataFeriado()!= null){
					select.append(" AND Feriado.DATA_FERIADO BETWEEN ? and ? ");				
				}
				if(feriado.getLoginUsuario()!= null){
					select.append(" AND Feriado.LOGIN_USUARIO = ? ");
				}
				if(feriado.getNomeFeriado()!= null && !feriado.getNomeFeriado().isEmpty()){
					select.append(" AND Feriado.NOME_FERIADO like ? ");
				}
				if (feriado.getFlagNacional() != null) {
					select.append(" AND Feriado.FLAG_NACIONAL = ? ");
				}
			}
			
			stmt = getPreparedStatement(select.toString());
			
			if(feriado!= null){
				
				if(feriado.getIdFeriado()!= null){
					stmt.setInt(++index, feriado.getIdFeriado());
				}
				if(feriado.getDataFeriado()!= null){
					Date dataInicio = DateUtil.dataInicioDia(feriado.getDataFeriado());
					Date dataFim = DateUtil.dataFimDia(feriado.getDataFeriado());
					stmt.setDate(++index, new java.sql.Date(dataInicio.getTime()));
					stmt.setDate(++index, new java.sql.Date(dataFim.getTime()));
				}
				if(feriado.getLoginUsuario()!= null){
					stmt.setString(++index, feriado.getLoginUsuario());
				}
				if(feriado.getNomeFeriado()!= null && !feriado.getNomeFeriado().isEmpty()){
					stmt.setString(++index, new StringBuilder(feriado.getNomeFeriado()).append("%").toString());
				}
				if (feriado.getFlagNacional() != null) {
					stmt.setBoolean(++index, feriado.getFlagNacional());
				}
			}
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			list = new ArrayList<Feriado>();
			if (resultSet != null) {
				while (resultSet.next()) {
					Feriado fe = Feriado.getFeriadoByResultSet(resultSet);
					list.add(fe);
				}
			}
		} catch (SQLException e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		return list;
	}
	
	@Override
	public Boolean isFeriado(Date date) throws DataException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
		
		StringBuilder select = new StringBuilder();
		select.append("SELECT TOP 1 1 ")
				.append(" FROM tb_feriado(nolock) ")
				.append(" WHERE (day(data_feriado) = day(?) and month(data_feriado) = month(?) and flag_fixo = 1) ")
				.append(" 		or data_feriado = ? ");
		
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		
		String strDate = sdf.format(date);
		
		stmt = getPreparedStatement(select.toString());
		try {
			stmt.setString(1, strDate);
			stmt.setString(2, strDate);
			stmt.setString(3, strDate);
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			return resultSet != null && resultSet.next();
			
		} catch (SQLException e) {
			throw new DataException("Erro ao validar feriado. Motivo: " + e.getMessage());
		}finally{
			super.close(resultSet);
		}
		
	}
	
}
