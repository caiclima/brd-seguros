package br.com.callink.cad.dao.impl;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.persistence.metamodel.Attribute;
import javax.persistence.metamodel.EntityType;
import javax.persistence.metamodel.Metamodel;
import javax.sql.DataSource;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.dao.IGenericCadDAO;
import br.com.callink.cad.pojo.entity.IEntity;
import br.com.callink.cad.sau.exception.DataException;

public class GenericCadDAO<T extends IEntity<Integer>> implements IGenericCadDAO<T> {
	
	private static final long serialVersionUID = 1137316960323139470L;
	
	public static final String WHERE_1_1 = " WHERE 1=1 ";
	public static final String WHERE = " WHERE ";
	public static final String FROM = " FROM ";
	public static final String SELECT = " SELECT ";
	public static final String INNER_JOIN = " INNER JOIN ";
	public static final String LEFT_JOIN = " LEFT JOIN ";
	public static final String ORDER_BY = " ORDER BY ";
	
	private Class<T> entityClass;

	@PersistenceContext(unitName = "CAD_PU")
	private EntityManager entityManager;
	
	@Resource(lookup = "java:jboss/datasources/CAD_DS")
	private DataSource dataSource; 
	
	private Connection connection;
	
	private PreparedStatement preparedStatement;
	
	public GenericCadDAO(Class<T> entityClass) {
		this.entityClass = entityClass;
	}
	
	public Connection getConnection() throws DataException{
		try {
			if(connection==null || connection.isClosed()){
				connection = getDataSource().getConnection();
			}
			return connection;
		} catch (SQLException e) {
			throw new DataException(e);
		}
	}
	
	
	public void close(ResultSet resultSet) throws DataException {

		try {

			if (resultSet != null) {
				resultSet.close();
			}
			if (preparedStatement != null) {
				preparedStatement.getConnection().close();
				preparedStatement.close();
			}
			closeConnection();

		} catch (SQLException e) {
			throw new DataException(e);
		}

	}
	
	public void closeConnection() throws DataException {
		try {
			if (connection != null && !connection.isClosed()) {
				connection.close();
			}

		} catch (SQLException e) {
			throw new DataException(e);
		}
	}
	
	public PreparedStatement getPreparedStatement(String sql)throws DataException {
		try {
			preparedStatement = getConnection().prepareStatement(sql);
			return preparedStatement;
		} catch (SQLException e) {
			throw new DataException(e);
		}
	}

	public Class<T> getEntityClass() {
		return entityClass;
	}

	public EntityManager getEntityManager(){
		return entityManager;
	}
	
	public DataSource getDataSource(){
		return dataSource;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<T> findAll() throws DataException {
		CriteriaQuery cq = getEntityManager().getCriteriaBuilder().createQuery();
		cq.select(cq.from(entityClass));

		return getEntityManager().createQuery(cq).getResultList();
	}

	public void save(T entity) throws DataException {
		getEntityManager().persist(entity);
	}

	public void update(T entity) throws DataException {
		getEntityManager().merge(entity);
	}

	public void saveOrUpdate(T object) throws DataException {
		try {
			if (possuiIdComValor(object)) {
				update(object);
			} else {
				save(object);
			}
		} catch (Exception e) {
			throw new DataException(e);
		}

	}

	public boolean possuiIdComValor(T object) throws DataException {
		if (object != null) {
			List<Field> fields = getAllFieldsByClass(entityClass);
			for (Field field : fields) {
				if (field.isAnnotationPresent(javax.persistence.Id.class) && getValue(object, field) != null) {
					return true;
				}
			}
		}
		return false;
	}
	
	public void delete(T entity) throws DataException {
		getEntityManager().remove(getEntityManager().merge(entity));
	}

	public T findByPk(Object id) throws DataException {
		return getEntityManager().find(entityClass, id);
	}
	
	@SuppressWarnings("unchecked")
	public List<T> findByNamedQuery(final String name, Object... params) {
		Query query = getEntityManager().createNamedQuery(name);

		for (int i = 0; i < params.length; i++) {
			query.setParameter(i + 1, params[i]);
		}

		return (List<T>) query.getResultList();
	}

	@SuppressWarnings("unchecked")
	public List<T> findByNamedQueryAndNamedParams(final String name, final Map<String, ? extends Object> params) {

		Query query = getEntityManager().createNamedQuery(name);

		for (final Map.Entry<String, ? extends Object> param : params.entrySet()) {
			query.setParameter(param.getKey(), param.getValue());
		}

		return (List<T>) query.getResultList();
	}
	
	public List<T> findByExample(T example) throws DataException {
		try {
			return findByExample(example, null);
		} catch (Exception ex) {
			throw new DataException(ex);
		}
	}

	public List<T> findByExample(T example, String order) throws DataException {
		try {
			Class<T> clazz = entityClass;
			CriteriaBuilder criteriaBuilder = getEntityManager().getCriteriaBuilder();
			CriteriaQuery<T> criteriaQuery = criteriaBuilder.createQuery(clazz);
			Root<T> root = criteriaQuery.from(clazz);
			Predicate predicate = criteriaBuilder.conjunction();
			Metamodel metaModel = getEntityManager().getMetamodel();
			EntityType<T> et = metaModel.entity(clazz);
			Set<Attribute<? super T, ?>> attrs = et.getAttributes();
			for (Attribute<? super T, ?> atributo : attrs) {
				String name = atributo.getName();
				String javaName = atributo.getJavaMember().getName();
				String getter = "get" + javaName.substring(0, 1).toUpperCase() + javaName.substring(1);
				Method metodo = clazz.getMethod(getter, (Class<?>[]) null);
				Object valorCampo = metodo.invoke(example, (Object[]) null);

				if (valorCampo != null && !metodo.isAnnotationPresent(Transient.class)) {
					if (valorCampo.getClass().equals(String.class)) {
						if (!valorCampo.toString().trim().equals("")) {
							predicate = criteriaBuilder.and(predicate,
									criteriaBuilder.like(root.<String> get(name), (valorCampo + "%")));
						}
					} else {
						predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(root.get(name), valorCampo));
					}
				}
			}
			criteriaQuery.select(root).where(predicate);
			
			if (order != null) {
				criteriaQuery.orderBy(criteriaBuilder.asc(root.get(order)));
			}
			
			TypedQuery<T> query = getEntityManager().createQuery(criteriaQuery);
			return query.getResultList();

		} catch (Exception e) {
			throw new DataException(e);
		}
	}
	
	@Override
	public List<T> findAtivos() throws DataException {
		return this.findAtivos(null);
	}
	
	@Override
	public List<T> findAtivos(String order) throws DataException {
		
		StringBuilder sql = new StringBuilder("select 1 as coluna from with(nolock) syscolumns where id = object_id(?) and name = ?");

        List<Object> param = new ArrayList<Object>();
        String nomeTabela = "???";
        
        Annotation tableAnnotation = entityClass.getAnnotation(Table.class);
        if (tableAnnotation != null) {
                Table tab = (Table) tableAnnotation;
                nomeTabela = tab.name(); 
                param.add(nomeTabela);
                param.add("FLAG_ATIVO");
        }
		
        Query query = getEntityManager().createNativeQuery(sql.toString(), entityClass);
        
        if(query.getResultList()== null || !query.getResultList().isEmpty()){
        	throw new DataException("Coluna flagAtivo nao existe na tabela " + nomeTabela);
        }
		
        CriteriaBuilder criteriaBuilder = getEntityManager().getCriteriaBuilder();
        CriteriaQuery<T> criteriaQuery = criteriaBuilder.createQuery(entityClass);
        Root<T> from = criteriaQuery.from(entityClass);
        
        Predicate predicate = criteriaBuilder.equal(from.get("flagAtivo"), 1);
        criteriaQuery.where(predicate);
        
        CriteriaQuery<T> select = criteriaQuery.select(from);
        
        if(StringUtils.isNotBlank(order)){
        	select.orderBy(criteriaBuilder.asc(from.get(order)));
        }
        
        TypedQuery<T> typedQuery = getEntityManager().createQuery(select);
        
        return typedQuery.getResultList();
        
	}
	
	public Date getDataBanco() throws DataException {
		StringBuilder query = new StringBuilder("select getDate()");
		try {
			
			Query q = getEntityManager().createNativeQuery(query.toString());
			return (Date) q.getSingleResult();
		} catch (Exception ex) {
			throw new DataException(ex);
		}
	}
	
	
	@SuppressWarnings("rawtypes")
	private static List<Field> getAllFieldsByClass(Class clazz) {

		List<Field> fields = new ArrayList<Field>();

		if (clazz != null) {
			fields.addAll(Arrays.asList(clazz.getDeclaredFields()));

			if (clazz.getSuperclass() != null) {
				fields.addAll(getAllFieldsByClass(clazz.getSuperclass()));
			}
		}

		return fields;
	}
	
	private static Object getValue(Object object, Field field) throws DataException {

		Object value = null;
		field.setAccessible(Boolean.TRUE);

		if (object != null) {
			try {
				value = field.get(object);
			} catch (IllegalArgumentException e) {
				throw new DataException(e);
			} catch (IllegalAccessException e) {
				throw new DataException(e);
			}
		}
		field.setAccessible(Boolean.FALSE);
		return value;
	}
	
}
