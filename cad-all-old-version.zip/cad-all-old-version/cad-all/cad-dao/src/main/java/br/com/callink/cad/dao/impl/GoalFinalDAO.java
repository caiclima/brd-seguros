package br.com.callink.cad.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;

import br.com.callink.cad.dao.IGoalFinalDAO;
import br.com.callink.cad.pojo.GoalFinal;
import br.com.callink.cad.pojo.Util.DateUtil;
import br.com.callink.cad.sau.exception.DataException;

public class GoalFinalDAO extends GenericCadDAO<GoalFinal> implements IGoalFinalDAO {

	private static final long serialVersionUID = 4147400971214883416L;

	public GoalFinalDAO() {
		super(GoalFinal.class);
	}
	
	@Override
	public List<GoalFinal> buscaGoalsAtivos() throws DataException {
		List<GoalFinal> goalFinalList = new ArrayList<GoalFinal>();
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder sql = new StringBuilder()
	        	.append(SELECT)
	        	.append(GoalFinal.getSqlCamposGoalFinal())
	        	.append(FROM)
	            .append(GoalFinal.getSqlFromGoalFinal())
	            .append(WHERE)
	            .append(" GoalFinal.DATA_FINAL is null ")
	            .append(" ORDER BY GoalFinal.GOAL_INICIAL ");
			
	        stmt = getPreparedStatement(sql.toString());
	        
			stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null) {
				while (resultSet.next()) {
					GoalFinal goalFinal = GoalFinal.getGoalFinalByResultSet(resultSet);
					goalFinalList.add(goalFinal);
				}
			}
		} catch (Exception e) {
			throw new DataException("Erro ao buscar goals ativos", e);
		} finally {
			super.close(resultSet);
		}
        return goalFinalList;
	}

	@Override
	public List<GoalFinal> buscaHistoricoGoals() throws DataException {
		List<GoalFinal> goalFinalList = new ArrayList<GoalFinal>();
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder sql = new StringBuilder()
	        	.append(SELECT)
	        	.append(GoalFinal.getSqlCamposGoalFinal())
	        	.append(FROM)
	            .append(GoalFinal.getSqlFromGoalFinal())
	            .append(WHERE)
	            .append(" GoalFinal.DATA_FINAL is not null ")
	            .append(" ORDER BY GoalFinal.GOAL_INICIAL ");
			
	        stmt = getPreparedStatement(sql.toString());
	        
			stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null) {
				while (resultSet.next()) {
					GoalFinal goalFinal = GoalFinal.getGoalFinalByResultSet(resultSet);
					goalFinalList.add(goalFinal);
				}
			}
		} catch (Exception e) {
			throw new DataException("Erro ao buscar historico goals", e);
		} finally {
			super.close(resultSet);
		}
        return goalFinalList;
	}
	
	@Override
	public void updateDataFinalPorId(Integer id) throws DataException {
		try {
            Query query = getEntityManager().createNativeQuery(" UPDATE tb_goal_final set data_final = :dataFinal WHERE id_goal_final = :idGoalFinal ");
            query.setParameter("dataFinal", DateUtil.convertDateStringWithHour(new Date(System.currentTimeMillis())));
            query.setParameter("idGoalFinal", id);
            query.executeUpdate();
		} catch (Exception ex) {
			throw new DataException("Erro ao atualizar data final pela ID do GoalFinal", ex);
		}
	}
	
	@Override
	public GoalFinal findByPk(Object id) throws DataException {
		GoalFinal result = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(GoalFinal.getSqlCamposGoalFinal())
				.append(FROM)
				.append(GoalFinal.getSqlFromGoalFinal())
				.append(" WHERE GoalFinal.ID_GOAL_FINAL = ? ");
			
			stmt = getPreparedStatement(select.toString());
			
			GoalFinal goalFinal = (GoalFinal) id;
			
			stmt.setInt(1, goalFinal.getIdGoalFinal());
			
			stmt.execute();
			
			resultSet = stmt.getResultSet();
			if (resultSet != null && resultSet.next()) {
				result = GoalFinal.getGoalFinalByResultSet(resultSet);
			}
		} catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		return result;
	}
	
}
