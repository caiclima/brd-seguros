/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import br.com.callink.cad.dao.IGrupoEmailDAO;
import br.com.callink.cad.pojo.GrupoEmail;
import br.com.callink.cad.pojo.Util.DateUtil;
import br.com.callink.cad.sau.exception.DataException;

/**
 *
 * @author Luiz Gustavo (luizgf@swb.com.br)
 */
public class GrupoEmailDAO extends GenericCadDAO<GrupoEmail> implements IGrupoEmailDAO {

	private static final long serialVersionUID = 8661179436475996267L;

	public GrupoEmailDAO() {
		super(GrupoEmail.class);
	}
	
	@Override
	public GrupoEmail findByPk(Object id) throws DataException {
		GrupoEmail result = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(GrupoEmail.getSqlCamposGrupoEmail())
				.append(FROM)
				.append(GrupoEmail.getSqlFromGrupoEmail())
				.append(" WHERE GrupoEmail.ID_GRUPO_EMAIL = ? ");
			
			stmt = getPreparedStatement(select.toString());
			GrupoEmail grupoEmail = (GrupoEmail) id;
			stmt.setInt(1, grupoEmail.getIdGrupoEmail());
			stmt.execute();
			
			resultSet = stmt.getResultSet();
			if (resultSet != null && resultSet.next()) {
				result = GrupoEmail.getGrupoEmailByResultSet(resultSet);
			}
		} catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		return result;
	}
	
	@Override
	public List<GrupoEmail> findByExample(GrupoEmail example) throws DataException {
		return findByExample(example, null);
	}
	
	@Override
	public List<GrupoEmail> findByExample(GrupoEmail example, String order) throws DataException {
		List<GrupoEmail> gruposEmail = new ArrayList<GrupoEmail>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		int index =0;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(GrupoEmail.getSqlCamposGrupoEmail())
				.append(FROM)
				.append(GrupoEmail.getSqlFromGrupoEmail())
				.append(WHERE_1_1);

			if(example!=null){
			
				if (example.getIdGrupoEmail() != null) {
					select.append(" AND GrupoEmail.ID_GRUPO_EMAIL = ? ");
				}
				if (example.getDescricao() != null && !example.getDescricao().isEmpty()) {
					select.append(" AND GrupoEmail.DESCRICAO like ? ");
				}
				if (example.getFlagAtivo() != null) {
					select.append(" AND GrupoEmail.FLAG_ATIVO = ? ");
				}
				if (example.getDataCriacao() != null) {
					select.append(" AND GrupoEmail.DATA_CRIACAO BETWEEN ? AND ? ");
				}
			}
			
			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			if(example!=null){
				
				if (example.getIdGrupoEmail() != null) {
					stmt.setInt(++index, example.getIdGrupoEmail());
				}
				if (example.getDescricao() != null && !example.getDescricao().isEmpty()) {
					stmt.setString(++index, new StringBuilder(example.getDescricao()).append("%").toString());
				}
				if (example.getFlagAtivo() != null) {
					stmt.setBoolean(++index, example.getFlagAtivo());
				}
				if (example.getDataCriacao() != null) {
					Date dataInicio = DateUtil.dataInicioDia(example.getDataCriacao());
					Date dataFim = DateUtil.dataFimDia(example.getDataCriacao());
					stmt.setDate(++index, new java.sql.Date(dataInicio.getTime()));
					stmt.setDate(++index, new java.sql.Date(dataFim.getTime()));
				}
			}
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					GrupoEmail grupoEmail = GrupoEmail.getGrupoEmailByResultSet(resultSet);
					gruposEmail.add(grupoEmail);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return gruposEmail;
	}
	
	@Override
	public List<GrupoEmail> findAll() throws DataException {
		return findAll(null);
	}
	
	@Override
	public List<GrupoEmail> findAll(String order) throws DataException {
		List<GrupoEmail> gruposEmail = new ArrayList<GrupoEmail>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(GrupoEmail.getSqlCamposGrupoEmail())
				.append(FROM)
				.append(GrupoEmail.getSqlFromGrupoEmail());

			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					GrupoEmail grupoEmail = GrupoEmail.getGrupoEmailByResultSet(resultSet);
					gruposEmail.add(grupoEmail);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return gruposEmail;
	}
	
	@Override
	public List<GrupoEmail> findAtivos(String order) throws DataException {
		List<GrupoEmail> gruposEmail = new ArrayList<GrupoEmail>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(GrupoEmail.getSqlCamposGrupoEmail())
				.append(FROM)
				.append(GrupoEmail.getSqlFromGrupoEmail())
				.append(WHERE)
				.append(" GrupoEmail.FLAG_ATIVO = 1 ");

			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					GrupoEmail grupoEmail = GrupoEmail.getGrupoEmailByResultSet(resultSet);
					gruposEmail.add(grupoEmail);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return gruposEmail;
	}
    
}
