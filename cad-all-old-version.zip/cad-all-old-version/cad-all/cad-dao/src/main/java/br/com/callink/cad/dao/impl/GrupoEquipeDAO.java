/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.com.callink.cad.dao.IGrupoEquipeDAO;
import br.com.callink.cad.pojo.GrupoEquipe;
import br.com.callink.cad.sau.exception.DataException;

/**
 *
 * @author Rogerio
 */
public class GrupoEquipeDAO extends GenericCadDAO<GrupoEquipe> implements IGrupoEquipeDAO {

	private static final long serialVersionUID = 1353105841354863405L;

	public GrupoEquipeDAO() {
		super(GrupoEquipe.class);
	}
	
	@Override
	public GrupoEquipe findByPk(Object id)throws DataException{
		
		ResultSet resultSet = null;
		PreparedStatement stmt = null;
		
		try {
			
			StringBuilder string = new StringBuilder(SELECT)
			  .append(GrupoEquipe.getSqlCamposGrupoEquipe())
			  .append(FROM).append(GrupoEquipe.getSqlFromGrupoEquipe())
			  .append(WHERE).append("GrupoEquipe.id_grupo_equipe = ? ");
			
			GrupoEquipe  grupoEquipe = (GrupoEquipe) id;
			
			stmt = getPreparedStatement(string.toString());
			stmt.setInt(1,grupoEquipe.getIdGrupoEquipe());
			stmt.execute();
			
			resultSet = stmt.getResultSet();

			while (resultSet.next()) {
				grupoEquipe = GrupoEquipe.getGrupoEquipeByResultSet(resultSet);
			}
			
			return grupoEquipe;
		} catch (Exception e) {
			throw new DataException("Erro ao buscar os Tipos de Ação pelo Status.", e);
		} finally {
			super.close(resultSet);
		}
	}
	
	@Override
	public List<GrupoEquipe> findAll() throws DataException{
		
		ResultSet resultSet = null;
		PreparedStatement stmt = null;
		List<GrupoEquipe> grupoEquipeList = new ArrayList<GrupoEquipe>();
		
		try {
			
			StringBuilder string = new StringBuilder(SELECT)
			  .append(GrupoEquipe.getSqlCamposGrupoEquipe())
			  .append(FROM).append(GrupoEquipe.getSqlFromGrupoEquipe());
			
			stmt = getPreparedStatement(string.toString());
			stmt.execute();
			resultSet = stmt.getResultSet();

			while (resultSet.next()) {
				grupoEquipeList.add(GrupoEquipe.getGrupoEquipeByResultSet(resultSet));
			}
			return grupoEquipeList;
		} catch (Exception e) {
			throw new DataException("Erro ao buscar todos grupoEquipe", e);
		} finally {
			super.close(resultSet);
		}
		
	}
}
