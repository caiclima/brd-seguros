/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import br.com.callink.cad.dao.IGrupoEquipeFilaDAO;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.pojo.GrupoEquipe;
import br.com.callink.cad.pojo.GrupoEquipeFila;
import br.com.callink.cad.sau.exception.DataException;

/**
 *
 * @author Rogerio
 */
public class GrupoEquipeFilaDAO extends GenericCadDAO<GrupoEquipeFila> implements IGrupoEquipeFilaDAO {
    
	private static final long serialVersionUID = -9553335305627201L;

	public GrupoEquipeFilaDAO() {
		super(GrupoEquipeFila.class);
	}

	@Override
    public List<GrupoEquipeFila> grupoEquipeFilaList(GrupoEquipe grupoEquipe) throws DataException{
        
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		List<GrupoEquipeFila> equipeFilas = null;
		
		try {
			
			StringBuilder sql = new StringBuilder(SELECT)
			.append(GrupoEquipeFila.getSqlCamposGrupoEquipeFila())
			.append(",").append(ConfiguracaoFila.getSqlCamposConfiguracaoFila())
			.append(FROM).append(GrupoEquipeFila.getSqlFromGrupoEquipeFila())
			.append(INNER_JOIN).append(ConfiguracaoFila.getSqlFromConfiguracaoFila())
			.append(" ON (ConfiguracaoFila.ID_CONFIGURACAO_FILA = GrupoEquipeFila.id_configuracao_fila ) ")
			.append(WHERE).append(" GrupoEquipeFila.id_grupo_equipe = ? ");
			
			stmt = getPreparedStatement(sql.toString());
			stmt.setInt(1,grupoEquipe.getIdGrupoEquipe());
			stmt.execute();
			resultSet = stmt.getResultSet();
			equipeFilas = new ArrayList<GrupoEquipeFila>();
			
			while (resultSet.next()) {
				GrupoEquipeFila grupo = GrupoEquipeFila.getGrupoEquipeFilaByResultSet(resultSet);
				grupo.setConfiguracaoFila(ConfiguracaoFila.getConfiguracaoFilaByResultSet(resultSet));
				equipeFilas.add(grupo);
			}
			
            return equipeFilas;
        } catch (Exception e) {
            throw new DataException("Erro ao buscar GrupoEquipeFila ", e);
        }finally{
        	super.close(resultSet);
        }
    }
    
    @Override
    public void limpaGrupoEquipeFila(GrupoEquipe equipe) throws DataException {
        
    	Query query = getEntityManager().createNativeQuery("delete from tb_grupo_equipe_fila where id_grupo_equipe = :grupo ");
		query.setParameter("grupo", equipe.getIdGrupoEquipe());
    	query.executeUpdate();
    }
    
    @Override
	public GrupoEquipeFila findByPk(Object id)throws DataException{
		
		ResultSet resultSet = null;
		PreparedStatement stmt = null;
		
		try {
			
			StringBuilder string = new StringBuilder(SELECT)
			  .append(GrupoEquipeFila.getSqlCamposGrupoEquipeFila())
			  .append(",").append(GrupoEquipe.getSqlCamposGrupoEquipe())
			  .append(",").append(ConfiguracaoFila.getSqlCamposConfiguracaoFila())
			  .append(FROM).append(GrupoEquipeFila.getSqlFromGrupoEquipeFila())
			  .append(INNER_JOIN).append(GrupoEquipe.getSqlFromGrupoEquipe())
			  .append(" ON GrupoEquipeFila.id_grupo_equipe=GrupoEquipe.id_grupo_equipe) ")
			   .append(INNER_JOIN).append(ConfiguracaoFila.getSqlFromConfiguracaoFila())
			  .append(" ON (GrupoEquipeFila.id_configuracao_fila=ConfiguracaoFila.ID_CONFIGURACAO_FILA) ")
			  .append(WHERE).append("GrupoEquipeFila.tb_grupo_equipe_fila= ? ");
			
			GrupoEquipeFila grupoEquipeFila = (GrupoEquipeFila) id;
			
			stmt = getPreparedStatement(string.toString());
			stmt.setInt(1,grupoEquipeFila.getTbGrupoEquipeFila());
			stmt.execute();
			
			resultSet = stmt.getResultSet();

			while (resultSet.next()) {
				grupoEquipeFila = GrupoEquipeFila.getGrupoEquipeFilaByResultSet(resultSet);
				grupoEquipeFila.setConfiguracaoFila(ConfiguracaoFila.getConfiguracaoFilaByResultSet(resultSet));
				grupoEquipeFila.setIdGrupoEquipe(GrupoEquipe.getGrupoEquipeByResultSet(resultSet));
			}
			
			return grupoEquipeFila;
		} catch (Exception e) {
			throw new DataException("Erro ao buscar GrupoEquipeFila pelo id.", e);
		} finally {
			super.close(resultSet);
		}
	}
    
}
