package br.com.callink.cad.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import br.com.callink.cad.dao.IHistoricoDadosCasoDAO;
import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.HistoricoDadosCaso;
import br.com.callink.cad.sau.exception.DataException;

public class HistoricoDadosCasoDAO extends GenericCadDAO<HistoricoDadosCaso> implements IHistoricoDadosCasoDAO {

	private static final long serialVersionUID = -9106858273062505285L;

	public HistoricoDadosCasoDAO() {
		super(HistoricoDadosCaso.class);
	}

	
	@Override
	public HistoricoDadosCaso findByPk(Object id)throws DataException{
		
		ResultSet resultSet = null;
		PreparedStatement stmt = null;
		
		try {
			
			StringBuilder string = new StringBuilder(SELECT)
			  .append(HistoricoDadosCaso.getSqlCamposHistoricoDadosCaso())
			  .append(",").append(Atendente.getSqlCamposAtendente())
			  .append(",").append(Caso.getSqlCamposCaso())
			  .append(FROM).append(HistoricoDadosCaso.getSqlFromHistoricoDadosCaso())
			  .append(INNER_JOIN).append(Atendente.getSqlFromAtendente())
			  .append(" ON (HistoricoDadosCaso.ID_ATENDENTE=Atendente.ID_ATENDENTE) ")
			   .append(INNER_JOIN).append(Caso.getSqlFromCaso())
			  .append(" ON (HistoricoDadosCaso.ID_CASO=Caso.ID_CASO) ")
			  .append(WHERE).append("HistoricoDadosCaso.id_historico_dados_caso = ? ");
			
			HistoricoDadosCaso historicoDadosCaso = (HistoricoDadosCaso) id;
			
			stmt = getPreparedStatement(string.toString());
			stmt.setInt(1,historicoDadosCaso.getIdHistoricoDadosCaso());
			stmt.execute();
			
			resultSet = stmt.getResultSet();

			while (resultSet.next()) {
				historicoDadosCaso = HistoricoDadosCaso.getHistoricoDadosCasoByResultSet(resultSet);
				historicoDadosCaso.setAtendente(Atendente.getAtendenteByResultSet(resultSet));
				historicoDadosCaso.setCaso(Caso.getCasoByResultSet(resultSet));
			}
			
			return historicoDadosCaso;
		} catch (Exception e) {
			throw new DataException("Erro ao buscar HistoricoDadosCaso pelo id.", e);
		} finally {
			super.close(resultSet);
		}
	}
}
