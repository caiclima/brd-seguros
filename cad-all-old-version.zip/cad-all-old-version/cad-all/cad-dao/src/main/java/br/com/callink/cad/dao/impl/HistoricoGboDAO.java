/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import br.com.callink.cad.dao.IHistoricoGboDAO;
import br.com.callink.cad.pojo.HistoricoGbo;
import br.com.callink.cad.pojo.TelaGbo;
import br.com.callink.cad.sau.exception.DataException;

public class HistoricoGboDAO extends GenericCadDAO<HistoricoGbo> implements IHistoricoGboDAO{

	private static final long serialVersionUID = 4520331900547561612L;

	public HistoricoGboDAO() {
		super(HistoricoGbo.class);
	}
	
	@Override
	public HistoricoGbo findByPk(Object id)throws DataException{
		
		ResultSet resultSet = null;
		PreparedStatement stmt = null;
		
		try {
			
			StringBuilder string = new StringBuilder(SELECT)
			  .append(HistoricoGbo.getSqlCamposHistoricoGbo())
			  .append(",").append(TelaGbo.getSqlCamposTelaGbo())
			  .append(FROM).append(HistoricoGbo.getSqlFromHistoricoGbo())
			  .append(INNER_JOIN).append(TelaGbo.getSqlFromTelaGbo())
			  .append(" ON (HistoricoGbo.ID_TELA_GBO=TelaGbo.ID_TELA_GBO ) ")
			  .append(WHERE).append("HistoricoGbo.ID_HISTORICO_ORDEM_CASO = ? ");
			
			HistoricoGbo historicoGbo = (HistoricoGbo) id;
			
			stmt = getPreparedStatement(string.toString());
			stmt.setInt(1,historicoGbo.getIdHistoricoOrdemCaso());
			stmt.execute();
			
			resultSet = stmt.getResultSet();

			while (resultSet.next()) {
				historicoGbo = HistoricoGbo.getHistoricoGboByResultSet(resultSet);
				historicoGbo.setTelaGbo(TelaGbo.getTelaGboByResultSet(resultSet));
			}
			
			return historicoGbo;
		} catch (Exception e) {
			throw new DataException("Erro ao buscar HistoricoGbo pelo id.", e);
		} finally {
			super.close(resultSet);
		}
	}
}
