package br.com.callink.cad.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import br.com.callink.cad.dao.ILogDAO;
import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.pojo.Email;
import br.com.callink.cad.pojo.Equipe;
import br.com.callink.cad.pojo.GrupoAnexo;
import br.com.callink.cad.pojo.Log;
import br.com.callink.cad.pojo.Status;
import br.com.callink.cad.pojo.Util.DateUtil;
import br.com.callink.cad.sau.exception.DataException;

public class LogDAO extends GenericCadDAO<Log> implements ILogDAO {

	private static final long serialVersionUID = -604404081582130898L;
	
	private static final String VIRGULA = ",";

	public LogDAO() {
		super(Log.class);
	}

	@Override
    public List<Log> findHistorico(Caso caso) throws DataException {
        
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		List<Log> list = null;
		
		try {
			
			StringBuilder sql = new StringBuilder(SELECT)
			.append(Log.getSqlCamposLog())
			.append(",").append(Atendente.getSqlCamposAtendente())
			.append(",").append(Status.getSqlCamposStatus())
			.append(",").append(Acao.getSqlCamposAcao())
			.append(",").append(Equipe.getSqlEquipe())
			.append(FROM).append(Log.getSqlFromLog())
			.append(LEFT_JOIN).append(Atendente.getSqlFromAtendente())
			.append(" ON (Log.ID_ATENDENTE = Atendente.ID_ATENDENTE) ")
			.append(LEFT_JOIN).append(Equipe.getSqlFromEquipe())
			.append(" ON (Atendente.ID_EQUIPE = Equipe.ID_EQUIPE) ")
			.append(INNER_JOIN).append(Status.getSqlFromStatus())
			.append(" ON (Log.ID_STATUS = Status.ID_STATUS)")
			.append(LEFT_JOIN).append(Acao.getSqlFromAcao())
			.append(" ON (Log.ID_ACAO = Acao.ID_ACAO)")
			.append(WHERE).append(" Log.ID_CASO = ? ")
			.append(" ORDER BY Log.DATA_LOG ");
			
			stmt = getPreparedStatement(sql.toString());
			stmt.setInt(1, caso.getIdCaso());
			stmt.execute();
			resultSet = stmt.getResultSet();
			list = new ArrayList<Log>();
			
			while (resultSet.next()) {
				
				Log log = Log.getLogByResultSet(resultSet);
				Atendente atendente = Atendente.getAtendenteByResultSet(resultSet);
				
				if(atendente != null){
					atendente.setEquipe(Equipe.getEquipeByResultSet(resultSet));
				}
				
				log.setAtendente(atendente);
				log.setStatus(Status.getStatusByResultSet(resultSet));
				log.setAcao(Acao.getAcaoByResultSet(resultSet));
				list.add(log);
			}

			return list;
			
        } catch (Exception e) {
            throw new DataException(e);
        } finally {
        	super.close(resultSet);
        }
    }
    
    @Override
    public List<Log> findHistoricoEmail(Caso caso) throws DataException {
    	
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
		List<Log> list = null;
		
		try {
			
			StringBuilder sql = new StringBuilder(SELECT)
			.append(Log.getSqlCamposLog())
			.append(",").append(Atendente.getSqlCamposAtendente())
			.append(",").append(Email.getSqlCamposEmail())
			.append(FROM).append(Log.getSqlFromLog())
			.append(LEFT_JOIN).append(Atendente.getSqlFromAtendente())
			.append(" ON (Log.ID_ATENDENTE = Atendente.ID_ATENDENTE) ")
			.append(INNER_JOIN).append(Email.getSqlFromEmail())
			.append(" ON (Log.ID_EMAIL = Email.ID_EMAIL ) ")
			.append(WHERE).append(" Email.ID_EMAIL IS NOT NULL ")
			.append(" AND Log.ID_CASO = ? ")
			.append(" ORDER BY Email.DATA_ENVIO DESC ");
			
			stmt = getPreparedStatement(sql.toString());
			stmt.setInt(1, caso.getIdCaso());
			stmt.execute();
			resultSet = stmt.getResultSet();
            list = retornaLog(resultSet);
            
            return list;
        } catch (Exception e) {
            throw new DataException(e);
        }finally{
        	super.close(resultSet);
        }
    }

    private List<Log> retornaLog(ResultSet resultSet) throws DataException {
        try {
            List<Log> logList = new ArrayList<Log>();
            if (resultSet != null) {
                while (resultSet.next()) {
                    Log log = Log.getLogByResultSet(resultSet);
                    Atendente atendente = Atendente.getAtendenteByResultSet(resultSet);
                    log.setAtendente(atendente);
                    Email email = Email.getEmailByResultSet(resultSet);
                    log.setEmail(email);
                    
                    logList.add(log);
                }
            } 
            return logList;
        } catch (SQLException e) {
                throw new DataException("Erro ", e);
        }
    }
    
    @Override
	public Log findByPk(Object id)throws DataException{
		
		ResultSet resultSet = null;
		PreparedStatement stmt = null;
		
		try {
			
			StringBuilder string = new StringBuilder(SELECT)
			  .append(Log.getSqlCamposLog())
			  .append(",").append(Status.getSqlCamposStatus())
			  .append(",").append(Atendente.getSqlCamposAtendente())
			  .append(",").append(Caso.getSqlCamposCaso())
			  .append(",").append(GrupoAnexo.getSqlCamposGrupoAnexo())
			  .append(",").append(Acao.getSqlCamposAcao())
			  .append(",").append(Email.getSqlCamposEmail())
			  .append(",").append(ConfiguracaoFila.getSqlCamposConfiguracaoFila())
			  .append(FROM).append(Log.getSqlFromLog())
			  .append(INNER_JOIN).append(Status.getSqlFromStatus())
			  .append(" ON (Log.ID_STATUS=Status.ID_STATUS ) ")
			  .append(LEFT_JOIN).append(Atendente.getSqlFromAtendente())
			  .append(" ON (Log.ID_ATENDENTE=Atendente.ID_ATENDENTE) ")
			  .append(INNER_JOIN).append(Caso.getSqlFromCaso())
			  .append(" ON (Log.ID_CASO=Caso.ID_CASO) ")
			  .append(LEFT_JOIN).append(GrupoAnexo.getSqlFromGrupoAnexo())
			  .append(" ON (Log.ID_GRUPO_ANEXO=GrupoAnexo.ID_GRUPO_ANEXO) ")
			  .append(LEFT_JOIN).append(Acao.getSqlFromAcao())
			  .append(" ON (Log.ID_ACAO=Acao.ID_ACAO) ")
			  .append(LEFT_JOIN).append(Email.getSqlFromEmail())
			  .append(" ON (Log.ID_EMAIL=Email.ID_EMAIL) ")
			  .append(LEFT_JOIN).append(ConfiguracaoFila.getSqlFromConfiguracaoFila())
			  .append(" ON (Log.ID_CONFIGURACAO_FILA=ConfiguracaoFila.ID_CONFIGURACAO_FILA) ")
			  .append(WHERE).append("Log.ID_LOG = ? ");
			
			Log log = (Log) id;
			stmt = getPreparedStatement(string.toString());
			stmt.setInt(1, log.getIdLog());
			stmt.execute();
			
			resultSet = stmt.getResultSet();

			while (resultSet.next()) {
				log = Log.getLogByResultSet(resultSet);
				log.setStatus(Status.getStatusByResultSet(resultSet));
				log.setAtendente(Atendente.getAtendenteByResultSet(resultSet));
				log.setCaso(Caso.getCasoByResultSet(resultSet));
				log.setGrupoAnexo(GrupoAnexo.getGrupoAnexoByResultSet(resultSet));
				log.setAcao(Acao.getAcaoByResultSet(resultSet));
				log.setEmail(Email.getEmailByResultSet(resultSet));
				log.setConfiguracaoFila(ConfiguracaoFila.getConfiguracaoFilaByResultSet(resultSet));
			}
			
			return log;
		} catch (Exception e) {
			throw new DataException("Erro ao buscar Log pelo id.", e);
		} finally {
			super.close(resultSet);
		}
	}

	@Override
	public Integer countLogByCasoAndData(Caso caso, Date dataInicial, Date dataFinal) throws DataException {
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		Integer countResult = 0;
		
		try {
			String dataInicialString = DateUtil.convertDateStringWithHour(dataInicial);
	    	String dataFinalString = DateUtil.convertDateStringWithHour(dataFinal);
			
			StringBuilder sql = new StringBuilder(SELECT)
			
			.append("count(*) ")
			.append(FROM).append(Log.getSqlFromLog())
			.append(INNER_JOIN).append(Status.getSqlFromStatus())
			.append(" ON (Log.ID_STATUS = Status.ID_STATUS)")
			.append(LEFT_JOIN).append(Acao.getSqlFromAcao())
			.append(" ON (Log.ID_ACAO = Acao.ID_ACAO)")
			.append(WHERE).append(" Log.ID_CASO = ? ")
			.append(" AND Log.data_log between '" + dataInicialString + "'" + " and " + "'" + dataFinalString + "'");
			
			stmt = getPreparedStatement(sql.toString());
			stmt.setInt(1, caso.getIdCaso());
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			while (resultSet.next()) {
				countResult = (Integer) resultSet.getObject(1);
			}

			return countResult;
			
        } catch (Exception e) {
            throw new DataException(e);
        } finally {
        	super.close(resultSet);
        }
	}
	
	@Override
	public Integer countLogByCasoAndDataAndStatus(Caso caso, Date dataInicial, Date dataFinal, List<Status> statusList) throws DataException {
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		Integer countResult = 0;
		
		try {
			String dataInicialString = DateUtil.convertDateStringWithHour(dataInicial);
	    	String dataFinalString = DateUtil.convertDateStringWithHour(dataFinal);
			
			StringBuilder sql = new StringBuilder(SELECT)
			
			.append("count(*) ")
			.append(FROM).append(Log.getSqlFromLog())
			.append(INNER_JOIN).append(Status.getSqlFromStatus())
			.append(" ON (Log.ID_STATUS = Status.ID_STATUS)")
			.append(LEFT_JOIN).append(Acao.getSqlFromAcao())
			.append(" ON (Log.ID_ACAO = Acao.ID_ACAO)")
			.append(WHERE).append(" Log.ID_CASO = ? ")
			.append(" AND Log.data_log between '" + dataInicialString + "'" + " and " + "'" + dataFinalString + "'")
			.append(" AND Status.NOME IN (");
			
			for (Status status : statusList) {
				sql.append("'" + status.getNome() + "'");
				
		        if (!status.equals(statusList.get(statusList.size()-1))) {
		        	sql.append(",");
		        }
		    }
			
			sql.append(")");
			
			stmt = getPreparedStatement(sql.toString());
			stmt.setInt(1, caso.getIdCaso());
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			while (resultSet.next()) {
				countResult = (Integer) resultSet.getObject(1);
			}

			return countResult;
			
        } catch (Exception e) {
            throw new DataException(e);
        } finally {
        	super.close(resultSet);
        }
	}
	
	@Override
    public List<Log> findLogsFromCaso(Caso caso, Date dataAlteracao) throws DataException {
    	List<Log> logList = new ArrayList<Log>();
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
		String data = DateUtil.convertDateStringWithHour(dataAlteracao);
    	try {
            StringBuilder sql = new StringBuilder()
            	.append(SELECT)
            	.append(Log.getSqlCamposLog())
            	.append(VIRGULA)
            	.append(ConfiguracaoFila.getSqlCamposConfiguracaoFila())
            	.append(VIRGULA)
            	.append(Atendente.getSqlCamposAtendente())
            	.append(FROM)
                .append(Log.getSqlFromLog())
                .append(LEFT_JOIN).append(ConfiguracaoFila.getSqlFromConfiguracaoFila())
				.append(" ON Log.ID_CONFIGURACAO_FILA = ConfiguracaoFila.ID_CONFIGURACAO_FILA ")
				.append(LEFT_JOIN).append(Atendente.getSqlFromAtendente())
				.append(" ON Log.ID_ATENDENTE = Atendente.ID_ATENDENTE ")
                .append(WHERE_1_1)
                .append(" AND Log.ID_CASO = ? ")
                .append(" AND Log.data_log > '" + data + "'")
                .append(" ORDER BY Log.DATA_LOG ");

            stmt = getPreparedStatement(sql.toString());
            
            stmt.setInt(1, caso.getIdCaso());
            
			stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null) {
				while (resultSet.next()) {
					Log log = Log.getLogByResultSet(resultSet);
					ConfiguracaoFila configuracaoFila = ConfiguracaoFila.getConfiguracaoFilaByResultSet(resultSet);
					Atendente atendente = Atendente.getAtendenteByResultSet(resultSet);
					log.setAtendente(atendente);
					log.setConfiguracaoFila(configuracaoFila);
					
					logList.add(log);
				}
			}
        } catch (Exception e) {
            throw new DataException(e);
        } finally {
        	super.close(resultSet);
        }
    	return logList;
    }
    
}
