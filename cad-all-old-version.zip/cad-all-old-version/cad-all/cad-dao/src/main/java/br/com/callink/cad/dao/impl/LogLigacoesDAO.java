package br.com.callink.cad.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import br.com.callink.cad.dao.ILogLigacoesDAO;
import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.ContatoTelefone;
import br.com.callink.cad.pojo.EventoLigacao;
import br.com.callink.cad.pojo.LogLigacoes;
import br.com.callink.cad.pojo.Telefone;
import br.com.callink.cad.sau.exception.DataException;

public class LogLigacoesDAO extends GenericCadDAO<LogLigacoes> implements ILogLigacoesDAO {

	public LogLigacoesDAO() {
		super(LogLigacoes.class);
	}

	private static final long serialVersionUID = -7492513094458967525L;

	
	@Override
	public List<LogLigacoes> findByCallIDAndDateEndNull(String callID) throws DataException {
		
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		List<LogLigacoes> list = null;
		
		try {
			
			StringBuilder sql = new StringBuilder(SELECT)
			 .append(LogLigacoes.getSqlCamposLogLigacoes())
			 .append(FROM).append(LogLigacoes.getSqlFromLogLigacoes())
			 .append(WHERE).append(" LogLigacoes.CALL_ID = ? ")
			 .append(" AND  LogLigacoes.DATA_FIM IS NULL ");
			
			stmt = getPreparedStatement(sql.toString());
			stmt.setString(1, callID);
			stmt.execute();
			
			resultSet = stmt.getResultSet();
			list = new ArrayList<LogLigacoes>();
			
			while (resultSet.next()) {
				LogLigacoes log = LogLigacoes.getLogLigacoesByResultSet(resultSet);
				list.add(log);
			}
			
			return list;
		} catch (Exception e) {
			throw new DataException("Erro ao buscar logLigacoes por callID e data final vazia", e);
		}finally{
			super.close(resultSet);
		}
	}
	
	@Override
	public List<LogLigacoes> findByUserSSOTelefone(String userSSO, String telefone) throws DataException {
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		List<LogLigacoes> list = null;
		
		try {
			
			StringBuilder sql = new StringBuilder(SELECT)
			 .append(LogLigacoes.getSqlCamposLogLigacoes())
			 .append(",").append(Atendente.getSqlCamposAtendente())
			 .append(FROM).append(LogLigacoes.getSqlFromLogLigacoes())
			 .append(INNER_JOIN).append(Atendente.getSqlFromAtendente())
			 .append(" ON ( LogLigacoes.ID_ATENDENTE = Atendente.ID_ATENDENTE ) ")
			 .append(WHERE).append(" Atendente.LOGIN = ? ")
			 .append(" AND LogLigacoes.TELEFONE_CLIENTE = ? ")
			 .append(" ORDER BY LogLigacoes.DATA_INICIO DESC ");
			
			stmt = getPreparedStatement(sql.toString());
			stmt.setString(1, userSSO);
			stmt.setString(2, telefone);
			stmt.execute();
			resultSet = stmt.getResultSet();
			list = new ArrayList<LogLigacoes>();
			
			while (resultSet.next()) {
				
				LogLigacoes log = LogLigacoes.getLogLigacoesByResultSet(resultSet);
				log.setAtendente(Atendente.getAtendenteByResultSet(resultSet));
				list.add(log);
			}
			
			return list;
			
		} catch (Exception e) {
			throw new DataException("Erro ao buscar logLigacoes por callID e data final vazia", e);
		}finally{
			super.close(resultSet);
		}
	}
	
	@Override
	public List<LogLigacoes> findByCallIdNullForUserSSO(String userSSO, String telefone) throws DataException {
		
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		List<LogLigacoes> list = null;
		
		try {
			
			StringBuilder sql = new StringBuilder(SELECT)
			 .append(LogLigacoes.getSqlCamposLogLigacoes())
			 .append(",").append(Atendente.getSqlCamposAtendente())
			 .append(FROM).append(LogLigacoes.getSqlFromLogLigacoes())
			 .append(INNER_JOIN).append(Atendente.getSqlFromAtendente())
			 .append(" ON ( LogLigacoes.ID_ATENDENTE = Atendente.ID_ATENDENTE ) ")
			 .append(WHERE).append(" Atendente.LOGIN = ? ")
			 .append(" AND LogLigacoes.DATA_FIM IS NULL ")
			 .append(" AND LogLigacoes.CALL_ID IS NULL ")
			 .append(" AND LogLigacoes.TELEFONE_CLIENTE = ? ")
			 .append(" ORDER BY LogLigacoes.ID_LOG_LIGACOES DESC ");
			
			stmt = getPreparedStatement(sql.toString());
			stmt.setString(1, userSSO);
			stmt.setString(2, telefone);
			stmt.execute();
			resultSet = stmt.getResultSet();
			list = new ArrayList<LogLigacoes>();
			
			while (resultSet.next()) {
				
				LogLigacoes log = LogLigacoes.getLogLigacoesByResultSet(resultSet);
				log.setAtendente(Atendente.getAtendenteByResultSet(resultSet));
				list.add(log);
			}
			
			return list;
			
		} catch (Exception e) {
			throw new DataException("Erro ao buscar logLigacoes por callID e data final vazia", e);
		}finally{
			super.close(resultSet);
		}
	}
	
	@Override
	public List<LogLigacoes> findByFilters(String idCaso, String flagEntrante, Date inicio, Date fim, List<Atendente> atendenteList) throws DataException {
		
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		List<LogLigacoes> list = null;
		int index =0;
		
		try {
			
			StringBuilder sql = new StringBuilder(SELECT)
			 .append(LogLigacoes.getSqlCamposLogLigacoes())
			 .append(",").append(Atendente.getSqlCamposAtendente())
			 .append(",").append(Caso.getSqlCamposCaso())
			 .append(FROM).append(LogLigacoes.getSqlFromLogLigacoes())
			 .append(INNER_JOIN).append(Atendente.getSqlFromAtendente())
			 .append(" ON ( LogLigacoes.ID_ATENDENTE = Atendente.ID_ATENDENTE ) ")
			 .append(LEFT_JOIN).append(Caso.getSqlFromCaso())
			 .append(" ON ( LogLigacoes.ID_CASO = Caso.ID_CASO ) ").append(WHERE_1_1);
			
			if (idCaso != null && !idCaso.isEmpty()) {
				sql.append(" AND Caso.ID_EXTERNO = ? ");
			}
			
			if (inicio != null && fim != null) {
				sql.append(" AND LogLigacoes.DATA_INICIO BETWEEN ? AND ? ");
			}
			
			if (flagEntrante != null && (flagEntrante.equals("S") || flagEntrante.equals("N"))) {
				if (flagEntrante.equals("S")) {
					sql.append(" AND LogLigacoes.ENTRANTE = 1 ");
				} else {
					sql.append(" AND LogLigacoes.ENTRANTE = 0 ");
				}
			}
			
			if (atendenteList != null && !atendenteList.isEmpty() ) {
				sql.append(String.format(" AND Atendente.ID_ATENDENTE IN (%s)", inIdAtendentes(atendenteList)));
			}
			
			sql.append(" ORDER BY LogLigacoes.ID_LOG_LIGACOES DESC ");
			
			stmt = getPreparedStatement(sql.toString());
			
			if (idCaso != null && !idCaso.isEmpty()) {
				stmt.setString(++index, idCaso);
			}
			
			if (inicio != null && fim != null) {
				stmt.setDate(++index, new java.sql.Date(inicio.getTime()));
				stmt.setDate(++index, new java.sql.Date(fim.getTime()));
			}
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			list = new ArrayList<LogLigacoes>();
			
			while (resultSet.next()) {
				
				LogLigacoes log = LogLigacoes.getLogLigacoesByResultSet(resultSet);
				log.setAtendente(Atendente.getAtendenteByResultSet(resultSet));
				log.setCaso(Caso.getCasoByResultSet(resultSet));
				
				list.add(log);
			}
			
			return list;
		} catch (Exception e) {
			throw new DataException("Erro ao buscar logLigacoes por findByFilters ", e);
		} finally{
			super.close(resultSet);
		}
	}
	
	private static String inIdAtendentes(List<Atendente> atendenteList) {
		
		StringBuilder idAtendentes = new StringBuilder();
		for (Atendente atendente : atendenteList) {
			idAtendentes.append(atendente.getIdAtendente()).append(",");
		}
		
		return idAtendentes.toString().substring(0, idAtendentes.length() - 1);
	}
	
	@Override
	public LogLigacoes findByPk(Object id)throws DataException{
		
		ResultSet resultSet = null;
		PreparedStatement stmt = null;
		
		try {
			
			StringBuilder string = new StringBuilder(SELECT)
			  .append(LogLigacoes.getSqlCamposLogLigacoes())
			  .append(",").append(Atendente.getSqlCamposAtendente())
			  .append(",").append(Caso.getSqlCamposCaso())
			  .append(FROM).append(LogLigacoes.getSqlFromLogLigacoes())
			  .append(LEFT_JOIN).append(Atendente.getSqlFromAtendente())
			  .append(" ON (LogLigacoes.ID_ATENDENTE=Atendente.ID_ATENDENTE ) ")
			  .append(LEFT_JOIN).append(Caso.getSqlFromCaso())
			  .append(" ON (LogLigacoes.ID_CASO=Caso.ID_CASO) ")
			  .append(WHERE).append("LogLigacoes.ID_LOG_LIGACOES = ? ");
			
			LogLigacoes logLigacoes = (LogLigacoes) id;
			stmt = getPreparedStatement(string.toString());
			stmt.setInt(1, logLigacoes.getIdLogLigacoes());
			stmt.execute();
			
			resultSet = stmt.getResultSet();

			while (resultSet.next()) {
				logLigacoes = LogLigacoes.getLogLigacoesByResultSet(resultSet);
				logLigacoes.setAtendente(Atendente.getAtendenteByResultSet(resultSet));
				logLigacoes.setCaso(Caso.getCasoByResultSet(resultSet));
			}
			
			return logLigacoes;
		} catch (Exception e) {
			throw new DataException("Erro ao buscar LogLigacoes pelo id.", e);
		} finally {
			super.close(resultSet);
		}
	}

	@Override
	public Boolean existeTentativaDeContatoPorCaso(Caso caso) throws DataException {
		ResultSet resultSet = null;
		PreparedStatement stmt = null;
		
		try {
			
			StringBuilder string = new StringBuilder(SELECT)
			  .append(" count(1) as total ")
			  .append(FROM).append(LogLigacoes.getSqlFromLogLigacoes())
			  .append(WHERE).append(" LogLigacoes.ID_CASO = ? ");
			
			stmt = getPreparedStatement(string.toString());
			stmt.setInt(1, caso.getIdCaso());
			stmt.execute();
			
			resultSet = stmt.getResultSet();
			return resultSet!= null && resultSet.next() && resultSet.getInt("total") > 0;
			
		} catch (Exception e) {
			throw new DataException("Erro ao buscar LogLigacoes.", e);
		} finally {
			super.close(resultSet);
		}
	}

	@Override
	public Boolean existeTentativaDeContatoParaTodosTelefonesPorCasoEData(Caso caso, Date data) throws DataException {
		final DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		ResultSet resultSet = null;
		PreparedStatement stmt = null;
		
		try {
			
			StringBuilder string = new StringBuilder(SELECT)
			  .append(" count(1) as total ")
			  .append(FROM).append(Telefone.getSqlFromTelefone())
			  .append(WHERE).append(" Telefone.telefone not in ( select LogLigacoes.telefone_cliente ")
			  .append(FROM).append(LogLigacoes.getSqlFromLogLigacoes())
			  .append(WHERE).append("LogLigacoes.id_caso = Telefone.id_caso and convert(date, LogLigacoes.data_inicio, 103) = ? ) ")
			  .append(" AND Telefone.id_caso = ?");
			
			stmt = getPreparedStatement(string.toString());
			stmt.setString(1, df.format(data));
			stmt.setInt(2, caso.getIdCaso());
			stmt.execute();
			
			resultSet = stmt.getResultSet();
			return resultSet!= null && resultSet.next() && resultSet.getInt("total") == 0;
			
		} catch (Exception e) {
			throw new DataException("Erro ao buscar LogLigacoes.", e);
		} finally {
			super.close(resultSet);
		}
	}

	@Override
	public Boolean existeContatoComSucessoPorCaso(Caso caso) throws DataException {
		ResultSet resultSet = null;
		PreparedStatement stmt = null;
		
		try {
			
			StringBuilder string = new StringBuilder(SELECT)
			  .append(" count(1) as total ")
			  .append(FROM).append(LogLigacoes.getSqlFromLogLigacoes())
			  .append(INNER_JOIN).append(ContatoTelefone.getSqlFromContato()).append(" ON ( LogLigacoes.ID_CASO = ContatoTelefone.ID_CASO ) ")
			  .append(WHERE).append("LogLigacoes.id_caso = ? ")
			  .append(" AND ContatoTelefone.ID_EVENTO_LIGACAO in ( select EventoLigacao.ID_EVENTO_LIGACAO ")
			  .append(FROM).append(EventoLigacao.getSqlFromEvento())
			  .append(WHERE).append("EventoLigacao.flag_sucesso = 1 ) ");
			
			stmt = getPreparedStatement(string.toString());
			stmt.setInt(1, caso.getIdCaso());
			stmt.execute();
			
			resultSet = stmt.getResultSet();
			return resultSet!= null && resultSet.next() && resultSet.getInt("total") > 0;
			
		} catch (Exception e) {
			throw new DataException("Erro ao buscar LogLigacoes.", e);
		} finally {
			super.close(resultSet);
		}
	}

	@Override
	public Boolean existeTentativaDeContatoParaTodosOutrosTelefonesPorCaso(Caso caso, String telefone) throws DataException {
		ResultSet resultSet = null;
		PreparedStatement stmt = null;
		
		try {
			
			StringBuilder string = new StringBuilder(SELECT)
			  .append(" count(1) as total ")
			  .append(FROM).append(Telefone.getSqlFromTelefone())
			  .append(WHERE).append(" Telefone.telefone not in ( select LogLigacoes.telefone_cliente ")
			  .append(FROM).append(LogLigacoes.getSqlFromLogLigacoes())
			  .append(WHERE).append("LogLigacoes.id_caso = Telefone.id_caso ) ")
			  .append(" AND Telefone.telefone <> ?")
			  .append(" AND Telefone.id_caso = ?");
			
			stmt = getPreparedStatement(string.toString());
			stmt.setString(1, telefone);
			stmt.setInt(2, caso.getIdCaso());
			stmt.execute();
			
			resultSet = stmt.getResultSet();
			return resultSet!= null && resultSet.next() && resultSet.getInt("total") == 0;
			
		} catch (Exception e) {
			throw new DataException("Erro ao buscar LogLigacoes.", e);
		} finally {
			super.close(resultSet);
		}
	}

	@Override
	public Integer findQtdTentativaDeContatoPorTelefoneEData(String telefone, Date data) throws DataException {
		final DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		ResultSet resultSet = null;
		PreparedStatement stmt = null;
		
		try {
			
			StringBuilder string = new StringBuilder(SELECT)
			  .append(" count(1) as total ")
			  .append(FROM).append(LogLigacoes.getSqlFromLogLigacoes())
			  .append(WHERE).append(" convert(date, LogLigacoes.data_inicio, 103) = ?  ")
			  .append(" AND LogLigacoes.telefone_cliente = ? ");
			
			stmt = getPreparedStatement(string.toString());
			stmt.setString(1, df.format(data));
			stmt.setString(2, telefone);
			stmt.execute();
			
			resultSet = stmt.getResultSet();
			while (resultSet.next()) {
				return resultSet.getInt("total");
			}
			
		} catch (Exception e) {
			throw new DataException("Erro ao buscar LogLigacoes.", e);
		} finally {
			super.close(resultSet);
		}
		return null;
	}
	
}
