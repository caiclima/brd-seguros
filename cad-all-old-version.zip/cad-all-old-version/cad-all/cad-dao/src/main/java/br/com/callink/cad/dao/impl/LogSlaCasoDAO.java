package br.com.callink.cad.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.com.callink.cad.dao.ILogSlaCasoDAO;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.LogSlaCaso;
import br.com.callink.cad.sau.exception.DataException;

public class LogSlaCasoDAO extends GenericCadDAO<LogSlaCaso> implements ILogSlaCasoDAO {

	private static final long serialVersionUID = 4418709165124648368L;

	public LogSlaCasoDAO() {
		super(LogSlaCaso.class);
	}
	
	public List<LogSlaCaso> findLogSlaByCaso(Caso caso) throws DataException {
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		List<LogSlaCaso> list = null;
		try {
			StringBuilder sql = new StringBuilder(SELECT)
					.append(LogSlaCaso.getSqlCamposLogSlaCaso())
					.append(FROM).append(LogSlaCaso.getSqlFromLogSlaCaso())
					.append(WHERE).append(" LogSlaCaso.ID_CASO = ? ")
					.append(" ORDER BY LogSlaCaso.DATA_ABERTURA DESC ");
			
			stmt = getPreparedStatement(sql.toString());
			stmt.setInt(1, caso.getIdCaso());
			stmt.execute();
			resultSet = stmt.getResultSet();
			list = new ArrayList<LogSlaCaso>();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					LogSlaCaso logSlaCaso = LogSlaCaso.getLogSlaCasoByResultSet(resultSet);
					list.add(logSlaCaso);
				}
			}
			return list;
        } catch (Exception e) {
            throw new DataException(e);
        } finally {
        	super.close(resultSet);
        }
	}
	
}
