package br.com.callink.cad.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import br.com.callink.cad.dao.ILogTaskDAO;
import br.com.callink.cad.pojo.LogTask;
import br.com.callink.cad.sau.exception.DataException;

public class LogTaskDAO extends GenericCadDAO<LogTask> implements ILogTaskDAO {

	private static final long serialVersionUID = -4005791204359684983L;

	public LogTaskDAO() {
		super(LogTask.class);
	}
	
	@Override
	public LogTask findByPk(Object id)throws DataException{
		
		ResultSet resultSet = null;
		PreparedStatement stmt = null;
		
		try {
			
			StringBuilder string = new StringBuilder(SELECT)
			  .append(LogTask.getSqlCamposLogTask())
			  .append(FROM).append(LogTask.getSqlFromLogTask())
			  .append(WHERE).append("LogTask.ID_LOG_TASKS = ? ");
			
			LogTask logTask = (LogTask) id;
			stmt = getPreparedStatement(string.toString());
			stmt.setInt(1, logTask.getIdLogTasks());
			stmt.execute();
			
			resultSet = stmt.getResultSet();

			while (resultSet.next()) {
				logTask = LogTask.getLogTaskByResultSet(resultSet);
			}
			
			return logTask;
		} catch (Exception e) {
			throw new DataException("Erro ao buscar os LogTask pelo id.", e);
		} finally {
			super.close(resultSet);
		}
	}
}
