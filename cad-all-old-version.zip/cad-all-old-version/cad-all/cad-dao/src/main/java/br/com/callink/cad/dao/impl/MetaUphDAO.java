/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.com.callink.cad.dao.IMetaUphDAO;
import br.com.callink.cad.pojo.CabUph;
import br.com.callink.cad.pojo.MetaUph;
import br.com.callink.cad.sau.exception.DataException;

/**
 *
 * @author swb.miller
 */
public class MetaUphDAO extends GenericCadDAO<MetaUph> implements IMetaUphDAO {

	private static final long serialVersionUID = -6634902790976698067L;

	public MetaUphDAO() {
		super(MetaUph.class);
	}

    @Override
    public List<MetaUph> findMetaByCabUph(CabUph cab) throws DataException {
        
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
		List<MetaUph> metaList = null;
    	
        try {
        	
        	StringBuilder sql = new StringBuilder(SELECT)
        	.append(MetaUph.getSqlCamposMetaUph())
        	.append(FROM).append(MetaUph.getSqlFromMetaUph())
        	.append(WHERE).append(" MetaUph.ID_CAB_UPH = ? ")
        	.append(" ORDER BY MetaUph.DESCRICAO ");
        	
        	stmt = getPreparedStatement(sql.toString());
        	stmt.setInt(1, cab.getIdCabUph());
        	stmt.execute();
        	
        	resultSet = stmt.getResultSet();
        	metaList = new ArrayList<MetaUph>();
        	
        	while (resultSet.next()) {
				MetaUph meta = MetaUph.getMetaUphByResultSet(resultSet);
				metaList.add(meta);
			}
            return metaList;

        } catch (Exception e) {
            throw new DataException("Erro ao buscar Meta." , e);
        } finally {
			super.close(resultSet);
		}
    }
    
    @Override
	public MetaUph findByPk(Object id)throws DataException{
		
		ResultSet resultSet = null;
		PreparedStatement stmt = null;
		
		try {
			
			StringBuilder string = new StringBuilder(SELECT)
			  .append(MetaUph.getSqlCamposMetaUph())
			  .append(",").append(CabUph.getSqlCamposCabUph())
			  .append(FROM).append(MetaUph.getSqlFromMetaUph())
			  .append(INNER_JOIN).append(CabUph.getSqlFromCabUph())
			  .append(" ON (MetaUph.ID_CAB_UPH = CabUph.ID_CAB_UPH) ")
			  .append(WHERE).append(" MetaUph.ID_META_UPH = ? ");
			
			MetaUph metaUph = (MetaUph) id;
			stmt = getPreparedStatement(string.toString());
			stmt.setInt(1, metaUph.getIdMetaUph());
			stmt.execute();
			
			resultSet = stmt.getResultSet();

			while (resultSet.next()) {
				metaUph = MetaUph.getMetaUphByResultSet(resultSet);
				metaUph.setIdCabUph(CabUph.getCabUphByResultSet(resultSet));
			}
			
			return metaUph;
		} catch (Exception e) {
			throw new DataException("Erro ao buscar MetaUph pelo id.", e);
		} finally {
			super.close(resultSet);
		}
	}
    
}
