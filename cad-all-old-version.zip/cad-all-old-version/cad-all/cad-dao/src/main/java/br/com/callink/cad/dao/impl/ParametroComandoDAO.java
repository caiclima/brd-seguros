/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import br.com.callink.cad.dao.IParametroComandoDAO;
import br.com.callink.cad.pojo.Comando;
import br.com.callink.cad.pojo.ParametroComando;
import br.com.callink.cad.pojo.Util.DateUtil;
import br.com.callink.cad.sau.exception.DataException;

/**
 *
 * @author Rogério Moreira de Andrade. [rogeriom@swb.com.br]
 */
public class ParametroComandoDAO extends GenericCadDAO<ParametroComando> implements IParametroComandoDAO{

	private static final long serialVersionUID = 8456431520508645611L;

	public ParametroComandoDAO() {
		super(ParametroComando.class);
	}

	@Override
	public ParametroComando findByPk(Object id)throws DataException{
		
		ResultSet resultSet = null;
		PreparedStatement stmt = null;
		
		try {
			
			StringBuilder string = new StringBuilder(SELECT)
			  .append(ParametroComando.getSqlCamposParametroComando())
			  .append(",").append(Comando.getSqlCamposComando())
			  .append(FROM).append(ParametroComando.getSqlFromParametroComando())
			  .append(INNER_JOIN).append(Comando.getSqlFromComando())
			  .append(" ON (ParametroComando.ID_COMANDO = Comando.ID_COMANDO) ")
			  .append(WHERE).append(" ParametroComando.ID_PARAMETRO_COMANDO = ? ");
			
			ParametroComando parametroComando = (ParametroComando) id;
			stmt = getPreparedStatement(string.toString());
			stmt.setInt(1, parametroComando.getIdParametroComando());
			stmt.execute();
			
			resultSet = stmt.getResultSet();

			while (resultSet.next()) {
				parametroComando = ParametroComando.getParametroComandoByResultSet(resultSet);
				parametroComando.setComando(Comando.getComandoByResultSet(resultSet));
			}
			
			return parametroComando;
		} catch (Exception e) {
			throw new DataException("Erro ao buscar ParametroComando pelo id.", e);
		} finally {
			super.close(resultSet);
		}
	}
	
	
	@Override
	public List<ParametroComando> findByExample(ParametroComando object)throws DataException{
		
		ResultSet resultSet = null;
		PreparedStatement stmt = null;
		List<ParametroComando> list = null;
		int index=0; 
		
		try {
			
			StringBuilder string = new StringBuilder(SELECT)
			  .append(ParametroComando.getSqlCamposParametroComando())
			  .append(FROM).append(ParametroComando.getSqlFromParametroComando())
			  .append(WHERE_1_1);
			
			if(object != null){
				
				if(object.getIdParametroComando() != null){
					string.append(" AND ParametroComando.ID_PARAMETRO_COMANDO = ? ");
				}
					
				if(object.getNome()!= null && !object.getNome().isEmpty()){
					string.append(" AND ParametroComando.NOME = ? ");
				}
						
				if(object.getValor()!= null && !object.getValor().isEmpty()){
					string.append(" AND ParametroComando.VALOR = ? ");
				}
							
				if(object.getComando()!= null && object.getComando().getIdComando()!= null){
					string.append(" AND ParametroComando.ID_COMANDO =  ? ");
				}
								
				if(object.getLoginUsuario()!= null && !object.getLoginUsuario().isEmpty()){
					string.append(" AND ParametroComando.LOGIN_USUARIO = ? ");
				}
									
				if(object.getDataCriacao()!= null){
					string.append(" AND ParametroComando.DATA_CRIACAO BETWEEN  ? AND ? ");
				}
				
			}
			
			stmt = getPreparedStatement(string.toString());
			
			if(object != null){
				
				if(object.getIdParametroComando() != null){
					stmt.setInt(++index, object.getIdParametroComando());
				}
					
				if(object.getNome()!= null && !object.getNome().isEmpty()){
					stmt.setString(++index, object.getNome());
				}
						
				if(object.getValor()!= null && !object.getValor().isEmpty()){
					stmt.setString(++index, object.getValor());
				}
							
				if(object.getComando()!= null && object.getComando().getIdComando()!= null){
					stmt.setInt(++index, object.getComando().getIdComando());
				}
								
				if(object.getLoginUsuario()!= null && !object.getLoginUsuario().isEmpty()){
					stmt.setString(++index, object.getLoginUsuario());
				}
									
				if(object.getDataCriacao()!= null){
					Date dataInicio = DateUtil.dataInicioDia(object.getDataCriacao());
					Date dataFim = DateUtil.dataFimDia(object.getDataCriacao());
					stmt.setDate(++index, new java.sql.Date(dataInicio.getTime()));
					stmt.setDate(++index, new java.sql.Date(dataFim.getTime()));
				}
			}
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			list = new ArrayList<ParametroComando>();

			while (resultSet.next()) {
				ParametroComando parametro = ParametroComando.getParametroComandoByResultSet(resultSet);
				list.add(parametro);
			}
			
			return list;
		} catch (Exception e) {
			throw new DataException("Erro ao buscar ParametroComando pelo exemplo.", e);
		} finally {
			super.close(resultSet);
		}
	}
	
}
