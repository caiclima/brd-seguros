package br.com.callink.cad.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import br.com.callink.cad.dao.IParametroGBODAO;
import br.com.callink.cad.pojo.ParametroGBO;
import br.com.callink.cad.sau.exception.DataException;

public class ParametroGBODAO extends GenericCadDAO<ParametroGBO>  implements IParametroGBODAO {

	private static final long serialVersionUID = -8912725684052139939L;

	public ParametroGBODAO() {
		super(ParametroGBO.class);
	}

	@Override
	public ParametroGBO findByParam(String key) throws DataException {
		
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		
		try {
			
			StringBuilder sql = new StringBuilder(SELECT)
			.append(ParametroGBO.getSqlCamposParametroGBO())
			.append(FROM).append(ParametroGBO.getSqlFromParametroGBO())
			.append(WHERE).append(" ParametroGbo.nome = ? ");
			
			stmt = getPreparedStatement(sql.toString());
			stmt.setString(1, key);
			stmt.execute();
			
			resultSet = stmt.getResultSet();
			
			while(resultSet.next()){
				return ParametroGBO.getParametroGBOByResultSet(resultSet);
			}
			return null;
		} catch (Exception ex) {
			throw new DataException(ex);
		}finally{
			super.close(resultSet);
		}
	}
	
	@Override
	public List<ParametroGBO> findByParam(String... key) throws DataException {
		
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		
		try {
			
			StringBuilder sql = new StringBuilder(SELECT)
			.append(ParametroGBO.getSqlCamposParametroGBO())
			.append(FROM).append(ParametroGBO.getSqlFromParametroGBO())
			.append(WHERE).append(" ParametroGbo.nome in ( ");
			
			for (int i = 0; i < key.length;) {
				sql.append("'" + key[i] + "'");
				
		        if (++i < key.length) {
		        	sql.append(",");
		        }
		    }
			sql.append(")");
			
			stmt = getPreparedStatement(sql.toString());
			stmt.execute();
			
			resultSet = stmt.getResultSet();
			
			List<ParametroGBO> ret = new ArrayList<>();
			while(resultSet.next()){
				ret.add(ParametroGBO.getParametroGBOByResultSet(resultSet));
			}
			return ret;
		} catch (Exception ex) {
			throw new DataException(ex);
		}finally{
			super.close(resultSet);
		}
	}

	@Override
	public ParametroGBO findByPk(Object id)throws DataException{
		
		ResultSet resultSet = null;
		PreparedStatement stmt = null;
		
		try {
			
			StringBuilder string = new StringBuilder(SELECT)
			  .append(ParametroGBO.getSqlCamposParametroGBO())
			  .append(FROM).append(ParametroGBO.getSqlFromParametroGBO())
			  .append(WHERE).append(" ParametroGbo.id_parametro_gbo = ? ");
			
			ParametroGBO parametroGBO = (ParametroGBO) id;
			stmt = getPreparedStatement(string.toString());
			stmt.setInt(1, parametroGBO.getIdParametroGBO());
			stmt.execute();
			
			resultSet = stmt.getResultSet();

			while (resultSet.next()) {
				parametroGBO = ParametroGBO.getParametroGBOByResultSet(resultSet);
			}
			
			return parametroGBO;
		} catch (Exception e) {
			throw new DataException("Erro ao buscar ParametroGBO pelo id.", e);
		} finally {
			super.close(resultSet);
		}
	}

	@Override
	public List<ParametroGBO> findParamStartsWithKey(String key) throws DataException {
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		
		try {
			StringBuilder sql = new StringBuilder(SELECT)
			.append(ParametroGBO.getSqlCamposParametroGBO())
			.append(FROM).append(ParametroGBO.getSqlFromParametroGBO())
			.append(WHERE).append(" ParametroGbo.nome like ? ");
			
			stmt = getPreparedStatement(sql.toString());
			stmt.setString(1, key.concat("%"));
			stmt.execute();
			
			resultSet = stmt.getResultSet();
			
			List<ParametroGBO> ret = new ArrayList<ParametroGBO>();
			while(resultSet.next()){
				ret.add(ParametroGBO.getParametroGBOByResultSet(resultSet));
			}
			return ret;
		} catch (Exception ex) {
			throw new DataException(ex);
		}finally{
			super.close(resultSet);
		}
	}

}
