/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.com.callink.cad.dao.IPerfilDAO;
import br.com.callink.cad.pojo.Perfil;
import br.com.callink.cad.sau.exception.DataException;

/**
 *
 * @author Rogério Moreira de Andrade. [rogeriom@swb.com.br]
 */
public class PerfilDAO extends GenericCadDAO<Perfil> implements IPerfilDAO{

	private static final long serialVersionUID = 8579217085477275027L;

	public PerfilDAO() {
		super(Perfil.class);
	}

	@Override
    public List<Perfil> findAtivos() throws DataException {
        
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		List<Perfil> perfis = null;
		
		try {
			
			StringBuilder sql = new StringBuilder(SELECT)
			.append(Perfil.getSqlCamposPerfil())
			.append(FROM).append(Perfil.getSqlFromPerfil())
			.append(WHERE).append(" Perfil.flag_ativo = 1 "); 
			
			stmt = getPreparedStatement(sql.toString());
			stmt.execute();
			resultSet = stmt.getResultSet();
			perfis = new ArrayList<Perfil>();
			
			while(resultSet.next()){
				Perfil perfil = Perfil.getPerfilByResultSet(resultSet);
				perfis.add(perfil);
			}
			
			return perfis;

        } catch (Exception e) {
            throw new DataException(e);
        }finally{
        	close(resultSet);
        }
    }
	
	@Override
	public Perfil findByPk(Object id)throws DataException{
		
		ResultSet resultSet = null;
		PreparedStatement stmt = null;
		
		try {
			
			StringBuilder string = new StringBuilder(SELECT)
			  .append(Perfil.getSqlCamposPerfil())
			  .append(FROM).append(Perfil.getSqlFromPerfil())
			  .append(WHERE).append(" Perfil.id_perfil = ? ");
			
			Perfil perfil = (Perfil) id;
			
			stmt = getPreparedStatement(string.toString());
			stmt.setInt(1, perfil.getIdPerfil());
			stmt.execute();
			
			resultSet = stmt.getResultSet();

			while (resultSet.next()) {
				perfil = Perfil.getPerfilByResultSet(resultSet);
			}
			
			return perfil;
		} catch (Exception e) {
			throw new DataException("Erro ao buscar Perfil pelo id.", e);
		} finally {
			close(resultSet);
		}
	}
	
	
}
