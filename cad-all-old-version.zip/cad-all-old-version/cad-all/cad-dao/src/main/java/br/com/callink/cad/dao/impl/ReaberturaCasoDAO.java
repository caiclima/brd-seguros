package br.com.callink.cad.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.com.callink.cad.dao.IReaberturaCasoDAO;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.ReaberturaCaso;
import br.com.callink.cad.sau.exception.DataException;

public class ReaberturaCasoDAO extends GenericCadDAO<ReaberturaCaso> implements IReaberturaCasoDAO {

	private static final long serialVersionUID = 3981666303027391071L;

	public ReaberturaCasoDAO() {
		super(ReaberturaCaso.class);
	}

	@Override
    public List<ReaberturaCaso> findByCaso(Caso caso) throws DataException {
        
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		List<ReaberturaCaso> reaberturaCasos = null;
		
		try {
			
			StringBuilder sql = new StringBuilder(SELECT)
			.append(ReaberturaCaso.getSqlCamposReaberturaCaso())
			.append(FROM).append(ReaberturaCaso.getSqlFromReaberturaCaso())
			.append(WHERE).append(" ReaberturaCaso.ID_CASO = ? ");
			
			stmt = getPreparedStatement(sql.toString());
			stmt.setInt(1, caso.getIdCaso());
			stmt.execute();
			
			resultSet = stmt.getResultSet();
			reaberturaCasos = new ArrayList<ReaberturaCaso>();
			
			while(resultSet.next()){
				ReaberturaCaso reaberturaCaso = ReaberturaCaso.getReaberturaCasoByResultSet(resultSet);
				reaberturaCasos.add(reaberturaCaso);
			}
            
            return reaberturaCasos;
        } catch (Exception ex) {
            throw new DataException("Erro ao buscar as reaberturas.",ex);
        }finally{
        	close(resultSet);
        }
    }
	
	@Override
	public ReaberturaCaso findByPk(Object id)throws DataException{
		
		ResultSet resultSet = null;
		PreparedStatement stmt = null;
		
		try {
			
			StringBuilder string = new StringBuilder(SELECT)
			  .append(ReaberturaCaso.getSqlCamposReaberturaCaso())
			  .append(",").append(Caso.getSqlCamposCaso())
			  .append(FROM).append(ReaberturaCaso.getSqlFromReaberturaCaso())
			  .append(INNER_JOIN).append(Caso.getSqlFromCaso())
			  .append(" ON (ReaberturaCaso.ID_CASO = Caso.ID_CASO)")
			  .append(WHERE).append(" ReaberturaCaso.ID_REABERTURA_CASO = ? ");
			
			ReaberturaCaso reaberturaCaso = (ReaberturaCaso) id;
			stmt = getPreparedStatement(string.toString());
			stmt.setInt(1, reaberturaCaso.getIdReaberturaCaso());
			stmt.execute();
			
			resultSet = stmt.getResultSet();

			while (resultSet.next()) {
				reaberturaCaso = ReaberturaCaso.getReaberturaCasoByResultSet(resultSet);
				reaberturaCaso.setCaso(Caso.getCasoByResultSet(resultSet));
			}
			
			return reaberturaCaso;
		} catch (Exception e) {
			throw new DataException("Erro ao buscar ReaberturaCaso pelo id.", e);
		} finally {
			close(resultSet);
		}
	}

}
