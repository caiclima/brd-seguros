package br.com.callink.cad.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.persistence.Query;

import br.com.callink.cad.dao.IRelatorioCasosFechadosDAO;
import br.com.callink.cad.pojo.RelatorioCasosFechados;
import br.com.callink.cad.pojo.Util.DateUtil;
import br.com.callink.cad.sau.exception.DataException;

public class RelatorioCasosFechadosDAO extends GenericCadDAO<RelatorioCasosFechados> implements IRelatorioCasosFechadosDAO {

	
	private static final long serialVersionUID = 8188334399518928481L;

	public RelatorioCasosFechadosDAO() {
		super(RelatorioCasosFechados.class);
	}

	@Override
	public List<RelatorioCasosFechados> buscaCasosFechadosDia(Date dataBusca) throws DataException {
		
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		List<RelatorioCasosFechados> casosFechados = null;
		
		try {
			if (dataBusca == null) {
				dataBusca = new Date();
			}
			
			Calendar dataConsulta = new GregorianCalendar();
			dataConsulta.setTime(dataBusca);
			
			Calendar dataInicio = new GregorianCalendar(dataConsulta.get(Calendar.YEAR), dataConsulta.get(Calendar.MONTH), dataConsulta.get(Calendar.DAY_OF_MONTH), Integer.valueOf(0), Integer.valueOf(1));
	        Calendar dataFim = new GregorianCalendar(dataConsulta.get(Calendar.YEAR), dataConsulta.get(Calendar.MONTH), dataConsulta.get(Calendar.DAY_OF_MONTH), Integer.valueOf(23), Integer.valueOf(59));
	
	        
	        StringBuilder sql = new StringBuilder(SELECT)
	        .append(RelatorioCasosFechados.getSqlCamposRelatorioCasosFechados())
	        .append(FROM).append(RelatorioCasosFechados.getSqlFromRelatorioCasosFechados())
	        .append(WHERE).append(" RelatorioCasosFechados.data_cadastro BETWEEN ? AND ? ")
	        .append(" ORDER BY RelatorioCasosFechados.fila_nome , RelatorioCasosFechados.data_fim ");
	        
	        stmt = getPreparedStatement(sql.toString());
	        stmt.setString(1, DateUtil.convertDateStringWithHour(dataInicio.getTime()));
	        stmt.setString(2, DateUtil.convertDateStringWithHour(dataFim.getTime()));
	        stmt.execute();
	        
	        resultSet = stmt.getResultSet();
	        casosFechados = new ArrayList<RelatorioCasosFechados>();
	        
	        while (resultSet.next()) {
	        	RelatorioCasosFechados relatorioCasosFechados = RelatorioCasosFechados.getRelatorioCasosFechadosByResultSet(resultSet);
	        	casosFechados.add(relatorioCasosFechados);
			}
	        
			return casosFechados;
		} catch (Exception e) {
			throw new DataException("Erro ao buscar os casos fechados no dia atual",e);
		}finally{
			close(resultSet);
		}
	}

	@Override
	public List<RelatorioCasosFechados> buscaCasosFechadosDia()	throws DataException {
		
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		List<RelatorioCasosFechados> casosFechados = null;
	
		try {
			
			Calendar dataInicio = new GregorianCalendar(Calendar.getInstance().get(Calendar.YEAR), Calendar.getInstance().get(Calendar.MONTH), Calendar.getInstance().get(Calendar.DAY_OF_MONTH), Integer.valueOf(0), Integer.valueOf(1));
	        Calendar dataFim = new GregorianCalendar(Calendar.getInstance().get(Calendar.YEAR), Calendar.getInstance().get(Calendar.MONTH), Calendar.getInstance().get(Calendar.DAY_OF_MONTH), Integer.valueOf(23), Integer.valueOf(59));
			
			 StringBuilder sql = new StringBuilder(SELECT)
		        .append(RelatorioCasosFechados.getSqlCamposRelatorioCasosFechados())
		        .append(FROM).append(RelatorioCasosFechados.getSqlFromRelatorioCasosFechados())
		        .append(WHERE).append(" RelatorioCasosFechados.data_cadastro BETWEEN ? AND ? ")
		        .append(" ORDER BY RelatorioCasosFechados.fila_nome , RelatorioCasosFechados.data_fim ");
			
	        stmt = getPreparedStatement(sql.toString());
	        stmt.setString(1, DateUtil.convertDateStringWithHour(dataInicio.getTime()));
	        stmt.setString(2, DateUtil.convertDateStringWithHour(dataFim.getTime()));
	        stmt.execute();
	        
	        resultSet = stmt.getResultSet();
	        casosFechados = new ArrayList<RelatorioCasosFechados>();
	        
	        while (resultSet.next()) {
	        	RelatorioCasosFechados relatorioCasosFechados = RelatorioCasosFechados.getRelatorioCasosFechadosByResultSet(resultSet);
	        	casosFechados.add(relatorioCasosFechados);
			} 
	        
	       return casosFechados;
		} catch (Exception e) {
			throw new DataException("Erro ao buscar os casos fechados no dia atual",e);
		}finally{
			close(resultSet);
		}
	}

	@Override
	public void limpaDiaAtual(Date dataAtual) throws DataException {
		try {
			
			Calendar dataConsulta = new GregorianCalendar();
			dataConsulta.setTime(dataAtual);
			
			Calendar calendarIni = new GregorianCalendar(dataConsulta.get(Calendar.YEAR),dataConsulta.get(Calendar.MONTH),dataConsulta.get(Calendar.DAY_OF_MONTH), Integer.valueOf(0), Integer.valueOf(0));
			Calendar calendarFim = new GregorianCalendar(dataConsulta.get(Calendar.YEAR),dataConsulta.get(Calendar.MONTH),dataConsulta.get(Calendar.DAY_OF_MONTH), Integer.valueOf(23), Integer.valueOf(59));
			
			Query query = getEntityManager().createNativeQuery(" delete from tb_relatorio_casos_fechados where data_cadastro > :dtInicial and data_cadastro < :dtFinal ");
	        query.setParameter("dtInicial", calendarIni.getTime());
	        query.setParameter("dtFinal",calendarFim.getTime());
	        query.executeUpdate();
			 
		} catch (Exception e) {
			throw new DataException("Erro ao deletar RelatorioCasosFechados dia atual",e);
		}
	}
	
	@Override
	public RelatorioCasosFechados findByPk(Object id)throws DataException{
		
		ResultSet resultSet = null;
		PreparedStatement stmt = null;
		
		try {
			
			StringBuilder string = new StringBuilder(SELECT)
			  .append(RelatorioCasosFechados.getSqlCamposRelatorioCasosFechados())
			  .append(FROM).append(RelatorioCasosFechados.getSqlFromRelatorioCasosFechados())
			  .append(WHERE).append(" RelatorioCasosFechados.id_relatorio_casos_fechados = ? ");
			
			RelatorioCasosFechados rel = (RelatorioCasosFechados) id;
			stmt = getPreparedStatement(string.toString());
			stmt.setInt(1,rel.getIdRelatoriosCasosFechados());
			stmt.execute();
			
			resultSet = stmt.getResultSet();

			while (resultSet.next()) {
				rel = RelatorioCasosFechados.getRelatorioCasosFechadosByResultSet(resultSet);
			}
			return rel;
		} catch (Exception e) {
			throw new DataException("Erro ao buscar RelatorioCasosFechados pelo id.", e);
		} finally {
			close(resultSet);
		}
	}


}
