package br.com.callink.cad.dao.impl;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import br.com.callink.cad.dao.IRelatorioTempoGeralDAO;
import br.com.callink.cad.pojo.RelatorioTempoGeral;
import br.com.callink.cad.sau.exception.DataException;

public class RelatorioTempoGeralDAO extends GenericCadDAO<RelatorioTempoGeral> implements IRelatorioTempoGeralDAO {

	
	private static final long serialVersionUID = 8188334399518928481L;

	public RelatorioTempoGeralDAO() {
		super(RelatorioTempoGeral.class);
	}

	@Override
	public void geraRelatorioTempoGeral(Date dataIncial) throws DataException {
		
		CallableStatement cs = null;
		try {
			if (dataIncial == null) {
				
				throw new DataException("Obrigatorio informar a data inicial");
			}

			StringBuilder sql = new StringBuilder();
	        sql.append(" exec PROC_RELATORIO_TEMPO_GERAL @data_geracao = ").append("'"+new java.sql.Timestamp(dataIncial.getTime()).toString()+"' ");
	        
	        cs = getConnection().prepareCall(sql.toString());
	        cs.execute();
	        
		} catch (Exception e) {
			throw new DataException("Erro ao buscar os casos fechados no dia atual",e);
		} finally {
			try {
				if(cs != null) {
					cs.close();
				}
				close(null);
			} catch (Exception e) {
				throw new DataException(e);
			}
		}
	}


	@Override
	public void limpaDiaAtual(Date dataAtual) throws DataException {
		try {
						 
		} catch (Exception e) {
			throw new DataException("Erro ao deletar RelatorioCasosFechados dia atual",e);
		}
	}
	
	public Date findUltimaHoraRelatorioTempoGeral() throws DataException {
		ResultSet resultSet = null;
		PreparedStatement stmt = null;
		
		try {
			
			StringBuilder string = new StringBuilder(SELECT)
			  .append(" max(RelatorioTempoGeral.data) as maxDate ")
			  .append(FROM).append(RelatorioTempoGeral.getSqlFromRelatorioTempoGeral());
			
			stmt = getPreparedStatement(string.toString());
			stmt.execute();
			
			resultSet = stmt.getResultSet();

			while (resultSet.next()) {
				return resultSet.getDate("maxDate");
			}
			return null;
		} catch (Exception e) {
			throw new DataException("Erro ao buscar RelatorioCasosFechados pelo id.", e);
		} finally {
			close(resultSet);
		}
	}
	
	@Override
	public List<RelatorioTempoGeral> findListRelatorioTempoGeral(int mes, int ano, int idEquipe) throws DataException {
		ResultSet resultSet = null;
		PreparedStatement stmt = null;
		
		List<RelatorioTempoGeral> listRelatorioTempoGeral = new ArrayList<RelatorioTempoGeral>();
		try {
			
			StringBuilder string = new StringBuilder(SELECT)
			  .append(RelatorioTempoGeral.getSqlCamposRelatorioTempoGeral())
			  .append(FROM).append(RelatorioTempoGeral.getSqlFromRelatorioTempoGeral())
				.append(WHERE_1_1)
				.append(" AND ")
				.append(" RelatorioTempoGeral.id_equipe = ? " )
				.append(" AND ")
				.append(" month(RelatorioTempoGeral.data) = ? ")
				.append(" AND ")
				.append(" year(RelatorioTempoGeral.data) = ? ");
			
			stmt = getPreparedStatement(string.toString());
			stmt.setInt(1, idEquipe);
			stmt.setInt(2, mes);
			stmt.setInt(3, ano);
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			while (resultSet.next()) {
				RelatorioTempoGeral relatorioTempoGeral = RelatorioTempoGeral.getRelatorioTempoGeralByResultSet(resultSet);
				listRelatorioTempoGeral.add(relatorioTempoGeral);
			}
			
			return listRelatorioTempoGeral;
		} catch (Exception e) {
			throw new DataException("Erro ao buscar RelatorioCasosFechados pelo id.", e);
		} finally {
			close(resultSet);
		}
	}
	
	@Override
	public RelatorioTempoGeral findByPk(Object id)throws DataException{
		
		ResultSet resultSet = null;
		PreparedStatement stmt = null;
		
		try {
			
			StringBuilder string = new StringBuilder(SELECT)
			  .append(RelatorioTempoGeral.getSqlCamposRelatorioTempoGeral())
			  .append(FROM).append(RelatorioTempoGeral.getSqlFromRelatorioTempoGeral())
			  .append(WHERE).append(" RelatorioCasosFechados.id_relatorio_casos_fechados = ? ");
			
			RelatorioTempoGeral rel = (RelatorioTempoGeral) id;
			stmt = getPreparedStatement(string.toString());
			stmt.setInt(1,rel.getIdRelatorioTempoGeral());
			stmt.execute();
			
			resultSet = stmt.getResultSet();

			while (resultSet.next()) {
				rel = RelatorioTempoGeral.getRelatorioTempoGeralByResultSet(resultSet);
			}
			return rel;
		} catch (Exception e) {
			throw new DataException("Erro ao buscar RelatorioCasosFechados pelo id.", e);
		} finally {
			close(resultSet);
		}
	}


}

