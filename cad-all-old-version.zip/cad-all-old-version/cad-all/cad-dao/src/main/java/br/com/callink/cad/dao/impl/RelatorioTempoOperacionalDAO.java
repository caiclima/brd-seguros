/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;

import br.com.callink.cad.dao.IRelatorioTempoOperacionalDAO;
import br.com.callink.cad.pojo.RelatorioTempoOperacional;
import br.com.callink.cad.pojo.Util.DateUtil;
import br.com.callink.cad.sau.exception.DataException;

/**
 *
 * @author brunomt
 */
public class RelatorioTempoOperacionalDAO extends GenericCadDAO<RelatorioTempoOperacional> implements IRelatorioTempoOperacionalDAO{

	private static final long serialVersionUID = -274068543292929759L;

	public RelatorioTempoOperacionalDAO() {
		super(RelatorioTempoOperacional.class);
	}

	@Override
    public List<RelatorioTempoOperacional> retornaLoginsUsuariosSSO(Date data1, Date data2, 
    		Integer idSupervisor, String linkedServerName) throws DataException {
		
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
        String dbSSOName = linkedServerName != null ? linkedServerName : "db_callink_sso.";
        
		try {
            StringBuilder string = new StringBuilder();
            string.append(" select us.login_usuario, lo.data_login, lo.data_logout, at.nome ");
            string.append(" from ").append(dbSSOName).append(".tb_sso_controle_login lo,   ");
            string.append(dbSSOName).append(".tb_sso_usuario us , ");
            string.append(" tb_atendente at with(nolock) ");
            string.append(" where ");
            string.append(" lo.data_login between ? and ? ");
            string.append(" and lo.id_usuario = us.id_usuario ");
            string.append(" and us.login_usuario collate SQL_Latin1_General_CP1_CI_AS = at.login ");
            string.append(" and at.id_perfil <> ? ");

            stmt = getPreparedStatement(string.toString());
            stmt.setString(1,DateUtil.convertDateStringWithHour(data1));
            stmt.setString(2,DateUtil.convertDateStringWithHour(data2));
            stmt.setInt(3, idSupervisor);
            stmt.execute();
            
            resultSet = stmt.getResultSet();

            List<RelatorioTempoOperacional> relatorioTempoOperacional = null;
            if (resultSet != null) {
                    relatorioTempoOperacional = retornaTempoOperacionalQuery(resultSet);
                    resultSet.close();
            }
            return relatorioTempoOperacional;
        } catch (Exception ex) {
            throw  new DataException("Erro ao buscar os tempos operacionais no SSO",ex);
        } finally {
            close(resultSet);
        }
    }
	
    private List<RelatorioTempoOperacional> retornaTempoOperacionalQuery(ResultSet resultSet) throws DataException {
        try {
            List<RelatorioTempoOperacional> relatorioTempoOperacionalList = null;
            if (resultSet != null) {
                relatorioTempoOperacionalList = new ArrayList<RelatorioTempoOperacional>();
                while (resultSet.next()) {
                    RelatorioTempoOperacional relatorioTempoOperacional = new RelatorioTempoOperacional();
                    relatorioTempoOperacional.setDataInicio(resultSet.getTimestamp("data_login"));
                    relatorioTempoOperacional.setDataFim(resultSet.getTimestamp("data_logout"));
                    relatorioTempoOperacional.setLogin(resultSet.getString("login_usuario"));
                    relatorioTempoOperacional.setNomeAtendente(resultSet.getString("nome"));
                    relatorioTempoOperacional.setStatusAtendente("LOGIN");
                    relatorioTempoOperacionalList.add(relatorioTempoOperacional);
                }
            }
            return relatorioTempoOperacionalList;
        } catch (Exception e) {
            throw new DataException("Erro ao montar o resultSet ", e);
        }
    }

    @Override
    public void limpaRelatorioAnterior() throws DataException {
        try {
        	
        	Query query = getEntityManager().createNativeQuery("DELETE FROM tb_relatorio_tempos_operacionais");
        	query.executeUpdate();
        	
        } catch (Exception ex) {
            throw new DataException("Erro ao limpar tabela de relatorio.", ex);
        }
    }
    
    @Override
	public RelatorioTempoOperacional findByPk(Object id)throws DataException{
		
		ResultSet resultSet = null;
		PreparedStatement stmt = null;
		
		try {
			
			StringBuilder string = new StringBuilder(SELECT)
			  .append(RelatorioTempoOperacional.getSqlCamposRelatorioTempoOperacional())	
			  .append(FROM).append(RelatorioTempoOperacional.getSqlFromRelatorioTempoOperacional())
			  .append(WHERE).append(" RelatorioTemposOperacionais.id_relatorio_tempos_operacionais = ? ");
			
			RelatorioTempoOperacional relatorioTempoOperacional = (RelatorioTempoOperacional) id;
			stmt = getPreparedStatement(string.toString());
			stmt.setInt(1,relatorioTempoOperacional.getIdRelatorioTemposOperacionais());
			stmt.execute();
			
			resultSet = stmt.getResultSet();

			while (resultSet.next()) {
				relatorioTempoOperacional = RelatorioTempoOperacional.getRelatorioTempoOperacionalByResultSet(resultSet);
			}
			return relatorioTempoOperacional;
		} catch (Exception e) {
			throw new DataException("Erro ao buscar RelatorioTempoOperacional pelo id.", e);
		} finally {
			close(resultSet);
		}
	}
    
}
