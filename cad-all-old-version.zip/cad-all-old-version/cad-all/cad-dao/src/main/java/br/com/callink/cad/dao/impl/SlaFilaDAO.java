/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.com.callink.cad.dao.ISlaFilaDAO;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.pojo.SlaFila;
import br.com.callink.cad.sau.exception.DataException;

/**
 *
 * @author swb.miller
 */
public class SlaFilaDAO extends GenericCadDAO<SlaFila> implements ISlaFilaDAO {

	private static final long serialVersionUID = 6765699136732179061L;

	public SlaFilaDAO() {
		super(SlaFila.class);
	}

	@Override
    public List<SlaFila> findSlaFilaByConfFila(ConfiguracaoFila fila) throws DataException {
         
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		List<SlaFila> slaFilas = null;
		
		try {
        	 
        	 StringBuilder sql = new StringBuilder(SELECT);
        	 sql.append(SlaFila.getSqlCamposSlaFila())
        	 .append(",")
        	 .append(ConfiguracaoFila.getSqlCamposConfiguracaoFila())
        	 .append(FROM).append(SlaFila.getSqlFromSlaFila())
        	 .append(INNER_JOIN).append(ConfiguracaoFila.getSqlFromConfiguracaoFila())
        	 .append(" ON (SlaFila.ID_CONFIGURACAO_FILA = ConfiguracaoFila.ID_CONFIGURACAO_FILA) ")
        	 .append(WHERE).append(" SlaFila.ID_CONFIGURACAO_FILA = ? ")
        	 .append(" ORDER BY SlaFila.ID_SLA_FILA DESC " );
        	 
        	 stmt = getPreparedStatement(sql.toString());
        	 stmt.setInt(1, fila.getIdConfiguracaoFila());
        	 stmt.execute();
        	 
        	 resultSet = stmt.getResultSet();
        	 slaFilas = new ArrayList<SlaFila>();
        	 
        	 while (resultSet.next()) {
				
        		 SlaFila slaFila = SlaFila.getSlaFilaByResultSet(resultSet);
        		 slaFila.setConfiguracaoFila(ConfiguracaoFila.getConfiguracaoFilaByResultSet(resultSet));
        		 slaFilas.add(slaFila);
			}
        	 
            return slaFilas;
        } catch (Exception e) {
            throw new DataException("Erro ao buscar fila pelo " , e);
        }finally{
        	close(resultSet);
        }
    }

    @Override
    public List<SlaFila> findAllSlafila() throws DataException {
        
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
		List<SlaFila> slaFilas = null;
    	
    	try {
        	
    		 StringBuilder sql = new StringBuilder(SELECT);
        	 sql.append(SlaFila.getSqlCamposSlaFila())
        	 .append(",")
        	 .append(ConfiguracaoFila.getSqlCamposConfiguracaoFila())
        	 .append(FROM).append(SlaFila.getSqlFromSlaFila())
        	 .append(INNER_JOIN).append(ConfiguracaoFila.getSqlFromConfiguracaoFila())
        	 .append(" ON (SlaFila.ID_CONFIGURACAO_FILA = ConfiguracaoFila.ID_CONFIGURACAO_FILA) ")
        	 .append(WHERE).append("SlaFila.DATA_FIM IS NULL ");
        	
        	stmt = getPreparedStatement(sql.toString());
        	stmt.execute();
        	 
        	resultSet = stmt.getResultSet();
        	slaFilas = new ArrayList<SlaFila>();
        	 
            while (resultSet.next()) {
				
        		 SlaFila slaFila = SlaFila.getSlaFilaByResultSet(resultSet);
        		 slaFila.setConfiguracaoFila(ConfiguracaoFila.getConfiguracaoFilaByResultSet(resultSet));
        		 slaFilas.add(slaFila);
			}
        	 
            return slaFilas;
        
    	} catch (Exception e) {
            throw new DataException(e);
        }finally{
        	close(resultSet);
        }
    }
    
    @Override
    public List<SlaFila> findSlaFilaByConfFilaAndDataFimNull(ConfiguracaoFila fila) throws DataException {
        
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
		List<SlaFila> slaFilas = null;
    	
    	try {
    		
    		 StringBuilder sql = new StringBuilder(SELECT)
        	 .append(SlaFila.getSqlCamposSlaFila())
        	 .append(FROM).append(SlaFila.getSqlFromSlaFila())
        	 .append(WHERE).append("SlaFila.DATA_FIM IS NULL ")
        	 .append(" AND SlaFila.ID_CONFIGURACAO_FILA = ? ");
    		
    		 stmt = getPreparedStatement(sql.toString());
    		 stmt.setInt(1, fila.getIdConfiguracaoFila());
    		 stmt.execute();
    		 
    		 resultSet = stmt.getResultSet();
         	 slaFilas = new ArrayList<SlaFila>();
         	 
             while (resultSet.next()) {
         		 SlaFila slaFila = SlaFila.getSlaFilaByResultSet(resultSet);
         		 slaFilas.add(slaFila);
 			}

            return slaFilas;
        } catch (Exception e) {
            throw new DataException("Erro ao buscar sla por configuracao e com data final vazia " , e);
        } finally {
			close(resultSet);
		}
    }
    
    @Override
	public List<SlaFila> findSlaFilaList(ConfiguracaoFila configFila, Integer sla, String descricao) throws DataException{
    	
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
		List<SlaFila> slaFilas = null;
		int index = 0;
    	
    	try {
    		
    		 StringBuilder sql = new StringBuilder(SELECT)
        	 .append(SlaFila.getSqlCamposSlaFila())
        	 .append(",")
        	 .append(ConfiguracaoFila.getSqlCamposConfiguracaoFila())
        	 .append(FROM).append(SlaFila.getSqlFromSlaFila())
        	 .append(INNER_JOIN).append(ConfiguracaoFila.getSqlFromConfiguracaoFila())
        	 .append(" ON (SlaFila.ID_CONFIGURACAO_FILA = ConfiguracaoFila.ID_CONFIGURACAO_FILA) ")
        	 .append(WHERE).append("SlaFila.DATA_FIM IS NULL ");
            
            if(configFila != null && configFila.getIdConfiguracaoFila() != null) {
            	sql.append(" AND SlaFila.ID_CONFIGURACAO_FILA = ? ");
            }
            
            if(sla != null) {
            	sql.append(" AND SlaFila.SLA like ? ");
            }
            
            if(descricao != null && !"".equals(descricao)) {
            	sql.append(" AND SlaFila.DESCRICAO like ? ");
            }
            
            stmt = getPreparedStatement(sql.toString());
            
            if(configFila != null && configFila.getIdConfiguracaoFila() != null) {
            	stmt.setInt(++index, configFila.getIdConfiguracaoFila());
            }
            
            if(sla != null) {
            	stmt.setString(++index, new StringBuilder("%").append(sla).append("%").toString());
            }
            
            if(descricao != null && !"".equals(descricao)) {
            	stmt.setString(++index, new StringBuilder("%").append(descricao).append("%").toString());
            }
            
	   		stmt.execute();
   		 
	   		resultSet = stmt.getResultSet();
        	slaFilas = new ArrayList<SlaFila>();
        	 
            while (resultSet.next()) {
        		 SlaFila slaFila = SlaFila.getSlaFilaByResultSet(resultSet);
        		 slaFila.setConfiguracaoFila(ConfiguracaoFila.getConfiguracaoFilaByResultSet(resultSet));
        		 slaFilas.add(slaFila);
			}

            return slaFilas;
        } catch (Exception e) {
            throw new DataException(e);
        } finally {
			close(resultSet);
		}
    }
    
    @Override
	public SlaFila findByPk(Object id)throws DataException{
		
		ResultSet resultSet = null;
		PreparedStatement stmt = null;
		
		try {
			
			StringBuilder string = new StringBuilder(SELECT)
			  .append(SlaFila.getSqlCamposSlaFila())
			  .append(",").append(ConfiguracaoFila.getSqlCamposConfiguracaoFila())
			  .append(FROM).append(SlaFila.getSqlFromSlaFila())
			  .append(INNER_JOIN).append(ConfiguracaoFila.getSqlFromConfiguracaoFila())
			  .append(" ON (SlaFila.ID_CONFIGURACAO_FILA = ConfiguracaoFila.ID_CONFIGURACAO_FILA)")
			  .append(WHERE).append(" SlaFila.ID_SLA_FILA = ? ");
			
			SlaFila slaFila = (SlaFila) id;
			stmt = getPreparedStatement(string.toString());
			stmt.setInt(1, slaFila.getIdSlaFila());
			stmt.execute();
			
			resultSet = stmt.getResultSet();

			while (resultSet.next()) {
				slaFila = SlaFila.getSlaFilaByResultSet(resultSet);
				slaFila.setConfiguracaoFila(ConfiguracaoFila.getConfiguracaoFilaByResultSet(resultSet));
			}
			return slaFila;
		} catch (Exception e) {
			throw new DataException("Erro ao buscar SlaFila pelo id.", e);
		} finally {
			close(resultSet);
		}
	}
    
    @Override
    public List<SlaFila> findAll() throws DataException {
         
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		List<SlaFila> slaFilas = null;
		
		try {
        	 
        	 StringBuilder sql = new StringBuilder(SELECT);
        	 sql.append(SlaFila.getSqlCamposSlaFila())
        	 .append(FROM).append(SlaFila.getSqlFromSlaFila());
        	 
        	 stmt = getPreparedStatement(sql.toString());
        	 stmt.execute();
        	 resultSet = stmt.getResultSet();
        	 slaFilas = new ArrayList<SlaFila>();
        	 
        	 while (resultSet.next()) {
        		 SlaFila slaFila = SlaFila.getSlaFilaByResultSet(resultSet);
        		 slaFilas.add(slaFila);
			}
        	 
            return slaFilas;
        } catch (Exception e) {
            throw new DataException("Erro ao buscar todas as SlaFila" , e);
        }finally{
        	close(resultSet);
        }
    }
    
}
