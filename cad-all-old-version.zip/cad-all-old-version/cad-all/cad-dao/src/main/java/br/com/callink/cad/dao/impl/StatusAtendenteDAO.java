package br.com.callink.cad.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.persistence.Query;

import br.com.callink.cad.dao.IStatusAtendenteDAO;
import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.AtendenteStatus;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.pojo.Equipe;
import br.com.callink.cad.pojo.StatusAtendente;
import br.com.callink.cad.pojo.Util.DateUtil;
import br.com.callink.cad.sau.exception.DataException;

/**
 *
 * @author brunomt
 */
public class StatusAtendenteDAO extends GenericCadDAO<StatusAtendente> implements IStatusAtendenteDAO {

	private static final long serialVersionUID = 7729677777419366446L;

	public StatusAtendenteDAO() {
		super(StatusAtendente.class);
	}

	@Override
    public Integer buscaUltimoStatusAtendente(Atendente atendente) throws DataException {
        
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		
		try {
		
			StringBuilder string = new StringBuilder(" select max(id_status_atendente) marcacao from tb_status_atendente with(nolock) where id_atendente =  ? ");
			
			stmt = getPreparedStatement(string.toString());
			stmt.setInt(1, atendente.getIdAtendente());
			stmt.execute();
			resultSet =  stmt.getResultSet();
        
		    if (resultSet.next()) {
		        return resultSet.getInt("marcacao");
		    }
		
		}catch (Exception ex) {
            throw new DataException(ex);
        }finally{
        	close(resultSet);
        }
		
		return null;
    }

    @Override
    public List<StatusAtendente> buscaTodosStatusAtendenteEntreDatas(Date dataInicio, Date dataFim) throws DataException {
        
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
		
        try {
            
        	StringBuilder builder = new StringBuilder(SELECT)
        	   .append(StatusAtendente.getSqlCamposStatusAtendente())
        	   .append(",").append(AtendenteStatus.getSqlCamposAtendenteStatus())
        	   .append(",").append(Atendente.getSqlCamposAtendente())
        	   .append(FROM).append(StatusAtendente.getSqlFromStatusAtendente())
        	   .append(INNER_JOIN).append(Atendente.getSqlFromAtendente())
        	   .append(" ON (StatusAtendente.ID_ATENDENTE = Atendente.ID_ATENDENTE ) ")
        	   .append(INNER_JOIN).append(AtendenteStatus.getSqlFromAtendenteStatus())
        	   .append(" ON (StatusAtendente.ID_ATENDENTE_STATUS = AtendenteStatus.ID_ATENDENTE_STATUS ) ")
        	   .append(WHERE)
        	   .append(" StatusAtendente.DATA_INICIO BETWEEN ? AND ? ");
        	
        	stmt = getPreparedStatement(builder.toString());
        	stmt.setString(1, DateUtil.convertDateStringWithHour(DateUtil.dataInicioDia(dataInicio)));
        	stmt.setString(2, DateUtil.convertDateStringWithHour(DateUtil.dataFimDia(dataFim)));
        	stmt.execute();
        	resultSet = stmt.getResultSet();
        	
        	List<StatusAtendente> statusAtendenteList = new ArrayList<StatusAtendente>();
        	
        	while (resultSet.next()){
        		
        		StatusAtendente statusAtendente = StatusAtendente.getStatusAtendenteByResultSet(resultSet);
        		statusAtendente.setIdAtendente(Atendente.getAtendenteByResultSet(resultSet));
        		statusAtendente.setIdAtendenteStatus(AtendenteStatus.getAtendenteStatusByResultSet(resultSet));
        		
        		statusAtendenteList.add(statusAtendente);
        	}
            
            return statusAtendenteList;
        } catch (Exception ex) {
            throw new DataException("Erro ao buscar todos os status do atendente.",ex);
        } finally {
            close(resultSet);
        }
            
    }

    
    @Override
	public List<StatusAtendente> buscaStatusAtendenteByUserEquipe(ConfiguracaoFila fila, Equipe equipe, Atendente atendente, 
    		Date dataInicial, Date dataFinal) throws DataException {
    	
    	//TODO - Consulta coreUtils nao usava equipe. Como ta no parametro foi adicionado. 
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
		List<StatusAtendente> statusAtendentes = null;
		int index = 0;
    	
    	try {

    		StringBuilder sql = new StringBuilder(SELECT);
    		sql.append(StatusAtendente.getSqlCamposStatusAtendente())
    		.append(FROM).append(StatusAtendente.getSqlFromStatusAtendente())
    		.append(WHERE).append(" StatusAtendente.DATA_INICIO BETWEEN ").append(" ? ").append(" AND ").append(" ? ");
    		
    		if(fila != null && fila.getIdConfiguracaoFila()!= null){
    			sql.append(" AND StatusAtendente.ID_CONFIGURACAO_FILA = ? ");
    		}
    		if(equipe != null && equipe.getIdEquipe()!= null){
    			sql.append(" AND StatusAtendente.ID_EQUIPE = ? ");
    		}
    		if(atendente!= null && atendente.getIdAtendente()!= null){
    			sql.append(" AND StatusAtendente.ID_ATENDENTE = ? ");
    		}
    		
    		stmt = getPreparedStatement(sql.toString());
    		
    		stmt.setString(++index, DateUtil.convertDateStringWithHour(dataInicial));
        	stmt.setString(++index, DateUtil.convertDateStringWithHour(dataFinal));
        	
        	if(fila != null && fila.getIdConfiguracaoFila()!= null){
    			stmt.setInt(++index, fila.getIdConfiguracaoFila());
    		}
    		if(equipe != null && equipe.getIdEquipe()!= null){
    			stmt.setInt(++index, equipe.getIdEquipe());
    		}
    		if(atendente!= null && atendente.getIdAtendente()!= null){
    			stmt.setInt(++index, atendente.getIdAtendente());
    		}
        	
        	stmt.execute();
     	    resultSet =  stmt.getResultSet();
     	    statusAtendentes = new ArrayList<StatusAtendente>();
     	    
     	    while (resultSet.next()) {
     	    	StatusAtendente status = StatusAtendente.getStatusAtendenteByResultSet(resultSet);
     	    	statusAtendentes.add(status);
			}
     	    
     	    return statusAtendentes;
     	    
    	} catch (Exception e) {
			throw new DataException("Erro ao buscar Status do atendente", e);
		}finally {
            close(resultSet);
        }
    }
    
    @Override
    public void finalizaStatusAtendenteSemDataFim() throws DataException {
    	
        Calendar calendar = new GregorianCalendar();
    	calendar.add(Calendar.HOUR_OF_DAY, -9);

    	Query query = getEntityManager().createNativeQuery(" update tb_status_atendente set data_fim = data_inicio where data_fim is null and data_inicio < :data ");
        query.setParameter("data", calendar.getTime());
        query.executeUpdate();
        
    }
    
    @Override
    public List<StatusAtendente> buscaStatusAtendenteByStatus(AtendenteStatus atendenteStatus, Integer tempoSegundos) throws DataException {
    	    	
        Calendar calendar = new GregorianCalendar();
    	calendar.add(Calendar.SECOND, -tempoSegundos);
    	SimpleDateFormat sf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
    	sf.format(calendar.getTime());
    	
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
		List<StatusAtendente> statusAtendentes = null;
		
		try {
		
			StringBuilder sql = new StringBuilder(SELECT);
			sql.append(StatusAtendente.getSqlCamposStatusAtendente())
			.append(FROM).append(StatusAtendente.getSqlFromStatusAtendente())
			.append(WHERE).append(" StatusAtendente.ID_ATENDENTE_STATUS = ? ")
			.append(" AND StatusAtendente.DATA_FIM IS NULL ")
			.append(" AND StatusAtendente.DATA_INICIO <= ? " );
			
			stmt = getPreparedStatement(sql.toString());
			stmt.setInt(1, atendenteStatus.getIdAtendenteStatus() );
			stmt.setString(2, DateUtil.convertDateStringWithHour(calendar.getTime()));
			stmt.execute();
			resultSet = stmt.getResultSet();
		 
			statusAtendentes = new ArrayList<StatusAtendente>();
	     	    
     	    while (resultSet.next()) {
     	    	StatusAtendente status = StatusAtendente.getStatusAtendenteByResultSet(resultSet);
     	    	statusAtendentes.add(status);
			}
    	
     	    return statusAtendentes;
    	} catch (Exception e) {
			throw new DataException("Não foi possível buscar os status dos atendentes",e);
		} finally {
            close(resultSet);
        }
    }
    	
    @Override
	public List<StatusAtendente> buscaStatusAtendenteByAtendente(Atendente atendente, Date dataInicial, 
			Date dataFinal) throws DataException {
    	
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
		List<StatusAtendente> statusAtendentes = null;
    	
    	try {

    		StringBuilder sql = new StringBuilder(SELECT);
			sql.append(StatusAtendente.getSqlCamposStatusAtendente())
			.append(",")
			.append(AtendenteStatus.getSqlCamposAtendenteStatus())
			.append(FROM).append(StatusAtendente.getSqlFromStatusAtendente())
			.append(INNER_JOIN).append(AtendenteStatus.getSqlFromAtendenteStatus())
        	.append(" ON (StatusAtendente.ID_ATENDENTE_STATUS = AtendenteStatus.ID_ATENDENTE_STATUS ) ")
			.append(WHERE).append(" StatusAtendente.DATA_INICIO BETWEEN ").append(" ? ").append(" AND ").append(" ? ")
			.append(" AND StatusAtendente.ID_ATENDENTE = ? ")
			.append(" ORDER BY StatusAtendente.ID_ATENDENTE_STATUS ASC ");
    		
			stmt = getPreparedStatement(sql.toString());
			
			stmt.setString(1, DateUtil.convertDateStringWithHour(dataInicial));
			stmt.setString(2, DateUtil.convertDateStringWithHour(dataFinal));
			stmt.setInt(3, atendente.getIdAtendente());
			stmt.execute();
			
			resultSet = stmt.getResultSet();
			statusAtendentes = new ArrayList<StatusAtendente>();
			
			while(resultSet.next()){
				StatusAtendente status = StatusAtendente.getStatusAtendenteByResultSet(resultSet);
				status.setIdAtendenteStatus(AtendenteStatus.getAtendenteStatusByResultSet(resultSet));
				
				statusAtendentes.add(status);
			}
			
			return statusAtendentes;
    		
    	} catch (Exception e) {
			throw new DataException("Erro ao buscar Status do atendente", e);
		} finally {
            close(resultSet);
        }
    }
    
    @Override
	public StatusAtendente findByPk(Object id)throws DataException{
		
		ResultSet resultSet = null;
		PreparedStatement stmt = null;
		
		try {
			
			StringBuilder string = new StringBuilder(SELECT)
			  .append(StatusAtendente.getSqlCamposStatusAtendente())
			  .append(",").append(Equipe.getSqlEquipe())
			  .append(",").append(ConfiguracaoFila.getSqlCamposConfiguracaoFila())
			  .append(",").append(Atendente.getSqlCamposAtendente())
			  .append(",").append(Caso.getSqlCamposCaso())
			  .append(",").append(AtendenteStatus.getSqlCamposAtendenteStatus())
			  .append(FROM).append(StatusAtendente.getSqlFromStatusAtendente())
			  .append(INNER_JOIN).append(Equipe.getSqlFromEquipe())
			  .append(" ON (StatusAtendente.ID_EQUIPE=Equipe.ID_EQUIPE)")
			  .append(LEFT_JOIN).append(ConfiguracaoFila.getSqlFromConfiguracaoFila())
			  .append(" ON (StatusAtendente.ID_CONFIGURACAO_FILA=ConfiguracaoFila.ID_CONFIGURACAO_FILA)")
			  .append(INNER_JOIN).append(Atendente.getSqlFromAtendente())
			  .append(" ON (StatusAtendente.ID_ATENDENTE=Atendente.ID_ATENDENTE)")
			  .append(LEFT_JOIN).append(Caso.getSqlFromCaso())
			  .append(" ON (StatusAtendente.ID_CASO=Caso.ID_CASO)")
			  .append(INNER_JOIN).append(AtendenteStatus.getSqlFromAtendenteStatus())
			  .append(" ON (StatusAtendente.ID_ATENDENTE_STATUS=AtendenteStatus.ID_ATENDENTE_STATUS)")
			  .append(WHERE).append(" StatusAtendente.ID_STATUS_ATENDENTE = ? ");
			
			StatusAtendente statusAtendente = (StatusAtendente) id;
			stmt = getPreparedStatement(string.toString());
			stmt.setInt(1, statusAtendente.getIdStatusAtendente());
			stmt.execute();
			
			resultSet = stmt.getResultSet();

			while (resultSet.next()) {
				statusAtendente = StatusAtendente.getStatusAtendenteByResultSet(resultSet);
				statusAtendente.setIdEquipe(Equipe.getEquipeByResultSet(resultSet));
				statusAtendente.setIdConfiguracaoFila(ConfiguracaoFila.getConfiguracaoFilaByResultSet(resultSet));
				statusAtendente.setIdAtendente(Atendente.getAtendenteByResultSet(resultSet));
				statusAtendente.setIdCaso(Caso.getCasoByResultSet(resultSet));
				statusAtendente.setIdAtendenteStatus(AtendenteStatus.getAtendenteStatusByResultSet(resultSet));
			}
			
			return statusAtendente;
		} catch (Exception e) {
			throw new DataException("Erro ao buscar StatusAtendente pelo id.", e);
		} finally {
			close(resultSet);
		}
	}

}
