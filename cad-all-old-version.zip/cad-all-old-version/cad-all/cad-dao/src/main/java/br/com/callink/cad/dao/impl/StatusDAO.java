package br.com.callink.cad.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;

import br.com.callink.cad.dao.IStatusDAO;
import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.pojo.Status;
import br.com.callink.cad.pojo.StatusAcao;
import br.com.callink.cad.pojo.StatusAcaoId;
import br.com.callink.cad.pojo.Util.DateUtil;
import br.com.callink.cad.sau.exception.DataException;

/**
 * 
 * @author brunomt [brunoam@swb.com.br]
 *
 */
public class StatusDAO extends GenericCadDAO<Status> implements IStatusDAO {

	private static final long serialVersionUID = -8235688882501888127L;
	
	public StatusDAO() {
		super(Status.class);
	}

	@Override
    public void associa(StatusAcao statusAcao) throws DataException {
		try {
			Query query = getEntityManager().createNativeQuery("INSERT INTO tb_status_acao (ID_ACAO, ID_STATUS) VALUES (:acao, :status)");
            query.setParameter("acao", statusAcao.getStatusAcaoId().getIdAcao().getIdAcao());
            query.setParameter("status", statusAcao.getStatusAcaoId().getIdStatus().getIdStatus());
            query.executeUpdate();
		} catch (Exception ex) {
			throw new DataException(ex);
		}
    }

    @Override
    public void associa(List<StatusAcao> statusAcao) throws DataException {
        for (StatusAcao associa : statusAcao) {
            associa(associa);
        }
    }

    @Override
    public void excluiAssociacao(StatusAcao statusAcao) throws DataException {
    	
    	Query query = getEntityManager().createNativeQuery("delete from tb_status_acao where id_acao = :idAcao and id_status = :idStatus ");
		query.setParameter("idAcao", statusAcao.getStatusAcaoId().getIdAcao().getIdAcao());
		query.setParameter("idStatus", statusAcao.getStatusAcaoId().getIdStatus().getIdStatus());
    	query.executeUpdate();
    }

    @Override
    public List<StatusAcao> findByStatus(Status status) throws DataException {
        return getStatusAcao(null, status);
    }

    @Override
    public List<StatusAcao> findByAcao(Acao acao) throws DataException {
        return getStatusAcao(acao, null);
    }


	private List<StatusAcao> getStatusAcao(Acao acao, Status status) throws DataException {
        
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		List<StatusAcao> ret = null;
        
		try {
        	
        	StringBuilder sql = new StringBuilder();
        	sql.append(SELECT)
        	.append(Acao.getSqlCamposAcao())
        	.append(",")
        	.append(Status.getSqlCamposStatus())
        	.append(FROM)
        	.append(StatusAcao.getSqlFromStatusAcao())
        	.append(INNER_JOIN).append(Acao.getSqlFromAcao())
        	.append(" ON StatusAcao.ID_ACAO = Acao.ID_ACAO ")
        	.append(INNER_JOIN).append(Status.getSqlFromStatus())
        	.append(" ON StatusAcao.ID_STATUS = Status.ID_STATUS ")
        	.append(WHERE_1_1);
        	
            boolean isAcao = acao != null && acao.getIdAcao() != null;
            boolean isStatus = status != null && status.getIdStatus() != null;
            
            if (isAcao && !isStatus) {
            	sql.append(" AND Acao.ID_ACAO = ? ");
            } else if (!isAcao && isStatus) {
            	sql.append(" AND Status.ID_STATUS = ? ");
            } else if (isAcao && isStatus) {
            	sql.append(" AND Acao.ID_ACAO = ? ");
            	sql.append(" AND Status.ID_STATUS = ? ");
            }
            
            stmt = getPreparedStatement(sql.toString());
            
            if (isAcao && !isStatus) {
            	stmt.setInt(1, acao.getIdAcao());
            } else if (!isAcao && isStatus) {
            	stmt.setInt(1, status.getIdStatus());
            } else if (isAcao && isStatus) {
            	stmt.setInt(1, acao.getIdAcao());
            	stmt.setInt(2, status.getIdStatus());
            }
            
            stmt.execute();
    	    resultSet =  stmt.getResultSet();
    	    ret = new ArrayList<StatusAcao>();
            
    	    while(resultSet.next()){
        	    
    	    	Status status2 = Status.getStatusByResultSet(resultSet); 
    	    	Acao acao2 = Acao.getAcaoByResultSet(resultSet);
    	    	StatusAcao statusAcao = new StatusAcao();
    	    	statusAcao.setStatusAcaoId(new StatusAcaoId(status2, acao2));
    	    	ret.add(statusAcao);
    	    }
    	    
    	    return ret;
    	    
		}catch (SQLException ex) {
            throw new DataException(ex);
        }finally{
        	close(resultSet);
        }
    }

    @Override
    public List<StatusAcao> find(Acao acao, Status status) throws DataException {
        return getStatusAcao(acao, status);
    }

    @Override
    public List<StatusAcao> findAllStatusAcao() throws DataException {
        return getStatusAcao(null, null);
    }
    
    @Override
    public Status findStatusByNomeStatus(String nomeStatus) throws DataException{
    	
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
		
		try {
			
			StringBuilder sql = new StringBuilder();
			sql.append(SELECT).append(Status.getSqlCamposStatus())
				.append(FROM).append(Status.getSqlFromStatus())
				.append(WHERE).append(" Status.NOME = ? ");
			
			stmt = getPreparedStatement(sql.toString());
			stmt.setString(1, nomeStatus);
		    stmt.execute();
		    resultSet =  stmt.getResultSet();
		    
		    while (resultSet.next()) {
				return  Status.getStatusByResultSet(resultSet);
			}
		    return null;
			
		} catch (Exception e) {
			throw new DataException(e);
		}finally{
			close(resultSet);
		}
    }
    
    @Override
	public Status findByPk(Object id)throws DataException{
		
		ResultSet resultSet = null;
		PreparedStatement stmt = null;
		
		try {
			
			StringBuilder string = new StringBuilder(SELECT)
			  .append(Status.getSqlCamposStatus())
			  .append(FROM).append(Status.getSqlFromStatus())
			  .append(WHERE).append(" Status.ID_STATUS = ? ");
			
			Status status = (Status) id;
			
			stmt = getPreparedStatement(string.toString());
			stmt.setInt(1, status.getIdStatus());
			stmt.execute();
			
			resultSet = stmt.getResultSet();

			while (resultSet.next()) {
				status = Status.getStatusByResultSet(resultSet);
			}
			return status;
		} catch (Exception e) {
			throw new DataException("Erro ao buscar Status pelo id.", e);
		} finally {
			close(resultSet);
		}
	}
    
    @Override
	public List<Status> findByExample(Status example) throws DataException {
		return findByExample(example, null);
	}
	
    @Override
	public List<Status> findByExample(Status example, String order) throws DataException {
		List<Status> listStatus = new ArrayList<Status>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		int index = 0;
		
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Status.getSqlCamposStatus())
				.append(FROM)
				.append(Status.getSqlFromStatus())
				.append(WHERE_1_1);

			if(example!= null){
			
				if (example.getIdStatus() != null) {
					select.append(" AND Status.ID_STATUS = ? ");
				}
				if (example.getNome() != null && !example.getNome().isEmpty()) {
					select.append(" AND Status.NOME like ? ");
				}
				if (example.getDataCriacao() != null) {
					select.append(" AND Status.DATA_CRIACAO BETWEEN ? AND ? ");
				}
				if (example.getDescricao() != null && !example.getDescricao().isEmpty()) {
					select.append(" AND Status.DESCRICAO = ? ");
				}
				if (example.getFlagAtivo() != null) {
					select.append(" AND Status.FLAG_ATIVO = ? ");
				}
				if (example.getFlagContaSla() != null) {
					select.append(" AND Status.FLAG_CONTA_SLA = ? ");
				}
				if (example.getLoginUsuario() != null && !example.getLoginUsuario().isEmpty()) {
					select.append(" AND Status.LOGIN_USUARIO = ? ");
				}
				if (example.getFlagPausado() != null) {
					select.append(" AND Status.FLAG_PAUSADO = ? ");
				}
			}
			
			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			if(example!= null){
				
				if (example.getIdStatus() != null) {
					stmt.setInt(++index, example.getIdStatus());
				}
				if (example.getNome() != null && !example.getNome().isEmpty()) {
					stmt.setString(++index, new StringBuilder(example.getNome()).append("%").toString());
				}
				if (example.getDataCriacao() != null) {
					Date dataInicio = DateUtil.dataInicioDia(example.getDataCriacao());
					Date dataFim = DateUtil.dataFimDia(example.getDataCriacao());
					stmt.setDate(++index, new java.sql.Date(dataInicio.getTime()));
					stmt.setDate(++index, new java.sql.Date(dataFim.getTime()));
				}
				if (example.getDescricao() != null && !example.getDescricao().isEmpty()) {
					stmt.setString(++index, example.getDescricao());
				}
				if (example.getFlagAtivo() != null) {
					stmt.setBoolean(++index, example.getFlagAtivo());
				}
				if (example.getFlagContaSla() != null) {
					stmt.setBoolean(++index, example.getFlagContaSla());
				}
				if (example.getLoginUsuario() != null && !example.getLoginUsuario().isEmpty()) {
					stmt.setString(++index, example.getLoginUsuario());
				}
				if (example.getFlagPausado() != null) {
					stmt.setBoolean(++index, example.getFlagPausado());
				}
			}
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					Status status = Status.getStatusByResultSet(resultSet);
					listStatus.add(status);
				}
			}
		} catch (SQLException ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return listStatus;
	}
	
	@Override
	public List<Status> findAll() throws DataException {
		return findAll(null);
	}
	
	@Override
	public List<Status> findAll(String order) throws DataException {
		List<Status> listStatus = new ArrayList<Status>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Status.getSqlCamposStatus())
				.append(FROM)
				.append(Status.getSqlFromStatus());

			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					Status status = Status.getStatusByResultSet(resultSet);
					listStatus.add(status);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return listStatus;
	}

	@Override
	public List<Status> findByPkIn(List<Integer> st) throws DataException {
		List<Status> lst = new ArrayList<Status>();
		ResultSet resultSet = null;
		PreparedStatement stmt = null;
		
		try {
			
			StringBuilder string = new StringBuilder(SELECT).append(Status.getSqlCamposStatus()).append(FROM).append(Status.getSqlFromStatus()).append(WHERE)
					.append(String.format(" Status.ID_STATUS in (%s) ", st.toString().substring(1, st.toString().length()-1)));

			stmt = getPreparedStatement(string.toString());
			stmt.execute();
			
			resultSet = stmt.getResultSet();

			Status status;
			while (resultSet.next()) {
				status = Status.getStatusByResultSet(resultSet);
				lst.add(status);
			}
			return lst;
		} catch (Exception e) {
			throw new DataException("Erro ao buscar Status pelo id.", e);
		} finally {
			close(resultSet);
		}
	}
	
	@Override
	public List<Status> findByNomes(List<String> nomes) throws DataException {
		
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		
		try {
			
			StringBuilder sql = new StringBuilder(SELECT)
			.append(Status.getSqlCamposStatus())
			.append(FROM).append(Status.getSqlFromStatus())
			.append(WHERE).append(" Status.flag_ativo = 1")
			.append(" AND Status.nome in ( ");
			
			for (String nome : nomes) {
				sql.append("'" + nome + "'");
				
		        if (!nome.equals(nomes.get(nomes.size()-1))) {
		        	sql.append(",");
		        }
		    }
			
			sql.append(")");
			
			stmt = getPreparedStatement(sql.toString());
			stmt.execute();
			
			resultSet = stmt.getResultSet();
			
			List<Status> ret = new ArrayList<>();
			while(resultSet.next()){
				ret.add(Status.getStatusByResultSet(resultSet));
			}
			return ret;
		} catch (Exception ex) {
			throw new DataException(ex);
		}finally{
			super.close(resultSet);
		}
	}
	
	@Override
	public List<Status> findExcludeByNomes(List<String> nomes) throws DataException {
		
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		
		try {
			
			StringBuilder sql = new StringBuilder(SELECT)
			.append(Status.getSqlCamposStatus())
			.append(FROM).append(Status.getSqlFromStatus())
			.append(WHERE).append(" Status.flag_ativo = 1")
			.append(" AND Status.nome not in ( ");
			
			for (String nome : nomes) {
				sql.append("'" + nome + "'");
				
		        if (!nome.equals(nomes.get(nomes.size()-1))) {
		        	sql.append(",");
		        }
		    }
			
			sql.append(")");
			
			stmt = getPreparedStatement(sql.toString());
			stmt.execute();
			
			resultSet = stmt.getResultSet();
			
			List<Status> ret = new ArrayList<>();
			while(resultSet.next()){
				ret.add(Status.getStatusByResultSet(resultSet));
			}
			return ret;
		} catch (Exception ex) {
			throw new DataException(ex);
		}finally{
			super.close(resultSet);
		}
	}
    
}
