/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import br.com.callink.cad.dao.ITelaGboDAO;
import br.com.callink.cad.pojo.TelaGbo;
import br.com.callink.cad.sau.exception.DataException;

public class TelaGboDAO extends GenericCadDAO<TelaGbo> implements ITelaGboDAO {
	
	private static final long serialVersionUID = 3806990468219543350L;

	public TelaGboDAO() {
		super(TelaGbo.class);
	}

	@Override
	public TelaGbo findByNomeTela(String mnemonico) throws DataException {

		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		
		try {
			
			StringBuilder sql = new StringBuilder();
			sql.append(SELECT).append(TelaGbo.getSqlCamposTelaGbo())
				.append(FROM).append(TelaGbo.getSqlFromTelaGbo())
				.append(WHERE).append(" TelaGbo.NOME_TELA = ? ");
			
			stmt = getPreparedStatement(sql.toString());
			stmt.setString(1, mnemonico);
		    stmt.execute();
		    resultSet =  stmt.getResultSet();
		    
		    while (resultSet.next()) {
				return TelaGbo.getTelaGboByResultSet(resultSet);
			}
		    return null;
			
		} catch (Exception e) {
			throw new DataException(e);
		}finally{
			close(resultSet);
		}
	}
	
	@Override
	public TelaGbo findByPk(Object id)throws DataException{
		
		ResultSet resultSet = null;
		PreparedStatement stmt = null;
		
		try {
			
			StringBuilder string = new StringBuilder(SELECT)
			  .append(TelaGbo.getSqlCamposTelaGbo())
			  .append(FROM).append(TelaGbo.getSqlFromTelaGbo())
			  .append(WHERE).append(" TelaGbo.ID_TELA_GBO = ? ");
			
			TelaGbo tela = (TelaGbo) id;
			stmt = getPreparedStatement(string.toString());
			stmt.setInt(1, tela.getIdTelaGbo());
			stmt.execute();
			
			resultSet = stmt.getResultSet();

			while (resultSet.next()) {
				tela = TelaGbo.getTelaGboByResultSet(resultSet);
			}
			return tela;
		} catch (Exception e) {
			throw new DataException("Erro ao buscar TelaGbo pelo id.", e);
		} finally {
			close(resultSet);
		}
	}
	

}
