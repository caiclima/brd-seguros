/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import br.com.callink.cad.dao.ITelefoneDAO;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.ContatoTelefone;
import br.com.callink.cad.pojo.LogLigacoes;
import br.com.callink.cad.pojo.Telefone;
import br.com.callink.cad.sau.exception.DataException;

/**
 *
 * @author Rogério Moreira de Andrade. [rogeriom@swb.com.br]
 */
public class TelefoneDAO extends GenericCadDAO<Telefone> implements ITelefoneDAO{

	private static final long serialVersionUID = 8781454627263127075L;

	public TelefoneDAO() {
		super(Telefone.class);
	}

	@Override
	public Telefone findByPk(Object id)throws DataException{
		
		ResultSet resultSet = null;
		PreparedStatement stmt = null;
		
		try {
			
			StringBuilder string = new StringBuilder(SELECT)
			  .append(Telefone.getSqlCamposTelefone())
			  .append(",")
			  .append(Caso.getSqlCamposCaso())
			  .append(FROM)
			  .append(Telefone.getSqlFromTelefone())
			  .append(INNER_JOIN).append(Caso.getSqlFromCaso())
			  .append(" ON (Telefone.ID_CASO = Caso.ID_CASO) ")
			  .append(WHERE).append(" Telefone.ID_TELEFONE = ? ");
			
			Telefone telefone = (Telefone) id;
			stmt = getPreparedStatement(string.toString());
			stmt.setInt(1, telefone.getIdTelefone());
			stmt.execute();
			
			resultSet = stmt.getResultSet();

			while (resultSet.next()) {
				telefone = Telefone.getTelefoneByResultSet(resultSet);
				telefone.setCaso(Caso.getCasoByResultSet(resultSet));
			}
			return telefone;
		} catch (Exception e) {
			throw new DataException("Erro ao buscar Telefone pelo id.", e);
		} finally {
			super.close(resultSet);
		}
	}

	@Override
	public List<Telefone> buscaTelefoneCaso(Caso caso) throws DataException {
		ResultSet resultSet = null;
		PreparedStatement stmt = null;
		
		try {
			
			StringBuilder string = new StringBuilder(SELECT)
			  .append(Telefone.getSqlCamposTelefone())
			  .append(",")
			  .append(Caso.getSqlCamposCaso())
			  .append(FROM)
			  .append(Telefone.getSqlFromTelefone())
			  .append(INNER_JOIN).append(Caso.getSqlFromCaso())
			  .append(" ON (Telefone.ID_CASO = Caso.ID_CASO) ")
			  .append(WHERE).append(" Telefone.ID_CASO = ? ");
			
			List<Telefone> telefoneList = new ArrayList<Telefone>();
			stmt = getPreparedStatement(string.toString());
			stmt.setInt(1, caso.getIdCaso());
			stmt.execute();
			
			resultSet = stmt.getResultSet();

			while (resultSet.next()) {
				Telefone telefone = new Telefone();
				
				telefone = Telefone.getTelefoneByResultSet(resultSet);
				telefone.setCaso(Caso.getCasoByResultSet(resultSet));
				
				telefoneList.add(telefone);
			}
			
			return telefoneList;
		} catch (Exception e) {
			throw new DataException("Erro ao buscar Telefone pelo id.", e);
		} finally {
			super.close(resultSet);
		}
	}

	@Override
	public List<Telefone> findTelefonesNaoTabulados(List<Telefone> telefoneList) throws DataException {
		ResultSet resultSet = null;
		PreparedStatement stmt = null;
		List<Telefone> ret = new ArrayList<Telefone>();
		
		final String QTD_LOG = 
				MessageFormat.format("(SELECT COUNT(1) FROM {0} WHERE Telefone.TELEFONE = LogLigacoes.TELEFONE_CLIENTE AND Telefone.ID_CASO = LogLigacoes.ID_CASO)",
						LogLigacoes.getSqlFromLogLigacoes());
		
		final String QTD_CONTATO = 
				MessageFormat.format("(SELECT COUNT(1) FROM {0} WHERE ContatoTelefone.ID_CASO = Telefone.ID_CASO AND ContatoTelefone.ID_TELEFONE = Telefone.ID_TELEFONE)",
						ContatoTelefone.getSqlFromContato());
		
		try {
			
			StringBuilder string = new StringBuilder(SELECT)
			  .append(Telefone.getSqlCamposTelefone())
			  .append(",")
			  .append(Caso.getSqlCamposCaso())
			  .append(FROM)
			  .append(Telefone.getSqlFromTelefone())
			  .append(INNER_JOIN).append(Caso.getSqlFromCaso())
			  .append(" ON (Telefone.ID_CASO = Caso.ID_CASO) ")
			  .append(WHERE).append(" Telefone.ID_TELEFONE in ( ");
			
			for (int i = 0; i < telefoneList.size();) {
				string.append(telefoneList.get(i).getIdTelefone());
				
		        if (++i < telefoneList.size()) {
		        	string.append(",");
		        }
		    }
			string.append(")").append(" AND ").append(QTD_LOG).append(" > ").append(QTD_CONTATO);
			
			stmt = getPreparedStatement(string.toString());
			stmt.execute();
			
			resultSet = stmt.getResultSet();

			while (resultSet.next()) {
				Telefone telefone = new Telefone();
				
				telefone = Telefone.getTelefoneByResultSet(resultSet);
				telefone.setCaso(Caso.getCasoByResultSet(resultSet));
				
				ret.add(telefone);
			}
			
			return ret;
		} catch (Exception e) {
			throw new DataException("Erro ao buscar Telefone pelo id.", e);
		} finally {
			super.close(resultSet);
		}
	}
	
	@Override
	public Boolean existeContatoNaoTabulado(Caso caso) throws DataException {
		ResultSet resultSet = null;
		PreparedStatement stmt = null;
		
		final String QTD_LOG = 
				MessageFormat.format("(SELECT COUNT(1) FROM {0} WHERE Telefone.TELEFONE = LogLigacoes.TELEFONE_CLIENTE AND Telefone.ID_CASO = LogLigacoes.ID_CASO)",
						LogLigacoes.getSqlFromLogLigacoes());
		
		final String QTD_CONTATO = 
				MessageFormat.format("(SELECT COUNT(1) FROM {0} WHERE ContatoTelefone.ID_CASO = Telefone.ID_CASO AND ContatoTelefone.ID_TELEFONE = Telefone.ID_TELEFONE)",
						ContatoTelefone.getSqlFromContato());
		
		try {
			
			StringBuilder string = new StringBuilder("select 1 ")
			  .append(FROM)
			  .append(Telefone.getSqlFromTelefone())
			  .append(INNER_JOIN).append(Caso.getSqlFromCaso())
			  .append(" ON (Telefone.ID_CASO = Caso.ID_CASO) ")
			  .append(WHERE).append(QTD_LOG).append(" > ").append(QTD_CONTATO).append(" and Telefone.ID_CASO = ?");
			
			stmt = getPreparedStatement(string.toString());
			stmt.setInt(1, caso.getIdCaso());
			stmt.execute();
			
			resultSet = stmt.getResultSet();
			return resultSet!= null && resultSet.next();
			
		} catch (Exception e) {
			throw new DataException("Erro ao buscar contatos", e);
		} finally {
			super.close(resultSet);
		}
	}

	@Override
	public void deletarTelefonesAusentes(List<Telefone> telefones) throws DataException {
		try {
			StringBuilder stringBuilder = new StringBuilder(); 
			Caso caso = telefones.get(0).getCaso();
			
			for (Telefone telefone : telefones) {
				if(telefone.getIdTelefone() != null){
					stringBuilder.append(",").append(telefone.getIdTelefone());
				}
			} 
			
			String notInClause = stringBuilder.toString().replaceFirst(",", "");
			
			if(!"".equals(notInClause.trim())){
				String delete = "delete from tb_telefone where id_telefone not in (:notInClause) and id_caso = ?";
				delete = delete.replace(":notInClause", notInClause);
				
				PreparedStatement stmt = getPreparedStatement(delete);
				stmt.setInt(1, caso.getIdCaso());
				
				stmt.executeUpdate();
			}else{
				deletarTelefonesCaso(caso);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DataException(e);
		}
	}

	@Override
	public void deletarTelefonesCaso(Caso caso) throws DataException {
		try {
			String delete = "delete from tb_telefone where id_caso = ?";
			
			PreparedStatement stmt = getPreparedStatement(delete);
			stmt.setInt(1, caso.getIdCaso());
			
			stmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DataException(e);
		}
	}
}
