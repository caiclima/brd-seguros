package br.com.callink.cad.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.com.callink.cad.dao.ITempoAtendimentoCasoDAO;
import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.TempoAtendimentoCaso;
import br.com.callink.cad.sau.exception.DataException;

public class TempoAtendimentoCasoDAO extends GenericCadDAO<TempoAtendimentoCaso> implements ITempoAtendimentoCasoDAO {

	private static final long serialVersionUID = -8819332194271442453L;

	public TempoAtendimentoCasoDAO() {
		super(TempoAtendimentoCaso.class);
	}

	@Override
	public Integer findUltimaMarcacaoAtendente(Atendente atendente) throws DataException {
		
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
	
	try{	
		
			StringBuilder string = new StringBuilder();
			string.append(" select max(id_tempo_atendimento_caso) marcacao from tb_tempo_atendimento_caso with(nolock) where id_atendente =  ? ");
			
			stmt = getPreparedStatement(string.toString());
			stmt.setInt(1, atendente.getIdAtendente());
		    stmt.execute();
		    resultSet =  stmt.getResultSet();
			
		    if (resultSet.next()) {
		        return resultSet.getInt("marcacao");
		    } 
		    
		    return null;    
		    
		}catch (Exception e) {
			throw new DataException(e);
		}finally{
			super.close(resultSet);
		}
	}
	
	@Override
	public TempoAtendimentoCaso findByPk(Object id)throws DataException{
		
		ResultSet resultSet = null;
		PreparedStatement stmt = null;
		
		try {
			
			StringBuilder string = new StringBuilder(SELECT)
			  .append(TempoAtendimentoCaso.getSqlCamposTempoAtendimentoCaso())
			  .append(",").append(Caso.getSqlCamposCaso())
			  .append(",").append(Atendente.getSqlCamposAtendente())
			  .append(",").append(Acao.getSqlCamposAcao())
			  .append(FROM).append(TempoAtendimentoCaso.getSqlFromTempoAtendimentoCaso())
			  .append(LEFT_JOIN).append(Caso.getSqlFromCaso())
			  .append(" ON (TempoAtendimentoCaso.ID_CASO = Caso.ID_CASO ) ")
			  .append(LEFT_JOIN).append(Atendente.getSqlFromAtendente())
			  .append(" ON (TempoAtendimentoCaso.ID_ATENDENTE = Atendente.ID_ATENDENTE ) ")
			  .append(LEFT_JOIN).append(Acao.getSqlFromAcao())
			  .append(" ON (TempoAtendimentoCaso.ID_ACAO = Acao.ID_ACAO) ")
			  .append(WHERE).append(" TempoAtendimentoCaso.id_tempo_atendimento_caso = ? ");
			
			TempoAtendimentoCaso tempo = (TempoAtendimentoCaso) id;
			
			stmt = getPreparedStatement(string.toString());
			stmt.setInt(1, tempo.getIdTempoAtendimentoCaso());
			stmt.execute();
			
			resultSet = stmt.getResultSet();

			while (resultSet.next()) {
				tempo = TempoAtendimentoCaso.getTempoAtendimentoCasoByResultSet(resultSet);
				tempo.setCaso(Caso.getCasoByResultSet(resultSet));
				tempo.setAtendente(Atendente.getAtendenteByResultSet(resultSet));
				tempo.setAcao(Acao.getAcaoByResultSet(resultSet));
			}
			return tempo;
		} catch (Exception e) {
			throw new DataException("Erro ao buscar TempoAtendimentoCaso pelo Id.", e);
		} finally {
			super.close(resultSet);
		}
	}
	
	@Override
    public List<TempoAtendimentoCaso> findByCaso(Caso caso) throws DataException{
		
		ResultSet resultSet = null;
		PreparedStatement stmt = null;
		
		try {
			
			StringBuilder string = new StringBuilder(SELECT)
			  .append(TempoAtendimentoCaso.getSqlCamposTempoAtendimentoCaso())
			  .append(",").append(Caso.getSqlCamposCaso())
			  .append(",").append(Atendente.getSqlCamposAtendente())
			  .append(",").append(Acao.getSqlCamposAcao())
			  .append(FROM).append(TempoAtendimentoCaso.getSqlFromTempoAtendimentoCaso())
			  .append(LEFT_JOIN).append(Caso.getSqlFromCaso())
			  .append(" ON (TempoAtendimentoCaso.ID_CASO = Caso.ID_CASO ) ")
			  .append(LEFT_JOIN).append(Atendente.getSqlFromAtendente())
			  .append(" ON (TempoAtendimentoCaso.ID_ATENDENTE = Atendente.ID_ATENDENTE ) ")
			  .append(LEFT_JOIN).append(Acao.getSqlFromAcao())
			  .append(" ON (TempoAtendimentoCaso.ID_ACAO = Acao.ID_ACAO) ")
			  .append(WHERE).append(" TempoAtendimentoCaso.id_caso = ? ");
			
			
			
			stmt = getPreparedStatement(string.toString());
			stmt.setInt(1, caso.getIdCaso());
			stmt.execute();
			
			resultSet = stmt.getResultSet();
			List<TempoAtendimentoCaso> list = new ArrayList<TempoAtendimentoCaso>();
			while (resultSet.next()) {
				TempoAtendimentoCaso tempo = TempoAtendimentoCaso.getTempoAtendimentoCasoByResultSet(resultSet);
				tempo.setCaso(Caso.getCasoByResultSet(resultSet));
				tempo.setAtendente(Atendente.getAtendenteByResultSet(resultSet));
				tempo.setAcao(Acao.getAcaoByResultSet(resultSet));
				list.add(tempo);
			}
			return list;
		} catch (Exception e) {
			throw new DataException("Erro ao buscar TempoAtendimentoCaso pelo Id.", e);
		} finally {
			super.close(resultSet);
		}
	}

}
