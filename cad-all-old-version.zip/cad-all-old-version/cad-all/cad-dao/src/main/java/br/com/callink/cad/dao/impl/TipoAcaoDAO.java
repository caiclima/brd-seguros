package br.com.callink.cad.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;

import br.com.callink.cad.dao.ITipoAcaoDAO;
import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.pojo.AcaoTipoAcao;
import br.com.callink.cad.pojo.AcaoTipoAcaoId;
import br.com.callink.cad.pojo.Status;
import br.com.callink.cad.pojo.TipoAcao;
import br.com.callink.cad.pojo.Util.DateUtil;
import br.com.callink.cad.sau.exception.DataException;

public class TipoAcaoDAO extends GenericCadDAO<TipoAcao> implements ITipoAcaoDAO {

	private static final long serialVersionUID = -8974224495219111275L;

	public TipoAcaoDAO() {
		super(TipoAcao.class);
	}

	@Override
    public void associa(AcaoTipoAcao acaoTipoAcao) throws DataException {
		try {
			Query query = getEntityManager().createNativeQuery("INSERT INTO tb_acao_tipo_acao (ID_ACAO, ID_TIPO_ACAO) VALUES (:acao, :tipoAcao)");
            query.setParameter("acao", acaoTipoAcao.getAcaoTipoAcaoId().getIdAcao().getIdAcao());
            query.setParameter("tipoAcao", acaoTipoAcao.getAcaoTipoAcaoId().getIdTipoAcao().getIdTipoAcao());
            query.executeUpdate();
		} catch (Exception ex) {
			throw new DataException(ex);
		}
    }

    @Override
    public void excluiAssociacao(AcaoTipoAcao acaoTipoAcao) throws DataException {
    	
    	Query query = getEntityManager().createNativeQuery("delete from tb_acao_tipo_acao where id_acao = :acao and id_tipo_acao = :tipoAcao");
		query.setParameter("acao", acaoTipoAcao.getAcaoTipoAcaoId().getIdAcao().getIdAcao());
		query.setParameter("tipoAcao", acaoTipoAcao.getAcaoTipoAcaoId().getIdTipoAcao().getIdTipoAcao());
    	query.executeUpdate();
    }
    
    @Override
    public List<AcaoTipoAcao> find(Acao acao, TipoAcao tipoAcao) throws DataException {
        return getAcaoTipoAcao(acao, tipoAcao);
    }

    private List<AcaoTipoAcao> getAcaoTipoAcao(Acao acao, TipoAcao tipoAcao) throws DataException {
    	
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
       
		try {
        	
        	StringBuilder string = new StringBuilder(SELECT)
		        	.append(TipoAcao.getSqlCamposTipoAcao())
					.append(",")
					.append(Acao.getSqlCamposAcao())
					.append(FROM)
					.append(AcaoTipoAcao.getSqlFromAcaoTipoAcao())
					.append(INNER_JOIN).append(TipoAcao.getSqlFromTipoAcao())
					.append(" ON AcaoTipoAcao.ID_TIPO_ACAO = TipoAcao.ID_TIPO_ACAO ")
					.append(INNER_JOIN).append(Acao.getSqlFromAcao())
					.append(" ON AcaoTipoAcao.ID_ACAO = Acao.ID_ACAO ")
		        	.append(WHERE_1_1);
			
            boolean isAcao = acao != null && acao.getIdAcao() != null;
            boolean isTipoAcao = tipoAcao != null && tipoAcao.getIdTipoAcao() != null;
           
            if (isAcao && !isTipoAcao) {
            	string.append(" AND Acao.ID_ACAO = ? ");
            } else if (!isAcao && isTipoAcao) {
            	string.append(" AND TipoAcao.ID_TIPO_ACAO = ? ");
            } else if (isAcao && isTipoAcao) {
            	string.append(" AND Acao.ID_ACAO = ? ");
            	string.append(" AND TipoAcao.ID_TIPO_ACAO = ? ");
            }
            
            stmt = getPreparedStatement(string.toString());
            
            if (isAcao && !isTipoAcao) {
            	stmt.setInt(1, acao.getIdAcao());
            } else if (!isAcao && isTipoAcao) {
            	stmt.setInt(1, tipoAcao.getIdTipoAcao());
            } else if (isAcao && isTipoAcao) {
            	stmt.setInt(1, acao.getIdAcao());
            	stmt.setInt(2, tipoAcao.getIdTipoAcao());
            }
            
            stmt.execute();
    	    resultSet =  stmt.getResultSet();
    	    List<AcaoTipoAcao> ret = new ArrayList<AcaoTipoAcao>();
    	    
    	    while(resultSet.next()){
    	    
    	    	TipoAcao tipo = TipoAcao.getTipoAcaoByResultSet(resultSet);
    	    	Acao acao2 = Acao.getAcaoByResultSet(resultSet);
    	    	AcaoTipoAcao acaoTipoAcao = new AcaoTipoAcao();
    	    	acaoTipoAcao.setAcaoTipoAcaoId(new AcaoTipoAcaoId(tipo, acao2));
    	    	
    	    	ret.add(acaoTipoAcao);
    	    }
    	    
    	    return ret;
    	    
		}catch (Exception ex) {
            throw new DataException(ex);
        }finally{
        	super.close(resultSet);
        }
        
	}

	@Override
    public List<AcaoTipoAcao> findAllAcaoTipoAcao() throws DataException {
        return getAcaoTipoAcao(null, null);
    }
	
	@Override
	public List<TipoAcao> findTipoAcaoPeloStatus(Status status) throws DataException {
		if (status == null || status.getIdStatus() == null) {
			throw new DataException("O status não pode ser nulo.");
		}
		
		List<TipoAcao> ret = new ArrayList<TipoAcao>();
		ResultSet resultSet = null;
		PreparedStatement stmt = null;
		try {
			StringBuilder string = new StringBuilder();
			string.append(" select distinct ");
			string.append(TipoAcao.getSqlCamposTipoAcao());
			string.append(" from tb_tipo_acao tipoAcao with(nolock), tb_acao_tipo_acao act with(nolock), tb_acao ac with(nolock), tb_status_acao sta with(nolock) ");
			string.append(" where sta.id_status = ? and sta.id_acao = ac.id_acao and ac.id_acao = act.id_acao ");
			string.append(" and act.id_tipo_acao = tipoAcao.id_tipo_acao and tipoAcao.flag_ativo = 1  ");
			stmt = getPreparedStatement(string.toString());
			stmt.setInt(1, status.getIdStatus());
			stmt.execute();
			
			resultSet =stmt.getResultSet();

			while (resultSet.next()) {
				TipoAcao tipo = TipoAcao.getTipoAcaoByResultSet(resultSet);
				ret.add(tipo);
			}
			
        } catch (Exception e) {
            throw new DataException("Erro ao buscar os Tipos de Ação pelo Status.", e);
        }finally{
        	super.close(resultSet);
        }
		
		return ret;
	}
	
	@Override
	public TipoAcao findByPk(Object id)throws DataException{
		
		ResultSet resultSet = null;
		PreparedStatement stmt = null;
		
		try {
			
			StringBuilder string = new StringBuilder(SELECT)
			  .append(TipoAcao.getSqlCamposTipoAcao())
			  .append(FROM)
			  .append(TipoAcao.getSqlFromTipoAcao())
			  .append(WHERE).append(" TipoAcao.ID_TIPO_ACAO = ? ");
			
			TipoAcao tipo = (TipoAcao) id;
			
			stmt = getPreparedStatement(string.toString());
			stmt.setInt(1, tipo.getIdTipoAcao());
			stmt.execute();
			
			resultSet =stmt.getResultSet();

			while (resultSet.next()) {
				tipo = TipoAcao.getTipoAcaoByResultSet(resultSet);
			}
			return tipo;
		} catch (Exception e) {
			throw new DataException("Erro ao buscar o Tipo de Ação pelo Id.", e);
		} finally {
			super.close(resultSet);
		}
	}
	
	@Override
	public List<TipoAcao> findByExample(TipoAcao example) throws DataException {
		return findByExample(example, null);
	}
	
	@Override
	public List<TipoAcao> findByExample(TipoAcao example, String order) throws DataException {
		List<TipoAcao> tipoAcoes = new ArrayList<TipoAcao>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		int index = 0;
		
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(TipoAcao.getSqlCamposTipoAcao())
				.append(FROM)
				.append(TipoAcao.getSqlFromTipoAcao())
				.append(WHERE_1_1);
			
			if(example != null){
			
				if (example.getIdTipoAcao() != null) {
					select.append(" AND TipoAcao.ID_TIPO_ACAO = ? ");
				}
				if (example.getNome() != null && !example.getNome().isEmpty()) {
					select.append(" AND TipoAcao.NOME like ? ");
				}
				if (example.getDataAlteracao() != null) {
					select.append(" AND TipoAcao.DATA_ALTERACAO BETWEEN ? AND ? ");
				}
				if (example.getFlagAtivo() != null) {
					select.append(" AND TipoAcao.FLAG_ATIVO = ? ");
				}
			}
			
			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			if(example != null){
				
				if (example.getIdTipoAcao() != null) {
					stmt.setInt(++index, example.getIdTipoAcao());
				}
				if (example.getNome() != null && !example.getNome().isEmpty()) {
					stmt.setString(++index, new StringBuilder(example.getNome()).append("%").toString());
				}
				if (example.getDataAlteracao() != null) {
					Date dataInicio = DateUtil.dataInicioDia(example.getDataAlteracao());
					Date dataFim = DateUtil.dataFimDia(example.getDataAlteracao());
					stmt.setDate(++index, new java.sql.Date(dataInicio.getTime()));
					stmt.setDate(++index, new java.sql.Date(dataFim.getTime()));
				}
				if (example.getFlagAtivo() != null) {
					stmt.setBoolean(++index, example.getFlagAtivo());
				}
			}
			
			stmt.execute();
			resultSet =stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					TipoAcao tipoAcao = TipoAcao.getTipoAcaoByResultSet(resultSet);
					tipoAcoes.add(tipoAcao);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return tipoAcoes;
	}
	
}
