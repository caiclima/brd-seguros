package br.com.callink.cad.sau.exception;

public class DataException extends Exception {

	private static final long serialVersionUID = 6832933853694260992L;
	
	public DataException(String msg) {
		super(msg);
	}

	public DataException(Throwable throwable) {
		super(throwable);
	}
	
	
	public DataException(String msg,Throwable throwable) {
		super(msg, throwable);
	}
	
}
