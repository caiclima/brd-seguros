package br.com.callink.cad.engine.buffer.fila;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import br.com.callink.cad.engine.buffer.BufferCaso;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.service.ICasoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

public class ThreadAtualizaBufferFila extends Thread {
	
	private static boolean executa;
	private static Integer bufferCasoParametro;
	
	private Logger logger = Logger.getLogger(ThreadAtualizaBufferFila.class.getName());

	private static Map<String,BufferCaso>  mapFila = new ConcurrentHashMap<String, BufferCaso>();
	private static Queue<ConfiguracaoFila> configuracaoBufferFila = new ConcurrentLinkedQueue<ConfiguracaoFila>();
	
	private ICasoService casoService;
	
	public ThreadAtualizaBufferFila(Integer bufferCasoParametro, ICasoService casoService) {
		ThreadAtualizaBufferFila.setBufferCasoParametro(bufferCasoParametro);
		this.casoService=casoService;
	}
	
	public static void setBufferCasoParametro(Integer bufferCasoParametro) {
		ThreadAtualizaBufferFila.bufferCasoParametro = bufferCasoParametro;
	}
	
        /**
	 * Insere o ID do caso.
	 * @param caso
	 */
	public static synchronized void addConfiguracaoFilaRefazerBuffer(ConfiguracaoFila configuracaoFila, Integer bufferCaso) {
            bufferCasoParametro = bufferCaso;
            configuracaoBufferFila.add(configuracaoFila);
	}
	
	/**
	 * Retorna o ID do Caso. Se não existir nenum caso na fila retorna null.
	 * @return
	 */
	private static synchronized ConfiguracaoFila poll() {
		return configuracaoBufferFila.poll();
	}
        
	public void run() {
		try {
			Thread.sleep(65000);
		} catch (InterruptedException ex) {
			Logger.getLogger(ThreadAtualizaBufferFila.class.getName()).log(Level.SEVERE, null, ex);
		}

		logger.info("ThreadAtualizaBuffer iniciada");
		
		ThreadAtualizaBufferFila.setExecuta(true);
		while (executa) {
			try {
				ConfiguracaoFila configuracaoFila = ThreadAtualizaBufferFila.poll();

				if (configuracaoFila != null && configuracaoFila.getIdConfiguracaoFila() != null) {
					atualizaBufferFila(configuracaoFila);
				} else {
					Thread.sleep(2000);
				}
			} catch (Exception e) {
				logger.log(Level.SEVERE, "", e);
			}

		}

		logger.info("ThreadAtualizaBuffer finalizada");
	}

	/**
	 * Atualiza o buffer das filas.
	 * @throws ValidationException 
	 */
	private synchronized void atualizaBufferFila(ConfiguracaoFila configuracaoFila) throws ValidationException {

            try {
                List<Caso> casoList = casoService.buscaCasosOrdernadosPorFilaSemAtendente(configuracaoFila,bufferCasoParametro);
                for (Caso caso : casoList) {
                        putCaso(configuracaoFila,caso);
                }
            } catch (ServiceException e) {
                logger.log(Level.SEVERE, "", e);
            }
	}
	
	public static void addFilaBuffer(ConfiguracaoFila configuracaoFila) {
		if (!mapFila.containsKey(configuracaoFila.getNome())) {
			mapFila.put(configuracaoFila.getNome(), new BufferCaso());
		}
	}
	
	public static synchronized void putCaso(ConfiguracaoFila configuracaoFila, Caso caso) {
		BufferCaso bufferCaso = mapFila.get(configuracaoFila.getNome());
		bufferCaso.add(caso.getIdCaso());
	}
	
	public static synchronized BufferCaso getBufferCaso(ConfiguracaoFila configuracaoFila) {
		return mapFila.get(configuracaoFila.getNome());
	}

	public static final boolean isExecuta() {
		return executa;
	}

	public static final void setExecuta(boolean executa) {
		ThreadAtualizaBufferFila.executa = executa;
	}
        
        
	
}
