package br.com.callink.cad.engine.buffer.fila;

import java.util.logging.Level;
import java.util.logging.Logger;

import br.com.callink.cad.service.IRelatorioCasosFechadosService;
import br.com.callink.cad.service.exception.ServiceException;

public class ThreadAtualizaCasosFechados extends Thread {
	
	private Logger logger = Logger.getLogger(ThreadAtualizaCasosFechados.class.getName());
	private static boolean executa;
	private static long time = 120000l;
	
	
	private IRelatorioCasosFechadosService relatorioCasosFechadosService;
	
	public ThreadAtualizaCasosFechados(IRelatorioCasosFechadosService relatorioCasosFechadosService) {
		setExecuta(true);
		this.relatorioCasosFechadosService = relatorioCasosFechadosService;
	}
	
	@Override
	public void run() {
		try {
			Thread.sleep(60000l);
		} catch (InterruptedException e1) {
			logger.log(Level.SEVERE, "Thread iniciada", e1);
		}

		logger.info("ThreadAtualizaCasosFechados iniciada");
		
		while (isExecuta()) {
			try {
				relatorioCasosFechadosService.geraCasosFechadosDia();
			} catch (ServiceException e) {
				logger.log(Level.SEVERE, "Erro ao gerar os casos fechados", e);
			} catch (Exception e) {
				logger.log(Level.SEVERE, "Erro ao gerar os casos fechados", e);
			}

			try {
				Thread.sleep(time);
			} catch (InterruptedException e1) {
				logger.log(Level.SEVERE, "Thread iniciada", e1);
			}
		}

		logger.info("ThreadAtualizaCasosFechados iniciada");
	}

	public static boolean isExecuta() {
		return executa;
	}

	public static void setExecuta(boolean executa) {
		ThreadAtualizaCasosFechados.executa = executa;
	}
	
}
