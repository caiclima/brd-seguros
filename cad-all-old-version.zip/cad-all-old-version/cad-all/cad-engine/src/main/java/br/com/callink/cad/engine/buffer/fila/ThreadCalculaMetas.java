package br.com.callink.cad.engine.buffer.fila;

import java.util.logging.Level;
import java.util.logging.Logger;

import br.com.callink.cad.service.IMetaUphService;
import br.com.callink.cad.service.exception.ServiceException;

/**
 * thread que calcula as metas e coloca em cache 
 * 
 * @author miller
 *
 */
public class ThreadCalculaMetas extends Thread {

	private static boolean executa;
	
	private Logger logger = Logger.getLogger(ThreadCalculaMetas.class.getName());
	private static long intervalo = 30000l;
	
	private IMetaUphService metaUphService;
	 
	public ThreadCalculaMetas(IMetaUphService metaUphService) {
		this.metaUphService= metaUphService;
	}
	
	@Override
	public void run() {
		try {
			ThreadCalculaMetas.setExecuta(Boolean.TRUE);
			Thread.sleep(intervalo);
			
			logger.info("ThreadCalculaMetas iniciada");
			
			setExecuta(Boolean.FALSE);
			while (executa) {
				logger.info(" inicio do calculo da meta " + System.currentTimeMillis());
				calculaMetas();
				logger.info(" fim do calculo da meta " + System.currentTimeMillis());
				try {
					Thread.sleep(intervalo);
				} catch (InterruptedException e) {
					logger.info("Erro na execucao da thread calcula metas com a seguinte mensagem :" + e.getMessage());
					logger.log(Level.SEVERE, "", e);
				}
			}

		} catch (ServiceException e) {
			logger.info("Erro no calculo das metas com a mesangem" + e.getMessage());
			logger.log(Level.SEVERE, "", e);
		} catch (Exception e) {
			logger.log(Level.SEVERE, "", e);
		}
		
		logger.info("ThreadCalculaMetas finalizada");
	}

	private synchronized void calculaMetas() throws ServiceException {
		metaUphService.calculaMetasUph();
	}

	public static final boolean isExecuta() {
		return executa;
	}

	public static final void setExecuta(boolean executa) {
		ThreadCalculaMetas.executa = executa;
	}

	
}
