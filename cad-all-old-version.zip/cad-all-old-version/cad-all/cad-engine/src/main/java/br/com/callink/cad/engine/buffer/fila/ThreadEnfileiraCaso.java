package br.com.callink.cad.engine.buffer.fila;

import java.util.logging.Level;
import java.util.logging.Logger;

import br.com.callink.cad.service.IConfiguracaoFilaService;
import br.com.callink.cad.service.exception.ServiceException;

/**
 * Thread que irá enfileirar os casos. A mesma deve ser executada de um em um minuto.
 * somente pode ser executada se a não existir outra thread executando. 
 * @author brunomt
 *
 */
public class ThreadEnfileiraCaso extends Thread {

	private static boolean executa;
	private Logger logger = Logger.getLogger(ThreadEnfileiraCaso.class.getName());
	
	private IConfiguracaoFilaService configuracaoFilaService;
	
	
	public ThreadEnfileiraCaso(IConfiguracaoFilaService configuracaoFilaService) {
		this.configuracaoFilaService=configuracaoFilaService;
	}
	
	/**
	 * Execução da thread.
	 */
	public void run() {
		try {
			Thread.sleep(60000);
		} catch (InterruptedException ex) {
			Logger.getLogger(ThreadEnfileiraCaso.class.getName()).log(Level.SEVERE, null, ex);
		}
		
		logger.info("ThreadEnfileiraCaso iniciada");
		
		ThreadEnfileiraCaso.setExecuta(Boolean.TRUE);
		while (executa) {
			try {
				Thread.sleep(20000);
				classificaCasos();
			} catch (InterruptedException e) {
				logger.log(Level.SEVERE, "", e);
			} catch (Exception ex) {
				logger.log(Level.SEVERE, "", ex);
			}
		}
		
		logger.info("ThreadEnfileiraCaso finalizada");
	}

	/**
	 * Classifica os casos
	 */
	private synchronized void classificaCasos() {
			//busca as filas cadastradas por prioridade
			logger.info("Enfileirando os casos.");

			try {
				configuracaoFilaService.classificaCasos();
			} catch (ServiceException e) {
				logger.log(Level.SEVERE, "", e);
			} catch (Exception e) {
				logger.log(Level.SEVERE, "", e);
			}
			logger.info("Casos colocados em suas filas.");
	}

	public static final boolean isExecuta() {
		return executa;
	}

	public static final void setExecuta(boolean executa) {
		ThreadEnfileiraCaso.executa = executa;
	}

	
}
