package br.com.callink.cad.engine.buffer.fila;

import java.util.logging.Level;
import java.util.logging.Logger;

import br.com.callink.cad.service.IConfiguracaoFilaService;
import br.com.callink.cad.service.exception.ServiceException;

/**
 * Thread que irá processar as reaberturas dos casos. A mesma deve ser executada de um em um minuto.
 * somente pode ser executada se a não existir outra thread executando. 
 * @author brunomt
 *
 */
public class ThreadProcessaReaberturaCaso extends Thread {

	private static boolean executa;
	
	private Logger logger = Logger.getLogger(ThreadProcessaReaberturaCaso.class.getName());
	
	private IConfiguracaoFilaService configuracaoFilaService;
	
	public ThreadProcessaReaberturaCaso(IConfiguracaoFilaService configuracaoFilaService) {
		this.configuracaoFilaService=configuracaoFilaService;
	}
	
	/**
	 * Execução da thread.
	 */
	public void run() {
		try {
			Thread.sleep(Integer.valueOf(55000));
		} catch (InterruptedException ex) {
			Logger.getLogger(ThreadProcessaReaberturaCaso.class.getName()).log(Level.SEVERE, null, ex);
		}

		logger.info("ThreadProcessaReaberturaCaso iniciada");
		
		ThreadProcessaReaberturaCaso.setExecuta(Boolean.TRUE);
		while (executa) {
			try {
				Thread.sleep(60000);
				processaReabertura();
			} catch (InterruptedException e) {
				logger.log(Level.SEVERE, "", e);
			} catch (Exception ex) {
				logger.log(Level.SEVERE, "", ex);
			}
		}

		logger.info("ThreadProcessaReaberturaCaso finalizada");
	}

	/**
	 * Classifica os casos
	 */
	private synchronized void processaReabertura() {
			//busca as filas cadastradas por prioridade
			logger.info("Processando os casos reabertos.");

			try {
				configuracaoFilaService.preparaReaberturasLiberaCasos();
			} catch (ServiceException e) {
				logger.log(Level.SEVERE, "", e);
			} catch (Exception e) {
				logger.log(Level.SEVERE, "", e);
			}
			logger.info("Casos Reabertos colocados em suas filas.");
	}

	public static final boolean isExecuta() {
		return executa;
	}

	public static final void setExecuta(boolean executa) {
		ThreadProcessaReaberturaCaso.executa = executa;
	}
	
}
