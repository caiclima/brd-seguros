package br.com.callink.cad.engine.buffer.fila;

import java.util.logging.Level;
import java.util.logging.Logger;
import br.com.callink.cad.service.IRelatorioTempoGeralOperadorService;
import br.com.callink.cad.service.IRelatorioTempoGeralService;

public class ThreadProcessaTempoGeral extends Thread {
	
	private Logger logger = Logger.getLogger(getClass().getName());
	private static boolean executa;
	private static long time = 7200000l;
	//private static long time = 60000l;
	
	private IRelatorioTempoGeralService relatorioTempoGeralService;
	private IRelatorioTempoGeralOperadorService relatorioTempoGeralOperadorService;
	
	
	public ThreadProcessaTempoGeral(IRelatorioTempoGeralService relatorioTempoGeralService, IRelatorioTempoGeralOperadorService relatorioTempoGeralOperadorService) {
		setExecuta(true);
		this.relatorioTempoGeralService = relatorioTempoGeralService;
		this.relatorioTempoGeralOperadorService = relatorioTempoGeralOperadorService;
	}
	
	@Override
	public void run() {
		try {
			Thread.sleep(60000l);
		} catch (InterruptedException e1) {
			logger.log(Level.SEVERE, "Thread iniciada", e1);
		}
		
		logger.info("ThreadProcessaTempoGeral iniciada");
		
		while (isExecuta()) {
			try {
				relatorioTempoGeralService.geraTempoGeralDia();
			} catch (Exception e) {
				logger.log(Level.SEVERE, "Erro ao gerar os tempo geral", e);
			}

			try {
				relatorioTempoGeralOperadorService.geraTempoGeralPorOperadorPorDia();
			} catch (Exception e) {
				logger.log(Level.SEVERE, "Erro ao gerar os tempo geral operador por dia", e);
			}

			try {
				Thread.sleep(time);
			} catch (InterruptedException e1) {
				logger.log(Level.SEVERE, "Thread iniciada", e1);
			}
		}
		
		logger.info("ThreadProcessaTempoGeral finalizada");
	}

	public static boolean isExecuta() {
		return executa;
	}

	public static void setExecuta(boolean executa) {
		ThreadProcessaTempoGeral.executa = executa;
	}
	
}
