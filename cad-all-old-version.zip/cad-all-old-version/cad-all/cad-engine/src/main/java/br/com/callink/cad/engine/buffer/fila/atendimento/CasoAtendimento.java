package br.com.callink.cad.engine.buffer.fila.atendimento;

import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Singleton;
import br.com.callink.cad.engine.buffer.BufferCaso;
import br.com.callink.cad.engine.buffer.fila.ThreadAtualizaBufferFila;
import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.pojo.EquipeFila;
import br.com.callink.cad.pojo.Log;
import br.com.callink.cad.pojo.ParametroGBO;
import br.com.callink.cad.service.IAtendenteService;
import br.com.callink.cad.service.ICasoService;
import br.com.callink.cad.service.IConfiguracaoFilaService;
import br.com.callink.cad.service.IEquipeFilaService;
import br.com.callink.cad.service.ILogService;
import br.com.callink.cad.service.IParametroGBOService;
import br.com.callink.cad.service.ITempoAtendimentoCasoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.service.repository.ControleStatusAtendentes;
import br.com.callink.cad.util.Constantes;

@Singleton
public class CasoAtendimento implements ICasoAtendimento{

	@EJB
	private ICasoService casoService;
	@EJB
	private IAtendenteService atendenteService;
	@EJB
	private ITempoAtendimentoCasoService tempoAtendimentoCasoService;
	@EJB
	private ILogService logService;
	@EJB
	private IConfiguracaoFilaService configuracaoFilaService;
	@EJB
	private IParametroGBOService parametroGBOService;
	@EJB
    private IEquipeFilaService equipeFilaService;

    /**
     * Método que retorna qual o proximo caso do atendente.
     * 
     * Verifica as seguintes regras, as regras são executadas na ordem a seguir. Se não for encontrado nenhum
     * caso na regra verificada o sistema passa para a próxima:
     *  1º Retorna caso que está agendados para o atendente na data/hora atual ou menor que atual.
     *  2º Retorna caso que foi delegado para o atendente e ainda não possui nenhum atendimento
     *  3º Retorna caso que está agendados para a fila.
     *  4º Retorna caso que está no {@link BufferFila} Buffer de atendimento das filas.
     * 
     * @return
     * @throws ServiceException 
     * @throws ValidationException 
     */
    
    public Caso solicitaCasoAtendenteAtendimento(Atendente atendente) throws ServiceException, ValidationException {
        
    	//Valida se o atendente possui perfil de SUPERVISOR. Se sim o mesmo não pode atender nenhum caso.
        if (!atendenteService.validaAtendenteCaso(atendente)) {
            throw new ValidationException("O analista possui perfil de supervisor. O mesmo n\u00E3o pode atender casos.");
        }
        
        if (ControleStatusAtendentes.atendenteSolicitouAlteracaoStatus(atendente)) {
        	throw new ValidationException("O analista solicitou uma altera\u00E7\u00E3o de status. Favor alterar o status.");
        }

        Caso caso;
        //Busca o caso agendado por ordem na data de agendamento- e com flag_ativo = true. Ao pegar um caso agendado, o agendamento deve ser desativado.
        caso = casoService.buscaCasoAgendado(atendente);
        if (caso != null && caso.getIdCaso() != null) {
            atualizarCasoAtendimento(atendente, casoService, tempoAtendimentoCasoService, caso);
            return caso;
        }

        //Buscar se existe algum caso na fila do atendente que pode ser atendido nesse momento. Ou seja, existem status que requerem atendimento.
        List<Caso> casosAtendente = casoService.buscaTodosCasosAtivosAtendente(atendente);
        if (casosAtendente != null) {
            for (Caso casoItem : casosAtendente) {
                casoItem = casoService.load(casoItem);

                if (!casoItem.getStatus().getFlagPausado()) {
                    atualizarCasoAtendimento(atendente, casoService, tempoAtendimentoCasoService, casoItem);
                    return casoItem;
                }
            }
        }

        caso = buscaCasoAgendadoFila(atendente);
        if (caso != null && caso.getIdCaso() != null) {
            atualizarCasoAtendimento(atendente, casoService, tempoAtendimentoCasoService, caso);
            return caso;
        }

        //Busca um caso de uma das filas que o atendente está cadastrado.
        caso = retornaProximoCasoFilaAtendente(atendente);
        if (caso != null && caso.getIdCaso() != null) {
            tempoAtendimentoCasoService.salvaMarcacaoAtendimento(caso, null, atendente, Boolean.TRUE);
            return caso;
        }

        return null;
    }

	/**
	 * @param atendente
	 * @param factoryService
	 * @param casoService
	 * @param tempoAtendimentoCasoService
	 * @param caso
	 * @throws ServiceException
	 * @throws ValidationException 
	 */
	private void atualizarCasoAtendimento(Atendente atendente,ICasoService casoService,
			ITempoAtendimentoCasoService tempoAtendimentoCasoService, Caso caso)
			throws ServiceException, ValidationException {
		caso.setAtendente(atendente);
		caso.setFlagEmAtendimento(Boolean.TRUE);
		casoService.update(caso);

		Log log = new Log();
		log.setCaso(caso);
		log.setDescricao("Caso enviado para o atendente: " + atendente.getLogin());
		log.setConfiguracaoFila(caso.getConfiguracaoFila());
		logService.saveLogAnexos(log);

		if (tempoAtendimentoCasoService != null) {
			tempoAtendimentoCasoService.salvaMarcacaoAtendimento(caso, null, atendente, Boolean.TRUE);
		}
	}

    private Caso buscaCasoAgendadoFila(Atendente atendente) throws ServiceException, ValidationException {
        try {

            List<ConfiguracaoFila> configuracaoFilaList = configuracaoFilaService.buscaProximaFilaAtendimentoAtendente(atendente);

            Caso caso = casoService.buscaProximoCasoAgendadoFila(configuracaoFilaList);

            if (caso == null) {
                return null;
            }

            caso.setAtendente(atendente);
            caso.setFlagEmAtendimento(Boolean.TRUE);
            casoService.update(caso);
            logService.saveLog(caso, "Caso enviado para o atendente: " + atendente.getLogin());

            return caso;
        } catch (ServiceException e) {
            throw new ServiceException("Erro ao buscar o Caso Agendado.",e);
        }
    }

    /**
     * Retorna o Caso a ser atendido pelo usuário. 
     * Se não for encontrado nenhum caso para ser atendido o retorno será null. Quem estiver solicitando um caso
     * deve solicitar novamente em alguns segundos.
     * @param configuracaoFila
     * @return
     * @throws ServiceException
     */
    private Caso retornaProximoCasoFilaAtendente(Atendente atendente) throws ServiceException {
        ConfiguracaoFila configuracaoFila = null;
        Integer bufferCasoParametro = 0;
        try {
            
            //Verifica qual a proxima fila de atendimento do atendente.
            List<ConfiguracaoFila> configuracaoFilaList = configuracaoFilaService.buscaProximaFilaAtendimentoAtendente(atendente);
            //Este for esta implementado para garantir que se não existir nenhum caso na fila de maior prioridade o sistema irá
            //pegar um caso em uma fila de menor prioridade.
            for (ConfiguracaoFila configuracaoFilaItem : configuracaoFilaList) {
                configuracaoFila = configuracaoFilaService.findByPk(configuracaoFilaItem);
                BufferCaso bufferCaso = ThreadAtualizaBufferFila.getBufferCaso(configuracaoFila);
                //Será iniciada a Thread que irá atualizar o buffer.
                //Se o atendente não existe no buffer é criado um novo registro
                if (bufferCaso == null) {
                    ThreadAtualizaBufferFila.addFilaBuffer(configuracaoFila);
                    bufferCaso = ThreadAtualizaBufferFila.getBufferCaso(configuracaoFila);
                }

                Integer casoId = bufferCaso.poll();

                try {
                    //Retorna os casos para serem adicionados na consulta.
                    bufferCasoParametro = Integer.valueOf(parametroGBOService.findByParam("bufferatendimento").getValor());
                } catch (NumberFormatException e1) {
                    bufferCasoParametro = 2;
                } catch (ServiceException e1) {
                    bufferCasoParametro = 2;
                }

                if (casoId != null) {
                    //Se o atendente já existe no buffer é iniciada a thread para atualizar o buffer e o caso que estava no buffer é retornado.
                    //Dessa forma o atendente não necessita ficar esperando que a busca seja feita, sempre terá um caso para ser atendido.
                	ParametroGBO param = parametroGBOService.findByParam(Constantes.FLAG_AUTO_ASSOCIAR_CASOS_MESMO_CLIENTE);
                	Caso caso = null; Integer qtdCaso = 0;
                	
                	if(param != null && Boolean.valueOf(param.getValor())){
                		/*
                		 * Busca todos os casos pendentes do mesmo cliente, que estejam em uma das filas configuradas para o atendente
                		 */
                		List<Caso> todoscasos = casoService.buscarTodosCasosPendentesDoCliente(atendente, casoId);
            			
            			for (Caso cso : todoscasos) {
            				
							if (cso.getIdCaso().equals(casoId)) {
								caso = cso;
								
							} else {
								enviarCasoParaAtendente(atendente, cso);
							}
						}
            			
            			qtdCaso = todoscasos.size();
                		
                	} else {
                		caso = new Caso();
                		caso.setPK(casoId);
                		caso = casoService.findByPk(caso);
                		
                		qtdCaso = 1;
                	}
                	
                	// Verificando se o caso está sendo atendido por outro usuário.
                    if (caso != null &&  (caso.getAtendente() == null || caso.getAtendente().getIdAtendente() == null)) {

                        atualizarCasoAtendimento(atendente, casoService,null, caso);

                        EquipeFila equipeFila = new EquipeFila();
                        equipeFila.setEquipe(atendente.getEquipe());
                        equipeFila.setConfiguracaoFila(configuracaoFila);

                        List<EquipeFila> equipeFilaList = equipeFilaService.findByExample(equipeFila);

                        if (equipeFilaList != null && equipeFilaList.size() > 0) {
                            equipeFila = equipeFilaList.get(0);
                            equipeFila.setQuantidadeCasoAtendido(equipeFila.getQuantidadeCasoAtendido() + qtdCaso);
                            equipeFilaService.update(equipeFila);
                        }
                        
                        iniciaBufferFila(configuracaoFila, bufferCasoParametro);
                        return caso;
                    }
                    
                } else {
                    iniciaBufferFila(configuracaoFila, bufferCasoParametro);
                }
            } 
        } catch(Exception ex) {
            throw new ServiceException("Erro ao buscar um caso para o atendente na fila.", ex);
        }
        return null;
    }

	private void enviarCasoParaAtendente(Atendente atendente, Caso caso) throws ServiceException,ValidationException {
		// Verificando se o caso está sendo atendido por outro usuário.
		if (caso != null && (caso.getAtendente() == null || caso.getAtendente().getIdAtendente() == null)) {
			caso.setAtendente(atendente);
			casoService.update(caso);

			Log log = new Log();
			log.setCaso(caso);
			log.setDescricao("Caso enviado para o atendente: " + atendente.getLogin());
			log.setConfiguracaoFila(caso.getConfiguracaoFila());
			logService.saveLogAnexos(log);
		}
	}

    public void iniciaBufferFila(ConfiguracaoFila configuracaoFila, Integer bufferCasoParametro) {
        BufferCaso bufferCaso = ThreadAtualizaBufferFila.getBufferCaso(configuracaoFila);
        if (bufferCaso == null) {
            //Se a fila não existe no buffer é criado um novo registro
            ThreadAtualizaBufferFila.addFilaBuffer(configuracaoFila);
        }
        
        //Add a fila para que o buffer da mesma seja refeito
        ThreadAtualizaBufferFila.addConfiguracaoFilaRefazerBuffer(configuracaoFila, bufferCasoParametro);
    }
}
