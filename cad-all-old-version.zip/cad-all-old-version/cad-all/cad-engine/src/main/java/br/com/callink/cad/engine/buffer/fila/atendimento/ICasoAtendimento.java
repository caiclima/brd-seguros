package br.com.callink.cad.engine.buffer.fila.atendimento;

import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

public interface ICasoAtendimento {

	Caso solicitaCasoAtendenteAtendimento(Atendente atendente) throws ServiceException, ValidationException;

	void iniciaBufferFila(ConfiguracaoFila configuracaoFila, Integer bufferCasoParametro);
}
