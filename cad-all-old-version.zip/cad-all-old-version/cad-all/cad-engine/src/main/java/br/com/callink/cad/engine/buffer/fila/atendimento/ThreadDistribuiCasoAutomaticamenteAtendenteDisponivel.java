package br.com.callink.cad.engine.buffer.fila.atendimento;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.AtendenteStatus;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.ParametroGBO;
import br.com.callink.cad.pojo.StatusAtendente;
import br.com.callink.cad.repository.MensagemToolbar;
import br.com.callink.cad.service.IAtendenteService;
import br.com.callink.cad.service.IAtendenteStatusService;
import br.com.callink.cad.service.ICasoService;
import br.com.callink.cad.service.IGboToolbarBusinessAppService;
import br.com.callink.cad.service.IParametroGBOService;
import br.com.callink.cad.service.IStatusAtendenteService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.util.Constantes;

public class ThreadDistribuiCasoAutomaticamenteAtendenteDisponivel extends Thread {
	private static boolean executa;
	private static final Logger LOGGER = Logger.getLogger(ThreadDistribuiCasoAutomaticamenteAtendenteDisponivel.class.getName());

	private ICasoAtendimento casoAtendimento;
	private IParametroGBOService parametroGBOService;
	private ICasoService casoService;
	private IGboToolbarBusinessAppService gboToolbarBusinessAppService;
	private IStatusAtendenteService statusAtendenteService;
	private IAtendenteStatusService atendenteStatusService;
	private IAtendenteService atendenteService;
	
	
	public ThreadDistribuiCasoAutomaticamenteAtendenteDisponivel(IParametroGBOService parametroGBOService, ICasoService casoService,
			IGboToolbarBusinessAppService gboToolbarBusinessAppService, IStatusAtendenteService statusAtendenteService,
			IAtendenteStatusService atendenteStatusService, IAtendenteService atendenteService, 
			ICasoAtendimento casoAtendimento) {

		this.parametroGBOService= parametroGBOService;
		this.casoService= casoService;
		this.gboToolbarBusinessAppService= gboToolbarBusinessAppService;
		this.statusAtendenteService= statusAtendenteService;
		this.atendenteStatusService = atendenteStatusService;
		this.atendenteService= atendenteService;
		this.casoAtendimento = casoAtendimento;
	}
	
	@Override
	public void run() {
		LOGGER.info("ThreadDistribuiCasoAutomaticamenteAtendenteDisponivel iniciada");

		ThreadDistribuiCasoAutomaticamenteAtendenteDisponivel.setExecuta(Boolean.TRUE);
		ParametroGBO parametroGBO = null;
		ParametroGBO portaServer = null;
		ParametroGBO ipServer = null;
		ParametroGBO urlTratativa = null;
		ParametroGBO statusDisponivel = null;
		
		try {
			parametroGBO = parametroGBOService.findByParam(Constantes.FLAG_INICIA_BAPP_TOOLBAR);
			portaServer = parametroGBOService.findByParam(Constantes.PORTA_TOOLBAR_SERVER);
			ipServer = parametroGBOService.findByParam(Constantes.IP_TOOLBAR_SERVER);
			urlTratativa = parametroGBOService.findByParam(Constantes.URL_TRATATIVA_GBO);
			statusDisponivel = parametroGBOService.findByParam(Constantes.ATENDENTE_STATUS_DISPONIVEL);

			sleep(66000);
		} catch (InterruptedException ex) {
			LOGGER.log(Level.SEVERE, null, ex);
		} catch (ServiceException e) {
			LOGGER.log(Level.SEVERE, null, e);
		}

		Boolean validaIniciaBapp;
		try {
			validaIniciaBapp = parametroGBO != null && !parametroGBO.getValor().isEmpty() ? Boolean.valueOf(parametroGBO.getValor()) : Boolean.FALSE;
		} catch (Exception e) {
			validaIniciaBapp = Boolean.FALSE;
		}

		if (validaIniciaBapp) {
			while (executa) {
				try {
					distribuiCasos(portaServer, ipServer, urlTratativa, statusDisponivel);
				} catch (Exception e) {
					LOGGER.log(Level.SEVERE, "Erro ao distribuir casos automaticamente.", e);
				}
				try {
					sleep(10000);
				} catch (InterruptedException ex) {
					LOGGER.log(Level.SEVERE, null, ex);
				}
			}
		} else {
			LOGGER.log(Level.INFO, "Distribuição de casos não foi iniciada porque o parametro está configurado como false ou não foi informado corretamente.");
		}

		LOGGER.info("ThreadDistribuiCasoAutomaticamenteAtendenteDisponivel finalizada");
	}
	
	private void distribuiCasos(ParametroGBO portaServer, ParametroGBO ipServer, ParametroGBO urlTratativa, ParametroGBO statusDisponivel) throws ServiceException, ValidationException {
        
        ParametroGBO tempoSolicitarCaso = parametroGBOService.findByParam(Constantes.TEMPO_DISPONIVEL_ENVIA_CASO);

        
        Integer tempoStatus;
        
        if (tempoSolicitarCaso == null || tempoSolicitarCaso.getIdParametroGBO() == null || tempoSolicitarCaso.getValor() == null || tempoSolicitarCaso.getValor().isEmpty()) {
        	tempoStatus = 120;
        } else {
        	tempoStatus = Integer.valueOf(tempoSolicitarCaso.getValor());
        }
        
        AtendenteStatus atendenteStatus = new AtendenteStatus();
        atendenteStatus.setIdAtendenteStatus(Integer.valueOf(statusDisponivel.getValor()));
        
        atendenteStatus = atendenteStatusService.findByPk(atendenteStatus);
        
        if (atendenteStatus == null || atendenteStatus.getIdAtendenteStatus() == null) {
        	LOGGER.log(Level.SEVERE,"Não foi possível buscar o status configurado nos parametros.");
        	throw new ServiceException("Não foi possível buscar o status configurado nos parametros.");
        }
        
        List<StatusAtendente> statusAtendenteList = statusAtendenteService.buscaStatusAtendenteByStatus(atendenteStatus, tempoStatus);
        
        for (StatusAtendente statusAtendente : statusAtendenteList) {
        	Caso caso = null;
        	Atendente atendente = atendenteService.findByPk(statusAtendente.getIdAtendente());
        	List<Caso> casoList = casoService.atendentePossuiCasoEmAtendimento(atendente.getLogin());
        	StringBuilder stringBuilder = new StringBuilder();
        	stringBuilder.append("Caso enviado para atendimento: ");

        	MensagemToolbar mensagemToolbar = new MensagemToolbar();
        	mensagemToolbar.setUsuarioSSOEmitente("GBO");
        	mensagemToolbar.setUsuarioSSORemetente(atendente.getLogin());
        	
        	if (casoList != null && !casoList.isEmpty()) {
        		stringBuilder.append(casoList.get(0).getIdExterno());
        		mensagemToolbar.setMensagem(stringBuilder.toString());
        		
        		gboToolbarBusinessAppService.enviaPaginaTrativa(ipServer.getValor(), portaServer.getValor(), atendente.getLogin(), urlTratativa.getValor());
        		gboToolbarBusinessAppService.enviaMensagemToolbar(mensagemToolbar);
        		
        		LOGGER.log(Level.INFO,stringBuilder.toString());
        	} else {
        	
        		caso = casoAtendimento.solicitaCasoAtendenteAtendimento(atendente);
        		
        		if (caso != null) {
        			stringBuilder.append(caso.getIdExterno());
        			mensagemToolbar.setMensagem(stringBuilder.toString());
        			
        			gboToolbarBusinessAppService.enviaPaginaTrativa(ipServer.getValor(), portaServer.getValor(), atendente.getLogin(), urlTratativa.getValor());
        			gboToolbarBusinessAppService.enviaMensagemToolbar(mensagemToolbar);
        			
        			LOGGER.log(Level.INFO,stringBuilder.toString());
        		}
        	}
        }
        
	}

	public static final void setExecuta(boolean executa) {
		ThreadDistribuiCasoAutomaticamenteAtendenteDisponivel.executa = executa;
	}
	
}
