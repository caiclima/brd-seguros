package br.com.callink.cad.engine.buffer.marcacao;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.ParametroGBO;
import br.com.callink.cad.service.ICasoService;
import br.com.callink.cad.service.IParametroGBOService;
import br.com.callink.cad.service.IStatusAtendenteService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.repository.ControleStatusAtendentes;
import br.com.callink.cad.util.Constantes;

/**
 *
 * @author brunomt
 */
public class ThreadFinalizaStatusAtendenteInativo extends Thread {
    private static boolean executa;
    private static final Logger LOGGER = Logger.getLogger(ThreadFinalizaStatusAtendenteInativo.class.getName());
    
    private IParametroGBOService parametroGBOService;
    
    private ICasoService casoService;
    
    private IStatusAtendenteService statusAtendenteService;
    
    public ThreadFinalizaStatusAtendenteInativo(IParametroGBOService parametroGBOService, ICasoService casoService
    		,IStatusAtendenteService statusAtendenteService) {
		this.parametroGBOService = parametroGBOService;
		this.casoService = casoService;
		this.statusAtendenteService= statusAtendenteService;
	}
    
    
	@Override
	public void run() {
		try {
			sleep(66000);
		} catch (InterruptedException ex) {
			Logger.getLogger(ThreadFinalizaStatusAtendenteInativo.class.getName()).log(Level.SEVERE, null, ex);
		}

		LOGGER.info("ThreadFinalizaStatusAtendenteInativo iniciada");
		
		ParametroGBO parametroGBO = null;

		try {
			parametroGBO = parametroGBOService.findByParam(Constantes.TEMPO_EXPIRA_SESSION);
		} catch (ServiceException ex) {
			Logger.getLogger(ThreadFinalizaStatusAtendenteInativo.class.getName()).log(Level.SEVERE, null, ex);
		}
		
		ThreadFinalizaStatusAtendenteInativo.setExecuta(Boolean.TRUE);
		while (executa) {
			try {
				ControleStatusAtendentes.atualizaMap();

				List<Atendente> listaAtendente = ControleStatusAtendentes.validaFinalizaStatusAtendente(parametroGBOService.getDataBanco(),
						Integer.valueOf(parametroGBO.getValor()));

				casoService.atualizaFlagEmAtendimentoParaFalse(listaAtendente);
				statusAtendenteService.finalizaStatusAtendenteSemDataFim();

				sleep(10000);
			} catch (Exception ex) {
				try {
					LOGGER.log(Level.SEVERE, "", ex);
					sleep(10000);
				} catch (InterruptedException ex1) {
					LOGGER.log(Level.SEVERE, "", ex1);
				}
			}
		}
		
		LOGGER.info("ThreadFinalizaStatusAtendenteInativo finalizada");
	}
	public static final boolean isExecuta() {
		return executa;
	}
	public static final void setExecuta(boolean executa) {
		ThreadFinalizaStatusAtendenteInativo.executa = executa;
	}
    
    
}
