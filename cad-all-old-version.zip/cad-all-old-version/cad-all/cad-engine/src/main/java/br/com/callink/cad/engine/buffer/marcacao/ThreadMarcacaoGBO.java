package br.com.callink.cad.engine.buffer.marcacao;

import java.util.logging.Level;
import java.util.logging.Logger;

import br.com.callink.cad.pojo.AtendimentoCaso;
import br.com.callink.cad.pojo.HistoricoDadosCaso;
import br.com.callink.cad.pojo.Log;
import br.com.callink.cad.pojo.LogLigacoes;
import br.com.callink.cad.pojo.TempoAtendimentoCaso;
import br.com.callink.cad.repository.MarcacaoLogs;
import br.com.callink.cad.service.IAtendimentoCasoService;
import br.com.callink.cad.service.IHistoricoDadosCasoService;
import br.com.callink.cad.service.ILogLigacoesService;
import br.com.callink.cad.service.ILogService;
import br.com.callink.cad.service.ITempoAtendimentoCasoService;
import br.com.callink.cad.service.exception.ServiceException;

/**
 * Thread responsável por gravar os logs no banco de dados.
 * @author brunomt
 *
 */
public class ThreadMarcacaoGBO extends Thread {
	
	private Logger logger = Logger.getLogger(ThreadMarcacaoGBO.class.getName());
	private static boolean executa;
	private ILogService logService;
	private IAtendimentoCasoService atendimentoCasoService;
	private ITempoAtendimentoCasoService tempoAtendimentoCasoService;
    private IHistoricoDadosCasoService historicoDadosCasoService;
	private ILogLigacoesService logLigacoesService;
	
	public ThreadMarcacaoGBO(ILogService logService, IAtendimentoCasoService atendimentoCasoService,
			ITempoAtendimentoCasoService tempoAtendimentoCasoService,IHistoricoDadosCasoService historicoDadosCasoService,
			ILogLigacoesService logLigacoesService) {
		
		this.logService = logService;
		this.atendimentoCasoService = atendimentoCasoService;
		this.tempoAtendimentoCasoService = tempoAtendimentoCasoService;
        this.historicoDadosCasoService = historicoDadosCasoService;
		this.logLigacoesService = logLigacoesService;
	}
	
	/**
	 * Exe...
	 */
	public void run() {
		/**
		 * Thread nunca para de executar
		 */
		try {
			Thread.sleep(Integer.valueOf(60000));
		} catch (InterruptedException ex) {
			Logger.getLogger(ThreadMarcacaoGBO.class.getName()).log(Level.SEVERE, null, ex);
		}

		logger.info("ThreadMarcacaoGBO iniciada");
		
		ThreadMarcacaoGBO.setExecuta(Boolean.TRUE);
		while (executa) {
			try {
				insereLogs();
			}
			// Se acontecer qualquer exception iremos gravar o log e aguardar
			// alguns segundos para tentar
			// novamente. Pode ser implementado uma forma de gravar a
			// serialização e gravação em arquivos
			// desses logs caso seja necessário recuperar os dados.
			catch (Exception e) {
				try {
					sleep(1000);
					logger.log(Level.SEVERE, "", e);
				} catch (InterruptedException e1) {
					logger.log(Level.SEVERE, "", e);
				}
			}
		}

		logger.info("ThreadMarcacaoGBO finalizada");
	}
	
	private synchronized void insereLogs() throws ServiceException {
        boolean logLog = true;
        boolean logAtendimenlog = true;
        boolean logTempoAtend = true;
        boolean logHistCaso = true;
        boolean logLigacoesLog = true;

        Log log = MarcacaoLogs.pollLog();
        if (log != null) {
            try {
                logService.save(log);
                logLog = false;
            } catch (ServiceException ex) {
                logger.log(Level.SEVERE, "", ex);
            } catch (Exception ex) {
                logger.log(Level.SEVERE, "", ex);
//                 MarcacaoLogs.offer(log);
            }
        }

        AtendimentoCaso atendimentoCaso = MarcacaoLogs.pollAtendimentoCaso();
        if (atendimentoCaso != null) {
            try {
                atendimentoCasoService.save(atendimentoCaso);
                logAtendimenlog = false;
            } catch (ServiceException ex) {
                logger.log(Level.SEVERE, "", ex);
            } catch (Exception ex) {
                logger.log(Level.SEVERE, "", ex);
//                MarcacaoLogs.offer(atendimentoCaso);
            }
        }

        TempoAtendimentoCaso tempoAtendimentoCaso = MarcacaoLogs.pollTempoAtendimentoCaso();
        if (tempoAtendimentoCaso != null) {
            try {
                tempoAtendimentoCasoService.save(tempoAtendimentoCaso);
                logTempoAtend = false;
            } catch (ServiceException ex) {
                logger.log(Level.SEVERE, "", ex);
            } catch (Exception ex) {
                logger.log(Level.SEVERE, "", ex);
            }
        }
            
        HistoricoDadosCaso historicoDadosCaso = MarcacaoLogs.pollHistoricoDadosCaso();
        if (historicoDadosCaso != null) {
            try {
                historicoDadosCasoService.save(historicoDadosCaso);
                logHistCaso = false;
            } catch (ServiceException ex) {
                logger.log(Level.SEVERE, "", ex);
            } catch (Exception ex) {
                logger.log(Level.SEVERE, "", ex);
            }
        }

        LogLigacoes logLigacoes = MarcacaoLogs.pollLogLigacoes();
        if (logLigacoes != null) {
            try {
                logLigacoesService.save(logLigacoes);
                logLigacoesLog = false;
            } catch (ServiceException ex) {
                logger.log(Level.SEVERE, "", ex);
            } catch (Exception ex) {
                logger.log(Level.SEVERE, "", ex);
            }
        }

        if (logLog && logAtendimenlog && logTempoAtend && logHistCaso && logLigacoesLog) {
            try {
                sleep(1000);
            } catch (InterruptedException e) {
                Logger.getLogger(ThreadMarcacaoGBO.class.getName()).log(Level.SEVERE, null, e);
            }
        }
	}

	public static final boolean isExecuta() {
		return executa;
	}

	public static final void setExecuta(boolean executa) {
		ThreadMarcacaoGBO.executa = executa;
	}
	
}
