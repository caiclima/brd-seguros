package br.com.callink.cad.engine.buffer.marcacao;

import br.com.callink.cad.pojo.StatusAtendente;
import br.com.callink.cad.service.IStatusAtendenteService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.service.repository.ControleStatusAtendentes;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author brunomt
 */
public class ThreadStatusAtendente extends Thread {
	
	private static boolean executa;
    private IStatusAtendenteService statusAtendenteService;
    private static final Logger LOGGER = Logger.getLogger(ThreadStatusAtendente.class.getName());
    
    public ThreadStatusAtendente(IStatusAtendenteService statusAtendenteService) {
		this.statusAtendenteService= statusAtendenteService;
	}
    
    @Override
	public void run() {
		// Espera o servidor subir
		try {
			Thread.sleep(Integer.valueOf(71000));
		} catch (InterruptedException ex) {
			Logger.getLogger(ThreadMarcacaoGBO.class.getName()).log(Level.SEVERE, null, ex);
		}

		LOGGER.info("ThreadStatusAtendente iniciada");
		
		ThreadStatusAtendente.setExecuta(Boolean.TRUE);
		while (executa) {
			try {
				// Insere o status atendente.
				insereStatusAtendente();
				// Para a thread não ficar rodando sem parar, vamos aguardar algum tempo
			} catch (Exception ex) {
				try {
					LOGGER.log(Level.SEVERE, "", ex);
					sleep(2000);
				} catch (InterruptedException ex1) {
					LOGGER.log(Level.SEVERE, "", ex1);
				}
			}
		}
		
		LOGGER.info("ThreadStatusAtendente finalizada");
	}
    
    private synchronized void insereStatusAtendente() throws ServiceException, ValidationException {
        StatusAtendente statusAtendente = ControleStatusAtendentes.pollStatusAtendente();
        
        if (statusAtendente != null) {
            statusAtendenteService.save(statusAtendente);
        } else {
        	try {
				sleep(2000);
			} catch (InterruptedException e) {
				LOGGER.log(Level.SEVERE, "", e);
			}
        }
        
    }

	public static final boolean isExecuta() {
		return executa;
	}

	public static final void setExecuta(boolean executa) {
		ThreadStatusAtendente.executa = executa;
	}
}
