package br.com.callink.cad.engine.command;

/**
 * @author rafaelps
 */
public interface ICommandScreen {

	/**
	 * executa o comando
	 */
	void execute();

	/**
	 * deve ser invocado pelo metodo como ultima linha do metodo execute() do
	 * managedbean que representa o comando e quando o popup for
	 * fechado/escondido , sendo que como o escopo do(s) managedbean devem ser
	 * viewscope para funcionamento apropriado, devido a este fato o
	 * desenvolvedor deve destruir os valores das variaveis de instancia ..
	 */
	void cleanData();
}
