package br.com.callink.cad.engine.command.executor;

import java.util.List;
import java.util.Map;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;
import br.com.callink.cad.dao.IAcaoDAO;
import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.pojo.AcaoComando;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.Comando;
import br.com.callink.cad.pojo.ParametroComando;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.service.ICasoService;
import br.com.callink.cad.service.IComandoService;
import br.com.callink.cad.service.IParametroComandoService;
import br.com.callink.cad.service.IStatusAtendenteService;
import br.com.callink.cad.service.command.ICommand;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.service.impl.GenericGboService;
import br.com.callink.cad.util.Constantes;
import br.com.callink.cad.util.GenerateInstanceService;
import br.com.callink.coreutils.util.collection.CollectionUtils;

/**
 * Classe responsável pela execução do comando deve ser herdada de um projeto
 * gbo-xpto-service
 * 
 * @author rafaelps
 */
@Stateless
public abstract class AbstractGBOExecutorCommandService extends GenericGboService<Acao, IAcaoDAO> implements IExecutorCommandService {

	private static final long serialVersionUID = 5270597821330782111L;
	
	
	@EJB
	private IParametroComandoService parametroComandoService;
	@EJB
	private ICasoService casoService;
	@EJB
	private IComandoService comandoService;
	@EJB
	private IStatusAtendenteService statusAtendenteService;
	
	
	@Inject
	private IAcaoDAO acaoDAO;
	
	@Override
	protected IAcaoDAO getDAO() {
		return acaoDAO;
	}
	
	@Override
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void execute(Map<String, Object> parametros) throws ServiceException, ValidationException {
		try {
			validateParams(parametros);
			List<AcaoComando> acoesComando = getDAO().findByAcaoAcaoComandoAtivos((Acao) parametros.get("acao"));

			Caso caso = (Caso) parametros.get("caso");
			
			if(casoService.validaSeCasoEstaSendoProcessadoPeloSpa(caso)) {
				throw new ValidationException("O caso está no momento sendo processado. Aguarde um minuto e tente realizar a operação novamente.");
			}
			
			if (!casoService.validaStatusCaso(caso)) {
				throw new ValidationException("Os dados do caso estão desatualizados. Favor recarregar o caso clicando em Atender Caso e tentar novamente.");
			}
			
			if (acoesComando != null) {
				// busca informações do(s) comando(s) pois estão só com o id
				// preenchido ..

				for (AcaoComando acaoComando : acoesComando) {
					
					acaoComando.setComando(comandoService.findByPk(acaoComando.getComando()));
					
					Comando comando = acaoComando.getComando();

					if (comando != null) {
						try {
							Object cmdObj = GenerateInstanceService.getInstanceObject(comando.getBeanName());
							if (cmdObj == null) {
								throw new ServiceException("Comando " + comando.getBeanName() + " não encontrado!");
							} else {
								if (cmdObj instanceof ICommand) {
									ICommand cmd = (ICommand) cmdObj;
									
									List<ParametroComando> params = parametroComandoService.buscaPorComando(comando);
									
									if(! CollectionUtils.isNullOrEmpty(params)){
										for (ParametroComando parametroComando : params) {
											parametros.put(parametroComando.getNome(), parametroComando.getValor());
										}	
									}
									
									parametros.put(Constantes.COMANDO_EM_EXECUCAO, comando);
                                    parametros.put(Constantes.ACAO, acaoComando.getAcao());
									cmd.execute(parametros);

								} else {
									throw new ServiceException("O Comando " + comando.getBeanName() + " deve implementar a interface "
											+ ICommand.class.getName());
								}
							}

						 }catch (ValidationException e) {
							throw new ValidationException(e.getMessage(), e);
						} catch (Exception e) {
							throw new ServiceException(e);
						}
					}
				}
                                
                Boolean naoSalvaStatus = parametros.get("naoSalvaStatus") == null ? Boolean.FALSE : (Boolean) parametros.get("naoSalvaStatus");
                if (!naoSalvaStatus) {
                    statusAtendenteService.salvaStatusAtendimentoDisponivel(caso.getAtendente());
                }
			}
		} catch (DataException e) {
			throw new ServiceException(e);
		}
	}

	private void validateParams(Map<String, Object> parametros) {
		if (parametros == null) {
			throw new IllegalArgumentException("parametros não pode ser nulo!");
		}
		if (!parametros.containsKey("acao")) {
			throw new IllegalArgumentException("Parametro 'acao' obrigatório!");
		}
		if (parametros.get("acao") == null) {
			throw new IllegalArgumentException("Parametro 'acao' não pode ser nulo!");
		}
	}
}
