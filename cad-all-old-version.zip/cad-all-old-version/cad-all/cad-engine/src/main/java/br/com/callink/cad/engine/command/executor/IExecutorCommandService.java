package br.com.callink.cad.engine.command.executor;

import br.com.callink.cad.dao.IAcaoDAO;
import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.service.IGenericGboService;
import br.com.callink.cad.service.command.ICommand;

public interface IExecutorCommandService extends IGenericGboService<Acao, IAcaoDAO>, ICommand {
}
