package br.com.callink.cad.engine.command.impl;

import java.util.Map;

import javax.ejb.Stateless;
import javax.inject.Inject;

import br.com.callink.cad.dao.IAcaoDAO;
import br.com.callink.cad.engine.command.executor.IExecutorCommandService;
import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.service.impl.GenericGboService;

@Stateless
public class CommandExecutor extends GenericGboService<Acao, IAcaoDAO> implements  IExecutorCommandService{

	private static final long serialVersionUID = 1L;

	@Inject
	private IAcaoDAO acaoDAO;
	
	@Override
	public void execute(Map<String, Object> parametros)
			throws ServiceException, ValidationException {
		
	}

	@Override
	protected IAcaoDAO getDAO() {
		return acaoDAO;
	}

}
