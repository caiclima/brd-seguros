package br.com.callink.cad.engine.email;


public interface IEnvioEmailEngine {

	/*
	 * Envia todos os emails que estão na lista e que ainda não foram enviados.
	 */
	void run();

}
