package br.com.callink.cad.engine.email;


public interface IRecebeEmailEngine {

	void run();

}
