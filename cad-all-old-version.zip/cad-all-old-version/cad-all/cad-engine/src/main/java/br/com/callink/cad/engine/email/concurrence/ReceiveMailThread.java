package br.com.callink.cad.engine.email.concurrence;

import javax.mail.AuthenticationFailedException;

import org.apache.log4j.Logger;

import br.com.callink.cad.pojo.ConfiguracaoEmail;
import br.com.callink.cad.service.IEmailService;
import br.com.callink.cad.util.ReceiveMail;

public class ReceiveMailThread implements Runnable {
	
	private static final Logger LOGGER = Logger.getLogger(ReceiveMailThread.class);
	
	private IEmailService emailService;
	private ConfiguracaoEmail configEmail;
	private String name;
		 
    public ReceiveMailThread(String name, IEmailService emailService, ConfiguracaoEmail configEmail) {
    	this.name = name;
        this.emailService = emailService;
        this.configEmail = configEmail;
    }
    
    @Override
    public void run() {
    	try {
    		LOGGER.info("Executando recebimento de email para dominio: ".concat(name));
    		emailService.salvaReceivedMails(new ReceiveMail().fetchEmails(configEmail));
    		LOGGER.info("Execução para o dominio: ".concat(name).concat(" finalizada."));
    	} catch (AuthenticationFailedException e) {
    		LOGGER.error("Erro ao autenticar na conta de dominio: " + configEmail.getEmail(), e);
    	} catch (Exception e) {
    		LOGGER.error("Erro ao executar task de recebimento de email", e);
    	} 
    }
    
    @Override
    public String toString() {
        return this.name;
    }
 
}
