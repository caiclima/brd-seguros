package br.com.callink.cad.engine.email.concurrence.handler;

import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadPoolExecutor;

import org.apache.log4j.Logger;

public class ReceiveMailExecutionHandlerImpl implements RejectedExecutionHandler {
	
	private static final Logger LOG = Logger.getLogger(ReceiveMailExecutionHandlerImpl.class);
	
	@Override
    public void rejectedExecution(Runnable runnable, ThreadPoolExecutor executor) {
		LOG.warn("Leitura da caixa de email com identificação " + runnable.toString() + " foi rejeitada.");
    }
}
