/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.engine.email.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import br.com.callink.cad.engine.email.IEnvioEmailEngine;
import br.com.callink.cad.pojo.Anexo;
import br.com.callink.cad.pojo.ConfiguracaoEmail;
import br.com.callink.cad.pojo.Email;
import br.com.callink.cad.service.IAnexoService;
import br.com.callink.cad.service.IConfiguracaoEmailService;
import br.com.callink.cad.service.IEmailService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.util.EmailException;
import br.com.callink.cad.util.SendEmail;

/**
 *
 * @author Luiz Gustavo (luizgf@swb.com.br)
 */
@Stateless
public class EnvioEmailEngine implements IEnvioEmailEngine {

    private static final Logger LOGGER = Logger.getLogger(EnvioEmailEngine.class.getName());
    
    @EJB
    private IEmailService emailService;
    @EJB
    private IAnexoService anexoService;
    @EJB
    private IConfiguracaoEmailService configuracaoEmailService;
    
    private List<ConfiguracaoEmail> configuracaoEmails;
    private ConfiguracaoEmail configuracaoEmailPrincipal;
    
    public EnvioEmailEngine() {
    }

    @Override
    public void run() {

        SendEmail sendEmail = null;
        
        try {
            sendEmail = new SendEmail();

            List<Email> emailsEnvioPendente = emailService.findEmailsEnvioPendente();
            List<Integer> remetentes = new ArrayList<Integer>();
            
            for(Email email: emailsEnvioPendente) {
            	if(email.getConfiguracaoEmail() != null) {
            		remetentes.add(email.getConfiguracaoEmail().getIdConfiguracaoEmail());
            	}
            }
            
            if(!remetentes.isEmpty()) {
            	configuracaoEmails = configuracaoEmailService.findByIds(remetentes);
            }
            configuracaoEmailPrincipal = buscarConfiguracaoEmailPrincipal();
            if (!emailsEnvioPendente.isEmpty()) {
                for (Email email : emailsEnvioPendente) {

                    Integer tentativasEnvio = 0;
                    //enqto a FlagEnvioPendente estiver ligada, tentar enviar
                    while (email.getFlagEnvioPendente()) {
                        try {
                            //se ja houveram mais de 5 tentativas de enviar o email..
                            if (tentativasEnvio > 5) {
                                email.setFlagErroEnvio(Boolean.TRUE);
                                emailService.update(email);
                                //seta essa flag para sair do laço
                                email.setFlagEnvioPendente(Boolean.FALSE);
                                throw new ServiceException("Email excedeu tentativas de envio. ID Email: " + email.getIdEmail());
                            }
                            
                            List<Anexo> anexos = new ArrayList<Anexo>();
                            
                            //tentando enviar o email
                            if(email.getGrupoAnexo()!= null 
                            		&& email.getGrupoAnexo().getIdGrupoAnexo()!= null 
                            		&& email.getGrupoAnexo().getIdGrupoAnexo()!= 0 ){
                            	
                            	anexos = anexoService.buscaPorGrupoAnexo(email.getGrupoAnexo());
                                if(anexos != null && anexos.size()>0){
                                    anexoService.carregaBytesAnexo(anexos);
                                }
                            }
                            Properties conf = buscarConfiguracaoEmail(email.getConfiguracaoEmail());
                            sendEmail.send(email, anexos, conf);
                            email.setFlagEnvioPendente(Boolean.FALSE);
                            email.setFlagErroEnvio(Boolean.FALSE);
                            emailService.update(email);
                            
                        } catch (EmailException ex) {
                            //caso haja erro no envio de email, começa a incrementar tentativas de envio
                            LOGGER.log(Level.SEVERE, "", ex);
                            tentativasEnvio++;
                        } 
                    }
                }
            }
        } catch (ServiceException ex) {
            LOGGER.log(Level.SEVERE, "", ex);
        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, "", ex);
        }
    }
    
    private Properties buscarConfiguracaoEmail(ConfiguracaoEmail configuracaoEmail) {
    	Properties properties = null;
    	if(configuracaoEmails != null && configuracaoEmail != null) {
	    	for(ConfiguracaoEmail ce: configuracaoEmails) {
	    		if(ce.getIdConfiguracaoEmail().equals(configuracaoEmail.getIdConfiguracaoEmail())) {
	    			properties = configuracaoEmailService.enviaEmailProperties(ce);
	    			break;
	    		}
	    	}
    	}
    	if(configuracaoEmailPrincipal != null && properties == null) {
    		properties = configuracaoEmailService.enviaEmailProperties(configuracaoEmailPrincipal);
    	} 
    	if(properties == null){
    		properties = emailService.enviaEmailProperties();
    	}
    	return properties;
    }
    
    private ConfiguracaoEmail buscarConfiguracaoEmailPrincipal() throws ServiceException {
    	ConfiguracaoEmail ce = new ConfiguracaoEmail();
		ce.setFlagAtivo(Boolean.TRUE);
		ce.setFlagPrincipal(Boolean.TRUE);
		List<ConfiguracaoEmail> list = configuracaoEmailService.findByExample(ce);
		if(list != null && !list.isEmpty()) {
			return list.get(0);
		}
		return null;
    }
}
