package br.com.callink.cad.engine.email.impl;

import java.util.List;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ejb.Asynchronous;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.mail.AuthenticationFailedException;
import javax.mail.MessagingException;

import br.com.callink.cad.engine.email.IRecebeEmailEngine;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.ConfiguracaoEmail;
import br.com.callink.cad.pojo.Email;
import br.com.callink.cad.pojo.GrupoAnexo;
import br.com.callink.cad.pojo.ParametroGBO;
import br.com.callink.cad.service.ICasoService;
import br.com.callink.cad.service.IEmailService;
import br.com.callink.cad.service.IParametroGBOService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.util.Constantes;
import br.com.callink.cad.util.ReceiveMail;

@Stateless
public class GenericRecebimentoEmail implements IRecebeEmailEngine{
	@EJB
	private ICasoService casoService;
	
	@EJB
	private IEmailService emailService;
	
	@EJB
	private IParametroGBOService paramService;
	
	private ReceiveMail receiveMail;
	
	private String diretorioAnexo;
	private String separadorInicial;
	private String separadorFinal;

	private final Logger LOGGER = getLogger();
	
	public GenericRecebimentoEmail(){
	}
	
	@Override
	public void run() {
		
		LOGGER.info("Task RecebeEmail - Iniciada");
		
		try{
			List<ConfiguracaoEmail> configsEmails = buscarConfigsEmails();
			
			processar(configsEmails);
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		LOGGER.info("Task RecebeEmail - Finalizada");
	}
	
	private void processar(List<ConfiguracaoEmail> configsEmails) {
		diretorioAnexo = buscarDiretorioAnexos();
		
		if(configsEmails == null || configsEmails.size() == 0){
			processar();
		}
		
		for (ConfiguracaoEmail configEmail : configsEmails) {
			try{
				processar(configEmail);
			}catch(Exception e){
				e.printStackTrace();
				LOGGER.warning("Erro ao processar recebimento de e-mail para o domínio: " + configEmail.getEmail() +
						"Motivo: " + e.getMessage());
			}
		}
	}

	@Asynchronous
	private void processar(ConfiguracaoEmail configEmail) throws ServiceException, MessagingException {
		try {
			receiveMail = new ReceiveMail();
			
			LOGGER.info("Executando recebimento de email para dominio ".concat(configEmail.getEmail()));
			List<Email> emails = receiveMail.fetchEmails(configEmail);

			processarEmails(emails);
			
			LOGGER.info("Execução para o dominio ".concat(configEmail.getEmail()).concat(" finalizada."));
		} catch (AuthenticationFailedException e) {
			e.printStackTrace();
			throw new ServiceException("Falha de autenticação. Verifique usuário e senha do domínio.");
		}
		
	}

	private void processarEmails(List<Email> emails) throws ServiceException {
		try{
			for (Email email : emails) {
				if(email.getAssunto() == null){
					continue;
				}
				
				salvarGrupoAnexo(email);
				
				String manifestacao = extrairManifestacaoAssunto(email.getAssunto());

				if(manifestacao != null){
					processarEmailComManifestacao(email, manifestacao);
				}else{
					processarEmailSemManifestacao(email);
				}
				
			}
			
		}catch(Exception e){
			throw new ServiceException("Erro ao processar e-mails. Motivo: " + e.getMessage(), e);
		}
		
	}

	protected void processarEmailComManifestacao(Email email, String manifestacao) throws ServiceException{
		try{
			Caso caso = casoService.buscarCasoPorIdExterno(manifestacao);
			
			email.setFlagPossuiCaso(caso != null);
			emailService.save(email);
			
			if(caso != null){
				associarEmailAoCaso(email, caso);
			}
			
		}catch(Exception e){
			throw new ServiceException("Erro ao processar e-mail com manifestação " + manifestacao 
					+ ". Motivo: " + e.getMessage(), e);
		}
	}

	protected void processarEmailSemManifestacao(Email email) throws ServiceException {
		email.setFlagPossuiCaso(Boolean.FALSE);
		try {
			emailService.save(email);
		} catch (ValidationException e) {
			throw new ServiceException("Erro ao salvar e-mail sem manifestação. Motivo: " + e.getMessage(), e);
		}
	}

	private String extrairManifestacaoAssunto(String assunto) throws ServiceException{
		buscarSeparadores();
		
		int inicio = assunto.indexOf(separadorInicial) + 1;
        int fim = assunto.indexOf(separadorFinal);
        
        return fim > 0 && fim > inicio ? assunto.substring(inicio, fim) : null;
		
	}
	
	private void buscarSeparadores() throws ServiceException {
		if (separadorInicial == null) {
    		ParametroGBO param = paramService.findByParam(Constantes.SEPARADOR_INICIAL);
    		if (param == null) {
    			throw new ServiceException("Parâmetro " + Constantes.SEPARADOR_INICIAL + " não cadastrado.");
    		}
    		
    		separadorInicial = param.getValor();
    	}
    	
    	if (separadorFinal == null) {
    		ParametroGBO param = paramService.findByParam(Constantes.SEPARADOR_FINAL);
    		if (param == null) {
    			throw new ServiceException("Parâmetro " + Constantes.SEPARADOR_FINAL + " não cadastrado.");
    		}
    		
    		separadorFinal = param.getValor();
    	}
		
	}

	protected void associarEmailAoCaso(Email email, Caso caso) throws ValidationException, ServiceException{
		emailService.associarEmailAoCaso(email, caso);
	}

	private GrupoAnexo salvarGrupoAnexo(Email email) throws ServiceException {
		return emailService.salvarGrupoAnexo(email, getDiretorioAnexo());
	}

	private void processar() {
		Properties properties = emailService.recebeEmailProperties();
		receiveMail = new ReceiveMail(properties);
		
		try {
            emailService.salvaReceivedMails(receiveMail.listaEmail());
        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, "", ex);
        } finally {
            try {
                receiveMail.close();
            } catch (Exception ex) {
                LOGGER.log(Level.SEVERE, "", ex);
            }
        }
		
	}

	private List<ConfiguracaoEmail> buscarConfigsEmails() throws ServiceException {
		return emailService.buscarConfigsEmails();
	}
	
	private String buscarDiretorioAnexos() {
		return emailService.buscarDiretorioAnexos();
	}

	protected Logger getLogger(){
		return Logger.getLogger(GenericRecebimentoEmail.class.getName());
	}

	public String getDiretorioAnexo() {
		return diretorioAnexo;
	}

	public void setDiretorioAnexo(String diretorioAnexo) {
		this.diretorioAnexo = diretorioAnexo;
	}
	
}
