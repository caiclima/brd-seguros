package br.com.callink.cad.engine.fila;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import br.com.callink.cad.pojo.ParametroGBO;
import br.com.callink.cad.service.ICasoService;
import br.com.callink.cad.service.IParametroGBOService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.util.Constantes;

/**
 * Thread responsável por validar quanto tempo o caso está com um analista sem ter nenhuma iteração, se o caso passar X tempo sem nenhuma
 * iteração o sistema devolve o mesmo para a fila para que outro analista possa atender o mesmo. Diminuindo o risco de casos ficarem muito tempo preso
 * com um analista.
 * @author brunomt
 */
public class ThreadRetiraCasoAtendente extends Thread {
    private static final Logger LOGGER = Logger.getLogger(ThreadRetiraCasoAtendente.class.getName());;
    
    private IParametroGBOService parametroGBOService;
    private ICasoService casoService;
    
    private Date dataUltimaExe;
    private static boolean executa;

    public ThreadRetiraCasoAtendente(IParametroGBOService parametroGBOService, ICasoService casoService) {
        this.parametroGBOService = parametroGBOService;
        this.casoService = casoService;
    }
    
    @Override
    public void run() {
    	
		try {
			Thread.sleep(Integer.valueOf(65000));
		} catch (InterruptedException ex) {
			LOGGER.log(Level.SEVERE, null, ex);
		}
		
		LOGGER.info("ThreadRetiraCasoAtendente iniciada");
		
		dataUltimaExe = null;
		executa = true;

		while (executa) {
			Boolean executaTempoAtendente = false;
			try {
				ParametroGBO parametroGBO = parametroGBOService.findByParam(Constantes.HORA_EXECUCAO_RETIRA_FILA);
				String[] horas = parametroGBO.getValor().split(";");
				SimpleDateFormat dt = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
				Date dataAtual = new Date();

				Calendar calendar = new GregorianCalendar();
				calendar.setTime(new Date());

				for (String horaMinuto : horas) {
					String sHoraMinuto[] = horaMinuto.split(":");
					calendar.set(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DATE), Integer.valueOf(sHoraMinuto[0]), Integer.valueOf(sHoraMinuto[1]), 0);
					if (dataUltimaExe == null) {
						if (calendar.getTime().compareTo(dataAtual) < 0) {
							dataUltimaExe = new Date();
							executaTempoAtendente = true;
						}
					} else {
						dt.format(dataAtual);
						dt.format(calendar.getTime());
						dt.format(dataUltimaExe);
						if (calendar.getTime().compareTo(dataUltimaExe) > 0 && calendar.getTime().compareTo(dataAtual) < 0) {
							dataUltimaExe = new Date();
							executaTempoAtendente = true;
						}
					}
				}

				if (executaTempoAtendente) {
					verificaTempoCasoAtendente();
				}

			} catch (ServiceException ex) {
				LOGGER.log(Level.SEVERE, "", ex);
			} catch (Exception ex) {
				LOGGER.log(Level.SEVERE, "", ex);
			}

			try {
				Thread.sleep(Integer.valueOf(60000));
			} catch (InterruptedException ex) {
				LOGGER.log(Level.SEVERE, null, ex);
			}
		}
        
        LOGGER.info("ThreadRetiraCasoAtendente iniciada");
    }

    private void verificaTempoCasoAtendente() throws ValidationException {
        try {
            SimpleDateFormat dt = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss"); 
            LOGGER.info("Executando processo que remove casos sem atendimento... Data:"+dt.format(dataUltimaExe));
            
            casoService.retiraCasoAtendentesInativos();
        } catch (ServiceException ex) {
            LOGGER.log(Level.SEVERE, "", ex);
        }
    }


	public static final boolean isExecuta() {
		return executa;
	}


	public static final void setExecuta(boolean executa) {
		ThreadRetiraCasoAtendente.executa = executa;
	}

}
