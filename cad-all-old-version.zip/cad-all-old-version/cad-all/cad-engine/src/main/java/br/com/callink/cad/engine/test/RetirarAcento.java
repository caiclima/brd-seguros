package br.com.callink.cad.engine.test;

import java.text.Normalizer;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;

public final class RetirarAcento {

	private RetirarAcento(){}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		SimpleDateFormat sf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		
		Calendar ca = new GregorianCalendar();
		System.out.println(sf.format(ca.getTime()));
		
		ca.add(Calendar.SECOND, -61);
		System.out.println(sf.format(ca.getTime()));
		
		String s = "Removendo todos os acentos. Acentuação básica dê sistemas à moda !@#$%¨&*()";
	
		String ok = removeAcentos(s);
		System.out.println(ok);
	}

	public static String removeAcentos(String str) {

		  str = Normalizer.normalize(str, Normalizer.Form.NFD);
		  str = str.replaceAll("[^0-9a-zA-ZéúíóáÉÚÍÓÁèùìòàÈÙÌÒÀõãñÕÃÑêûîôâÊÛÎÔÂëÿüïöäËYÜÏÖÄçÇ\\s]+?", "");
		  return str;

	}
	
}
