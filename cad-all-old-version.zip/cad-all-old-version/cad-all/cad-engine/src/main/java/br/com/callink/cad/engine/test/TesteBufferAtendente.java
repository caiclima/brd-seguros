package br.com.callink.cad.engine.test;

import java.util.logging.Logger;

import br.com.callink.cad.engine.buffer.fila.atendimento.CasoAtendimento;
import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.service.IAtendenteService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.service.impl.AtendenteService;

public final class TesteBufferAtendente {
	
	private static Logger logger = Logger.getLogger(TesteBufferAtendente.class.getName());

	private TesteBufferAtendente(){
		
	}
	public static void main(String[] args) throws ServiceException, InterruptedException, ValidationException {
		IAtendenteService atendenteService = new AtendenteService();
		CasoAtendimento casoAtendimento = new CasoAtendimento();
		Atendente atendente = atendenteService.findAll().get(0);
		Caso caso = casoAtendimento.solicitaCasoAtendenteAtendimento(atendente);
		if (caso != null) {
			logger.info("Caso Retornado: "+caso.getIdCaso());
		} else {
			logger.info("Caso NULO");
		}
		
		Thread.sleep(10000);
		
		
		if (caso == null) {
			logger.info("Caso NULO");
		} else {
			logger.info("Caso Retornado: "+caso.getIdCaso());
		}
	}
	
}
