package br.com.callink.cad.engine.test;

import br.com.callink.cad.engine.email.impl.EnvioEmailEngine;

public final class TesteEnviaEmailThread {

	private TesteEnviaEmailThread(){}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("Iniciando a thread de envio de email.");
		EnvioEmailEngine envioEmailEngine = new EnvioEmailEngine();
		//envioEmailEngine.run();
	}

}
