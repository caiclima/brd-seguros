package br.com.callink.cad.engine.test;

import br.com.callink.cad.engine.buffer.fila.ThreadEnfileiraCaso;
import br.com.callink.cad.service.IConfiguracaoFilaService;
import br.com.callink.cad.service.impl.ConfiguracaoFilaService;

public final class TesteThread {

	private TesteThread(){}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		IConfiguracaoFilaService configuracaoFilaService = new ConfiguracaoFilaService();
		
		System.out.println("Iniciando a thread de enfileiramento de caso.");
		ThreadEnfileiraCaso threadEnfileiraCaso = new ThreadEnfileiraCaso(configuracaoFilaService);
		threadEnfileiraCaso.start();
	}

}
