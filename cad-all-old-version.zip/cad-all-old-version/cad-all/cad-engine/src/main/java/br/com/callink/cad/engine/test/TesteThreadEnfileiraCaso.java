package br.com.callink.cad.engine.test;

import java.util.logging.Logger;

import br.com.callink.cad.engine.buffer.fila.ThreadEnfileiraCaso;
import br.com.callink.cad.service.IConfiguracaoFilaService;
import br.com.callink.cad.service.impl.ConfiguracaoFilaService;

public final class TesteThreadEnfileiraCaso {

	private static Logger logger = Logger.getLogger(TesteThreadEnfileiraCaso.class.getName());
	
	private TesteThreadEnfileiraCaso(){
		
	}
	
	public static void main(String[] args) {
		
		IConfiguracaoFilaService configuracaoFilaService = new ConfiguracaoFilaService();
		logger.info("Iniciando a thread de enfileiramento de caso.");
		ThreadEnfileiraCaso threadEnfileiraCaso = new ThreadEnfileiraCaso(configuracaoFilaService);
		threadEnfileiraCaso.start();
	}

}
