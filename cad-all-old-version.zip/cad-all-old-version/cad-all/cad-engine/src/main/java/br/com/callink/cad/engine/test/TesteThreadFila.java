package br.com.callink.cad.engine.test;

import java.util.logging.Logger;

import br.com.callink.cad.engine.fila.ThreadRetiraCasoAtendente;
import br.com.callink.cad.service.ICasoService;
import br.com.callink.cad.service.IParametroGBOService;
import br.com.callink.cad.service.impl.CasoService;
import br.com.callink.cad.service.impl.ParametroGBOService;
import br.com.callink.coreutils.service.exception.ServiceException;

public final class TesteThreadFila {
	
	private static Logger logger = Logger.getLogger(TesteThreadFila.class.getName());

	private TesteThreadFila(){
		
	}

	public static void main(String[] args) throws ServiceException, InterruptedException {
            
		IParametroGBOService parametroGBOService = new ParametroGBOService();
		ICasoService casoService = new CasoService();
		logger.info("Iniciando a thread de retirar casos de fila.");
            ThreadRetiraCasoAtendente threadRetiraCasoAtendente = new ThreadRetiraCasoAtendente(parametroGBOService, casoService);
            threadRetiraCasoAtendente.start();
	}
	
}
