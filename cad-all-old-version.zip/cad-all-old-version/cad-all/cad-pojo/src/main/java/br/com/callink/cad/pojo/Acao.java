package br.com.callink.cad.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;

/**
*
* @author Ednaldo Caic [ednaldo@swb.com.br]
* @since 22/12/2011
*/
@Entity
@Table(name = "TB_ACAO")
public class Acao implements IEntity<Integer> {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID_ACAO", unique = true, nullable = false)
	private Integer idAcao;

	@Column(name = "NOME", length = 200)
	private String nome;

	@Column(name = "DATA_CRIACAO")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataCriacao;

	@Column(name = "DESCRICAO")
	private String descricao;

	@Column(name = "FLAG_ATIVO")
	private Boolean flagAtivo;

	@Column(name = "URL_PAGE", length = 200)
	private String urlPage;
	
	@Column(name = "LOGIN_USUARIO", length = 50)
	private String loginUsuario;
	
	public Acao() {
	}
	
	public Acao(Integer idAcao) {
		super();
		this.idAcao = idAcao;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((idAcao == null) ? 0 : idAcao.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof Acao)) {
			return false;
		}
		Acao other = (Acao) obj;
		if (idAcao == null) {
			if (other.idAcao != null) {
				return false;
			}
		} else if (!idAcao.equals(other.idAcao)) {
			return false;
		}
		return true;
	}

	public final Integer getIdAcao() {
		return idAcao;
	}

	public final void setIdAcao(Integer idAcao) {
		this.idAcao = idAcao;
	}

	public final String getNome() {
		return nome;
	}

	public final void setNome(String nome) {
		this.nome = nome;
	}

	public final Date getDataCriacao() {
		return dataCriacao != null ? new Date(dataCriacao.getTime()) : null;
	}

	public final void setDataCriacao(Date dataCriacao) {
		this.dataCriacao = dataCriacao != null ? new Date(dataCriacao.getTime()) : null;
	}

	public Integer getPK() {
		return idAcao;
	}

	public void setPK(Integer pk) {
		this.idAcao = pk;
	}

	public final String getDescricao() {
		return descricao;
	}

	public final void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public final String getUrlPage() {
		return urlPage;
	}

	public final void setUrlPage(String urlPage) {
		this.urlPage = urlPage;
	}

	public void setLoginUsuario(String loginUsuario) {
		this.loginUsuario = loginUsuario;
	}

	public String getLoginUsuario() {
		return loginUsuario;
	}

	public final Boolean getFlagAtivo() {
		return flagAtivo;
	}

	public final void setFlagAtivo(Boolean flagAtivo) {
		this.flagAtivo = flagAtivo;
	}
        
            
    public static String getSqlCamposAcao() {

        return new StringBuilder()
                .append(" \nAcao.ID_ACAO AS 'Acao.ID_ACAO', ")
                .append(" \nAcao.NOME AS 'Acao.NOME', ")
                .append(" \nAcao.DESCRICAO AS 'Acao.DESCRICAO', ")
                .append(" \nAcao.FLAG_ATIVO AS 'Acao.FLAG_ATIVO', ")
                .append(" \nAcao.URL_PAGE AS 'Acao.URL_PAGE', ")
                .append(" \nAcao.LOGIN_USUARIO AS 'Acao.LOGIN_USUARIO', ")
                .append(" \nAcao.DATA_CRIACAO AS 'Acao.DATA_CRIACAO'").toString();
    }

    public static String getSqlFromAcao() {
        return " TB_ACAO  AS Acao with(nolock) ";
    }
    
    public static Acao getAcaoByResultSet(ResultSet rs) {
        try {
        	
        	if(rs.getInt("Acao.ID_ACAO") == 0) {
        		return null;
        	}
        	
            Acao acao = new Acao();
            acao.setIdAcao(rs.getInt("Acao.ID_ACAO"));
            acao.setFlagAtivo(rs.getBoolean("Acao.FLAG_ATIVO"));
            acao.setDataCriacao(rs.getTimestamp("Acao.DATA_CRIACAO"));
            acao.setNome(rs.getString("Acao.NOME"));
            acao.setUrlPage(rs.getString("Acao.URL_PAGE"));
            acao.setDescricao(rs.getString("Acao.DESCRICAO"));
            acao.setLoginUsuario(rs.getString("Acao.LOGIN_USUARIO"));
            return acao;
        } catch (SQLException ex) {
            throw new IllegalArgumentException(
                    "Erro ao montar objeto a partir do ResultSet", ex);
        }
    }

	@Override
	public String toString() {
		return nome;
	}

    
}
