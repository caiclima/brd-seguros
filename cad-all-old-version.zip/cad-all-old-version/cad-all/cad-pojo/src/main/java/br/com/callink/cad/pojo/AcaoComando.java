package br.com.callink.cad.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import br.com.callink.cad.pojo.entity.IEntity;

/**
 * 
 * @author Rogério Moreira de Andrade
 * @since 22/12/2011
 */
@Entity
@Table(name = "TB_ACAO_COMANDO")
public class AcaoComando implements IEntity<Integer> {
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID_ACAO_COMANDO", unique = true, nullable = false)
	private Integer id;

	public AcaoComando() {
	}

	public AcaoComando(Integer id) {
		super();
		this.id = id;
	}

	public AcaoComando(Acao acao, Comando comando) {
		this.comando = comando;
		this.acao = acao;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_COMANDO", referencedColumnName = "ID_COMANDO", nullable = false)
	private Comando comando;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_ACAO", referencedColumnName = "ID_ACAO", nullable = false)
	private Acao acao;

	public Acao getAcao() {
		return acao;
	}

	public void setAcao(Acao acao) {
		this.acao = acao;
	}

	public Comando getComando() {
		return comando;
	}

	public void setComando(Comando idComando) {
		this.comando = idComando;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final AcaoComando other = (AcaoComando) obj;
		if (this.comando != other.comando && (this.comando == null || !this.comando.equals(other.comando))) {
			return false;
		}
		if (this.acao != other.acao && (this.acao == null || !this.acao.equals(other.acao))) {
			return false;
		}
		return true;
	}

	@Override
	public int hashCode() {
		int hash = 3;
		hash = 79 * hash + (this.comando != null ? this.comando.hashCode() : 0);
		hash = 79 * hash + (this.acao != null ? this.acao.hashCode() : 0);
		return hash;
	}

	public Integer getPK() {
		return id;
	}

	public void setPK(Integer id) {
		this.id = id;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer idAcaoComando) {
		this.id = idAcaoComando;
	}
	
	public static String getSqlCamposAcaoComando() {
        return new StringBuilder()
                .append(" \nAcaoComando.ID_ACAO_COMANDO AS 'AcaoComando.ID_ACAO_COMANDO', ")
                .append(" \nAcaoComando.ID_COMANDO AS 'AcaoComando.ID_COMANDO', ")
                .append(" \nAcaoComando.ID_ACAO AS 'AcaoComando.ID_ACAO' ").toString();
    }

    public static String getSqlFromAcaoComando() {
        return " TB_ACAO_COMANDO  AS AcaoComando with(nolock) ";
    }
    
    public static AcaoComando getAcaoComandoByResultSet(ResultSet rs) {
        try {
        	
        	if(rs.getInt("AcaoComando.ID_ACAO_COMANDO") == 0) {
        		return null;
        	}
        	
            AcaoComando acaoComando = new AcaoComando();
            acaoComando.setId(rs.getInt("AcaoComando.ID_ACAO_COMANDO"));
            acaoComando.setComando(rs.getInt("AcaoComando.ID_COMANDO") == 0 ? null : new Comando(rs.getInt("AcaoComando.ID_COMANDO")));
            acaoComando.setAcao(rs.getInt("AcaoComando.ID_ACAO") == 0 ? null : new Acao(rs.getInt("AcaoComando.ID_ACAO")));
            return acaoComando;
        } catch (SQLException ex) {
            throw new IllegalArgumentException(
                    "Erro ao montar objeto a partir do ResultSet", ex);
        }
    }

}
