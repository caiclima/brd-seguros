package br.com.callink.cad.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import br.com.callink.cad.pojo.entity.IEntity;

/**
 * 
 * @since 22/12/2011
 */
@Entity
@Table(name = "TB_ACAO_TIPO_ACAO")
public class AcaoTipoAcao implements IEntity<Integer> {

	private static final long serialVersionUID = 1L;
	
	@EmbeddedId
	private AcaoTipoAcaoId acaoTipoAcaoId;

	public AcaoTipoAcao() {
	}

	public AcaoTipoAcaoId getAcaoTipoAcaoId() {
		if (acaoTipoAcaoId == null) {
			acaoTipoAcaoId = new AcaoTipoAcaoId();
		}
		return acaoTipoAcaoId;
	}

	public void setAcaoTipoAcaoId(AcaoTipoAcaoId acaoTipoAcaoId) {
		this.acaoTipoAcaoId = acaoTipoAcaoId;
	}

	public Integer getPK() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void setPK(Integer t) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

	public static String getSqlCamposAcaoTipoAcao() {
        return new StringBuilder()
                .append(" \nAcaoTipoAcao.ID_TIPO_ACAO AS 'AcaoTipoAcao.ID_TIPO_ACAO', ")
                .append(" \nAcaoTipoAcao.ID_ACAO AS 'AcaoTipoAcao.ID_ACAO' ").toString();
    }

    public static String getSqlFromAcaoTipoAcao() {
        return " TB_ACAO_TIPO_ACAO  AS AcaoTipoAcao with(nolock) ";
    }
    
    public static AcaoTipoAcao getAcaoTipoAcaoByResultSet(ResultSet rs) {
        try {
        	
        	if(rs.getInt("AcaoTipoAcao.ID_TIPO_ACAO") == 0) {
        		return null;
        	}
        	
            AcaoTipoAcao acaoTipoAcao = new AcaoTipoAcao();
            acaoTipoAcao.setAcaoTipoAcaoId(new AcaoTipoAcaoId());
            acaoTipoAcao.getAcaoTipoAcaoId().setIdTipoAcao(rs.getInt("AcaoTipoAcao.ID_TIPO_ACAO") == 0 ? null : new TipoAcao(rs.getInt("AcaoTipoAcao.ID_TIPO_ACAO")));
            acaoTipoAcao.getAcaoTipoAcaoId().setIdAcao(rs.getInt("AcaoTipoAcao.ID_ACAO") == 0 ? null : new Acao(rs.getInt("AcaoTipoAcao.ID_ACAO")));
            return acaoTipoAcao;
        } catch (SQLException ex) {
            throw new IllegalArgumentException(
                    "Erro ao montar objeto a partir do ResultSet", ex);
        }
    }

}
