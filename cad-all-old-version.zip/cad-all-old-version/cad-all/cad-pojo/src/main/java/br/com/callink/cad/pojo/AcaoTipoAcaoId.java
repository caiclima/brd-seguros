package br.com.callink.cad.pojo;

import javax.persistence.Embeddable;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import br.com.callink.cad.pojo.entity.IEntity;

@Embeddable
public class AcaoTipoAcaoId implements IEntity<Integer> {

	private static final long serialVersionUID = 1L;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_TIPO_ACAO", referencedColumnName = "ID_TIPO_ACAO", nullable = false)
	private TipoAcao idTipoAcao;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_ACAO", referencedColumnName = "ID_ACAO", nullable = false)
	private Acao idAcao;
	
	public AcaoTipoAcaoId() {
	}
	
	public AcaoTipoAcaoId(TipoAcao tipoAcao, Acao acao) {
		this.idTipoAcao = tipoAcao;
		this.idAcao = acao;
	}
	
	public Acao getIdAcao() {
		return idAcao;
	}

	public void setIdAcao(Acao acao) {
		this.idAcao = acao;
	}

	public final TipoAcao getIdTipoAcao() {
		return idTipoAcao;
	}

	public final void setIdTipoAcao(TipoAcao idTipoAcao) {
		this.idTipoAcao = idTipoAcao;
	}
	
	@Override
	public String toString() {
		return "TipoAcaoAcao [idTipoAcao=" + idTipoAcao + ", idAcao=" + idAcao
				+ "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((idAcao == null) ? 0 : idAcao.hashCode());
		result = prime * result
				+ ((idTipoAcao == null) ? 0 : idTipoAcao.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj){
			return true;
		}
		if (obj == null){
			return false;
		}
		if (getClass() != obj.getClass()){
			return false;
		}
		AcaoTipoAcaoId other = (AcaoTipoAcaoId) obj;
		if (idAcao == null) {
			if (other.idAcao != null){
				return false;
			}
		} else if (!idAcao.equals(other.idAcao)){
			return false;
		}
		if (idTipoAcao == null) {
			if (other.idTipoAcao != null){
				return false;
			}
		} else if (!idTipoAcao.equals(other.idTipoAcao)){
			return false;
		}
		return true;
	}
	
	public Integer getPK() {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	public void setPK(Integer t) {
		throw new UnsupportedOperationException("Not supported yet.");
	}
	
}
