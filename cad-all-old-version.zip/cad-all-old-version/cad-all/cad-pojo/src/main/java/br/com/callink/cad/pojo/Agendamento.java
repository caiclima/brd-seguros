package br.com.callink.cad.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;

/**
 *
 * @author Ednaldo Caic [ednaldo@swb.com.br]
 * @since 23/12/2011
 */
@Entity
@Table(name = "TB_AGENDAMENTO")
public class Agendamento implements IEntity<Integer> {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID_AGENDAMENTO", unique = true, nullable = false)
    private Integer idAgendamento;
    
    @Column(name = "DATA_AGENDAMENTO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataAgendamento;
    
    @Column(name = "DATA_CADASTRO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataCadastro;
    
    @Column(name = "FLAG_ATIVO")
    private Boolean flagAtivo;
    
    @ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_CASO", referencedColumnName = "ID_CASO", nullable = false)
    private Caso caso;
    
    @Column(name = "LOGIN_USUARIO", length = 50)
    private String loginUsuario;
    
    @Column(name = "DESCRICAO")
    private String descricao;

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result
                + ((idAgendamento == null) ? 0 : idAgendamento.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof Agendamento)) {
            return false;
        }
        Agendamento other = (Agendamento) obj;
        if (idAgendamento == null) {
            if (other.idAgendamento != null) {
                return false;
            }
        } else if (!idAgendamento.equals(other.idAgendamento)) {
            return false;
        }
        return true;
    }

    public Integer getPK() {
        return idAgendamento;
    }

    public void setPK(Integer pk) {
        this.idAgendamento = pk;
    }

    public final Integer getIdAgendamento() {
        return idAgendamento;
    }

    public final void setIdAgendamento(Integer idAgendamento) {
        this.idAgendamento = idAgendamento;
    }

    public final Date getDataAgendamento() {
        return dataAgendamento != null ? new Date(dataAgendamento.getTime()) : null;
    }

    public final void setDataAgendamento(Date dataAgendamento) {
        this.dataAgendamento = dataAgendamento != null ? new Date(dataAgendamento.getTime()) : null;
    }

    public final Date getDataCadastro() {
        return dataCadastro != null ? new Date(dataCadastro.getTime()) : null;
    }

    public final void setDataCadastro(Date dataCadastro) {
        this.dataCadastro = dataCadastro != null ? new Date(dataCadastro.getTime()) : null;
    }

    public final Caso getCaso() {
        return caso;
    }

    public final void setCaso(Caso caso) {
        this.caso = caso;
    }

    public void setLoginUsuario(String loginUsuario) {
        this.loginUsuario = loginUsuario;
    }

    public String getLoginUsuario() {
        return loginUsuario;
    }

    public final Boolean getFlagAtivo() {
        return flagAtivo;
    }

    public final void setFlagAtivo(Boolean flagAtivo) {
        this.flagAtivo = flagAtivo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    
    public static String getSqlCamposAgendamento() {
        return new StringBuilder()
                .append(" \nAgendamento.ID_AGENDAMENTO AS 'Agendamento.ID_AGENDAMENTO', ")
                .append(" \nAgendamento.DATA_AGENDAMENTO AS 'Agendamento.DATA_AGENDAMENTO', ")
                .append(" \nAgendamento.DATA_CADASTRO AS 'Agendamento.DATA_CADASTRO', ")
                .append(" \nAgendamento.FLAG_ATIVO AS 'Agendamento.FLAG_ATIVO', ")
                .append(" \nAgendamento.ID_CASO AS 'Agendamento.ID_CASO', ")
                .append(" \nAgendamento.LOGIN_USUARIO AS 'Agendamento.LOGIN_USUARIO', ")
                .append(" \nAgendamento.DESCRICAO AS 'Agendamento.DESCRICAO' ").toString();
    }

    public static String getSqlFromAgendamento() {
        return " TB_AGENDAMENTO  AS Agendamento with(nolock) ";
    }
    
    public static Agendamento getAgendamentoByResultSet(ResultSet rs) {
        try {
        	
        	if(rs.getInt("Agendamento.ID_AGENDAMENTO") == 0) {
        		return null;
        	}
        	
        	Agendamento agendamento = new Agendamento();
        	agendamento.setIdAgendamento(rs.getInt("Agendamento.ID_AGENDAMENTO"));
        	agendamento.setDataAgendamento(rs.getTimestamp("Agendamento.DATA_AGENDAMENTO"));
        	agendamento.setDataCadastro(rs.getTimestamp("Agendamento.DATA_CADASTRO"));
        	agendamento.setFlagAtivo(rs.getBoolean("Agendamento.FLAG_ATIVO"));
        	agendamento.setCaso(rs.getInt("Agendamento.ID_CASO") == 0 ? null : new Caso(rs.getInt("Agendamento.ID_CASO")));
        	agendamento.setLoginUsuario(rs.getString("Agendamento.LOGIN_USUARIO"));
        	agendamento.setDescricao(rs.getString("Agendamento.DESCRICAO"));
            return agendamento;
        } catch (SQLException ex) {
            throw new IllegalArgumentException(
                    "Erro ao montar objeto a partir do ResultSet", ex);
        }
    }
    
}
