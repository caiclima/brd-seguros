package br.com.callink.cad.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;

/**
*
* @author Ednaldo Caic [ednaldo@swb.com.br]
* @since 22/12/2011
*/
@Entity
@Table(name = "TB_ANEXO")
public class Anexo implements IEntity<Integer>{

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID_ANEXO", unique = true, nullable = false)
	private Integer idAnexo;

	@Column(name = "NOME_REAL", length = 255)
	private String nomeReal;
	
	@Column(name = "NOME_FAKE", length = 255)
	private String nomeFake;
	
	@Column(name = "DIRETORIO", length = 255)
	private String diretorio;
	
	@Column(name = "DATA_CRIACAO")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataCriacao;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_GRUPO_ANEXO", referencedColumnName = "ID_GRUPO_ANEXO")
	private GrupoAnexo grupoAnexo;
	
	private transient byte [] dados;
	private transient int tamanho;
	
	public Anexo() {
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((idAnexo == null) ? 0 : idAnexo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof Anexo)) {
			return false;
		}
		Anexo other = (Anexo) obj;
		if (idAnexo == null) {
			if (other.idAnexo != null) {
				return false;
			}
		} else if (!idAnexo.equals(other.idAnexo)) {
			return false;
		}
		return true;
	}

	public Integer getPK() {
		return idAnexo;
	}

	public void setPK(Integer pk) {
		idAnexo = pk;
	}

	public final Integer getIdAnexo() {
		return idAnexo;
	}

	public final void setIdAnexo(Integer idAnexo) {
		this.idAnexo = idAnexo;
	}

	public final String getNomeReal() {
		return nomeReal;
	}

	public final void setNomeReal(String nomeReal) {
		this.nomeReal = nomeReal;
	}

	public final String getNomeFake() {
		return nomeFake;
	}

	public final void setNomeFake(String nomeFake) {
		this.nomeFake = nomeFake;
	}

	public final String getDiretorio() {
		return diretorio;
	}

	public final void setDiretorio(String diretorio) {
		this.diretorio = diretorio;
	}

	public final Date getDataCriacao() {
		return dataCriacao == null ? null : new Date(dataCriacao.getTime());
	}

	public final void setDataCriacao(Date dataCriacao) {
		this.dataCriacao = dataCriacao == null ? null : new Date(dataCriacao.getTime());
	}

	public final GrupoAnexo getGrupoAnexo() {
		return grupoAnexo;
	}

	public final void setGrupoAnexo(GrupoAnexo grupoAnexo) {
		this.grupoAnexo = grupoAnexo;
	}

	public final byte[] getDados() {
		return dados;
	}

	public final void setDados(byte[] dados) {
		this.dados = dados;
	}

	public final int getTamanho() {
		return tamanho;
	}

	public final void setTamanho(int tamanho) {
		this.tamanho = tamanho;
	}
	
	public static String getSqlCamposAnexo() {
        return new StringBuilder()
                .append(" \nAnexo.ID_ANEXO AS 'Anexo.ID_ANEXO', ")
                .append(" \nAnexo.NOME_REAL AS 'Anexo.NOME_REAL', ")
                .append(" \nAnexo.NOME_FAKE AS 'Anexo.NOME_FAKE', ")
                .append(" \nAnexo.DIRETORIO AS 'Anexo.DIRETORIO', ")
                .append(" \nAnexo.DATA_CRIACAO AS 'Anexo.DATA_CRIACAO', ")
                .append(" \nAnexo.ID_GRUPO_ANEXO AS 'Anexo.ID_GRUPO_ANEXO' ").toString();
    }

    public static String getSqlFromAnexo() {
        return " TB_ANEXO  AS Anexo with(nolock) ";
    }
    
    public static Anexo getAnexoByResultSet(ResultSet rs) {
        try {
        	
        	if(rs.getInt("Anexo.ID_ANEXO") == 0) {
        		return null;
        	}
        	
        	Anexo anexo = new Anexo();
        	anexo.setIdAnexo(rs.getInt("Anexo.ID_ANEXO"));
        	anexo.setNomeReal(rs.getString("Anexo.NOME_REAL"));
        	anexo.setNomeFake(rs.getString("Anexo.NOME_FAKE"));
        	anexo.setDiretorio(rs.getString("Anexo.DIRETORIO"));
        	anexo.setDataCriacao(rs.getTimestamp("Anexo.DATA_CRIACAO"));
        	anexo.setGrupoAnexo(rs.getInt("Anexo.ID_GRUPO_ANEXO") == 0 ? null : new GrupoAnexo(rs.getInt("Anexo.ID_GRUPO_ANEXO")));
            return anexo;
        } catch (SQLException ex) {
            throw new IllegalArgumentException(
                    "Erro ao montar objeto a partir do ResultSet", ex);
        }
    }
	
}
