package br.com.callink.cad.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import br.com.callink.cad.pojo.entity.IEntity;

/**
 *
 * @author Luiz Gustavo (luizgf@swb.com.br)
 */
@Entity
@Table(name = "TB_ASSOCIA_GRUPO_EMAIL")
public class AssociaGrupoEmail implements IEntity<Integer> {
    
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_associa_grupo_email", unique = true, nullable = false)
    private Integer idAssociaGrupoEmail;
    
    @ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_endereco_email", referencedColumnName = "id_endereco_email")
    private EnderecoEmail enderecoEmail;
    
    @ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_grupo_email", referencedColumnName = "id_grupo_email")
    private GrupoEmail grupoEmail;

    public AssociaGrupoEmail() {
    }
    
    public AssociaGrupoEmail(EnderecoEmail enderecoEmail,GrupoEmail grupoEmail) {
        super();
        this.enderecoEmail = enderecoEmail;
        this.grupoEmail = grupoEmail;
    }
    
    public Integer getIdAssociaGrupoEmail() {
        return idAssociaGrupoEmail;
    }

    public void setIdAssociaGrupoEmail(Integer idAssociaGrupoEmail) {
        this.idAssociaGrupoEmail = idAssociaGrupoEmail;
    }

    public EnderecoEmail getEnderecoEmail() {
        return enderecoEmail;
    }

    public void setEnderecoEmail(EnderecoEmail enderecoEmail) {
        this.enderecoEmail = enderecoEmail;
    }

    public GrupoEmail getGrupoEmail() {
        return grupoEmail;
    }

    public void setGrupoEmail(GrupoEmail grupoEmail) {
        this.grupoEmail = grupoEmail;
    }

    public Integer getPK() {
        return idAssociaGrupoEmail;
    }

    public void setPK(Integer t) {
        this.idAssociaGrupoEmail = t;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final AssociaGrupoEmail other = (AssociaGrupoEmail) obj;
        if (this.idAssociaGrupoEmail == null || !this.idAssociaGrupoEmail.equals(other.idAssociaGrupoEmail)) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 79 * hash + (this.idAssociaGrupoEmail != null ? this.idAssociaGrupoEmail.hashCode() : 0);
        return hash;
    }
    
    public static String getSqlCamposAssociaGrupoEmail() {
        return new StringBuilder()
                .append(" \nAssociaGrupoEmail.ID_ASSOCIA_GRUPO_EMAIL AS 'AssociaGrupoEmail.ID_ASSOCIA_GRUPO_EMAIL', ")
                .append(" \nAssociaGrupoEmail.ID_ENDERECO_EMAIL AS 'AssociaGrupoEmail.ID_ENDERECO_EMAIL', ")
                .append(" \nAssociaGrupoEmail.ID_GRUPO_EMAIL AS 'AssociaGrupoEmail.ID_GRUPO_EMAIL' ").toString();
    }

    public static String getSqlFromAssociaGrupoEmail() {
        return " TB_ASSOCIA_GRUPO_EMAIL  AS AssociaGrupoEmail with(nolock) ";
    }
    
    public static AssociaGrupoEmail getAssociaGrupoEmailByResultSet(ResultSet rs) {
        try {
        	
        	if(rs.getInt("AssociaGrupoEmail.ID_ASSOCIA_GRUPO_EMAIL") == 0) {
        		return null;
        	}
        	
        	AssociaGrupoEmail associaGrupoEmail = new AssociaGrupoEmail();
        	associaGrupoEmail.setIdAssociaGrupoEmail(rs.getInt("AssociaGrupoEmail.ID_ASSOCIA_GRUPO_EMAIL"));
        	associaGrupoEmail.setEnderecoEmail(rs.getInt("AssociaGrupoEmail.ID_ENDERECO_EMAIL") == 0 ? null : new EnderecoEmail(rs.getInt("AssociaGrupoEmail.ID_ENDERECO_EMAIL")));
        	associaGrupoEmail.setGrupoEmail(rs.getInt("AssociaGrupoEmail.ID_GRUPO_EMAIL") ==0 ? null : new GrupoEmail(rs.getInt("AssociaGrupoEmail.ID_GRUPO_EMAIL")));
            return associaGrupoEmail;
        } catch (SQLException ex) {
            throw new IllegalArgumentException(
                    "Erro ao montar objeto a partir do ResultSet", ex);
        }
    }
    
}
