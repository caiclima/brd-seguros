package br.com.callink.cad.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;

/**
 * 
 * @author Ednaldo Caic [ednaldo@swb.com.br]
 * @since 22/12/2011
 */
@Entity
@Table(name = "TB_ATENDENTE")
public class Atendente implements IEntity<Integer> {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID_ATENDENTE", unique = true, nullable = false)
	private Integer idAtendente;
	
	@Column(name = "LOGIN", length = 200)
	private String login;
	
	@Column(name = "DATA_CRIACAO")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataCriacao;
	
	@Column(name = "FLAG_ATIVO", nullable = false)
	private Boolean flagAtivo;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_PERFIL", referencedColumnName = "id_perfil", nullable = false)
	private Perfil perfil;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_EQUIPE", referencedColumnName = "id_equipe")
	private Equipe equipe;
        
    @Column(name="nome", length = 200)
    private String nome;
    
    @Column(name="telefone", length = 20)
    private String telefone;
    
    @Column(name="ramal", length = 4)
    private String ramal;
    
    @Column(name="fax", length = 20)
    private String fax;
    
    @Column(name="id_telefonia", length = 20)
    private String idTelefonia;
        
	private transient Boolean selecionado;
        
    private transient Date dataPingAtendente;
        
	public Atendente() {

	}

	public Atendente(Integer idAtendente) {
		this.idAtendente = idAtendente;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((idAtendente == null) ? 0 : idAtendente.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof Atendente)) {
			return false;
		}
		Atendente other = (Atendente) obj;
		if (idAtendente == null) {
			if (other.idAtendente != null) {
				return false;
			}
		} else if (!idAtendente.equals(other.idAtendente)) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return login;
	}

	public final Integer getIdAtendente() {
		return idAtendente;
	}

	public final void setIdAtendente(Integer idAtendente) {
		this.idAtendente = idAtendente;
	}

	public final String getLogin() {
		return login;
	}

	public final void setLogin(String login) {
		this.login = login;
	}

	public final Date getDataCriacao() {
		return dataCriacao != null ? new Date(this.dataCriacao.getTime()) : null;
	}

	public final void setDataCriacao(Date dataCriacao) {
		this.dataCriacao = dataCriacao != null ? new Date(dataCriacao.getTime()) : null;
	}

	public Integer getPK() {
		return idAtendente;
	}

	public void setPK(Integer pk) {
		this.idAtendente = pk;
	}

	public final Equipe getEquipe() {
		return equipe;
	}

	public final void setEquipe(Equipe equipe) {
		this.equipe = equipe;
	}

	public final Perfil getPerfil() {
		return perfil;
	}

	public final void setPerfil(Perfil perfil) {
		this.perfil = perfil;
	}

	public final Boolean getFlagAtivo() {
		return flagAtivo;
	}

	public final void setFlagAtivo(Boolean flagAtivo) {
		this.flagAtivo = flagAtivo;
	}

	public final Boolean getSelecionado() {
		return selecionado;
	}

	public final void setSelecionado(Boolean selecionado) {
		this.selecionado = selecionado;
	}

        public String getIdTelefonia() {
            return idTelefonia;
        }

        public void setIdTelefonia(String idTelefonia) {
            this.idTelefonia = idTelefonia;
        }

	public static String getSqlCamposAtendente() {

		return new StringBuilder()
				.append(" \nAtendente.ID_ATENDENTE AS 'Atendente.ID_ATENDENTE',")
				.append(" \nAtendente.LOGIN AS 'Atendente.LOGIN',")
				.append(" \nAtendente.DATA_CRIACAO AS 'Atendente.DATA_CRIACAO',")
				.append(" \nAtendente.FLAG_ATIVO AS 'Atendente.FLAG_ATIVO',")
				.append(" \nAtendente.ID_PERFIL AS 'Atendente.ID_PERFIL',")
				.append(" \nAtendente.ID_EQUIPE AS 'Atendente.ID_EQUIPE',")
                .append(" \nAtendente.NOME AS 'Atendente.NOME',")
                .append(" \nAtendente.TELEFONE AS 'Atendente.TELEFONE',")
                .append(" \nAtendente.RAMAL AS 'Atendente.RAMAL',")
                .append(" \nAtendente.FAX AS 'Atendente.FAX', ")                        
                .append(" \nAtendente.ID_TELEFONIA AS 'Atendente.ID_TELEFONIA' ")
				.toString();

	}

	public static String getSqlFromAtendente() {
		return " TB_ATENDENTE As Atendente with(nolock) ";
	}

	public static Atendente getAtendenteByResultSet(ResultSet resultSet) {
		try {
			
			if(resultSet.getInt("Atendente.ID_ATENDENTE") == 0) {
        		return null;
        	}
			
			Atendente atendente = new Atendente();

			atendente.setIdAtendente(resultSet.getInt("Atendente.ID_ATENDENTE"));
			atendente.setLogin(resultSet.getString("Atendente.LOGIN"));
			atendente.setDataCriacao(resultSet.getTimestamp("Atendente.DATA_CRIACAO"));
			atendente.setFlagAtivo(resultSet.getBoolean("Atendente.FLAG_ATIVO"));
			atendente.setPerfil(resultSet.getInt("Atendente.ID_PERFIL") == 0 ? null : new Perfil(resultSet.getInt("Atendente.ID_PERFIL")));
			atendente.setEquipe(resultSet.getInt("Atendente.ID_EQUIPE") == 0 ? null : new Equipe(resultSet.getInt("Atendente.ID_EQUIPE")));
            atendente.setNome(resultSet.getString("Atendente.NOME"));
            atendente.setTelefone(resultSet.getString("Atendente.TELEFONE"));
            atendente.setRamal(resultSet.getString("Atendente.RAMAL"));
            atendente.setFax(resultSet.getString("Atendente.FAX"));
            atendente.setIdTelefonia(resultSet.getString("Atendente.ID_TELEFONIA"));
            
			return atendente;
		} catch (SQLException e) {
			throw new IllegalArgumentException(
					"Erro ao montar objeto a partir do ResultSet", e);
		}

	}

    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getRamal() {
        return ramal;
    }

    public void setRamal(String ramal) {
        this.ramal = ramal;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public Date getDataPingAtendente() {
        return dataPingAtendente == null ? null : new Date(dataPingAtendente.getTime());
    }

    public void setDataPingAtendente(Date dataPingAtendente) {
        this.dataPingAtendente = dataPingAtendente == null ? null : new Date(dataPingAtendente.getTime());
    }
        
}
