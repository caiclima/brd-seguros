package br.com.callink.cad.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;

/**
 * 
 * @author Bruno Alves [brunoam@swb.com.br]
 * @since 19/04/2011
 */
@Entity
@Table(name = "TB_ATENDENTE_STATUS")
public class AtendenteStatus implements IEntity<Integer> {
    
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID_ATENDENTE_STATUS", unique = true, nullable = false)
    private Integer idAtendenteStatus;
    
    @Column(name = "NOME_STATUS", length = 50)
    private String nomeStatus;
    
    @Column(name = "DATA_CADASTRO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataCadastro;
    
    @Column(name = "FLAG_ATIVO")
    private Boolean flagAtivo;
    
    @Column(name = "PAUSA_ATENDIMENTO")
    private Boolean pausaAtendimento;
    
    @Column(name = "COR_STATUS", length = 30)
    private String corStatus;
    
    @Column(name = "ID_STATUS_TOOLBAR", length = 10)
    private Integer idStatusToolbar;
    
    public AtendenteStatus() {
		// TODO Auto-generated constructor stub
	}
    
    public AtendenteStatus(Integer idAtendenteStatus){
    	this.idAtendenteStatus = idAtendenteStatus;
    }
    
    public Date getDataCadastro() {
        return dataCadastro == null ? null : new Date(dataCadastro.getTime());
    }

    public void setDataCadastro(Date dataCadastro) {
        this.dataCadastro = dataCadastro == null ? null : new Date(dataCadastro.getTime());
    }

    public Boolean getFlagAtivo() {
        return flagAtivo;
    }

    public void setFlagAtivo(Boolean flagAtivo) {
        this.flagAtivo = flagAtivo;
    }

    public Integer getIdAtendenteStatus() {
        return idAtendenteStatus;
    }

    public void setIdAtendenteStatus(Integer idAtendenteStatus) {
        this.idAtendenteStatus = idAtendenteStatus;
    }

    public String getNomeStatus() {
        return nomeStatus;
    }

    public void setNomeStatus(String nomeStatus) {
        this.nomeStatus = nomeStatus;
    }

    public Boolean getPausaAtendimento() {
        return pausaAtendimento;
    }

    public void setPausaAtendimento(Boolean pausaAtendimento) {
        this.pausaAtendimento = pausaAtendimento;
    }

    public String getCorStatus() {
        return corStatus;
    }

    public void setCorStatus(String corStatus) {
        this.corStatus = corStatus;
    }

    @Override
    public String toString() {
        return nomeStatus;
    }

    public Integer getPK() {
        return idAtendenteStatus;
    }

    public void setPK(Integer pk) {
        this.idAtendenteStatus = pk;
    }

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((idAtendenteStatus == null) ? 0 : idAtendenteStatus
						.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof AtendenteStatus)) {
			return false;
		}
		AtendenteStatus other = (AtendenteStatus) obj;
		if (idAtendenteStatus == null) {
			if (other.idAtendenteStatus != null) {
				return false;
			}
		} else if (!idAtendenteStatus.equals(other.idAtendenteStatus)) {
			return false;
		}
		return true;
	}

	public Integer getIdStatusToolbar() {
		return idStatusToolbar;
	}

	public void setIdStatusToolbar(Integer idStatusToolbar) {
		this.idStatusToolbar = idStatusToolbar;
	}
	
	public static String getSqlCamposAtendenteStatus() {
		return new StringBuilder()
				.append(" \nAtendenteStatus.ID_ATENDENTE_STATUS AS 'AtendenteStatus.ID_ATENDENTE_STATUS',")
				.append(" \nAtendenteStatus.NOME_STATUS AS 'AtendenteStatus.NOME_STATUS',")
				.append(" \nAtendenteStatus.DATA_CADASTRO AS 'AtendenteStatus.DATA_CADASTRO',")
				.append(" \nAtendenteStatus.FLAG_ATIVO AS 'AtendenteStatus.FLAG_ATIVO',")
				.append(" \nAtendenteStatus.PAUSA_ATENDIMENTO AS 'AtendenteStatus.PAUSA_ATENDIMENTO',")
				.append(" \nAtendenteStatus.COR_STATUS AS 'AtendenteStatus.COR_STATUS',")
                .append(" \nAtendenteStatus.ID_STATUS_TOOLBAR AS 'AtendenteStatus.ID_STATUS_TOOLBAR'").toString();

	}

	public static String getSqlFromAtendenteStatus() {
		return " TB_ATENDENTE_STATUS As AtendenteStatus with(nolock) ";
	}

	public static AtendenteStatus getAtendenteStatusByResultSet(ResultSet resultSet) {
		try {
			
			if(resultSet.getInt("AtendenteStatus.ID_ATENDENTE_STATUS") == 0) {
        		return null;
        	}
			
			AtendenteStatus atendenteStatus = new AtendenteStatus();

			atendenteStatus.setIdAtendenteStatus(resultSet.getInt("AtendenteStatus.ID_ATENDENTE_STATUS"));
			atendenteStatus.setNomeStatus(resultSet.getString("AtendenteStatus.NOME_STATUS"));
			atendenteStatus.setDataCadastro(resultSet.getTimestamp("AtendenteStatus.DATA_CADASTRO"));
			atendenteStatus.setFlagAtivo(resultSet.getBoolean("AtendenteStatus.FLAG_ATIVO"));
			atendenteStatus.setPausaAtendimento(resultSet.getBoolean("AtendenteStatus.PAUSA_ATENDIMENTO"));
			atendenteStatus.setCorStatus(resultSet.getString("AtendenteStatus.COR_STATUS"));
			atendenteStatus.setIdStatusToolbar(resultSet.getInt("AtendenteStatus.ID_STATUS_TOOLBAR"));
            
			return atendenteStatus;
		} catch (SQLException e) {
			throw new IllegalArgumentException("Erro ao montar objeto a partir do ResultSet", e);
		}
	}
    
}
