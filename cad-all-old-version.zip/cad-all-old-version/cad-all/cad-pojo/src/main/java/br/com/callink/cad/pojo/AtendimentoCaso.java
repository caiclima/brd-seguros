package br.com.callink.cad.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;

/**
*
* @author Ednaldo Caic [ednaldo@swb.com.br]
* @since 23/12/2011
*/
@Entity
@Table(name = "TB_ATENDIMENTO_CASO")
public class AtendimentoCaso implements IEntity<Integer> {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID_ATENDIMENTO_CASO", unique = true, nullable = false)
	private Integer idAtendimentoCaso;

	@Column(name = "DATA_MARCACAO")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataMarcacao;

	private transient Boolean flgInicio;
	
	@Column(name = "DATA_INICIO")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataInicio;
	
	@Column(name = "DATA_FIM")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataFim;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_ATENDENTE", referencedColumnName = "ID_ATENDENTE")
	private Atendente atendente;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_CASO", referencedColumnName = "ID_CASO", nullable = false)
	private Caso caso;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_STATUS", referencedColumnName = "ID_STATUS", nullable = false)
	private Status status;

    @ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_CONFIGURACAO_FILA", referencedColumnName = "ID_CONFIGURACAO_FILA")
    private ConfiguracaoFila configuracaoFila;
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((idAtendimentoCaso == null) ? 0 : idAtendimentoCaso
						.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof AtendimentoCaso)) {
			return false;
		}
		AtendimentoCaso other = (AtendimentoCaso) obj;
		if (idAtendimentoCaso == null) {
			if (other.idAtendimentoCaso != null) {
				return false;
			}
		} else if (!idAtendimentoCaso.equals(other.idAtendimentoCaso)) {
			return false;
		}
		return true;
	}

	public Integer getPK() {
		return idAtendimentoCaso;
	}

	public void setPK(Integer pk) {
		this.idAtendimentoCaso = pk;
	}

	public final Integer getIdAtendimentoCaso() {
		return idAtendimentoCaso;
	}

	public final void setIdAtendimentoCaso(Integer idAtendimentoCaso) {
		this.idAtendimentoCaso = idAtendimentoCaso;
	}

	public final Date getDataMarcacao() {
		return dataMarcacao != null ? new Date(dataMarcacao.getTime()) : null;
	}

	public final void setDataMarcacao(Date dataMarcacao) {
		this.dataMarcacao = dataMarcacao != null ? new Date(dataMarcacao.getTime()) : null;
	}

	public final Boolean getFlgInicio() {
		if (flgInicio == null) {
			flgInicio = this.dataFim == null;
		}
		return flgInicio;
	}

	public final void setFlgInicio(Boolean flgInicio) {
		this.flgInicio = flgInicio;
	}

	public final Date getDataInicio() {
		return dataInicio == null ? null : new Date(dataInicio.getTime());
	}

	public final void setDataInicio(Date dataInicio) {
		this.dataInicio = dataInicio == null ? null : new Date(dataInicio.getTime());
	}

	public Date getDataFim() {
		return dataFim == null ? null : new Date(dataFim.getTime());
	}

	public void setDataFim(Date dataFim) {
		this.dataFim = dataFim == null ? null : new Date(dataFim.getTime());
	}

	public final Atendente getAtendente() {
		return atendente;
	}

	public final void setAtendente(Atendente atendente) {
		this.atendente = atendente;
	}

	public final Caso getCaso() {
		return caso;
	}

	public final void setCaso(Caso caso) {
		this.caso = caso;
	}

	public final Status getStatus() {
		return status;
	}

	public final void setStatus(Status status) {
		this.status = status;
	}

	public void setConfiguracaoFila(ConfiguracaoFila configuracaoFila) {
		this.configuracaoFila = configuracaoFila;
	}

	public ConfiguracaoFila getConfiguracaoFila() {
		return configuracaoFila;
	}
	
	public static String getSqlCamposAtendimentoCaso() {
		return new StringBuilder()
				.append(" \nAtendimentoCaso.ID_ATENDIMENTO_CASO AS 'AtendimentoCaso.ID_ATENDIMENTO_CASO',")
				.append(" \nAtendimentoCaso.DATA_MARCACAO AS 'AtendimentoCaso.DATA_MARCACAO',")
				.append(" \nAtendimentoCaso.DATA_INICIO AS 'AtendimentoCaso.DATA_INICIO',")
				.append(" \nAtendimentoCaso.DATA_FIM AS 'AtendimentoCaso.DATA_FIM',")
				.append(" \nAtendimentoCaso.ID_ATENDENTE AS 'AtendimentoCaso.ID_ATENDENTE',")
				.append(" \nAtendimentoCaso.ID_CASO AS 'AtendimentoCaso.ID_CASO',")
                .append(" \nAtendimentoCaso.ID_STATUS AS 'AtendimentoCaso.ID_STATUS',")
                .append(" \nAtendimentoCaso.ID_CONFIGURACAO_FILA AS 'AtendimentoCaso.ID_CONFIGURACAO_FILA'").toString();

	}

	public static String getSqlFromAtendimentoCaso() {
		return " TB_ATENDIMENTO_CASO As AtendimentoCaso with(nolock) ";
	}

	public static AtendimentoCaso getAtendimentoCasoByResultSet(ResultSet resultSet) {
		try {
			
			if(resultSet.getInt("AtendimentoCaso.ID_ATENDIMENTO_CASO") == 0) {
        		return null;
        	}
			
			AtendimentoCaso atendimentoCaso = new AtendimentoCaso();

			atendimentoCaso.setIdAtendimentoCaso(resultSet.getInt("AtendimentoCaso.ID_ATENDIMENTO_CASO"));
			atendimentoCaso.setDataMarcacao(resultSet.getTimestamp("AtendimentoCaso.DATA_MARCACAO"));
			atendimentoCaso.setDataInicio(resultSet.getTimestamp("AtendimentoCaso.DATA_INICIO"));
			atendimentoCaso.setDataFim(resultSet.getTimestamp("AtendimentoCaso.DATA_FIM"));
			atendimentoCaso.setAtendente(resultSet.getInt("AtendimentoCaso.ID_ATENDENTE") == 0 ? null : new Atendente(resultSet.getInt("AtendimentoCaso.ID_ATENDENTE")));
			atendimentoCaso.setCaso(resultSet.getInt("AtendimentoCaso.ID_CASO") == 0 ? null : new Caso(resultSet.getInt("AtendimentoCaso.ID_CASO")));
			atendimentoCaso.setStatus(resultSet.getInt("AtendimentoCaso.ID_STATUS") == 0 ? null : new Status(resultSet.getInt("AtendimentoCaso.ID_STATUS")));
			atendimentoCaso.setConfiguracaoFila(resultSet.getInt("AtendimentoCaso.ID_CONFIGURACAO_FILA") == 0 ? null : new ConfiguracaoFila(resultSet.getInt("AtendimentoCaso.ID_CONFIGURACAO_FILA")));
            
			return atendimentoCaso;
		} catch (SQLException e) {
			throw new IllegalArgumentException("Erro ao montar objeto a partir do ResultSet", e);
		}
	}
	
}
