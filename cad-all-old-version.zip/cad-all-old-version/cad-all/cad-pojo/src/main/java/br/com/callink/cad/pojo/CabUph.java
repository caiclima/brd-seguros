package br.com.callink.cad.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;

/**
 *
 * @author miller(miller@swb.com.br)
 * 
 * @since 26/06/2012
 */
@Entity
@Table(name = "TB_CAB_UPH")
public class CabUph implements IEntity<Integer> {
    
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID_CAB_UPH", unique = true, nullable = false)
    private Integer idCabUph;
    
    @Column(name="DATA_INICIAL")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataInicial;
    
    @Column(name="DATA_FINAL")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataFinal;
    
    @Column(name="LOGIN_USUARIO", length = 50)
    private String logiUsuario;
    
    @Column(name="DESCRICAO", length = 50)
    private String descricao;
    
    @Column(name="META")
    private Double meta;
    
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_CONFIGURACAO_FILA", referencedColumnName = "ID_CONFIGURACAO_FILA", nullable = false)
	private ConfiguracaoFila configuracaoFila;

	
	
	public CabUph() {
		// TODO Auto-generated constructor stub
	}
	
	public CabUph(Integer idCabUph) {
		this.idCabUph = idCabUph;
	}
	
    public  Integer getPK() {
        return idCabUph;
    }
    
    public  void setPK(Integer id) {
        this.idCabUph = id;
    }
    
    public final Date getDataFinal() {
        return  dataFinal!= null ? new Date(dataFinal.getTime()) : null;
    }

    public final void setDataFinal(Date dataFinal) {
        this.dataFinal = dataFinal!= null ? new Date(dataFinal.getTime()) : null;
    }

    public final Date getDataInicial() {
        return dataInicial!= null ? new Date(dataInicial.getTime()) : null;
    }

    public final void setDataInicial(Date dataInicial) {
        this.dataInicial = dataInicial!= null ? new Date(dataInicial.getTime()) : null;
    }

    public final String getDescricao() {
        return descricao;
    }

    public final void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public final Integer getIdCabUph() {
        return idCabUph;
    }

    public final void setIdCabUph(Integer idCabUph) {
        this.idCabUph = idCabUph;
    }

    public ConfiguracaoFila getConfiguracaoFila() {
		return configuracaoFila;
	}

	public void setConfiguracaoFila(ConfiguracaoFila configuracaoFila) {
		this.configuracaoFila = configuracaoFila;
	}

	public final String getLogiUsuario() {
        return logiUsuario;
    }

    public final void setLogiUsuario(String logiUsuario) {
        this.logiUsuario = logiUsuario;
    }
    
    /* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((configuracaoFila == null) ? 0 : configuracaoFila.hashCode());
		result = prime * result
				+ ((idCabUph == null) ? 0 : idCabUph.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof CabUph)) {
			return false;
		}
		CabUph other = (CabUph) obj;
		if (configuracaoFila == null) {
			if (other.configuracaoFila != null) {
				return false;
			}
		} else if (!configuracaoFila.equals(other.configuracaoFila)) {
			return false;
		}
		if (idCabUph == null) {
			if (other.idCabUph != null) {
				return false;
			}
		} else if (!idCabUph.equals(other.idCabUph)) {
			return false;
		}
		return true;
	}

	@Override
    public final String toString() {
        return getDescricao();
    }

	public Double getMeta() {
		return meta;
	}

	public void setMeta(Double meta) {
		this.meta = meta;
	}

	public static String getSqlCamposCabUph() {
		return new StringBuilder()
				.append(" \nCabUph.ID_CAB_UPH AS 'CabUph.ID_CAB_UPH',")
				.append(" \nCabUph.DATA_INICIAL AS 'CabUph.DATA_INICIAL',")
				.append(" \nCabUph.DATA_FINAL AS 'CabUph.DATA_FINAL',")
				.append(" \nCabUph.LOGIN_USUARIO AS 'CabUph.LOGIN_USUARIO',")
				.append(" \nCabUph.DESCRICAO AS 'CabUph.DESCRICAO',")
				.append(" \nCabUph.META AS 'CabUph.META',")
                .append(" \nCabUph.ID_CONFIGURACAO_FILA AS 'CabUph.ID_CONFIGURACAO_FILA'").toString();
	}

	public static String getSqlFromCabUph() {
		return " TB_CAB_UPH As CabUph with(nolock) ";
	}

	public static CabUph getCabUphByResultSet(ResultSet resultSet) {
		try {
			
			if(resultSet.getInt("CabUph.ID_CAB_UPH") == 0) {
        		return null;
        	}
			
			CabUph cabUph = new CabUph();

			cabUph.setIdCabUph(resultSet.getInt("CabUph.ID_CAB_UPH"));
			cabUph.setDataInicial(resultSet.getTimestamp("CabUph.DATA_INICIAL"));
			cabUph.setDataFinal(resultSet.getTimestamp("CabUph.DATA_FINAL"));
			cabUph.setLogiUsuario(resultSet.getString("CabUph.LOGIN_USUARIO"));
			cabUph.setDescricao(resultSet.getString("CabUph.DESCRICAO"));
			cabUph.setMeta(resultSet.getDouble("CabUph.META"));
			cabUph.setConfiguracaoFila(resultSet.getInt("CabUph.ID_CONFIGURACAO_FILA") == 0 ? null : new ConfiguracaoFila(resultSet.getInt("CabUph.ID_CONFIGURACAO_FILA")));
            
			return cabUph;
		} catch (SQLException e) {
			throw new IllegalArgumentException("Erro ao montar objeto a partir do ResultSet", e);
		}
	}

}
