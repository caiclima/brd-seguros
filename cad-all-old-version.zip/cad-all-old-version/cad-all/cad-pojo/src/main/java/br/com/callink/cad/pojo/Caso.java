package br.com.callink.cad.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;

/**
 * 
 * @author Ednaldo Caic [ednaldo@swb.com.br]
 * @since 23/12/2011
 */
@Entity
@Table(name = "TB_CASO")
public class Caso implements IEntity<Integer> {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID_CASO", unique = true, nullable = false)
	private Integer idCaso;

	@Column(name = "DATA_ABERTURA")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataAbertura;

	@Column(name = "DATA_ENCERRAMENTO")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataEncerramento;

	@Column(name = "DATA_CADASTRO")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataCadastro;

	@Column(name = "DATA_FIM_SLA")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataFimSla;
        
        @Column(name = "DATA_VENCIMENTO_SLA")
	@Temporal(TemporalType.TIMESTAMP)
        private Date dataVencimentoSla;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_ATENDENTE", referencedColumnName = "ID_ATENDENTE")
	private Atendente atendente;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_STATUS", referencedColumnName = "ID_STATUS", nullable = false)
	private Status status;

	@Column(name = "FLAG_CLASSIFICA")
	private Boolean flagClassifica;

	@Column(name = "FLAG_FINALIZADO")
	private Boolean flagFinalizado;
        
    @Column(name = "FLAG_REABERTO")
	private Boolean flagReaberto;

	@Column(name = "FLAG_EM_ATENDIMENTO")
	private Boolean flagEmAtendimento;
	
	@Column(name = "FLAG_RECLASSIFICA_REABERTURA")
	private Boolean flagReclassificaReabertura;
	
	@Column(name = "FLAG_TELEFONE_EDITADO")
	private Boolean flagTelefoneEditado;
        
    @Column(name = "CLASSIFICACAO_COUNT", length = 10)
    private Integer classificacaoCount;
    
    @Column(name = "EDICAO_TELEFONE_COUNT", length = 10)
    private Integer edicaoTelefoneCount;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_CONFIGURACAO_FILA", referencedColumnName = "ID_CONFIGURACAO_FILA")
	private ConfiguracaoFila configuracaoFila;

	@Column(name = "ID_EXTERNO", length = 20)
	private String idExterno;
	
	private transient List<Agendamento> agendamentos;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_SLA_FILA", referencedColumnName = "ID_SLA_FILA")
	private SlaFila slaFila;

	private transient String slaEmMinutos;

	private transient String iconeSla;

	private transient Agendamento agendamento;

    private transient Boolean possuiEmailNaoLido;

    private transient String iconeEmail;
    
    private transient List<Email> emails; 
    
    private transient List<Log> logs;
    
    /**Guarda a porcentagem que ja foi gasta do sla*/
    private transient Double porcentagemSla = 0D;
        
	public Caso() {

	}

	public Caso(Integer idCaso) {
		this.idCaso = idCaso;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((idCaso == null) ? 0 : idCaso.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof Caso)) {
			return false;
		}
		Caso other = (Caso) obj;
		if (idCaso == null) {
			if (other.idCaso != null) {
				return false;
			}
		} else if (!idCaso.equals(other.idCaso)) {
			return false;
		}
		return true;
	}

	public Integer getPK() {
		return idCaso;
	}

	public void setPK(Integer pk) {
		this.idCaso = pk;
	}

	public final Integer getIdCaso() {
		return idCaso;
	}

	public final void setIdCaso(Integer idCaso) {
		this.idCaso = idCaso;
	}

	public final Date getDataEncerramento() {
		return dataEncerramento != null ? new Date(dataEncerramento.getTime())
				: null;
	}

	public final void setDataEncerramento(Date dataEncerramento) {
		this.dataEncerramento = dataEncerramento != null ? new Date(
				dataEncerramento.getTime()) : null;
	}

	public final Atendente getAtendente() {
		return atendente;
	}

	public final void setAtendente(Atendente atendente) {
		this.atendente = atendente;
	}

	public final Status getStatus() {
		return status;
	}

	public final void setStatus(Status status) {
		this.status = status;
	}

	public final String getSlaEmMinutos() {
		return slaEmMinutos;
	}

	public final void setSlaEmMinutos(String slaEmMinutos) {
		this.slaEmMinutos = slaEmMinutos;
	}

	public void setFlagClassifica(Boolean flagClassifica) {
		this.flagClassifica = flagClassifica;
	}

	public Boolean getFlagClassifica() {
		return flagClassifica;
	}

	public void setFlagFinalizado(Boolean flagFinalizado) {
		this.flagFinalizado = flagFinalizado;
	}

	public Boolean getFlagFinalizado() {
		return flagFinalizado;
	}

	public void setConfiguracaoFila(ConfiguracaoFila configuracaoFila) {
		this.configuracaoFila = configuracaoFila;
	}

	public ConfiguracaoFila getConfiguracaoFila() {
		return configuracaoFila;
	}

	public void setDataAbertura(Date dataAbertura) {
		this.dataAbertura = dataAbertura != null ? new Date(
				dataAbertura.getTime()) : null;
	}

	public Date getDataAbertura() {
		return dataAbertura != null ? new Date(dataAbertura.getTime()) : null;
	}

	public void setDataCadastro(Date dataCadastro) {
		this.dataCadastro = dataCadastro != null ? new Date(
				dataCadastro.getTime()) : null;
	}

	public Date getDataCadastro() {
		return dataCadastro != null ? new Date(dataCadastro.getTime()) : null;
	}

	public String getIdExterno() {
		return idExterno;
	}

	public void setIdExterno(String idExterno) {
		this.idExterno = idExterno;
	}

	public final void setIconeSla(String iconeSla) {
		this.iconeSla = iconeSla;
	}

	public String getIconeSla() {
		return iconeSla;
	}

	public Agendamento getAgendamento() {
		return agendamento;
	}

	public void setAgendamento(Agendamento agendamento) {
		this.agendamento = agendamento;
	}

	public Date getDataFimSla() {
		return dataFimSla == null ? null : new Date(dataFimSla.getTime());
	}

	public void setDataFimSla(Date dataFimSla) {
		this.dataFimSla = dataFimSla == null ? null : new Date(dataFimSla.getTime());
	}

	public Boolean getFlagEmAtendimento() {
		return flagEmAtendimento;
	}

	public void setFlagEmAtendimento(Boolean flagEmAtendimento) {
		this.flagEmAtendimento = flagEmAtendimento;
	}

    public Integer getClassificacaoCount() {
        return classificacaoCount;
    }

    public void setClassificacaoCount(Integer classificacaoCount) {
        this.classificacaoCount = classificacaoCount;
    }
    
	public Integer getEdicaoTelefoneCount() {
		return edicaoTelefoneCount;
	}
	
	public void setEdicaoTelefoneCount(Integer edicaoTelefoneCount) {
		this.edicaoTelefoneCount = edicaoTelefoneCount;
	}

	public static String getSqlCamposCaso() {
		return new StringBuilder()
				.append(" \nCaso.ID_CASO AS 'Caso.ID_CASO',")
				.append(" \nCaso.DATA_ABERTURA AS 'Caso.DATA_ABERTURA',")
				.append(" \nCaso.DATA_ENCERRAMENTO AS 'Caso.DATA_ENCERRAMENTO',")
				.append(" \nCaso.DATA_CADASTRO AS 'Caso.DATA_CADASTRO',")
				.append(" \nCaso.DATA_FIM_SLA AS 'Caso.DATA_FIM_SLA',")
				.append(" \nCaso.DATA_VENCIMENTO_SLA AS 'Caso.DATA_VENCIMENTO_SLA', ")
				.append(" \nCaso.ID_ATENDENTE AS 'Caso.ID_ATENDENTE',")
				.append(" \nCaso.ID_STATUS AS 'Caso.ID_STATUS',")
				.append(" \nCaso.FLAG_CLASSIFICA AS 'Caso.FLAG_CLASSIFICA',")
				.append(" \nCaso.FLAG_TELEFONE_EDITADO AS 'Caso.FLAG_TELEFONE_EDITADO',")
				.append(" \nCaso.FLAG_FINALIZADO AS 'Caso.FLAG_FINALIZADO',")
                .append(" \nCaso.FLAG_REABERTO AS 'Caso.FLAG_REABERTO',")
                .append(" \nCaso.FLAG_EM_ATENDIMENTO AS 'Caso.FLAG_EM_ATENDIMENTO',")
				.append(" \nCaso.ID_CONFIGURACAO_FILA AS 'Caso.ID_CONFIGURACAO_FILA',")
                .append(" \nCaso.CLASSIFICACAO_COUNT AS 'Caso.CLASSIFICACAO_COUNT',")
                .append(" \nCaso.EDICAO_TELEFONE_COUNT AS 'Caso.EDICAO_TELEFONE_COUNT',")
				.append(" \nCaso.ID_EXTERNO AS 'Caso.ID_EXTERNO',")
				.append(" \nCaso.FLAG_RECLASSIFICA_REABERTURA AS 'Caso.FLAG_RECLASSIFICA_REABERTURA', ")
				.append(" \nCaso.ID_SLA_FILA AS 'Caso.ID_SLA_FILA'").toString();
	}

	public static String getSqlFromCaso() {
		return " TB_CASO  AS Caso with(nolock) ";
	}

	public static Caso getCasoByResultSet(ResultSet resultSet) {

		Caso caso = new Caso();

		try {
			
			if(resultSet.getInt("Caso.ID_CASO") == 0) {
        		return null;
        	}
			
			caso.setIdCaso(resultSet.getInt("Caso.ID_CASO"));

			caso.setDataAbertura(resultSet.getTimestamp("Caso.DATA_ABERTURA"));
			caso.setDataEncerramento(resultSet.getTimestamp("Caso.DATA_ENCERRAMENTO"));
			caso.setDataCadastro(resultSet.getTimestamp("Caso.DATA_CADASTRO"));
			caso.setDataFimSla(resultSet.getTimestamp("Caso.DATA_FIM_SLA"));
			caso.setDataVencimentoSla(resultSet.getTimestamp("Caso.DATA_VENCIMENTO_SLA"));
			caso.setAtendente(resultSet.getInt("Caso.ID_ATENDENTE") == 0 ? null : new Atendente(resultSet.getInt("Caso.ID_ATENDENTE")));
			caso.setStatus(resultSet.getInt("Caso.ID_STATUS") == 0 ? null : new Status(resultSet.getInt("Caso.ID_STATUS")));
			caso.setFlagClassifica(resultSet.getBoolean("Caso.FLAG_CLASSIFICA"));
			caso.setFlagTelefoneEditado(resultSet.getBoolean("Caso.FLAG_TELEFONE_EDITADO"));
			caso.setFlagFinalizado(resultSet.getBoolean("Caso.FLAG_FINALIZADO"));
			caso.setConfiguracaoFila(resultSet.getInt("Caso.ID_CONFIGURACAO_FILA") == 0 ? null : new ConfiguracaoFila(resultSet.getInt("Caso.ID_CONFIGURACAO_FILA")));
            caso.setClassificacaoCount(resultSet.getInt("Caso.CLASSIFICACAO_COUNT"));
            caso.setEdicaoTelefoneCount(resultSet.getInt("Caso.EDICAO_TELEFONE_COUNT"));
            caso.setFlagReaberto(resultSet.getBoolean("Caso.FLAG_REABERTO"));
            caso.setFlagEmAtendimento(resultSet.getBoolean("Caso.FLAG_EM_ATENDIMENTO"));
			caso.setIdExterno(resultSet.getString("Caso.ID_EXTERNO"));
			caso.setSlaFila(resultSet.getInt("Caso.ID_SLA_FILA") == 0 ? null :  new SlaFila(resultSet.getInt("Caso.ID_SLA_FILA")));
			caso.setFlagReclassificaReabertura(resultSet.getBoolean("Caso.FLAG_RECLASSIFICA_REABERTURA"));
			
		} catch (SQLException e) {
			throw new IllegalArgumentException(
					"Erro ao montar objeto a partir do ResultSet", e);
		}
		return caso;
	}

	/**
	 * @param agendamentos the agendamentos to set
	 */
	public void setAgendamentos(List<Agendamento> agendamentos) {
		this.agendamentos = agendamentos;
	}

	/**
	 * @return the agendamentos
	 */
	public List<Agendamento> getAgendamentos() {
		return agendamentos;
	}

    public Boolean getPossuiEmailNaoLido() {
        return possuiEmailNaoLido;
    }

    public void setPossuiEmailNaoLido(Boolean possuiEmailNaoLido) {
        this.possuiEmailNaoLido = possuiEmailNaoLido;
    }

    public List<Email> getEmails() {
        return emails;
    }

    public void setEmails(List<Email> emails) {
        this.emails = emails;
    }

    public String getIconeEmail() {
        return iconeEmail;
    }

    public void setIconeEmail(String iconeEmail) {
        this.iconeEmail = iconeEmail;
    }

    public Boolean getFlagReaberto() {
        return flagReaberto;
    }

    public void setFlagReaberto(Boolean flagReaberto) {
        this.flagReaberto = flagReaberto;
    }

	/**
	 * @return the slaFila
	 */
	public SlaFila getSlaFila() {
		return slaFila;
	}

	/**
	 * @param slaFila the slaFila to set
	 */
	public void setSlaFila(SlaFila slaFila) {
		this.slaFila = slaFila;
	}

	/**
	 * @return the porcentagemSla
	 */
	public Double getPorcentagemSla() {
		return porcentagemSla;
	}

	/**
	 * @param porcentagemSla the porcentagemSla to set
	 */
	public void setPorcentagemSla(Double porcentagemSla) {
		this.porcentagemSla = porcentagemSla;
	}

	public Boolean getFlagReclassificaReabertura() {
		return flagReclassificaReabertura;
	}

	public void setFlagReclassificaReabertura(Boolean flagReclassificaReabertura) {
		this.flagReclassificaReabertura = flagReclassificaReabertura;
	}
	
	public Boolean getFlagTelefoneEditado() {
		return flagTelefoneEditado;
	}

	public void setFlagTelefoneEditado(Boolean flagTelefoneEditado) {
		this.flagTelefoneEditado = flagTelefoneEditado;
	}

    public Date getDataVencimentoSla() {
        return dataVencimentoSla;
    }

    public void setDataVencimentoSla(Date dataVencimentoSla) {
        this.dataVencimentoSla = dataVencimentoSla;
    }

	public List<Log> getLogs() {
		return logs;
	}

	public void setLogs(List<Log> logs) {
		this.logs = logs;
	}
	
}
