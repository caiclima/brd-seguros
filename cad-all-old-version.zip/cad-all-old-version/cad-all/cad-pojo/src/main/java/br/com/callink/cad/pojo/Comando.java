package br.com.callink.cad.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;

/**
*
* @author Ednaldo Caic [ednaldo@swb.com.br]
* @since 23/12/2011
*/
@Entity
@Table(name = "TB_COMANDO")
public class Comando implements IEntity<Integer> {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID_COMANDO", unique = true, nullable = false)
	private Integer idComando;

	@Column(name = "NOME", length = 200)
	private String nome;

	@Column(name = "DATA_CRIACAO")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataCriacao;

	@Column(name = "DESCRICAO")
	private String descricao;

	@Column(name = "FLAG_ATIVO")
	private Boolean flagAtivo;

	@Column(name = "BEAN_NAME", length = 500)
	private String beanName;
	
	@Column(name = "LOGIN_USUARIO", length = 50)
	private String loginUsuario;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_STATUS", referencedColumnName = "ID_STATUS")
	private Status status;
	
	public Comando() {
	}
	
	public Comando(Integer idComando) {
		super();
		this.idComando = idComando;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((idComando == null) ? 0 : idComando.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof Comando)) {
			return false;
		}
		Comando other = (Comando) obj;
		if (idComando == null) {
			if (other.idComando != null) {
				return false;
			}
		} else if (!idComando.equals(other.idComando)) {
			return false;
		}
		return true;
	}
	
	@Override
	public String toString() {
		return "Comando [nome=" + nome + ", descricao=" + descricao + "]";
	}

	public Integer getPK() {
		return idComando;
	}

	public void setPK(Integer pk) {
		this.idComando = pk;
	}

	public final Integer getIdComando() {
		return idComando;
	}

	public final void setIdComando(Integer idComando) {
		this.idComando = idComando;
	}

	public final String getNome() {
		return nome;
	}

	public final void setNome(String nome) {
		this.nome = nome;
	}

	public final Date getDataCriacao() {
		return dataCriacao != null ? new Date(dataCriacao.getTime()) : null;
	}

	public final void setDataCriacao(Date dataCriacao) {
		this.dataCriacao = dataCriacao != null ? new Date(dataCriacao.getTime()) : null;
	}

	public final String getDescricao() {
		return descricao;
	}

	public final void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public final String getBeanName() {
		return beanName;
	}

	public final void setBeanName(String beanName) {
		this.beanName = beanName;
	}

	public void setLoginUsuario(String loginUsuario) {
		this.loginUsuario = loginUsuario;
	}

	public String getLoginUsuario() {
		return loginUsuario;
	}

	public final Boolean getFlagAtivo() {
		return flagAtivo;
	}

	public final void setFlagAtivo(Boolean flagAtivo) {
		this.flagAtivo = flagAtivo;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}
	
	public static String getSqlCamposComando() {
		return new StringBuilder()
				.append(" \nComando.ID_COMANDO AS 'Comando.ID_COMANDO',")
				.append(" \nComando.NOME AS 'Comando.NOME',")
				.append(" \nComando.DATA_CRIACAO AS 'Comando.DATA_CRIACAO',")
				.append(" \nComando.DESCRICAO AS 'Comando.DESCRICAO',")
				.append(" \nComando.FLAG_ATIVO AS 'Comando.FLAG_ATIVO',")
				.append(" \nComando.BEAN_NAME AS 'Comando.BEAN_NAME',")
                .append(" \nComando.LOGIN_USUARIO AS 'Comando.LOGIN_USUARIO',")
                .append(" \nComando.ID_STATUS AS 'Comando.ID_STATUS'").toString();
	}

	public static String getSqlFromComando() {
		return " TB_COMANDO As Comando with(nolock) ";
	}

	public static Comando getComandoByResultSet(ResultSet resultSet) {
		try {
			
			if(resultSet.getInt("Comando.ID_COMANDO") == 0) {
        		return null;
        	}
			
			Comando comando = new Comando();

			comando.setIdComando(resultSet.getInt("Comando.ID_COMANDO"));
			comando.setNome(resultSet.getString("Comando.NOME"));
			comando.setDataCriacao(resultSet.getTimestamp("Comando.DATA_CRIACAO"));
			comando.setDescricao(resultSet.getString("Comando.DESCRICAO"));
			comando.setFlagAtivo(resultSet.getBoolean("Comando.FLAG_ATIVO"));
			comando.setBeanName(resultSet.getString("Comando.BEAN_NAME"));
			comando.setLoginUsuario(resultSet.getString("Comando.LOGIN_USUARIO"));
			comando.setStatus(resultSet.getInt("Comando.ID_STATUS") == 0 ? null : new Status(resultSet.getInt("Comando.ID_STATUS")));
            
			return comando;
		} catch (SQLException e) {
			throw new IllegalArgumentException("Erro ao montar objeto a partir do ResultSet", e);
		}
	}

}
