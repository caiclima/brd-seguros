package br.com.callink.cad.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;

@Entity
@Table(name = "TB_CONFIGURACAO_EMAIL")
public class ConfiguracaoEmail implements IEntity<Integer> {

	private static final long serialVersionUID = 608490152138281566L;
    
	@Id
	@Column(name = "ID_CONFIGURACAO_EMAIL")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer idConfiguracaoEmail;
	
	@Column(name = "EMAIL")
	private String email;
	
	@Column(name = "SENHA")
	private String senha;
	
	@Column(name = "SMTP")
	private String smtp;
	
	@Column(name = "POP")
	private String pop;
	
	@Column(name = "FOLDER")
	private String folder;
	
	@Column(name = "PROTOCOL_STORE")
	private String protocolStore;
	
	@Column(name = "ASSINATURA")
	private String assinatura;
	
	@Column(name = "LOGIN_USUARIO")
	private String loginUsuario;
	
	@Column(name = "PORTA")
	private Integer porta;
	
	@Column(name = "FLAG_ATIVO")
	private Boolean flagAtivo;
	
	@Column(name = "FLAG_PRINCIPAL")
	private Boolean flagPrincipal;
	
	@Column(name = "DATA_CRIACAO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataCriacao;

	public ConfiguracaoEmail() {

	}

	public ConfiguracaoEmail(Integer idConfiguracaoEmail) {
		this.idConfiguracaoEmail = idConfiguracaoEmail;
	}

	public Integer getPK() {
		return idConfiguracaoEmail;
	}

	public void setPK(Integer pk) {
		idConfiguracaoEmail = pk;
	}


	public final Boolean getFlagAtivo() {
		return flagAtivo;
	}

	public final void setFlagAtivo(Boolean flagAtivo) {
		this.flagAtivo = flagAtivo;
	}

	@Override
	public String toString() {
		return this.getEmail();
	}

	public Integer getIdConfiguracaoEmail() {
		return idConfiguracaoEmail;
	}

	public void setIdConfiguracaoEmail(Integer idConfiguracaoEmail) {
		this.idConfiguracaoEmail = idConfiguracaoEmail;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public String getSmtp() {
		return smtp;
	}

	public void setSmtp(String smtp) {
		this.smtp = smtp;
	}

	public String getPop() {
		return pop;
	}

	public void setPop(String pop) {
		this.pop = pop;
	}

	public String getProtocolStore() {
		return protocolStore;
	}

	public void setProtocolStore(String protocolStore) {
		this.protocolStore = protocolStore;
	}

	public String getFolder() {
		return folder;
	}

	public void setFolder(String folder) {
		this.folder = folder;
	}

	public Integer getPorta() {
		return porta;
	}

	public void setPorta(Integer porta) {
		this.porta = porta;
	}

	public final Date getDataCriacao() {
		return dataCriacao == null ? null : new Date(dataCriacao.getTime());
	}

	public final void setDataCriacao(Date dataCriacao) {
		this.dataCriacao = dataCriacao == null ? null : new Date(dataCriacao.getTime());
	}

	public String getAssinatura() {
		return assinatura;
	}

	public void setAssinatura(String assinatura) {
		this.assinatura = assinatura;
	}

	public String getLoginUsuario() {
		return loginUsuario;
	}

	public void setLoginUsuario(String loginUsuario) {
		this.loginUsuario = loginUsuario;
	}

	public Boolean getFlagPrincipal() {
		return flagPrincipal;
	}

	public void setFlagPrincipal(Boolean flagPrincipal) {
		this.flagPrincipal = flagPrincipal;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((idConfiguracaoEmail == null) ? 0 : idConfiguracaoEmail.hashCode());
		return result;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof ConfiguracaoEmail)) {
			return false;
		}
		ConfiguracaoEmail other = (ConfiguracaoEmail) obj;
		if (idConfiguracaoEmail == null) {
			if (other.idConfiguracaoEmail != null) {
				return false;
			}
		} else if (!idConfiguracaoEmail.equals(other.idConfiguracaoEmail)) {
			return false;
		}
		return true;
	}
	
	public static String getSqlCamposConfiguracaoEmail() {

        return new StringBuilder()
                .append(" \nConfiguracaoEmail.ID_CONFIGURACAO_EMAIL AS 'ConfiguracaoEmail.ID_CONFIGURACAO_EMAIL', ")
                .append(" \nConfiguracaoEmail.EMAIL AS 'ConfiguracaoEmail.EMAIL', ")
                .append(" \nConfiguracaoEmail.SENHA AS 'ConfiguracaoEmail.SENHA', ")
                .append(" \nConfiguracaoEmail.SMTP AS 'ConfiguracaoEmail.SMTP', ")
                .append(" \nConfiguracaoEmail.POP AS 'ConfiguracaoEmail.POP', ")
                .append(" \nConfiguracaoEmail.FOLDER AS 'ConfiguracaoEmail.FOLDER', ")
                .append(" \nConfiguracaoEmail.PROTOCOL_STORE AS 'ConfiguracaoEmail.PROTOCOL_STORE', ")
                .append(" \nConfiguracaoEmail.PORTA AS 'ConfiguracaoEmail.PORTA', ")
                .append(" \nConfiguracaoEmail.FLAG_ATIVO AS 'ConfiguracaoEmail.FLAG_ATIVO', ")
                .append(" \nConfiguracaoEmail.ASSINATURA AS 'ConfiguracaoEmail.ASSINATURA', ")
                .append(" \nConfiguracaoEmail.LOGIN_USUARIO AS 'ConfiguracaoEmail.LOGIN_USUARIO', ")
                .append(" \nConfiguracaoEmail.FLAG_PRINCIPAL AS 'ConfiguracaoEmail.FLAG_PRINCIPAL', ")
                .append(" \nConfiguracaoEmail.DATA_CRIACAO AS 'ConfiguracaoEmail.DATA_CRIACAO' ")
                .toString();
    }

    public static String getSqlFromConfiguracaoEmail() {
        return " TB_CONFIGURACAO_EMAIL  AS ConfiguracaoEmail with(nolock) ";
    }

    public static ConfiguracaoEmail getConfiguracaoEmailByResultSet(
            ResultSet resultSet) {
        try {
        	
        	if(resultSet.getInt("ConfiguracaoEmail.ID_CONFIGURACAO_EMAIL") == 0){
        		return null;
        	}
        	
        	ConfiguracaoEmail configuracaoEmail = new ConfiguracaoEmail();
        	configuracaoEmail.setIdConfiguracaoEmail(resultSet.getInt("ConfiguracaoEmail.ID_CONFIGURACAO_EMAIL"));
        	configuracaoEmail.setEmail(resultSet.getString("ConfiguracaoEmail.EMAIL"));
        	configuracaoEmail.setSenha(resultSet.getString("ConfiguracaoEmail.SENHA"));
        	configuracaoEmail.setSmtp(resultSet.getString("ConfiguracaoEmail.SMTP"));
        	configuracaoEmail.setPop(resultSet.getString("ConfiguracaoEmail.POP"));
        	configuracaoEmail.setFolder(resultSet.getString("ConfiguracaoEmail.FOLDER"));
        	configuracaoEmail.setProtocolStore(resultSet.getString("ConfiguracaoEmail.PROTOCOL_STORE"));
        	configuracaoEmail.setPorta(resultSet.getInt("ConfiguracaoEmail.PORTA"));
        	configuracaoEmail.setFlagAtivo(resultSet.getBoolean("ConfiguracaoEmail.FLAG_ATIVO"));
        	configuracaoEmail.setFlagPrincipal(resultSet.getBoolean("ConfiguracaoEmail.FLAG_PRINCIPAL"));
        	configuracaoEmail.setDataCriacao(resultSet.getTimestamp("ConfiguracaoEmail.DATA_CRIACAO"));
        	configuracaoEmail.setAssinatura(resultSet.getString("ConfiguracaoEmail.ASSINATURA"));
        	configuracaoEmail.setLoginUsuario(resultSet.getString("ConfiguracaoEmail.LOGIN_USUARIO"));
        	return configuracaoEmail;
        } catch (SQLException e) {
            throw new IllegalArgumentException(
                    "Erro ao montar objeto a partir do ResultSet", e);
        }
    }


}
