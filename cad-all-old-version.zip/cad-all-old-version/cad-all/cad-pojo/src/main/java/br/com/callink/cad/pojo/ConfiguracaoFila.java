package br.com.callink.cad.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;

/**
 * 
 * @author Ednaldo Caic [ednaldo@swb.com.br]
 * @since 23/12/2011
 */
@Entity
@Table(name = "TB_CONFIGURACAO_FILA")
public class ConfiguracaoFila implements IEntity<Integer> {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID_CONFIGURACAO_FILA", unique = true, nullable = false)
	private Integer idConfiguracaoFila;

	@Column(name = "nome", length = 50)
	private String nome;

	@Column(name = "DATA_CRIACAO")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataCriacao;

	@Column(name = "FLAG_ATIVO")
	private Boolean flagAtivo;

	@Column(name = "DESCRICAO")
	private String descricao;

	@Column(name = "FLAG_BUILD")
	private Boolean flagBuild;

	@Column(name = "PRIORIDADE", length = 10)
	private Integer prioridade;

	@Column(name = "LOGIN_USUARIO", length = 50)
	private String loginUsuario;

	@Column(name = "DATA_ALTERACAO")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataAlteracao;

	@Column(name = "SQL_WHERE")
	private String sqlWhere;

	@Column(name = "SQL_ORDER")
	private String sqlOrder;
	
	@Column(name = "FLAG_BLOQUEIA_CASO_IMPORTACAO")
	private Boolean flagBloqueiaCasoImportacao;

	

	private transient boolean selecionado;

	public ConfiguracaoFila() {

	}

	public ConfiguracaoFila(Integer idConfiguracaoFiila) {
		this.idConfiguracaoFila = idConfiguracaoFiila;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((idConfiguracaoFila == null) ? 0 : idConfiguracaoFila
						.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof ConfiguracaoFila)) {
			return false;
		}
		ConfiguracaoFila other = (ConfiguracaoFila) obj;
		if (idConfiguracaoFila == null) {
			if (other.idConfiguracaoFila != null) {
				return false;
			}
		} else if (!idConfiguracaoFila.equals(other.idConfiguracaoFila)) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return nome;
	}

	public Integer getPK() {
		return idConfiguracaoFila;
	}

	public void setPK(Integer pk) {
		this.idConfiguracaoFila = pk;
	}

	public final Integer getIdConfiguracaoFila() {
		return idConfiguracaoFila;
	}

	public final void setIdConfiguracaoFila(Integer idConfiguracaoFila) {
		this.idConfiguracaoFila = idConfiguracaoFila;
	}

	public final String getNome() {
		return nome;
	}

	public final void setNome(String nome) {
		this.nome = nome;
	}

	public final Date getDataCriacao() {
		return dataCriacao != null ? new Date(dataCriacao.getTime()) : null;
	}

	public final void setDataCriacao(Date dataCriacao) {
		this.dataCriacao = dataCriacao != null ? new Date(dataCriacao.getTime())
				: null;
	}

	public final Boolean getFlagAtivo() {
		return flagAtivo;
	}

	public final void setFlagAtivo(Boolean flagAtivo) {
		this.flagAtivo = flagAtivo;
	}

	public final String getDescricao() {
		return descricao;
	}

	public final void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public void setFlagBuild(Boolean flagBuild) {
		this.flagBuild = flagBuild;
	}

	public Boolean getFlagBuild() {
		return flagBuild;
	}

	public void setPrioridade(Integer prioridade) {
		this.prioridade = prioridade;
	}

	public Integer getPrioridade() {
		return prioridade;
	}

	public void setLoginUsuario(String loginUsuario) {
		this.loginUsuario = loginUsuario;
	}

	public String getLoginUsuario() {
		return loginUsuario;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao != null ? new Date(
				dataAlteracao.getTime()) : null;
	}

	public Date getDataAlteracao() {
		return dataAlteracao != null ? new Date(dataAlteracao.getTime()) : null;
	}
	
	public final Boolean getFlagBloqueiaCasoImportacao() {
		return flagBloqueiaCasoImportacao;
	}

	public final void setFlagBloqueiaCasoImportacao(
			Boolean flagBloqueiaCasoImportacao) {
		this.flagBloqueiaCasoImportacao = flagBloqueiaCasoImportacao;
	}

	/**
	 * @return the sqlWhere
	 */
	public final String getSqlWhere() {
		return sqlWhere;
	}

	/**
	 * @param sqlWhere
	 *            the sqlWhere to set
	 */
	public final void setSqlWhere(String sqlWhere) {
		this.sqlWhere = sqlWhere;
	}

	/**
	 * @return the sqlOrder
	 */
	public final String getSqlOrder() {
		return sqlOrder;
	}

	/**
	 * @param sqlOrder
	 *            the sqlOrder to set
	 */
	public final void setSqlOrder(String sqlOrder) {
		this.sqlOrder = sqlOrder;
	}

	public final Boolean getSelecionado() {
		return selecionado;
	}

	public final void setSelecionado(Boolean selecionado) {
		this.selecionado = selecionado;
	}
        
        
    public static String getSqlCamposConfiguracaoFila() {

        return new StringBuilder()
                .append(" \nConfiguracaoFila.ID_CONFIGURACAO_FILA AS 'ConfiguracaoFila.ID_CONFIGURACAO_FILA', ")
                .append(" \nConfiguracaoFila.NOME AS 'ConfiguracaoFila.NOME', ")
                .append(" \nConfiguracaoFila.DESCRICAO AS 'ConfiguracaoFila.DESCRICAO', ")
                .append(" \nConfiguracaoFila.FLAG_ATIVO AS 'ConfiguracaoFila.FLAG_ATIVO', ")
                .append(" \nConfiguracaoFila.PRIORIDADE AS 'ConfiguracaoFila.PRIORIDADE', ")
                .append(" \nConfiguracaoFila.LOGIN_USUARIO AS 'ConfiguracaoFila.LOGIN_USUARIO', ")
                .append(" \nConfiguracaoFila.DATA_CRIACAO AS 'ConfiguracaoFila.DATA_CRIACAO', ")
                .append(" \nConfiguracaoFila.FLAG_BUILD AS 'ConfiguracaoFila.FLAG_BUILD', ")
                .append(" \nConfiguracaoFila.SQL_WHERE AS 'ConfiguracaoFila.SQL_WHERE', ")
                .append(" \nConfiguracaoFila.SQL_ORDER AS 'ConfiguracaoFila.SQL_ORDER', ")                
                .append(" \nConfiguracaoFila.DATA_ALTERACAO AS 'ConfiguracaoFila.DATA_ALTERACAO', ")
                .append(" \nConfiguracaoFila.FLAG_BLOQUEIA_CASO_IMPORTACAO AS 'ConfiguracaoFila.FLAG_BLOQUEIA_CASO_IMPORTACAO' ").toString();
    }

    public static String getSqlFromConfiguracaoFila() {
        return " TB_CONFIGURACAO_FILA  AS ConfiguracaoFila with(nolock) ";
    }
    
    public static ConfiguracaoFila getConfiguracaoFilaByResultSet(ResultSet rs) {
        try {
        	
        	if(rs.getInt("ConfiguracaoFila.ID_CONFIGURACAO_FILA") == 0) {
        		return null;
        	}
        			
            ConfiguracaoFila configuracaoFila = new ConfiguracaoFila();
            configuracaoFila.setIdConfiguracaoFila(rs.getInt("ConfiguracaoFila.ID_CONFIGURACAO_FILA"));
            configuracaoFila.setNome(rs.getString("ConfiguracaoFila.NOME"));
            configuracaoFila.setDescricao(rs.getString("ConfiguracaoFila.DESCRICAO"));
            configuracaoFila.setFlagAtivo(rs.getBoolean("ConfiguracaoFila.FLAG_ATIVO"));
            configuracaoFila.setFlagBloqueiaCasoImportacao(rs.getBoolean("ConfiguracaoFila.FLAG_BLOQUEIA_CASO_IMPORTACAO"));
            configuracaoFila.setPrioridade(rs.getInt("ConfiguracaoFila.PRIORIDADE"));
            configuracaoFila.setLoginUsuario(rs.getString("ConfiguracaoFila.LOGIN_USUARIO"));
            configuracaoFila.setDataCriacao(rs.getTimestamp("ConfiguracaoFila.DATA_CRIACAO"));
            configuracaoFila.setFlagBuild(rs.getBoolean("ConfiguracaoFila.FLAG_BUILD"));
            configuracaoFila.setSqlWhere(rs.getString("ConfiguracaoFila.SQL_WHERE"));
            configuracaoFila.setSqlOrder(rs.getString("ConfiguracaoFila.SQL_ORDER"));
            configuracaoFila.setDataAlteracao(rs.getTimestamp("ConfiguracaoFila.DATA_ALTERACAO"));
            return configuracaoFila;
        } catch (SQLException ex) {
            throw new IllegalArgumentException(
                    "Erro ao montar objeto a partir do ResultSet", ex);
        }
    }

}
