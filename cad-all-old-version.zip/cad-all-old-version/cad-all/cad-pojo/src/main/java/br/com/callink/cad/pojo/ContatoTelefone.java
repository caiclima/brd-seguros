package br.com.callink.cad.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import br.com.callink.cad.pojo.entity.IEntity;

@Entity
@Table(name = "TB_CONTATO_TELEFONE")
public class ContatoTelefone implements IEntity<Integer> {

	private static final long serialVersionUID = -7123115231908454923L;

	@Id
	@Column(name = "ID_CONTATO_TELEFONE")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idContatoTelefone;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_CASO", referencedColumnName = "ID_CASO")
	private Caso caso;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_ATENDENTE", referencedColumnName = "ID_ATENDENTE")
    private Atendente atendente;
    
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_TELEFONE", referencedColumnName = "ID_TELEFONE")
	private Telefone telefone;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_EVENTO_LIGACAO", referencedColumnName = "ID_EVENTO_LIGACAO")
	private EventoLigacao eventoLigacao;
	
    @Column(name = "DATA_CRIACAO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataCriacao;
	
    public ContatoTelefone() {
    }

    public ContatoTelefone(Integer idContatoEventoLigacao) {
        this.idContatoTelefone = idContatoEventoLigacao;
    }

    public Integer getPK() {
        return idContatoTelefone;
    }

    public void setPK(Integer pk) {
        this.idContatoTelefone = pk;
    }
    
	public Integer getIdContatoTelefone() {
		return idContatoTelefone;
	}
	
	public void setIdContatoTelefone	(Integer idContato) {
		this.idContatoTelefone = idContato;
	}
	
	public Atendente getAtendente() {
		return atendente;
	}
	
	public void setAtendente(Atendente atendente) {
		this.atendente = atendente;
	}

	public Caso getCaso() {
		return caso;
	}
	
	public void setCaso(Caso caso) {
		this.caso = caso;
	}

	public Telefone getTelefone() {
		return telefone;
	}
	
	public void setTelefone(Telefone telefone) {
		this.telefone = telefone;
	}
	
	public EventoLigacao getEventoLigacao() {
		return eventoLigacao;
	}
	
	public void setEventoLigacao(EventoLigacao eventoLigacao) {
		this.eventoLigacao = eventoLigacao;
	}
	
	public Date getDataCriacao() {
		return dataCriacao;
	}

	public void setDataCriacao(Date dataContato) {
		this.dataCriacao = dataContato;
	}

	public static String getSqlContato() {
        return new StringBuilder().append(" \nContatoTelefone.ID_CONTATO_TELEFONE AS 'ContatoTelefone.ID_CONTATO_TELEFONE',")
        		.append(" \nContatoTelefone.ID_ATENDENTE AS 'ContatoTelefone.ID_ATENDENTE',")
        		.append(" \nContatoTelefone.ID_CASO AS 'ContatoTelefone.ID_CASO',")
        		.append(" \nContatoTelefone.ID_TELEFONE AS 'ContatoTelefone.ID_TELEFONE',")
                .append(" \nContatoTelefone.ID_EVENTO_LIGACAO AS 'ContatoTelefone.ID_EVENTO_LIGACAO',")
                .append(" \nContatoTelefone.DATA_CRIACAO AS 'ContatoTelefone.DATA_CRIACAO'").toString();
   }
   
   public static String getSqlFromContato() {
       return " TB_CONTATO_TELEFONE AS ContatoTelefone with(nolock) ";
   }

   public static ContatoTelefone getContatoByResultSet(ResultSet rs) {
        try {
        	
        	if(rs.getInt("Contato.ID_CONTATO_TELEFONE") == 0){
        		return null;
        	}
        	
            ContatoTelefone contato = new ContatoTelefone();
            contato.setIdContatoTelefone(rs.getInt("ContatoTelefone.ID_CONTATO_TELEFONE"));
            contato.setAtendente(new Atendente(rs.getInt("ContatoTelefone.ID_ATENDENTE")));
            contato.setCaso(new Caso(rs.getInt("ContatoTelefone.ID_CASO")));
            contato.setTelefone(new Telefone(rs.getInt("ContatoTelefone.ID_TELEFONE")));
            contato.setEventoLigacao(new EventoLigacao(rs.getInt("ContatoTelefone.ID_EVENTO_LIGACAO")));
            contato.setDataCriacao(rs.getDate("ContaContatoTelefoneto.DATA_CRIACAO"));
            return contato;
        } catch (SQLException ex) {
            throw new IllegalArgumentException(
                    "Erro ao montar objeto a partir do ResultSet", ex);
        }
    }
   

    @Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((idContatoTelefone == null) ? 0 : idContatoTelefone.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof ContatoTelefone)) {
			return false;
		}
		ContatoTelefone other = (ContatoTelefone) obj;
		if (idContatoTelefone == null) {
			if (other.idContatoTelefone != null) {
				return false;
			}
		} else if (!idContatoTelefone.equals(other.idContatoTelefone)) {
			return false;
		}
		return true;
	}
    
   
}
