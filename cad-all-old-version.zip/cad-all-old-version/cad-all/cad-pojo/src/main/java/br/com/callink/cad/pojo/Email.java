package br.com.callink.cad.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;

/**
 *
 * @author luiz gustavo f
 */
@Entity
@Table(name = "TB_EMAIL")
public class Email implements IEntity<Integer> {

	private static final long serialVersionUID = 1L;

	public Email() {
    }
    
    public Email(Integer idEmail) {
        this.idEmail = idEmail;
    }
    
    @Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID_EMAIL", unique = true, nullable = false)
    private Integer idEmail;
    
    @Column(name = "ASSUNTO", length = 200)
    private String assunto;
    
    @Column(name = "REMETENTE", length = 200)
    private String remetente;
    
    @Column(name = "DESTINATARIO")
    private String destinatario;
    
    @Column(name = "CONTEUDO")
    private String conteudo;
    
    @Column(name = "DATA_ENVIO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataEnvio;
    
    //Flag para sinalizar se o e-mail está sendo gerado pelo sistema. Se for true o sistema que envia o e-mail.
    private transient boolean emailSistema;
   
    /**
     * indica que o envio do email está pendente - deixar esta Flag TRUE 
     * quando se deseja que o email seja enviado pela Thread de envio de emails
     */
    @Column(name = "FLAG_ENVIO_PENDENTE")
    private Boolean flagEnvioPendente;
    /**
     * FLAG QUE INDICA SE HOUVE ERRO NO ENVIO DO EMAIL
     * A thread de envio ignora todos emails com esta flag true
     */
    @Column(name = "FLAG_ERRO_ENVIO")
    private Boolean flagErroEnvio;
    
    /**
     * flag que indica se o email está sendo enviado pelo GBO (true) ou sendo recebido pelo GBO (gbo)
     */
    @Column(name = "FLAG_ENVIO")
    private Boolean flagEnvio;
    
    /**
     * Flag que indica se o email está associado a um caso
     */
    @Column(name = "FLAG_POSSUI_CASO")
    private Boolean flagPossuiCaso;
    
    /**
     * PARA EMAILS RECEBIDOS, INDICA SE O EMAIL JA FOI LIDO POR ALGUM ATENDENTE
     */
    @Column(name = "FLAG_LIDO")
    private Boolean flagLido;
    
    /**
     * Flag que representa um e-mail que não será apresentado.
     */
    @Column(name = "FLAG_DESATIVADO")
    private Boolean flagDesativado = Boolean.FALSE;
    
    @ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_GRUPO_EMAIL", referencedColumnName = "ID_GRUPO_EMAIL")
    private GrupoEmail grupoEmail;
    
    @ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_GRUPO_ANEXO", referencedColumnName = "ID_GRUPO_ANEXO")
    private GrupoAnexo grupoAnexo;
    
    @ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_PAI", referencedColumnName = "ID_EMAIL")
    private Email pai;
    
    @ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_CONFIGURACAO_EMAIL", referencedColumnName = "ID_CONFIGURACAO_EMAIL")
    private ConfiguracaoEmail configuracaoEmail;
    
    @Column(name="destinatario_para_exibicao")
    private String destinatarioParaExibicao;
    
    @Column(name = "DESTINATARIO_COPIA")
    private String destinatarioCopia;
    
    @Column(name = "DESTINATARIO_COPIA_OCULTA")
    private String destinatarioCopiaOculta;
    
    private transient List<GrupoEmail> listaDestinatarios;
    private transient List<Anexo> listaAnexos;
    private transient StringBuffer mensagemTxt;
    private transient StringBuffer mensagemHtml;
    private transient String descricaoLog;
    
    public List<Anexo> getListaAnexos() {
        if (listaAnexos == null) {
            listaAnexos = new ArrayList<Anexo>();
        }
        return listaAnexos;
    }

    public void setListaAnexos(List<Anexo> listaAnexos) {
        this.listaAnexos = listaAnexos;
    }

    public String getAssunto() {
        return assunto;
    }

    public void setAssunto(String assunto) {
        this.assunto = assunto;
    }

    public String getConteudo() {
        return conteudo;
    }

    public void setConteudo(String conteudo) {
        this.conteudo = conteudo;
    }

    public Date getDataEnvio() {
        return dataEnvio == null ? null : new Date(dataEnvio.getTime());
    }

    public void setDataEnvio(Date dataEnvio) {
        this.dataEnvio = dataEnvio == null ? null : new Date(dataEnvio.getTime());
    }

    public String getDestinatario() {
        return destinatario;
    }

    public void setDestinatario(String destinatario) {
        this.destinatario = destinatario;
    }

    public Integer getIdEmail() {
        return idEmail;
    }

    public void setIdEmail(Integer idEmail) {
        this.idEmail = idEmail;
    }

    public String getRemetente() {
        return remetente;
    }

    public void setRemetente(String remetente) {
        this.remetente = remetente;
    }

    public Boolean getFlagEnvio() {
        return flagEnvio;
    }

    public void setFlagEnvio(Boolean flagEnvio) {
        this.flagEnvio = flagEnvio;
    }

    public GrupoEmail getGrupoEmail() {
        return grupoEmail;
    }

    public void setGrupoEmail(GrupoEmail grupoEmail) {
        this.grupoEmail = grupoEmail;
    }

    public Boolean getFlagEnvioPendente() {
        return flagEnvioPendente;
    }

    public void setFlagEnvioPendente(Boolean flagEnvioPendente) {
        this.flagEnvioPendente = flagEnvioPendente;
    }

    public Boolean getFlagErroEnvio() {
        return flagErroEnvio;
    }

    public void setFlagErroEnvio(Boolean flagErroEnvio) {
        this.flagErroEnvio = flagErroEnvio;
    }

    public Boolean getFlagLido() {
        return flagLido;
    }

    public void setFlagLido(Boolean flagLido) {
        this.flagLido = flagLido;
    }

    public Boolean getFlagPossuiCaso() {
        return flagPossuiCaso;
    }

    public void setFlagPossuiCaso(Boolean flagPossuiCaso) {
        this.flagPossuiCaso = flagPossuiCaso;
    }

    public StringBuffer getMensagemHtml() {
        if (mensagemHtml == null) {
            mensagemHtml = new StringBuffer();
        }
        return mensagemHtml;
    }

    public void setMensagemHtml(StringBuffer mensagemHtml) {
        this.mensagemHtml = mensagemHtml;
    }

    public StringBuffer getMensagemTxt() {
        if (mensagemTxt == null) {
            mensagemTxt = new StringBuffer();
        }
        return mensagemTxt;
    }

    public void setMensagemTxt(StringBuffer mensagemTxt) {
        this.mensagemTxt = mensagemTxt;
    }

    public GrupoAnexo getGrupoAnexo() {
        return grupoAnexo;
    }

    public void setGrupoAnexo(GrupoAnexo grupoAnexo) {
        this.grupoAnexo = grupoAnexo;
    }

    public Integer getPK() {
        return idEmail;
    }

    public void setPK(Integer idEmail) {
        this.idEmail = idEmail;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Email other = (Email) obj;
        if (this.idEmail == null || !this.idEmail.equals(other.idEmail)) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 71 * hash + (this.idEmail != null ? this.idEmail.hashCode() : 0);
        return hash;
    }

    public Email getPai() {
        return pai;
    }

    public void setPai(Email pai) {
        this.pai = pai;
    }

    public List<GrupoEmail> getListaDestinatarios() {
        return listaDestinatarios;
    }

    public void setListaDestinatarios(List<GrupoEmail> listaDestinatarios) {
        this.listaDestinatarios = listaDestinatarios;
    }

    public String getDescricaoLog() {
        return descricaoLog;
    }

    public void setDescricaoLog(String descricaoLog) {
        this.descricaoLog = descricaoLog;
    }

    public String getDestinatarioParaExibicao() {
        return destinatarioParaExibicao;
    }

    public void setDestinatarioParaExibicao(String destinatarioParaExibicao) {
        this.destinatarioParaExibicao = destinatarioParaExibicao;
    }

    public boolean isEmailSistema() {
        return emailSistema;
    }

    public void setEmailSistema(boolean emailSistema) {
        this.emailSistema = emailSistema;
    }
    
    public Boolean getFlagDesativado() {
		return flagDesativado;
	}

	public void setFlagDesativado(Boolean flagDesativado) {
		this.flagDesativado = flagDesativado;
	}
	
	public ConfiguracaoEmail getConfiguracaoEmail() {
		return configuracaoEmail;
	}

	public void setConfiguracaoEmail(ConfiguracaoEmail configuracaoEmail) {
		this.configuracaoEmail = configuracaoEmail;
	}

	public static String getSqlFromEmail() {
		return " TB_Email  AS Email with(nolock) ";
	}
	
	public String getDestinatarioCopia() {
		return destinatarioCopia;
	}

	public void setDestinatarioCopia(String destinatarioCopia) {
		this.destinatarioCopia = destinatarioCopia;
	}

	public String getDestinatarioCopiaOculta() {
		return destinatarioCopiaOculta;
	}

	public void setDestinatarioCopiaOculta(String destinatarioCopiaOculta) {
		this.destinatarioCopiaOculta = destinatarioCopiaOculta;
	}

	public static String getSqlCamposEmail() {
		

		return new StringBuilder()
		.append(" \nEmail.ID_EMAIL as 'Email.ID_EMAIL',")
		.append(" \nEmail.ASSUNTO as 'Email.ASSUNTO',")
		.append(" \nEmail.REMETENTE as 'Email.REMETENTE',")
	    .append(" \nEmail.DESTINATARIO as 'Email.DESTINATARIO',")
	    .append(" \nEmail.CONTEUDO as 'Email.CONTEUDO',")
	    .append(" \nEmail.DATA_ENVIO as 'Email.DATA_ENVIO',")
	    .append(" \nEmail.FLAG_ENVIO_PENDENTE as 'Email.FLAG_ENVIO_PENDENTE',")
	    .append(" \nEmail.FLAG_ERRO_ENVIO as 'Email.FLAG_ERRO_ENVIO',")
	    .append(" \nEmail.FLAG_ENVIO as 'Email.FLAG_ENVIO',")
	    .append(" \nEmail.FLAG_POSSUI_CASO as 'Email.FLAG_POSSUI_CASO',")
	    .append(" \nEmail.FLAG_LIDO as 'Email.FLAG_LIDO',")
	    .append(" \nEmail.FLAG_DESATIVADO as 'Email.FLAG_DESATIVADO',")
	    .append(" \nEmail.ID_GRUPO_EMAIL as 'Email.ID_GRUPO_EMAIL',")
	    .append(" \nEmail.ID_GRUPO_ANEXO as 'Email.ID_GRUPO_ANEXO',")
	    .append(" \nEmail.ID_PAI as 'Email.ID_PAI',")
	    .append(" \nEmail.ID_CONFIGURACAO_EMAIL as 'Email.ID_CONFIGURACAO_EMAIL',")
	    .append(" \nEmail.DESTINATARIO_COPIA AS 'Email.DESTINATARIO_COPIA',")
	    .append(" \nEmail.DESTINATARIO_COPIA_OCULTA AS 'Email.DESTINATARIO_COPIA_OCULTA',")
	    .append(" \nEmail.destinatario_para_exibicao as 'Email.destinatario_para_exibicao'").toString();
	}

	public static Email getEmailByResultSet(ResultSet resultSet) {
        try {
        	
        	if(resultSet.getInt("Email.ID_EMAIL") == 0) {
        		return null;
        	}
        	
            Email email = new Email();
            email.setIdEmail(resultSet.getInt("Email.ID_EMAIL"));
            email.setAssunto(resultSet.getString("Email.ASSUNTO"));
            email.setRemetente(resultSet.getString("Email.REMETENTE"));
            email.setDestinatario(resultSet.getString("Email.DESTINATARIO"));
            String texto =null;
            texto = resultSet.getString("Email.CONTEUDO");
            email.setConteudo(texto);

            email.setDataEnvio(resultSet.getTimestamp("Email.DATA_ENVIO"));
            email.setFlagEnvioPendente(resultSet.getBoolean("Email.FLAG_ENVIO_PENDENTE"));
            email.setFlagErroEnvio(resultSet.getBoolean("Email.FLAG_ERRO_ENVIO"));
            email.setFlagEnvio(resultSet.getBoolean("Email.FLAG_ENVIO"));
            email.setFlagPossuiCaso(resultSet.getBoolean("Email.FLAG_POSSUI_CASO"));
            email.setFlagLido(resultSet.getBoolean("Email.FLAG_LIDO"));
            email.setFlagDesativado(resultSet.getBoolean("Email.FLAG_DESATIVADO"));
            
            email.setGrupoEmail(resultSet.getInt("Email.ID_GRUPO_EMAIL") == 0 ? null : new GrupoEmail(resultSet.getInt("Email.ID_GRUPO_EMAIL")));
            email.setGrupoAnexo(resultSet.getInt("Email.ID_GRUPO_ANEXO") == 0 ? null : new GrupoAnexo(resultSet.getInt("Email.ID_GRUPO_ANEXO")));
            email.setPai(resultSet.getInt("Email.ID_PAI") == 0 ? null : new Email(resultSet.getInt("Email.ID_PAI")));
            email.setConfiguracaoEmail(resultSet.getInt("Email.ID_CONFIGURACAO_EMAIL") == 0 ? null : new ConfiguracaoEmail(resultSet.getInt("Email.ID_CONFIGURACAO_EMAIL")));
            email.setDestinatarioParaExibicao(resultSet.getString("Email.destinatario_para_exibicao"));
            email.setDestinatarioCopia(resultSet.getString("Email.DESTINATARIO_COPIA"));
            email.setDestinatarioCopiaOculta(resultSet.getString("Email.DESTINATARIO_COPIA_OCULTA"));
            
            return email;
        } catch (SQLException ex) {
            throw new IllegalArgumentException(
                    "Erro ao montar objeto a partir do ResultSet", ex);
        }
    }
}
