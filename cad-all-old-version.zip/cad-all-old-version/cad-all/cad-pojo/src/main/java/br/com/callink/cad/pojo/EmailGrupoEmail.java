package br.com.callink.cad.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import br.com.callink.cad.pojo.entity.IEntity;

/**
 *
 * @author Luiz Gustavo F. (luizgf@swb.com.br)
 */
@Entity
@Table(name = "TB_EMAIL_GRUPO_EMAIL")
public class EmailGrupoEmail implements IEntity<Integer> {

	private static final long serialVersionUID = 1L;

	@Id
 	@GeneratedValue(strategy = GenerationType.IDENTITY)
 	@Column(name = "id_email_grupo_email", unique = true, nullable = false)
    private Integer idEmailGrupoEmail;
    
    @ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_email", referencedColumnName = "id_email")
    private Email email;
    
    @ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_grupo_email", referencedColumnName = "id_grupo_email")
    private GrupoEmail grupoEmail;

    public Email getEmail() {
        return email;
    }

    public void setEmail(Email email) {
        this.email = email;
    }

    public GrupoEmail getGrupoEmail() {
        return grupoEmail;
    }

    public void setGrupoEmail(GrupoEmail grupoEmail) {
        this.grupoEmail = grupoEmail;
    }

    public Integer getIdEmailGrupoEmail() {
        return idEmailGrupoEmail;
    }

    public void setIdEmailGrupoEmail(Integer idEmailGrupoEmail) {
        this.idEmailGrupoEmail = idEmailGrupoEmail;
    }
    
    
    public Integer getPK() {
        return this.idEmailGrupoEmail;
    }

    public void setPK(Integer t) {
        this.idEmailGrupoEmail = t;
    }
    
    public static String getSqlCamposEmailGrupoEmail() {
		return new StringBuilder()
				.append(" \nEmailGrupoEmail.ID_EMAIL_GRUPO_EMAIL AS 'EmailGrupoEmail.ID_EMAIL_GRUPO_EMAIL',")
				.append(" \nEmailGrupoEmail.ID_EMAIL AS 'EmailGrupoEmail.ID_EMAIL',")
				.append(" \nEmailGrupoEmail.ID_GRUPO_EMAIL AS 'EmailGrupoEmail.ID_GRUPO_EMAIL'").toString();
	}

	public static String getSqlFromEmailGrupoEmail() {
		return " TB_EMAIL_GRUPO_EMAIL As EmailGrupoEmail with(nolock) ";
	}

	public static EmailGrupoEmail getEmailGrupoEmailByResultSet(ResultSet resultSet) {
		try {
			
			if(resultSet.getInt("EmailGrupoEmail.ID_EMAIL_GRUPO_EMAIL") == 0) {
        		return null;
        	}
			
			EmailGrupoEmail emailGrupoEmail = new EmailGrupoEmail();

			emailGrupoEmail.setIdEmailGrupoEmail(resultSet.getInt("EmailGrupoEmail.ID_EMAIL_GRUPO_EMAIL"));
			emailGrupoEmail.setEmail(resultSet.getInt("EmailGrupoEmail.ID_EMAIL") == 0 ? null : new Email(resultSet.getInt("EmailGrupoEmail.ID_EMAIL")));
			emailGrupoEmail.setGrupoEmail(resultSet.getInt("EmailGrupoEmail.ID_GRUPO_EMAIL") == 0 ? null : new GrupoEmail(resultSet.getInt("EmailGrupoEmail.ID_GRUPO_EMAIL")));
            
			return emailGrupoEmail;
		} catch (SQLException e) {
			throw new IllegalArgumentException("Erro ao montar objeto a partir do ResultSet", e);
		}
	}
    
}
