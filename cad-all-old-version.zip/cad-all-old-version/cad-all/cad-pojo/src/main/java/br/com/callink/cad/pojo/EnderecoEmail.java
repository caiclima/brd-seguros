package br.com.callink.cad.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;

/**
 *
 * @author Luiz Gustavo (luizgf@swb.com.br)
 */
@Entity
@Table(name = "TB_ENDERECO_EMAIL")
public class EnderecoEmail implements IEntity<Integer> {
    
	private static final long serialVersionUID = 1L;

	@Id
 	@GeneratedValue(strategy = GenerationType.IDENTITY)
 	@Column(name = "ID_ENDERECO_EMAIL", unique = true, nullable = false)
    private Integer idEnderecoEmail;

    @Column(name="DESCRICAO", length = 200)
    private String descricao;
    
    @Column(name="ENDERECO_EMAIL", length = 200)
    private String enderecoEmail;
    
    @Column(name = "FLAG_ATIVO")
    private Boolean flagAtivo;
    
    @Column(name="DATA_CRIACAO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataCriacao;
    
    private transient boolean selecionado;
    
    public EnderecoEmail() {
    }
    
    public EnderecoEmail(Integer idEnderecoEmail) {
    	this.idEnderecoEmail = idEnderecoEmail;
    }
    
    public Integer getPK() {
        return idEnderecoEmail;
    }

    public void setPK(Integer enderecoEmail) {
        this.idEnderecoEmail = enderecoEmail;
    }

    public Date getDataCriacao() {
        return dataCriacao == null ? null : new Date(dataCriacao.getTime());
    }

    public void setDataCriacao(Date dataCriacao) {
        this.dataCriacao = dataCriacao == null ? null : new Date(dataCriacao.getTime());
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getEnderecoEmail() {
        return enderecoEmail;
    }

    public void setEnderecoEmail(String enderecoEmail) {
        this.enderecoEmail = enderecoEmail;
    }

    public Boolean getFlagAtivo() {
        return flagAtivo;
    }

    public void setFlagAtivo(Boolean flagAtivo) {
        this.flagAtivo = flagAtivo;
    }

    public Integer getIdEnderecoEmail() {
        return idEnderecoEmail;
    }

    public void setIdEnderecoEmail(Integer idEnderecoEmail) {
        this.idEnderecoEmail = idEnderecoEmail;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final EnderecoEmail other = (EnderecoEmail) obj;
        if (this.idEnderecoEmail == null || !this.idEnderecoEmail.equals(other.idEnderecoEmail)) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 29 * hash + (this.idEnderecoEmail != null ? this.idEnderecoEmail.hashCode() : 0);
        return hash;
    }

    public boolean isSelecionado() {
        return selecionado;
    }

    public void setSelecionado(boolean selecionado) {
        this.selecionado = selecionado;
    }
    
    public static String getSqlCamposEnderecoEmail() {
		return new StringBuilder()
				.append(" \nEnderecoEmail.ID_ENDERECO_EMAIL AS 'EnderecoEmail.ID_ENDERECO_EMAIL',")
				.append(" \nEnderecoEmail.DESCRICAO AS 'EnderecoEmail.DESCRICAO',")
				.append(" \nEnderecoEmail.ENDERECO_EMAIL AS 'EnderecoEmail.ENDERECO_EMAIL',")
				.append(" \nEnderecoEmail.FLAG_ATIVO AS 'EnderecoEmail.FLAG_ATIVO',")
				.append(" \nEnderecoEmail.DATA_CRIACAO AS 'EnderecoEmail.DATA_CRIACAO'").toString();
	}

	public static String getSqlFromEnderecoEmail() {
		return " TB_ENDERECO_EMAIL As EnderecoEmail with(nolock) ";
	}

	public static EnderecoEmail getEnderecoEmailByResultSet(ResultSet resultSet) {
		try {
			
			if(resultSet.getInt("EnderecoEmail.ID_ENDERECO_EMAIL") == 0) {
        		return null;
        	}
			
			EnderecoEmail enderecoEmail = new EnderecoEmail();

			enderecoEmail.setIdEnderecoEmail(resultSet.getInt("EnderecoEmail.ID_ENDERECO_EMAIL"));
			enderecoEmail.setDescricao(resultSet.getString("EnderecoEmail.DESCRICAO"));
			enderecoEmail.setEnderecoEmail(resultSet.getString("EnderecoEmail.ENDERECO_EMAIL"));
			enderecoEmail.setFlagAtivo(resultSet.getBoolean("EnderecoEmail.FLAG_ATIVO"));
			enderecoEmail.setDataCriacao(resultSet.getTimestamp("EnderecoEmail.DATA_CRIACAO"));
            
			return enderecoEmail;
		} catch (SQLException e) {
			throw new IllegalArgumentException("Erro ao montar objeto a partir do ResultSet", e);
		}
	}
    
}
