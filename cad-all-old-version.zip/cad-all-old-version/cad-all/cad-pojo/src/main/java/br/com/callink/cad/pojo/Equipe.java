package br.com.callink.cad.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;

/**
*
* @author Ednaldo Caic [ednaldo@swb.com.br]
* @since 23/12/2011
*/
@Entity
@Table(name = "TB_EQUIPE")
public class Equipe implements IEntity<Integer> {

	private static final long serialVersionUID = 1L;

	@Id
 	@GeneratedValue(strategy = GenerationType.IDENTITY)
 	@Column(name = "ID_EQUIPE", unique = true, nullable = false)
	private Integer idEquipe;

	@Column(name = "NOME", length = 200)
	private String nome;

	@Column(name = "DATA_CRIACAO")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataCriacao;

	@Column(name = "FLAG_ATIVO")
	private Boolean flagAtivo;

	@Column(name = "FLAG_PRIORIDADE", nullable = false)
	private Boolean flagPrioridade;
        
    private transient List<EquipeFila> equipeFilaList;
    
    private transient Boolean selecionado;

	
	public Equipe(){
		
	}
	
	public Equipe(Integer idEquipe){
		this.idEquipe = idEquipe;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((idEquipe == null) ? 0 : idEquipe.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof Equipe)) {
			return false;
		}
		Equipe other = (Equipe) obj;
		if (idEquipe == null) {
			if (other.idEquipe != null) {
				return false;
			}
		} else if (!idEquipe.equals(other.idEquipe)) {
			return false;
		}
		return true;
	}

	public Integer getPK() {
		return idEquipe;
	}

	public void setPK(Integer pk) {
		this.idEquipe = pk;
	}

	public final Integer getIdEquipe() {
		return idEquipe;
	}

	public final void setIdEquipe(Integer idEquipe) {
		this.idEquipe = idEquipe;
	}

	public final String getNome() {
		return nome;
	}

	public final void setNome(String nome) {
		this.nome = nome;
	}

	public final Date getDataCriacao() {
		return dataCriacao != null ? new Date(dataCriacao.getTime()) : null;
	}

	public final void setDataCriacao(Date dataCriacao) {
		this.dataCriacao = dataCriacao != null ? new Date(dataCriacao.getTime()) : null;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return nome;
	}

	public final void setFlagAtivo(Boolean flagAtivo) {
		this.flagAtivo = flagAtivo;
	}

	public final Boolean getFlagAtivo() {
		return flagAtivo;
	}
	
	/**
	 * @param flagPrioridade
	 *            the flagPrioridade to set
	 */
	public final void setFlagPrioridade(Boolean flagPrioridade) {
		this.flagPrioridade = flagPrioridade;
	}

	/**
	 * @return the flagPrioridade
	 */
	public final Boolean getFlagPrioridade() {
		return flagPrioridade;
	}

    public final Boolean getSelecionado() {
        return selecionado;
    }

    public final void setSelecionado(Boolean selecionado) {
        this.selecionado = selecionado;
    }

    public final List<EquipeFila> getEquipeFilaList() {
        return equipeFilaList;
    }

    public final void setEquipeFilaList(List<EquipeFila> equipeFilaList) {
        this.equipeFilaList = equipeFilaList;
    }
    
    public static String getSqlEquipe() {
        return new StringBuilder()
            .append(" \nEquipe.ID_EQUIPE AS 'Equipe.ID_EQUIPE',")
            .append(" \nEquipe.NOME AS 'Equipe.NOME',")
            .append(" \nEquipe.DATA_CRIACAO AS 'Equipe.DATA_CRIACAO',")
            .append(" \nEquipe.FLAG_ATIVO AS 'Equipe.FLAG_ATIVO',")
            .append(" \nEquipe.FLAG_PRIORIDADE as 'Equipe.FLAG_PRIORIDADE'").toString();
    }
   
    public static String getSqlFromEquipe() {
        return " TB_EQUIPE AS Equipe with(nolock) ";
    }
    
     public static Equipe getEquipeByResultSet(ResultSet rs) {
        try {
        	
        	if(rs.getInt("Equipe.ID_EQUIPE") == 0) {
        		return null;
        	}
        	
            Equipe equipe = new Equipe();
            equipe.setIdEquipe(rs.getInt("Equipe.ID_EQUIPE"));
            equipe.setFlagAtivo(rs.getBoolean("Equipe.FLAG_ATIVO"));
            equipe.setDataCriacao(rs.getTimestamp("Equipe.DATA_CRIACAO"));
            equipe.setNome(rs.getString("Equipe.NOME"));
            equipe.setFlagPrioridade(rs.getBoolean("Equipe.FLAG_PRIORIDADE"));
            return equipe;
        } catch (SQLException ex) {
            throw new IllegalArgumentException(
                    "Erro ao montar objeto a partir do ResultSet", ex);
        }
    }
     
}
