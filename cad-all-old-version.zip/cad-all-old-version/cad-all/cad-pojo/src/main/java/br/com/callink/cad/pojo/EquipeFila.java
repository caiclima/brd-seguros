package br.com.callink.cad.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import br.com.callink.cad.pojo.entity.IEntity;

/**
 * 
 * @author Ednaldo Caic [ednaldo@swb.com.br]
 * @since 23/12/2011
 */
@Entity
@Table(name = "TB_EQUIPE_FILA")
public class EquipeFila implements IEntity<Integer> {

	private static final long serialVersionUID = 1L;

	@Id
 	@GeneratedValue(strategy = GenerationType.IDENTITY)
 	@Column(name = "ID_EQUIPE_FILA", unique = true, nullable = false)
	private Integer idEquipeFila;

	@Column(name = "QUANTIDADE_CASO_ATENDIDO", length = 10)
	private Integer quantidadeCasoAtendido;

	@Column(name = "QUANTIDADE_CASO_FILA", length = 10)
	private Integer quantidadeCasoFila;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_EQUIPE", referencedColumnName = "ID_EQUIPE", nullable = false)
	private Equipe equipe;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_CONFIGURACAO_FILA", referencedColumnName = "ID_CONFIGURACAO_FILA", nullable = false)
	private ConfiguracaoFila configuracaoFila;

	private transient Double ordemFila;

	public EquipeFila() {

	}

	public EquipeFila(Equipe equipe, ConfiguracaoFila configuracaoFila) {
		this.equipe = equipe;
		this.configuracaoFila = configuracaoFila;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((idEquipeFila == null) ? 0 : idEquipeFila.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof EquipeFila)) {
			return false;
		}
		EquipeFila other = (EquipeFila) obj;
		if (idEquipeFila == null) {
			if (other.idEquipeFila != null) {
				return false;
			}
		} else if (!idEquipeFila.equals(other.idEquipeFila)) {
			return false;
		}
		return true;
	}

	public Integer getPK() {
		return idEquipeFila;
	}

	public void setPK(Integer pk) {
		this.idEquipeFila = pk;
	}

	public final Integer getIdEquipeFila() {
		return idEquipeFila;
	}

	public final void setIdEquipeFila(Integer idEquipeFila) {
		this.idEquipeFila = idEquipeFila;
	}

	public final Equipe getEquipe() {
		return equipe;
	}

	public final void setEquipe(Equipe equipe) {
		this.equipe = equipe;
	}

	public final ConfiguracaoFila getConfiguracaoFila() {
		return configuracaoFila;
	}

	/**
	 * 
	 * @param configuracaoFila
	 */
	public final void setConfiguracaoFila(ConfiguracaoFila configuracaoFila) {
		this.configuracaoFila = configuracaoFila;
	}

	/**
	 * @return the quantidadeCasoAtendido
	 */
	public final Integer getQuantidadeCasoAtendido() {
		return quantidadeCasoAtendido;
	}

	/**
	 * @param quantidadeCasoAtendido
	 *            the quantidadeCasoAtendido to set
	 */
	public final void setQuantidadeCasoAtendido(Integer quantidadeCasoAtendido) {
		this.quantidadeCasoAtendido = quantidadeCasoAtendido;
	}

	/**
	 * @return the quantidadeCasoFila
	 */
	public final Integer getQuantidadeCasoFila() {
		return quantidadeCasoFila;
	}

	/**
	 * @param quantidadeCasoFila
	 *            the quantidadeCasoFila to set
	 */
	public final void setQuantidadeCasoFila(Integer quantidadeCasoFila) {
		this.quantidadeCasoFila = quantidadeCasoFila;
	}

	public final Double getOrdemFila() {
		return ordemFila;
	}

	public final void setOrdemFila(Double ordemFila) {
		this.ordemFila = ordemFila;
	}
	
	public static String getSqlCamposEquipeFila() {
		return new StringBuilder()
				.append(" \nEquipeFila.ID_EQUIPE_FILA AS 'EquipeFila.ID_EQUIPE_FILA',")
				.append(" \nEquipeFila.QUANTIDADE_CASO_ATENDIDO AS 'EquipeFila.QUANTIDADE_CASO_ATENDIDO',")
				.append(" \nEquipeFila.QUANTIDADE_CASO_FILA AS 'EquipeFila.QUANTIDADE_CASO_FILA',")
				.append(" \nEquipeFila.ID_EQUIPE AS 'EquipeFila.ID_EQUIPE',")
				.append(" \nEquipeFila.ID_CONFIGURACAO_FILA AS 'EquipeFila.ID_CONFIGURACAO_FILA'").toString();
	}

	public static String getSqlFromEquipeFila() {
		return " TB_EQUIPE_FILA As EquipeFila with(nolock) ";
	}

	public static EquipeFila getEquipeFilaByResultSet(ResultSet resultSet) {
		try {
			
			if(resultSet.getInt("EquipeFila.ID_EQUIPE_FILA") == 0) {
        		return null;
        	}
			
			EquipeFila equipeFila = new EquipeFila();

			equipeFila.setIdEquipeFila(resultSet.getInt("EquipeFila.ID_EQUIPE_FILA"));
			equipeFila.setQuantidadeCasoAtendido(resultSet.getInt("EquipeFila.QUANTIDADE_CASO_ATENDIDO"));
			equipeFila.setQuantidadeCasoFila(resultSet.getInt("EquipeFila.QUANTIDADE_CASO_FILA"));
			equipeFila.setEquipe(new Equipe(resultSet.getInt("EquipeFila.ID_EQUIPE") == 0 ? null : resultSet.getInt("EquipeFila.ID_EQUIPE")));
			equipeFila.setConfiguracaoFila(resultSet.getInt("EquipeFila.ID_CONFIGURACAO_FILA") == 0 ? null : new ConfiguracaoFila(resultSet.getInt("EquipeFila.ID_CONFIGURACAO_FILA")));
            
			return equipeFila;
		} catch (SQLException e) {
			throw new IllegalArgumentException("Erro ao montar objeto a partir do ResultSet", e);
		}
	}

}
