package br.com.callink.cad.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import br.com.callink.cad.pojo.entity.IEntity;

@Entity
@Table(name = "TB_EVENTO_LIGACAO")
public class EventoLigacao implements IEntity<Integer> {

	private static final long serialVersionUID = -7123115231908454923L;

	@Id
	@Column(name = "ID_EVENTO_LIGACAO")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idEventoLigacao;
    
    @Column(name = "NOME" , length = 500)
    private String nome;
    
    @Column(name = "DATA_CRIACAO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataCriacao;
    
    @Column(name = "FLAG_ATIVO")
    private Boolean flagAtivo;
    
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_EVENTO_LIGACAO_PAI", referencedColumnName = "ID_EVENTO_LIGACAO")
	private EventoLigacao eventoPai;
	
	@Column(name = "FLAG_SUCESSO")
	private Boolean flagSucesso;
	
    private transient boolean selecionado;

    public EventoLigacao() {
    }

    public EventoLigacao(Integer idEvento) {
        this.idEventoLigacao = idEvento;
    }

    public Integer getPK() {
        return idEventoLigacao;
    }

    public void setPK(Integer pk) {
        this.idEventoLigacao = pk;
    }

    /**
     * @return the idEvento
     */
    public final Integer getIdEventoLigacao() {
        return idEventoLigacao;
    }

    /**
     * @param idEvento
     *            the idEvento to set
     */
    public final void setIdEventoLigacao(Integer idEvento) {
        this.idEventoLigacao = idEvento;
    }

    /**
     * @return the nome
     */
    public final String getNome() {
        return nome;
    }

    /**
     * @param nome
     *            the nome to set
     */
    public final void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the dataCriacao
     */
    public final Date getDataCriacao() {
        return dataCriacao == null ? null : new Date(dataCriacao.getTime());
    }

    /**
     * @param dataCriacao
     *            the dataCriacao to set
     */
    public final void setDataCriacao(Date dataCriacao) {
        this.dataCriacao = dataCriacao == null ? null : new Date(dataCriacao.getTime());
    }

    /**
     * @return the flagAtivo
     */
    public final Boolean getFlagAtivo() {
        return flagAtivo;
    }

    /**
     * @param flagAtivo
     *            the flagAtivo to set
     */
    public final void setFlagAtivo(Boolean flagAtivo) {
        this.flagAtivo = flagAtivo;
    }
    
	public Boolean getFlagSucesso() {
		return flagSucesso;
	}
	
	public void setFlagSucesso(Boolean sucesso) {
		this.flagSucesso = sucesso;
	}

	public EventoLigacao getEventoPai() {
		return eventoPai;
	}
	
	public void setEventoPai(EventoLigacao eventoPai) {
		this.eventoPai = eventoPai;
	}
	
	public void setSelecionado(boolean selecionado) {
		this.selecionado = selecionado;
	}

	@Override
    public String toString() {
        return this.getNome();
    }

    public final Boolean getSelecionado() {
        return selecionado;
    }

    public final void setSelecionado(Boolean selecionado) {
        this.selecionado = selecionado;
    }

    public static String getSqlEvento() {

        return new StringBuilder().append(" \nEventoLigacao.ID_EVENTO_LIGACAO AS 'EventoLigacao.ID_EVENTO_LIGACAO',")
        		.append(" \nEventoLigacao.ID_EVENTO_LIGACAO_PAI AS 'EventoLigacao.ID_EVENTO_LIGACAO_PAI',")
                .append(" \nEventoLigacao.NOME AS 'EventoLigacao.NOME',")
                .append(" \nEventoLigacao.FLAG_SUCESSO AS 'EventoLigacao.FLAG_SUCESSO',")
                .append(" \nEventoLigacao.DATA_CRIACAO AS 'EventoLigacao.DATA_CRIACAO',")
                .append(" \nEventoLigacao.FLAG_ATIVO AS 'EventoLigacao.FLAG_ATIVO'").toString();
   }
   
   public static String getSqlFromEvento() {
       return " TB_EVENTO_LIGACAO AS EventoLigacao with(nolock) ";
   }

   public static EventoLigacao getEventoByResultSet(ResultSet rs) {
        try {
        	
        	if(rs.getInt("EventoLigacao.ID_EVENTO_LIGACAO") == 0){
        		return null;
        	}
        	
            EventoLigacao evento = new EventoLigacao();
            evento.setIdEventoLigacao(rs.getInt("EventoLigacao.ID_EVENTO_LIGACAO"));
            evento.setEventoPai(new EventoLigacao(rs.getInt("EventoLigacao.ID_EVENTO_LIGACAO_PAI")));
            evento.setFlagAtivo(rs.getBoolean("EventoLigacao.FLAG_ATIVO"));
            evento.setFlagSucesso(rs.getBoolean("EventoLigacao.FLAG_SUCESSO"));
            evento.setDataCriacao(rs.getTimestamp("EventoLigacao.DATA_CRIACAO"));
            evento.setNome(rs.getString("EventoLigacao.NOME"));
            return evento;
        } catch (SQLException ex) {
            throw new IllegalArgumentException(
                    "Erro ao montar objeto a partir do ResultSet", ex);
        }
    }
   

    @Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((idEventoLigacao == null) ? 0 : idEventoLigacao.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof EventoLigacao)) {
			return false;
		}
		EventoLigacao other = (EventoLigacao) obj;
		if (idEventoLigacao == null) {
			if (other.idEventoLigacao != null) {
				return false;
			}
		} else if (!idEventoLigacao.equals(other.idEventoLigacao)) {
			return false;
		}
		return true;
	}
    
   
}
