package br.com.callink.cad.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;

/**
*
* @author Ednaldo Caic [ednaldo@swb.com.br]
* @since 23/12/2011
*/
@Entity
@Table(name = "TB_FERIADO")
public class Feriado implements IEntity<Integer> {

	private static final long serialVersionUID = 1L;

	@Id
 	@GeneratedValue(strategy = GenerationType.IDENTITY)
 	@Column(name = "ID_FERIADO", unique = true, nullable = false)
	private Integer idFeriado;

	@Column(name = "DATA_FERIADO", nullable = false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataFeriado;

	@Column(name = "FLAG_NACIONAL")
	private Boolean flagNacional;
	
	@Column(name = "LOGIN_USUARIO", length = 50)
	private String loginUsuario;
	
	@Column(name="NOME_FERIADO", length = 100)
	private String nomeFeriado;
        
        @Column(name = "FLAG_FIXO")
	private Boolean flagFixo;
	
	public Feriado() {
	}
	
	public Feriado(Date dataFeriado){
		this.dataFeriado = dataFeriado != null ? new Date(dataFeriado.getTime()) : null;
	}
	public Feriado(Date dataFeriado, Boolean flagNacional){
		this.dataFeriado = dataFeriado != null ? new Date(dataFeriado.getTime()) : null;
		this.flagNacional = flagNacional;
	}
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((idFeriado == null) ? 0 : idFeriado.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof Feriado)) {
			return false;
		}
		Feriado other = (Feriado) obj;
		if (idFeriado == null) {
			if (other.idFeriado != null) {
				return false;
			}
		} else if (!idFeriado.equals(other.idFeriado)) {
			return false;
		}
		return true;
	}

	public Integer getPK() {
		return idFeriado;
	}

	public void setPK(Integer pk){
		this.idFeriado = pk;
	}

	public final Integer getIdFeriado() {
		return idFeriado;
	}

	public final void setIdFeriado(Integer idFeriado) {
		this.idFeriado = idFeriado;
	}

	public final Date getDataFeriado() {
		return dataFeriado != null ? new Date(dataFeriado.getTime()) : null;
	}

	public final void setDataFeriado(Date dataFeriado) {
		this.dataFeriado = dataFeriado != null ? new Date(dataFeriado.getTime()) : null;
	}

	public final Boolean getFlagNacional() {
		return flagNacional;
	}

	public final void setFlagNacional(Boolean flagNacional) {
		this.flagNacional = flagNacional;
	}

	public void setLoginUsuario(String loginUsuario) {
		this.loginUsuario = loginUsuario;
	}

	public String getLoginUsuario() {
		return loginUsuario;
	}

	public void setNomeFeriado(String nomeFeriado) {
		this.nomeFeriado = nomeFeriado;
	}

	public String getNomeFeriado() {
		return nomeFeriado;
	}

        public Boolean getFlagFixo() {
            return flagFixo;
        }

        public void setFlagFixo(Boolean flagFixo) {
            this.flagFixo = flagFixo;
        }

	public static String getSqlCamposFeriado() {
		return new StringBuilder()
				.append(" \nFeriado.ID_FERIADO AS 'Feriado.ID_FERIADO',")
				.append(" \nFeriado.DATA_FERIADO AS 'Feriado.DATA_FERIADO',")
				.append(" \nFeriado.FLAG_NACIONAL AS 'Feriado.FLAG_NACIONAL',")
				.append(" \nFeriado.FLAG_FIXO AS 'Feriado.FLAG_FIXO',")
                                .append(" \nFeriado.LOGIN_USUARIO AS 'Feriado.LOGIN_USUARIO',")
				.append(" \nFeriado.NOME_FERIADO AS 'Feriado.NOME_FERIADO'").toString();
	}

	public static String getSqlFromFeriado() {
		return " TB_FERIADO As Feriado with(nolock) ";
	}

	public static Feriado getFeriadoByResultSet(ResultSet resultSet) {
		try {
			
			if(resultSet.getInt("Feriado.ID_FERIADO") == 0) {
        		return null;
        	}
			
			Feriado feriado = new Feriado();

			feriado.setIdFeriado(resultSet.getInt("Feriado.ID_FERIADO"));
			feriado.setDataFeriado(resultSet.getTimestamp("Feriado.DATA_FERIADO"));
			feriado.setFlagNacional(resultSet.getBoolean("Feriado.FLAG_NACIONAL"));
                        feriado.setFlagFixo(resultSet.getBoolean("Feriado.FLAG_FIXO"));
			feriado.setLoginUsuario(resultSet.getString("Feriado.LOGIN_USUARIO"));
			feriado.setNomeFeriado(resultSet.getString("Feriado.NOME_FERIADO"));
            
			return feriado;
		} catch (SQLException e) {
			throw new IllegalArgumentException("Erro ao montar objeto a partir do ResultSet", e);
		}
	}

}
