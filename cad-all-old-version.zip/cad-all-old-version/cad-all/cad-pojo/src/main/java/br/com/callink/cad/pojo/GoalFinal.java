package br.com.callink.cad.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;

/**
 * Classe que representa tabela goal final
 * 
 * @author miller
 *
 */
@Entity
@Table(name = "TB_GOAL_FINAL")
public class GoalFinal implements IEntity<Integer>, Comparable<GoalFinal> {
	
	private static final long serialVersionUID = 1L;

	@Id
 	@GeneratedValue(strategy = GenerationType.IDENTITY)
 	@Column(name = "id_goal_final", unique = true, nullable = false)
	private Integer idGoalFinal;
	
	@Column(name="goal_inicial")
	private Double goalInicial;
	
	@Column(name="goal_final")
	private Double goalFinal;
	
	@Column(name="descricao", length = 50)
	private String descricao;
	
	@Column(name="data_inicial")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataInicial;
	
	@Column(name="data_final")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataFinal;
	
	@Column(name="login_usuario", length = 50)
	private String loginUsuario;
	
	@Column(name="nome_imagem", length = 50)
	private String nomeImagem;
	
	private transient boolean flagAlterado;
	private transient boolean flagAtualizar;
	
	public GoalFinal() {
		super();
	}
	
	public final Integer getIdGoalFinal() {
		return idGoalFinal;
	}

	public final void setIdGoalFinal(Integer idGoalFinal) {
		this.idGoalFinal = idGoalFinal;
	}

	public final Double getGoalInicial() {
		return goalInicial;
	}

	public final void setGoalInicial(Double goalInicial) {
		this.goalInicial = goalInicial;
	}


	public final String getDescricao() {
		return descricao;
	}

	public final void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public final Date getDataInicial() {
		return dataInicial == null ? null : new Date(dataInicial.getTime());
	}

	public final void setDataInicial(Date dataInicial) {
		this.dataInicial = dataInicial == null ? null : new Date(dataInicial.getTime());
	}

	public final Date getDataFinal() {
		return dataFinal == null ? null : new Date(dataFinal.getTime());
	}

	public final void setDataFinal(Date dataFinal) {
		this.dataFinal = dataFinal == null ? null : new Date(dataFinal.getTime());
	}

	public final String getLoginUsuario() {
		return loginUsuario;
	}

	public final void setLoginUsuario(String loginUsuario) {
		this.loginUsuario = loginUsuario;
	}

	
	@Override
	public String toString() {
		return descricao;
	}

	public Integer getPK() {
		return this.idGoalFinal;
	}

	public void setPK(Integer id) {
		this.idGoalFinal = id;
	}

	@Override
	public int compareTo(GoalFinal o) {
		return this.goalInicial.compareTo(o.getGoalInicial());
	}

	public final boolean isFlagAlterado() {
		return flagAlterado;
	}

	public final void setFlagAlterado(boolean flagAlterado) {
		this.flagAlterado = flagAlterado;
	}
	public final Double getGoalFinal() {
		return goalFinal;
	}
	
	public final void setGoalFinal(Double goalFinal) {
		this.goalFinal = goalFinal;
	}
	
	public final String getNomeImagem() {
		return nomeImagem;
	}
	
	public final void setNomeImagem(String nomeImagem) {
		this.nomeImagem = nomeImagem;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((idGoalFinal == null) ? 0 : idGoalFinal.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof GoalFinal)) {
			return false;
		}
		GoalFinal other = (GoalFinal) obj;
		if (idGoalFinal == null) {
			if (other.idGoalFinal != null) {
				return false;
			}
		} else if (!idGoalFinal.equals(other.idGoalFinal)) {
			return false;
		}
		return true;
	}

	public boolean isFlagAtualizar() {
		return flagAtualizar;
	}

	public void setFlagAtualizar(boolean flagAtualizar) {
		this.flagAtualizar = flagAtualizar;
	}
	
	public static String getSqlCamposGoalFinal() {
		return new StringBuilder()
				.append(" \nGoalFinal.ID_GOAL_FINAL AS 'GoalFinal.ID_GOAL_FINAL',")
				.append(" \nGoalFinal.GOAL_INICIAL AS 'GoalFinal.GOAL_INICIAL',")
				.append(" \nGoalFinal.GOAL_FINAL AS 'GoalFinal.GOAL_FINAL',")
				.append(" \nGoalFinal.DESCRICAO AS 'GoalFinal.DESCRICAO',")
				.append(" \nGoalFinal.DATA_INICIAL AS 'GoalFinal.DATA_INICIAL',")
				.append(" \nGoalFinal.DATA_FINAL AS 'GoalFinal.DATA_FINAL',")
				.append(" \nGoalFinal.LOGIN_USUARIO AS 'GoalFinal.LOGIN_USUARIO',")
				.append(" \nGoalFinal.NOME_IMAGEM AS 'GoalFinal.NOME_IMAGEM'").toString();
	}

	public static String getSqlFromGoalFinal() {
		return " TB_GOAL_FINAL As GoalFinal with(nolock) ";
	}

	public static GoalFinal getGoalFinalByResultSet(ResultSet resultSet) {
		try {
			
			if(resultSet.getInt("GoalFinal.ID_GOAL_FINAL") == 0) {
        		return null;
        	}
			
			GoalFinal goalFinal = new GoalFinal();

			goalFinal.setIdGoalFinal(resultSet.getInt("GoalFinal.ID_GOAL_FINAL"));
			goalFinal.setGoalInicial(resultSet.getDouble("GoalFinal.GOAL_INICIAL"));
			goalFinal.setGoalFinal(resultSet.getDouble("GoalFinal.GOAL_FINAL"));
			goalFinal.setDescricao(resultSet.getString("GoalFinal.DESCRICAO"));
			goalFinal.setDataInicial(resultSet.getTimestamp("GoalFinal.DATA_INICIAL"));
			goalFinal.setDataFinal(resultSet.getTimestamp("GoalFinal.DATA_FINAL"));
			goalFinal.setLoginUsuario(resultSet.getString("GoalFinal.LOGIN_USUARIO"));
			goalFinal.setNomeImagem(resultSet.getString("GoalFinal.NOME_IMAGEM"));
            
			return goalFinal;
		} catch (SQLException e) {
			throw new IllegalArgumentException("Erro ao montar objeto a partir do ResultSet", e);
		}
	}
	
}
