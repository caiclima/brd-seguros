package br.com.callink.cad.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import br.com.callink.cad.pojo.entity.IEntity;

/**
*
* @author Ednaldo Caic [ednaldo@swb.com.br]
* @since 01/03/2012
*/
@Entity
@Table(name = "TB_GRUPO_ANEXO")
public class GrupoAnexo implements IEntity<Integer> {

	private static final long serialVersionUID = 1L;

	@Id
 	@GeneratedValue(strategy = GenerationType.IDENTITY)
 	@Column(name = "ID_GRUPO_ANEXO", unique = true, nullable = false)
	private Integer idGrupoAnexo;

	@Column(name = "NOME")
	private String nome;

	@Column(name = "DESCRICAO")
	private String descricao;
	
	private transient List<Anexo> anexoList;
	
	public GrupoAnexo() {
	}
	public GrupoAnexo(Integer idGrupoAnexo) {
		this.idGrupoAnexo = idGrupoAnexo;
	}
	
	

	public Integer getPK() {
		return idGrupoAnexo;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((idGrupoAnexo == null) ? 0 : idGrupoAnexo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof GrupoAnexo)) {
			return false;
		}
		GrupoAnexo other = (GrupoAnexo) obj;
		if (idGrupoAnexo == null) {
			if (other.idGrupoAnexo != null) {
				return false;
			}
		} else if (!idGrupoAnexo.equals(other.idGrupoAnexo)) {
			return false;
		}
		return true;
	}

	public void setPK(Integer pk) {
		this.idGrupoAnexo = pk;
	}

	public final Integer getIdGrupoAnexo() {
		return idGrupoAnexo;
	}

	public final void setIdGrupoAnexo(Integer idGrupoAnexo) {
		this.idGrupoAnexo = idGrupoAnexo;
	}

	public final String getNome() {
		return nome;
	}

	public final void setNome(String nome) {
		this.nome = nome;
	}

	public final String getDescricao() {
		return descricao;
	}

	public final void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public final List<Anexo> getAnexoList() {
		return anexoList;
	}

	public final void setAnexoList(List<Anexo> anexoList) {
		this.anexoList = anexoList;
	}
	
	public static String getSqlCamposGrupoAnexo() {
		return new StringBuilder()
				.append(" \nGrupoAnexo.ID_GRUPO_ANEXO AS 'GrupoAnexo.ID_GRUPO_ANEXO',")
				.append(" \nGrupoAnexo.NOME AS 'GrupoAnexo.NOME',")
				.append(" \nGrupoAnexo.DESCRICAO AS 'GrupoAnexo.DESCRICAO'").toString();
	}

	public static String getSqlFromGrupoAnexo() {
		return " TB_GRUPO_ANEXO As GrupoAnexo with(nolock) ";
	}

	public static GrupoAnexo getGrupoAnexoByResultSet(ResultSet resultSet) {
		try {
			
			if(resultSet.getInt("GrupoAnexo.ID_GRUPO_ANEXO") == 0) {
        		return null;
        	}
			
			GrupoAnexo grupoAnexo = new GrupoAnexo();

			grupoAnexo.setIdGrupoAnexo(resultSet.getInt("GrupoAnexo.ID_GRUPO_ANEXO"));
			grupoAnexo.setNome(resultSet.getString("GrupoAnexo.NOME"));
			grupoAnexo.setDescricao(resultSet.getString("GrupoAnexo.DESCRICAO"));
            
			return grupoAnexo;
		} catch (SQLException e) {
			throw new IllegalArgumentException("Erro ao montar objeto a partir do ResultSet", e);
		}
	}
}
