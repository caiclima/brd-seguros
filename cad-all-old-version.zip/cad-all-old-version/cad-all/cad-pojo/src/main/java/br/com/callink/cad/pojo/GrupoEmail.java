package br.com.callink.cad.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;

/**
 *
 * @author Luiz Gustavo (luizgf@swb.com.br)
 */
@Entity
@Table(name = "TB_GRUPO_EMAIL")
public class GrupoEmail implements IEntity<Integer> {
    
	private static final long serialVersionUID = 1L;

	@Id
 	@GeneratedValue(strategy = GenerationType.IDENTITY)
 	@Column(name = "ID_GRUPO_EMAIL", unique = true, nullable = false)
    private Integer idGrupoEmail;
    
    @Column(name="DESCRICAO", length = 200)
    private String descricao;
    
    @Column(name="FLAG_ATIVO")
    private Boolean flagAtivo;
    
    @Column(name="DATA_CRIACAO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataCriacao;
    
    private transient Boolean selecionado;

    public GrupoEmail() {
    	
    }
    
    public GrupoEmail(Integer idGrupoEmail) {
    	this.idGrupoEmail = idGrupoEmail;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final GrupoEmail other = (GrupoEmail) obj;
        if (this.idGrupoEmail == null || !this.idGrupoEmail.equals(other.idGrupoEmail)) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 37 * hash + (this.idGrupoEmail != null ? this.idGrupoEmail.hashCode() : 0);
        return hash;
    }

    public Date getDataCriacao() {
        return dataCriacao == null ? null : new Date(dataCriacao.getTime());
    }

    public void setDataCriacao(Date dataCriacao) {
        this.dataCriacao = dataCriacao == null ? null : new Date(dataCriacao.getTime());
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Boolean getFlagAtivo() {
        return flagAtivo;
    }

    public void setFlagAtivo(Boolean flagAtivo) {
        this.flagAtivo = flagAtivo;
    }

    public Integer getIdGrupoEmail() {
        return idGrupoEmail;
    }

    public void setIdGrupoEmail(Integer idGrupoEmail) {
        this.idGrupoEmail = idGrupoEmail;
    }

    public Integer getPK() {
        return idGrupoEmail;
    }

    public void setPK(Integer t) {
        this.idGrupoEmail = t;
    }
    
    @Override
    public String toString() {
        return this.descricao;
    }

    public Boolean getSelecionado() {
        return selecionado;
    }

    public void setSelecionado(Boolean selecionado) {
        this.selecionado = selecionado;
    }
    
    public static String getSqlCamposGrupoEmail() {
		return new StringBuilder()
				.append(" \nGrupoEmail.ID_GRUPO_EMAIL AS 'GrupoEmail.ID_GRUPO_EMAIL',")
				.append(" \nGrupoEmail.DESCRICAO AS 'GrupoEmail.DESCRICAO',")
				.append(" \nGrupoEmail.FLAG_ATIVO AS 'GrupoEmail.FLAG_ATIVO',")
				.append(" \nGrupoEmail.DATA_CRIACAO AS 'GrupoEmail.DATA_CRIACAO'").toString();
	}

	public static String getSqlFromGrupoEmail() {
		return " TB_GRUPO_EMAIL As GrupoEmail with(nolock) ";
	}

	public static GrupoEmail getGrupoEmailByResultSet(ResultSet resultSet) {
		try {
			
			if(resultSet.getInt("GrupoEmail.ID_GRUPO_EMAIL") == 0) {
        		return null;
        	}
			
			GrupoEmail grupoEmail = new GrupoEmail();

			grupoEmail.setIdGrupoEmail(resultSet.getInt("GrupoEmail.ID_GRUPO_EMAIL"));
			grupoEmail.setDescricao(resultSet.getString("GrupoEmail.DESCRICAO"));
			grupoEmail.setFlagAtivo(resultSet.getBoolean("GrupoEmail.FLAG_ATIVO"));
			grupoEmail.setDataCriacao(resultSet.getTimestamp("GrupoEmail.DATA_CRIACAO"));
            
			return grupoEmail;
		} catch (SQLException e) {
			throw new IllegalArgumentException("Erro ao montar objeto a partir do ResultSet", e);
		}
	}
    
}
