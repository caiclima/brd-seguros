/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import br.com.callink.cad.pojo.entity.IEntity;

/**
 *
 * @author Rogerio
 */
@Entity
@Table(name = "tb_grupo_equipe")
public class GrupoEquipe implements IEntity<Integer>{

    /**
	 * 
	 */
	private static final long serialVersionUID = -1193626220029287267L;

	@Id
	@Column(name = "id_grupo_equipe")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idGrupoEquipe;
    
    @Column(name = "nome" , length = 200 , nullable = false)
    private String nome;
    
    @Column(name = "flag_prioridade")
    private Boolean flagPrioridade;
    
    @OneToMany(cascade = {CascadeType.REFRESH, CascadeType.REMOVE}, mappedBy = "idGrupoEquipe", fetch = FetchType.LAZY)
    private List<GrupoEquipeFila> grupoEquipeFilaList;

    public GrupoEquipe() {
    }

    public GrupoEquipe(Integer idGrupoEquipe) {
        this.idGrupoEquipe = idGrupoEquipe;
    }

    public GrupoEquipe(Integer idGrupoEquipe, String nome) {
        this.idGrupoEquipe = idGrupoEquipe;
        this.nome = nome;
    }

    public Integer getPK() {
        return idGrupoEquipe;
    }

    public void setPK(Integer t) {
        this.idGrupoEquipe = t;
    }

    public Integer getIdGrupoEquipe() {
        return idGrupoEquipe;
    }

    public void setIdGrupoEquipe(Integer idGrupoEquipe) {
        this.idGrupoEquipe = idGrupoEquipe;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Boolean getFlagPrioridade() {
        return flagPrioridade;
    }

    public void setFlagPrioridade(Boolean flagPrioridade) {
        this.flagPrioridade = flagPrioridade;
    }

    public List<GrupoEquipeFila> getGrupoEquipeFilaList() {
        return grupoEquipeFilaList;
    }

    public void setGrupoEquipeFilaList(List<GrupoEquipeFila> grupoEquipeFilaList) {
        this.grupoEquipeFilaList = grupoEquipeFilaList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idGrupoEquipe != null ? idGrupoEquipe.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof GrupoEquipe)) {
            return false;
        }
        GrupoEquipe other = (GrupoEquipe) object;
        if ((this.idGrupoEquipe == null && other.idGrupoEquipe != null) || (this.idGrupoEquipe != null && !this.idGrupoEquipe.equals(other.idGrupoEquipe))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "br.com.callink.gbo.pojo.GrupoEquipe[ idGrupoEquipe=" + idGrupoEquipe + " ]";
    }
    
    public static String getSqlCamposGrupoEquipe() {
 		
     	return new StringBuilder()
 		.append(" \nGrupoEquipe.id_grupo_equipe AS 'GrupoEquipe.id_grupo_equipe',")
 		.append(" \nGrupoEquipe.nome AS 'GrupoEquipe.nome',")
 		.append(" \nGrupoEquipe.flag_prioridade AS 'GrupoEquipe.flag_prioridade'")
 		.toString();
 	}

 	public static String getSqlFromGrupoEquipe() {
 		return " tb_grupo_equipe  AS GrupoEquipe with(nolock) ";
 	}

 	public static GrupoEquipe getGrupoEquipeByResultSet(ResultSet resultSet) {

 		GrupoEquipe grupoEquipe = new GrupoEquipe();

 		try {
 			
 			if(resultSet.getInt("GrupoEquipe.id_grupo_equipe") == 0) {
        		return null;
        	}
 			
 			grupoEquipe.setIdGrupoEquipe(resultSet.getInt("GrupoEquipe.id_grupo_equipe"));
 			grupoEquipe.setNome(resultSet.getString("GrupoEquipe.nome"));
 			grupoEquipe.setFlagPrioridade(resultSet.getBoolean("GrupoEquipe.flag_prioridade"));
 			
 		} catch (SQLException e) {
 			throw new IllegalArgumentException("Erro ao montar objeto a partir do ResultSet", e);
 		}
 		return grupoEquipe;
 	}
    
    
}
