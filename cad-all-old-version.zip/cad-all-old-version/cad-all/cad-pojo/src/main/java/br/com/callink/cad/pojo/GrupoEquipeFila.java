/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import br.com.callink.cad.pojo.entity.IEntity;



/**
 *
 * @author Rogerio
 */
@Entity
@Table(name = "tb_grupo_equipe_fila")
public class GrupoEquipeFila implements IEntity<Integer> {

    
	private static final long serialVersionUID = 5746453180084383786L;
	
	@Id
	@Column(name = "tb_grupo_equipe_fila")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer tbGrupoEquipeFila;
    
	@Column(name = "quantidade_caso_fila")
    private Integer quantidadeCasoFila;
    
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_grupo_equipe", referencedColumnName = "id_grupo_equipe" , nullable = false)
    private GrupoEquipe idGrupoEquipe;
    
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_configuracao_fila", referencedColumnName = "id_configuracao_fila" , nullable = false)
    private ConfiguracaoFila configuracaoFila;

    public GrupoEquipeFila() {
    }

    public GrupoEquipeFila(Integer tbGrupoEquipeFila) {
        this.tbGrupoEquipeFila = tbGrupoEquipeFila;
    }

    public Integer getPK() {
        return tbGrupoEquipeFila;
    }

    public void setPK(Integer t) {
        this.tbGrupoEquipeFila = t;
    }

    public Integer getTbGrupoEquipeFila() {
        return tbGrupoEquipeFila;
    }

    public void setTbGrupoEquipeFila(Integer tbGrupoEquipeFila) {
        this.tbGrupoEquipeFila = tbGrupoEquipeFila;
    }

    public Integer getQuantidadeCasoFila() {
        return quantidadeCasoFila;
    }

    public void setQuantidadeCasoFila(Integer quantidadeCasoFila) {
        this.quantidadeCasoFila = quantidadeCasoFila;
    }

    public GrupoEquipe getIdGrupoEquipe() {
        return idGrupoEquipe;
    }

    public void setIdGrupoEquipe(GrupoEquipe idGrupoEquipe) {
        this.idGrupoEquipe = idGrupoEquipe;
    }

    public ConfiguracaoFila getConfiguracaoFila() {
        return configuracaoFila;
    }

    public void setConfiguracaoFila(ConfiguracaoFila configuracaoFila) {
        this.configuracaoFila = configuracaoFila;
    }

    @Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((configuracaoFila == null) ? 0 : configuracaoFila.hashCode());
		result = prime * result
				+ ((idGrupoEquipe == null) ? 0 : idGrupoEquipe.hashCode());
		result = prime
				* result
				+ ((quantidadeCasoFila == null) ? 0 : quantidadeCasoFila
						.hashCode());
		result = prime
				* result
				+ ((tbGrupoEquipeFila == null) ? 0 : tbGrupoEquipeFila
						.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		GrupoEquipeFila other = (GrupoEquipeFila) obj;
		if (configuracaoFila == null) {
			if (other.configuracaoFila != null) {
				return false;
			}
		} else if (!configuracaoFila.equals(other.configuracaoFila)) {
			return false;
		}
		if (idGrupoEquipe == null) {
			if (other.idGrupoEquipe != null) {
				return false;
			}
		} else if (!idGrupoEquipe.equals(other.idGrupoEquipe)) {
			return false;
		}
		if (quantidadeCasoFila == null) {
			if (other.quantidadeCasoFila != null) {
				return false;
			}
		} else if (!quantidadeCasoFila.equals(other.quantidadeCasoFila)) {
			return false;
		}
		if (tbGrupoEquipeFila == null) {
			if (other.tbGrupoEquipeFila != null) {
				return false;
			}
		} else if (!tbGrupoEquipeFila.equals(other.tbGrupoEquipeFila)) {
			return false;
		}
		return true;
	}

	public static String getSqlCamposGrupoEquipeFila() {
 		
     	return new StringBuilder()
 		.append(" \nGrupoEquipeFila.tb_grupo_equipe_fila AS 'GrupoEquipeFila.tb_grupo_equipe_fila',")
 		.append(" \nGrupoEquipeFila.quantidade_caso_fila AS 'GrupoEquipeFila.quantidade_caso_fila',")
 		.append(" \nGrupoEquipeFila.id_grupo_equipe AS 'GrupoEquipeFila.id_grupo_equipe',")
 		.append(" \nGrupoEquipeFila.id_configuracao_fila AS 'GrupoEquipeFila.id_configuracao_fila'")
 		.toString();
 	}

 	public static String getSqlFromGrupoEquipeFila() {
 		return " tb_grupo_equipe_fila  AS GrupoEquipeFila with(nolock) ";
 	}

 	public static GrupoEquipeFila getGrupoEquipeFilaByResultSet(ResultSet resultSet) {

 		GrupoEquipeFila grupoEquipeFila = new GrupoEquipeFila();

 		try {
 			
 			if(resultSet.getInt("GrupoEquipeFila.tb_grupo_equipe_fila") == 0) {
        		return null;
        	}
 			
 			grupoEquipeFila.setTbGrupoEquipeFila(resultSet.getInt("GrupoEquipeFila.tb_grupo_equipe_fila"));
 			grupoEquipeFila.setQuantidadeCasoFila(resultSet.getInt("GrupoEquipeFila.quantidade_caso_fila"));
 			grupoEquipeFila.setIdGrupoEquipe(resultSet.getInt("GrupoEquipeFila.id_grupo_equipe") == 0 ? null : new GrupoEquipe(resultSet.getInt("GrupoEquipeFila.id_grupo_equipe")));
 			grupoEquipeFila.setConfiguracaoFila(resultSet.getInt("GrupoEquipeFila.id_configuracao_fila") == 0 ? null : new ConfiguracaoFila(resultSet.getInt("GrupoEquipeFila.id_configuracao_fila")));
 			
 		} catch (SQLException e) {
 			throw new IllegalArgumentException("Erro ao montar objeto a partir do ResultSet", e);
 		}
 		return grupoEquipeFila;
 	}
    
    
}
