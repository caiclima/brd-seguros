package br.com.callink.cad.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;


/**
 * 
 * @author ednaldo [ednaldo@swb.com.br]
 *
 */
@Entity
@Table(name = "tb_historico_dados_caso")
public class HistoricoDadosCaso implements IEntity<Integer> {

	private static final long serialVersionUID = 6379787833352909101L;

	@Id
	@Column(name = "id_historico_dados_caso")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer idHistoricoDadosCaso;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_ATENDENTE", referencedColumnName = "ID_ATENDENTE" , nullable = false)
	private Atendente atendente;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_CASO", referencedColumnName = "ID_CASO" , nullable = false)
	private Caso caso;
	
	@Column(name = "DATA_CADASTRO")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataCadastro;
	
	@Column(name = "CASO_JSON")
	private String casoJson;	
	
	public Integer getPK() {
		return idHistoricoDadosCaso;
	}

	public void setPK(Integer pk) {
		this.idHistoricoDadosCaso = pk;
	}

	/**
	 * @return the idHistoricoDadosCaso
	 */
	public synchronized Integer getIdHistoricoDadosCaso() {
		return idHistoricoDadosCaso;
	}

	/**
	 * @param idHistoricoDadosCaso the idHistoricoDadosCaso to set
	 */
	public synchronized void setIdHistoricoDadosCaso(
			Integer idHistoricoDadosCaso) {
		this.idHistoricoDadosCaso = idHistoricoDadosCaso;
	}

	/**
	 * @return the atendente
	 */
	public synchronized Atendente getAtendente() {
		return atendente;
	}

	/**
	 * @param atendente the atendente to set
	 */
	public synchronized void setAtendente(Atendente atendente) {
		this.atendente = atendente;
	}

	/**
	 * @return the caso
	 */
	public synchronized Caso getCaso() {
		return caso;
	}

	/**
	 * @param caso the caso to set
	 */
	public synchronized void setCaso(Caso caso) {
		this.caso = caso;
	}

	/**
	 * @return the dataCadastro
	 */
	public synchronized Date getDataCadastro() {
		return dataCadastro!=null ? new Date(dataCadastro.getTime()) : null;
	}

	/**
	 * @param dataCadastro the dataCadastro to set
	 */
	public synchronized void setDataCadastro(Date dataCadastro) {
		this.dataCadastro = dataCadastro!=null ? new Date(dataCadastro.getTime()) : null;
	}

	/**
	 * @return the casoJson
	 */
	public synchronized String getCasoJson() {
		return casoJson;
	}

	/**
	 * @param casoJson the casoJson to set
	 */
	public synchronized void setCasoJson(String casoJson) {
		this.casoJson = casoJson;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((idHistoricoDadosCaso == null) ? 0 : idHistoricoDadosCaso.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof HistoricoDadosCaso)) {
			return false;
		}
		HistoricoDadosCaso other = (HistoricoDadosCaso) obj;
		if (idHistoricoDadosCaso == null) {
			if (other.idHistoricoDadosCaso != null) {
				return false;
			}
		} else if (!idHistoricoDadosCaso.equals(other.idHistoricoDadosCaso)) {
			return false;
		}
		return true;
	}

	public static String getSqlCamposHistoricoDadosCaso() {
 		
     	return new StringBuilder()
 		.append(" \nHistoricoDadosCaso.id_historico_dados_caso AS 'HistoricoDadosCaso.id_historico_dados_caso',")
 		.append(" \nHistoricoDadosCaso.ID_ATENDENTE AS 'HistoricoDadosCaso.ID_ATENDENTE',")
 		.append(" \nHistoricoDadosCaso.ID_CASO AS 'HistoricoDadosCaso.ID_CASO',")
 		.append(" \nHistoricoDadosCaso.DATA_CADASTRO AS 'HistoricoDadosCaso.DATA_CADASTRO',")
 		.append(" \nHistoricoDadosCaso.CASO_JSON AS 'HistoricoDadosCaso.CASO_JSON'")
 		.toString();
 	}

 	public static String getSqlFromHistoricoDadosCaso() {
 		return " tb_historico_dados_caso  AS HistoricoDadosCaso with(nolock) ";
 	}

 	public static HistoricoDadosCaso getHistoricoDadosCasoByResultSet(ResultSet resultSet) {

 		HistoricoDadosCaso historicoDadosCaso = new HistoricoDadosCaso();

 		try {
 			
 			if(resultSet.getInt("HistoricoDadosCaso.id_historico_dados_caso") == 0) {
        		return null;
        	}
 			
 			historicoDadosCaso.setIdHistoricoDadosCaso(resultSet.getInt("HistoricoDadosCaso.id_historico_dados_caso"));
 			historicoDadosCaso.setAtendente(resultSet.getInt("HistoricoDadosCaso.ID_ATENDENTE")==0 ? null : new Atendente(resultSet.getInt("HistoricoDadosCaso.ID_ATENDENTE")));
 			historicoDadosCaso.setCaso(resultSet.getInt("HistoricoDadosCaso.ID_CASO") == 0 ? null : new Caso(resultSet.getInt("HistoricoDadosCaso.ID_CASO")));
 			historicoDadosCaso.setDataCadastro(resultSet.getTimestamp("HistoricoDadosCaso.DATA_CADASTRO"));
 			historicoDadosCaso.setCasoJson(resultSet.getString("HistoricoDadosCaso.CASO_JSON"));
 			
 		} catch (SQLException e) {
 			throw new IllegalArgumentException("Erro ao montar objeto a partir do ResultSet", e);
 		}
 		return historicoDadosCaso;
 	}
	
}
