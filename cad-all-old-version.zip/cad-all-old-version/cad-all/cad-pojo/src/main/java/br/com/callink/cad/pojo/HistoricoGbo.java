package br.com.callink.cad.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;


/**
*
* @author Ednaldo Caic [ednaldo@swb.com.br]
* @since 03/01/2012
*/

@Entity
@Table(name = "TB_HISTORICO_GBO")
public class HistoricoGbo implements IEntity<Integer>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 810417230634711777L;

	@Id
	@Column(name = "ID_HISTORICO_ORDEM_CASO")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer idHistoricoOrdemCaso;

	@Column(name = "ID_TABELA_ORIGEM")
	private Integer idTabelaOrigem;

	@Column(name = "DATA_CRIACAO")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataCriacao;

	@Column(name = "LOGIN_USUARIO" , length = 50)
	private String loginUsuario;

	@Column(name = "HISTORICO" , length = 4000)
	private String historico;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_TELA_GBO", referencedColumnName = "ID_TELA_GBO" , nullable = false)
	private TelaGbo telaGbo;

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((idHistoricoOrdemCaso == null) ? 0 : idHistoricoOrdemCaso.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof HistoricoGbo)) {
			return false;
		}
		HistoricoGbo other = (HistoricoGbo) obj;
		if (idHistoricoOrdemCaso == null) {
			if (other.idHistoricoOrdemCaso != null) {
				return false;
			}
		} else if (!idHistoricoOrdemCaso.equals(other.idHistoricoOrdemCaso)) {
			return false;
		}
		return true;
	}

	public Integer getPK() {
		return idHistoricoOrdemCaso;
	}

	public void setPK(Integer pk) {
		this.idHistoricoOrdemCaso = pk;
	}

	public final Integer getIdHistoricoOrdemCaso() {
		return idHistoricoOrdemCaso;
	}

	public final void setIdHistoricoOrdemCaso(Integer idHistoricoOrdemCaso) {
		this.idHistoricoOrdemCaso = idHistoricoOrdemCaso;
	}

	public final Date getDataCriacao() {
		return dataCriacao!= null ? new Date(dataCriacao.getTime()) : null;
	}

	public final void setDataCriacao(Date dataCriacao) {
		this.dataCriacao = dataCriacao!= null ? new Date(dataCriacao.getTime()) : null;
	}

	public final String getLoginUsuario() {
		return loginUsuario;
	}

	public final void setLoginUsuario(String loginUsuario) {
		this.loginUsuario = loginUsuario;
	}

	public final String getHistorico() {
		return historico;
	}

	public final void setHistorico(String historico) {
		this.historico = historico;
	}

	public final TelaGbo getTelaGbo() {
		return telaGbo;
	}

	public final void setTelaGbo(TelaGbo telaGbo) {
		this.telaGbo = telaGbo;
	}

	public final Integer getIdTabelaOrigem() {
		return idTabelaOrigem;
	}

	public final void setIdTabelaOrigem(Integer idTabelaOrigem) {
		this.idTabelaOrigem = idTabelaOrigem;
	}
	
	public static String getSqlCamposHistoricoGbo() {
 		
     	return new StringBuilder()
 		.append(" \nHistoricoGbo.ID_HISTORICO_ORDEM_CASO AS 'HistoricoGbo.ID_HISTORICO_ORDEM_CASO',")
 		.append(" \nHistoricoGbo.ID_TABELA_ORIGEM AS 'HistoricoGbo.ID_TABELA_ORIGEM',")
 		.append(" \nHistoricoGbo.DATA_CRIACAO AS 'HistoricoGbo.DATA_CRIACAO',")
 		.append(" \nHistoricoGbo.LOGIN_USUARIO AS 'HistoricoGbo.LOGIN_USUARIO',")
 		.append(" \nHistoricoGbo.HISTORICO AS 'HistoricoGbo.HISTORICO',")
 		.append(" \nHistoricoGbo.ID_TELA_GBO AS 'HistoricoGbo.ID_TELA_GBO'")
 		.toString();
 	}

 	public static String getSqlFromHistoricoGbo() {
 		return " TB_HISTORICO_GBO  AS HistoricoGbo with(nolock) ";
 	}

 	public static HistoricoGbo getHistoricoGboByResultSet(ResultSet resultSet) {

 		HistoricoGbo historicoGbo = new HistoricoGbo();

 		try {
 			
 			if(resultSet.getInt("HistoricoGbo.ID_HISTORICO_ORDEM_CASO") == 0) {
        		return null;
        	}
 			
 			historicoGbo.setIdHistoricoOrdemCaso(resultSet.getInt("HistoricoGbo.ID_HISTORICO_ORDEM_CASO"));
 			historicoGbo.setIdTabelaOrigem(resultSet.getInt("HistoricoGbo.ID_TABELA_ORIGEM"));
 			historicoGbo.setDataCriacao(resultSet.getTimestamp("HistoricoGbo.DATA_CRIACAO"));
 			historicoGbo.setLoginUsuario(resultSet.getString("HistoricoGbo.LOGIN_USUARIO"));
 			historicoGbo.setHistorico(resultSet.getString("HistoricoGbo.HISTORICO"));
 			historicoGbo.setTelaGbo(resultSet.getInt("HistoricoGbo.ID_TELA_GBO") == 0 ? null : new TelaGbo(resultSet.getInt("HistoricoGbo.ID_TELA_GBO")));
 			
 		} catch (SQLException e) {
 			throw new IllegalArgumentException("Erro ao montar objeto a partir do ResultSet", e);
 		}
 		return historicoGbo;
 	}
	
	
}
