package br.com.callink.cad.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;

/**
 *
 * @author Ednaldo Caic [ednaldo@swb.com.br]
 * @since 22/12/2011
 */

@Entity
@Table(name = "TB_LOG")
public class Log implements IEntity<Integer> {

	private static final long serialVersionUID = 2925201375904013052L;

	@Id
	@Column(name = "ID_LOG")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idLog;
    
    @Column(name = "DATA_LOG")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataLog;
    
    private transient String slaLog;
    
    private transient String tempoGasto;

    @Column(name = "DESCRICAO" , length = 4000)
    private String descricao;
    
    @ManyToOne(fetch = FetchType.LAZY)
   	@JoinColumn(name = "ID_STATUS", referencedColumnName = "ID_STATUS", nullable = false )
    private Status status;
    
    @ManyToOne(fetch = FetchType.LAZY)
   	@JoinColumn(name = "ID_ATENDENTE", referencedColumnName = "ID_ATENDENTE" )
    private Atendente atendente;
    
    @ManyToOne(fetch = FetchType.LAZY)
   	@JoinColumn(name = "ID_CASO", referencedColumnName = "ID_CASO", nullable = false )
    private Caso caso;
    
    @ManyToOne(fetch = FetchType.LAZY)
   	@JoinColumn(name = "ID_GRUPO_ANEXO", referencedColumnName = "ID_GRUPO_ANEXO" )
    private GrupoAnexo grupoAnexo;
    
    @ManyToOne(fetch = FetchType.LAZY)
   	@JoinColumn(name = "ID_ACAO", referencedColumnName = "ID_ACAO" )
    private Acao acao;
    
    @ManyToOne(fetch = FetchType.LAZY)
   	@JoinColumn(name = "ID_EMAIL", referencedColumnName = "ID_EMAIL" )
    private Email email;
    
    @ManyToOne(fetch = FetchType.LAZY)
   	@JoinColumn(name = "ID_CONFIGURACAO_FILA", referencedColumnName = "ID_CONFIGURACAO_FILA")
    private ConfiguracaoFila configuracaoFila;

    @Column(name = "DETALHE" , length = 2000)
    private String detalhe;
    
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((idLog == null) ? 0 : idLog.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof Log)) {
            return false;
        }
        Log other = (Log) obj;
        if (idLog == null) {
            if (other.idLog != null) {
                return false;
            }
        } else if (!idLog.equals(other.idLog)) {
            return false;
        }
        return true;
    }

    public Integer getPK() {
        return idLog;
    }

    public void setPK(Integer pk) {
        this.idLog = pk;
    }

    public final Integer getIdLog() {
        return idLog;
    }

    public final void setIdLog(Integer idLog) {
        this.idLog = idLog;
    }

    public final Date getDataLog() {
        return dataLog != null ? new Date(dataLog.getTime()) : null;
    }

    public final void setDataLog(Date dataLog) {
        this.dataLog = dataLog != null ? new Date(dataLog.getTime()) : null;
    }

    public String getSlaLog() {
        return slaLog;
    }

    public void setSlaLog(String slaLog) {
        this.slaLog = slaLog;
    }

    public final String getDescricao() {
        return descricao;
    }

    public final void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public final Status getStatus() {
        return status;
    }

    public final void setStatus(Status status) {
        this.status = status;
    }

    public final Atendente getAtendente() {
        return atendente;
    }

    public final void setAtendente(Atendente atendente) {
        this.atendente = atendente;
    }

    public final Caso getCaso() {
        return caso;
    }

    public final void setCaso(Caso caso) {
        this.caso = caso;
    }
    
    
    public String getTempoGasto() {
        return tempoGasto;
    }

    public void setTempoGasto(String tempoGasto) {
        this.tempoGasto = tempoGasto;
    }

    public final GrupoAnexo getGrupoAnexo() {
            return grupoAnexo;
    }

    public final void setGrupoAnexo(GrupoAnexo grupoAnexo) {
            this.grupoAnexo = grupoAnexo;
    }

    public Acao getAcao() {
        return acao;
    }

    public void setAcao(Acao acao) {
        this.acao = acao;
    }

    public Email getEmail() {
        return email;
    }

    public void setEmail(Email email) {
        this.email = email;
    }

    public ConfiguracaoFila getConfiguracaoFila() {
        return configuracaoFila;
    }

    public void setConfiguracaoFila(ConfiguracaoFila configuracaoFila) {
        this.configuracaoFila = configuracaoFila;
    }
    
    
    
    public static String getSqlCamposLog() {

        return new StringBuilder()
                .append(" \nLog.ID_LOG AS 'Log.ID_LOG', ")
                .append(" \nLog.DATA_LOG AS 'Log.DATA_LOG', ")
                .append(" \nLog.DESCRICAO AS 'Log.DESCRICAO', ")
                .append(" \nLog.ID_STATUS AS 'Log.ID_STATUS', ")
                .append(" \nLog.ID_ACAO AS 'Log.ID_ACAO', ")
                .append(" \nLog.ID_EMAIL AS 'Log.ID_EMAIL', ")
                .append(" \nLog.ID_ATENDENTE AS 'Log.ID_ATENDENTE', ")
                .append(" \nLog.ID_CASO AS 'Log.ID_CASO', ")
                .append(" \nLog.ID_CONFIGURACAO_FILA as 'Log.ID_CONFIGURACAO_FILA', ")
                .append(" \nLog.DETALHE as 'Log.DETALHE', ")
                .append(" \nLog.ID_GRUPO_ANEXO AS 'Log.ID_GRUPO_ANEXO'").toString();
    }

    public static String getSqlFromLog() {
        return " TB_LOG  AS Log with(nolock) ";
    }
    
       public static Log getLogByResultSet(ResultSet rs) {
        try {
        	
        	if(rs.getInt("Log.ID_LOG") == 0) {
        		return null;
        	}
        	
            Log log = new Log();
            log.setIdLog(rs.getInt("Log.ID_LOG"));
            log.setDataLog(rs.getTimestamp("Log.DATA_LOG"));
            log.setDescricao(rs.getString("Log.DESCRICAO"));
            log.setAcao(rs.getInt("Log.ID_ACAO") == 0 ? null : new Acao(rs.getInt("Log.ID_ACAO")));
            log.setAtendente(rs.getInt("Log.ID_ATENDENTE") == 0 ? null : new Atendente(rs.getInt("Log.ID_ATENDENTE")));
            log.setEmail(rs.getInt("Log.ID_EMAIL") == 0 ? null : new Email(rs.getInt("Log.ID_EMAIL")));
            log.setCaso(rs.getInt("Log.ID_CASO") == 0 ? null : new Caso(rs.getInt("Log.ID_CASO")));
            log.setGrupoAnexo(rs.getInt("Log.ID_GRUPO_ANEXO") == 0 ? null : new GrupoAnexo(rs.getInt("Log.ID_GRUPO_ANEXO")));
            log.setStatus(rs.getInt("Log.ID_STATUS") == 0 ? null : new Status(rs.getInt("Log.ID_STATUS")));
            log.setDetalhe(rs.getString("Log.DETALHE"));
            log.setConfiguracaoFila(rs.getInt("Log.ID_CONFIGURACAO_FILA") == 0 ? null : new ConfiguracaoFila(rs.getInt("Log.ID_CONFIGURACAO_FILA")));
            return log;
        } catch (SQLException ex) {
            throw new IllegalArgumentException(
                    "Erro ao montar objeto a partir do ResultSet", ex);
        }
    }

    public String getDetalhe() {
        return detalhe;
    }

    public void setDetalhe(String detalhe) {
        this.detalhe = detalhe;
    }
    
}
