package br.com.callink.cad.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import br.com.callink.cad.pojo.entity.IEntity;



/**
 * @author jose_araujo
 */
@Entity
@Table(name = "TB_LOG_LIGACOES")
public class LogLigacoes implements IEntity<Integer> {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2629924570011984347L;

	@Id
	@Column(name = "ID_LOG_LIGACOES")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idLogLigacoes;
    
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_ATENDENTE", referencedColumnName = "ID_ATENDENTE")
    private Atendente atendente;
    
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_CASO", referencedColumnName = "ID_CASO")
    private Caso caso;
    
	@Column(name = "CALL_ID" , length = 21)
    private String callID;
    
	@Column(name = "TELEFONE_CLIENTE", length = 21)
    private String telefoneCliente;
    
	@Column(name = "CANAL_ENTRADA", length = 21)
    private String canalEntrada;
    
	@Column(name = "RAMAL", length = 21)
    private String ramal;
    
	@Column(name = "ENTRANTE")
    private Boolean entrante;
    
	@Column(name = "DATA_INICIO")
	@Temporal(TemporalType.TIMESTAMP)
    private Date dataInicio;
    
	@Column(name = "DATA_FIM")
	@Temporal(TemporalType.TIMESTAMP)
    private Date dataFim;
	
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((idLogLigacoes == null) ? 0 : idLogLigacoes.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof LogLigacoes)) {
            return false;
        }
        LogLigacoes other = (LogLigacoes) obj;
        if (idLogLigacoes == null) {
            if (other.idLogLigacoes != null) {
                return false;
            }
        } else if (!idLogLigacoes.equals(other.idLogLigacoes)) {
            return false;
        }
        return true;
    }

	public Integer getPK() {
		return this.idLogLigacoes;
	}

	public void setPK(Integer pk) {
		this.idLogLigacoes = pk;
	}
	
	public static String getSqlCamposLogLigacoes() {

		return new StringBuilder()
				.append(" \nLogLigacoes.ID_LOG_LIGACOES AS 'LogLigacoes.ID_LOG_LIGACOES', ")
				.append(" \nLogLigacoes.ID_ATENDENTE AS 'LogLigacoes.ID_ATENDENTE', ")
				.append(" \nLogLigacoes.ID_CASO AS 'LogLigacoes.ID_CASO', ")
				.append(" \nLogLigacoes.CALL_ID AS 'LogLigacoes.CALL_ID', ")
				.append(" \nLogLigacoes.TELEFONE_CLIENTE AS 'LogLigacoes.TELEFONE_CLIENTE', ")
				.append(" \nLogLigacoes.CANAL_ENTRADA AS 'LogLigacoes.CANAL_ENTRADA', ")
				.append(" \nLogLigacoes.RAMAL AS 'LogLigacoes.RAMAL', ")
				.append(" \nLogLigacoes.ENTRANTE AS 'LogLigacoes.ENTRANTE', ")
				.append(" \nLogLigacoes.DATA_INICIO AS 'LogLigacoes.DATA_INICIO', ")
				.append(" \nLogLigacoes.DATA_FIM AS 'LogLigacoes.DATA_FIM' ")
				.toString();
    }

    public static String getSqlFromLogLigacoes() {
        return " TB_LOG_LIGACOES  AS LogLigacoes with (nolock) ";
    }
    
       public static LogLigacoes getLogLigacoesByResultSet(ResultSet rs) {
        try {
        	
        	if(rs.getInt("LogLigacoes.ID_LOG_LIGACOES") == 0) {
        		return null;
        	}
        	
            LogLigacoes logLigacoes = new LogLigacoes();
            logLigacoes.setIdLogLigacoes(rs.getInt("LogLigacoes.ID_LOG_LIGACOES"));
            logLigacoes.setAtendente(rs.getInt("LogLigacoes.ID_ATENDENTE") == 0 ? null : new Atendente(rs.getInt("LogLigacoes.ID_ATENDENTE")));
            logLigacoes.setCaso(rs.getInt("LogLigacoes.ID_CASO") == 0 ? null : new Caso(rs.getInt("LogLigacoes.ID_CASO")));
            logLigacoes.setCallID(rs.getString("LogLigacoes.CALL_ID"));
            logLigacoes.setTelefoneCliente(rs.getString("LogLigacoes.TELEFONE_CLIENTE"));
            logLigacoes.setCanalEntrada(rs.getString("LogLigacoes.CANAL_ENTRADA"));
            logLigacoes.setRamal(rs.getString("LogLigacoes.RAMAL"));
            logLigacoes.setEntrante(rs.getBoolean("LogLigacoes.ENTRANTE"));
            logLigacoes.setDataInicio(rs.getTimestamp("LogLigacoes.DATA_INICIO"));
            logLigacoes.setDataFim(rs.getTimestamp("LogLigacoes.DATA_FIM"));

            return logLigacoes;
        } catch (SQLException ex) {
            throw new IllegalArgumentException(
                    "Erro ao montar objeto a partir do ResultSet", ex);
        }
    }

	/**
	 * @return the idLogLigacoes
	 */
	public Integer getIdLogLigacoes() {
		return idLogLigacoes;
	}

	/**
	 * @param idLogLigacoes the idLogLigacoes to set
	 */
	public void setIdLogLigacoes(Integer idLogLigacoes) {
		this.idLogLigacoes = idLogLigacoes;
	}

	/**
	 * @return the atendente
	 */
	public Atendente getAtendente() {
		return atendente;
	}

	/**
	 * @param atendente the atendente to set
	 */
	public void setAtendente(Atendente atendente) {
		this.atendente = atendente;
	}

	/**
	 * @return the caso
	 */
	public Caso getCaso() {
		return caso;
	}

	/**
	 * @param caso the caso to set
	 */
	public void setCaso(Caso caso) {
		this.caso = caso;
	}

	/**
	 * @return the callID
	 */
	public String getCallID() {
		return callID;
	}

	/**
	 * @param callID the callID to set
	 */
	public void setCallID(String callID) {
		this.callID = callID;
	}

	/**
	 * @return the telefoneCliente
	 */
	public String getTelefoneCliente() {
		return telefoneCliente;
	}

	/**
	 * @param telefoneCliente the telefoneCliente to set
	 */
	public void setTelefoneCliente(String telefoneCliente) {
		this.telefoneCliente = telefoneCliente;
	}

	/**
	 * @return the canalEntrada
	 */
	public String getCanalEntrada() {
		return canalEntrada;
	}

	/**
	 * @param canalEntrada the canalEntrada to set
	 */
	public void setCanalEntrada(String canalEntrada) {
		this.canalEntrada = canalEntrada;
	}

	/**
	 * @return the ramal
	 */
	public String getRamal() {
		return ramal;
	}

	/**
	 * @param ramal the ramal to set
	 */
	public void setRamal(String ramal) {
		this.ramal = ramal;
	}

	/**
	 * @return the entrante
	 */
	public Boolean getEntrante() {
		return entrante;
	}

	/**
	 * @param entrante the entrante to set
	 */
	public void setEntrante(Boolean entrante) {
		this.entrante = entrante;
	}

	/**
	 * @return the dataInicio
	 */
	public Date getDataInicio() {
		return dataInicio == null ? null : new Date(dataInicio.getTime());
	}

	/**
	 * @param dataInicio the dataInicio to set
	 */
	public void setDataInicio(Date dataInicio) {
		this.dataInicio = dataInicio == null ? null : new Date(dataInicio.getTime());
	}

	/**
	 * @return the dataFim
	 */
	public Date getDataFim() {
		return dataFim == null ? null : new Date(dataFim.getTime());
	}

	/**
	 * @param dataFim the dataFim to set
	 */
	public void setDataFim(Date dataFim) {
		this.dataFim = dataFim == null ? null : new Date(dataFim.getTime());
	}
}
