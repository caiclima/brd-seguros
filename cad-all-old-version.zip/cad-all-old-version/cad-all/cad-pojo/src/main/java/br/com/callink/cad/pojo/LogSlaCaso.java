package br.com.callink.cad.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.pojo.SlaFila;
import br.com.callink.cad.pojo.entity.IEntity;

@Entity
@Table(name = "TB_LOG_SLA_CASO")
public class LogSlaCaso implements IEntity<Integer> {

	private static final long serialVersionUID = -15841936063148368L;

	@Id
	@Column(name = "ID_LOG_SLA_CASO")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idLogSlaCaso;
	
	@ManyToOne(fetch = FetchType.LAZY)
   	@JoinColumn(name = "ID_CASO", referencedColumnName = "ID_CASO" )
    private Caso caso;
	
	@Column(name = "DATA_ABERTURA")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataAbertura;
	
	@Column(name = "DATA_ALTERACAO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataAlteracao;
	
	@ManyToOne(fetch = FetchType.LAZY)
   	@JoinColumn(name = "ID_SLA_FILA", referencedColumnName = "ID_SLA_FILA")
	private SlaFila slaFila;
	
	@ManyToOne(fetch = FetchType.LAZY)
   	@JoinColumn(name = "ID_CONFIGURACAO_FILA", referencedColumnName = "ID_CONFIGURACAO_FILA")
    private ConfiguracaoFila configuracaoFila;
	
	@Column(name = "TEMPO_SLA")
	private Integer tempoSla;
	
	@Column(name = "PERCENTUAL_GASTO")
	private Double percentualGasto;
	
	public Integer getPK() {
        return idLogSlaCaso;
    }

    public void setPK(Integer pk) {
        this.idLogSlaCaso = pk;
    }
	
	public Integer getIdLogSlaCaso() {
		return idLogSlaCaso;
	}

	public void setIdLogSlaCaso(Integer idLogSlaCaso) {
		this.idLogSlaCaso = idLogSlaCaso;
	}

	public Caso getCaso() {
		return caso;
	}

	public void setCaso(Caso caso) {
		this.caso = caso;
	}

	public Date getDataAbertura() {
		return dataAbertura;
	}

	public void setDataAbertura(Date dataAbertura) {
		this.dataAbertura = dataAbertura;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public SlaFila getSlaFila() {
		return slaFila;
	}

	public void setSlaFila(SlaFila slaFila) {
		this.slaFila = slaFila;
	}
	
	public ConfiguracaoFila getConfiguracaoFila() {
		return configuracaoFila;
	}

	public void setConfiguracaoFila(ConfiguracaoFila configuracaoFila) {
		this.configuracaoFila = configuracaoFila;
	}

	public Integer getTempoSla() {
		return tempoSla;
	}

	public void setTempoSla(Integer tempoSla) {
		this.tempoSla = tempoSla;
	}

	public Double getPercentualGasto() {
		return percentualGasto;
	}

	public void setPercentualGasto(Double percentualGasto) {
		this.percentualGasto = percentualGasto;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((idLogSlaCaso == null) ? 0 : idLogSlaCaso.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LogSlaCaso other = (LogSlaCaso) obj;
		if (idLogSlaCaso == null) {
			if (other.idLogSlaCaso != null)
				return false;
		} else if (!idLogSlaCaso.equals(other.idLogSlaCaso))
			return false;
		return true;
	}
	
	public static String getSqlCamposLogSlaCaso() {
		return new StringBuilder()
				.append(" \nLogSlaCaso.ID_LOG_SLA_CASO AS 'LogSlaCaso.ID_LOG_SLA_CASO', ")
				.append(" \nLogSlaCaso.ID_CASO AS 'LogSlaCaso.ID_CASO', ")
				.append(" \nLogSlaCaso.DATA_ABERTURA AS 'LogSlaCaso.DATA_ABERTURA', ")
				.append(" \nLogSlaCaso.DATA_ALTERACAO AS 'LogSlaCaso.DATA_ALTERACAO', ")
				.append(" \nLogSlaCaso.ID_SLA_FILA as 'LogSlaCaso.ID_SLA_FILA', ")
				.append(" \nLogSlaCaso.ID_CONFIGURACAO_FILA as 'LogSlaCaso.ID_CONFIGURACAO_FILA', ")
				.append(" \nLogSlaCaso.TEMPO_SLA as 'LogSlaCaso.TEMPO_SLA', ")
				.append(" \nLogSlaCaso.PERCENTUAL_GASTO as 'LogSlaCaso.PERCENTUAL_GASTO' ").toString();
	}

	public static String getSqlFromLogSlaCaso() {
		return " TB_LOG_SLA_CASO  AS LogSlaCaso with(nolock) ";
	}

	public static LogSlaCaso getLogSlaCasoByResultSet(ResultSet rs) {
		try {
			if (rs.getInt("LogSlaCaso.ID_LOG_SLA_CASO") == 0) {
				return null;
			}

			LogSlaCaso logSlaCaso = new LogSlaCaso();
			logSlaCaso.setIdLogSlaCaso(rs.getInt("LogSlaCaso.ID_LOG_SLA_CASO"));
			logSlaCaso.setCaso(rs.getInt("LogSlaCaso.ID_CASO") == 0 ? null : new Caso(rs.getInt("LogSlaCaso.ID_CASO")));
			logSlaCaso.setDataAbertura(rs.getTimestamp("LogSlaCaso.DATA_ABERTURA"));
			logSlaCaso.setDataAlteracao(rs.getTimestamp("LogSlaCaso.DATA_ALTERACAO"));
			logSlaCaso.setSlaFila(rs.getInt("LogSlaCaso.ID_SLA_FILA") == 0 ? null : new SlaFila(rs.getInt("LogSlaCaso.ID_SLA_FILA")));
			logSlaCaso.setConfiguracaoFila(rs.getInt("LogSlaCaso.ID_CONFIGURACAO_FILA") == 0 ? null : new ConfiguracaoFila(rs.getInt("LogSlaCaso.ID_CONFIGURACAO_FILA")));
			logSlaCaso.setTempoSla(rs.getInt("LogSlaCaso.TEMPO_SLA"));
			logSlaCaso.setPercentualGasto(rs.getDouble("LogSlaCaso.PERCENTUAL_GASTO"));
			return logSlaCaso;
		} catch (SQLException ex) {
			throw new IllegalArgumentException("Erro ao montar objeto a partir do ResultSet", ex);
		}
	}
	
}
