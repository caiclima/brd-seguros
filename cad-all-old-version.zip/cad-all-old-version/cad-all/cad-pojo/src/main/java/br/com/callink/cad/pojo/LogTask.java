package br.com.callink.cad.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;



/**
 * 
 * @author bruno [bruno.martins@callink.com.br]
 *
 */

@Entity
@Table(name = "TB_LOG_TASKS")
public class LogTask implements IEntity<Integer> {

	private static final long serialVersionUID = -4340293799448747960L;

	@Id
	@Column(name = "ID_LOG_TASKS")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer idLogTasks;
	
	@Column(name = "MNM_EXECUTOR" , length = 200)
	private String mnmExecutor;
	
	@Column(name = "DATA_INICIAL")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataInicial;
	
	@Column(name = "DATA_FINAL")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataFinal;
	
	@Column(name = "TOTAL_REGISTROS")
	private Integer totalRegistros;
	
	public final Integer getIdLogTasks() {
		return idLogTasks;
	}

	public final void setIdLogTasks(Integer idLogTasks) {
		this.idLogTasks = idLogTasks;
	}

	public final Date getDataInicial() {
		return dataInicial == null ? null : new Date(dataInicial.getTime());
	}

	public final void setDataInicial(Date dataInicial) {
		this.dataInicial = dataInicial == null ? null : new Date(dataInicial.getTime());
	}

	public final Date getDataFinal() {
		return dataFinal == null ? null : new Date(dataFinal.getTime());
	}

	public final void setDataFinal(Date dataFinal) {
		this.dataFinal = dataFinal == null ? null : new Date(dataFinal.getTime());
	}

	public final Integer getTotalRegistros() {
		return totalRegistros;
	}

	public final void setTotalRegistros(Integer totalRegistros) {
		this.totalRegistros = totalRegistros;
	}

	public final String getMnmExecutor() {
		return mnmExecutor;
	}

	public final void setMnmExecutor(String mnmExecutor) {
		this.mnmExecutor = mnmExecutor;
	}

	public Integer getPK() {
		return idLogTasks;
	}

	public void setPK(Integer pk) {
		this.idLogTasks = pk;
	}

	
	public static String getSqlCamposLogTask() {
 		
     	return new StringBuilder()
 		.append(" \nLogTask.ID_LOG_TASKS AS 'LogTask.ID_LOG_TASKS',")
 		.append(" \nLogTask.MNM_EXECUTOR AS 'LogTask.MNM_EXECUTOR',")
 		.append(" \nLogTask.DATA_INICIAL AS 'LogTask.DATA_INICIAL',")
 		.append(" \nLogTask.DATA_FINAL AS 'LogTask.DATA_FINAL',")
 		.append(" \nLogTask.TOTAL_REGISTROS AS 'LogTask.TOTAL_REGISTROS'")
 		.toString();
 	}

 	public static String getSqlFromLogTask() {
 		return " TB_LOG_TASKS  AS LogTask with(nolock) ";
 	}

 	public static LogTask getLogTaskByResultSet(ResultSet resultSet) {

 		LogTask logTask = new LogTask();

 		try {
 			
 			if(resultSet.getInt("LogTask.ID_LOG_TASKS") == 0) {
        		return null;
        	}
 			
 			logTask.setIdLogTasks(resultSet.getInt("LogTask.ID_LOG_TASKS"));
 			logTask.setMnmExecutor(resultSet.getString("LogTask.MNM_EXECUTOR"));
 			logTask.setDataInicial(resultSet.getTimestamp("LogTask.DATA_INICIAL"));
 			logTask.setDataFinal(resultSet.getTimestamp("LogTask.DATA_FINAL"));
 			logTask.setTotalRegistros(resultSet.getInt("LogTask.TOTAL_REGISTROS"));
 			
 		} catch (SQLException e) {
 			throw new IllegalArgumentException("Erro ao montar objeto a partir do ResultSet", e);
 		}
 		return logTask;
 	}
	
}
