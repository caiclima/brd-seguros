/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import br.com.callink.cad.pojo.entity.IEntity;



/**
 *
 * @author miller(miller@swb.com.br)
 * @since 26/06/2012
 * 
 */
@Entity
@Table(name = "TB_META_UPH")
public class MetaUph implements IEntity<Integer>, Comparable<MetaUph> {
    
	private static final long serialVersionUID = -3344995964205234855L;

	@Id
	@Column(name = "ID_META_UPH")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idMetaUph;
    
    @Column(name="META" , nullable = false)
    private Double meta;
    
    @Column(name="DESCRICAO" , length = 50)
    private String descricao;
    
    @Column(name="NOME_IMAGEM" , length = 50)
    private String nomeImagem;
		
    @Column(name="GOAL")
    private Integer goal; 
    
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_CAB_UPH", referencedColumnName = "ID_CAB_UPH" , nullable = false)
    private CabUph idCabUph;
    
	public MetaUph() {
		super();
	}

    public final Integer getPK() {
        return idMetaUph;
    }
    
    public final void setPK(Integer id) {
         this.idMetaUph = id;
    }
    
    public final String getDescricao() {
        return descricao;
    }

    public final void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public final CabUph getIdCabUph() {
        return idCabUph;
    }

    public final void setIdCabUph(CabUph idCabUph) {
        this.idCabUph = idCabUph;
    }

    public final Integer getIdMetaUph() {
        return idMetaUph;
    }

    public final void setIdMetaUph(Integer idMetaUph) {
        this.idMetaUph = idMetaUph;
    }

    public final Double getMeta() {
        return meta;
    }

    public final void setMeta(Double meta) {
        this.meta = meta;
    }

    public String getNomeImagem() {
    	return nomeImagem;
    }
    
    public void setNomeImagem(String nomeImagem) {
    	this.nomeImagem = nomeImagem;
    }

    /* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((idCabUph == null) ? 0 : idCabUph.hashCode());
		result = prime * result
				+ ((idMetaUph == null) ? 0 : idMetaUph.hashCode());
		result = prime * result + ((meta == null) ? 0 : meta.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof MetaUph)) {
			return false;
		}
		MetaUph other = (MetaUph) obj;
		if (idCabUph == null) {
			if (other.idCabUph != null) {
				return false;
			}
		} else if (!idCabUph.equals(other.idCabUph)) {
			return false;
		}
		if (idMetaUph == null) {
			if (other.idMetaUph != null) {
				return false;
			}
		} else if (!idMetaUph.equals(other.idMetaUph)) {
			return false;
		}
		if (meta == null) {
			if (other.meta != null) {
				return false;
			}
		} else if (!meta.equals(other.meta)) {
			return false;
		}
		return true;
	}

	@Override
    public final String toString() {
        return getDescricao();
    }

	@Override
	public int compareTo(MetaUph o) {
		return this.meta.compareTo(o.getMeta());
	}

	public final Integer getGoal() {
		return goal;
	}

	public final void setGoal(Integer goal) {
		this.goal = goal;
	}
	
	public static String getSqlCamposMetaUph() {
 		
     	return new StringBuilder()
 		.append(" \nMetaUph.ID_META_UPH AS 'MetaUph.ID_META_UPH',")
 		.append(" \nMetaUph.META AS 'MetaUph.META',")
 		.append(" \nMetaUph.DESCRICAO AS 'MetaUph.DESCRICAO',")
 		.append(" \nMetaUph.NOME_IMAGEM AS 'MetaUph.NOME_IMAGEM',")
 		.append(" \nMetaUph.GOAL AS 'MetaUph.GOAL',")
 		.append(" \nMetaUph.ID_CAB_UPH AS 'MetaUph.ID_CAB_UPH'")
 		.toString();
 	}

 	public static String getSqlFromMetaUph() {
 		return " TB_META_UPH  AS MetaUph with(nolock) ";
 	}

 	public static MetaUph getMetaUphByResultSet(ResultSet resultSet) {

 		MetaUph metaUph = new MetaUph();

 		try {
 			
 			if(resultSet.getInt("MetaUph.ID_META_UPH") == 0) {
        		return null;
        	}
 			
 			metaUph.setIdMetaUph(resultSet.getInt("MetaUph.ID_META_UPH"));
 			metaUph.setMeta(resultSet.getDouble("MetaUph.META"));
 			metaUph.setDescricao(resultSet.getString("MetaUph.DESCRICAO"));
 			metaUph.setNomeImagem(resultSet.getString("MetaUph.NOME_IMAGEM"));
 			metaUph.setGoal(resultSet.getInt("MetaUph.GOAL"));
 			metaUph.setIdCabUph(resultSet.getInt("MetaUph.ID_CAB_UPH") ==0 ? null : new CabUph(resultSet.getInt("MetaUph.ID_CAB_UPH")));
 			
 		} catch (SQLException e) {
 			throw new IllegalArgumentException("Erro ao montar objeto a partir do ResultSet", e);
 		}
 		return metaUph;
 	}
	
}
