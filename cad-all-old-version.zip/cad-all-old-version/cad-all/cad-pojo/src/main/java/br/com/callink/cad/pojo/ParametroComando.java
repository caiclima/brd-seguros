package br.com.callink.cad.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;


/**
 *
 * @author Ednaldo Caic [ednaldo@swb.com.br]
 * @since 23/12/2011
 */
@Entity
@Table(name = "TB_PARAMETRO_COMANDO")
public class ParametroComando implements IEntity<Integer> {

	private static final long serialVersionUID = -3594988793019301868L;

	@Id
	@Column(name = "ID_PARAMETRO_COMANDO")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idParametroComando;
    
    @Column(name = "NOME")
    private String nome;
    
    @Column(name = "VALOR")
    private String valor;
    
    @ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_COMANDO", referencedColumnName = "ID_COMANDO" , nullable = false)
    private Comando comando;
    
    @Column(name = "LOGIN_USUARIO")
    private String loginUsuario;
    
    @Column(name = "DATA_CRIACAO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataCriacao;
    
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result
                + ((idParametroComando == null) ? 0 : idParametroComando.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof ParametroComando)) {
            return false;
        }
        ParametroComando other = (ParametroComando) obj;
        if (idParametroComando == null) {
            if (other.idParametroComando != null) {
                return false;
            }
        } else if (!idParametroComando.equals(other.idParametroComando)) {
            return false;
        }
        return true;
    }

    public Integer getPK() {
        return idParametroComando;
    }

    public void setPK(Integer pk) {
        this.idParametroComando = pk;
    }

    public final Integer getIdParametroComando() {
        return idParametroComando;
    }

    public final void setIdParametroComando(Integer idParametroComando) {
        this.idParametroComando = idParametroComando;
    }

    public final String getNome() {
        return nome;
    }

    public final void setNome(String nome) {
        this.nome = nome;
    }

    public final String getValor() {
        return valor;
    }

    public final void setValor(String valor) {
        this.valor = valor;
    }

    public final Comando getComando() {
        return comando;
    }

    public final void setComando(Comando comando) {
        this.comando = comando;
    }

	public void setDataCriacao(Date dataCriacao) {
		this.dataCriacao = dataCriacao!= null ? new Date(dataCriacao.getTime()) : null;
	}

	public Date getDataCriacao() {
		return dataCriacao!= null ? new Date(dataCriacao.getTime()) : null;
	}

	public final String getLoginUsuario() {
		return loginUsuario;
	}

	public final void setLoginUsuario(String loginUsuario) {
		this.loginUsuario = loginUsuario;
	}
	
	public static String getSqlCamposParametroComando() {
 		
     	return new StringBuilder()
 		.append(" \nParametroComando.ID_PARAMETRO_COMANDO AS 'ParametroComando.ID_PARAMETRO_COMANDO',")
 		.append(" \nParametroComando.NOME AS 'ParametroComando.NOME',")
 		.append(" \nParametroComando.VALOR AS 'ParametroComando.VALOR',")
 		.append(" \nParametroComando.ID_COMANDO AS 'ParametroComando.ID_COMANDO',")
 		.append(" \nParametroComando.LOGIN_USUARIO AS 'ParametroComando.LOGIN_USUARIO',")
 		.append(" \nParametroComando.DATA_CRIACAO AS 'ParametroComando.DATA_CRIACAO'")
 		.toString();
 	}

 	public static String getSqlFromParametroComando() {
 		return " TB_PARAMETRO_COMANDO  AS ParametroComando with(nolock) ";
 	}

 	public static ParametroComando getParametroComandoByResultSet(ResultSet resultSet) {

 		ParametroComando parametroComando = new ParametroComando();

 		try {
 			
 			if(resultSet.getInt("ParametroComando.ID_PARAMETRO_COMANDO") == 0) {
        		return null;
        	}
 			
 			parametroComando.setIdParametroComando(resultSet.getInt("ParametroComando.ID_PARAMETRO_COMANDO"));
 			parametroComando.setNome(resultSet.getString("ParametroComando.NOME"));
 			parametroComando.setValor(resultSet.getString("ParametroComando.VALOR"));
 			parametroComando.setComando(resultSet.getInt("ParametroComando.ID_COMANDO") == 0 ? null : new Comando(resultSet.getInt("ParametroComando.ID_COMANDO")));
 			parametroComando.setLoginUsuario(resultSet.getString("ParametroComando.LOGIN_USUARIO"));
 			parametroComando.setDataCriacao(resultSet.getTimestamp("ParametroComando.DATA_CRIACAO"));
 			
 		} catch (SQLException e) {
 			throw new IllegalArgumentException("Erro ao montar objeto a partir do ResultSet", e);
 		}
 		return parametroComando;
 	}
	
 	
 	public static ParametroGBO getParametroGBOByResultSet(ResultSet resultSet) {

 		ParametroGBO parametroGBO = new ParametroGBO();

 		try {
 			
 			if(resultSet.getInt("ParametroGbo.id_parametro_gbo") == 0) {
        		return null;
        	}
 			
 			parametroGBO.setIdParametroGBO(resultSet.getInt("ParametroGbo.id_parametro_gbo"));
 			parametroGBO.setNome(resultSet.getString("ParametroGbo.nome"));
 			parametroGBO.setValor(resultSet.getString("ParametroGbo.valor"));
 			parametroGBO.setLoginUsuario(resultSet.getString("ParametroGbo.login_usuario"));
 			parametroGBO.setDataAlteracao(resultSet.getTimestamp("ParametroGbo.data_alteracao"));
 			parametroGBO.setDescricao(resultSet.getString("ParametroGbo.descricao"));
 			
 		} catch (SQLException e) {
 			throw new IllegalArgumentException("Erro ao montar objeto a partir do ResultSet", e);
 		}
 		return parametroGBO;
 	}
 	
}
