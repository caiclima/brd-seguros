package br.com.callink.cad.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;


/**
 * 
 * @author brunomt [brunoam@swb.com.br]
 *
 */
@Entity
@Table(name = "TB_PARAMETRO_GBO")
public class ParametroGBO implements IEntity<Integer> {

	
	private static final long serialVersionUID = -4099151722334549481L;

	@Id
	@Column(name = "id_parametro_gbo")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer idParametroGBO;
	
	@Column(name = "nome" , length = 200)
	private String nome;
	
	@Column(name = "valor" , length = 4000)
	private String valor;
	
	@Column(name = "login_usuario" , length = 200)
	private String loginUsuario;
	
	@Column(name = "data_alteracao")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataAlteracao;
	
	@Column(name = "descricao" , length = 2000)
	private String descricao;
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((idParametroGBO == null) ? 0 : idParametroGBO.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof ParametroGBO)) {
			return false;
		}
		ParametroGBO other = (ParametroGBO) obj;
		if (idParametroGBO == null) {
			if (other.idParametroGBO != null) {
				return false;
			}
		} else if (!idParametroGBO.equals(other.idParametroGBO)) {
			return false;
		}
		return true;
	}

	public Integer getPK() {
		return idParametroGBO;
	}

	public void setPK(Integer pk) {
		this.idParametroGBO = pk;
	}

	public final Integer getIdParametroGBO() {
		return idParametroGBO;
	}

	public final void setIdParametroGBO(Integer idParametroGBO) {
		this.idParametroGBO = idParametroGBO;
	}

	public final String getNome() {
		return nome;
	}

	public final void setNome(String nome) {
		this.nome = nome;
	}

	public final String getValor() {
		return valor;
	}

	public final void setValor(String valor) {
		this.valor = valor;
	}

	public final String getLoginUsuario() {
		return loginUsuario;
	}

	public final void setLoginUsuario(String loginUsuario) {
		this.loginUsuario = loginUsuario;
	}

	public final Date getDataAlteracao() {
		return dataAlteracao != null ? new Date(dataAlteracao.getTime()) : null;
	}

	public final void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao != null ? new Date(dataAlteracao.getTime()) : null;
	}

	public final String getDescricao() {
		return descricao;
	}

	public final void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public static String getSqlCamposParametroGBO() {
 		
     	return new StringBuilder()
 		.append(" \nParametroGbo.id_parametro_gbo AS 'ParametroGbo.id_parametro_gbo',")
 		.append(" \nParametroGbo.nome AS 'ParametroGbo.nome',")
 		.append(" \nParametroGbo.valor AS 'ParametroGbo.valor',")
 		.append(" \nParametroGbo.login_usuario AS 'ParametroGbo.login_usuario',")
 		.append(" \nParametroGbo.data_alteracao AS 'ParametroGbo.data_alteracao',")
 		.append(" \nParametroGbo.descricao AS 'ParametroGbo.descricao'")
 		.toString();
 	}

 	public static String getSqlFromParametroGBO() {
 		return " TB_PARAMETRO_GBO  AS ParametroGbo with(nolock) ";
 	}

 	public static ParametroGBO getParametroGBOByResultSet(ResultSet resultSet) {

 		ParametroGBO parametroGBO = new ParametroGBO();

 		try {
 			
 			if(resultSet.getInt("ParametroGbo.id_parametro_gbo") == 0) {
        		return null;
        	}
 			
 			parametroGBO.setIdParametroGBO(resultSet.getInt("ParametroGbo.id_parametro_gbo"));
 			parametroGBO.setNome(resultSet.getString("ParametroGbo.nome"));
 			parametroGBO.setValor(resultSet.getString("ParametroGbo.valor"));
 			parametroGBO.setLoginUsuario(resultSet.getString("ParametroGbo.login_usuario"));
 			parametroGBO.setDataAlteracao(resultSet.getTimestamp("ParametroGbo.data_alteracao"));
 			parametroGBO.setDescricao(resultSet.getString("ParametroGbo.descricao"));
 			
 		} catch (SQLException e) {
 			throw new IllegalArgumentException("Erro ao montar objeto a partir do ResultSet", e);
 		}
 		return parametroGBO;
 	}
	
	
}
