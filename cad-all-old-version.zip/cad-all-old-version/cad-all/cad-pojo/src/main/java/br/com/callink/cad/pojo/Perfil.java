/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.pojo;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;

/**
 *
 * @author Rogério Moreira de Andrade. [rogeriom@swb.com.br]
 */
@Entity
@Table(name = "TB_PERFIL")
public class Perfil implements IEntity<Integer> {

	private static final long serialVersionUID = 5542830147939055443L;
	
	@Id
	@Column(name = "id_perfil")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idPerfil;
    
	@Column(name = "nome" , length = 200)
    private String nome;
   
	@Column(name = "data_criacao")
	@Temporal(TemporalType.TIMESTAMP)
    private Date dataCriacao;
    
	@Column(name = "flag_ativo")
    private Boolean flagAtivo;
    
    public Perfil(){
    	
    }
    
    public Perfil(Integer idPerfil){
    	this.idPerfil = idPerfil;
    }

    public Integer getPK() {
        return this.idPerfil;
    }

    public void setPK(Integer pk) {
        this.idPerfil = pk;
    }

    public Date getDataCriacao() {
        return dataCriacao != null ? new Date(dataCriacao.getTime()) : null;
    }

    public void setDataCriacao(Date dataCriacao) {
        this.dataCriacao = dataCriacao != null ? new Date(dataCriacao.getTime()) : null;
    }

    public Boolean getFlagAtivo() {
        return flagAtivo;
    }

    public void setFlagAtivo(Boolean flagAtivo) {
        this.flagAtivo = flagAtivo;
    }

    public Integer getIdPerfil() {
        return idPerfil;
    }

    public void setIdPerfil(Integer idPerfil) {
        this.idPerfil = idPerfil;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((idPerfil == null) ? 0 : idPerfil.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof Perfil)) {
			return false;
		}
		Perfil other = (Perfil) obj;
		if (idPerfil == null) {
			if (other.idPerfil != null) {
				return false;
			}
		} else if (!idPerfil.equals(other.idPerfil)) {
			return false;
		}
		return true;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return nome;
	}

	public static String getSqlCamposPerfil() {
 		
     	return new StringBuilder()
 		.append(" \nPerfil.id_perfil AS 'Perfil.id_perfil',")
 		.append(" \nPerfil.nome AS 'Perfil.nome',")
 		.append(" \nPerfil.data_criacao AS 'Perfil.data_criacao',")
 		.append(" \nPerfil.flag_ativo AS 'Perfil.flag_ativo'")
 		.toString();
 	}

 	public static String getSqlFromPerfil() {
 		return " TB_PERFIL  AS Perfil with(nolock) ";
 	}

 	public static Perfil getPerfilByResultSet(ResultSet resultSet) {

 		Perfil perfil = new Perfil();

 		try {
 			
 			if(resultSet.getInt("Perfil.id_perfil") == 0) {
        		return null;
        	}
 			
 			perfil.setIdPerfil(resultSet.getInt("Perfil.id_perfil"));
 			perfil.setNome(resultSet.getString("Perfil.nome"));
 			perfil.setDataCriacao(resultSet.getTimestamp("Perfil.data_criacao"));
 			perfil.setFlagAtivo(resultSet.getBoolean("Perfil.flag_ativo"));
 			
 		} catch (SQLException e) {
 			throw new IllegalArgumentException("Erro ao montar objeto a partir do ResultSet", e);
 		}
 		return perfil;
 	}
    
}
