package br.com.callink.cad.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;


/**
*
* @author Bruno Alves [brunoam@swb.com.br]
* @since 13/01/2012
*/

@Entity
@Table(name = "TB_REABERTURA_CASO")
public class ReaberturaCaso implements IEntity<Integer>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 488348006625260128L;

	@Id
	@Column(name = "ID_REABERTURA_CASO")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer idReaberturaCaso;

	@Column(name = "DATA_REABERTURA")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataReabertura;
	
	@Column(name = "MOTIVO_REABERTURA")
	private String motivoReabertura;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_CASO", referencedColumnName = "ID_CASO" , nullable = false)
	private Caso caso;

	/**
	 * @return the idReaberturaCaso
	 */
	public final Integer getIdReaberturaCaso() {
		return idReaberturaCaso;
	}

	/**
	 * @param idReaberturaCaso the idReaberturaCaso to set
	 */
	public final void setIdReaberturaCaso(Integer idReaberturaCaso) {
		this.idReaberturaCaso = idReaberturaCaso;
	}

	/**
	 * @return the dataReabertura
	 */
	public final Date getDataReabertura() {
		return dataReabertura != null ? new Date(dataReabertura.getTime()) : null;
	}

	/**
	 * @param dataReabertura the dataReabertura to set
	 */
	public final void setDataReabertura(Date dataReabertura) {
		this.dataReabertura = dataReabertura != null ? new Date(dataReabertura.getTime()) : null;
	}

	/**
	 * @return the motivoReabertura
	 */
	public final String getMotivoReabertura() {
		return motivoReabertura;
	}

	/**
	 * @param motivoReabertura the motivoReabertura to set
	 */
	public final void setMotivoReabertura(String motivoReabertura) {
		this.motivoReabertura = motivoReabertura;
	}

	/**
	 * @return the caso
	 */
	public final Caso getCaso() {
		return caso;
	}

	/**
	 * @param caso the caso to set
	 */
	public final void setCaso(Caso caso) {
		this.caso = caso;
	}

	public Integer getPK() {
		return idReaberturaCaso;
	}

	public void setPK(Integer pk) {
		this.idReaberturaCaso = pk;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((idReaberturaCaso == null) ? 0 : idReaberturaCaso.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof ReaberturaCaso)) {
			return false;
		}
		ReaberturaCaso other = (ReaberturaCaso) obj;
		if (idReaberturaCaso == null) {
			if (other.idReaberturaCaso != null) {
				return false;
			}
		} else if (!idReaberturaCaso.equals(other.idReaberturaCaso)) {
			return false;
		}
		return true;
	}

    public static String getSqlCamposReaberturaCaso() {
 		
     	return new StringBuilder()
 		.append(" \nReaberturaCaso.ID_REABERTURA_CASO AS 'ReaberturaCaso.ID_REABERTURA_CASO',")
 		.append(" \nReaberturaCaso.DATA_REABERTURA AS 'ReaberturaCaso.DATA_REABERTURA',")
 		.append(" \nReaberturaCaso.MOTIVO_REABERTURA AS 'ReaberturaCaso.MOTIVO_REABERTURA',")
 		.append(" \nReaberturaCaso.ID_CASO AS 'ReaberturaCaso.ID_CASO'")
 		.toString();
 	}

 	public static String getSqlFromReaberturaCaso() {
 		return " TB_REABERTURA_CASO  AS ReaberturaCaso with(nolock) ";
 	}

 	public static ReaberturaCaso getReaberturaCasoByResultSet(ResultSet resultSet) {

 		ReaberturaCaso reaberturaCaso = new ReaberturaCaso();

 		try {
 			
 			if(resultSet.getInt("ReaberturaCaso.ID_REABERTURA_CASO") == 0) {
        		return null;
        	}
 			
 			reaberturaCaso.setIdReaberturaCaso(resultSet.getInt("ReaberturaCaso.ID_REABERTURA_CASO"));
 			reaberturaCaso.setDataReabertura(resultSet.getTimestamp("ReaberturaCaso.DATA_REABERTURA"));
 			reaberturaCaso.setMotivoReabertura(resultSet.getString("ReaberturaCaso.MOTIVO_REABERTURA"));
 			reaberturaCaso.setCaso(resultSet.getInt("ReaberturaCaso.ID_CASO") == 0 ? null : new Caso(resultSet.getInt("ReaberturaCaso.ID_CASO")));
 			
 		} catch (SQLException e) {
 			throw new IllegalArgumentException("Erro ao montar objeto a partir do ResultSet", e);
 		}
 		return reaberturaCaso;
 	}
	
}
