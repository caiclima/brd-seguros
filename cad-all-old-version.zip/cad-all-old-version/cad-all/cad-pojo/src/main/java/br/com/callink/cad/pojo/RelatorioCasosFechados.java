package br.com.callink.cad.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;


/**
 * 
 * @author bruno
 * 
 */

@Entity
@Table(name = "tb_relatorio_casos_fechados")
public class RelatorioCasosFechados implements IEntity<Integer> {

	private static final long serialVersionUID = 5459268706031213405L;

	@Id
	@Column(name = "id_relatorio_casos_fechados")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer idRelatoriosCasosFechados;
	
	@Column(name = "id_caso" , nullable = false )
	private Integer idCaso;
	
	@Column(name = "id_externo" , nullable = false , length = 20)
	private String idExterno;
	
	@Column(name = "id_equipe")
	private Integer idEquipe;
	
	@Column(name = "equipe_nome" , length = 50)
	private String equipeNome;
	
	@Column(name = "id_fila")
	private Integer idFila;
	
	@Column(name = "fila_nome" , length = 50)
	private String filaNome;
	
	@Column(name = "atendente" , length = 50)
	private String atendente;
	
	@Column(name = "data_fim" , nullable = false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataFim;
	
	@Column(name = "data_cadastro")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataCadastro;
	
	@Column(name = "sla" , nullable = false)
	private Double sla;
	
	@Column(name = "flag_dentro_prazo" , nullable = false)
	private Boolean flagDentroPrazo;
	
	@Column(name = "id_atendente")
	private Integer idAtendente;
	/**
	 * @return the idRelatoriosCasosFechados
	 */
	public Integer getIdRelatoriosCasosFechados() {
		return idRelatoriosCasosFechados;
	}
	/**
	 * @param idRelatoriosCasosFechados the idRelatoriosCasosFechados to set
	 */
	public void setIdRelatoriosCasosFechados(Integer idRelatoriosCasosFechados) {
		this.idRelatoriosCasosFechados = idRelatoriosCasosFechados;
	}
	/**
	 * @return the idCaso
	 */
	public Integer getIdCaso() {
		return idCaso;
	}
	/**
	 * @param idCaso the idCaso to set
	 */
	public void setIdCaso(Integer idCaso) {
		this.idCaso = idCaso;
	}
	/**
	 * @return the idExterno
	 */
	public String getIdExterno() {
		return idExterno;
	}
	/**
	 * @param idExterno the idExterno to set
	 */
	public void setIdExterno(String idExterno) {
		this.idExterno = idExterno;
	}
	/**
	 * @return the idEquipe
	 */
	public Integer getIdEquipe() {
		return idEquipe;
	}
	/**
	 * @param idEquipe the idEquipe to set
	 */
	public void setIdEquipe(Integer idEquipe) {
		this.idEquipe = idEquipe;
	}
	/**
	 * @return the equipeNome
	 */
	public String getEquipeNome() {
		return equipeNome;
	}
	/**
	 * @param equipeNome the equipeNome to set
	 */
	public void setEquipeNome(String equipeNome) {
		this.equipeNome = equipeNome;
	}
	/**
	 * @return the idFila
	 */
	public Integer getIdFila() {
		return idFila;
	}
	/**
	 * @param idFila the idFila to set
	 */
	public void setIdFila(Integer idFila) {
		this.idFila = idFila;
	}
	/**
	 * @return the filaNome
	 */
	public String getFilaNome() {
		return filaNome;
	}
	/**
	 * @param filaNome the filaNome to set
	 */
	public void setFilaNome(String filaNome) {
		this.filaNome = filaNome;
	}
	/**
	 * @return the atendente
	 */
	public String getAtendente() {
		return atendente;
	}
	/**
	 * @param atendente the atendente to set
	 */
	public void setAtendente(String atendente) {
		this.atendente = atendente;
	}
	/**
	 * @return the dataFim
	 */
	public Date getDataFim() {
		return dataFim == null ? null : new Date(dataFim.getTime());
	}
	/**
	 * @param dataFim the dataFim to set
	 */
	public void setDataFim(Date dataFim) {
		this.dataFim = dataFim == null ? null : new Date(dataFim.getTime());
	}
	/**
	 * @return the sla
	 */
	public Double getSla() {
		return sla;
	}
	/**
	 * @param sla the sla to set
	 */
	public void setSla(Double sla) {
		this.sla = sla;
	}
	/**
	 * @return the flagDentroPrazo
	 */
	public Boolean getFlagDentroPrazo() {
		return flagDentroPrazo;
	}
	/**
	 * @param flagDentroPrazo the flagDentroPrazo to set
	 */
	public void setFlagDentroPrazo(Boolean flagDentroPrazo) {
		this.flagDentroPrazo = flagDentroPrazo;
	}
	/**
	 * @return the idAtendente
	 */
	public Integer getIdAtendente() {
		return idAtendente;
	}
	/**
	 * @param idAtendente the idAtendente to set
	 */
	public void setIdAtendente(Integer idAtendente) {
		this.idAtendente = idAtendente;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((idRelatoriosCasosFechados == null) ? 0
						: idRelatoriosCasosFechados.hashCode());
		return result;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof RelatorioCasosFechados)) {
			return false;
		}
		RelatorioCasosFechados other = (RelatorioCasosFechados) obj;
		if (idRelatoriosCasosFechados == null) {
			if (other.idRelatoriosCasosFechados != null) {
				return false;
			}
		} else if (!idRelatoriosCasosFechados
				.equals(other.idRelatoriosCasosFechados)) {
			return false;
		}
		return true;
	}
	public Integer getPK() {
		return idRelatoriosCasosFechados;
	}
	public void setPK(Integer pk) {
		this.idRelatoriosCasosFechados = pk;
	}
	public Date getDataCadastro() {
		return dataCadastro == null ? null : new Date(dataCadastro.getTime());
	}
	public void setDataCadastro(Date dataCadastro) {
		this.dataCadastro = dataCadastro == null ? null : new Date(dataCadastro.getTime());
	}
	
	
	public static String getSqlCamposRelatorioCasosFechados() {
 		
     	return new StringBuilder()
 		.append(" \nRelatorioCasosFechados.id_relatorio_casos_fechados AS 'RelatorioCasosFechados.id_relatorio_casos_fechados',")
 		.append(" \nRelatorioCasosFechados.id_caso AS 'RelatorioCasosFechados.id_caso',")
 		.append(" \nRelatorioCasosFechados.id_externo AS 'RelatorioCasosFechados.id_externo',")
 		.append(" \nRelatorioCasosFechados.id_equipe AS 'RelatorioCasosFechados.id_equipe',")
 		.append(" \nRelatorioCasosFechados.equipe_nome AS 'RelatorioCasosFechados.equipe_nome',")
 		.append(" \nRelatorioCasosFechados.id_fila AS 'RelatorioCasosFechados.id_fila',")
 		.append(" \nRelatorioCasosFechados.fila_nome AS 'RelatorioCasosFechados.fila_nome',")
 		.append(" \nRelatorioCasosFechados.atendente AS 'RelatorioCasosFechados.atendente',")
 		.append(" \nRelatorioCasosFechados.data_fim AS 'RelatorioCasosFechados.data_fim',")
 		.append(" \nRelatorioCasosFechados.data_cadastro AS 'RelatorioCasosFechados.data_cadastro',")
 		.append(" \nRelatorioCasosFechados.sla AS 'RelatorioCasosFechados.sla',")
 		.append(" \nRelatorioCasosFechados.flag_dentro_prazo AS 'RelatorioCasosFechados.flag_dentro_prazo',")
 		.append(" \nRelatorioCasosFechados.id_atendente AS 'RelatorioCasosFechados.id_atendente'")
 		.toString();
 	}

 	public static String getSqlFromRelatorioCasosFechados() {
 		return " tb_relatorio_casos_fechados  AS RelatorioCasosFechados with(nolock)";
 	}

 	public static RelatorioCasosFechados getRelatorioCasosFechadosByResultSet(ResultSet resultSet) {

 		RelatorioCasosFechados relatorioCasosFechados = new RelatorioCasosFechados();

 		try {
 			
 			if(resultSet.getInt("RelatorioCasosFechados.id_relatorio_casos_fechados") == 0) {
        		return null;
        	}
 			
 			relatorioCasosFechados.setIdRelatoriosCasosFechados(resultSet.getInt("RelatorioCasosFechados.id_relatorio_casos_fechados"));
 			relatorioCasosFechados.setIdCaso(resultSet.getInt("RelatorioCasosFechados.id_caso"));
 			relatorioCasosFechados.setIdExterno(resultSet.getString("RelatorioCasosFechados.id_externo"));
 			relatorioCasosFechados.setIdEquipe(resultSet.getInt("RelatorioCasosFechados.id_equipe"));
 			relatorioCasosFechados.setEquipeNome(resultSet.getString("RelatorioCasosFechados.equipe_nome"));
 			relatorioCasosFechados.setIdFila(resultSet.getInt("RelatorioCasosFechados.id_fila"));
 			relatorioCasosFechados.setFilaNome(resultSet.getString("RelatorioCasosFechados.fila_nome"));
 			relatorioCasosFechados.setAtendente(resultSet.getString("RelatorioCasosFechados.atendente"));
 			relatorioCasosFechados.setDataFim(resultSet.getTimestamp("RelatorioCasosFechados.data_fim"));
 			relatorioCasosFechados.setDataCadastro(resultSet.getTimestamp("RelatorioCasosFechados.data_cadastro"));
 			relatorioCasosFechados.setSla(resultSet.getDouble("RelatorioCasosFechados.sla"));
 			relatorioCasosFechados.setFlagDentroPrazo(resultSet.getBoolean("RelatorioCasosFechados.flag_dentro_prazo"));
 			relatorioCasosFechados.setIdAtendente(resultSet.getInt("RelatorioCasosFechados.id_atendente"));
 			
 		} catch (SQLException e) {
 			throw new IllegalArgumentException("Erro ao montar objeto a partir do ResultSet", e);
 		}
 		return relatorioCasosFechados;
 	}
	

}
