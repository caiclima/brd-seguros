package br.com.callink.cad.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;


/**
 * 
 * @author swb.brunocamargo
 * 
 */

@Entity
@Table(name = "tb_relatorio_casos_fechados")
public class RelatorioTempoGeral implements IEntity<Integer> {

	private static final long serialVersionUID = 5459268706031213405L;

	@Id
	@Column(name = "id_relatorio_tempo_geral")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer idRelatorioTempoGeral;
	
	@Column(name = "data")
	@Temporal(TemporalType.TIMESTAMP)
	private Date data;
	
	@Column(name = "id_status" , nullable = false )
	private Integer idStatus;
	
	@Column(name = "status" , nullable = false )
	private String status;
	
	@Column(name = "tempo" , nullable = false )	
	private long tempo;
	
	@Column(name = "qtd_agente_logado_dia" , nullable = false )
	private long qtdAgenteLogadoDia;
	
	@Column(name = "tempo_logado_dia" , nullable = false )
	private long tempoLogadoDia;
	
	@Column(name = "tempo_produtivo_dia" , nullable = false )
	private long tempoProdutivoDia;
	
	@Column(name = "porcent_tempo_produtivo_dia" , nullable = false )
	private double porcentTempoProdutivoDia;
	
	@Column(name = "tempo_pausa_dia" , nullable = false )
	private long tempoPausaDia;
	
	@Column(name = "porcent_tempo_pausa_dia" , nullable = false )
	private double porcentTempoPausaDia;
	
	@Column(name = "tempo_ocioso_dia" , nullable = false )
	private long tempoOciosoDia;
	
	@Column(name = "porcent_tempo_ocioso_dia" , nullable = false )
	private double porcentTempoOciosoDia;
	
	
	@Override
	public Integer getPK() {
		return idRelatorioTempoGeral;
	}

	@Override
	public void setPK(Integer pk) {
		this.idRelatorioTempoGeral = pk;
	}
	
	public Integer getIdRelatorioTempoGeral() {
		return idRelatorioTempoGeral;
	}

	public void setIdRelatorioTempoGeral(Integer idRelatorioTempoGeral) {
		this.idRelatorioTempoGeral = idRelatorioTempoGeral;
	}

	public Date getData() {
		return data;
	}

	public void setData(Date data) {
		this.data = data;
	}

	public Integer getIdStatus() {
		return idStatus;
	}

	public void setIdStatus(Integer idStatus) {
		this.idStatus = idStatus;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public long getTempo() {
		return tempo;
	}

	public void setTempo(long tempo) {
		this.tempo = tempo;
	}

	public long getQtdAgenteLogadoDia() {
		return qtdAgenteLogadoDia;
	}

	public void setQtdAgenteLogadoDia(long qtdAgenteLogadoDia) {
		this.qtdAgenteLogadoDia = qtdAgenteLogadoDia;
	}

	public long getTempoLogadoDia() {
		return tempoLogadoDia;
	}

	public void setTempoLogadoDia(long tempoLogadoDia) {
		this.tempoLogadoDia = tempoLogadoDia;
	}

	public long getTempoProdutivoDia() {
		return tempoProdutivoDia;
	}

	public void setTempoProdutivoDia(long tempoProdutivoDia) {
		this.tempoProdutivoDia = tempoProdutivoDia;
	}

	public double getPorcentTempoProdutivoDia() {
		return porcentTempoProdutivoDia;
	}

	public void setPorcentTempoProdutivoDia(double porcentTempoProdutivoDia) {
		this.porcentTempoProdutivoDia = porcentTempoProdutivoDia;
	}

	public long getTempoPausaDia() {
		return tempoPausaDia;
	}

	public void setTempoPausaDia(long tempoPausaDia) {
		this.tempoPausaDia = tempoPausaDia;
	}

	public double getPorcentTempoPausaDia() {
		return porcentTempoPausaDia;
	}

	public void setPorcentTempoPausaDia(double porcentTempoPausaDia) {
		this.porcentTempoPausaDia = porcentTempoPausaDia;
	}
	
	public long getTempoOciosoDia() {
		return tempoOciosoDia;
	}

	public void setTempoOciosoDia(long tempoOciosoDia) {
		this.tempoOciosoDia = tempoOciosoDia;
	}

	public double getPorcentTempoOciosoDia() {
		return porcentTempoOciosoDia;
	}

	public void setPorcentTempoOciosoDia(double porcentTempoOciosoDia) {
		this.porcentTempoOciosoDia = porcentTempoOciosoDia;
	}

	public static String getSqlCamposRelatorioTempoGeral() {
 		
     	return new StringBuilder()
 		.append(" \nRelatorioTempoGeral.id_relatorio_tempo_geral AS 'RelatorioTempoGeral.id_relatorio_tempo_geral',")
 		.append(" \nRelatorioTempoGeral.data AS 'RelatorioTempoGeral.data',")
 		.append(" \nRelatorioTempoGeral.id_status AS 'RelatorioTempoGeral.id_status',")
 		.append(" \nRelatorioTempoGeral.status AS 'RelatorioTempoGeral.status',")
 		.append(" \nRelatorioTempoGeral.tempo AS 'RelatorioTempoGeral.tempo',")
 		.append(" \nRelatorioTempoGeral.qtd_agente_logado_dia AS 'RelatorioTempoGeral.qtd_agente_logado_dia',")
 		.append(" \nRelatorioTempoGeral.tempo_logado_dia AS 'RelatorioTempoGeral.tempo_logado_dia',")
 		.append(" \nRelatorioTempoGeral.tempo_produtivo_dia AS 'RelatorioTempoGeral.tempo_produtivo_dia',")
 		.append(" \nRelatorioTempoGeral.porcent_tempo_produtivo_dia AS 'RelatorioTempoGeral.porcent_tempo_produtivo_dia',")
 		.append(" \nRelatorioTempoGeral.tempo_pausa_dia AS 'RelatorioTempoGeral.tempo_pausa_dia',")
 		.append(" \nRelatorioTempoGeral.porcent_tempo_pausa_dia AS 'RelatorioTempoGeral.porcent_tempo_pausa_dia', ")
 		.append(" \nRelatorioTempoGeral.tempo_ocioso_dia AS 'RelatorioTempoGeral.tempo_ocioso_dia', ")
 		.append(" \nRelatorioTempoGeral.porcent_tempo_ocioso_dia AS 'RelatorioTempoGeral.porcent_tempo_ocioso_dia' ")
 		.toString();
 	}

 	public static String getSqlFromRelatorioTempoGeral() {
 		return " tb_relatorio_tempo_geral  AS RelatorioTempoGeral with(nolock) ";
 	}

 	public static RelatorioTempoGeral getRelatorioTempoGeralByResultSet(ResultSet resultSet) {

 		RelatorioTempoGeral relatorioTempoGeral = new RelatorioTempoGeral();

 		try {
 			
 			if(resultSet.getInt("RelatorioTempoGeral.id_relatorio_tempo_geral") == 0) {
        		return null;
        	}
 			
 			relatorioTempoGeral.setIdRelatorioTempoGeral(resultSet.getInt("RelatorioTempoGeral.id_relatorio_tempo_geral"));
 			relatorioTempoGeral.setData(resultSet.getTimestamp("RelatorioTempoGeral.data"));
 			relatorioTempoGeral.setIdStatus(resultSet.getInt("RelatorioTempoGeral.id_status"));
 			relatorioTempoGeral.setStatus(resultSet.getString("RelatorioTempoGeral.status"));
 			relatorioTempoGeral.setTempo(resultSet.getLong("RelatorioTempoGeral.tempo"));
 			relatorioTempoGeral.setQtdAgenteLogadoDia(resultSet.getLong("RelatorioTempoGeral.qtd_agente_logado_dia"));
 			relatorioTempoGeral.setTempoLogadoDia(resultSet.getLong("RelatorioTempoGeral.tempo_logado_dia"));
 			relatorioTempoGeral.setTempoProdutivoDia(resultSet.getLong("RelatorioTempoGeral.tempo_produtivo_dia"));
 			relatorioTempoGeral.setPorcentTempoProdutivoDia(resultSet.getDouble("RelatorioTempoGeral.porcent_tempo_produtivo_dia"));
 			relatorioTempoGeral.setTempoPausaDia(resultSet.getLong("RelatorioTempoGeral.tempo_pausa_dia"));
 			relatorioTempoGeral.setPorcentTempoPausaDia(resultSet.getDouble("RelatorioTempoGeral.porcent_tempo_pausa_dia"));
 			relatorioTempoGeral.setTempoOciosoDia(resultSet.getLong("RelatorioTempoGeral.tempo_ocioso_dia"));
 			relatorioTempoGeral.setPorcentTempoOciosoDia(resultSet.getDouble("RelatorioTempoGeral.porcent_tempo_ocioso_dia"));
 			
 			
 		} catch (SQLException e) {
 			throw new IllegalArgumentException("Erro ao montar objeto a partir do ResultSet", e);
 		}
 		return relatorioTempoGeral;
 	}

	
	

}
