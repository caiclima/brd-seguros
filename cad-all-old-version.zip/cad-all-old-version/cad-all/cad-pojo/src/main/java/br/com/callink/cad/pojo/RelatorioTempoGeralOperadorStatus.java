package br.com.callink.cad.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;

/**
 * 
 * @author swb.hermano
 * 
 */

@Entity
@Table(name = "tb_relatorio_tempo_geral_operador_status")
public class RelatorioTempoGeralOperadorStatus implements IEntity<Integer> {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 4007429724398061359L;

	@Id
	@Column(name = "id_tempo_geral_operador")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	Integer idTempoGeralOperador;
	
	@Column(name = "supervisor")
	private String supervisor;
	
	@Column(name = "login_atendente")
	private String loginAtendente;
	
	@Column(name = "id_atendente")
	private Integer idAtendente;
	
	@Column(name = "id_equipe")
	private Integer idEquipe;
	
	@Column(name = "nome_equipe")
	private String nomeEquipe;
	
	@Column(name = "data")
	@Temporal(TemporalType.TIMESTAMP)
	private Date data;
	
	@Column(name = "status")
	private String status;
	
	@Column(name = "tempo_status")
	private long tempoStatus;
	
	
	public Integer getIdTempoGeralOperador() {
		return idTempoGeralOperador;
	}

	public void setIdTempoGeralOperador(Integer idTempoGeralOperador) {
		this.idTempoGeralOperador = idTempoGeralOperador;
	}

	public String getSupervisor() {
		return supervisor;
	}

	public void setSupervisor(String supervisor) {
		this.supervisor = supervisor;
	}

	public String getLoginAtendente() {
		return loginAtendente;
	}

	public void setLoginAtendente(String loginAtendente) {
		this.loginAtendente = loginAtendente;
	}

	public Integer getIdAtendente() {
		return idAtendente;
	}

	public void setIdAtendente(Integer idAtendente) {
		this.idAtendente = idAtendente;
	}

	public Integer getIdEquipe() {
		return idEquipe;
	}

	public void setIdEquipe(Integer idEquipe) {
		this.idEquipe = idEquipe;
	}

	public String getNomeEquipe() {
		return nomeEquipe;
	}

	public void setNomeEquipe(String nomeEquipe) {
		this.nomeEquipe = nomeEquipe;
	}

	public Date getData() {
		return data;
	}

	public void setData(Date data) {
		this.data = data;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public long getTempoStatus() {
		return tempoStatus;
	}

	public void setTempoStatus(long tempoStatus) {
		this.tempoStatus = tempoStatus;
	}

	@Override
	public Integer getPK() {
		return idTempoGeralOperador;
	}

	@Override
	public void setPK(Integer pk) {
		this.idTempoGeralOperador = pk;
	}
	
	
	public static String getSqlCamposRelatorioTempoGeralOperadorStatus() {
 		
     	return new StringBuilder()
 		.append(" \nRelatorioTempoGeralOperadorStatus.id_tempo_geral_operador AS 'RelatorioTempoGeralOperadorStatus.id_tempo_geral_operador',")
 		.append(" \nRelatorioTempoGeralOperadorStatus.supervisor  AS 'RelatorioTempoGeralOperadorStatus.supervisor',")
 		.append(" \nRelatorioTempoGeralOperadorStatus.login_atendente  AS 'RelatorioTempoGeralOperadorStatus.login_atendente',")
 		.append(" \nRelatorioTempoGeralOperadorStatus.data AS 'RelatorioTempoGeralOperadorStatus.data',")
 		.append(" \nRelatorioTempoGeralOperadorStatus.status  AS 'RelatorioTempoGeralOperadorStatus.status',")
 		.append(" \nRelatorioTempoGeralOperadorStatus.tempo_status  AS 'RelatorioTempoGeralOperadorStatus.tempo_status'")
 		.toString();
 	}

 	public static String getSqlFromRelatorioTempoGeralOperadorStatus() {
 		return " tb_relatorio_tempo_geral_operador_status  AS RelatorioTempoGeralOperadorStatus with(nolock) ";
 	}
 	

 	public static RelatorioTempoGeralOperadorStatus getRelatorioTempoGeralOperadorStatusByResultSet(ResultSet resultSet) {

 		RelatorioTempoGeralOperadorStatus relatorioTempoGeralOperadorStatus = new RelatorioTempoGeralOperadorStatus();

 		try {
 			
 			if(resultSet.getInt("RelatorioTempoGeralOperadorStatus.id_tempo_geral_operador") == 0) {
        		return null;
        	}
 			
 			relatorioTempoGeralOperadorStatus.setIdTempoGeralOperador(resultSet.getInt("RelatorioTempoGeralOperadorStatus.id_tempo_geral_operador"));
 			relatorioTempoGeralOperadorStatus.setSupervisor(resultSet.getString("RelatorioTempoGeralOperadorStatus.supervisor"));
 			relatorioTempoGeralOperadorStatus.setLoginAtendente(resultSet.getString("RelatorioTempoGeralOperadorStatus.login_atendente"));
 			relatorioTempoGeralOperadorStatus.setData(resultSet.getTimestamp("RelatorioTempoGeralOperadorStatus.data"));
 			relatorioTempoGeralOperadorStatus.setStatus(resultSet.getString("RelatorioTempoGeralOperadorStatus.status"));
 			relatorioTempoGeralOperadorStatus.setTempoStatus(resultSet.getLong("RelatorioTempoGeralOperadorStatus.tempo_status"));
 			
 		} catch (SQLException e) {
 			throw new IllegalArgumentException("Erro ao montar objeto a partir do ResultSet", e);
 		}
 		return relatorioTempoGeralOperadorStatus;
 	}
}
