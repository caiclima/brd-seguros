package br.com.callink.cad.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;

@Entity
@Table(name = "tb_relatorio_tempo_geral_operador_sumarizado")
public class RelatorioTempoGeralOperadorSumarizado implements IEntity<Integer> {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1124290175943413701L;
	
	@Id
	@Column(name = "id_tempo_geral_operador_sumarizado")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer idTempoGeralOperadorSumarizado;
	
	@Column(name = "data")
	@Temporal(TemporalType.TIMESTAMP)
	private Date data;

	@Column(name = "login_atendente")
	private String loginAtendente;
	
	@Column(name = "id_atendente")
	private Integer idAtendente;
	
	@Column(name = "id_equipe")
	private Integer idEquipe;
	
	@Column(name = "nome_equipe")
	private String nomeEquipe;
	
	@Column(name = "primeiro_login")
	private String primeiroLogin;
	
	@Column(name = "ultimo_login")
	private String ultimoLogin;
	
	@Column(name = "tempo_produtivo")
	private long tempoProdutivo;
	
	@Column(name = "tempo_logado")
	private long tempoLogado;
	
	@Column(name = "perc_tempo_produtivo")
	private Double percentualTempoProdutivo;
	
	@Column(name = "tempo_pausa")
	private long tempoPausa;
	
	@Column(name = "perc_tempo_pausa")
	private Double percentualTempoPausa;
	
	@Column(name = "perc_tempo_ocioso")
	private Double percentualTempoOcioso;
	
	public Integer getIdTempoGeralOperadorSumarizado() {
		return idTempoGeralOperadorSumarizado;
	}

	public void setIdTempoGeralOperadorSumarizado(Integer idTempoGeralOperadorSumarizado) {
		this.idTempoGeralOperadorSumarizado = idTempoGeralOperadorSumarizado;
	}

	public Date getData() {
		return data;
	}

	public void setData(Date data) {
		this.data = data;
	}

	public String getLoginAtendente() {
		return loginAtendente;
	}

	public void setLoginAtendente(String loginAtendente) {
		this.loginAtendente = loginAtendente;
	}

	public Integer getIdAtendente() {
		return idAtendente;
	}

	public void setIdAtendente(Integer idAtendente) {
		this.idAtendente = idAtendente;
	}

	public Integer getIdEquipe() {
		return idEquipe;
	}

	public void setIdEquipe(Integer idEquipe) {
		this.idEquipe = idEquipe;
	}

	public String getNomeEquipe() {
		return nomeEquipe;
	}

	public void setNomeEquipe(String nomeEquipe) {
		this.nomeEquipe = nomeEquipe;
	}

	public String getPrimeiroLogin() {
		return primeiroLogin;
	}

	public void setPrimeiroLogin(String primeiroLogin) {
		this.primeiroLogin = primeiroLogin;
	}

	public String getUltimoLogin() {
		return ultimoLogin;
	}

	public void setUltimoLogin(String ultimoLogin) {
		this.ultimoLogin = ultimoLogin;
	}

	public long getTempoProdutivo() {
		return tempoProdutivo;
	}

	public void setTempoProdutivo(long tempoProdutivo) {
		this.tempoProdutivo = tempoProdutivo;
	}

	public long getTempoLogado() {
		return tempoLogado;
	}

	public void setTempoLogado(long tempoLogado) {
		this.tempoLogado = tempoLogado;
	}

	public Double getPercentualTempoProdutivo() {
		return percentualTempoProdutivo;
	}

	public void setPercentualTempoProdutivo(Double percentualTempoProdutivo) {
		this.percentualTempoProdutivo = percentualTempoProdutivo;
	}

	public long getTempoPausa() {
		return tempoPausa;
	}

	public void setTempoPausa(long tempoPausa) {
		this.tempoPausa = tempoPausa;
	}

	public Double getPercentualTempoPausa() {
		return percentualTempoPausa;
	}

	public void setPercentualTempoPausa(Double percentualTempoPausa) {
		this.percentualTempoPausa = percentualTempoPausa;
	}

	public Double getPercentualTempoOcioso() {
		return percentualTempoOcioso;
	}

	public void setPercentualTempoOcioso(Double percentualTempoOcioso) {
		this.percentualTempoOcioso = percentualTempoOcioso;
	}

	@Override
	public Integer getPK() {
		return idTempoGeralOperadorSumarizado;
	}

	@Override
	public void setPK(Integer pk) {
		this.idTempoGeralOperadorSumarizado = pk;

	}
	
	public static String getSqlCamposRelatorioTempoGeralOperadorSumarizado() {
 		
     	return new StringBuilder()
 		.append(" \nRelatorioTempoGeralOperadorSumarizado.id_tempo_geral_operador_sumarizado AS 'RelatorioTempoGeralOperadorSumarizado.id_relatorio_tempo_geral_operador_sumarizado',")
 		.append(" \nRelatorioTempoGeralOperadorSumarizado.data AS 'RelatorioTempoGeralOperadorSumarizado.data',")
 		.append(" \nRelatorioTempoGeralOperadorSumarizado.login_atendente AS 'RelatorioTempoGeralOperadorSumarizado.login_atendente',")
 		.append(" \nRelatorioTempoGeralOperadorSumarizado.id_atendente AS 'RelatorioTempoGeralOperadorSumarizado.id_atendente',")
 		.append(" \nRelatorioTempoGeralOperadorSumarizado.id_equipe AS 'RelatorioTempoGeralOperadorSumarizado.id_equipe',")
 		.append(" \nRelatorioTempoGeralOperadorSumarizado.nome_equipe AS 'RelatorioTempoGeralOperadorSumarizado.nome_equipe',")
 		.append(" \nRelatorioTempoGeralOperadorSumarizado.primeiro_login AS 'RelatorioTempoGeralOperadorSumarizado.primeiro_login',")
 		.append(" \nRelatorioTempoGeralOperadorSumarizado.ultimo_login AS 'RelatorioTempoGeralOperadorSumarizado.ultimo_login',")
 		.append(" \nRelatorioTempoGeralOperadorSumarizado.tempo_produtivo AS 'RelatorioTempoGeralOperadorSumarizado.tempo_produtivo',")
 		.append(" \nRelatorioTempoGeralOperadorSumarizado.tempo_logado AS 'RelatorioTempoGeralOperadorSumarizado.tempo_logado',")
 		.append(" \nRelatorioTempoGeralOperadorSumarizado.perc_tempo_produtivo AS 'RelatorioTempoGeralOperadorSumarizado.perc_tempo_produtivo',")
 		.append(" \nRelatorioTempoGeralOperadorSumarizado.tempo_pausa AS 'RelatorioTempoGeralOperadorSumarizado.tempo_pausa',")
 		.append(" \nRelatorioTempoGeralOperadorSumarizado.perc_tempo_pausa AS 'RelatorioTempoGeralOperadorSumarizado.perc_tempo_pausa',")
 		.append(" \nRelatorioTempoGeralOperadorSumarizado.perc_tempo_ociosos AS 'RelatorioTempoGeralOperadorSumarizado.perc_tempo_ociosos'")
 		
 		.toString();
 	}
	

	
 	public static String getSqlFromRelatorioTempoGeralOperadorSumarizado() {
 		return " tb_relatorio_tempo_geral_operador_sumarizado  AS RelatorioTempoGeralOperadorSumarizado with(nolock) ";
 	}

 	public static RelatorioTempoGeralOperadorSumarizado getRelatorioTempoGeralOperadorSumarizadoByResultSet(ResultSet resultSet) {

 		RelatorioTempoGeralOperadorSumarizado relatorioTempoGeralOperadorSumarizado = new RelatorioTempoGeralOperadorSumarizado();

 		try {
 			
 			if(resultSet.getInt("RelatorioTempoGeralOperadorSumarizado.id_relatorio_tempo_geral_operador_sumarizado") == 0) {
        		return null;
        	}
 			
 			relatorioTempoGeralOperadorSumarizado.setIdTempoGeralOperadorSumarizado(resultSet.getInt("RelatorioTempoGeralOperadorSumarizado.id_relatorio_tempo_geral_operador_sumarizado"));
 			relatorioTempoGeralOperadorSumarizado.setIdAtendente(resultSet.getInt("RelatorioTempoGeralOperadorSumarizado.id_atendente"));
 			relatorioTempoGeralOperadorSumarizado.setIdEquipe(resultSet.getInt("RelatorioTempoGeralOperadorSumarizado.id_equipe"));
 			relatorioTempoGeralOperadorSumarizado.setData(resultSet.getTimestamp("RelatorioTempoGeralOperadorSumarizado.data"));
 			relatorioTempoGeralOperadorSumarizado.setLoginAtendente(resultSet.getString("RelatorioTempoGeralOperadorSumarizado.login_atendente"));
 			relatorioTempoGeralOperadorSumarizado.setNomeEquipe(resultSet.getString("RelatorioTempoGeralOperadorSumarizado.nome_equipe"));
 			relatorioTempoGeralOperadorSumarizado.setPercentualTempoOcioso(resultSet.getDouble("RelatorioTempoGeralOperadorSumarizado.perc_tempo_ociosos"));
 			relatorioTempoGeralOperadorSumarizado.setPercentualTempoPausa(resultSet.getDouble("RelatorioTempoGeralOperadorSumarizado.perc_tempo_pausa"));
 			relatorioTempoGeralOperadorSumarizado.setPercentualTempoProdutivo(resultSet.getDouble("RelatorioTempoGeralOperadorSumarizado.perc_tempo_produtivo"));
 			relatorioTempoGeralOperadorSumarizado.setPrimeiroLogin(resultSet.getString("RelatorioTempoGeralOperadorSumarizado.primeiro_login"));
 			relatorioTempoGeralOperadorSumarizado.setUltimoLogin(resultSet.getString("RelatorioTempoGeralOperadorSumarizado.ultimo_login"));
 			relatorioTempoGeralOperadorSumarizado.setTempoLogado(resultSet.getLong("RelatorioTempoGeralOperadorSumarizado.tempo_logado"));
 			relatorioTempoGeralOperadorSumarizado.setTempoPausa(resultSet.getLong("RelatorioTempoGeralOperadorSumarizado.tempo_pausa"));
 			relatorioTempoGeralOperadorSumarizado.setTempoProdutivo(resultSet.getLong("RelatorioTempoGeralOperadorSumarizado.tempo_produtivo"));
 			
 		} catch (SQLException e) {
 			throw new IllegalArgumentException("Erro ao montar objeto a partir do ResultSet", e);
 		}
 		return relatorioTempoGeralOperadorSumarizado;
 	}
 	
}
