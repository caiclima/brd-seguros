package br.com.callink.cad.pojo;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;

/**
 *
 * @author brunomt
 */
@Entity
@Table(name = "TB_RELATORIO_TEMPOS_OPERACIONAIS")
public class RelatorioTempoOperacional implements IEntity<Integer> {
    
	private static final long serialVersionUID = 1786516894680372266L;

	@Id
	@Column(name = "id_relatorio_tempos_operacionais")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idRelatorioTemposOperacionais;

    @Column(name = "login" , length = 100)
    private String login;

    @Column(name = "data_inicio")
	@Temporal(TemporalType.TIMESTAMP)
    private Date dataInicio;

    @Column(name = "data_fim")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataFim;

    @Column(name = "status_atendente" , length=100)
    private String statusAtendente;

    @Column(name = "nome_atendente" , length=150)
    private String nomeAtendente;

    @Column(name = "id_equipe")
    private Integer idEquipe;    
    
    public Date getDataFim() {
        return dataFim == null ? null : new Date(dataFim.getTime());
    }

    public void setDataFim(Date dataFim) {
        this.dataFim = dataFim == null ? null : new Date(dataFim.getTime());
    }

    public Date getDataInicio() {
        return dataInicio == null ? null : new Date(dataInicio.getTime());
    }

    public void setDataInicio(Date dataInicio) {
        this.dataInicio = dataInicio == null ? null : new Date(dataInicio.getTime());
    }

    public Integer getIdRelatorioTemposOperacionais() {
        return idRelatorioTemposOperacionais;
    }

    public void setIdRelatorioTemposOperacionais(Integer idRelatorioTemposOperacionais) {
        this.idRelatorioTemposOperacionais = idRelatorioTemposOperacionais;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getNomeAtendente() {
        return nomeAtendente;
    }

    public void setNomeAtendente(String nomeAtendente) {
        this.nomeAtendente = nomeAtendente;
    }

    public String getStatusAtendente() {
        return statusAtendente;
    }

    public void setStatusAtendente(String statusAtendente) {
        this.statusAtendente = statusAtendente;
    }

    public Integer getIdEquipe() {
        return idEquipe;
    }

    public void setIdEquipe(Integer idEquipe) {
        this.idEquipe = idEquipe;
    }

    public Integer getPK() {
        return this.idRelatorioTemposOperacionais;
    }

    public void setPK(Integer t) {
        this.idRelatorioTemposOperacionais = t;
    }
    
	public static String getSqlCamposRelatorioTempoOperacional() {
 		
     	return new StringBuilder()
 		.append(" \nRelatorioTemposOperacionais.id_relatorio_tempos_operacionais AS 'RelatorioTemposOperacionais.id_relatorio_tempos_operacionais',")
 		.append(" \nRelatorioTemposOperacionais.login AS 'RelatorioTemposOperacionais.login',")
 		.append(" \nRelatorioTemposOperacionais.data_inicio AS 'RelatorioTemposOperacionais.data_inicio',")
 		.append(" \nRelatorioTemposOperacionais.data_fim AS 'RelatorioTemposOperacionais.data_fim',")
 		.append(" \nRelatorioTemposOperacionais.status_atendente AS 'RelatorioTemposOperacionais.status_atendente',")
 		.append(" \nRelatorioTemposOperacionais.nome_atendente AS 'RelatorioTemposOperacionais.nome_atendente',")
                .append(" \nRelatorioTemposOperacionais.id_equipe AS 'RelatorioTemposOperacionais.id_equipe'")
 		.toString();
 	}

 	public static String getSqlFromRelatorioTempoOperacional() {
 		return " TB_RELATORIO_TEMPOS_OPERACIONAIS  AS RelatorioTemposOperacionais with(nolock) ";
 	}

 	public static RelatorioTempoOperacional getRelatorioTempoOperacionalByResultSet(ResultSet resultSet) {

 		RelatorioTempoOperacional relatorioTempoOperacional = new RelatorioTempoOperacional();

 		try {
 			
 			if(resultSet.getInt("RelatorioTemposOperacionais.id_relatorio_tempos_operacionais") == 0) {
        		return null;
        	}
 			
 			relatorioTempoOperacional.setIdRelatorioTemposOperacionais(resultSet.getInt("RelatorioTemposOperacionais.id_relatorio_tempos_operacionais"));
 			relatorioTempoOperacional.setLogin(resultSet.getString("RelatorioTemposOperacionais.login"));
 			relatorioTempoOperacional.setDataInicio(resultSet.getTimestamp("RelatorioTemposOperacionais.data_inicio"));
 			relatorioTempoOperacional.setDataFim(resultSet.getTimestamp("RelatorioTemposOperacionais.data_fim"));
 			relatorioTempoOperacional.setStatusAtendente(resultSet.getString("RelatorioTemposOperacionais.status_atendente"));
 			relatorioTempoOperacional.setNomeAtendente(resultSet.getString("RelatorioTemposOperacionais.nome_atendente"));
                        relatorioTempoOperacional.setIdEquipe(resultSet.getInt("RelatorioTemposOperacionais.id_equipe"));
 			
 		} catch (SQLException e) {
 			throw new IllegalArgumentException("Erro ao montar objeto a partir do ResultSet", e);
 		}
 		return relatorioTempoOperacional;
 	}
    
}
