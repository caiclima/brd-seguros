/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.pojo;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;

/**
 *
 * @author miller(miller@swb.com.br)
 * @since 26/06/2012
 */
@Entity
@Table(name = "TB_SLA_FILA")
public class SlaFila implements IEntity<Integer> {
    
	private static final long serialVersionUID = -1955627723783502144L;

	@Id
	@Column(name = "ID_SLA_FILA")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idSlaFila;
    
    @Column(name = "DATA_INICIO")
	@Temporal(TemporalType.TIMESTAMP)
    private Date dataInicial;
    
    @Column(name = "DATA_FIM")
	@Temporal(TemporalType.TIMESTAMP)
    private Date dataFinal;
    
    @Column(name = "SLA" , nullable = false)
    private Integer sla ;
    
    @Column(name = "DESCRICAO", length = 50)
    private String descricao;
    
    @ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_CONFIGURACAO_FILA", referencedColumnName = "ID_CONFIGURACAO_FILA" , nullable = false)
    private ConfiguracaoFila configuracaoFila;
    
    @Column(name = "FLAG_INICIA_SLA")
    private Boolean flagIniciaSLA;
    
    public SlaFila() {
		flagIniciaSLA = Boolean.FALSE;
	}

    public SlaFila(Integer idSlaFila) {
		this.idSlaFila = idSlaFila;
	}
    
    public final Integer getPK() {
        return idSlaFila;
    }
    
    public final void setPK(Integer id) {
        this.idSlaFila = id;
    }
    
      public final Date getDataFinal() {
        return  dataFinal!= null ? new Date(dataFinal.getTime()) : null;
    }

    public final void setDataFinal(Date dataFinal) {
        this.dataFinal = dataFinal!= null ? new Date(dataFinal.getTime()) : null;
    }

    public final Date getDataInicial() {
        return dataInicial!= null ? new Date(dataInicial.getTime()) : null;
    }

    public final void setDataInicial(Date dataInicial) {
        this.dataInicial = dataInicial!= null ? new Date(dataInicial.getTime()) : null;
    }

    public final String getDescricao() {
        return descricao;
    }

    public final void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public final ConfiguracaoFila getConfiguracaoFila() {
        return configuracaoFila;
    }

    public final void setConfiguracaoFila(ConfiguracaoFila configuracaoFila) {
        this.configuracaoFila = configuracaoFila;
    }

    public final Integer getIdSlaFila() {
        return idSlaFila;
    }

    public final void setIdSlaFila(Integer idSlaFila) {
        this.idSlaFila = idSlaFila;
    }

    public final Integer getSla() {
        return sla;
    }

    public final void setSla(Integer sla) {
        this.sla = sla;
    }

    public Boolean getFlagIniciaSLA() {
		return flagIniciaSLA;
	}

	public void setFlagIniciaSLA(Boolean flagIniciaSLA) {
		this.flagIniciaSLA = flagIniciaSLA;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((idSlaFila == null) ? 0 : idSlaFila.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof SlaFila)) {
			return false;
		}
		SlaFila other = (SlaFila) obj;
		if (idSlaFila == null) {
			if (other.idSlaFila != null) {
				return false;
			}
		} else if (!idSlaFila.equals(other.idSlaFila)) {
			return false;
		}
		return true;
	}

	/**
     * Retorna campos da base de dados do sla fila
     * 
     * @return sqlCampos
     */
    public static String getSqlCamposSlaFila() {
		return new StringBuilder()
				.append(" \nSlaFila.ID_SLA_FILA AS 'SlaFila.ID_SLA_FILA',")
				.append(" \nSlaFila.DATA_INICIO AS 'SlaFila.DATA_INICIO',")
				.append(" \nSlaFila.DATA_FIM AS 'SlaFila.DATA_FIM',")
				.append(" \nSlaFila.SLA AS 'SlaFila.SLA',")
				.append(" \nSlaFila.DESCRICAO AS 'SlaFila.DESCRICAO',")
				.append(" \nSlaFila.ID_CONFIGURACAO_FILA AS 'SlaFila.ID_CONFIGURACAO_FILA', ")
				.append(" \nSlaFila.FLAG_INICIA_SLA AS 'SlaFila.FLAG_INICIA_SLA' ")
				.toString();
	}
    
    public static String getSqlFromSlaFila() {
		return " TB_SLA_FILA  AS SlaFila with(nolock) ";
	}

    public static SlaFila getSlaFilaByResultSet(ResultSet resultSet) {

    	SlaFila slaFila = new SlaFila();

 		try {
 			
 			if(resultSet.getInt("SlaFila.ID_SLA_FILA") == 0) {
        		return null;
        	}
 			
 			slaFila.setIdSlaFila(resultSet.getInt("SlaFila.ID_SLA_FILA"));
 			slaFila.setDataInicial(resultSet.getTimestamp("SlaFila.DATA_INICIO"));
 			slaFila.setDataFinal(resultSet.getTimestamp("SlaFila.DATA_FIM"));
 			slaFila.setSla(resultSet.getInt("SlaFila.SLA"));
 			slaFila.setDescricao(resultSet.getString("SlaFila.DESCRICAO"));
 			slaFila.setConfiguracaoFila(resultSet.getInt("SlaFila.ID_CONFIGURACAO_FILA") == 0 ? null : new ConfiguracaoFila(resultSet.getInt("SlaFila.ID_CONFIGURACAO_FILA")));
 			slaFila.setFlagIniciaSLA(resultSet.getBoolean("SlaFila.FLAG_INICIA_SLA"));
 			
 		} catch (SQLException e) {
 			throw new IllegalArgumentException("Erro ao montar objeto a partir do ResultSet", e);
 		}
 		return slaFila;
 	}
    
    
    @Override
    public final String toString() {
        return "SlaFila{" + "descricao=" + descricao + '}';
    }
    
}
