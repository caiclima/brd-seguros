package br.com.callink.cad.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;


/**
 * 
 * @author Ednaldo Caic [ednaldo@swb.com.br]
 * @since 22/12/2011
 */

@Entity
@Table(name = "TB_STATUS")
public class Status implements IEntity<Integer> {

	private static final long serialVersionUID = 6373565689108400446L;

	@Id
	@Column(name = "ID_STATUS")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer idStatus;

	@Column(name = "NOME" , length = 200)
	private String nome;

	@Column(name = "DATA_CRIACAO")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataCriacao;

	@Column(name = "DESCRICAO" , length = 2000)
	private String descricao;

	@Column(name = "FLAG_ATIVO")
	private Boolean flagAtivo;

	@Column(name = "FLAG_CONTA_SLA")
	private Boolean flagContaSla;

	@Column(name = "LOGIN_USUARIO" , length = 50)
	private String loginUsuario;

	@Column(name = "FLAG_PAUSADO")
	private Boolean flagPausado;
	
	@Column(name= "FLAG_MOSTRA_REGUA_CASOS_ABERTOS")
	private Boolean flagMostraRegua;
	
	private transient Boolean selecionado;

	public Status() {

	}

	public Status(Integer idStatus) {
		this.idStatus = idStatus;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((idStatus == null) ? 0 : idStatus.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof Status)) {
			return false;
		}
		Status other = (Status) obj;
		if (idStatus == null) {
			if (other.idStatus != null) {
				return false;
			}
		} else if (!idStatus.equals(other.idStatus)) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return this.nome;
	}

	public final Integer getIdStatus() {
		return idStatus;
	}

	public final void setIdStatus(Integer idStatus) {
		this.idStatus = idStatus;
	}

	public final String getNome() {
		return nome;
	}

	public final void setNome(String nome) {
		this.nome = nome;
	}

	public final Date getDataCriacao() {
		return dataCriacao != null ? new Date(dataCriacao.getTime()) : null;
	}

	public final void setDataCriacao(Date dataCriacao) {
		this.dataCriacao = dataCriacao != null ? new Date(dataCriacao.getTime())
				: null;
	}

	public Integer getPK() {
		return idStatus;
	}

	public void setPK(Integer pk) {
		this.idStatus = pk;
	}

	public final String getDescricao() {
		return descricao;
	}

	public final void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public final Boolean getFlagAtivo() {
		return flagAtivo;
	}

	public final void setFlagAtivo(Boolean flagAtivo) {
		this.flagAtivo = flagAtivo;
	}

	public void setFlagContaSla(Boolean flagContaSla) {
		this.flagContaSla = flagContaSla;
	}

	public Boolean getFlagContaSla() {
		return flagContaSla;
	}

	public final String getLoginUsuario() {
		return loginUsuario;
	}

	public final void setLoginUsuario(String loginUsuario) {
		this.loginUsuario = loginUsuario;
	}

	public final Boolean getFlagPausado() {
		return flagPausado;
	}

	public final void setFlagPausado(Boolean flagPausado) {
		this.flagPausado = flagPausado;
	}

	public static String getSqlCamposStatus() {

		return new StringBuilder()
				.append(" \nStatus.ID_STATUS AS 'Status.ID_STATUS',")
				.append(" \nStatus.NOME AS 'Status.NOME',")
				.append(" \nStatus.DATA_CRIACAO AS 'Status.DATA_CRIACAO',")
				.append(" \nStatus.DESCRICAO AS 'Status.DESCRICAO',")
				.append(" \nStatus.FLAG_ATIVO AS 'Status.FLAG_ATIVO',")
				.append(" \nStatus.FLAG_CONTA_SLA AS 'Status.FLAG_CONTA_SLA',")
				.append(" \nStatus.LOGIN_USUARIO AS 'Status.LOGIN_USUARIO', ")
				.append(" \nStatus.FLAG_PAUSADO AS 'Status.FLAG_PAUSADO', ")
				.append(" \nStatus.FLAG_MOSTRA_REGUA_CASOS_ABERTOS AS 'Status.FLAG_MOSTRA_REGUA_CASOS_ABERTOS' ")
				.toString();
	}

	public static String getSqlFromStatus() {
		return " TB_STATUS  AS Status with(nolock) ";
	}

	public static Status getStatusByResultSet(ResultSet resultSet) {

		try {
			
			if(resultSet.getInt("Status.ID_STATUS") == 0) {
        		return null;
        	}
			
			Status status = new Status();
			status.setIdStatus(resultSet.getInt("Status.ID_STATUS"));
			status.setNome(resultSet.getString("Status.NOME"));
			status.setDataCriacao(resultSet.getTimestamp("Status.DATA_CRIACAO"));
			status.setDescricao(resultSet.getString("Status.DESCRICAO"));
			status.setFlagAtivo(resultSet.getBoolean("Status.FLAG_ATIVO"));
			status.setFlagContaSla(resultSet.getBoolean("Status.FLAG_CONTA_SLA"));
			status.setLoginUsuario(resultSet.getString("Status.LOGIN_USUARIO"));
			status.setFlagPausado(resultSet.getBoolean("Status.FLAG_PAUSADO"));
			status.setFlagMostraRegua(resultSet.getBoolean("Status.FLAG_MOSTRA_REGUA_CASOS_ABERTOS"));

			return status;
		} catch (SQLException e) {
			throw new IllegalArgumentException(
					"Erro ao montar objeto a partir do ResultSet", e);
		}
	}

	public final Boolean getSelecionado() {
		return selecionado;
	}

	public final void setSelecionado(Boolean selecionado) {
		this.selecionado = selecionado;
	}

	public Boolean getFlagMostraRegua() {
		return flagMostraRegua;
	}

	public void setFlagMostraRegua(Boolean flagMostraRegua) {
		this.flagMostraRegua = flagMostraRegua;
	}
	
}
