package br.com.callink.cad.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import br.com.callink.cad.pojo.entity.IEntity;

/**
 * 
 * @author Rogério Moreira de Andrade
 * @since 22/12/2011
 */
@Entity
@Table(name = "TB_STATUS_ACAO")
public class StatusAcao implements IEntity<Integer> {

	private static final long serialVersionUID = -6960470973769580676L;

	@EmbeddedId
	private StatusAcaoId statusAcaoId;
	
	public StatusAcao() {
	}
	
	public StatusAcaoId getStatusAcaoId() {
		if (statusAcaoId == null) {
			statusAcaoId = new StatusAcaoId();
		}
		return statusAcaoId;
	}

	public void setStatusAcaoId(StatusAcaoId statusAcaoId) {
		this.statusAcaoId = statusAcaoId;
	}
	
	public Integer getPK() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void setPK(Integer t) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

	public static String getSqlCamposStatusAcao() {
 		
     	return new StringBuilder()
 		.append(" \nStatusAcao.ID_STATUS AS 'StatusAcao.ID_STATUS',")
 		.append(" \nStatusAcao.ID_ACAO AS 'StatusAcao.ID_ACAO'")
 		.toString();
 	}

 	public static String getSqlFromStatusAcao() {
 		return " TB_STATUS_ACAO  AS StatusAcao with(nolock) ";
 	}

 	public static StatusAcao getStatusAcaoByResultSet(ResultSet resultSet) {
 		StatusAcao statusAcao = new StatusAcao();
 		statusAcao.setStatusAcaoId(new StatusAcaoId());
 		try {
 			
 			if(resultSet.getInt("StatusAcao.ID_ACAO") == 0) {
        		return null;
        	}
 			
 			statusAcao.getStatusAcaoId().setIdAcao(resultSet.getInt("StatusAcao.ID_ACAO") == 0 ? null : new Acao(resultSet.getInt("StatusAcao.ID_ACAO")));
 			statusAcao.getStatusAcaoId().setIdStatus(resultSet.getInt("StatusAcao.ID_STATUS") == 0 ? null : new Status(resultSet.getInt("StatusAcao.ID_STATUS")));
 		} catch (SQLException e) {
 			throw new IllegalArgumentException("Erro ao montar objeto a partir do ResultSet", e);
 		}
 		return statusAcao;
 	}
 	
 	
 	@Override
	public String toString() {
		if (statusAcaoId != null && statusAcaoId.getIdAcao() != null) {
			return statusAcaoId.getIdAcao().getNome();
		} else {
			return "";
		}
	}

}
