package br.com.callink.cad.pojo;

import javax.persistence.Embeddable;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import br.com.callink.cad.pojo.entity.IEntity;

@Embeddable
public class StatusAcaoId implements IEntity<Integer> {

	private static final long serialVersionUID = 1L;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_STATUS", referencedColumnName = "ID_STATUS" , nullable = false)
	private Status idStatus;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_ACAO", referencedColumnName = "ID_ACAO", nullable = false)
	private Acao idAcao;
	
	public StatusAcaoId() {
	}
	
	public StatusAcaoId(Status status, Acao acao) {
		this.idStatus = status;
		this.idAcao = acao;
	}
	
	public Acao getIdAcao() {
		return idAcao;
	}

	public void setIdAcao(Acao acao) {
		this.idAcao = acao;
	}

	public Status getIdStatus() {
		return idStatus;
	}

	public void setIdStatus(Status status) {
		this.idStatus = status;
	}
	
	public Integer getPK() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void setPK(Integer t) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
	
	@Override
	public String toString() {
		if (idAcao != null) {
			return idAcao.getNome();
		} else {
			return "";
		}
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((idAcao == null) ? 0 : idAcao.hashCode());
		result = prime * result
				+ ((idStatus == null) ? 0 : idStatus.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj){
			return true;
		}
		if (obj == null){
			return false;
		}
		if (getClass() != obj.getClass()){
			return false;
		}
		StatusAcaoId other = (StatusAcaoId) obj;
		if (idAcao == null) {
			if (other.idAcao != null){
				return false;
			}
		} else if (!idAcao.equals(other.idAcao)){
			return false;
		}
		if (idStatus == null) {
			if (other.idStatus != null){
				return false;
			}
		} else if (!idStatus.equals(other.idStatus)){
			return false;
		}
		return true;
	}
	
}
