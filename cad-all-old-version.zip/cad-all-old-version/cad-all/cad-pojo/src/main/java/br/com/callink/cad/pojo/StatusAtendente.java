package br.com.callink.cad.pojo;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;
import br.com.callink.cad.repository.to.MetaFilaTO;

/**
 *
 * @author brunomt
 */
@Entity
@Table(name = "TB_STATUS_ATENDENTE")
public class StatusAtendente implements IEntity<Integer> {
   
	private static final long serialVersionUID = -6290944625823782538L;

	@Id
	@Column(name = "ID_STATUS_ATENDENTE")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idStatusAtendente;
    
    @ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_EQUIPE", referencedColumnName = "ID_EQUIPE", nullable = false)
    private Equipe idEquipe;
    
    @ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_CONFIGURACAO_FILA", referencedColumnName = "ID_CONFIGURACAO_FILA")
    private ConfiguracaoFila idConfiguracaoFila;
    
    @ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_ATENDENTE", referencedColumnName = "ID_ATENDENTE" , nullable = false)
    private Atendente idAtendente;
    
    @ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_CASO", referencedColumnName = "ID_CASO")
    private Caso idCaso;
    
    @ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_ATENDENTE_STATUS", referencedColumnName = "ID_ATENDENTE_STATUS", nullable = false)
    private AtendenteStatus idAtendenteStatus;
    
    @Column(name = "DATA_INICIO")
	@Temporal(TemporalType.TIMESTAMP)
    private Date dataInicio;
    
    @Column(name = "DATA_FIM")
	@Temporal(TemporalType.TIMESTAMP)
    private Date dataFim;
    
    private transient boolean uphFora;
    private transient Double uph;
    
    private transient Date dataBanco;
    private transient boolean flagInicio;
    
    private transient String goal;
    private transient List<MetaFilaTO> metasUph;
    
    private transient Long tempoDecorrigoLong;
    
    private transient String tempoDecorrido;

    public Date getDataFim() {
        return dataFim == null ? null : new Date(dataFim.getTime());
    }

    public void setDataFim(Date dataFim) {
        this.dataFim = dataFim == null ? null : new Date(dataFim.getTime());
    }

    public Date getDataInicio() {
        return dataInicio == null ? null : new Date(dataInicio.getTime());
    }

    public void setDataInicio(Date dataInicio) {
        this.dataInicio = dataInicio == null ? null : new Date(dataInicio.getTime());
    }

    public Atendente getIdAtendente() {
        return idAtendente;
    }

    public void setIdAtendente(Atendente idAtendente) {
        this.idAtendente = idAtendente;
    }

    public AtendenteStatus getIdAtendenteStatus() {
        return idAtendenteStatus;
    }

    public void setIdAtendenteStatus(AtendenteStatus idAtendenteStatus) {
        this.idAtendenteStatus = idAtendenteStatus;
    }

    public Caso getIdCaso() {
        return idCaso;
    }

    public void setIdCaso(Caso idCaso) {
        this.idCaso = idCaso;
    }

    public ConfiguracaoFila getIdConfiguracaoFila() {
        return idConfiguracaoFila;
    }

    public void setIdConfiguracaoFila(ConfiguracaoFila idConfiguracaoFila) {
        this.idConfiguracaoFila = idConfiguracaoFila;
    }

    public Equipe getIdEquipe() {
        return idEquipe;
    }

    public void setIdEquipe(Equipe idEquipe) {
        this.idEquipe = idEquipe;
    }

    public Integer getIdStatusAtendente() {
        return idStatusAtendente;
    }

    public void setIdStatusAtendente(Integer idStatusAtendente) {
        this.idStatusAtendente = idStatusAtendente;
    }

    public Date getDataBanco() {
        return dataBanco == null ? null : new Date(dataBanco.getTime());
    }

    public void setDataBanco(Date dataBanco) {
        this.dataBanco = dataBanco == null ? null : new Date(dataBanco.getTime());
    }

    public String getTempoDecorrido() {
        return tempoDecorrido;
    }

    public void setTempoDecorrido(String tempoDecorrido) {
        this.tempoDecorrido = tempoDecorrido;
    }

    @Override
    public String toString() {
        return "StatusAtendente{" + "idStatusAtendente=" + idStatusAtendente + ", dataInicio=" + dataInicio + ", dataFim=" + dataFim + '}';
    }
    
    
    @Override
    public int hashCode() {
            final int prime = 31;
            int result = 1;
            result = prime * result
                            + ((idStatusAtendente == null) ? 0 : idStatusAtendente.hashCode());
            return result;
    }

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof StatusAtendente)) {
			return false;
		}
		StatusAtendente other = (StatusAtendente) obj;
		if (idStatusAtendente == null) {
			if (other.idStatusAtendente != null) {
				return false;
			}
		} else if (!idStatusAtendente.equals(other.idStatusAtendente)) {
			return false;
		}
		return true;
	}

    public Integer getPK() {
        return idStatusAtendente;
    }

    public void setPK(Integer pk) {
        this.idStatusAtendente = pk;
    }

    public boolean isFlagInicio() {
        return flagInicio;
    }

    public void setFlagInicio(boolean flagInicio) {
        this.flagInicio = flagInicio;
    }
    
    public Double getUph() {
        return uph;
    }

    public void setUph(Double uph) {
        this.uph = uph;
    }

    public boolean isUphFora() {
        return uphFora;
    }

    public void setUphFora(boolean uphFora) {
        this.uphFora = uphFora;
    }

	public String getGoal() {
		return goal;
	}

	public void setGoal(String goal) {
		this.goal = goal;
	}

	public List<MetaFilaTO> getMetasUph() {
		return metasUph;
	}

	public void setMetasUph(List<MetaFilaTO> metasUph) {
		this.metasUph = metasUph;
	}

	public Long getTempoDecorrigoLong() {
		return tempoDecorrigoLong;
	}

	public void setTempoDecorrigoLong(Long tempoDecorrigoLong) {
		this.tempoDecorrigoLong = tempoDecorrigoLong;
	}
	
	public static String getSqlCamposStatusAtendente() {
 		
     	return new StringBuilder()
 		.append(" \nStatusAtendente.ID_STATUS_ATENDENTE AS 'StatusAtendente.ID_STATUS_ATENDENTE',")
 		.append(" \nStatusAtendente.ID_EQUIPE AS 'StatusAtendente.ID_EQUIPE',")
 		.append(" \nStatusAtendente.ID_CONFIGURACAO_FILA AS 'StatusAtendente.ID_CONFIGURACAO_FILA',")
 		.append(" \nStatusAtendente.ID_ATENDENTE AS 'StatusAtendente.ID_ATENDENTE',")
 		.append(" \nStatusAtendente.ID_CASO AS 'StatusAtendente.ID_CASO',")
 		.append(" \nStatusAtendente.ID_ATENDENTE_STATUS AS 'StatusAtendente.ID_ATENDENTE_STATUS',")
 		.append(" \nStatusAtendente.DATA_INICIO AS 'StatusAtendente.DATA_INICIO',")
		.append(" \nStatusAtendente.DATA_FIM AS 'StatusAtendente.DATA_FIM'").toString();
 	}

 	public static String getSqlFromStatusAtendente() {
 		return " TB_STATUS_ATENDENTE  AS StatusAtendente with(nolock) ";
 	}

 	public static StatusAtendente getStatusAtendenteByResultSet(ResultSet resultSet) {

 		StatusAtendente statusAtendente = new StatusAtendente();

 		try {
 			
 			if(resultSet.getInt("StatusAtendente.ID_STATUS_ATENDENTE") == 0) {
        		return null;
        	}
 			
 			statusAtendente.setIdStatusAtendente(resultSet.getInt("StatusAtendente.ID_STATUS_ATENDENTE"));
 			statusAtendente.setIdEquipe(resultSet.getInt("StatusAtendente.ID_EQUIPE") == 0 ? null : new Equipe(resultSet.getInt("StatusAtendente.ID_EQUIPE")));
 			statusAtendente.setIdConfiguracaoFila(resultSet.getInt("StatusAtendente.ID_CONFIGURACAO_FILA") == 0 ? null : new ConfiguracaoFila(resultSet.getInt("StatusAtendente.ID_CONFIGURACAO_FILA")));
 			statusAtendente.setIdAtendente(resultSet.getInt("StatusAtendente.ID_ATENDENTE") == 0 ? null : new Atendente(resultSet.getInt("StatusAtendente.ID_ATENDENTE")));
 			statusAtendente.setIdCaso(resultSet.getInt("StatusAtendente.ID_CASO") == 0 ? null : new Caso(resultSet.getInt("StatusAtendente.ID_CASO")));
 			statusAtendente.setIdAtendenteStatus(resultSet.getInt("StatusAtendente.ID_ATENDENTE_STATUS") == 0 ? null : new AtendenteStatus(resultSet.getInt("StatusAtendente.ID_ATENDENTE_STATUS")));
 			statusAtendente.setDataInicio(resultSet.getTimestamp("StatusAtendente.DATA_INICIO"));
 			statusAtendente.setDataFim(resultSet.getTimestamp("StatusAtendente.DATA_FIM"));
 		} catch (SQLException e) {
 			throw new IllegalArgumentException("Erro ao montar objeto a partir do ResultSet", e);
 		}
 		return statusAtendente;
 	}
	
	
}
