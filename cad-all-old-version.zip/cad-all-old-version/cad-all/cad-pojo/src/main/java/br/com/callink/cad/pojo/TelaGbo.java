package br.com.callink.cad.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import br.com.callink.cad.pojo.entity.IEntity;



/**
*
* @author Ednaldo Caic [ednaldo@swb.com.br]
* @since 03/01/2012
*/

@Entity
@Table(name = "TB_TELA_GBO")
public class TelaGbo implements IEntity<Integer>{

	private static final long serialVersionUID = 6893937945739307404L;

	@Id
	@Column(name = "ID_TELA_GBO")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer idTelaGbo;

	@Column(name = "NOME_TELA" , length = 200)
	private String nomeTela;

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((idTelaGbo == null) ? 0 : idTelaGbo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof TelaGbo)) {
			return false;
		}
		TelaGbo other = (TelaGbo) obj;
		if (idTelaGbo == null) {
			if (other.idTelaGbo != null) {
				return false;
			}
		} else if (!idTelaGbo.equals(other.idTelaGbo)) {
			return false;
		}
		return true;
	}

	public TelaGbo(Integer idTelaGbo) {
		this.idTelaGbo = idTelaGbo;
	}
	
	public TelaGbo(){
		
	}
	
	public Integer getPK() {
		return idTelaGbo;
	}

	public void setPK(Integer pk) {
		this.idTelaGbo = pk;
	}

	public final Integer getIdTelaGbo() {
		return idTelaGbo;
	}

	public final void setIdTelaGbo(Integer idTelaGbo) {
		this.idTelaGbo = idTelaGbo;
	}

	public final String getNomeTela() {
		return nomeTela;
	}

	public final void setNomeTela(String nomeTela) {
		this.nomeTela = nomeTela;
	}
	
	public static String getSqlCamposTelaGbo() {
 		
     	return new StringBuilder()
 		.append(" \nTelaGbo.ID_TELA_GBO AS 'TelaGbo.ID_TELA_GBO',")
		.append(" \nTelaGbo.NOME_TELA AS 'TelaGbo.NOME_TELA'").toString();
 	}

 	public static String getSqlFromTelaGbo() {
 		return " TB_TELA_GBO  AS TelaGbo with(nolock) ";
 	}

 	public static TelaGbo getTelaGboByResultSet(ResultSet resultSet) {

 		TelaGbo telaGbo = new TelaGbo();

 		try {
 			
 			if(resultSet.getInt("TelaGbo.ID_TELA_GBO") == 0) {
        		return null;
        	}
 			
 			telaGbo.setIdTelaGbo(resultSet.getInt("TelaGbo.ID_TELA_GBO"));
 			telaGbo.setNomeTela(resultSet.getString("TelaGbo.NOME_TELA"));
 		} catch (SQLException e) {
 			throw new IllegalArgumentException("Erro ao montar objeto a partir do ResultSet", e);
 		}
 		return telaGbo;
 	}
	
	
}
