package br.com.callink.cad.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import br.com.callink.cad.pojo.entity.IEntity;


/**
 *
 * @author Rogerio Moreira [rogeriom@swb.com.br]
 * @since 27/12/2011
 */
@Entity
@Table(name = "TB_TELEFONE")
public class Telefone implements IEntity<Integer> {

	private static final long serialVersionUID = -6612906782040239913L;

	@Id
	@Column(name = "ID_TELEFONE")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idTelefone;
    
    @Column(name = "DATA_CADASTRO")
	@Temporal(TemporalType.TIMESTAMP)
    private Date dataCadastro;
    
    @Column(name = "TELEFONE" , length = 50)
    private String telefone;
    
    @Column(name = "DDD", length = 3)
    private String ddd;
    
    @ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_CASO", referencedColumnName = "ID_CASO", nullable = false)
    private Caso caso;
    
    public Telefone(){
    	
    }
    
    public Telefone(String ddd, String telefone){
    	this.ddd = ddd;
    	this.telefone = telefone;
    }

    public Telefone(Integer idTelefone) {
		this.idTelefone = idTelefone;
	}

	public Date getDataCadastro() {
        return dataCadastro != null ? new Date(dataCadastro.getTime()) : null;
    }

    public void setDataCadastro(Date dataCadastro) {
        this.dataCadastro = dataCadastro != null ? new Date(dataCadastro.getTime()) : null;
    }

    public String getDdd() {
        return ddd;
    }

    public void setDdd(String ddd) {
        this.ddd = ddd;
    }

    public Integer getIdTelefone() {
        return idTelefone;
    }

    public void setIdTelefone(Integer idTelefone) {
        this.idTelefone = idTelefone;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public final Caso getCaso() {
        return caso;
    }

    public final void setCaso(Caso caso) {
        this.caso = caso;
    }

    public Integer getPK() {
        return getIdTelefone();
    }

    public void setPK(Integer pk) {
        this.idTelefone = pk;
    }

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((caso == null) ? 0 : caso.hashCode());
		result = prime * result
				+ ((idTelefone == null) ? 0 : idTelefone.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof Telefone)) {
			return false;
		}
		Telefone other = (Telefone) obj;
		if (caso == null) {
			if (other.caso != null) {
				return false;
			}
		} else if (!caso.equals(other.caso)) {
			return false;
		}
		if (idTelefone == null) {
			if (other.idTelefone != null) {
				return false;
			}
		} else if (!idTelefone.equals(other.idTelefone)) {
			return false;
		}
		return true;
	}
    
	
	public static String getSqlCamposTelefone() {
		
    	return new StringBuilder()
		.append(" \nTelefone.ID_TELEFONE AS 'Telefone.ID_TELEFONE',")
		.append(" \nTelefone.DATA_CADASTRO AS 'Telefone.DATA_CADASTRO',")
		.append(" \nTelefone.TELEFONE AS 'Telefone.TELEFONE',")
		.append(" \nTelefone.DDD AS 'Telefone.DDD', ")
		.append(" \nTelefone.ID_CASO AS 'Telefone.ID_CASO'").toString();
	}

	public static String getSqlFromTelefone() {
		return " TB_TELEFONE  AS Telefone with(nolock) ";
	}

	public static Telefone getTelefoneByResultSet(ResultSet resultSet) {

		Telefone telefone = new Telefone();

		try {
			
			if(resultSet.getInt("Telefone.ID_TELEFONE") == 0) {
        		return null;
        	}
			
			telefone.setIdTelefone(resultSet.getInt("Telefone.ID_TELEFONE"));
			telefone.setTelefone(resultSet.getString("Telefone.TELEFONE"));
			telefone.setDdd(resultSet.getString("Telefone.DDD"));
			telefone.setDataCadastro(resultSet.getTimestamp("Telefone.DATA_CADASTRO"));
			telefone.setCaso(resultSet.getInt("Telefone.ID_CASO") == 0 ? null : new Caso(resultSet.getInt("Telefone.ID_CASO")));
		
		} catch (SQLException e) {
			throw new IllegalArgumentException(
					"Erro ao montar objeto a partir do ResultSet", e);
		}
		return telefone;
	}

    
}
