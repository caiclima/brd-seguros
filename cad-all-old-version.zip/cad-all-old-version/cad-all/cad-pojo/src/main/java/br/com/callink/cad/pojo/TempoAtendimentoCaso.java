package br.com.callink.cad.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;



/**
 * 
 * @author brunomt
 * 
 */
@Entity
@Table(name = "TB_TEMPO_ATENDIMENTO_CASO")
public class TempoAtendimentoCaso implements IEntity<Integer> {
	
	private static final long serialVersionUID = -988282742874472771L;

	@Id
	@Column(name = "ID_TEMPO_ATENDIMENTO_CASO")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer idTempoAtendimentoCaso;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_CASO", referencedColumnName = "ID_CASO")
	private Caso caso;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_ATENDENTE", referencedColumnName = "ID_ATENDENTE")
	private Atendente atendente;

	@Column(name = "DATA_FIM")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataFim;

	@Column(name = "DATA_INICIO")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataInicio;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_ACAO", referencedColumnName = "ID_ACAO")
	private Acao acao;

	private transient Boolean flagInicio;

	private transient Date dataMarcacao;

	public Integer getPK() {
		return idTempoAtendimentoCaso;
	}

	public void setPK(Integer pk) {
		this.idTempoAtendimentoCaso = pk;
	}

	/**
	 * @return the idTempoAtendimentoCaso
	 */
	public final Integer getIdTempoAtendimentoCaso() {
		return idTempoAtendimentoCaso;
	}

	/**
	 * @param idTempoAtendimentoCaso
	 *            the idTempoAtendimentoCaso to set
	 */
	public final void setIdTempoAtendimentoCaso(Integer idTempoAtendimentoCaso) {
		this.idTempoAtendimentoCaso = idTempoAtendimentoCaso;
	}

	/**
	 * @return the caso
	 */
	public final Caso getCaso() {
		return caso;
	}

	/**
	 * @param caso
	 *            the caso to set
	 */
	public final void setCaso(Caso caso) {
		this.caso = caso;
	}

	/**
	 * @return the atendente
	 */
	public final Atendente getAtendente() {
		return atendente;
	}

	/**
	 * @param atendente
	 *            the atendente to set
	 */
	public final void setAtendente(Atendente atendente) {
		this.atendente = atendente;
	}

	/**
	 * @return the dataMarcacao
	 */
	public final Date getDataFim() {
		return dataFim == null ? null : new Date(dataFim.getTime());
	}

	/**
	 * @param dataMarcacao
	 *            the dataMarcacao to set
	 */
	public final void setDataFim(Date dataFim) {
		this.dataFim = dataFim == null ? null : new Date(dataFim.getTime());
	}

	/**
	 * @return the flagInicio
	 */
	public final Boolean getFlagInicio() {
		if (flagInicio == null) {
			flagInicio = this.dataFim == null;
		}
		return flagInicio;
	}

	/**
	 * @param flagInicio
	 *            the flagInicio to set
	 */
	public final void setFlagInicio(Boolean flagInicio) {
		this.flagInicio = flagInicio;
	}

	/**
	 * get dataInicio
	 * 
	 * @return
	 */
	public final Date getDataInicio() {
		return dataInicio == null ? null : new Date(dataInicio.getTime());
	}

	/**
	 * seta dataInicio
	 * 
	 * @param dataInicio
	 */
	public final void setDataInicio(Date dataInicio) {
		this.dataInicio = dataInicio == null ? null : new Date(dataInicio.getTime());
	}

	public Acao getAcao() {
		return acao;
	}

	public void setAcao(Acao acao) {
		this.acao = acao;
	}

	public Date getDataMarcacao() {
		return dataMarcacao == null ? null : new Date(dataMarcacao.getTime());
	}

	public void setDataMarcacao(Date dataMarcacao) {
		this.dataMarcacao = dataMarcacao == null ? null : new Date(dataMarcacao.getTime());
	}

	@Override
	public int hashCode() {
		int hash = 7;
		hash = 31
				* hash
				+ (this.idTempoAtendimentoCaso != null ? this.idTempoAtendimentoCaso
						.hashCode() : 0);
		return hash;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final TempoAtendimentoCaso other = (TempoAtendimentoCaso) obj;
		if (this.idTempoAtendimentoCaso == null
				|| !this.idTempoAtendimentoCaso
						.equals(other.idTempoAtendimentoCaso)) {
			return false;
		}
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "TempoAtendimentoCaso [idTempoAtendimentoCaso="
				+ idTempoAtendimentoCaso + "]";
	}

	public static String getSqlCamposTempoAtendimentoCaso() {
		return new StringBuilder()
		.append(" \nTempoAtendimentoCaso.ID_TEMPO_ATENDIMENTO_CASO AS 'TempoAtendimentoCaso.ID_TEMPO_ATENDIMENTO_CASO',")
		.append(" \nTempoAtendimentoCaso.ID_CASO AS 'TempoAtendimentoCaso.ID_CASO',")
		.append(" \nTempoAtendimentoCaso.ID_ATENDENTE AS 'TempoAtendimentoCaso.ID_ATENDENTE',")
		.append(" \nTempoAtendimentoCaso.DATA_INICIO AS 'TempoAtendimentoCaso.DATA_INICIO',")
		.append(" \nTempoAtendimentoCaso.DATA_FIM AS 'TempoAtendimentoCaso.DATA_FIM',")
		.append(" \nTempoAtendimentoCaso.ID_ACAO AS 'TempoAtendimentoCaso.ID_ACAO' ")
		.toString();
	}

	public static String getSqlFromTempoAtendimentoCaso() {
		return " TB_TEMPO_ATENDIMENTO_CASO  AS TempoAtendimentoCaso with(nolock) ";
	}

	public static TempoAtendimentoCaso getTempoAtendimentoCasoByResultSet(
			ResultSet resultSet) {

		TempoAtendimentoCaso tempoAtendimentoCaso = new TempoAtendimentoCaso();

		try {
			
			if(resultSet.getInt("TempoAtendimentoCaso.id_tempo_atendimento_caso") == 0) {
        		return null;
        	}
			
			tempoAtendimentoCaso.setIdTempoAtendimentoCaso(resultSet.getInt("TempoAtendimentoCaso.id_tempo_atendimento_caso"));
			tempoAtendimentoCaso.setCaso(resultSet.getInt("TempoAtendimentoCaso.ID_CASO") == 0 ? null : new Caso(resultSet.getInt("TempoAtendimentoCaso.ID_CASO")));
			tempoAtendimentoCaso.setAtendente(resultSet.getInt("TempoAtendimentoCaso.ID_ATENDENTE") == 0 ? null : new Atendente(resultSet.getInt("TempoAtendimentoCaso.ID_ATENDENTE")));
			tempoAtendimentoCaso.setDataFim(resultSet.getTimestamp("TempoAtendimentoCaso.data_fim"));
			tempoAtendimentoCaso.setDataInicio(resultSet.getTimestamp("TempoAtendimentoCaso.data_inicio"));
			tempoAtendimentoCaso.setAcao(resultSet.getInt("TempoAtendimentoCaso.id_acao") == 0 ? null : new Acao(resultSet.getInt("TempoAtendimentoCaso.id_acao")));
		} catch (SQLException e) {
			throw new IllegalArgumentException(
					"Erro ao montar objeto a partir do ResultSet", e);
		}
		return tempoAtendimentoCaso;
	}

}
