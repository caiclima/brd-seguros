package br.com.callink.cad.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;

/**
*
* @author Bruno [brunoam@swb.com.br]
* @since 27/02/2012
*/

@Entity
@Table(name = "TB_TIPO_ACAO")
public class TipoAcao implements IEntity<Integer>{

	private static final long serialVersionUID = 1689831595790280490L;

	@Id
	@Column(name = "ID_TIPO_ACAO")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer idTipoAcao;

	@Column(name = "NOME" , length = 250, nullable = false)
	private String nome;

	@Column(name = "DATA_ALTERACAO", nullable = false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataAlteracao;

	@Column(name = "FLAG_ATIVO", nullable = false)
	private Boolean flagAtivo;
	
	public TipoAcao(){
		
	}
	
	public TipoAcao(Integer idTipoAcao){
		this.idTipoAcao = idTipoAcao;
	}

	/**
	 * @return the dataAlteracao
	 */
	public final Date getDataAlteracao() {
		return dataAlteracao == null ? null : new Date(dataAlteracao.getTime());
	}

	/**
	 * @param dataAlteracao the dataAlteracao to set
	 */
	public final void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao == null ? null : new Date(dataAlteracao.getTime());
	}

	public Integer getPK() {
		return idTipoAcao;
	}

	public void setPK(Integer pk) {
		this.idTipoAcao = pk;
	}

	/**
	 * @return the idTipoAcao
	 */
	public final Integer getIdTipoAcao() {
		return idTipoAcao;
	}

	/**
	 * @param idTipoAcao the idTipoAcao to set
	 */
	public final void setIdTipoAcao(Integer idTipoAcao) {
		this.idTipoAcao = idTipoAcao;
	}

	public final String getNome() {
		return nome;
	}

	public final void setNome(String nome) {
		this.nome = nome;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return nome;
	}

	public void setFlagAtivo(Boolean flagAtivo) {
		this.flagAtivo = flagAtivo;
	}

	public Boolean getFlagAtivo() {
		return flagAtivo;
	}

        @Override
        public int hashCode() {
            int hash = 7;
            hash = 59 * hash + (this.idTipoAcao != null ? this.idTipoAcao.hashCode() : 0);
            return hash;
        }

        @Override
        public boolean equals(Object obj) {
            if (obj == null) {
                return false;
            }
            if (getClass() != obj.getClass()) {
                return false;
            }
            final TipoAcao other = (TipoAcao) obj;
            if (this.idTipoAcao == null || !this.idTipoAcao.equals(other.idTipoAcao)) {
                return false;
            }
            return true;
        }
        
        public static String getSqlCamposTipoAcao() {
    		
        	return new StringBuilder()
    		.append(" \nTipoAcao.ID_TIPO_ACAO AS 'TipoAcao.ID_TIPO_ACAO',")
			.append(" \nTipoAcao.NOME AS 'TipoAcao.NOME',")
			.append(" \nTipoAcao.DATA_ALTERACAO AS 'TipoAcao.DATA_ALTERACAO',")
			.append(" \nTipoAcao.FLAG_ATIVO AS 'TipoAcao.FLAG_ATIVO' ").toString();
    	}

    	public static String getSqlFromTipoAcao() {
    		return " TB_TIPO_ACAO  AS TipoAcao with(nolock) ";
    	}

    	public static TipoAcao getTipoAcaoByResultSet(ResultSet resultSet) {

    		TipoAcao tipoAcao = new TipoAcao();

    		try {
    			
    			if(resultSet.getInt("TipoAcao.ID_TIPO_ACAO") == 0) {
            		return null;
            	}
    			
    			tipoAcao.setIdTipoAcao(resultSet.getInt("TipoAcao.ID_TIPO_ACAO"));
    			tipoAcao.setNome(resultSet.getString("TipoAcao.NOME"));
    			tipoAcao.setDataAlteracao(resultSet.getTimestamp("TipoAcao.DATA_ALTERACAO"));
    			tipoAcao.setFlagAtivo(resultSet.getBoolean("TipoAcao.FLAG_ATIVO"));
    			
    		} catch (SQLException e) {
    			throw new IllegalArgumentException(
    					"Erro ao montar objeto a partir do ResultSet", e);
    		}
    		return tipoAcao;
    	}
	
}
