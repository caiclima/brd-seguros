package br.com.callink.cad.pojo.Util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.persistence.criteria.From;

public final class DateUtil {

	
	
	private DateUtil(){}
	
	
	/**
	 * Converte Date em String com horas.
	 * @param date
	 * @return
	 */
	public static String convertDateStringWithHour(Date date){
		
		SimpleDateFormat formatBra = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
		return formatBra.format(date);
	}
	
	/**
	 * Converte Date em String com horas.
	 * @param date
	 * @return
	 */
	public static String convertDateStringWithHourAndMilesimo(Date date){
		
		SimpleDateFormat formatBra = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS"); 
		return formatBra.format(date);
	}
	
	/**
	 * COnverte Date em String
	 * @param date
	 * @return
	 */
	public static String convertDateString(Date date){
		
		SimpleDateFormat formatBra = new SimpleDateFormat("yyyy-MM-dd"); 
		return formatBra.format(date);
	}
	
	public static Date dataInicioDia(Date date) {
		//Inicio Dia
		GregorianCalendar cal = new GregorianCalendar();
		
		cal.setTime(date);
		cal.set(GregorianCalendar.HOUR_OF_DAY,0); 
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		return cal.getTime();
	}
	
	public static Date dataFimDia(Date date) {
		
		//Fim dia
		GregorianCalendar cal = new GregorianCalendar();
		cal.setTime(date);
		cal.set(GregorianCalendar.HOUR_OF_DAY, 23); 
		cal.set(GregorianCalendar.MINUTE, 59);  
		return cal.getTime();		
	}
}
