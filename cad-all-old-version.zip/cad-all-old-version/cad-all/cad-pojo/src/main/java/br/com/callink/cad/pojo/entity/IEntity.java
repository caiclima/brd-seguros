package br.com.callink.cad.pojo.entity;

import java.io.Serializable;

public interface IEntity <T> extends Serializable {

	 T getPK();

	 void setPK(T pk);
}
