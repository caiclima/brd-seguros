package br.com.callink.cad.repository;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

import br.com.callink.cad.pojo.AtendimentoCaso;
import br.com.callink.cad.pojo.HistoricoDadosCaso;
import br.com.callink.cad.pojo.Log;
import br.com.callink.cad.pojo.LogLigacoes;
import br.com.callink.cad.pojo.TempoAtendimentoCaso;

public final class MarcacaoLogs {
	private static Queue<Log> logQueue = new ConcurrentLinkedQueue<Log>();
	private static Queue<TempoAtendimentoCaso> tempoAtendimentoCasoQueue = new ConcurrentLinkedQueue<TempoAtendimentoCaso>();
	private static Queue<AtendimentoCaso> atendimentoCasoQueue = new ConcurrentLinkedQueue<AtendimentoCaso>();
	private static Queue<HistoricoDadosCaso> historicoDadosCasoQueue = new ConcurrentLinkedQueue<HistoricoDadosCaso>();
	private static Queue<LogLigacoes> logLigacoesQueue = new ConcurrentLinkedQueue<LogLigacoes>();
        
	private MarcacaoLogs(){}
	
	public static synchronized void offer(Log log) {
		logQueue.offer(log);
	}
	
	public static synchronized void offer(TempoAtendimentoCaso tempoAtendimentoCaso) {
		tempoAtendimentoCasoQueue.offer(tempoAtendimentoCaso);
	}
	
	public static synchronized void offer(AtendimentoCaso atendimentoCaso) {
		atendimentoCasoQueue.offer(atendimentoCaso);
	}
        
        public static synchronized void offer(HistoricoDadosCaso historicoDadosCaso) {
            historicoDadosCasoQueue.offer(historicoDadosCaso);
        }
	
	public static synchronized Log pollLog() {
		return logQueue.poll();
	}
    
	public static synchronized void offer(LogLigacoes logLigacoes) {
		logLigacoesQueue.offer(logLigacoes);
	}
	
	public static synchronized TempoAtendimentoCaso pollTempoAtendimentoCaso() {
		return tempoAtendimentoCasoQueue.poll();
	}
	
	public static synchronized AtendimentoCaso pollAtendimentoCaso() {
		return atendimentoCasoQueue.poll();
	}
        
    public static synchronized HistoricoDadosCaso pollHistoricoDadosCaso() {
        return historicoDadosCasoQueue.poll();
    }
    
	public static synchronized LogLigacoes pollLogLigacoes() {
		return logLigacoesQueue.poll();
	}
	
}
