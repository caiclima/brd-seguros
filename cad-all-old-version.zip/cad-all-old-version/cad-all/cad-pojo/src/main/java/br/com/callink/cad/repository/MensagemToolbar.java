package br.com.callink.cad.repository;

import java.util.List;

import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.Equipe;

public class MensagemToolbar {

	private String usuarioSSOEmitente;
	private String usuarioSSORemetente;
	
	private List<Equipe> equipeAtendentes;
	private List<Atendente> analistasAtendentes;
	
	private String mensagem;
	
	
	public MensagemToolbar() {
		super();
	}
	
	public MensagemToolbar(String usuarioSSOEmitente, String usuarioSSORemetente, String mensagem) {
		super();
		this.usuarioSSOEmitente = usuarioSSOEmitente;
		this.usuarioSSORemetente = usuarioSSORemetente;
		this.mensagem = mensagem;
	}
	
	
	/**
	 * @return the usuarioSSOEmitente
	 */
	public String getUsuarioSSOEmitente() {
		return usuarioSSOEmitente;
	}
	/**
	 * @param usuarioSSOEmitente the usuarioSSOEmitente to set
	 */
	public void setUsuarioSSOEmitente(String usuarioSSOEmitente) {
		this.usuarioSSOEmitente = usuarioSSOEmitente;
	}
	/**
	 * @return the usuarioSSORemetente
	 */
	public String getUsuarioSSORemetente() {
		return usuarioSSORemetente;
	}
	/**
	 * @param usuarioSSORemetente the usuarioSSORemetente to set
	 */
	public void setUsuarioSSORemetente(String usuarioSSORemetente) {
		this.usuarioSSORemetente = usuarioSSORemetente;
	}
	
	/**
	 * @return the equipeAtendentes
	 */
	public List<Equipe> getEquipeAtendentes() {
		return equipeAtendentes;
	}

	/**
	 * @param equipeAtendentes the equipeAtendentes to set
	 */
	public void setEquipeAtendentes(List<Equipe> equipeAtendentes) {
		this.equipeAtendentes = equipeAtendentes;
	}

	/**
	 * @return the analistasAtendentes
	 */
	public List<Atendente> getAnalistasAtendentes() {
		return analistasAtendentes;
	}

	/**
	 * @param analistasAtendentes the analistasAtendentes to set
	 */
	public void setAnalistasAtendentes(List<Atendente> analistasAtendentes) {
		this.analistasAtendentes = analistasAtendentes;
	}

	/**
	 * @return the mensagem
	 */
	public String getMensagem() {
		return mensagem;
	}
	/**
	 * @param mensagem the mensagem to set
	 */
	public void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}

	@Override
	public String toString() {
		return "MensagemToolbar [usuarioSSOEmitente=" + usuarioSSOEmitente + ", usuarioSSORemetente="
				+ usuarioSSORemetente + ", mensagem=" + mensagem + "]";
	}
	
	
	
}
