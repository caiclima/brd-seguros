package br.com.callink.cad.repository;

import br.com.callink.cad.repository.to.CabMetaTO;
import br.com.callink.cad.repository.to.MetaFilaTO;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;


/**
 * classe que controla o cache das metas
 * 
 * @author miller
 *
 */
public final class MetasUphCache {

	private static Map<String, CabMetaTO> mapMetasCache = new ConcurrentHashMap<String, CabMetaTO>();

	public static void criaMapMetas(Map<String,CabMetaTO> mapCabMetaTO) {
		mapMetasCache = mapCabMetaTO;
	}

	private MetasUphCache(){}
	
	
	public static CabMetaTO montaListaByUser(String user) {
		
		CabMetaTO cabMetaTo = mapMetasCache.get(user);
		
                if (cabMetaTo != null) {

                    List<MetaFilaTO> listaMetaFilaTO = new ArrayList<MetaFilaTO>();

                    CabMetaTO cabMetaAux = new CabMetaTO();
                    cabMetaAux.setgMediaPonderadaFinal(cabMetaTo.getgMediaPonderadaFinal());
                    cabMetaAux.setIdAtendente(cabMetaTo.getIdAtendente());
                    cabMetaAux.setImageGFinal(cabMetaTo.getImageGFinal());

                    for(MetaFilaTO filaTO: cabMetaTo.getListaMetaFilaTO()) {

                            MetaFilaTO metaTO = new MetaFilaTO();
                            metaTO.setEquipeMetaTO(filaTO.getEquipeMetaTO());
                            metaTO.setFila(filaTO.getFila());
                            metaTO.setGoalFinal(filaTO.getGoalFinal());
                            metaTO.setImagemGoal(filaTO.getImagemGoal());
                            metaTO.setIndiceGoal(filaTO.getIndiceGoal());
                            metaTO.setLogin(filaTO.getLogin());
                            metaTO.setMeta(filaTO.getMeta());
                            metaTO.setUph(filaTO.getUph());
                            listaMetaFilaTO.add(metaTO);
                    }

                    cabMetaAux.setListaMetaFilaTO(listaMetaFilaTO);

                    return cabMetaAux;
                } else {
                    return null;
                }
	}
}
