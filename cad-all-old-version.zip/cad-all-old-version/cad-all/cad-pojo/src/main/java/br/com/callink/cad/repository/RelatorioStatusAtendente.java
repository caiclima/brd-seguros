package br.com.callink.cad.repository;

import java.util.List;

import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.StatusAtendente;

public class RelatorioStatusAtendente {
	
	private Atendente atendente;
	private List<StatusAtendente> statusAtendenteList;
	private String tempoTotalAtendente;
	
	public Atendente getAtendente() {
		return atendente;
	}
	public void setAtendente(Atendente atendente) {
		this.atendente = atendente;
	}
	public List<StatusAtendente> getStatusAtendenteList() {
		return statusAtendenteList;
	}
	public void setStatusAtendenteList(List<StatusAtendente> statusAtendenteList) {
		this.statusAtendenteList = statusAtendenteList;
	}
	public String getTempoTotalAtendente() {
		return tempoTotalAtendente;
	}
	public void setTempoTotalAtendente(String tempoTotalAtendente) {
		this.tempoTotalAtendente = tempoTotalAtendente;
	}

}
