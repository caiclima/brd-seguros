/**
 * 
 */
package br.com.callink.cad.repository;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import br.com.callink.cad.pojo.SlaFila;

/**
 * @author José Araújo (joseap@swb.com.br)
 *
 */
public final class SlaFilaConfiguracao {
	
	/**Guarda o map de sla fila já carregado*/
	private static Map<Integer, SlaFila> slaFilaCache = new ConcurrentHashMap<Integer, SlaFila>();

	private SlaFilaConfiguracao() {
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * @return the slaFilaCache
	 */
	public static synchronized SlaFila getSlaFilaCache(Integer slaFila) {
		return slaFilaCache.get(slaFila);
	}

	/**
	 * @param slaFilaCache the slaFilaCache to set
	 */
	public static synchronized void setSlaFilaCache(SlaFila slaFilaCache) {
		SlaFilaConfiguracao.slaFilaCache.put(slaFilaCache.getIdSlaFila(), slaFilaCache);
	}
	
}
