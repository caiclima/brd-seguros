package br.com.callink.cad.repository.to;

import java.io.Serializable;
import java.util.List;


public class AtendenteCasoStatusTO implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private Integer idAtendente;
	private String nomeAtendente;
	private List<CasoStatusTO> listCasos;
	
	public Integer getIdAtendente() {
		return idAtendente;
	}
	
	public void setIdAtendente(Integer idAtendente) {
		this.idAtendente = idAtendente;
	}
	
	public String getNomeAtendente() {
		return nomeAtendente;
	}
	
	public void setNomeAtendente(String nomeAtendente) {
		this.nomeAtendente = nomeAtendente;
	}
	
	public List<CasoStatusTO> getListCasos() {
		return listCasos;
	}

	public void setListCasos(List<CasoStatusTO> listCasos) {
		this.listCasos = listCasos;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((idAtendente == null) ? 0 : idAtendente.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AtendenteCasoStatusTO other = (AtendenteCasoStatusTO) obj;
		if (idAtendente == null) {
			if (other.idAtendente != null)
				return false;
		} else if (!idAtendente.equals(other.idAtendente))
			return false;
		return true;
	}
	
}
