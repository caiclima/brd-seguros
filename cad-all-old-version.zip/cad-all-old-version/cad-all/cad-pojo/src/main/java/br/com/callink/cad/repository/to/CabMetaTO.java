/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.repository.to;

import java.util.List;


/**
 *
 * @author bruno
 */
public class CabMetaTO implements Cloneable {
    
    private Integer idAtendente;
    private Double gMediaPonderadaFinal;
    private String imageGFinal;
    private List<MetaFilaTO> listaMetaFilaTO;

    public Integer getIdAtendente() {
        return idAtendente;
    }

    public void setIdAtendente(Integer idAtendente) {
        this.idAtendente = idAtendente;
    }

    public Double getgMediaPonderadaFinal() {
        return gMediaPonderadaFinal;
    }

    public void setgMediaPonderadaFinal(Double gMediaPonderadaFinal) {
        this.gMediaPonderadaFinal = gMediaPonderadaFinal;
    }

    public String getImageGFinal() {
        return imageGFinal;
    }

    public void setImageGFinal(String imageGFinal) {
        this.imageGFinal = imageGFinal;
    }

    public List<MetaFilaTO> getListaMetaFilaTO() {
        return listaMetaFilaTO;
    }

    public void setListaMetaFilaTO(List<MetaFilaTO> listaMetaFilaTO) {
        this.listaMetaFilaTO = listaMetaFilaTO;
    }
    
    
    
}
