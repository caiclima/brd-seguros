package br.com.callink.cad.repository.to;

import java.util.ArrayList;
import java.util.List;

public class CasoFechadoTO {
	private String rangeHora;
	private Integer horaInicio;
	private Integer horaFim;
	private List<DetalheCasoFechadoTO> casosFechadosPorTipo;
        private DetalheCasoFechadoTO detalheTotalFinal;
        
	public CasoFechadoTO() {
		casosFechadosPorTipo = new ArrayList<DetalheCasoFechadoTO>();
	}
	
	/**
	 * @return the rangeHora
	 */
	public String getRangeHora() {
		return rangeHora;
	}
	/**
	 * @param rangeHora the rangeHora to set
	 */
	public void setRangeHora(String rangeHora) {
		this.rangeHora = rangeHora;
	}
	/**
	 * @return the casosFechadosPorTipo
	 */
	public List<DetalheCasoFechadoTO> getCasosFechadosPorTipo() {
		return casosFechadosPorTipo;
	}
	/**
	 * @param casosFechadosPorTipo the casosFechadosPorTipo to set
	 */
	public void setCasosFechadosPorTipo(List<DetalheCasoFechadoTO> casosFechadosPorTipo) {
		this.casosFechadosPorTipo = casosFechadosPorTipo;
	}

	public Integer getHoraInicio() {
		return horaInicio;
	}

	public void setHoraInicio(Integer horaInicio) {
		this.horaInicio = horaInicio;
	}

	public Integer getHoraFim() {
		return horaFim;
	}

	public void setHoraFim(Integer horaFim) {
		this.horaFim = horaFim;
	}
        

        public List<String> getFilasCasosFechados() {
            
            List<String> listaCaso = new ArrayList<String>();
                    
            for (DetalheCasoFechadoTO detalheCasoFechadoTO : casosFechadosPorTipo) {
                listaCaso.add(detalheCasoFechadoTO.getTipoCaso());
            }
            
            return listaCaso;
        }

    public DetalheCasoFechadoTO getDetalheTotalFinal() {
        return detalheTotalFinal;
    }

    public void setDetalheTotalFinal(DetalheCasoFechadoTO detalheTotalFinal) {
        this.detalheTotalFinal = detalheTotalFinal;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final CasoFechadoTO other = (CasoFechadoTO) obj;
        if ((this.rangeHora == null) ? (other.rangeHora != null) : !this.rangeHora.equals(other.rangeHora)) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 59 * hash + (this.rangeHora != null ? this.rangeHora.hashCode() : 0);
        return hash;
    }
    
    

}
