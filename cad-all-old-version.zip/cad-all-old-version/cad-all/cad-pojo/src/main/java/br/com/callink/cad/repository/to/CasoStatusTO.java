package br.com.callink.cad.repository.to;

import java.io.Serializable;


public class CasoStatusTO implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private Integer idStatus;
	private String nomeStatus;
	private Integer quantidadeCasosAtendidos;
	
	public Integer getIdStatus() {
		return idStatus;
	}
	
	public void setIdStatus(Integer idStatus) {
		this.idStatus = idStatus;
	}
	
	public String getNomeStatus() {
		return nomeStatus;
	}
	
	public void setNomeStatus(String nomeStatus) {
		this.nomeStatus = nomeStatus;
	}
	
	public Integer getQuantidadeCasosAtendidos() {
		return quantidadeCasosAtendidos;
	}
	
	public void setQuantidadeCasosAtendidos(Integer quantidade) {
		this.quantidadeCasosAtendidos = quantidade;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((idStatus == null) ? 0 : idStatus.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CasoStatusTO other = (CasoStatusTO) obj;
		if (idStatus == null) {
			if (other.idStatus != null)
				return false;
		} else if (!idStatus.equals(other.idStatus))
			return false;
		return true;
	}
	
}
