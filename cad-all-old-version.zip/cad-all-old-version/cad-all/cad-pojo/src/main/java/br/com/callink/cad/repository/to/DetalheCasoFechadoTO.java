package br.com.callink.cad.repository.to;

public class DetalheCasoFechadoTO {
	
	private String tipoCaso;
	private Integer fechadoDentroPrazo;
	private Integer fechadoForaPrazo;
	private Integer totalTipo;
	
	public DetalheCasoFechadoTO() {
		fechadoDentroPrazo = Integer.valueOf("0");
		fechadoForaPrazo = Integer.valueOf("0");
		totalTipo = Integer.valueOf("0");
	}
	
	public void addFechadoDentroPrazo() {
		fechadoDentroPrazo++;
		totalTipo++;
	}
	
	public void addFechadoForaPrazo() {
		fechadoForaPrazo++;
		totalTipo++;
	}
	
	/**
	 * @return the tipoCaso
	 */
	public String getTipoCaso() {
		return tipoCaso;
	}
	/**
	 * @param tipoCaso the tipoCaso to set
	 */
	public void setTipoCaso(String tipoCaso) {
		this.tipoCaso = tipoCaso;
	}
	/**
	 * @return the fechadoDentroPrazo
	 */
	public Integer getFechadoDentroPrazo() {
		return fechadoDentroPrazo;
	}
	/**
	 * @param fechadoDentroPrazo the fechadoDentroPrazo to set
	 */
	public void setFechadoDentroPrazo(Integer fechadoDentroPrazo) {
		this.fechadoDentroPrazo = fechadoDentroPrazo;
	}
	/**
	 * @return the fechadoForaPrazo
	 */
	public Integer getFechadoForaPrazo() {
		return fechadoForaPrazo;
	}
	/**
	 * @param fechadoForaPrazo the fechadoForaPrazo to set
	 */
	public void setFechadoForaPrazo(Integer fechadoForaPrazo) {
		this.fechadoForaPrazo = fechadoForaPrazo;
	}
	/**
	 * @return the totalTipo
	 */
	public Integer getTotalTipo() {
		return totalTipo;
	}
	/**
	 * @param totalTipo the totalTipo to set
	 */
	public void setTotalTipo(Integer totalTipo) {
		this.totalTipo = totalTipo;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((tipoCaso == null) ? 0 : tipoCaso.hashCode());
		return result;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof DetalheCasoFechadoTO)) {
			return false;
		}
		DetalheCasoFechadoTO other = (DetalheCasoFechadoTO) obj;
		if (tipoCaso == null) {
			if (other.tipoCaso != null) {
				return false;
			}
		} else if (!tipoCaso.equals(other.tipoCaso)) {
			return false;
		}
		return true;
	}
	
	
}
