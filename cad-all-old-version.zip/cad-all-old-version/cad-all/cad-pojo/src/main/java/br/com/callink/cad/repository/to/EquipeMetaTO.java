package br.com.callink.cad.repository.to;

import br.com.callink.cad.pojo.ConfiguracaoFila;

/**
 *
 * @author bruno
 */
public class EquipeMetaTO {
    
    private ConfiguracaoFila configuracaoFila;
    private Double tempoTotalEquipe;
    private Integer casosFechados;
    private Double uphEquipe;

    public Integer getCasosFechados() {
        return casosFechados;
    }

    public void setCasosFechados(Integer casosFechados) {
        this.casosFechados = casosFechados;
    }

    public ConfiguracaoFila getConfiguracaoFila() {
        return configuracaoFila;
    }

    public void setConfiguracaoFila(ConfiguracaoFila configuracaoFila) {
        this.configuracaoFila = configuracaoFila;
    }

    public Double getTempoTotalEquipe() {
        return tempoTotalEquipe;
    }

    public void setTempoTotalEquipe(Double tempoTotalEquipe) {
        this.tempoTotalEquipe = tempoTotalEquipe;
    }

    public Double getUphEquipe() {
        return uphEquipe;
    }

    public void setUphEquipe(Double uphEquipe) {
        this.uphEquipe = uphEquipe;
    }
    
    
    
}
