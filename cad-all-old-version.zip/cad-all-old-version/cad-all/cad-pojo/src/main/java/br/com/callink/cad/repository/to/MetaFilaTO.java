package br.com.callink.cad.repository.to;

import java.io.Serializable;

import br.com.callink.cad.pojo.ConfiguracaoFila;

/**
 * Classe que representa os dados de apresentacao das metas 
 * 
 * @author swb.miller
 *
 */
public class MetaFilaTO implements Comparable<MetaFilaTO>, Serializable {

	private static final long serialVersionUID = 1L;

	private ConfiguracaoFila fila;
	
	/**
	 * uph do atendente
	 */
	private Double uph;
	
	/**
	 * meta da fila
	 */
	private Double meta;
	
	/**
	 * indice do goal
	 */
	private Double indiceGoal;
	
    private EquipeMetaTO equipeMetaTO;

	private String login;
	
	private String imagemGoal;
	
	private Double goalFinal;
	
	public ConfiguracaoFila getFila() {
		return fila;
	}

	public void setFila(ConfiguracaoFila fila) {
		this.fila = fila;
	}

	public Double getUph() {
		return uph;
	}

	public void setUph(Double uph) {
		this.uph = uph;
	}

	public Double getMeta() {
		return meta;
	}

	public void setMeta(Double meta) {
		this.meta = meta;
	}

	public Double getIndiceGoal() {
		return indiceGoal;
	}

	public void setIndiceGoal(Double indiceGoal) {
		this.indiceGoal = indiceGoal;
	}

        public String getLogin() {
		return login;
	}
	
	public void setLogin(String login) {
		this.login = login;
	}

	public String getImagemGoal() {
		return imagemGoal;
	}
	
	public void setImagemGoal(String imagemGoal) {
		this.imagemGoal = imagemGoal;
	}

	@Override
	public int compareTo(MetaFilaTO o) {
		return this.getLogin().compareTo(o.getLogin());
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((fila == null) ? 0 : fila.hashCode());
		result = prime * result
				+ ((indiceGoal == null) ? 0 : indiceGoal.hashCode());
		result = prime * result + ((login == null) ? 0 : login.hashCode());
		result = prime * result + ((meta == null) ? 0 : meta.hashCode());
		result = prime * result + ((uph == null) ? 0 : uph.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof MetaFilaTO)) {
			return false;
		}
		MetaFilaTO other = (MetaFilaTO) obj;
		if (fila == null) {
			if (other.fila != null) {
				return false;
			}
		} else if (!fila.equals(other.fila)) {
			return false;
		}
		if (indiceGoal == null) {
			if (other.indiceGoal != null) {
				return false;
			}
		} else if (!indiceGoal.equals(other.indiceGoal)) {
			return false;
		}
		if (login == null) {
			if (other.login != null) {
				return false;
			}
		} else if (!login.equals(other.login)) {
			return false;
		}
		if (meta == null) {
			if (other.meta != null) {
				return false;
			}
		} else if (!meta.equals(other.meta)) {
			return false;
		}
		if (uph == null) {
			if (other.uph != null) {
				return false;
			}
		} else if (!uph.equals(other.uph)) {
			return false;
		}
		return true;
	}

	public final Double getGoalFinal() {
		return goalFinal;
	}

	public final void setGoalFinal(Double goalFinal) {
		this.goalFinal = goalFinal;
	}

    public EquipeMetaTO getEquipeMetaTO() {
        return equipeMetaTO;
    }

    public void setEquipeMetaTO(EquipeMetaTO equipeMetaTO) {
        this.equipeMetaTO = equipeMetaTO;
    }

	
}
