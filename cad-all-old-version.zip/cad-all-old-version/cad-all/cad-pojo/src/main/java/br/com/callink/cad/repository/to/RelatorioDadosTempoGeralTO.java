package br.com.callink.cad.repository.to;

import java.util.Date;
import java.util.List;

public class RelatorioDadosTempoGeralTO {

	
	private Integer idRelatorioTempoGeral;
	private Date data;
	private int diaData;
	
	private List<RelatorioDinamicoTempoGeralTO> listDinamicoTempoGeralTOs;
	
	private long qtdAgenteLogadoDia;
	private long tempoLogadoDia;
	
	private long tempoProdutivoDia;
	
	private double porcentTempoProdutivoDia;
	private long tempoPausaDia;
	
	private double porcentTempoPausaDia;

	private long tempoOciosoDia;
	private double porcentTempoOciosoDia;
	
	public Integer getIdRelatorioTempoGeral() {
		return idRelatorioTempoGeral;
	}

	public void setIdRelatorioTempoGeral(Integer idRelatorioTempoGeral) {
		this.idRelatorioTempoGeral = idRelatorioTempoGeral;
	}
	
	public int getDiaData() {
		return diaData;
	}

	public void setDiaData(int diaData) {
		this.diaData = diaData;
	}

	public Date getData() {
		return data;
	}

	public void setData(Date data) {
		this.data = data;
	}

	public List<RelatorioDinamicoTempoGeralTO> getListDinamicoTempoGeralTOs() {
		return listDinamicoTempoGeralTOs;
	}

	public void setListDinamicoTempoGeralTOs(List<RelatorioDinamicoTempoGeralTO> listDinamicoTempoGeralTOs) {
		this.listDinamicoTempoGeralTOs = listDinamicoTempoGeralTOs;
	}

	public long getQtdAgenteLogadoDia() {
		return qtdAgenteLogadoDia;
	}

	public void setQtdAgenteLogadoDia(long qtdAgenteLogadoDia) {
		this.qtdAgenteLogadoDia = qtdAgenteLogadoDia;
	}

	public long getTempoLogadoDia() {
		return tempoLogadoDia;
	}

	public void setTempoLogadoDia(long tempoLogadoDia) {
		this.tempoLogadoDia = tempoLogadoDia;
	}

	public long getTempoProdutivoDia() {
		return tempoProdutivoDia;
	}

	public void setTempoProdutivoDia(long tempoProdutivoDia) {
		this.tempoProdutivoDia = tempoProdutivoDia;
	}

	public double getPorcentTempoProdutivoDia() {
		return porcentTempoProdutivoDia;
	}

	public void setPorcentTempoProdutivoDia(double porcentTempoProdutivoDia) {
		this.porcentTempoProdutivoDia = porcentTempoProdutivoDia;
	}

	public long getTempoPausaDia() {
		return tempoPausaDia;
	}

	public void setTempoPausaDia(long tempoPausaDia) {
		this.tempoPausaDia = tempoPausaDia;
	}

	public double getPorcentTempoPausaDia() {
		return porcentTempoPausaDia;
	}

	public void setPorcentTempoPausaDia(double porcentTempoPausaDia) {
		this.porcentTempoPausaDia = porcentTempoPausaDia;
	}
	
	public long getTempoOciosoDia() {
		return tempoOciosoDia;
	}

	public void setTempoOciosoDia(long tempoOciosoDia) {
		this.tempoOciosoDia = tempoOciosoDia;
	}

	public double getPorcentTempoOciosoDia() {
		return porcentTempoOciosoDia;
	}

	public void setPorcentTempoOciosoDia(double porcentTempoOciosoDia) {
		this.porcentTempoOciosoDia = porcentTempoOciosoDia;
	}
	
}
