package br.com.callink.cad.repository.to;


public class RelatorioDadosTempoGeralTOTela implements Comparable<RelatorioDadosTempoGeralTOTela> {

	private int posicao;
	
	private String titulo;
	private String valorTotal;
	private long valorTotalSomaLong;
	private double valorTotalSomaDouble;
	private String valor1;
	private String valor2;
	private String valor3;
	private String valor4;
	private String valor5;
	private String valor6;
	private String valor7;
	private String valor8;
	private String valor9;
	private String valor10;
	private String valor11;
	private String valor12;
	private String valor13;
	private String valor14;
	private String valor15;
	private String valor16;
	private String valor17;
	private String valor18;
	private String valor19;
	private String valor20;
	private String valor21;
	private String valor22;
	private String valor23;
	private String valor24;
	private String valor25;
	private String valor26;
	private String valor27;
	private String valor28;
	private String valor29;
	private String valor30;
	private String valor31;
	
	
	public RelatorioDadosTempoGeralTOTela(String titulo, String inicializa, int posicao) {
		super();
		
		this.posicao = posicao;
		
		this.titulo = titulo;
		
		valorTotal = inicializa;
		valor1 = inicializa;
		valor2 = inicializa;
		valor3 = inicializa;
		valor4 = inicializa;
		valor5 = inicializa;
		valor6 = inicializa;
		valor7 = inicializa;
		valor8 = inicializa;
		valor9 = inicializa;
		valor10 = inicializa;
		valor11 = inicializa;
		valor12 = inicializa;
		valor13 = inicializa;
		valor14 = inicializa;
		valor15 = inicializa;
		valor16 = inicializa;
		valor17 = inicializa;
		valor18 = inicializa;
		valor19 = inicializa;
		valor20 = inicializa;
		valor21 = inicializa;
		valor22 = inicializa;
		valor23 = inicializa;
		valor24 = inicializa;
		valor25 = inicializa;
		valor26 = inicializa;
		valor27 = inicializa;
		valor28 = inicializa;
		valor29 = inicializa;
		valor30 = inicializa;
		valor31 = inicializa;
	}


	public int getPosicao() {
		return posicao;
	}

	public void setPosicao(int posicao) {
		this.posicao = posicao;
	}

	public String getTitulo() {
		return titulo;
	}


	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}


	public String getValorTotal() {
		return valorTotal;
	}


	public void setValorTotal(String valorTotal) {
		this.valorTotal = valorTotal;
	}
	
	public long getValorTotalSomaLong() {
		return valorTotalSomaLong;
	}


	public void setValorTotalSomaLong(long valorTotalSomaLong) {
		this.valorTotalSomaLong = valorTotalSomaLong;
	}


	public double getValorTotalSomaDouble() {
		return valorTotalSomaDouble;
	}


	public void setValorTotalSomaDouble(double valorTotalSomaDouble) {
		this.valorTotalSomaDouble = valorTotalSomaDouble;
	}


	public String getValor1() {
		return valor1;
	}


	public void setValor1(String valor1) {
		this.valor1 = valor1;
	}


	public String getValor2() {
		return valor2;
	}


	public void setValor2(String valor2) {
		this.valor2 = valor2;
	}


	public String getValor3() {
		return valor3;
	}


	public void setValor3(String valor3) {
		this.valor3 = valor3;
	}


	public String getValor4() {
		return valor4;
	}


	public void setValor4(String valor4) {
		this.valor4 = valor4;
	}


	public String getValor5() {
		return valor5;
	}


	public void setValor5(String valor5) {
		this.valor5 = valor5;
	}


	public String getValor6() {
		return valor6;
	}


	public void setValor6(String valor6) {
		this.valor6 = valor6;
	}


	public String getValor7() {
		return valor7;
	}


	public void setValor7(String valor7) {
		this.valor7 = valor7;
	}


	public String getValor8() {
		return valor8;
	}


	public void setValor8(String valor8) {
		this.valor8 = valor8;
	}


	public String getValor9() {
		return valor9;
	}


	public void setValor9(String valor9) {
		this.valor9 = valor9;
	}


	public String getValor10() {
		return valor10;
	}


	public void setValor10(String valor10) {
		this.valor10 = valor10;
	}


	public String getValor11() {
		return valor11;
	}


	public void setValor11(String valor11) {
		this.valor11 = valor11;
	}


	public String getValor12() {
		return valor12;
	}


	public void setValor12(String valor12) {
		this.valor12 = valor12;
	}


	public String getValor13() {
		return valor13;
	}


	public void setValor13(String valor13) {
		this.valor13 = valor13;
	}


	public String getValor14() {
		return valor14;
	}


	public void setValor14(String valor14) {
		this.valor14 = valor14;
	}


	public String getValor15() {
		return valor15;
	}


	public void setValor15(String valor15) {
		this.valor15 = valor15;
	}


	public String getValor16() {
		return valor16;
	}


	public void setValor16(String valor16) {
		this.valor16 = valor16;
	}


	public String getValor17() {
		return valor17;
	}


	public void setValor17(String valor17) {
		this.valor17 = valor17;
	}


	public String getValor18() {
		return valor18;
	}


	public void setValor18(String valor18) {
		this.valor18 = valor18;
	}


	public String getValor19() {
		return valor19;
	}


	public void setValor19(String valor19) {
		this.valor19 = valor19;
	}


	public String getValor20() {
		return valor20;
	}


	public void setValor20(String valor20) {
		this.valor20 = valor20;
	}


	public String getValor21() {
		return valor21;
	}


	public void setValor21(String valor21) {
		this.valor21 = valor21;
	}


	public String getValor22() {
		return valor22;
	}


	public void setValor22(String valor22) {
		this.valor22 = valor22;
	}


	public String getValor23() {
		return valor23;
	}


	public void setValor23(String valor23) {
		this.valor23 = valor23;
	}


	public String getValor24() {
		return valor24;
	}


	public void setValor24(String valor24) {
		this.valor24 = valor24;
	}


	public String getValor25() {
		return valor25;
	}


	public void setValor25(String valor25) {
		this.valor25 = valor25;
	}


	public String getValor26() {
		return valor26;
	}


	public void setValor26(String valor26) {
		this.valor26 = valor26;
	}


	public String getValor27() {
		return valor27;
	}


	public void setValor27(String valor27) {
		this.valor27 = valor27;
	}


	public String getValor28() {
		return valor28;
	}


	public void setValor28(String valor28) {
		this.valor28 = valor28;
	}


	public String getValor29() {
		return valor29;
	}


	public void setValor29(String valor29) {
		this.valor29 = valor29;
	}


	public String getValor30() {
		return valor30;
	}


	public void setValor30(String valor30) {
		this.valor30 = valor30;
	}


	public String getValor31() {
		return valor31;
	}


	public void setValor31(String valor31) {
		this.valor31 = valor31;
	}
	
	@Override
	public int compareTo(RelatorioDadosTempoGeralTOTela relatorioDinamicoTempoGeralTO) {
        if(this.getPosicao() > relatorioDinamicoTempoGeralTO.getPosicao()){
            return 1;
        }
        else if(this.getPosicao() < relatorioDinamicoTempoGeralTO.getPosicao()){
            return -1;
        }
        return 0;
    }
}
