package br.com.callink.cad.repository.to;


public class RelatorioDinamicoTempoGeralTO implements Comparable<RelatorioDinamicoTempoGeralTO> {

	
	private Integer idStatus;
	private String status;
	private long tempo;
	
	
	public Integer getIdStatus() {
		return idStatus;
	}
	public void setIdStatus(Integer idStatus) {
		this.idStatus = idStatus;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public long getTempo() {
		return tempo;
	}
	public void setTempo(long tempo) {
		this.tempo = tempo;
	}
	
	@Override
	public int compareTo(RelatorioDinamicoTempoGeralTO relatorioDinamicoTempoGeralTO) {
        if(this.getIdStatus() > relatorioDinamicoTempoGeralTO.getIdStatus()){
            return -1;
        }
        else if(this.getIdStatus() < relatorioDinamicoTempoGeralTO.getIdStatus()){
            return 1;
        }
        return 0;
    }
	
}
