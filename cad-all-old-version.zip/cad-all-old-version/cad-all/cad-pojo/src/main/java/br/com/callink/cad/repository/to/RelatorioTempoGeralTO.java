package br.com.callink.cad.repository.to;

import java.util.List;
import java.util.Map;

public class RelatorioTempoGeralTO {

	private RelatorioDadosTempoGeralTO relatorioDadosTempoGeralTOTotal;
	private List<RelatorioDadosTempoGeralTO> listDadosTempoGeralTOs;
	private Map<Integer, RelatorioDadosTempoGeralTO> mapDiaDadosTempoGeralTOs;
	
	public RelatorioDadosTempoGeralTO getRelatorioDadosTempoGeralTOTotal() {
		return relatorioDadosTempoGeralTOTotal;
	}
	public void setRelatorioDadosTempoGeralTOTotal(RelatorioDadosTempoGeralTO relatorioDadosTempoGeralTOTotal) {
		this.relatorioDadosTempoGeralTOTotal = relatorioDadosTempoGeralTOTotal;
	}
	public List<RelatorioDadosTempoGeralTO> getListDadosTempoGeralTOs() {
		return listDadosTempoGeralTOs;
	}
	public void setListDadosTempoGeralTOs(List<RelatorioDadosTempoGeralTO> listDadosTempoGeralTOs) {
		this.listDadosTempoGeralTOs = listDadosTempoGeralTOs;
	}
	public Map<Integer, RelatorioDadosTempoGeralTO> getMapDiaDadosTempoGeralTOs() {
		return mapDiaDadosTempoGeralTOs;
	}
	public void setMapDiaDadosTempoGeralTOs(Map<Integer, RelatorioDadosTempoGeralTO> mapDiaDadosTempoGeralTOs) {
		this.mapDiaDadosTempoGeralTOs = mapDiaDadosTempoGeralTOs;
	}
	
	
}
