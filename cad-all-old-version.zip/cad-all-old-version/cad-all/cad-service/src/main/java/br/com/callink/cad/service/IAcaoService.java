package br.com.callink.cad.service;

import java.util.List;

import br.com.callink.cad.dao.IAcaoDAO;
import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.pojo.AcaoComando;
import br.com.callink.cad.pojo.Comando;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 * @author Rogério Moreira de Andrade. [rogeriom@swb.com.br]
 */
public interface IAcaoService extends IGenericGboService<Acao, IAcaoDAO> {

	/**
	 * Busca ativos
	 */
	List<Acao> findAtivos() throws ServiceException;

	/**
	 * inativa uma acao
	 * @param acao
	 * @throws ServiceException
	 * @throws ValidationException 
	 */
	void inativar(Acao acao) throws ServiceException, ValidationException;

	/**
	 * Associa Acao com Comando
	 * @param acaoComando
	 * @throws ServiceException
	 * @throws ValidationException 
	 */
	void associa(AcaoComando acaoComando) throws ServiceException, ValidationException;

	/**
	 * Associa uma Lista de Acao e Comando
	 * @param acaoComando
	 * @throws ServiceException
	 */
	void associa(List<AcaoComando> acaoComando) throws ServiceException;

	/**
	 * Exclui uma associado entre Acao e Comando
	 * @param acaoComando
	 * @throws ServiceException
	 */
	void excluiAssociacao(AcaoComando acaoComando) throws ServiceException;

	/**
	 * Busca AcaoComando pelo Comando
	 * @param comando
	 * @return
	 * @throws ServiceException
	 * @throws ValidationException 
	 */
	List<AcaoComando> findByComando(Comando comando) throws ServiceException, ValidationException;

	/**
	 * Busca AcaoComando pela Acao
	 * @param acao
	 * @return
	 * @throws ServiceException
	 * @throws ValidationException 
	 */
	List<AcaoComando> findByAcao(Acao acao) throws ServiceException, ValidationException;

	/**
	 * Busca AcaoComando pela Acao e pelo Comando
	 * @param acao
	 * @param comando
	 * @return
	 * @throws ServiceException
	 * @throws ValidationException 
	 */
	List<AcaoComando> find(Acao acao, Comando comando) throws ServiceException, ValidationException;

	/**
	 * Busca todos os AcaoComando
	 * @return
	 * @throws ServiceException
	 * @throws ValidationException 
	 */
	List<AcaoComando> findAllAcaoComando() throws ServiceException, ValidationException;
	
	/**
	 * Busca todos os acaoComando ativos.
	 * @return
	 * @throws ServiceException
	 */
	List<AcaoComando> findAllAcaoComandoAtivos() throws ServiceException;
	
	/**
	 * Busca AcaoComando.
	 * @param acao
	 * @param comando
	 * @return
	 * @throws ServiceException
	 * @throws ValidationException 
	 */
	List<AcaoComando> findByExample(Acao acao, Comando comando) throws ServiceException, ValidationException;

	/**
	 * Retorna uma Acao pelo nome
	 * @param acao
	 * @return Acao
	 * @throws ServiceException
	 */
	Acao findByNome(Acao acao) throws ServiceException;

	List<Acao> findByExample(Acao acao, String order) throws ServiceException;
	
}
