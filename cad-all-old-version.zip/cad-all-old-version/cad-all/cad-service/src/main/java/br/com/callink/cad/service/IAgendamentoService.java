package br.com.callink.cad.service;

import java.util.List;

import br.com.callink.cad.dao.IAgendamentoDAO;
import br.com.callink.cad.pojo.Agendamento;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 * @author Rogério Moreira de Andrade. [rogeriom@swb.com.br]
 */
public interface IAgendamentoService extends IGenericGboService<Agendamento, IAgendamentoDAO> {

	/**
	 * 
	 */
    List<Agendamento> findAtivos() throws ServiceException;

    /**
     * 
     * @param agendamento
     * @throws ServiceException
     * @throws ValidationException 
     */
    void inativar(Agendamento agendamento) throws ServiceException, ValidationException;
    
    /**
     * Desativa o agendamento de um caso
     * @param caso
     * @throws ServiceException
     * @throws ValidationException 
     */
    void inativar(Caso caso) throws ServiceException, ValidationException;

    /**
	 * Busca um List de Agendamento pelo {@link Caso}
     * @param caso
     * @return List<Agendamento>
     * @throws ServiceException
     */
	List<Agendamento> buscaPeloCaso(Caso caso) throws ServiceException;

	/**
	 * Busca um List de Agendamento ativos pelo {@link Caso} 
	 * @param caso
	 * @return List<Agendamento>
	 * @throws ServiceException
	 */
	List<Agendamento> buscaAtivosPeloCaso(Caso caso) throws ServiceException;
}
