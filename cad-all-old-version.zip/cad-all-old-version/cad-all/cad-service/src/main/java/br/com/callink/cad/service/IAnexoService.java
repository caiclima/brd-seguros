package br.com.callink.cad.service;

import java.util.List;

import br.com.callink.cad.dao.IAnexoDAO;
import br.com.callink.cad.pojo.Anexo;
import br.com.callink.cad.pojo.GrupoAnexo;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 * @author Ednaldo Caic [ednaldo@swb.com.br]
 */
public interface IAnexoService extends IGenericGboService<Anexo, IAnexoDAO> {

    /**
     * Persiste na base de dados todos os Anexos 
     * @param anexo
     * @throws ServiceException
     * @throws ValidationException 
     */
    void saveAll(List<Anexo> anexo) throws ServiceException, ValidationException;

    /**
     * Busca todos os Anexos vinculados a um grupo
     * @param grupoAnexo
     * @return
     * @throws ServiceException 
     */
    List<Anexo> buscaPorGrupoAnexo(GrupoAnexo grupoAnexo) throws ServiceException;
    
    List<Anexo> carregaBytesAnexo(List<Anexo> anexos) throws ServiceException;
}
