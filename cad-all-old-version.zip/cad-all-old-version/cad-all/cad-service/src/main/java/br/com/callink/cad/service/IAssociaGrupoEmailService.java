/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.service;

import java.util.List;

import br.com.callink.cad.dao.IAssociaGrupoEmailDAO;
import br.com.callink.cad.pojo.AssociaGrupoEmail;
import br.com.callink.cad.pojo.EnderecoEmail;
import br.com.callink.cad.pojo.GrupoEmail;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 *
 * @author Luiz Gustavo (luizgf@swb.com.br)
 */
public interface IAssociaGrupoEmailService extends IGenericGboService<AssociaGrupoEmail, IAssociaGrupoEmailDAO> {
    /**
     * 
     * @param grupoEmail
     * @param endereco
     * @return
     * @throws ServiceException 
     */
    List<AssociaGrupoEmail> findByGrupoEmailEnderecoEmail(GrupoEmail grupoEmail, EnderecoEmail endereco) throws ServiceException;
    
    /**
     * 
     * @param listaGrupoEmail
     * @param mostrarDescricaoGrupoEmail
     * @return
     * @throws ServiceException 
     * @throws ValidationException 
     */
    String getDestinatariosFromListaGrupoEmail(List<GrupoEmail> listaGrupoEmail, Boolean mostrarDescricaoGrupoEmail) throws ServiceException, ValidationException;
    
    /**
     * 
     * @param grupoEmail
     * @return
     * @throws ServiceException 
     * @throws ValidationException 
     */
    String getDestinatariosFromGrupoEmail(GrupoEmail grupoEmail) throws ServiceException, ValidationException;
    
    /**
     * 
     * @param grupoEmail
     * @param enderecoEmailList
     * @throws ServiceException 
     * @throws ValidationException 
     */
    void saveGrupoEmails(GrupoEmail grupoEmail, List<EnderecoEmail> enderecoEmailList) throws ServiceException, ValidationException;
    
    /**
     * 
     * @param grupoEmail
     * @throws ServiceException 
     */
    void deletaAssociacoes(GrupoEmail grupoEmail) throws ServiceException;
}
