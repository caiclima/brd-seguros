package br.com.callink.cad.service;


import java.util.List;
import br.com.callink.cad.dao.IAtendenteDAO;
import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.pojo.Equipe;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 * @author Rogerio Moreira [rogeriom@swb.com.br]
 * 
 */
public interface IAtendenteService extends IGenericGboService<Atendente, IAtendenteDAO> {


	/**
	 * Retorna todos os Atendentes cadastrados na base de dados
	 * @throws ServiceException
	 */
    List<Atendente> findAtivos() throws ServiceException;
    
    /**
     * Atualiza o Atendente para Inativo
     * @param atendente
     * @throws ServiceException
     * @throws ValidationException 
     */
    void inativar(Atendente atendente) throws ServiceException, ValidationException;

    /**
     * Retorna um Atendente pelo login
     * @param login
     * @return
     * @throws ServiceException
     */
	Atendente findByLogin(String login) throws ServiceException;
	
	/**
	 * Busca todos os atributos do Atendente preenchendo todos os objetos.
	 * 
	 * @param atendente
	 * @return
	 * @throws ServiceException
	 */
	List<Atendente> findByExampleAll(Atendente atendente) throws ServiceException;

	/**
	 * Retorna um List de Atendente pela {@link configuracaoFila}
	 * @param configuracaoFila
	 * @return
	 * @throws ServiceException
	 */
	List<Atendente> buscaPorFila(ConfiguracaoFila configuracaoFila)
			throws ServiceException;

	/**
	 * Retorna todos os atendentes ativos que nao estao associados a equipe
	 * @return List<Atendente>
	 * @throws ServiceException
	 */
	List<Atendente> buscaAtivosQueNaoPossuemFila() throws ServiceException;

	/**
	 * Valida se o atendente pode atender um caso. Se for um atendente com perfil de supervisor ele irá retornar false.
	 * Se for um atendente com outro perfil o retorno será true;
	 * @param atendente
	 * @return
	 * @throws ServiceException
	 * @throws ValidationException 
	 */
	Boolean validaAtendenteCaso(Atendente atendente) throws ServiceException, ValidationException;
        
        /**
	 * Retorna o Supervisor do Atendente passado pelo parametro;
         * 
	 * @param Atendente
	 * @return Atendente
	 * @throws ServiceException
	 */
        Atendente findSupervisor(Atendente atendente) throws ServiceException;
 
        /**
         * Verifica se o login informado pertence a um supervisor. 
         * @param loginSupervisor
         * @return
         * @throws ServiceException 
         */
        Boolean validaLoginSupervisor(String loginSupervisor) throws ServiceException;
        
        /**
         * Retorna todos os atendentes vinculados a uma fila
         * @param configuracaoFilaList
         * @return
         * @throws ServiceException 
         */
        List<Atendente> buscaPorConfiguracaoFilaList(List<ConfiguracaoFila> configuracaoFilaList) throws ServiceException ;
        
        /**
         * Retorna todos os Atendentes vinculados a @link{equipeList}
         * @param equipeList
         * @return
         * @throws ServiceException 
         */
        List<Atendente> buscaPorEquipeList(List<Equipe> equipeList) throws ServiceException ;

        /**
         * 
         * @param equipe
         * @return
         * @throws ServiceException
         */
		List<Atendente> buscaAtendentesPorEquipe(Equipe equipe)
				throws ServiceException;
		
		List<Atendente> findAll(String order) throws ServiceException;

		/**
		 * @param idsAtendentes
		 * @return
		 * @throws ServiceException
		 */
		List<Atendente> findByPkIn(List<Integer> idsAtendentes) throws ServiceException;
        
}
