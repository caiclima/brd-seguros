package br.com.callink.cad.service;

import java.util.List;

import br.com.callink.cad.dao.IAtendenteStatusDAO;
import br.com.callink.cad.pojo.AtendenteStatus;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 *
 * @author brunomt
 */
public interface IAtendenteStatusService extends IGenericGboService<AtendenteStatus, IAtendenteStatusDAO> {
    
    /**
     * Inativar um status.
     * @param atendenteStatus
     * @throws ServiceException 
     * @throws ValidationException 
     */
    void inativar(AtendenteStatus atendenteStatus) throws ServiceException, ValidationException;
    
    /**
     * 
     * @return
     * @throws DataExceptio 
     */
    List<AtendenteStatus> buscaAtendenteStatusPausado() throws ServiceException;

    /**
     * Busca o status correspondente utilizado no GBO
     * @param idStatusToolbar
     * @return
     * @throws ServiceException
     */
	AtendenteStatus buscaAtendenteStatusIdToolbar(Integer idStatusToolbar)
			throws ServiceException;
	
	List<AtendenteStatus> findByExample(AtendenteStatus example, String order) throws ServiceException;
}
