package br.com.callink.cad.service;


import java.util.List;
import java.util.Map;

import br.com.callink.cad.dao.IAtendimentoCasoDAO;
import br.com.callink.cad.pojo.AtendimentoCaso;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.Status;
import br.com.callink.cad.service.exception.ServiceException;

/**
 * @author Rogério Moreira de Andrade. [rogeriom@swb.com.br]
 */
public interface IAtendimentoCasoService extends IGenericGboService<AtendimentoCaso, IAtendimentoCasoDAO> {
	
	/**
	 * Busca todos os AtendimentoCaso pelo Caso
	 * @param caso
	 * @return List<AtendimentoCaso>
	 * @throws ServiceException
	 */
	List<AtendimentoCaso> findAtendimentoCasoByCaso(Caso caso)	throws ServiceException;

	/**
	 * 
	 * @param caso
	 * @return Map<Status, Float> 
	 * @throws ServiceException
	 */
	Map<Status, Float> calculaTempoAtendimentoByCaso(Caso caso) throws ServiceException;


    
}
