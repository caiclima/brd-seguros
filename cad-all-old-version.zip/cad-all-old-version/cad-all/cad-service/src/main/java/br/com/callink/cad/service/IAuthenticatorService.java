/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.service;

import br.com.callink.cad.service.exception.ServiceException;


/**
 *
 * @author ubuntu
 */
public interface IAuthenticatorService {

    /**
     * Autentica o usuário. Caso não seja possível é retornada uma exception.
     * @param usuario
     * @param senha
     * @param authenticatorService
     * @throws ServiceException 
     */
    void authentica(String usuario, String senha, String authenticatorService) throws ServiceException;
}
