/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.service;

import java.util.List;

import br.com.callink.cad.dao.ICabUphDAO;
import br.com.callink.cad.pojo.CabUph;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.pojo.MetaUph;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 *
 * @author swb.miller
 */
public interface ICabUphService extends  IGenericGboService<CabUph, ICabUphDAO> {
    
    /**
     * busca configuraçoes de metas de acordo com a fila
     * 
     * @param fila
     * @return
     * @throws ServiceException 
     */
    List<CabUph> findLlistByConfFila(ConfiguracaoFila fila) throws ServiceException;
    
    /**
     * salva uma configuracao parametrizada de uma fila com sua respectivas metas
     * 
     * @param listMetas
     * @param cabUph
     * @throws ServiceException 
     * @throws ValidationException 
     */
    void salvaMetasParametrizadas(List<MetaUph> listMetas, CabUph cabUph) throws ServiceException, ValidationException;
    
    /**
     * regra para atualizacao de uma meta
     * 
     * @param listMetas
     * @param cabUph
     * @throws ServiceException 
     * @throws ValidationException 
     */
    void salvaNovaMetaParametrizada(List<MetaUph> listMetas, CabUph cabUphAntigo,CabUph cabUphNovo ) throws ServiceException, ValidationException;
    
    /**
     * 
     * @param fila
     * @return
     * @throws ServiceException
     */
	CabUph findUltimaMetaConfigura(ConfiguracaoFila fila) throws ServiceException;

	/**
	 * 
	 * @param descricao
	 * @param fila
	 * @param meta
	 * @return
	 * @throws ServiceException
	 */
	List<CabUph> findCabUphList(String descricao, ConfiguracaoFila fila,
			Double meta) throws ServiceException;

}
