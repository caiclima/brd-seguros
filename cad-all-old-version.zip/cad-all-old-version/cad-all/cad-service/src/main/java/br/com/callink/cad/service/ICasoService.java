package br.com.callink.cad.service;

import java.util.Date;
import java.util.List;

import br.com.callink.cad.dao.ICasoDAO;
import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.pojo.Status;
import br.com.callink.cad.repository.to.AtendenteCasoStatusTO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 * Service para um {@link Caso}
 * @author brunomt [brunoam@swb.com.br]
 *
 */
/**
 * @author swb_samuel
 *
 */
public interface ICasoService extends IGenericGboService<Caso, ICasoDAO> {
	
	void flush();

    /**
     * Busca os casos de uma fila ordenando os mesmos pela regra configurada. Se não existir nenhuma configuração
     * os casos serão ordenados pela propriedade dataInicio.
     * 
     * @param configuracaoFila
     * @return
     * @throws ServiceException
     * @throws ValidationException 
     */
    List<Caso> buscaCasosFiltroPorFilaSemAtendente(ConfiguracaoFila configuracaoFila) throws ServiceException, ValidationException;
    
    /**
     * Busca os casos de uma fila ordenando os mesmos pela regra configurada. Se não existir nenhuma configuração
     * os casos serão ordenados pela propriedade dataInicio.
     * 
     * @param configuracaoFila
     * @return
     * @throws ServiceException
     * @throws ValidationException 
     */
    List<Caso> buscaCasosFiltroPorFilaSemAtendente(ConfiguracaoFila configuracaoFila, Integer top) throws ServiceException, ValidationException;

    /**
     * Busca todos os casos que estão ativos na fila de um atendente.
     * @param atendente
     * @return
     * @throws ServiceException
     */
    List<Caso> buscaTodosCasosAtivosAtendente(Atendente atendente) throws ServiceException;

    /**
     * Calcula e seta a variavel slaEmMinutos. A data deve ser informada para realizar o calculo do sla. Essa data sera utilizada
     * para casos que não foram fechados. 
     * @param caso
     * @param data
     * @return
     * @throws ServiceException
     */
    Caso calculaSla(Caso caso, Date data) throws ServiceException;

    /**
     * Calcula e seta a variavel slaEmMinutos de todos os casos da lista. 
     * @param List
     * @return
     * @throws ServiceException
     */
    List<Caso> carregaSlas(List<Caso> casos) throws ServiceException;
    
    /**
     * Retira a fila de todos os casos que não estão em atendimento, ou seja, que não tem nenhum atendente vinculado
     * Também atualiza o flag_classifica para 1 para que o caso possa ser reclassificado pelo processo de classificação de casos.
     * 
     * @param configuracaoFila
     * @throws ServiceException
     */
    void retiraFilaCaso(ConfiguracaoFila configuracaoFila) throws ServiceException;
    
    /**
     * Busca os casos ordenados por fila.
     * Retorna uma lista de casos para ser o buffer. Essa lista é feita pelo ORDER cadastrado para a fila. Caso não tenha nenhum ORDER os
     * casos serão ordenados pela data de abertura do mesmo.
     * @param confFila
     * @param quantidadeCasos
     * @return
     * @throws ServiceException
     * @throws ValidationException 
     */
    List<Caso> buscaCasosOrdernadosPorFilaSemAtendente(ConfiguracaoFila confFila, Integer quantidadeCasos) throws ServiceException, ValidationException;
    
    /**
     * Retorna o agendamento com a menor data. Após o caso ser retornado o agendamento será cancelado.
     * 
     * @param atendente
     * @return
     * @throws ServiceException
     * @throws ValidationException 
     */
    Caso buscaCasoAgendado(Atendente atendente) throws ServiceException, ValidationException;

    /**
	 * Busca todos os cados ativos pela {@link ConfiguracaoFila}
     * @param configuracaoFila
	 * @return List<Caso>
     * @throws ServiceException
     */
	List<Caso> buscaCasosAtivosPorConfiguracaoFila(ConfiguracaoFila configuracaoFila) throws ServiceException;

	/**
	 * Busca todos os casos por {@link Status}
	 * @param status
	 * @return List<Caso> 
	 * @throws ServiceException
	 */
	List<Caso> buscaPorStatus(Status status) throws ServiceException;

	/**
	 * Retorna o Caso se o tempo de Sla for maior do que o parametro
	 * @param caso
	 * @param slaParam
	 * @return
	 * @throws ServiceException
	 */
	Caso verificaSlaMaiorParametro(Caso caso, long slaParam)
			throws ServiceException;

	/**
	 * Verifica qual o proximo caso agendado para uma lista de filas. A primeira fila da lista que possuir o caso será atendida.
	 * @param confList
	 * @return
	 * @throws ServiceException
	 */
	Caso buscaProximoCasoAgendadoFila(List<ConfiguracaoFila> confList) throws ServiceException;
        
        /**
         * Busca todos os casos ativos no sistema. Após isso verifica se o caso ficou mais do que um tempo Parametrizado no sistema sem
         * ter nenhum andamento, se o caso ficar mais que esse tempo ele será retirado do analista e irá voltar para a fila para que outro
         * analista possa dar tratativa para esse caso.
         * 
         * @return
         * @throws ServiceException 
         * @throws ValidationException 
         */
        Boolean retiraCasoAtendentesInativos() throws ServiceException, ValidationException;
        
        /**
         * Busca os casos ativos e que não foram finalizados.
         * 
         * @return
         * @throws ServiceException 
         */
        List<Caso> buscaCasoEmAtendimento() throws ServiceException;
        
        
        /**
         * Carrega os Emails de um caso
         */
        List<Caso> carregaEmails(List<Caso> casos) throws ServiceException;
        
        /**
         * Carrega o ícone dos emails de um caso
         * @param casos
         * @return
         * @throws ServiceException 
         */
        List<Caso> carregaIconeEmails(List<Caso> casos) throws ServiceException;

        /**
         * Finaliza o caso
         * @param caso
         * @param userLogin
         * @throws ServiceException 
         * @throws ValidationException 
         */
        void finalizaCaso(Caso caso, String userLogin) throws ServiceException, ValidationException;
        
        /**
         * Realiza o update no caso e grava log quando o caso é delegado.
         * @param caso
         * @param supervisorLogin
         * @throws ServiceException 
         */
        void delegaCasoAtendente(Caso caso, Atendente atendente ,String supervisorLogin) throws ServiceException, ValidationException;

        /**
         * 
         * @param caso
         * @param slaParam
         * @return
         * @throws ServiceException
         */
		Caso verificaSlaMenorParametro(Caso caso, long slaParam)
				throws ServiceException;

		/**
		 * 
		 * @param idAtendente
		 * @param idFila
		 * @param dataInicial
		 * @param dataFinal
		 * @return
		 * @throws ServiceException
		 */
		Integer quantidadeCasosFechados(Integer idAtendente, Integer idFila,
				Date dataInicial, Date dataFinal) throws ServiceException;

		/**
		 * Busca todos os casos reabertos que precisam ser reclassificados.
		 * @return
		 * @throws ServiceException
		 */
		List<Caso> buscaCasoReclassificaReabertura() throws ServiceException;
        
		/**
		 * Busca todos os casos em atendimento de um determinado atendente.
		 * @param atendente
		 * @return
		 * @throws DataException
		 */
		List<Caso> findCasoEmAtendimento(Atendente atendente) throws ServiceException;

		/**
	     * Atualiza flagEmAtendimento para false por uma determinada lista de atendentes
	     * 
	     * @param listaAtendente
	     * @throws DataException
	     */
		void atualizaFlagEmAtendimentoParaFalse(List<Atendente> listaAtendente) throws ServiceException;

		/**
		 * Verifica se o caso está em atendimento
		 * 
		 * @param caso
		 * @return
		 * @throws ServiceException
		 */
		boolean casoEstaEmAtendimento(Caso caso) throws ServiceException;

		/**
		 * Valida o statu do caso. Se o status do caso enviado for diferente do caso que está na base de dados o retorno será FALSE. 
		 * Se for o mesmo status ele retorna true;
		 * 
		 * @param caso
		 * @return
		 * @throws ServiceException
		 * @throws ValidationException 
		 */
		boolean validaStatusCaso(Caso caso) throws ServiceException, ValidationException;

		/**
		 * Retorna se os casos em atendimento para um atendente. (Normalmente deve ser retornado apenas um caso) 
		 * @param loginAtendente
		 * @return
		 * @throws ServiceException
		 */
		List<Caso> atendentePossuiCasoEmAtendimento(String loginAtendente)	throws ServiceException;

		/**
		 * Valida se o Caso esta sendo processado pelo SPA
		 * @param caso
		 * @return boolean
		 * @throws ServiceException
		 */
		boolean validaSeCasoEstaSendoProcessadoPeloSpa(Caso caso) throws ServiceException;
		
		/**
		 * Busca os casos que tem seu SLA finalizado no dia atual
		 * @return
		 */
		List<Caso> buscaCasosSLAFimDia() throws ServiceException;
		
		/**
		 * Busca todos os casos com SLA FIM na data informada
		 * @param data
		 * @return
		 * @throws DataException
		 */
		List<Caso> buscaCasosSLAFimDia(Date dataBusca) throws ServiceException;

		
		/**
	     * Atualiza flagEmAtendimento para false por um atendente
	     * 
	     * @param atendente
	     * @throws DataException
	     */
		void atualizaFlagEmAtendimentoParaFalse(Atendente atendente) throws ServiceException;

		/**
		 * Carrega SLA de um caso
		 * @param data
		 * @param caso
		 * @return
		 * @throws ServiceException
		 */
		Caso carregaSla(Date data, Caso caso) throws ServiceException;

		/**
		 * Carrega se o caso possui email e o SLA
		 * @param caso
		 * @return
		 * @throws ServiceException
		 */
		Caso carregaSlaEmailCaso(Caso caso) throws ServiceException;
		
		/**
		 * @return
		 * @throws ServiceException
		 */
		List<AtendenteCasoStatusTO> buscarQuantidadeCasosAtendidosPorStatus() throws ServiceException;

	/**
	 * retorna todos os casos pendentes do cliente inclusive o caso recebido como parâmetro, que estejam em uma das filas configuradas para o atendente
	 * 
	 * @param atendente
	 * @param idCaso
	 * @return
	 * @throws ServiceException
	 */
	List<Caso> buscarTodosCasosPendentesDoCliente(Atendente atendente, Integer idCaso) throws ServiceException;
	
	/**
	 * retorna Caso de acordo com o idExterno passado
	 * 
	 * @param idExterno
	 * @return
	 * @throws ServiceException
	 */
	Caso buscarCasoPorIdExterno(String idExterno) throws ServiceException;

	/**
	 * atualiza a data de vencimento do sla dos casos abertos ou fechados, de acordo com o parametro passado
	 * 
	 * @param casosFinalizados
	 * @return
	 * @throws ServiceException
	 */
	void atuaizarVencimentoSlaByFinalizado(Boolean casosFinalizados) throws ServiceException;
	
	/**
	 * 
	 * @return
	 * @throws ServiceException
	 */
	List<String> buscaColunasTabelaCaso() throws ServiceException;
		
}
