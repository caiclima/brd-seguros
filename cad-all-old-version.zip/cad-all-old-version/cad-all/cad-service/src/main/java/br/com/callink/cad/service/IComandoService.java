package br.com.callink.cad.service;

import java.util.List;

import br.com.callink.cad.dao.IComandoDAO;
import br.com.callink.cad.pojo.Comando;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 * @author Rogério Moreira de Andrade. [rogeriom@swb.com.br]
 */
public interface IComandoService extends IGenericGboService<Comando, IComandoDAO> {

    List<Comando> findAtivos() throws ServiceException;

    void inativar(Comando comando) throws ServiceException, ValidationException;
    
    List<Comando> findByExample(Comando example, String order) throws ServiceException;
}
