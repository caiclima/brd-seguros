package br.com.callink.cad.service;


import java.util.List;
import java.util.Properties;

import br.com.callink.cad.dao.IConfiguracaoEmailDAO;
import br.com.callink.cad.pojo.ConfiguracaoEmail;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

public interface IConfiguracaoEmailService extends IGenericGboService<ConfiguracaoEmail, IConfiguracaoEmailDAO> {

	/**
	 * Inativar uma parceiro
	 * @param parceiro
	 * @throws ServiceException 
	 */
	void inativar(ConfiguracaoEmail configuracaoEmail) throws ServiceException;
	void validarSave(ConfiguracaoEmail configuracaoEmail) throws ValidationException;
	void validarUpdate(ConfiguracaoEmail configuracaoEmail) throws ValidationException;
	void validarDelete(ConfiguracaoEmail object) throws ValidationException;
	List<ConfiguracaoEmail> findByExample(ConfiguracaoEmail example,  String order) throws ServiceException;
	Properties enviaEmailProperties(ConfiguracaoEmail configuracaoEmail);
	List<ConfiguracaoEmail> findByIds(List<Integer> ids) throws ServiceException;
	ConfiguracaoEmail buscarConfPrincipal() throws ServiceException;
}
