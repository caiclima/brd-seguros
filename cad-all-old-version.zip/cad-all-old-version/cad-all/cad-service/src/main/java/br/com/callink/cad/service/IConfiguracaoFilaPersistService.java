package br.com.callink.cad.service;

import java.util.List;

import br.com.callink.cad.dao.IConfiguracaoFilaDAO;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.service.exception.ServiceException;

/**
 * 
 * @author bruno.camargo
 *
 */
public interface IConfiguracaoFilaPersistService extends IGenericGboService<ConfiguracaoFila, IConfiguracaoFilaDAO> {
	

	public void persistClassificaCasos(List<Caso> casoList, ConfiguracaoFila confFila) throws ServiceException;

	void removeCasosFilasBuild(List<ConfiguracaoFila> configuracaoFilas)
			throws ServiceException;
}
