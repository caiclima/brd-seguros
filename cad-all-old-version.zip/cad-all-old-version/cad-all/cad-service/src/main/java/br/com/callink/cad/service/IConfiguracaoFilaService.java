package br.com.callink.cad.service;

import java.util.List;
import br.com.callink.cad.dao.IConfiguracaoFilaDAO;
import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.pojo.Equipe;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 * @author brunomt [brunoam@swb.com.br]
 */
public interface IConfiguracaoFilaService extends IGenericGboService<ConfiguracaoFila, IConfiguracaoFilaDAO> {
	/**
	 * Verifica se o caso está com o status correto. Se estiver insere o caso na fila desejada.
	 * Se a fila que o caso deve ser inserida não existir o sistema cria essa tabela.
	 * 
	 * @param configuracaoFila
	 * @throws ServiceException
	 */
	void insereCasoNaFila(Caso caso, ConfiguracaoFila configuracaoFila) throws ServiceException;
	
	/**
	 * Busca todas as filas ordenadas
	 * @return
	 * @throws ServiceException
	 */
	List<ConfiguracaoFila> buscaFilaPorPrioridade() throws ServiceException;
	
	/**
	 * Busca todas as filas ativas ordenadas pela prioridade
	 * @return
	 * @throws ServiceException
	 */
	List<ConfiguracaoFila> buscaFilaAtivaPorPrioridade() throws ServiceException;
	
	/**
	 * Busca as filas que precisam de build por prioridade.
	 * @return
	 * @throws ServiceException
	 */
	List<ConfiguracaoFila> buscaFilaBuildPorPrioridade() throws ServiceException;
	
    /**
     * Responsável por realizar a classificação de todos os casos pendentes e enfileiramento dos mesmos.
     * @throws ServiceException
     */
    void classificaCasos() throws ServiceException;

	/**
	 * Faz os calculos de quantos casos foram atendidos em cada fila do atendente e retorna a próxima fila a ser atendida. O retorno é uma lista ordenada
	 * por prioridade de filas.
	 * @param atendente
	 * @return
	 * @throws ServiceException
	 * @throws ValidationException 
	 */
	List<ConfiguracaoFila> buscaProximaFilaAtendimentoAtendente(Atendente atendente) throws ServiceException, ValidationException;
	
	/**
	 * Inativar uma fila.
	 * @param configuracaoFila
	 * @throws ServiceException
	 * @throws ValidationException 
	 */
	void inativar(ConfiguracaoFila configuracaoFila, String usuario) throws ServiceException, ValidationException;
	
	/**
	 * Aumenta a prioridade da fila para quando for executar o enfileiramento dos casos
	 * @param configuracaoFila
	 * @throws ServiceException
	 * @throws ValidationException 
	 */
	void aumentarPrioridade(ConfiguracaoFila configuracaoFila, String usuario) throws ServiceException, ValidationException;
	
	/**
	 * Diminui a prioridade da fila para quando for executar o enfileiramento dos casos
	 * @param configuracaoFila
	 * @throws ServiceException
	 * @throws ValidationException 
	 */
	void diminuirPrioridade(ConfiguracaoFila configuracaoFila, String usuario) throws ServiceException, ValidationException;

	/**
	 * Remove da tb_fila_classificao_caso o caso pelo id_caso e id_configuracao_fila do caso
	 * @param caso
	 * @throws ServiceException
	 */
	void removeFilaClassificaoCaso(Caso caso) throws ServiceException;

	/**
	 * Busca todas as ConfiguracaoFila que ainda nao foram associadas a {@link Equipe}
	 * @param equipe
	 * @return List<ConfiguracaoFila>
	 * @throws ServiceException
	 */
	List<ConfiguracaoFila> buscaQueAindaNaoForamAdicionadosByEquipe(
			Equipe equipe) throws ServiceException;

	/**
	 * Prepara Reaberturas. Joga casos reabertos ou para próprio analista que fechou o caso ou devolve para a fila!
	 * @throws ServiceException
	 */
	void preparaReaberturasLiberaCasos() throws ServiceException;

	List<ConfiguracaoFila> findByExample(ConfiguracaoFila configuracaoFila,
			String order) throws ServiceException;
	
	List<ConfiguracaoFila> findAll(String order) throws ServiceException;

	/**
	 * @return
	 * @throws ServiceException
	 */
	ConfiguracaoFila buscaConfiguracaoFilaPadraoCasosImportados() throws ServiceException;

}
