package br.com.callink.cad.service;

import br.com.callink.cad.dao.IContatoDAO;
import br.com.callink.cad.pojo.ContatoTelefone;

public interface IContatoService extends IGenericGboService<ContatoTelefone, IContatoDAO> {

}
