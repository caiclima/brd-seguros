/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.service;

import java.util.List;

import br.com.callink.cad.dao.IEmailGrupoEmailDAO;
import br.com.callink.cad.pojo.Email;
import br.com.callink.cad.pojo.EmailGrupoEmail;
import br.com.callink.cad.pojo.GrupoEmail;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 *
 * @author Luiz Gustavo F. (luizgf@swb.com.br)
 */
public interface IEmailGrupoEmailService extends IGenericGboService<EmailGrupoEmail, IEmailGrupoEmailDAO> {   
    void salvaDestinatariosEmail(Email email, List<GrupoEmail> destinatarios) throws ServiceException, ValidationException;
}
