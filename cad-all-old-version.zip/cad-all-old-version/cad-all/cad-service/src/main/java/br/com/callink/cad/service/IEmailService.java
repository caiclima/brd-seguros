/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.service;

import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import br.com.callink.cad.dao.IEmailDAO;
import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.ConfiguracaoEmail;
import br.com.callink.cad.pojo.Email;
import br.com.callink.cad.pojo.GrupoAnexo;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 *
 * @author Luiz Gustavo (luizgf@swb.com.br)
 */
public interface IEmailService extends IGenericGboService<Email, IEmailDAO> {

	/**
	 * Envia um e-mail
	 * @param email
	 * @param caso
	 * @param acao
	 * @throws ServiceException
	 * @throws ValidationException 
	 */
    void envia(Email email, Caso caso, Acao acao) throws ServiceException, ValidationException;

    /**
     * Busca todos os e-mails com envio pendente
     * @return
     * @throws ServiceException
     */
    List<Email> findEmailsEnvioPendente() throws ServiceException;

    /**
     * Busca todos os e-mails do caso
     * @param caso
     * @return
     * @throws ServiceException
     */
    List<Email> findEmailsFromCaso(Caso caso) throws ServiceException;

    /**
     * Verfiica se existe e-mail não lido
     * @param emails
     * @return
     */
    Boolean existemEmailsNaoLidos(List<Email> emails);

    /**
     * Busca todos os e-mails sem caso
     * @return
     * @throws ServiceException
     */
    List<Email> findEmailsSemCaso() throws ServiceException;

    /**
     * Carrega todas as propriedades do e-mail
     * @param casos
     * @throws ServiceException
     */
    void loadEmails(List<Caso> casos) throws ServiceException;

    /**
     * 
     * @param casos
     * @throws ServiceException
     */
    void loadIconeEmails(List<Caso> casos) throws ServiceException;

    /**
     * 
     * @param emails
     * @throws ServiceException
     * @throws ValidationException 
     */
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    void salvaReceivedMails(List<Email> emails) throws ServiceException, ValidationException;

    /**
     * 
     * @return 
     */
    Properties enviaEmailProperties();

    /**
     * 
     * @return 
     */
    Properties recebeEmailProperties();

    /**
     * 
     * @param email
     * @param caso
     * @throws ServiceException 
     * @throws ValidationException 
     */
    void lerEmail(Email email, Caso caso) throws ServiceException, ValidationException;

    /**
     * 
     * @param email
     * @throws ServiceException 
     */
    void updateFlagLido(Email email) throws ServiceException;
    
    /**
     * Associa Email a caso
     * @param email
     * @param caso
     * @param loginAtendente
     * @throws ServiceException 
     * @throws ValidationException 
     */
    void associaEmailCaso(Email email, Caso caso, String loginAtendente) throws ServiceException, ValidationException;
    
    /**
     * Retira o caso da lista.
     * @param email
     * @throws ServiceException
     */
    void updateFlagDesativado(Email email) throws ServiceException;

    /**
     * busca se o caso possui um icon
     * @param caso
     * @throws ServiceException
     */
	void loadIconCaso(Caso caso) throws ServiceException;

	 /**
     * busca os emails do caso de acordo com o flag envio (recebidos ou enviados)
     * @param caso
     * @throws ServiceException
     */
	List<Email> findEmailsFromCasoByFlagEnvio(Caso caso, Boolean flagEnvio) throws ServiceException;
	
	List<Email> findEmailsSemCasoByExample(Email email, Date dataInicio, Date dataFim) throws ServiceException;
	
	String buscarDiretorioAnexos();
	
	List<ConfiguracaoEmail> buscarConfigsEmails() throws ServiceException;
	
	GrupoAnexo salvarGrupoAnexo(Email email, String diretorioAnexo) throws ServiceException;
	
	void associarEmailAoCaso(Email email, Caso caso) throws ValidationException, ServiceException;
	
}
