package br.com.callink.cad.service;

import java.util.List;

import br.com.callink.cad.dao.IEquipeFilaDAO;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.pojo.Equipe;
import br.com.callink.cad.pojo.EquipeFila;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 * 
 * @author brunomt
 *
 */
public interface IEquipeFilaService extends IGenericGboService<EquipeFila, IEquipeFilaDAO> {
	
	/**
	 * Busca as filas ordenadas pela prioridade das mesmas.
	 * @return
	 * @throws ServiceException
	 */
	List<EquipeFila> buscaEquipeFilaPelaPrioridade(Equipe equipe) throws ServiceException;

	/**
	 * Buca EquipeFila unica para uma equipe e configuracaoFila
	 * @param equipe
	 * @param configuracaoFila
	 * @return
	 * @throws ServiceException
	 * @throws ValidationException 
	 */
	EquipeFila buscaByEquipeAndConfiguracaoFila(Equipe equipe, ConfiguracaoFila configuracaoFila) throws ServiceException, ValidationException;

	/**
	 * Retorna um List de EquipeFila pelo {@link equipe} e {@link configuracaoFila}
	 * @param equipe
	 * @param configuracaoFila
	 * @return
	 * @throws ServiceException
	 */
	List<EquipeFila> buscaEquipeFilaListByEquipeEConfiguracaoFila(
			Equipe equipe, ConfiguracaoFila configuracaoFila)
			throws ServiceException;

	/**
	 * Busca um List EquipeFila pela {@equipe} e {@link configuracaoFila} com todos os campos preenchidos
	 * @param equipe
	 * @param configuracaoFila
	 * @return
	 * @throws ServiceException
	 */
	List<EquipeFila> buscaEquipeFilaListByEquipeEConfiguracaoFilaTudo(
			Equipe equipe, ConfiguracaoFila configuracaoFila)
			throws ServiceException; 
        
        /**
         * Busca Todas as EquipeFila Pelo {@link equipeList}
         * @param equipeList
         * @return
         * @throws ServiceException 
         */
        List<EquipeFila> buscaPorEquipeList(List<Equipe> equipeList) throws ServiceException;

        /**
         * 
         * @param equipe
         * @return
         * @throws ServiceException
         */
		List<EquipeFila> findFilasByEquipe(Equipe equipe) throws ServiceException;
        /**
        * Exclui a associação de equipes com filas
        *
        * @param equipe
        * @throws ServiceException
        */
       void limpaEquipeFila(Equipe equipe) throws ServiceException;
}
