package br.com.callink.cad.service;

import java.util.List;

import br.com.callink.cad.dao.IEquipeDAO;
import br.com.callink.cad.pojo.Equipe;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 * @author Rogério Moreira de Andrade. [rogeriom@swb.com.br]
 */
public interface IEquipeService extends IGenericGboService<Equipe, IEquipeDAO> {

    List<Equipe> findAtivos() throws ServiceException;
    
    void inativar(Equipe equipe) throws ServiceException, ValidationException;
    
    List<Equipe> findByExample(Equipe example, String order) throws ServiceException;
}
