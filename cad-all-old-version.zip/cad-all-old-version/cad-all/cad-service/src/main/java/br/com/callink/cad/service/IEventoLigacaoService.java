package br.com.callink.cad.service;

import java.util.List;
import br.com.callink.cad.dao.IEventoLigacaoDAO;
import br.com.callink.cad.pojo.EventoLigacao;
import br.com.callink.cad.service.exception.ServiceException;

public interface IEventoLigacaoService extends IGenericGboService<EventoLigacao, IEventoLigacaoDAO> {

	/**
	 * @param pojo
	 * @return
	 * @throws ServiceException
	 */
	List<EventoLigacao> findAtivosExceto(EventoLigacao pojo) throws ServiceException;

	List<EventoLigacao> findByEvento(EventoLigacao eventoLigacao) throws ServiceException;

}
