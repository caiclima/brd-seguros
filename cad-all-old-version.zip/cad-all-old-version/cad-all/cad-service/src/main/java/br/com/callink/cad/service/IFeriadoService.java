package br.com.callink.cad.service;


import java.util.Date;

import br.com.callink.cad.dao.IFeriadoDAO;
import br.com.callink.cad.pojo.Feriado;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 * @author Ednaldo caic [ednaldo@swb.com.br]
 * @since 27/12/2011
 */
public interface IFeriadoService extends IGenericGboService<Feriado, IFeriadoDAO> {
	
	/**
	 * Grava o Feriado do banco de dados
	 * @param feriado
	 * @throws ServiceException
	 */
	void save(Feriado feriado) throws ServiceException, ValidationException;
	
	public Boolean isFeriado(Date date) throws ServiceException;
    
}
