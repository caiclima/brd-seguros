package br.com.callink.cad.service;

import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.repository.MensagemToolbar;
import br.com.callink.cad.service.exception.ServiceException;


public interface IGboToolbarBusinessAppService {

	/**
	 * Envia menssagem toolbar.
	 * @param mensagemToolbar
	 * @throws ServiceException
	 */
	void enviaMensagemToolbar(MensagemToolbar mensagemToolbar) throws ServiceException;
	
	/**
	 * Envia menssagem toolbar por lista de atendente.
	 * @param mensagemToolbar
	 * @throws ServiceException
	 */
	void enviaMensagemToolbarAtendentes(MensagemToolbar mensagemToolbar) throws ServiceException;

	void enviaPaginaTrativa(String ip, String porta, String userSSO, String host) throws ServiceException;

	void enviaLigacaoToolbar(String telefone, String atendente, Caso caso)	throws ServiceException;

}
