package br.com.callink.cad.service;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import br.com.callink.cad.dao.IGenericCadDAO;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

public interface IGenericGboService<T, DAO extends IGenericCadDAO<T>> extends Serializable {

    /**
     * Localiza todos os objetos do tipo T.
     *
     * @return Colecao de objetos do tipo T.
     * @throws ServiceException
     */
    List<T> findAll() throws ServiceException;

    T findByPk(Object object) throws ServiceException;

    /**
     * Salva um objeto do tipo T.
     *
     * @param object o objeto a ser salvo
     * @throws ServiceException
     */
    void save(final T object) throws ServiceException, ValidationException;

    /**
     * Salva ou atualiza um objeto do tipo T.
     *
     * @param object o objeto a ser salvo ou atualizado.
     * @throws ServiceException LanÃ§ada quando a validacao nao ocorre com
     * sucesso.
     */
    void saveOrUpdate(final T object) throws ServiceException, ValidationException;

    /**
     * Exclui o objeto do tipo T.
     *
     * @param object o objeto a ser excluido
     * @throws ServiceException LanÃ§ada quando a validacao nao ocorre com
     * sucesso.
     */
    void delete(final T object) throws ServiceException, ValidationException;

    /**
     *
     * @param object
     * @return
     * @throws br.com.callink.center.coreutils.service.exception
     */
    T get(final T object) throws ServiceException;

    /**
     * Carrega o objeto do tipo T.
     *
     * @param object objeto do tipo T com o atributo ID setado.
     * @return o objeto do tipo T com todos os atributos preenchidos.
     * @throws ServiceException
     */
    T load(T object) throws ServiceException;

    /**
     * Carrega os objetos com propriedades iguais a que foi passada no objeto de
     * exemplo.
     *
     * @param object
     * @return
     * @throws ServiceException
     */
    List<T> findByExample(T object) throws ServiceException;
    
    /**
     * Carrega os objetos com propriedades iguais a que foi passada no objeto
     * exemplo ordenadas.
     *
     * @param object
     * @param order
     * @return
     * @throws ServiceException
     */
	public List<T> findByExample(T object, String order) throws ServiceException;

    /**
     * Carrega os objetos que possume o campo flag_ativos pela ordem em parametro
     *
     * @param object
     * @return
     * @throws ServiceException
     */
	List<T> findAtivos(String object) throws ServiceException;
	
	/**
     * Salva ou atualiza um objeto do tipo T.
     *
     * @param object o objeto a ser salvo ou atualizado.
     * @throws ServiceException LanÃ§ada quando a validacao nao ocorre com
     * sucesso.
     */
	void update(T object) throws ServiceException, ValidationException;
	
	/**
	 * retorna a data atual do banco de dados
	 * @return
	 * @throws ServiceException
	 */
	Date getDataBanco() throws ServiceException;

	/**
     * Carrega os objetos que possume o campo flag_ativos pela ordem em parametro
     *
     * @param object
     * @return
     * @throws ServiceException
     */
	List<T> findAtivos() throws ServiceException;
}
