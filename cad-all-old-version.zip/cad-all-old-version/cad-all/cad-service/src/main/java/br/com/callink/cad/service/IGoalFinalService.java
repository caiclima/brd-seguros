package br.com.callink.cad.service;

import java.util.List;

import br.com.callink.cad.dao.IGoalFinalDAO;
import br.com.callink.cad.pojo.GoalFinal;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 * 
 * @author miller
 *
 */
public interface IGoalFinalService extends IGenericGboService<GoalFinal, IGoalFinalDAO> {

	/**
	 * 
	 * @return
	 * @throws ServiceException
	 */
	List<GoalFinal> buscaGoalsAtivos() throws ServiceException;

	/**
	 * 
	 * @param goalFinal
	 * @throws ServiceException
	 */
	void saveGoal(GoalFinal goalFinal) throws ServiceException;



	/**
	 * Editar GoalFinal guardando log;
	 * @param List<GoalFinal>
	 * @throws ServiceException
	 * @throws ValidationException 
	 */
	void editarGoalFinal(List<GoalFinal> listGoal) throws ServiceException, ValidationException;

	/**
	 * Verifica se o range de GoalFinal é válido.
	 * 
	 * @param listaValidar
	 * @return true or false
	 */
	boolean validaRangeGoalFinal(List<GoalFinal> listaValidar);

	/**
	 * Buscar histórico goals
	 * @return
	 * @throws ServiceException
	 */
	List<GoalFinal> buscaHistoricoGoals() throws ServiceException;

}
