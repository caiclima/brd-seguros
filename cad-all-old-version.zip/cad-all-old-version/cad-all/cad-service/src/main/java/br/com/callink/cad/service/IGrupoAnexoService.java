package br.com.callink.cad.service;

import br.com.callink.cad.dao.IGrupoAnexoDAO;
import br.com.callink.cad.pojo.GrupoAnexo;
import br.com.callink.cad.service.exception.ServiceException;

/**
 * @author Ednaldo Caic [ednaldo@swb.com.br]
 */
public interface IGrupoAnexoService extends IGenericGboService<GrupoAnexo, IGrupoAnexoDAO> {

	GrupoAnexo buscaPorNome(String nomeGrupo) throws ServiceException;

	
}
