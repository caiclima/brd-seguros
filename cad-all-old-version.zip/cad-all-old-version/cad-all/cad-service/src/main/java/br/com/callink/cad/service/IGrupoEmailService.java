/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.service;

import br.com.callink.cad.dao.IGrupoEmailDAO;
import br.com.callink.cad.pojo.GrupoEmail;
import br.com.callink.cad.service.exception.ServiceException;

import java.util.List;

/**
 *
 * @author Luiz Gustavo (luizgf@swb.com.br)
 */
public interface IGrupoEmailService extends IGenericGboService<GrupoEmail, IGrupoEmailDAO> {
     
	String getDescricaoFromListaGrupoEmail(List<GrupoEmail> listaGrupoEmail);
	
	List<GrupoEmail> findByExample(GrupoEmail grupoEmail, String order) throws ServiceException;
}
