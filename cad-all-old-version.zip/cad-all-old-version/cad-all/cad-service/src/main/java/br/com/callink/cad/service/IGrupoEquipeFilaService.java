/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.service;

import java.util.List;

import br.com.callink.cad.dao.IGrupoEquipeFilaDAO;
import br.com.callink.cad.pojo.GrupoEquipe;
import br.com.callink.cad.pojo.GrupoEquipeFila;
import br.com.callink.cad.service.exception.ServiceException;

/**
 *
 * @author Rogerio
 */
public interface IGrupoEquipeFilaService extends IGenericGboService<GrupoEquipeFila, IGrupoEquipeFilaDAO> {

    /**
     * 
     * @param grupoEquipe
     * @return
     * @throws ServiceException 
     */
    List<GrupoEquipeFila> grupoEquipeFilaList(GrupoEquipe grupoEquipe) throws ServiceException;
    /**
     * 
     * @param grupoEquipe
     * @throws ServiceException 
     */
    void limpaGrupoEquipeFila(GrupoEquipe grupoEquipe) throws ServiceException ;
}
