/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.service;

import java.util.List;

import br.com.callink.cad.dao.IGrupoEquipeDAO;
import br.com.callink.cad.pojo.Equipe;
import br.com.callink.cad.pojo.GrupoEquipe;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 *
 * @author Rogerio
 */
public interface IGrupoEquipeService extends IGenericGboService<GrupoEquipe, IGrupoEquipeDAO> {

    void associaEquipeFila(GrupoEquipe grupoEquipe, List<Equipe> equipes) throws ServiceException, ValidationException;
}
