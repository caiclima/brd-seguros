package br.com.callink.cad.service;

import br.com.callink.cad.dao.IHistoricoDadosCasoDAO;
import br.com.callink.cad.pojo.HistoricoDadosCaso;

/**
 * 
 * @author brunomt
 */
public interface IHistoricoDadosCasoService extends IGenericGboService<HistoricoDadosCaso, IHistoricoDadosCasoDAO>{

}
