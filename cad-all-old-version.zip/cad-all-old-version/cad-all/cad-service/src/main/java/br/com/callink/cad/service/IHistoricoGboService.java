package br.com.callink.cad.service;


import br.com.callink.cad.dao.IHistoricoGboDAO;
import br.com.callink.cad.pojo.HistoricoGbo;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
*
* @author Ednaldo Caic [ednaldo@swb.com.br]
* @since 03/01/2012
*/
public interface IHistoricoGboService extends IGenericGboService<HistoricoGbo, IHistoricoGboDAO> {

	void save(HistoricoGbo historicoGbo, String nomeFila) throws ServiceException, ValidationException;

}
