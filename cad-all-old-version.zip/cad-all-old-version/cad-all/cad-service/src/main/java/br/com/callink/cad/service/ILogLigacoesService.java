package br.com.callink.cad.service;

import java.util.Date;
import java.util.List;
import br.com.callink.cad.dao.ILogLigacoesDAO;
import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.LogLigacoes;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

public interface ILogLigacoesService extends IGenericGboService<LogLigacoes, ILogLigacoesDAO> {

	/**
	 * Coloca os logs na fila para ser salvo
	 * @param logLigacoes
	 * @throws ServiceException
	 */
	void saveLogLigacoes(LogLigacoes logLigacoes) throws ServiceException;

	/**
	 * Busca log por callID e data final vazia
	 * @param callID
	 * @return List<LogLigacoes>
	 * @throws ServiceException
	 */
	List<LogLigacoes> findByCallIDAndDateEndNull(String callID) throws ServiceException;

	/**
	 * Busca log por userSSO(login) e callID null e data final vazia
	 * @param userSSO
	 * @return List<LogLigacoes>
	 * @throws ServiceException
	 */
	List<LogLigacoes> findByCallIdNullForUserSSO(String userSSO, String telefone) throws ServiceException;

	/**
	 * Salva log sem todos os dados da ligação.
	 * @param logLigacoes
	 * @throws ServiceException
	 */
	void saveInicioLogLigacoesRealizada(LogLigacoes logLigacoes) throws ServiceException;

	/**
	 * Busca os log ligações por filtros
	 * @param idCaso
	 * @param flagEntrante
	 * @param inicio
	 * @param fim
	 * @param atendenteList
	 * @return
	 * @throws ServiceException
	 */
	List<LogLigacoes> findByFilters(String idCaso, String flagEntrante,	Date inicio, Date fim, List<Atendente> atendenteList) throws ServiceException, ValidationException;

	List<LogLigacoes> findByUserSSOTelefone(String userSSO, String telefone) throws ServiceException;
	
	/**
	 * @param caso
	 * @return
	 * @throws ServiceException, ValidationException
	 */
	Boolean existeTentativaDeContatoPorCaso(Caso caso) throws ServiceException, ValidationException;

	/**
	 * @param caso
	 * @param data
	 * @return
	 * @throws ServiceException, ValidationException
	 * @throws ValidationException 
	 * @throws ServiceException 
	 */
	Boolean existeTentativaDeContatoParaTodosTelefonesPorCasoEData(Caso caso, Date data) throws ServiceException, ValidationException;

	/**
	 * @param caso
	 * @return
	 * @throws ServiceException, ValidationException
	 */
	Boolean existeContatoComSucessoPorCaso(Caso caso) throws ServiceException, ValidationException;

	/**
	 * @param caso
	 * @param telefone
	 * @return
	 * @throws ServiceException
	 * @throws ValidationException
	 */
	Boolean existeTentativaDeContatoParaTodosOutrosTelefonesPorCaso(Caso caso, String telefone) throws ServiceException, ValidationException;

	/**
	 * @param telefone
	 * @param data
	 * @return
	 * @throws ServiceException
	 * @throws ValidationException
	 */
	Integer findQtdTentativaDeContatoPorTelefoneEData(String telefone, Date data) throws ServiceException, ValidationException;
}
