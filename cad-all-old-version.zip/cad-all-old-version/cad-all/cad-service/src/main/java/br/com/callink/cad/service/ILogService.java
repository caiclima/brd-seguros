package br.com.callink.cad.service;

import java.util.Date;
import java.util.List;

import br.com.callink.cad.dao.ILogDAO;
import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.Email;
import br.com.callink.cad.pojo.Log;
import br.com.callink.cad.pojo.Status;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

public interface ILogService extends IGenericGboService<Log, ILogDAO> {

	/**
	 * Para salvar um log do caso e enviar sua descrição.
	 * @param caso
	 * @param descricao
	 * @throws ServiceException
	 */
	void saveLog(Caso caso, String descricao) throws ServiceException;
        
        /**
         * Salva um log e a ação que criou o mesmo. Se existir salva  o grupo de anexo do LOG.
         * @param grupoAnexo
         * @param caso
         * @param observacao
         * @param atendente
         * @param email
         * @param detalhe
         * @throws ServiceException 
         * @throws ValidationException 
         */
        void saveLogAnexos(Log log) throws ServiceException, ValidationException;
        
        /**
         * Salva log de envio de email
         * @param caso
         * @param email 
         */
        void saveLogEmail(Caso caso, Email email, Acao acao) throws ServiceException;
        
        
	/**
	 * 
	 * @param caso
	 * @return
	 * @throws ServiceException
	 */
	List<Log> findHistorico(Caso caso) throws ServiceException;
        
        /**
         * Busca todos Logs relativos a troca de email no caso
         * @param caso
         * @return
         * @throws ServiceException 
         */
        List<Log> findHistoricoEmail(Caso caso) throws ServiceException;

        /**
         * Salva o log com anexo Imediato - nao coloca na fila para ser persistido depois
         * @param log
         * @throws ServiceException
         * @throws ValidationException 
         */
		void saveImediatoLogAnexos(Log log) throws ValidationException, ServiceException;

		/**
		 * @param log
		 * @throws ServiceException
		 * @throws ValidationException
		 */
		void saveLogDocumento(Log log) throws ServiceException,	ValidationException;

	 /**
     * retorn quantidade de Logs do caso de acordo com a data passada
     * @param caso
     * @param dataInicial
     * @param dataFinal
     * @return
     * @throws ServiceException 
     */
	Integer countLogByCasoAndData(Caso caso, Date dataInicial, Date dataAtual) throws ServiceException;
	
	 /**
     * retorn quantidade de Logs do caso de acordo com a data e status passados
     * @param caso
     * @param dataInicial
     * @param dataFinal
     * @return
     * @throws ServiceException 
     */
	Integer countLogByCasoAndDataAndStatus(Caso caso, Date dataInicial, Date dataAtual, List<Status> statusList) throws ServiceException;

	 /**
     * Busca todos os logs do caso
     * @param caso
     * @return
     * @throws ServiceException
     */
	List<Log> findLogsFromCaso(Caso caso, Date dataAlteracao) throws ServiceException;
}
