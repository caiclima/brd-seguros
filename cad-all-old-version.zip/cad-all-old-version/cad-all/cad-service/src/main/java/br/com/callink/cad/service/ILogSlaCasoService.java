package br.com.callink.cad.service;

import java.util.List;

import br.com.callink.cad.dao.ILogSlaCasoDAO;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.LogSlaCaso;
import br.com.callink.cad.service.exception.ServiceException;

public interface ILogSlaCasoService extends IGenericGboService<LogSlaCaso, ILogSlaCasoDAO> {

	List<LogSlaCaso> findLogSlaByCaso(Caso caso) throws ServiceException;
	
}
