package br.com.callink.cad.service;

import br.com.callink.cad.dao.ILogTaskDAO;
import br.com.callink.cad.pojo.LogTask;

public interface ILogTaskService extends IGenericGboService<LogTask, ILogTaskDAO> {

}
