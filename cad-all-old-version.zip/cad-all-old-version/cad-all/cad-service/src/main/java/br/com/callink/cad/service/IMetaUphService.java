/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.service;

import java.util.List;

import br.com.callink.cad.dao.IMetaUphDAO;
import br.com.callink.cad.pojo.CabUph;
import br.com.callink.cad.pojo.MetaUph;
import br.com.callink.cad.service.exception.ServiceException;

/**
 *
 * @author swb.miller
 */
public interface IMetaUphService extends IGenericGboService<MetaUph, IMetaUphDAO> {
    
    /**
     * busca a lista de metas para um determinado cab
     * 
     * @param cab
     * @return
     * @throws DataException 
     */
    List<MetaUph>  findMetaByCabUph(CabUph cab) throws ServiceException;

    /**
     * cria lista de metas configuradas para todos usuario e filas configuradas no sistema
     * 
     * @return
     * @throws ServiceException
     */
    void  calculaMetasUph() throws ServiceException;

    
}
