package br.com.callink.cad.service;


import java.util.List;

import br.com.callink.cad.dao.IParametroComandoDAO;
import br.com.callink.cad.pojo.Comando;
import br.com.callink.cad.pojo.ParametroComando;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 * @author Rogério Moreira de Andrade. [rogeriom@swb.com.br]
 */
public interface IParametroComandoService extends IGenericGboService<ParametroComando, IParametroComandoDAO> {

	/**
	 * Busca todos os ParametroComando de um Comando.
	 * @param comando
	 * @return
	 * @throws ValidationException 
	 */
	List<ParametroComando> buscaPorComando(Comando comando) throws ServiceException, ValidationException;
	
	ParametroComando buscaPorComandoNome(Comando comando, String nomeParametro) throws ServiceException, ValidationException;
    
}
