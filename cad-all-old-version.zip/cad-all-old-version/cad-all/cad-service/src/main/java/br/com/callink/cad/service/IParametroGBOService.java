package br.com.callink.cad.service;

import java.util.Calendar;
import java.util.List;

import br.com.callink.cad.dao.IParametroGBODAO;
import br.com.callink.cad.pojo.ParametroGBO;
import br.com.callink.cad.service.exception.ServiceException;
/**
 * Service para um {@link ParametroGBO}
 * @author brunomt
 *
 */
public interface IParametroGBOService extends IGenericGboService<ParametroGBO, IParametroGBODAO> {

	/**
	 * Busca os parametros pela chave.
	 * @param key
	 * @return
	 * @throws ServiceException
	 */
	ParametroGBO findByParam(String key) throws ServiceException;
        
        /**
         * Verifica se a data atual está configurada para ser contabilizada no dia atual.
         * 
         * @return
         * @throws ServiceException 
         */
        Boolean contabilizaDataAtual() throws ServiceException;
        
        /**
         * Verifica se a data enviada é um dua útil.
         * @param calendar
         * @return
         * @throws ServiceException 
         */
        Boolean contabilizaData(Calendar calendar) throws ServiceException;

		/**
		 * @param key
		 * @return
		 * @throws ServiceException
		 */
		List<ParametroGBO> findParamStartsWithKey(String key) throws ServiceException;

		/**
		 * @param key
		 * @return
		 * @throws ServiceException
		 */
		List<ParametroGBO> findByParam(String... key) throws ServiceException;
		
		public boolean buscarParametroBooleano(String nomeParametro);
}
