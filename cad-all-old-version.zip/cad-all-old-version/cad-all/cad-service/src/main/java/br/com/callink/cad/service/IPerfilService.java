package br.com.callink.cad.service;

import java.util.List;

import br.com.callink.cad.dao.IPerfilDAO;
import br.com.callink.cad.pojo.Perfil;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 * @author Rogério Moreira de Andrade. [rogeriom@swb.com.br]
 */
public interface IPerfilService extends IGenericGboService<Perfil, IPerfilDAO> {

    List<Perfil> findAtivos() throws ServiceException;
    
    void inativar(Perfil perfil) throws ServiceException, ValidationException;
}
