package br.com.callink.cad.service;

import java.util.List;

import br.com.callink.cad.dao.IReaberturaCasoDAO;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.ReaberturaCaso;
import br.com.callink.cad.service.exception.ServiceException;

public interface IReaberturaCasoService extends IGenericGboService<ReaberturaCaso, IReaberturaCasoDAO> {
    
    /**
     * Busca as reaberturas pelo caso.
     * @param caso
     * @return
     * @throws ServiceException 
     */
    List<ReaberturaCaso> findByCaso(Caso caso) throws ServiceException;

}
