package br.com.callink.cad.service;

import java.util.Date;
import java.util.List;

import br.com.callink.cad.dao.IRelatorioCasosFechadosDAO;
import br.com.callink.cad.pojo.RelatorioCasosFechados;
import br.com.callink.cad.repository.to.CasoFechadoTO;
import br.com.callink.cad.service.exception.ServiceException;

public interface IRelatorioCasosFechadosService extends IGenericGboService<RelatorioCasosFechados, IRelatorioCasosFechadosDAO> {

	/**
	 * Retorna os casos fechados do dia infomado.
	 * @param dataBusca
	 * @return
	 * @throws ServiceException
	 */
	List<RelatorioCasosFechados> buscaCasosFechadosDia(Date dataBusca) throws ServiceException;
	
	/**
	 * Busca os casos fechados na data atual
	 * @return
	 * @throws ServiceException
	 */
	List<RelatorioCasosFechados> buscaCasosFechadosDia() throws ServiceException;
	
	/**
	 * Gera todos os casos fechados no dia e insere na base.
	 * @throws ServiceException
	 */
	void geraCasosFechadosDia() throws ServiceException;

	/**
	 * Remove os casos inseridos no dia atual.
	 * @param dataAtual
	 * @throws ServiceException
	 */
	void limpaDiaAtual(Date dataAtual) throws ServiceException;
	
	/**
	 * 
	 * @param qtdDias
	 * @return
	 * @throws ServiceException
	 */
	List<CasoFechadoTO> retornaCasosFechados(Integer qtdDias, Integer divisaoRelatorio, String equipe) throws ServiceException;
        
        /**
         * Retorna o Total
         * @param casosList
         * @return 
         */
        CasoFechadoTO retornaTotal(List<CasoFechadoTO> casosList);
}
