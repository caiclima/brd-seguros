package br.com.callink.cad.service;

import java.util.List;
import java.util.SortedMap;

import br.com.callink.cad.dao.IRelatorioTempoGeralOperadorStatusDAO;
import br.com.callink.cad.pojo.AtendenteStatus;
import br.com.callink.cad.pojo.Equipe;
import br.com.callink.cad.pojo.RelatorioTempoGeralOperadorStatus;
import br.com.callink.cad.service.exception.ServiceException;

public interface IRelatorioTempoGeralOperadorService extends IGenericGboService<RelatorioTempoGeralOperadorStatus, IRelatorioTempoGeralOperadorStatusDAO> {
	
	/**
	 * Gera todos os tempos por operadores
	 * @throws ServiceException
	 */
	void geraTempoGeralPorOperadorPorDia() throws ServiceException;

	List<AtendenteStatus> buscaTodosStatusAtendimentoCadastrados() throws ServiceException;

	List<SortedMap<String, Object>> buscaTodosTotalizadores(String dataRelatorio, Equipe idEquipe) throws ServiceException;

}
