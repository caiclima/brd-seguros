package br.com.callink.cad.service;

import java.util.Date;
import java.util.List;

import br.com.callink.cad.dao.IRelatorioTempoGeralDAO;
import br.com.callink.cad.pojo.RelatorioTempoGeral;
import br.com.callink.cad.repository.to.RelatorioDadosTempoGeralTOTela;
import br.com.callink.cad.repository.to.RelatorioTempoGeralTO;
import br.com.callink.cad.service.exception.ServiceException;

public interface IRelatorioTempoGeralService extends IGenericGboService<RelatorioTempoGeral, IRelatorioTempoGeralDAO> {

	
	/**
	 * Gera todos os tempo geral no dia e insere na base.
	 * @throws ServiceException
	 */
	void geraTempoGeralDia() throws ServiceException;
	
	/**
	 * Remove os casos inseridos no dia atual.
	 * @param dataAtual
	 * @throws ServiceException
	 */
	void limpaDiaAtual(Date dataAtual) throws ServiceException;

	
	/**
	 * Busca todos os dados Relatorio Tempo Geral
	 * 
	 * @param mes
	 * @param ano
	 * @param idEquipe
	 * @return
	 * @throws ServiceException
	 */
	public List<RelatorioDadosTempoGeralTOTela> findDadosRelatorioTempoGeral(int mes, int ano, int idEquipe) throws ServiceException;

}
