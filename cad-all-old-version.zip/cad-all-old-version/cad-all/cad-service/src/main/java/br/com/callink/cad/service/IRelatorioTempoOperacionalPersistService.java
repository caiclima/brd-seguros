package br.com.callink.cad.service;

import java.util.List;

import br.com.callink.cad.dao.IRelatorioTempoOperacionalDAO;
import br.com.callink.cad.pojo.RelatorioTempoOperacional;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

public interface IRelatorioTempoOperacionalPersistService extends IGenericGboService<RelatorioTempoOperacional, IRelatorioTempoOperacionalDAO>{
    
    /**
     * Persist dados relatorio
     * 
     * @param relatorioList
     * @throws ServiceException
     * @throws ValidationException
     */
	void persistDadosRelatorio(List<RelatorioTempoOperacional> relatorioList) throws ServiceException, ValidationException;
	
	
	/**
	 * Limpa todos os dados
	 * 
	 * @throws ServiceException
	 * @throws ValidationException
	 */
	void deleteAll() throws ServiceException, ValidationException;
}