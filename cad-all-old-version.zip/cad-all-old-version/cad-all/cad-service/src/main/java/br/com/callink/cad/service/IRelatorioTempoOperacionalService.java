/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.service;

import java.util.Date;
import java.util.List;

import br.com.callink.cad.dao.IRelatorioTempoOperacionalDAO;
import br.com.callink.cad.pojo.RelatorioTempoOperacional;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 *
 * @author brunomt
 */
public interface IRelatorioTempoOperacionalService extends IGenericGboService<RelatorioTempoOperacional, IRelatorioTempoOperacionalDAO> {
    
    /**
     * Busca todos os tempos operacionais
     * @param data1
     * @param data2
     * @return
     * @throws ServiceException 
     * @throws ValidationException 
     */
    List<RelatorioTempoOperacional> retornaLoginsUsuariosSSO(Date dataInicio, Date dataFim) throws ServiceException, ValidationException;
    
    /**
     * Gera o relatorio para D -1
     * @throws ValidationException 
     */
    void geraRelatorioTempoOperacionalOntem() throws ServiceException, ValidationException;
    
    /**
     * Gera o relatorio por datas.
     * @param data1
     * @param data2 
     * @throws ValidationException 
     */
    void geraRelatorioTempoOperacionalDatas(Date dataInicio, Date dataFim) throws ServiceException, ValidationException;
    
    /**
     * 
     * @return
     * @throws ServiceException 
     */
    Date getDataUltimoRelatorio() throws ServiceException;
    
    /**
     * 
     * @throws ServiceException 
     * @throws ValidationException 
     */
    void geraRelatorioParametroTempoOperacional() throws ServiceException, ValidationException;
    
}
