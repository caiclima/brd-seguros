/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.service;

import java.util.Map;

import br.com.callink.cad.pojo.Feriado;
import br.com.callink.cad.service.exception.ServiceException;

/**
 * 
 * Cache para variáveis do Sla Tipo Fila Servive
 *
 */
public interface ISlaCacheService {

	Map<String, Feriado> getFeriado() throws ServiceException;
	
	Boolean getSabado() throws ServiceException;
	
	Boolean getDomingo() throws ServiceException;
	
	Integer getTempoOk() throws ServiceException;
	
	Integer getTempoAtencao() throws ServiceException;
	
	Integer getInicioContagem() throws ServiceException;
	
	void recarrega() throws ServiceException;
}
