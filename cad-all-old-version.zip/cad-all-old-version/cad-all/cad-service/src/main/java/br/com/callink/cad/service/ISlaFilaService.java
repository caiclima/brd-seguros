/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.service;

import java.util.List;

import br.com.callink.cad.dao.ISlaFilaDAO;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.pojo.SlaFila;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 *
 * @author swb.miller
 */
public interface ISlaFilaService extends IGenericGboService<SlaFila, ISlaFilaDAO> {

    /**
     * Busca sla de acordo com a fila
     * 
     * @param conf
     * @return
     * @throws DataException 
     */
    List<SlaFila> findSlaFilaByConfFila(ConfiguracaoFila conf) throws ServiceException;
    
    /**
     * busca todas sla com join na tabela de fila
     * 
     * @return
     * @throws DataExceptio 
     */
    List<SlaFila> findAllSlafila() throws ServiceException;
    
    /**
     * salva nova sla guardando um log da fila anterior
     * 
     * @param slaFilaAntiga
     * @param slaFilaNova
     * @throws ServiceException 
     */
    SlaFila saveLogSlaFila(SlaFila slaFilaAntiga, SlaFila slaFilaNova) throws ServiceException;
    
    /**
     * Busca sla por configuracao e com dat fim vazio
     * @param configuracaoFila
     * @return
     * @throws ServiceException
     * @throws ValidationException 
     */
    SlaFila findSlaFilaByConfFilaAndDataFimNull(ConfiguracaoFila configuracaoFila) throws ServiceException, ValidationException;

    /**
     * Busca sla fila por parametros passados pelo usuário na tela.
     * 
     * @param configFila
     * @param sla
     * @param descricao
     * @return
     * @throws ServiceException
     */
	List<SlaFila> findSlaFilaList(ConfiguracaoFila configFila, Integer sla,
			String descricao) throws ServiceException;

	void save(SlaFila slaFila) throws ServiceException;

	/**
	 * @return
	 * @throws ServiceException 
	 */
	SlaFila buscaSlaFilaPadraoCasosImportados() throws ServiceException;
    
    
}
