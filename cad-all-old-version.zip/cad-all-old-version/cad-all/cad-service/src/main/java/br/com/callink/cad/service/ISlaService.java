/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.service;

import java.util.List;

import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.service.exception.ServiceException;

import java.util.Date;

/**
 * 
 * @author Rogério Moreira de Andrade. [rogeriom@swb.com.br]
 */
public interface ISlaService {

	/**
	 * 
	 * @param caso
	 * @return
	 * @throws ServiceException
	 */
	String calculaSlaHoraMinuto(Caso caso) throws ServiceException;

	/**
	 * 
	 * @param init
	 * @param fim
	 * @return
	 * @throws ServiceException
	 */
	long calculaSlaMinutos(Date init, Date fim, Integer formaCalculo) throws ServiceException;

	/**
	 * 
	 * @param caso
	 * @return
	 * @throws ServiceException
	 */
	Caso loadSla(Caso caso) throws ServiceException;

	/**
	 * Inicializa os parametros de calculos de SLA
	 * 
	 * @throws ServiceException
	 * @throws br.com.callink.cad.service.exception.ServiceException 
	 */
	void initSlaService() throws ServiceException;

	/**
	 * Verifica se o Sla do caso eh maior do que o passado {@link long}
	 * @param caso
	 * @param slaParam
	 * @return Caso
	 * @throws ServiceException
	 */
	Caso verificaSlaMaiorParametro(Caso caso, long slaParam)
			throws ServiceException;

	/**
	 * 
	 * @param casoLlist
	 * @param sla
	 * @throws ServiceException
	 */
	void verificaSlaMaiorParametroList(List<Caso> casoLlist, long sla)
			throws ServiceException;

        /**
         * 
         * @param inicio
         * @param fim
         * @return
         * @throws ServiceException 
         */
        String calculaSlaIntervaloEmMinutos(Date inicio, Date fim) throws ServiceException;

        /**
         * 
         * @param minutos
         * @return 
         */
        String formataMinutosEmHorasMinutos(Long minutos);
        
        /**
         * Transforma o dado enviado em HH:MM:SS
         * @param segundos
         * @return 
         */
        String formataSegundosEmHMS(Long segundos);
        
        /**
         * 
         * @param inicio
         * @param fim
         * @return
         * @throws ServiceException 
         */
        Long calculaSlaInterValo(Date inicio, Date fim) throws ServiceException;

        /**
         * 
         * @param caso
         * @param slaParam
         * @return
         * @throws ServiceException
         */
		Caso verificaSlaMenorParametro(Caso caso, long slaParam)
				throws ServiceException;
		
		/**
		 * Método que calcula a porcentagem gasta do SLA
		 * @param tempoSlaEmMinutos
		 * @param tempoAtualEmMinutos
		 * @return
		 * @throws ServiceException
		 */
		Double calcularPorcentagem(Double tempoSlaEmMinutos, Long tempoAtualEmMinutos) throws ServiceException;
		
		/**
		 * @param slaEmMinutos
		 * @return
		 * @throws ServiceException
		 */
		Integer retornaSlaMinutos(String slaEmMinutos) throws ServiceException;
        
}
