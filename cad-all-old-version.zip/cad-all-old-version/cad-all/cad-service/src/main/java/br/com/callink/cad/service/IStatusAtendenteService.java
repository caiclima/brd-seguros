package br.com.callink.cad.service;

import java.util.Date;
import java.util.List;

import br.com.callink.cad.dao.IStatusAtendenteDAO;
import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.AtendenteStatus;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.pojo.Equipe;
import br.com.callink.cad.pojo.StatusAtendente;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 *
 * @author brunomt
 */
public interface IStatusAtendenteService extends IGenericGboService<StatusAtendente, IStatusAtendenteDAO> {
    
    /**
     * Cria uma nova marcação e envia para que a Thread consiga salvar essa marcação.
     * O flag inicio indica se é para fazer uma nova marcação ou se é para finalizar uma marcação que já tenha sido iniciada.
     *  0 = Apenas finaliza uma marcação que já tenha sido iniciada.
     *  1 = Finaliza a ultima marcação e inicia uma nova.
     * @param caso
     * @param atendente
     * @param atendenteStatus
     * @param flagInicio
     * @throws ValidationException 
     */
    void salvarNovoStatusAtendendimento(Caso caso, Atendente atendente, AtendenteStatus atendenteStatus, Boolean flagInicio) throws ServiceException, ValidationException;
    
    /**
     * Cria uma nova marcação com o atendente no status disponível.
     * @param atendente
     * @throws ServiceException 
     */
    void salvaStatusAtendimentoDisponivel(Atendente atendente) throws ServiceException;
    
    /**
     * Salva o statusAtendente para atendimento.
     * @param atendente
     * @throws ServiceException 
     * @throws ValidationException 
     * @throws NumberFormatException 
     */
    void salvaStatusAtendimentoAtendimento(Atendente atendente, Caso caso) throws ServiceException, ValidationException;
    
    /**
     * Busca todos os status atendentes entre datas.
     * @param data1
     * @param data2
     * @return
     * @throws ServiceException 
     */
    List<StatusAtendente> buscaTodosStatusAtendenteEntreDatas(Date data1, Date data2) throws ServiceException;
    
    
    /**
     * 
     * @param atendente
     * @param dataInicial
     * @param dataFinal
     * @return
     * @throws ServiceException
     */
    List<StatusAtendente> buscaStatusAtendenteByAtendente(Atendente atendente, Date dataInicial, 
			Date dataFinal) throws ServiceException;

    /**
     * 
     * @param fila
     * @param equipe
     * @param atendente
     * @param dataInicial
     * @param dataFinal
     * @return
     * @throws ServiceException
     */
	List<StatusAtendente> buscaStatusAtendenteByUserEquipe(
			ConfiguracaoFila fila, Equipe equipe, Atendente atendente,
			Date dataInicial, Date dataFinal) throws ServiceException;
	
	

	/**
	 * Verifica se o atendente pode alterar o status e altera o status se tudo estiver ok. Caso contrário retorna uma exception.
	 * @param loginAtendente
	 * @param idStatusToolbar
	 * @throws ServiceException
	 * @throws ValidationException 
	 */
	void alteraStatusToolbarGBO(String loginAtendente, Integer idStatusToolbar)	throws ServiceException, ValidationException;

	/**
	 * Verifica se o atendente possui um caso em atendimento, se sim não coloca o mesmo como disponível
	 * @param loginAtendente
	 * @throws ServiceException
	 */
	void alteraStatusToolbarGBODisponivel(String loginAtendente) throws ServiceException;

	/**
	 * Finaliza os status sem data_fim
	 * @throws ServiceException
	 */
	void finalizaStatusAtendenteSemDataFim() throws ServiceException; 
	
	/**
	 * Busca os atendentes com o status e tempo informado
	 * @param atendenteStatus
	 * @param tempoSegundos
	 * @return
	 * @throws ServiceException
	 */
	List<StatusAtendente> buscaStatusAtendenteByStatus(AtendenteStatus atendenteStatus, Integer tempoSegundos) throws ServiceException;
}
