package br.com.callink.cad.service;

import java.util.List;

import br.com.callink.cad.dao.IStatusDAO;
import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.pojo.Status;
import br.com.callink.cad.pojo.StatusAcao;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 * 
 * @author brunomt [brunoam@swb.com.br]
 *
 */
public interface IStatusService extends IGenericGboService<Status, IStatusDAO> {

    void inativar(Status status) throws ServiceException, ValidationException;

    void associa(StatusAcao statusAcao) throws ServiceException, ValidationException;

    void excluiAssociacao(StatusAcao statusAcao) throws ServiceException, ValidationException;

    List<StatusAcao> findByStatus(Status status) throws ServiceException, ValidationException;

    List<StatusAcao> findByAcao(Acao acao) throws ServiceException, ValidationException;

    List<StatusAcao> find(Acao acao, Status status) throws ServiceException, ValidationException;

    List<StatusAcao> findAllStatusAcao() throws ServiceException, ValidationException;

    /**
     * Retorna o Status pelo nome
     * @param nomeStatus
     * @return
     * @throws ServiceException
     */
	Status findStatusByNomeStatus(String nomeStatus) throws ServiceException;
	
	List<Status> findAll(String order) throws ServiceException;
	
	List<Status> findByExample(Status example, String order) throws ServiceException;

	/**
	 * @return
	 * @throws ServiceException
	 */
	Status buscaStatusPadraoCasosImportados() throws ServiceException;

	/**
	 * @param st
	 * @return
	 * @throws ServiceException
	 */
	List<Status> findByPkIn(List<Integer> st) throws ServiceException;
	
	/**
	 * @param nomesList
	 * @return
	 * @throws ServiceException
	 */
	List<Status> findByNomes(List<String> nomesList) throws ServiceException;
	
	/**
	 * @param nomesList
	 * @return
	 * @throws ServiceException
	 */
	List<Status> findExcludeByNomes(List<String> nomesList) throws ServiceException;
}
