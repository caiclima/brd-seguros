package br.com.callink.cad.service;


import br.com.callink.cad.dao.ITelaGboDAO;
import br.com.callink.cad.pojo.TelaGbo;
import br.com.callink.cad.service.exception.ServiceException;

/**
*
* @author Ednaldo Caic [ednaldo@swb.com.br]
* @since 03/01/2012
*/
public interface ITelaGboService extends IGenericGboService<TelaGbo, ITelaGboDAO> {

	/**
	 * Inativa o TelaGbo passado 
	 * @param telaGbo
	 * @throws ServiceException
	 */
	void inativa(TelaGbo telaGbo) throws ServiceException;

	/**
	 * Busca um TelaGbo pelo nome da fila
	 * @param mnemonico
	 * @return TelaGbo 
	 * @throws ServiceException
	 */
	TelaGbo findByNomeTela(String mnemonico) throws ServiceException;

}
