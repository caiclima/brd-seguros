package br.com.callink.cad.service;


import java.util.List;

import br.com.callink.cad.dao.ITelefoneDAO;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.Telefone;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 * @author Rogério Moreira de Andrade. [rogeriom@swb.com.br]
 */
public interface ITelefoneService extends IGenericGboService<Telefone, ITelefoneDAO> {

	List<Telefone> buscaTelefoneCaso(Caso caso) throws ServiceException;

	void saveListTel(List<Telefone> telefones)  throws ServiceException;

	/**
	 * Retorna os telefones nao tabulados da lista recebida por parametro.
	 * @param telefoneList
	 * @return
	 */
	List<Telefone> findTelefonesNaoTabulados(List<Telefone> telefoneList) throws ServiceException;

	/**
	 * @param caso
	 * @return
	 * @throws ServiceException
	 * @throws ValidationException
	 */
	Boolean existeContatoNaoTabulado(Caso caso) throws ServiceException, ValidationException;

	void deletarTelefonesCaso(Caso caso) throws ServiceException;
    
}
