package br.com.callink.cad.service;

import java.util.List;

import br.com.callink.cad.dao.ITempoAtendimentoCasoDAO;
import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.TempoAtendimentoCaso;
import br.com.callink.cad.service.exception.ServiceException;

/**
 * Serviço que realiza a marcação do tempo que um usuário está em atendimento.
 * @author brunomt
 *
 */
public interface ITempoAtendimentoCasoService extends IGenericGboService<TempoAtendimentoCaso, ITempoAtendimentoCasoDAO> {

    /**
     * Cria uma nova marcação de atendimento para o atendente.
     * 
     * @param caso
     * @param acao
     * @param atendente
     * @param inicioFim (Deve informar ser é para iniciar uma nova marcação ou finalizar uma já existente)
     * @throws ServiceException 
     */
    void salvaMarcacaoAtendimento(Caso caso, Acao acao, Atendente atendente, Boolean inicioFim) throws ServiceException;
    
    List<TempoAtendimentoCaso> findByCaso(Caso caso) throws ServiceException;
}
