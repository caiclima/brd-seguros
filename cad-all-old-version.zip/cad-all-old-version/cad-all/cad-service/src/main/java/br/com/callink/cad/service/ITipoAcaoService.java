package br.com.callink.cad.service;

import java.util.List;

import br.com.callink.cad.dao.IGenericCadDAO;
import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.pojo.AcaoTipoAcao;
import br.com.callink.cad.pojo.Status;
import br.com.callink.cad.pojo.TipoAcao;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 * 
 * @author brunomt [brunoam@swb.com.br]
 *
 */
public interface ITipoAcaoService extends IGenericGboService<TipoAcao, IGenericCadDAO<TipoAcao>>{

	/**
	 * Inativar um TipoAcao
	 * @param tipoAcao
	 * @throws ServiceException
	 * @throws ValidationException 
	 */
	void inativar(TipoAcao tipoAcao) throws ServiceException, ValidationException;

	/**
	 * Associa Acao com TipoAcao.
	 * @param acaoTipoAcao
	 * @throws ServiceException
	 * @throws ValidationException 
	 */
	void associa(AcaoTipoAcao acaoTipoAcao) throws ServiceException, ValidationException;

	/**
	 * Exclui associação.
	 * @param acaoTipoAcao
	 * @throws ServiceException
	 * @throws ValidationException 
	 */
	void excluiAssociacao(AcaoTipoAcao acaoTipoAcao) throws ServiceException, ValidationException;

	/**
	 * Busca tipos de ação pelo filtro informado
	 * @param acao
	 * @param tipoAcao
	 * @return
	 * @throws ServiceException
	 * @throws ValidationException 
	 */
	List<AcaoTipoAcao> find(Acao acao, TipoAcao tipoAcao) throws ServiceException, ValidationException;

	/**
	 * Busca todos os tipos de ação
	 * @return
	 * @throws ServiceException
	 * @throws ValidationException 
	 */
	List<AcaoTipoAcao> findAllAcaoTipoAcao() throws ServiceException, ValidationException;

	/**
	 * Busca todos os TipoAcao que estão relacionados com as açoões que possuem o status.
	 * @param status
	 * @return
	 * @throws ServiceException
	 * @throws ValidationException 
	 */
	List<TipoAcao> findTipoAcaoPeloStatus(Status status) throws ServiceException, ValidationException;

	List<TipoAcao> findByExample(TipoAcao tipoAcao, String order)
			throws ServiceException;
}
