package br.com.callink.cad.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.logging.Logger;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;
import br.com.callink.cad.dao.IRelatorioTempoGeralOperadorStatusDAO;
import br.com.callink.cad.dao.IRelatorioTempoGeralOperadorSumarizadoDAO;
import br.com.callink.cad.pojo.AtendenteStatus;
import br.com.callink.cad.pojo.Equipe;
import br.com.callink.cad.pojo.RelatorioTempoGeralOperadorStatus;
import br.com.callink.cad.pojo.RelatorioTempoGeralOperadorSumarizado;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.impl.GenericGboService;
import br.com.callink.cad.util.Constantes;
import br.com.callink.cad.util.Data;
import br.com.callink.cad.util.DateUtils;
import br.com.callink.cad.util.NumberUtils;

@Stateless
public class RelatorioTempoGeralOperadorService extends GenericGboService<RelatorioTempoGeralOperadorStatus, IRelatorioTempoGeralOperadorStatusDAO> implements
		IRelatorioTempoGeralOperadorService {

	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(RelatorioTempoGeralOperadorService.class.getName());

	@Inject
	private IRelatorioTempoGeralOperadorStatusDAO relatorioTempoGeralOperadorStatusDAO;

	@Inject
	private IRelatorioTempoGeralOperadorSumarizadoDAO relatorioTempoGeralOperadorSumarizadoDAO;

	@Inject
	private IAtendenteStatusService atendenteStatusService;

	protected IRelatorioTempoGeralOperadorStatusDAO getDAO() {
		return relatorioTempoGeralOperadorStatusDAO;
	}

	@Override
	public List<SortedMap<String, Object>> buscaTodosTotalizadores(String dataRelatorio, Equipe equipe) throws ServiceException {
		
		SortedMap<String, Object> mapSumarizadoAtendente = new TreeMap<String, Object>();
		List<SortedMap<String, Object>> listaDeDadosSumarizado = new ArrayList<>();

		String loginAntigo = "";

		try {
					
			List<RelatorioTempoGeralOperadorStatus> listaRelatorioTempoGeralOperadorStatusByResultSet = buscaResultSetSomatoriaStatusOperador(dataRelatorio, equipeEnviada(equipe));
			List<RelatorioTempoGeralOperadorSumarizado> listaRelatorioTempoGeralOperadorTotalizadoresByResultSet = buscaResultbuscaResultSetSomatoriaTotalizadores(dataRelatorio, equipeEnviada(equipe));

			for (RelatorioTempoGeralOperadorSumarizado relatorioTempoTotalizadores : listaRelatorioTempoGeralOperadorTotalizadoresByResultSet) {

				mapSumarizadoAtendente = (SortedMap<String, Object>) preencheMapaDeRetornoPorAtendente(mapSumarizadoAtendente, relatorioTempoTotalizadores,
						listaRelatorioTempoGeralOperadorStatusByResultSet, loginAntigo);

				mapSumarizadoAtendente = (SortedMap<String, Object>) preencheTodosStatusMesmoQueSemValores(mapSumarizadoAtendente);

				listaDeDadosSumarizado.add(mapSumarizadoAtendente);

				mapSumarizadoAtendente = new TreeMap<String, Object>();
			}
			
			return listaDeDadosSumarizado;

		} catch (DataException e) {
			throw new ServiceException("Erro ao buscar totalizadores dos Atendentes", e);
		}
	}
	
	private Integer equipeEnviada(Equipe equipe) {
		if (equipe == null) {
			return null;
		} else {
			return equipe.getIdEquipe();
		}
	}
	private List<RelatorioTempoGeralOperadorStatus> buscaResultSetSomatoriaStatusOperador(String dataRelatorio, Integer idEquipe) throws DataException {

		List<RelatorioTempoGeralOperadorStatus> listaRelatorioTempoGeralOperadorStatusByResultSet = relatorioTempoGeralOperadorStatusDAO
				.buscaTodosTemposStatusOperador(dataRelatorio, idEquipe);
		return listaRelatorioTempoGeralOperadorStatusByResultSet;
	}

	private List<RelatorioTempoGeralOperadorSumarizado> buscaResultbuscaResultSetSomatoriaTotalizadores(String dataRelatorio, Integer idEquipe) throws DataException {

		List<RelatorioTempoGeralOperadorSumarizado> listaRelatorioTempoGeralOperadorTotalizadoresByResultSet = relatorioTempoGeralOperadorSumarizadoDAO
				.buscaTodosTemposStatusSumarizadosPorOperador(dataRelatorio, idEquipe);
		return listaRelatorioTempoGeralOperadorTotalizadoresByResultSet;
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void geraTempoGeralPorOperadorPorDia() throws ServiceException {
		try {
			Date dataInicio = getDAO().findUltimaHoraRelatorioTempoGeralOperador();

			// Se for a primeira geração do relatório (dataInicio == null) gerar apenas do dia anterior (quantDias = 1)
			Long dados = dataInicio == null ? 1 : new Long(Data.diferencaEmDias(new Date(), dataInicio));
			
			int quantDias = dados.intValue();

			for (int i = quantDias; i > 0; i--) {

				Date dataAtual = null;
				if (dataAtual == null) {
					Calendar calFinal = Calendar.getInstance();
					calFinal.setTime(new Date());
					calFinal.set(Calendar.HOUR_OF_DAY, 00);
					calFinal.set(Calendar.MINUTE, 00);
					calFinal.set(Calendar.SECOND, 00);
					calFinal.set(Calendar.MILLISECOND, 000);

					calFinal.add(Calendar.DAY_OF_MONTH, -i);

					dataAtual = calFinal.getTime();
				}

				getDAO().geraRelatorioTempoGeralOperador(dataAtual);

			}

		} catch (Exception e) {
			throw new ServiceException("Erro ao buscar casos fechados no dia", e);
		}

	}

	private Map<String, Object> preencheMapaDeRetornoPorAtendente(Map<String, Object> mapSumarizadoAtendente,
			RelatorioTempoGeralOperadorSumarizado relatorioTempoGeralSumarizado,
			List<RelatorioTempoGeralOperadorStatus> listaRelatorioTempoGeralOperadorStatusByResultSet, String atendenteAntigo) throws DataException, ServiceException {

			  mapSumarizadoAtendente.put(Constantes.LOGIN_ATENDENTE.toUpperCase(), relatorioTempoGeralSumarizado.getLoginAtendente());
			  mapSumarizadoAtendente.put(Constantes.ID_RELATORIO_TEMPO_GERAL_OPERADOR_SUMARIZADO.toUpperCase(), relatorioTempoGeralSumarizado.getIdTempoGeralOperadorSumarizado());
			  mapSumarizadoAtendente.put(Constantes.ID_EQUIPE.toUpperCase(), relatorioTempoGeralSumarizado.getIdEquipe());
			  mapSumarizadoAtendente.put(Constantes.NOME_EQUIPE.toUpperCase(), relatorioTempoGeralSumarizado.getNomeEquipe());
			  mapSumarizadoAtendente.put(Constantes.PERCENTUAL_TEMPO_OCIOSO.toUpperCase(), NumberUtils.formataPorcentagem(relatorioTempoGeralSumarizado.getPercentualTempoOcioso()));
			  mapSumarizadoAtendente.put(Constantes.PERCENTUAL_TEMPO_PAUSA.toUpperCase(), NumberUtils.formataPorcentagem(relatorioTempoGeralSumarizado.getPercentualTempoPausa()));
			  mapSumarizadoAtendente.put(Constantes.PERCENTUAL_TEMPO_PRODUTIVO.toUpperCase(), NumberUtils.formataPorcentagem(relatorioTempoGeralSumarizado.getPercentualTempoProdutivo()));
			  mapSumarizadoAtendente.put(Constantes.PRIMEIRO_LOGIN.toUpperCase(), relatorioTempoGeralSumarizado.getPrimeiroLogin());
			  mapSumarizadoAtendente.put(Constantes.ULTIMO_LOGIN.toUpperCase(), relatorioTempoGeralSumarizado.getUltimoLogin());
			  
			  mapSumarizadoAtendente.put(Constantes.TEMPO_LOGADO.toUpperCase(), DateUtils.formataTempo(relatorioTempoGeralSumarizado.getTempoLogado()));
			  mapSumarizadoAtendente.put(Constantes.TEMPO_PAUSA.toUpperCase(), DateUtils.formataTempo(relatorioTempoGeralSumarizado.getTempoPausa()));
			  mapSumarizadoAtendente.put(Constantes.TEMPO_PRODUTIVO.toUpperCase(), DateUtils.formataTempo(relatorioTempoGeralSumarizado.getTempoProdutivo()));
			  
			  mapSumarizadoAtendente = preencheMapaComStatusDeAtendimentoPorAtendenteDiario(mapSumarizadoAtendente, listaRelatorioTempoGeralOperadorStatusByResultSet, relatorioTempoGeralSumarizado.getLoginAtendente(), atendenteAntigo);
		
		return mapSumarizadoAtendente;

	}

	private Map<String, Object> preencheMapaComStatusDeAtendimentoPorAtendenteDiario(Map<String, Object> mapSumarizadoAtendente,
			List<RelatorioTempoGeralOperadorStatus> listaRelatorioTempoGeralOperadorStatusByResultSet, String loginAtendente, String atendenteAntigo) throws ServiceException {
		try {
			String statusAntigo = "";
			boolean camposComunsDoAtendenteSetado = false;
	
			for (RelatorioTempoGeralOperadorStatus relatorioResumidoStatus : listaRelatorioTempoGeralOperadorStatusByResultSet) {
				
				if (loginAtendente.equalsIgnoreCase(relatorioResumidoStatus.getLoginAtendente())) {
					
					if(!camposComunsDoAtendenteSetado) {
						mapSumarizadoAtendente.put(Constantes.SUPERVISOR.toUpperCase(), relatorioResumidoStatus.getSupervisor());
						mapSumarizadoAtendente.put(Constantes.DATA.toUpperCase(), DateUtils.formatDate(new Date(relatorioResumidoStatus.getData().getTime())));
						camposComunsDoAtendenteSetado = true;
					}
					
					if (statusAntigo != relatorioResumidoStatus.getStatus()) {
						mapSumarizadoAtendente.put(relatorioResumidoStatus.getStatus(), DateUtils.formataTempo(relatorioResumidoStatus.getTempoStatus()));
						statusAntigo = relatorioResumidoStatus.getStatus();
					}
					
				} else {
					if (mapSumarizadoAtendente.get(Constantes.LOGIN_ATENDENTE.toUpperCase()).toString().equals(relatorioResumidoStatus.getLoginAtendente())) {
						return mapSumarizadoAtendente;
					}
				}
			}
	
			return mapSumarizadoAtendente;
		} catch (Exception e){
			throw new ServiceException("Erro ao mapear os dados recebidos do banco de dados! ", e);
		}
	}

	@Override
	public List<AtendenteStatus> buscaTodosStatusAtendimentoCadastrados() throws ServiceException {
		try {
			List<AtendenteStatus> statusList = atendenteStatusService.findAll();
			return statusList;
		} catch (ServiceException e) {
			throw new ServiceException("Erro ao buscar todos os status no banco de dados ", e);
		}
	}

	private Map<String, Object> preencheTodosStatusMesmoQueSemValores(Map<String, Object> mapSumarizadoAtendente) throws DataException {

		try {

			List<AtendenteStatus> todosStatus = buscaTodosStatusAtendimentoCadastrados();

			for (AtendenteStatus status : todosStatus) {

				Object valorStatus = mapSumarizadoAtendente.get(status.getNomeStatus());

				if (valorStatus == null || valorStatus.equals("")) {
					mapSumarizadoAtendente.put(status.getNomeStatus().toUpperCase(), null);
				}
			}

			return mapSumarizadoAtendente;

		} catch (ServiceException e) {
			throw new DataException("Erro ao buscar todos os status cadastrados no banco de dados! ", e);
		}
	}
}
