package br.com.callink.cad.service.command;

import java.util.Map;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.service.ITempoAtendimentoCasoService;
import br.com.callink.cad.service.exception.ServiceException;

/**
 * Serviço generico para comandos herdarem Observação o comando deve
 * obrigatóriamente implementar a interface ICommand
 * 
 * @author rafaelps
 * 
 */
@Stateless
public abstract class GenericCommandService implements ICommand {

    private static final long serialVersionUID = -7763775774524536882L;
    
    @EJB
    private ITempoAtendimentoCasoService tempoAtendimentoCasoService;

    protected void salvaMarcacaoAtendimento(Map<String, Object> parametros) throws ServiceException {
        Caso caso = (Caso) parametros.get("caso");
        Acao acao = (Acao) parametros.get("acao");
        if (caso.getAtendente() != null && caso.getAtendente().getIdAtendente() != null) {
            tempoAtendimentoCasoService.salvaMarcacaoAtendimento(caso, acao, caso.getAtendente(), Boolean.FALSE);
        }
    }
    
}
