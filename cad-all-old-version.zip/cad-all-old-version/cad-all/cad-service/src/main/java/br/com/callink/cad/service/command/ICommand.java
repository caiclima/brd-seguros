package br.com.callink.cad.service.command;


import java.io.Serializable;
import java.util.Map;

import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 * @author rafaelps
 */
public interface ICommand extends Serializable{

    /**
     * com base na acao(obrigatório) e statusInicial(não obrigatório) contido em
     * parametros execute o comando xpto
     * Existe um parametro "naoSalvaStatus" que se for necessário que o processo não
     * salve o status para o atendente flague como TRUE. Este parametro não é obrigatório.
     * Se não for informado por default o sistema irá salvar status.
     * @param parametros
     */
    void execute(Map<String, Object> parametros) throws ServiceException, ValidationException;
}
