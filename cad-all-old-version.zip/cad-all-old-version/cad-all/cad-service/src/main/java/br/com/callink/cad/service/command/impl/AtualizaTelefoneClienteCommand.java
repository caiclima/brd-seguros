package br.com.callink.cad.service.command.impl;

import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.Log;
import br.com.callink.cad.pojo.Telefone;
import br.com.callink.cad.service.ICasoService;
import br.com.callink.cad.service.ILogService;
import br.com.callink.cad.service.ITelefoneService;
import br.com.callink.cad.service.command.GenericCommandService;
import br.com.callink.cad.service.command.ICommand;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.coreutils.util.collection.CollectionUtils;

@Stateless
public class AtualizaTelefoneClienteCommand extends GenericCommandService implements ICommand{

    private static final long serialVersionUID = -4694480624617832426L;

    @EJB
    private ICasoService casoService;
    @EJB
    private ILogService logService;
    @EJB
    private ITelefoneService telefoneService;
    
    @SuppressWarnings("unchecked")
	@Override
    public void execute(Map<String, Object> parametros) throws ServiceException {
        try {
            Caso caso = (Caso) parametros.get("caso");
            List<Telefone> telefoneList = (List<Telefone>) parametros.get("telefones");
            
            if (caso == null || caso.getIdCaso()==null) {
                throw new IllegalArgumentException("Parametro 'Caso' obrigat\u00F3rio!");
            }

            Caso casoFound = casoService.findByPk(caso);

            if(!CollectionUtils.isNullOrEmpty(telefoneList)){
				Integer edicaoTelefoneCount = casoFound.getEdicaoTelefoneCount();
                edicaoTelefoneCount = edicaoTelefoneCount == null ? Integer.valueOf(0) : edicaoTelefoneCount;
                
            	casoFound.setFlagTelefoneEditado(Boolean.TRUE);
            	casoFound.setEdicaoTelefoneCount(edicaoTelefoneCount+1);
                casoService.update(casoFound);
        	 
            	telefoneService.saveListTel(telefoneList);
            }else{
            	telefoneService.deletarTelefonesCaso(casoFound);
            }
            
            Log logTel = new Log();
            logTel.setCaso(caso);
            logTel.setAtendente(caso.getAtendente());
            logTel.setAcao((Acao)parametros.get("acao"));
            logTel.setDescricao("Telefones editados");
            logService.saveLogAnexos(logTel);

            salvaMarcacaoAtendimento(parametros);

        }catch (ValidationException e) {
            throw new ServiceException(e.getMessage());
        } catch (ServiceException e) {
            throw new ServiceException(e);
        }
    }
}
