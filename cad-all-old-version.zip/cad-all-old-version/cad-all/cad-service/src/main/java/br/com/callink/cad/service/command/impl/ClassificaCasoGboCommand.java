package br.com.callink.cad.service.command.impl;

import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.Comando;
import br.com.callink.cad.pojo.GrupoAnexo;
import br.com.callink.cad.pojo.Log;
import br.com.callink.cad.pojo.Telefone;
import br.com.callink.cad.service.ICasoService;
import br.com.callink.cad.service.IConfiguracaoFilaService;
import br.com.callink.cad.service.ILogService;
import br.com.callink.cad.service.ITelefoneService;
import br.com.callink.cad.service.command.GenericCommandService;
import br.com.callink.cad.service.command.ICommand;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.util.Constantes;

@Stateless
public class ClassificaCasoGboCommand extends GenericCommandService implements ICommand{

    private static final long serialVersionUID = -4694480624617832426L;

    @EJB
    private ICasoService casoService;
    @EJB
    private IConfiguracaoFilaService configuracaoFilaService;
    @EJB
    private ILogService logService;
    @EJB
    private ITelefoneService telefoneService;
    
    @Override
    public void execute(Map<String, Object> parametros) throws ServiceException {
        try {
            Caso caso = (Caso) parametros.get("caso");
            String observacao = (String) parametros.get("observacao");
            List<Telefone> telefoneList = (List<Telefone>) parametros.get("telefones");
            Boolean telEdit = (Boolean) (parametros.get("editTel") == null ? Boolean.FALSE : parametros.get("editTel"));
            
            Comando comando = (Comando) parametros.get(Constantes.COMANDO_EM_EXECUCAO);
            if (caso == null || caso.getIdCaso()==null) {
                throw new IllegalArgumentException("Parametro 'Caso' obrigat\u00F3rio!");
            }

            Caso casoFound = casoService.findByPk(caso);

            configuracaoFilaService.removeFilaClassificaoCaso(casoFound);
            casoFound.setFlagEmAtendimento(Boolean.FALSE);
            casoFound.setFlagClassifica(Boolean.TRUE);
            casoFound.setAtendente(null);
            casoFound.setConfiguracaoFila(null);
            casoFound.setDataVencimentoSla(null);
            
            Integer classificacaoCount = casoFound.getClassificacaoCount();
            casoFound.setClassificacaoCount(classificacaoCount == null ? 1 : classificacaoCount + 1);
            
            if (StringUtils.isBlank(observacao) && casoFound.getClassificacaoCount() > 1) {
                throw new IllegalArgumentException("Parametro 'Observa\u00E7\u00E3o' obrigat\u00F3rio!");
            }
            
            if (observacao != null && observacao.length() >= 4000) {
            	throw new ServiceException("O campo Observação não pode ultrapassar 4000 caracteres!");
            }
            
            casoFound.setStatus(comando.getStatus());

            if (telEdit) {
            	casoFound.setFlagTelefoneEditado(Boolean.TRUE);
            }
            
            casoService.update(casoFound);

            Log log = new Log();
            log.setGrupoAnexo((GrupoAnexo)parametros.get("grupoAnexo"));
            log.setCaso(caso);
            log.setAtendente(caso.getAtendente());
            log.setAcao((Acao)parametros.get("acao"));
            
            if (StringUtils.isBlank(observacao)) {
                GrupoAnexo grupoAnexo = (GrupoAnexo) parametros.get("grupoAnexo");
                if (grupoAnexo != null && grupoAnexo.getAnexoList() != null && !grupoAnexo.getAnexoList().isEmpty()) {
                    observacao = "Documentos anexados!";
                    log.setDescricao(observacao);
                    logService.saveLogAnexos(log);
                }
            } else {
                log.setDescricao(observacao);
                logService.saveLogAnexos(log);
            }

            if (telEdit) {
            	telefoneService.saveListTel(telefoneList);
            	Log logTel = new Log();
            	logTel.setCaso(caso);
            	logTel.setAtendente(caso.getAtendente());
            	logTel.setAcao((Acao)parametros.get("acao"));
            	logTel.setDescricao("Telefones editados");
                logService.saveLogAnexos(log);
            }
            
            salvaMarcacaoAtendimento(parametros);

        }catch (ValidationException e) {
            throw new ServiceException(e.getMessage());
        } catch (ServiceException e) {
            throw new ServiceException(e);
        }
    }
}
