package br.com.callink.cad.service.command.impl;

import java.util.Map;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.ContatoTelefone;
import br.com.callink.cad.pojo.EventoLigacao;
import br.com.callink.cad.pojo.GrupoAnexo;
import br.com.callink.cad.pojo.Log;
import br.com.callink.cad.pojo.Telefone;
import br.com.callink.cad.service.ICasoService;
import br.com.callink.cad.service.IContatoService;
import br.com.callink.cad.service.ILogService;
import br.com.callink.cad.service.command.GenericCommandService;
import br.com.callink.cad.service.command.ICommand;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

@Stateless
public class ContatoTelefoneCommand extends GenericCommandService implements ICommand {

	private static final long serialVersionUID = 1L;

	@EJB
	private ICasoService casoService;
	@EJB
	private IContatoService contatoService;
	@EJB
	private ILogService logService;

	@Override
	public void execute(Map<String, Object> parametros) throws ServiceException, ValidationException {
		Caso caso = (Caso) parametros.get("caso");
		String observacao = (String) parametros.get("observacao");

		if (observacao != null && observacao.length() >= 4000) {
			throw new ServiceException("O campo Observação não pode ultrapassar 4000 caracteres!");
		}

		ContatoTelefone contato = new ContatoTelefone();
		contato.setAtendente((Atendente) parametros.get("atendente"));
		contato.setCaso(caso);
		contato.setTelefone((Telefone) parametros.get("telefone"));
		contato.setEventoLigacao((EventoLigacao) parametros.get("evento"));
		contato.setDataCriacao(contatoService.getDataBanco());
		contatoService.save(contato);

		Log log = new Log();
		log.setGrupoAnexo((GrupoAnexo) parametros.get("grupoAnexo"));
		log.setCaso(caso);
		log.setConfiguracaoFila(caso.getConfiguracaoFila());
		log.setDescricao(observacao);
		log.setAtendente(caso.getAtendente());
		log.setAcao((Acao) parametros.get("acao"));
		logService.saveLogAnexos(log);

		caso.setFlagEmAtendimento(Boolean.FALSE);
		casoService.update(caso);
	}

}
