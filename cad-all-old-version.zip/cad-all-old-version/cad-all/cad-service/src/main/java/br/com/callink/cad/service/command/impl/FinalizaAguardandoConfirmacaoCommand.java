package br.com.callink.cad.service.command.impl;

import java.util.Map;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.pojo.Agendamento;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.Comando;
import br.com.callink.cad.pojo.GrupoAnexo;
import br.com.callink.cad.pojo.Log;
import br.com.callink.cad.pojo.Status;
import br.com.callink.cad.service.IAgendamentoService;
import br.com.callink.cad.service.ICasoService;
import br.com.callink.cad.service.ILogService;
import br.com.callink.cad.service.IStatusService;
import br.com.callink.cad.service.command.GenericCommandService;
import br.com.callink.cad.service.command.ICommand;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.util.Constantes;

@Stateless
public class FinalizaAguardandoConfirmacaoCommand extends GenericCommandService implements ICommand{

    private static final long serialVersionUID = -782928408886790703L;
    
    @EJB
    private ICasoService casoService;
    @EJB
    private IStatusService statusService;
    @EJB
    private IAgendamentoService agendamentoService;
    @EJB
    private ILogService logService;

    @Override
    public void execute(Map<String, Object> parametros) throws ServiceException, ValidationException {
        Comando comando = (Comando) parametros.get(Constantes.COMANDO_EM_EXECUCAO);
        String observacao = (String) parametros.get("observacao");
        
        Boolean retiraCasoAtendente = false;
        try {
        	retiraCasoAtendente = parametros.get("retiraCasoAtendente") != null ? Boolean.valueOf((String)parametros.get("retiraCasoAtendente")) : false;
        } catch (Exception e) {
        	retiraCasoAtendente = false;
        }
        
        
        if(observacao == null || observacao.isEmpty() || observacao.length() >= 4000 ){
            throw new ServiceException("O campo Observação é obrigatório e não pode ultrapassar 4000 caracteres!");
        }
        
        Caso casoFound = (Caso) parametros.get("caso");
        Caso caso = casoService.findByPk(casoFound);
        
        Status status = statusService.load(comando.getStatus());

        caso.setStatus(status);
        caso.setFlagEmAtendimento(Boolean.FALSE);
        caso.setDataEncerramento(casoService.getDataBanco());
        
        
        if (retiraCasoAtendente) {
	        caso.setAtendente(null);
	        caso.setConfiguracaoFila(null);
	        caso.setDataVencimentoSla(null);
	        caso.setFlagClassifica(Boolean.TRUE);
        }
        
        if (status.getFlagContaSla()) {
            caso.setDataFimSla(null);
        } else {
            if (caso.getDataFimSla() == null) {
                caso.setDataFimSla(casoService.getDataBanco());
            }
        }

        Agendamento agendamento = (Agendamento) parametros.get("agendamento");
        if (agendamento != null && agendamento.getDataAgendamento() != null) {
            agendamento.setCaso(caso);
            agendamentoService.save(agendamento);
        }
        
        casoService.update(caso);
        
        Log log = new Log();
        log.setGrupoAnexo((GrupoAnexo)parametros.get("grupoAnexo"));
        log.setCaso(caso);
        log.setDescricao(observacao);
        log.setAtendente(caso.getAtendente());
        log.setAcao((Acao)parametros.get("acao"));
        log.setConfiguracaoFila(caso.getConfiguracaoFila());
        logService.saveLogAnexos(log);
        
        salvaMarcacaoAtendimento(parametros);
    }
}
