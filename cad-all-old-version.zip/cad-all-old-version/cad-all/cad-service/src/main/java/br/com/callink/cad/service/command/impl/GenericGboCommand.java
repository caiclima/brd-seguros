package br.com.callink.cad.service.command.impl;

import java.util.Map;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.Comando;
import br.com.callink.cad.pojo.GrupoAnexo;
import br.com.callink.cad.pojo.Log;
import br.com.callink.cad.service.ICasoService;
import br.com.callink.cad.service.IConfiguracaoFilaService;
import br.com.callink.cad.service.ILogService;
import br.com.callink.cad.service.command.GenericCommandService;
import br.com.callink.cad.service.command.ICommand;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.util.Constantes;

/**
 * Command que executa as seguintes alterações no caso.
 * 	1 - Busca o proximo status pelo parametro "proximoStatus" e se o mesmo estiver setado altera o status.
 *  2 - Busca o parametro "observacao" para registar um assentamento (String)
 *  3 - Busca o parametro "flagFinaliza" para verificar se é para flegar o caso para finalizado. 
 *  Se null || não informado o falor será false. (Boolean)
 *  4 - Busca o parametro "flagEmAtendimento" para verificar se é para flegar o caso para em atendimento. 
 *  Se null || não informado o valor será false. (Boolean)
 *  5 - Busca o parametro "flagClassifica" para reclassificar um caso (não implementado) (Boolean)
 * @author brunomt
 *
 */
@Stateless
public class GenericGboCommand extends GenericCommandService  implements ICommand{
	private static final long serialVersionUID = 1L;

	@EJB
	private IConfiguracaoFilaService configuracaoFilaService;
	
	@EJB
	private ICasoService casoService;
	
	@EJB
	private ILogService logService;
	
    @Override
    public void execute(Map<String, Object> parametros) throws ServiceException, ValidationException {
        Caso caso = (Caso) parametros.get("caso");
        Comando comando = (Comando) parametros.get(Constantes.COMANDO_EM_EXECUCAO);
        String detalhe = (String) parametros.get("detalhe");
        Boolean flagFinaliza = (Boolean) (parametros.get("flagFinaliza") == null ? Boolean.FALSE : parametros.get("flagFinaliza"));
        Boolean flagEmAtendimento = (Boolean) (parametros.get("flagEmAtendimento") == null ? Boolean.FALSE : parametros.get("flagEmAtendimento"));
        GrupoAnexo grupoAnexo = (GrupoAnexo) parametros.get("grupoAnexo");

        caso.setStatus(comando.getStatus());
        caso.setFlagFinalizado(flagFinaliza);
    	caso.setFlagEmAtendimento(flagEmAtendimento);
        
        if (flagFinaliza) {
            if (caso.getDataFimSla() == null) {
	        caso.setDataFimSla(casoService.getDataBanco());
            }
            caso.setDataEncerramento(casoService.getDataBanco());
            configuracaoFilaService.removeFilaClassificaoCaso(caso);
        }
        casoService.update(caso);
        
        String observacao = (String)parametros.get("observacao");
        
        if(observacao != null && observacao.length() >= 4000 ){
            throw new ServiceException("O campo Observação não pode ultrapassar 4000 caracteres!");
        }
        
        if (detalhe != null && detalhe.length() >= 2000) {
        	detalhe = detalhe.substring(0, 1999);
        }
        
        Log log = new Log();
        log.setGrupoAnexo(grupoAnexo);
        log.setCaso(caso);
        log.setDescricao(observacao);
        log.setAtendente(caso.getAtendente());
        log.setAcao((Acao)parametros.get("acao"));
        log.setDetalhe(detalhe);
        
        logService.saveLogAnexos(log);
        
        salvaMarcacaoAtendimento(parametros);
    }

}
