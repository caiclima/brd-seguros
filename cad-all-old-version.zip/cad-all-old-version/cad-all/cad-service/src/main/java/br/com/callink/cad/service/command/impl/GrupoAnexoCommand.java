package br.com.callink.cad.service.command.impl;

import java.util.Map;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import br.com.callink.cad.pojo.GrupoAnexo;
import br.com.callink.cad.service.IGrupoAnexoService;
import br.com.callink.cad.service.command.GenericCommandService;
import br.com.callink.cad.service.command.ICommand;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

@Stateless
public class GrupoAnexoCommand extends GenericCommandService implements ICommand{
	
	private static final long serialVersionUID = 1L;

	@EJB
	private IGrupoAnexoService grupoAnexoService;
	
	@Override
	public void execute(Map<String, Object> parametros) throws ServiceException, ValidationException {
		GrupoAnexo grupoAnexo = (GrupoAnexo) parametros.get("grupoAnexo");
		grupoAnexoService.save(grupoAnexo);
	}
}
