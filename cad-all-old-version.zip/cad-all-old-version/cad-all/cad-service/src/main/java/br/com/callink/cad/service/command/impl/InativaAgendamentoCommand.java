package br.com.callink.cad.service.command.impl;

import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import br.com.callink.cad.pojo.Agendamento;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.service.IAgendamentoService;
import br.com.callink.cad.service.command.GenericCommandService;
import br.com.callink.cad.service.command.ICommand;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

@Stateless
public class InativaAgendamentoCommand extends GenericCommandService implements ICommand{
	private static final long serialVersionUID = 1L;
	
	@EJB
	private  IAgendamentoService agendamentoService;
	
    @Override
    public void execute(Map<String, Object> parametros) throws ServiceException, ValidationException {
        Caso caso = (Caso) parametros.get("caso");
        //verifica se o caso possui agendamentos ativos, se tiver, os inativa
        List<Agendamento> agendamentoList = agendamentoService.buscaAtivosPeloCaso(caso);
        if (agendamentoList != null && !agendamentoList.isEmpty()) {
        	agendamentoService.inativar(caso);
        }
    }

}
