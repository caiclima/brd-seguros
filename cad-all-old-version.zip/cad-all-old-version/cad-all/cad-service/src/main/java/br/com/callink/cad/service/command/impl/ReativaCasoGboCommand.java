package br.com.callink.cad.service.command.impl;

import java.util.Map;

import org.apache.commons.lang.NotImplementedException;

import br.com.callink.cad.service.command.GenericCommandService;
import br.com.callink.cad.service.command.ICommand;
import br.com.callink.cad.service.exception.ServiceException;

public class ReativaCasoGboCommand extends GenericCommandService implements ICommand{

	private static final long serialVersionUID = 7090143184224132135L;

	@Override
	public void execute(Map<String, Object> parametros) throws ServiceException {
		throw new NotImplementedException(ReativaCasoGboCommand.class.getName()+ ".execute(StatusAcao statusAcao, Object parametro) não implementado ainda!");
	}

}
