/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.service.impl;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;

import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.Feriado;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.util.Constantes;
import br.com.callink.coreutils.util.date.DateUtils;

/**
 * 
 * @author Rogério Moreira de Andrade. [rogeriom@swb.com.br]
 */
public abstract class AbstractSlaService {

    private static final int SESSENTA = 60;

	/**
     * Lista de feriados, dias que nao serao contabilizados SLAs. String key
     * deve conter a data do feriado no formato dd/MM/yyyy
     * 
     * @throws ServiceException
     */
    public abstract Map<String, Feriado> getFeriados() throws ServiceException;

    /**
     * @param dataInicio
     *            e o primeiro dia de usado para contabilizar o SLA
     * @return Date primeiro dia efetivo de contabilizacao de SLAs
     * @throws ServiceException
     */
    public abstract Date inicioContagem(Date dataInicio)
            throws ServiceException;

    /**
     * @return boolean true se o sabado for contabilizado.
     * @throws ServiceException
     */
    public abstract Boolean conbilizaSabados() throws ServiceException;

    /**
     * @return boolean true se o domingo for contabilizado.
     * @throws ServiceException
     */
    public abstract Boolean conbilizaDomingos() throws ServiceException;
    
    public String calculaSlaHoraMinuto(Caso caso) throws ServiceException {
        Long minutos = getMinutosSla(caso.getDataAbertura(), caso.getDataFimSla());
        String minutosHora = null;
        if (minutos != null) {
            minutos = Math.abs(minutos);
            Long minuto = Long.valueOf(minutos % SESSENTA);
            Long hora = Long.valueOf(minutos / SESSENTA);

            minutosHora = (hora.toString().length() < 2 ? "0" + hora : hora)
                    + ":"
                    + (minuto.toString().length() < 2 ? "0" + minuto : minuto);
        }
        return minutosHora;
    }

    /**
     * Calcula a data do SLA
     * @param init
     * @param fim
     * @return
     * @throws ServiceException
     * 
     */
    public long calculaSlaMinutos(Date init, Date fim, Integer formaCalculo) throws ServiceException {
    	if (fim == null) {
    		fim = new Date();
    	}
    	if (formaCalculo == null || !formaCalculo.equals(0)) {
    		return getMinutosSla(init,fim);
    	} else {
    		return getMinutosSlaPelaData(init,fim);
    	}
    	
    }

    private long getMinutosSlaPelaData(Date init, Date fim) throws ServiceException {
    	long minutos = 0;
    	Calendar cal = Calendar.getInstance();
        Calendar calFim = Calendar.getInstance();
        Calendar calCalc = Calendar.getInstance();
        
        cal.setTime(init);
        calFim.setTime(fim);
        calCalc.setTime(init);
        
        calCalc.set(Calendar.HOUR_OF_DAY, 23);
        calCalc.set(Calendar.MINUTE, 59);
        calCalc.set(Calendar.SECOND, 59);
        
        DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		boolean validaSabado;
		boolean validaDomingo;
		
		String dataInicio = df.format(init);
		String dataFim = df.format(fim);
		
        validaSabado = cal.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY ? conbilizaSabados() : Boolean.TRUE;
        validaDomingo = cal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY ? conbilizaDomingos() : Boolean.TRUE;
        
        //Conta SLA do dia apenas do dia atual
        if (cal.get(Calendar.DAY_OF_MONTH) == calFim.get(Calendar.DAY_OF_MONTH) 
        		&& cal.get(Calendar.MONTH) == calFim.get(Calendar.MONTH) 
        		&& cal.get(Calendar.YEAR) == calFim.get(Calendar.YEAR) ) {
        	
        	if (cal.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY) {
        		if (validaSabado) {
        			return DateUtils.getMinutesBetweenDates(init, fim); 
        		} else {
        			return 0l;
        		}
        	} else if (cal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) {
        		if (validaDomingo) {
        			return DateUtils.getMinutesBetweenDates(init, fim);
        		} else {
        			return 0l;
        		}
        	} else {
        		return DateUtils.getMinutesBetweenDates(init, fim);
        	}
        }
        
        if (validaSabado && validaDomingo) {
        	//Conta o SLA do primeiro dia e passa para os proximos dias.
        	minutos += DateUtils.getMinutesBetweenDates(init, calCalc.getTime());
        }
        cal.setTime(init);
        cal.add(Calendar.DAY_OF_MONTH, 1);
        init = cal.getTime();
        dataInicio = df.format(init);	
        
        //Conta o SLA até o ultimo dia do caso
        while (!dataInicio.equals(dataFim)) {
                	
        	validaSabado = cal.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY ? conbilizaSabados() : Boolean.TRUE;
            validaDomingo = cal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY ? conbilizaDomingos() : Boolean.TRUE;
            
            
            if (cal.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY) {
            	if (validaSabado) {
            		minutos += Constantes.MINUTOS_DIA;
            	}
            } else if (cal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) {
            	if (validaDomingo) {
            		minutos += Constantes.MINUTOS_DIA;
            	}
            } else if (!getFeriados().containsKey(dataInicio)) {
            	minutos += Constantes.MINUTOS_DIA;
            }
        	
            
            cal.setTime(init);
            cal.add(Calendar.DAY_OF_MONTH, 1);
            init = cal.getTime();
            dataInicio = df.format(init);
        }
    	
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.MILLISECOND, 0);
        
        //Conta SLA do ultimo dia do caso.
        if (cal.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY) {
        	if (validaSabado) {
        		
        		minutos += DateUtils.getMinutesBetweenDates(cal.getTime(), fim);
        	}
        } else if (cal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) {
        	if (validaDomingo) {
        		minutos += DateUtils.getMinutesBetweenDates(cal.getTime(), fim);
        	}
        } else if (!getFeriados().containsKey(dataInicio)) {
        	minutos += DateUtils.getMinutesBetweenDates(cal.getTime(), fim);
        }
    	
		return minutos;
	}

	public Long getMinutosSlaIntervalo(Date init, Date fim, Integer formaCalculo) throws ServiceException {
    	if (formaCalculo == null || !formaCalculo.equals(0)) {
    		return getMinutosSla(init,fim);
    	} else {
    		return getMinutosSlaPelaData(init,fim);
    	}
    }
    
    private Long getMinutosSla(Date init, Date fim) throws ServiceException {
    	DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        Calendar cal = Calendar.getInstance();
        Calendar calFim = Calendar.getInstance();
        cal.setTime(init);
        calFim.setTime(fim);

        if (cal.get(Calendar.DAY_OF_MONTH) == calFim.get(Calendar.DAY_OF_MONTH) 
        		&& cal.get(Calendar.MONTH) == calFim.get(Calendar.MONTH) 
        		&& cal.get(Calendar.YEAR) == calFim.get(Calendar.YEAR) ) {
            return 0L;
        }

        init = inicioContagem(init);

        if (init.after(fim)) {
            Date initTemp = init;
            init = fim;
            fim = initTemp;
        }

        cal.setTime(init);

        String dataFim = df.format(fim);
        String dataInicio = df.format(init);
        long minutos = 0;
        boolean validaSabado = cal.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY ? conbilizaSabados()
                : Boolean.TRUE;
        boolean validaDomingo = cal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY ? conbilizaDomingos()
                : Boolean.TRUE;
        boolean contaDia = validaSabado && validaDomingo;

        return contaSLA(init, fim, dataFim, dataInicio, minutos,
				contaDia);

    }

	private long contaSLA(Date init, Date fim, String dataFim,
			String dataInicio, long minutos, boolean contaDia)
			throws ServiceException {
		try {
			boolean validaSabado;
			boolean validaDomingo;
			DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
			while (!dataInicio.equals(dataFim)) {
				Calendar cal = Calendar.getInstance();
	            if (contaDia && !getFeriados().containsKey(dataInicio)) {
	                minutos += Constantes.MINUTOS_DIA;
	            }
	            cal.setTime(init);
	            cal.add(Calendar.DAY_OF_MONTH, 1);
	            init = cal.getTime();
	            dataInicio = df.format(init);
	            validaSabado = cal.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY ? conbilizaSabados() : Boolean.TRUE;
	            validaDomingo = cal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY ? conbilizaDomingos() : Boolean.TRUE;
	            contaDia = validaSabado && validaDomingo; //TODO avaliar
	        }
	        
	        if (contaDia) {
	            if (init.after(fim)) {
	                Date initTemp = init;
	                init = fim;
	                fim = initTemp;
	            }
	            minutos += DateUtils.getMinutesBetweenDates(init, fim);
	        }
			return minutos;
		} catch (Exception e) {
			throw new ServiceException(e);
		}
	}

    /**
     * Esse metodo formata uma quantidade de minutos em uma <i>string</i> no
     * formato <b>HH...H:mm</b> se minutos for negativo retorna
     * <b>-HH...H:mm</b>.
     * 
     * @param minutos
     * @return
     */
    public String formataMinutosEmHorasMinutos(Long minutos) {
        String minutosHora = "";
        if (minutos != null) {
            minutosHora = minutos < 0 ? "-" : "";
            minutos = Math.abs(minutos);
            Long minuto = Long.valueOf(minutos % SESSENTA);
            Long hora = Long.valueOf(minutos / SESSENTA);
            minutosHora += (hora.toString().length() < 2 ? "0" + hora : hora)
                    + ":"
                    + (minuto.toString().length() < 2 ? "0" + minuto : minuto);
        }
        return minutosHora;
    }
    
    public String formataSegundosEmHMS(Long segundos) {
        String horaMinutoSegundo = "";
        if (segundos != null) {
            horaMinutoSegundo = segundos < 0 ? "-" : "";
            segundos = Math.abs(segundos);
            Long segundo = Long.valueOf(segundos % SESSENTA);
            Long minutos = Long.valueOf(segundos / SESSENTA);
            Long minuto = Long.valueOf(minutos % SESSENTA);
            Long hora = Long.valueOf(minutos / SESSENTA);
            
            StringBuilder sb = new StringBuilder();
            if (hora.toString().length() < 2) {
                sb.append("0");
            }
            sb.append(hora);
            sb.append(":");
            if (minuto.toString().length() < 2) {
                sb.append("0");
            }
            sb.append(minuto);
            sb.append(":");
            if (segundo.toString().length() < 2) {
                sb.append("0");
            }
            sb.append(segundo);
            
            horaMinutoSegundo = sb.toString();
        }
        return horaMinutoSegundo;
    }

}
