package br.com.callink.cad.service.impl;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.dao.IAcaoDAO;
import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.pojo.AcaoComando;
import br.com.callink.cad.pojo.Comando;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.service.IAcaoService;
import br.com.callink.cad.service.IComandoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 * @author Rogerio Moreira [rogeriom@swb.com.br]
 * 
 */
@Stateless
public class AcaoService extends GenericGboService<Acao, IAcaoDAO> implements IAcaoService {

	private static final long serialVersionUID = 1L;

	@Inject
	private IAcaoDAO acaoDAO;
	
	@EJB
	private IComandoService comandoService;
	
	@Override
	protected IAcaoDAO getDAO() {
		return acaoDAO;
	}
	
	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<Acao> findAtivos() throws ServiceException {
		try {
			return getDAO().findAtivos("Acao.NOME");
		} catch (DataException ex) {
			throw new ServiceException(ex);
		}
	}

	@Override
	public void inativar(Acao acao) throws ServiceException, ValidationException {
		if (acao.getPK() == null) {
			throw new ServiceException("Falha ao inativar: chave primaria n\u00E3o informada.");
		} else {
			acao.setFlagAtivo(Boolean.FALSE);
			update(acao);
		}
	}

	@Override
	public void save(Acao acao) throws ServiceException, ValidationException {
		if (validaCampos(acao)) {
			acao.setDataCriacao(getDataBanco());
			super.save(acao);
		}
	}

	@Override
	public void update(Acao acao) throws ServiceException, ValidationException {
		if (validaCampos(acao)) {
			acao.setDataCriacao(getDataBanco());
			super.update(acao);
		}
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void associa(AcaoComando acaoComando) throws ServiceException, ValidationException {

		if (acaoComando.getAcao() == null || acaoComando.getAcao().getIdAcao() == null || acaoComando.getComando() == null
				|| acaoComando.getComando().getIdComando() == null) {
				throw new ValidationException("Os campos Comando e A\u00E7\u00E3o devem ser preenchidos.");
		}

		try {
			if (getDAO().find(acaoComando.getAcao(), acaoComando.getComando()).isEmpty()) {
				getDAO().associa(acaoComando);
			} else {
				throw new ValidationException("Associa\u00E7\u00E3o j\u00E1 cadastrada.");
			}
		} catch (DataException ex) {
			throw new ServiceException(ex);
		}
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void excluiAssociacao(AcaoComando acaoComando) throws ServiceException {

		if (acaoComando.getAcao() == null || acaoComando.getAcao().getIdAcao() == null || acaoComando.getComando() == null
				|| acaoComando.getComando().getIdComando() == null) {
			throw new ServiceException("Os campos Comando e A\u00E7\u00E3o devem ser preenchidos.");
		}
		try {
			getDAO().excluiAssociacao(acaoComando);
		} catch (DataException ex) {
			throw new ServiceException(ex);
		}
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<AcaoComando> findByComando(Comando comando) throws ServiceException, ValidationException {
		try {
			return loadAcaoComando(getDAO().findByComando(comando));
		} catch (DataException ex) {
			throw new ServiceException("Erro ao buscar A\u00E7\u00E3o Comando.", ex);
		}
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<AcaoComando> findByAcao(Acao acao) throws ServiceException, ValidationException {
		try {
			return loadAcaoComando(getDAO().findByAcao(acao));
		} catch (DataException ex) {
			throw new ServiceException("Erro ao buscar A\u00E7\u00E3o Comando.", ex);
		}
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<AcaoComando> find(Acao acao, Comando comando) throws ServiceException, ValidationException {
		try {
			return loadAcaoComando(getDAO().find(acao, comando));
		} catch (DataException ex) {
			throw new ServiceException("Erro ao buscar A\u00E7\u00E3o Comando.", ex);
		}
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<AcaoComando> findAllAcaoComando() throws ServiceException, ValidationException {
		try {
			return loadAcaoComando(getDAO().findAllAcaoComando());
		} catch (DataException ex) {
			throw new ServiceException("Erro ao buscar A\u00E7\u00E3o Comando.", ex);
		}
	}

	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	private List<AcaoComando> loadAcaoComando(List<AcaoComando> lista) throws ServiceException, ValidationException {
		if (lista != null && lista.size() > 0) {
			try {

				for (AcaoComando acao :lista) {
					acao.setAcao(load(acao.getAcao()));
					acao.setComando(comandoService.load(acao.getComando()));
				}

			} catch (ServiceException ex) {
				throw new ServiceException("Erro ao carregar A\u00E7\u00E3o Comando.", ex);
			}
		}
		return lista;
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void associa(List<AcaoComando> acaoComando) throws ServiceException {
		try {
			getDAO().associa(acaoComando);
		} catch (DataException ex) {
			throw new ServiceException("Erro ao associar A\u00E7\u00E3o Comando.", ex);
		}
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<AcaoComando> findAllAcaoComandoAtivos() throws ServiceException {
		try {
			return getDAO().findAllAcaoComandoAtivos();
		} catch (DataException e) {
			throw new ServiceException("Erro ao buscar A\u00E7\u00E3o Comando.", e);
		}
	}
	
	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<AcaoComando> findByExample(Acao acao, Comando comando) throws ServiceException, ValidationException {
		try {
			return loadAcaoComando(getDAO().findAcaoComando(acao, comando));
		} catch (DataException e) {
			throw new ServiceException("Erro ao buscar A\u00E7\u00E3o Comando.", e);
		}
	}
	
	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public Acao findByNome(Acao acao) throws ServiceException {
		try {
			return getDAO().findByNome(acao);
		} catch (DataException e) {
			throw new ServiceException("Erro ao buscar A\u00E7\u00E3o pelo nome.", e);
		}
	}
	
	private boolean validaCampos(Acao acao) throws ValidationException {
		if (StringUtils.isBlank(acao.getNome()) || StringUtils.isBlank(acao.getLoginUsuario()) || StringUtils.isBlank(acao.getUrlPage())) {
			throw new ValidationException("Campos obrigat\u00F3rios n\u00E3o foram preenchidos.");
		}
		return true;
	}
	
	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<Acao> findByExample(Acao acao, String order) throws ServiceException {
		try {
			return getDAO().findByExample(acao, order);
		} catch (DataException e) {
			throw new ServiceException("Erro ao buscar A\u00E7\u00E3o.", e);
		}
	}
}
