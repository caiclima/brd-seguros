package br.com.callink.cad.service.impl;

import br.com.callink.cad.dao.IAgendamentoDAO;
import br.com.callink.cad.pojo.Agendamento;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.service.IAgendamentoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

/**
 * @author Rogerio Moreira [rogeriom@swb.com.br]
 * 
 */
@Stateless
public class AgendamentoService extends GenericGboService<Agendamento, IAgendamentoDAO> implements IAgendamentoService {

	private static final long serialVersionUID = 1L;
	
	@Inject
	private IAgendamentoDAO agendamentoDAO;
	
	@Override
	protected IAgendamentoDAO getDAO() {
		return agendamentoDAO;
	}

	@Override
	public void save(Agendamento agendamento) throws ServiceException, ValidationException {

		if (agendamento == null || agendamento.getDataAgendamento() == null
				|| agendamento.getDescricao() == null) {
			throw new ValidationException("Campos obrigat\u00F3rios.");
		}
		if (agendamento.getDataAgendamento().getTime() < getDataBanco().getTime()) {
			throw new ValidationException("Data do agendamento deve ser maior do que a data Atual.");
		}
		agendamento.setDataCadastro(getDataBanco());
		agendamento.setFlagAtivo(Boolean.TRUE);

		List<Agendamento> agendamentoList = buscaAtivosPeloCaso(agendamento
				.getCaso());
		if (agendamentoList != null && !agendamentoList.isEmpty()) {
			for (Agendamento agendamentoInativar : agendamentoList) {
				agendamentoInativar.setFlagAtivo(Boolean.FALSE);
				super.saveOrUpdate(agendamentoInativar);
			}
		}
		super.save(agendamento);
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<Agendamento> findAtivos() throws ServiceException {
		try {
			return getDAO().findAtivos(null);
		} catch (DataException ex) {
			throw new ServiceException("Erro ao buscar agendamentos", ex);
		}
	}

	@Override
	public void inativar(Agendamento agendamento) throws ServiceException, ValidationException {
		if (agendamento.getPK() == null) {
			throw new ValidationException("Falha ao inativar: chave primaria n\u00E3o informada.");
		} else {
			agendamento.setFlagAtivo(Boolean.FALSE);
			super.update(agendamento);
		}
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<Agendamento> buscaAtivosPeloCaso(Caso caso)
			throws ServiceException {

		try {
			return getDAO().buscaAtivosPeloCaso(caso);
		} catch (DataException e) {
			throw new ServiceException("Erro ao buscar agendamentos", e);
		}
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<Agendamento> buscaPeloCaso(Caso caso) throws ServiceException {
		try {
			return getDAO().buscaPeloCaso(caso);
		} catch (DataException e) {
			throw new ServiceException("Erro ao buscar agendamentos", e);
		}
	}

	@Override
	public void inativar(Caso caso) throws ServiceException, ValidationException {
		try {
			List<Agendamento> adendamentoList = getDAO().buscaAtivosPeloCaso(caso);

			if (adendamentoList == null || adendamentoList.isEmpty()) {
				throw new ValidationException("Este caso não possui nenhum agendamento para ser inativado. Casoid: "+ caso.getIdCaso());
			}

			Agendamento agendamento = adendamentoList.get(0);
			inativar(agendamento);
		} catch (DataException e) {
			throw new ServiceException("Erro ao inativar agendamento", e);
		}
	}

}
