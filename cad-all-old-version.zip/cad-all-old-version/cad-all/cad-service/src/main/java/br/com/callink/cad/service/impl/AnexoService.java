package br.com.callink.cad.service.impl;

import java.io.IOException;
import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.dao.IAnexoDAO;
import br.com.callink.cad.pojo.Anexo;
import br.com.callink.cad.pojo.GrupoAnexo;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.service.IAnexoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.util.ArquivoUtils;

/**
 * @author Ednaldo Caic [ednaldo@swb.com.br]
 * 
 */
@Stateless
public class AnexoService extends GenericGboService<Anexo, IAnexoDAO> implements
        IAnexoService {

    private static final long serialVersionUID = 1L;
    
    @Inject
    private IAnexoDAO anexoDAO;
    
    @Override
	protected IAnexoDAO getDAO() {
		return anexoDAO;
	}

    @Override
    public void save(Anexo anexo) throws ServiceException, ValidationException {

        try {
            validaAnexo(anexo);
            super.save(anexo);
            
            if(anexo.getDados() != null){
            	ArquivoUtils.gravarArquivo(anexo.getNomeFake(), anexo.getDiretorio(),anexo.getDados());
            }
        } catch (IOException e) {
            throw new ServiceException("Erro ao salvar Anexo. Tente novamente mais tarde. Se persistir o erro procure administrador.", e);
        }
    }

    @Override
    public void saveAll(List<Anexo> anexoList) throws ServiceException, ValidationException {
        if (anexoList != null && !anexoList.isEmpty()) {
            for (Anexo item : anexoList) {
                save(item);
            }
        }
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<Anexo> buscaPorGrupoAnexo(GrupoAnexo grupoAnexo) throws ServiceException {
        try {
        	
        	if(grupoAnexo!= null && grupoAnexo.getIdGrupoAnexo()!= null){
        		 return getDAO().buscaPorGrupoAnexo(grupoAnexo);
        	}
        	return null;
        } catch (DataException e) {
            throw new ServiceException(e);
        }
    }

    private void validaAnexo(Anexo anexo) throws ValidationException {
        if (anexo == null || StringUtils.isBlank(anexo.getNomeReal())) {
            throw new ValidationException("Campos obrigat\u00F3rios n\u00E3o foram preenchidos.");
        }
    }

    @Override
    public List<Anexo> carregaBytesAnexo(List<Anexo> anexos) throws ServiceException {
        try {
            for (Anexo anx : anexos) {
                String caminho = anx.getDiretorio() + anx.getNomeFake();
                anx.setDados(ArquivoUtils.getBytesArquivo(caminho));
            }
        } catch (IOException ex) {
            throw new ServiceException("Falha ao carregar anexo.",ex);
        }
        return anexos;
    }

}
