package br.com.callink.cad.service.impl;

import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.dao.IAssociaGrupoEmailDAO;
import br.com.callink.cad.pojo.AssociaGrupoEmail;
import br.com.callink.cad.pojo.EnderecoEmail;
import br.com.callink.cad.pojo.GrupoEmail;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.service.IAssociaGrupoEmailService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 *
 * @author Luiz Gustavo (luizgf@swb.com.br)
 */
@Stateless
public class AssociaGrupoEmailService extends GenericGboService<AssociaGrupoEmail, IAssociaGrupoEmailDAO>
        implements IAssociaGrupoEmailService {

	private static final long serialVersionUID = 1L;
	private static final char VIRGULA = ',';
    private static final char ABRE_PARENTESES = '(';
    private static final char FECHA_PARENTESES = ')';
    private static final char ESPACO = ' ';

    @Inject
    private IAssociaGrupoEmailDAO associaGrupoEmailDAO;
    
    @Override
	protected IAssociaGrupoEmailDAO getDAO() {
		return associaGrupoEmailDAO;
	}
    
    @Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<AssociaGrupoEmail> findByGrupoEmailEnderecoEmail(GrupoEmail grupoEmail, EnderecoEmail endereco) throws ServiceException {
        try {
            return getDAO().findByGrupoEmailEnderecoEmail(grupoEmail, endereco);
        } catch (DataException ex) {
            throw new ServiceException("Erro ao buscar associaçao endereço email - grupo de email.", ex);
        }
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void save(AssociaGrupoEmail obj) throws ServiceException, ValidationException  {
        try {
            if (!getDAO().findByGrupoEmailEnderecoEmail(obj.getGrupoEmail(), obj.getEnderecoEmail()).isEmpty()) {
                throw new ValidationException("Esta associacao já existe.");
            } else {
                super.save(obj);
            }
        } catch (DataException ex) {
            throw new ServiceException("Erro ao salvar registro.", ex);
        }
    }
    
    /**
     * Retorna a lista de emails no seguinte formato: 
     * (Descrição do grupo de email) endereçoemail1, endereçoemail2 (Desc. grupo email 2) email3, email4, etc...
     * @param listaGrupoEmail
     * @param mostrarDescricaoGrupoEmail
     * @return
     * @throws ServiceException 
     */
    @Override
    public String getDestinatariosFromListaGrupoEmail(List<GrupoEmail> listaGrupoEmail, Boolean mostrarDescricaoGrupoEmail) throws ServiceException, ValidationException {
        StringBuilder retorno = new StringBuilder();
        if (listaGrupoEmail == null || listaGrupoEmail.isEmpty()) {
            return "";
        }
        
        for (GrupoEmail g : listaGrupoEmail) {
            if (g.getSelecionado() == null || !g.getSelecionado()) {
                continue;
            }
            if (mostrarDescricaoGrupoEmail) {
                retorno.append(ABRE_PARENTESES).append(g.getDescricao()).append(FECHA_PARENTESES).append(ESPACO);
            }
            retorno.append(getDestinatariosFromGrupoEmail(g));
            //se nao for o ultimo, poe virgula antes do proximo
            if (listaGrupoEmail.indexOf(g) < listaGrupoEmail.size()-1) {
                retorno.append(VIRGULA).append(ESPACO);
            }
        }
        return retorno.toString();
    }
    
    /**
     * Busca uma string com os endereços de um grupo de email separados por virgula, exemplo:
     * email1@callink.com.br, email2@callink.com.br, email3@callink.com.br, etc..
     * @param grupoEmail
     * @return
     * @throws ServiceException 
     */
    @Override
    public String getDestinatariosFromGrupoEmail(GrupoEmail grupoEmail) throws ServiceException, ValidationException {
        
        List<AssociaGrupoEmail> listAssociaGrupoEmail = findByGrupoEmailEnderecoEmail(grupoEmail, null);
        
        if (listAssociaGrupoEmail == null) {
            throw new ValidationException("Nao ha emails cadastrados no grupo: "+grupoEmail);
        }
        
        StringBuilder retorno = new StringBuilder();
        
        for (AssociaGrupoEmail obj : listAssociaGrupoEmail) {
            if (obj.getEnderecoEmail() != null && obj.getEnderecoEmail().getFlagAtivo()) {
                if (StringUtils.isNotEmpty(retorno.toString())) {
                    retorno.append(VIRGULA).append(ESPACO);
                }
                retorno.append(obj.getEnderecoEmail().getEnderecoEmail());
            }
        }
        
        if (StringUtils.isEmpty(retorno.toString())) {
            throw new ValidationException("Nao ha emails cadastrados no grupo de email: "+grupoEmail);
        }
        
        return retorno.toString();
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void saveGrupoEmails(GrupoEmail grupoEmail, List<EnderecoEmail> enderecoEmailList) throws ServiceException, ValidationException {
        deletaAssociacoes(grupoEmail);
        
        for (EnderecoEmail enderecoEmail:enderecoEmailList) {
            AssociaGrupoEmail associaGrupoEmail = new AssociaGrupoEmail();
            associaGrupoEmail.setGrupoEmail(grupoEmail);
            associaGrupoEmail.setEnderecoEmail(enderecoEmail);
            
            save(associaGrupoEmail);
        }
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void deletaAssociacoes(GrupoEmail grupoEmail) throws ServiceException {
        try {
        	getDAO().deletaAssociacoes(grupoEmail);
        } catch (DataException ex) {
            throw new ServiceException("Erro ao deletar as associações.",ex);
        }
    }

}
