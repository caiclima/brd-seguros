package br.com.callink.cad.service.impl;

import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;
import org.apache.commons.lang.StringUtils;
import br.com.callink.cad.dao.IAtendenteDAO;
import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.pojo.Equipe;
import br.com.callink.cad.pojo.ParametroGBO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.service.IAtendenteService;
import br.com.callink.cad.service.IEquipeService;
import br.com.callink.cad.service.IParametroGBOService;
import br.com.callink.cad.service.IPerfilService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.util.Constantes;

/**
 * @author Rogerio Moreira [rogeriom@swb.com.br]
 * 
 */
@Stateless
public class AtendenteService extends GenericGboService<Atendente, IAtendenteDAO> implements
        IAtendenteService {

    private static final long serialVersionUID = 1L;

    @Inject
    private IAtendenteDAO atendenteDAO;
    
    @EJB
    private IParametroGBOService parametroGBOService;
    @EJB
    private IPerfilService perfilService;
    @EJB
    private IEquipeService equipeService;
    
    @Override
	protected IAtendenteDAO getDAO() {
		return atendenteDAO;
	}
    
    @Override
    public void save(Atendente atendente) throws ServiceException, ValidationException {
        validaAtendente(atendente);

        atendente.setDataCriacao(getDataBanco());
        super.save(atendente);
    }

    @Override
    public void update(Atendente atendente) throws ServiceException, ValidationException {
        validaAtendente(atendente);
        atendente.setDataCriacao(getDataBanco());
        super.update(atendente);
    }

    /**
     * @param atendente
     * @throws ServiceException
     */
    private void validaAtendente(Atendente atendente) throws ServiceException, ValidationException{
        if (atendente == null) {
            throw new ValidationException("O Atendente n\u00E3o pode ser nulo.");
        }
        if (StringUtils.isEmpty(atendente.getLogin())) {
            throw new ValidationException("O login deve ser informado.");
        }
        if (atendente.getPerfil() == null) {
            throw new ValidationException("O Perfil deve ser informados.");
        }
        try {
            Atendente atendentePesquisado = getDAO().findByLogin(atendente.getLogin());
            if (atendentePesquisado != null && !atendentePesquisado.getPK().equals(atendente.getPK())) {
                throw new ValidationException("Login informado j\u00E1 esta cadastrado!");
            }
        } catch (DataException e) {
            throw new ServiceException(e);
        }
        validaSupervisor(atendente);
    }

    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    private void validaSupervisor(Atendente atendente) throws ServiceException, ValidationException {
        
    	ParametroGBO parametro = parametroGBOService.findByParam(Constantes.ID_SUPERVISOR);

        try {
            //Validar se o atendente é um supervisor. Se for validar se já existe um supervisor na fila.
            if (atendente.getEquipe() != null && atendente.getPerfil().getIdPerfil().equals(Integer.valueOf(parametro.getValor()))) {
                //Só pode existir um supervisor por fila.				
                Atendente atendenteValida = new Atendente();
                atendenteValida.setEquipe(atendente.getEquipe());
                List<Atendente> atendentes = getDAO().findByExample(atendenteValida);
                for (Atendente atendenteItem : atendentes) {
                    atendenteItem.setPerfil(perfilService.findByPk(atendenteItem.getPerfil()));
                    if (atendenteItem.getPerfil().getIdPerfil().equals(Integer.valueOf(parametro.getValor()))) {
                        throw new ValidationException("J\u00E1 existe um SUPERVISOR nessa equipe. Favor retirar o supervisor ou alterar o perfil do analista.");
                    }
                }
            }
        } catch (NumberFormatException e) {
            throw new ServiceException("O par\u00E2metro idsupervisor n\u00E3o foi configurado corretamente.", e);
        } catch (DataException e) {
            throw new ServiceException("Erro ao validar se o atendente é supervisor.", e);
        }
    }
    
    @Override
    public Boolean validaLoginSupervisor(String loginSupervisor) throws ServiceException {
        if (StringUtils.isBlank(loginSupervisor)) {
            return Boolean.FALSE;
        }
        
        ParametroGBO parametro = parametroGBOService.findByParam(Constantes.ID_SUPERVISOR);
        
        Atendente atendente = findByLogin(loginSupervisor);
        
        if (atendente == null || atendente.getIdAtendente() == null) {
            return Boolean.FALSE;
        }
        
        if (atendente.getPerfil().getIdPerfil().equals(Integer.valueOf(parametro.getValor()))) {
            return Boolean.TRUE;
        } else {
            return Boolean.FALSE;
        }
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<Atendente> findAtivos() throws ServiceException {
        try {
            return getDAO().findAtivos("Atendente.LOGIN");
        } catch (DataException ex) {
            throw new ServiceException("Erro ao buscar Atendentes.", ex);
        }
    }

    @Override
    public void inativar(Atendente atendente) throws ServiceException , ValidationException{
        if (atendente.getPK() == null) {
            throw new ValidationException("Falha ao inativar: chave primaria n\u00E3o informada.");
        } else {
            atendente.setFlagAtivo(Boolean.FALSE);
            update(atendente);
        }
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public Atendente findByLogin(String login) throws ServiceException {
        try {
            return getDAO().findByLogin(login);
        } catch (DataException ex) {
            throw new ServiceException("Erro ao buscar Atendente.", ex);
        }
    }

    @Override
    public List<Atendente> findByExampleAll(Atendente atendente)
            throws ServiceException {
    	
        List<Atendente> atendenteList = super.findByExample(atendente);

        for (Atendente atendenteItem : atendenteList) {
            atendenteItem.setPerfil(perfilService.findByPk(atendenteItem.getPerfil()));
            if(atendenteItem.getEquipe() != null){
            	 atendenteItem.setEquipe(equipeService.findByPk(atendenteItem.getEquipe()));
            }
        }

        return atendenteList;
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<Atendente> buscaPorFila(ConfiguracaoFila configuracaoFila)
            throws ServiceException {
        try {
            return getDAO().buscaPorFila(configuracaoFila);
        } catch (DataException e) {
            throw new ServiceException("Erro ao buscar Atendentes.", e);
        }
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<Atendente> buscaAtivosQueNaoPossuemFila()
            throws ServiceException {
        try {
            return getDAO().buscaAtivosQueNaoPossuemFila();
        } catch (DataException e) {
            throw new ServiceException("Erro ao buscar Atendentes.", e);
        }
    }

    @Override
    public Boolean validaAtendenteCaso(Atendente atendente) throws ServiceException, ValidationException {
        if (atendente == null || atendente.getIdAtendente() == null) {
            throw new ValidationException("O Atendente n\u00E3o pode ser nulo.");
        }
        ParametroGBO parametro = parametroGBOService.findByParam(Constantes.ID_SUPERVISOR);

        //Valida se o atendente possui perfil de SUPERVISOR. Se sim o mesmo não pode atender nenhum caso.
        if (atendente.getPerfil() != null && atendente.getPerfil().getIdPerfil() != null
                && atendente.getPerfil().getIdPerfil().equals(Integer.valueOf(parametro.getValor()))) {
            return Boolean.FALSE;
        }
        return Boolean.TRUE;
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public Atendente findSupervisor(Atendente atendente) throws ServiceException {
        try {
            ParametroGBO parametro = parametroGBOService.findByParam(Constantes.ID_SUPERVISOR);
            Integer idPerfilSupervisor = Integer.valueOf(parametro.getValor());
            return getDAO().findSupervisor(atendente, idPerfilSupervisor);
        } catch (DataException ex) {
            throw new ServiceException("Falha ao buscar Supervisor", ex);
        }
    }
    
    @Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<Atendente> buscaPorConfiguracaoFilaList(List<ConfiguracaoFila> configuracaoFilaList) throws ServiceException {
        try {
            return getDAO().buscaPorConfiguracaoFilaList(configuracaoFilaList);
        } catch (DataException ex) {
            throw new ServiceException("Erro ao buscar Atendentes.", ex);
        }
    }
    
    @Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<Atendente> buscaPorEquipeList(List<Equipe> equipeList) throws ServiceException {
        try {
            return getDAO().buscaPorEquipeList(equipeList);
        } catch (DataException ex) {
            throw new ServiceException("Erro ao buscar atendentes pela equipe", ex);
        }
    }
    
    @Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<Atendente> buscaAtendentesPorEquipe(Equipe equipe) throws ServiceException {
    	try {
    		return getDAO().buscaAtendentesPorEquipe(equipe);
    	} catch (DataException e) {
			throw new ServiceException(e); 
		}
    }
    
    @Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<Atendente> findAll(String order) throws ServiceException {
    	try {
    		return getDAO().findAll(order);
    	} catch (DataException e) {
			throw new ServiceException(e); 
		}
    }

	@Override
	public List<Atendente> findByPkIn(List<Integer> idsAtendentes) throws ServiceException {
		try {
    		return getDAO().findByPkIn(idsAtendentes);
    	} catch (DataException e) {
			throw new ServiceException(e); 
		}
	}

}
