package br.com.callink.cad.service.impl;

import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.dao.IAtendenteStatusDAO;
import br.com.callink.cad.pojo.AtendenteStatus;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.service.IAtendenteStatusService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 *
 * @author brunomt
 */
@Stateless
public class AtendenteStatusService extends GenericGboService<AtendenteStatus, IAtendenteStatusDAO> implements IAtendenteStatusService {

	private static final long serialVersionUID = -1974019389876820295L;

	@Inject
	private IAtendenteStatusDAO atendenteStatusDAO;
	
	@Override
	protected IAtendenteStatusDAO getDAO() {
		return atendenteStatusDAO;
	}
	
    @Override
    public void save(AtendenteStatus atendenteStatus) throws ServiceException, ValidationException {
        validaAtendenteStatus(atendenteStatus);
        super.save(atendenteStatus);
    }

    @Override
    public void update(AtendenteStatus atendenteStatus) throws ServiceException, ValidationException {
        validaAtendenteStatus(atendenteStatus);
        super.update(atendenteStatus);
    }

    @Override
    public void inativar(AtendenteStatus atendenteStatus) throws ServiceException, ValidationException {
        validaAtendenteStatus(atendenteStatus);
        atendenteStatus.setFlagAtivo(Boolean.FALSE);
        update(atendenteStatus);
    }

    private void validaAtendenteStatus(AtendenteStatus atendenteStatus) throws ValidationException {
        if (atendenteStatus == null) {
            throw new ValidationException("O AtendenteStatus não pode ser nulo.");
        }
        if (StringUtils.isBlank(atendenteStatus.getNomeStatus())) {
            throw new ValidationException("O nome do AtendenteStatus não pode ser nulo.");
        }
        
        if (atendenteStatus.getFlagAtivo() == null) {
            atendenteStatus.setFlagAtivo(Boolean.FALSE);
        }
        
        if (atendenteStatus.getPausaAtendimento() == null) {
            atendenteStatus.setPausaAtendimento(Boolean.FALSE);
        }
        
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<AtendenteStatus> buscaAtendenteStatusPausado() throws ServiceException {
        try {
            return getDAO().buscaAtendenteStatusPausado();
        } catch (DataException ex) {
            throw new ServiceException("Erro ao buscar o AtendenteStatus.",ex);
        }
    }
    
    @Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public AtendenteStatus buscaAtendenteStatusIdToolbar(Integer idStatusToolbar) throws ServiceException {
    	try {
    		
    		List<AtendenteStatus> atendenteStatusList = getDAO().buscaAtendenteStatusIdToolbar(idStatusToolbar);
    		if (atendenteStatusList != null && !atendenteStatusList.isEmpty()) {
    			return atendenteStatusList.get(0);
    		} else {
    			return null;
    		}
    	} catch (DataException e) {
    		throw new ServiceException("Erro ao buscar o AtendenteStatus.",e);
		}
    }
    
    @Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<AtendenteStatus> findByExample(AtendenteStatus example, String order) throws ServiceException {
        try {
            return getDAO().findByExample(example, order);
        } catch (DataException ex) {
            throw new ServiceException("Erro ao buscar o AtendenteStatus.", ex);
        }
    }
    
}
