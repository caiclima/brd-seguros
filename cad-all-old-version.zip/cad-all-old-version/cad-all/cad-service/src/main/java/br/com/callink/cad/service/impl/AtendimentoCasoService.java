package br.com.callink.cad.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import br.com.callink.cad.dao.IAtendimentoCasoDAO;
import br.com.callink.cad.pojo.AtendimentoCaso;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.Status;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.service.IAtendimentoCasoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.coreutils.util.date.DateUtils;

/**
 * @author Rogerio Moreira [rogeriom@swb.com.br]
 *
 */
@Stateless
public class AtendimentoCasoService extends GenericGboService<AtendimentoCaso, IAtendimentoCasoDAO>
        implements IAtendimentoCasoService {

    private static final long serialVersionUID = 1654516699442663983L;
    private static final int SESSENTA = 60;
    
    @Inject
    private IAtendimentoCasoDAO atendimentoCasoDAO;
    
    @Override
	protected IAtendimentoCasoDAO getDAO() {
		return atendimentoCasoDAO;
	}
    
    /**
     * O Save da marcação de atendimento verifica a existencia de uma marcação
     * anterior para verificar a necessidade de uma nova marcação ou se não é
     * necessário fazer uma nova marcação. Somente será feita uma nova marcação
     * se o caso mudar algumas das suas colunas. Se o caso estiver com os mesmos
     * dados a marcação não será inserida.
     * @throws ValidationException 
     */
    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void save(AtendimentoCaso atendimentoCaso) throws ServiceException, ValidationException {
        Boolean novaMarcacao = false;
        //Busca o último ID da marcação do caso. Necessário indice entre caso x id marcação
        try {
            Integer ultimaIdMarcacao = getDAO().findUltimaMarcacaoCaso(atendimentoCaso);
            if (ultimaIdMarcacao != null && !ultimaIdMarcacao.equals(0)) {
                AtendimentoCaso atendimentoCasoValida = new AtendimentoCaso();
                atendimentoCasoValida.setPK(ultimaIdMarcacao);

                atendimentoCasoValida = getDAO().findByPk(atendimentoCasoValida);
                if (atendimentoCasoValida.getFlgInicio()) {
                    if ((atendimentoCaso.getConfiguracaoFila() != null && !atendimentoCaso.getConfiguracaoFila().equals(atendimentoCasoValida.getConfiguracaoFila()))
                            || (atendimentoCaso.getAtendente() != null && !atendimentoCaso.getAtendente().equals(atendimentoCasoValida.getAtendente()))
                            || (atendimentoCaso.getStatus() != null && !atendimentoCaso.getStatus().equals(atendimentoCasoValida.getStatus()))) {

                        atendimentoCasoValida.setFlgInicio(Boolean.FALSE);
                        atendimentoCasoValida.setDataFim(getDataBanco());
                        super.update(atendimentoCasoValida);
                        novaMarcacao = true;
                    }
                } else {
                    novaMarcacao = true;
                }
            } else {
                novaMarcacao = true;
            }

        } catch (DataException e) {
            throw new ServiceException("Erro ao buscar a \u00FAltima marca\u00E7\u00E3o.", e);
        }

        if (novaMarcacao && !atendimentoCaso.getCaso().getFlagFinalizado()) {
            atendimentoCaso.setDataInicio(getDataBanco());
            super.save(atendimentoCaso);
        }
    }

    /**
     * Não será possível alterar uma marcação realizada anteriormente.
     */
    @Override
    public void update(AtendimentoCaso atendimentoCaso) throws ValidationException {
        throw new ValidationException("N\u00E3o \u00E9 poss\u00EDvel fazer altera\u00E7\u00F5es em uma marca\u00E7\u00E3o. Favor solicitar o save de uma nova marca\u00E7\u00E3o.");
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<AtendimentoCaso> findAtendimentoCasoByCaso(Caso caso) throws ServiceException {

        try {
            return getDAO().findAtendimentoCasoByCaso(caso);
        } catch (DataException e) {
            throw new ServiceException("Erro ao buscar Atendimentos.", e);
        }
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public Map<Status, Float> calculaTempoAtendimentoByCaso(Caso caso) throws ServiceException {

        try {
            return calculaTempoAtendimento(findAtendimentoCasoByCaso(caso));
        } catch (ServiceException e) {
            throw new ServiceException("Erro ao calcular tempo de Atendimento do Caso.", e);
        }
    }

    private Map<Status, Float> calculaTempoAtendimento(List<AtendimentoCaso> atendimentoCasoList) throws ServiceException {

        Map<Status, Float> tempoAtendimentoByStatus = new HashMap<Status, Float>();

        for (AtendimentoCaso atendimentoCaso : atendimentoCasoList) {

            Integer tempoEmMinutos = DateUtils.getMinutesBetweenDates(atendimentoCaso.getDataInicio(),
                    atendimentoCaso.getDataFim() == null ? getDataBanco() : atendimentoCaso.getDataFim());
            Float tempoEmHoras = Float.valueOf(tempoEmMinutos) / SESSENTA;

            if (tempoAtendimentoByStatus.get(atendimentoCaso.getStatus()) != null) {
                tempoEmHoras += tempoAtendimentoByStatus.get(atendimentoCaso.getStatus());
            }
            tempoAtendimentoByStatus.put(atendimentoCaso.getStatus(), tempoEmHoras);
        }
        return tempoAtendimentoByStatus;
    }

}
