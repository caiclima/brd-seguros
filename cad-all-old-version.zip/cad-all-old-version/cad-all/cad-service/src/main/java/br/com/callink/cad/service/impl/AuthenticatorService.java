/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.service.impl;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.Properties;

import javax.ejb.Stateless;
import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;

import br.com.callink.cad.service.IAuthenticatorService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.util.Constantes;
import br.com.callink.cad.util.PropertieUtils;

/**
 *
 * @author Rogério Moreira de Andrade. rogeriom@swb.com.br
 */
@Stateless
public class AuthenticatorService implements IAuthenticatorService {
    public static final String AD = "AD";
    public static final String LDAP = "LDAP";
    
    @Override
    public void authentica(String usuario, String senha, String authenticatorService) throws ServiceException {
        String ldapServerName = PropertieUtils.getPropertieByArquivoAndChave(
                Constantes.CAMINHO_ARQUIVO_PROPERTIES_CONFIGURACAO_TELA,
                Constantes.NOME_ARQUIVO_PROPERTIE,
                "parametro.ldap.name");
        String rootdn = PropertieUtils.getPropertieByArquivoAndChave(
                Constantes.CAMINHO_ARQUIVO_PROPERTIES_CONFIGURACAO_TELA,
                Constantes.NOME_ARQUIVO_PROPERTIE,
                "parametro.rootdn");
        String rootContext = PropertieUtils.getPropertieByArquivoAndChave(
                Constantes.CAMINHO_ARQUIVO_PROPERTIES_CONFIGURACAO_TELA,
                Constantes.NOME_ARQUIVO_PROPERTIE,
                "parametro.rootcontext");        
        
        if (authenticatorService.equals(AuthenticatorService.AD)) {
            if (!validaAutenticacaoAD(ldapServerName, rootdn, rootContext, usuario, senha)) {
                throw new ServiceException("Usuário ou senha inválidos.");
            }
            
            return;
        } else {
            if (authenticatorService.equals(AuthenticatorService.LDAP)) {
                Properties env = new Properties();

                env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
                env.put(Context.PROVIDER_URL, ldapServerName + "/" + rootContext);
                env.put(Context.SECURITY_PRINCIPAL, rootdn.replaceFirst(":NOME_USUARIO:", usuario));
                env.put(Context.SECURITY_CREDENTIALS, senha);

                try {
                    new InitialDirContext(env);
                } catch (Exception e) {
                   throw new ServiceException(e);
                }
                return;
            }
        }
    }

    private boolean validaAutenticacaoAD(String ldapServerName, String rootdn, String rootContext, String usuario, String senha) throws ServiceException {
        try {
            String returnedAtts[] = {"sn", "givenName", "mail"};
            String searchFilter = "(&(objectClass=user)(sAMAccountName=" + usuario + "))";

            //Create the search controls
            SearchControls searchCtls = new SearchControls();
            searchCtls.setReturningAttributes(returnedAtts);

            //Specify the search scope
            searchCtls.setSearchScope(SearchControls.SUBTREE_SCOPE);

            Hashtable env = new Hashtable();
            env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
            env.put(Context.PROVIDER_URL, ldapServerName);
            env.put(Context.SECURITY_AUTHENTICATION, "simple");
            env.put(Context.SECURITY_PRINCIPAL, usuario + "@" + rootdn);
            env.put(Context.SECURITY_CREDENTIALS, senha);

            LdapContext ctxGC = null;
            
            ctxGC = new InitialLdapContext(env, null);
            //Search objects in GC using filters
            NamingEnumeration answer = ctxGC.search(rootContext, searchFilter, searchCtls);
            while (answer.hasMoreElements()) {
                SearchResult sr = (SearchResult) answer.next();
                Attributes attrs = sr.getAttributes();
                Map amap = null;
                if (attrs != null) {
                    amap = new HashMap();
                    NamingEnumeration ne = attrs.getAll();
                    while (ne.hasMore()) {
                        Attribute attr = (Attribute) ne.next();
                        amap.put(attr.getID(), attr.get());
                    }
                    ne.close();
                }
                return (amap != null && !amap.isEmpty());
            }

            return false;
        } catch (NamingException ex) {
            throw new ServiceException("Erro ao validar o usuÃ¡rio ou senha.",ex);
        }
    }
}
