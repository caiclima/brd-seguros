/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.service.impl;

import br.com.callink.cad.dao.ICabUphDAO;
import br.com.callink.cad.pojo.CabUph;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.pojo.MetaUph;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.service.ICabUphService;
import br.com.callink.cad.service.IMetaUphService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

import java.util.Date;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

/**
 *
 * @author swb.miller
 */
@Stateless
public class CabUphService extends GenericGboService<CabUph, ICabUphDAO> implements ICabUphService{
    
	private static final long serialVersionUID = -3223551695204338938L;

	@Inject
	private ICabUphDAO cabUphDAO;
	
	@EJB
	private IMetaUphService metaUphService;
	
	@Override
	protected ICabUphDAO getDAO() {
		return cabUphDAO;
	}

	
	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<CabUph> findLlistByConfFila(ConfiguracaoFila fila) throws ServiceException {
        try {
            return getDAO().findLlistByConfFila(fila);
        } catch(DataException e) {
            throw new ServiceException(e);       
        }
    }
    
    @Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<CabUph> findCabUphList(String descricao, ConfiguracaoFila fila, Double meta) throws ServiceException {
        try {
            return getDAO().findCabUphList(descricao, fila, meta);
        } catch(DataException e) {
            throw new ServiceException(e);       
        }
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void salvaMetasParametrizadas(List<MetaUph> listMetas, CabUph cabUph) throws ServiceException, ValidationException {
        try {
            
            CabUph cabUphValida = getDAO().findUltimaMetaConfigura(cabUph.getConfiguracaoFila());
            
            if (cabUphValida != null && cabUphValida.getDataFinal() == null) {
            	cabUphValida.setDataFinal(getDataBanco());
            	getDAO().update(cabUphValida);
            }
            
            cabUph.setDataInicial(new Date(System.currentTimeMillis()));
            getDAO().save(cabUph);
            
            for(MetaUph meta: listMetas) {
                meta.setIdCabUph(cabUph);
                metaUphService.save(meta);
            }
                        
        } catch(DataException e) {
            throw new ServiceException(e);       
        } catch(ServiceException e) {
            throw new ServiceException(e);       
        }
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void salvaNovaMetaParametrizada(List<MetaUph> listMetas, CabUph cabUphAntigo, CabUph cabUphNova) throws ServiceException, ValidationException {
        try {
            cabUphAntigo.setDataFinal(new Date(System.currentTimeMillis()));
            getDAO().update(cabUphAntigo);

            cabUphNova.setDataInicial(new Date(System.currentTimeMillis()));
            getDAO().save(cabUphNova);

            for (MetaUph meta : listMetas) {
                meta.setIdCabUph(cabUphNova);
                metaUphService.save(meta);
            }

        } catch (DataException e) {
            throw new ServiceException(e);
        } catch (ServiceException e) {
            throw new ServiceException(e);
        }
    }
    
    @Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public CabUph findUltimaMetaConfigura(ConfiguracaoFila fila) throws ServiceException {
    	try {
    		return getDAO().findUltimaMetaConfigura(fila);
    	} catch (DataException e) {
			throw new ServiceException(e);
		}
    }

}
    

