package br.com.callink.cad.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.dao.ICasoDAO;
import br.com.callink.cad.pojo.Agendamento;
import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.AtendimentoCaso;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.pojo.EquipeFila;
import br.com.callink.cad.pojo.Log;
import br.com.callink.cad.pojo.ParametroGBO;
import br.com.callink.cad.pojo.Status;
import br.com.callink.cad.repository.MarcacaoLogs;
import br.com.callink.cad.repository.to.AtendenteCasoStatusTO;
import br.com.callink.cad.repository.to.CasoStatusTO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.service.IAgendamentoService;
import br.com.callink.cad.service.IAtendenteService;
import br.com.callink.cad.service.ICasoService;
import br.com.callink.cad.service.IConfiguracaoFilaService;
import br.com.callink.cad.service.IEmailService;
import br.com.callink.cad.service.IEquipeFilaService;
import br.com.callink.cad.service.ILogService;
import br.com.callink.cad.service.IParametroGBOService;
import br.com.callink.cad.service.ISlaService;
import br.com.callink.cad.service.IStatusService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.util.Constantes;

/**
 * Service para um {@link Caso}
 * 
 * @author brunomt [brunoam@swb.com.br]
 * 
 */
@Stateless
public class CasoService extends GenericGboService<Caso, ICasoDAO> implements ICasoService {
	
	private static final long serialVersionUID = 1L;
	
	@Inject
	private ICasoDAO casoDAO;
	@EJB(beanName="SlaTipoFilaService")
	private ISlaService slaService;
    @EJB
	private IEmailService emailService;
    @EJB
    private IStatusService statusService;
    @EJB
    private IAgendamentoService agendamentoService; 
    @EJB
    private IParametroGBOService parametroGBOService;
    @EJB
    private IConfiguracaoFilaService configuracaoFilaService;
    @EJB
    private ILogService logService;
    @EJB
    private IEquipeFilaService equipeFilaService;
    @EJB
    private IAtendenteService atendenteService;
    
    @Override
	protected ICasoDAO getDAO() {
		return casoDAO;
	}

	/**
	 * Salva um caso.
	 * @throws ValidationException 
	 */
	@Override
	public void save(Caso caso) throws ServiceException, ValidationException {

		String erros = validaCaso(caso);
		if (StringUtils.isNotBlank(erros)) {
			throw new ServiceException(erros);
		}
		caso.setDataCadastro(getDataBanco());
		
		verificaExistenciaFila(caso);
		
		super.save(caso);

		if (caso.getConfiguracaoFila() != null) {
			marcacaoAtendimentoCaso(caso);
		}
	}

	@Override
	public void update(Caso caso) throws ServiceException, ValidationException {

		String erros = validaCaso(caso);
		if (StringUtils.isNotBlank(erros)) {
			throw new ServiceException(erros);
		}
		
		verificaExistenciaFila(caso);
		
		super.update(caso);

		if (caso.getConfiguracaoFila() != null) {
			marcacaoAtendimentoCaso(caso);
		}
	}

	private void verificaExistenciaFila(Caso caso) {
		if (caso.getConfiguracaoFila() == null) {
			caso.setDataVencimentoSla(null);
		}
	}

	private String validaCaso(Caso caso) throws ValidationException {
		StringBuilder erro = new StringBuilder();
		if (caso == null) {
			throw new ValidationException("Caso informado esta nulo.");
		}

		if (caso.getDataAbertura() == null) {
			erro.append("Campo obrigat\u00F3rio. : Data de abertura ").append(Constantes.NOVA_LINHA);
		}
		return erro.toString();
	}

	/**
	 * @param caso
	 * @throws ServiceException
	 */
	private void marcacaoAtendimentoCaso(Caso caso) throws ServiceException {
		AtendimentoCaso atendimentoCaso = new AtendimentoCaso();
		atendimentoCaso.setCaso(caso);
		atendimentoCaso.setAtendente(caso.getAtendente());
		atendimentoCaso.setStatus(caso.getStatus());
		atendimentoCaso.setConfiguracaoFila(caso.getConfiguracaoFila());
		atendimentoCaso.setFlgInicio(Boolean.TRUE);

		MarcacaoLogs.offer(atendimentoCaso);
	}

	/**
	 * Busca os casos de uma fila ordenando os mesmos pela regra configurada. Se
	 * não existir nenhuma configuração os casos serão ordenados pela
	 * propriedade dataInicio.
	 * 
	 * @param configuracaoFila
	 * @return
	 * @throws ServiceException
	 */
	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<Caso> buscaCasosFiltroPorFilaSemAtendente(
			ConfiguracaoFila configuracaoFila) throws ServiceException, ValidationException {
		if (configuracaoFila == null) {
			throw new ValidationException("A configura\u00E7\u00E3o do caso deve ser informada.");
		}
        if (configuracaoFila.getSqlWhere()==null) {
            throw  new ValidationException("O WHERE na ConfiguracaoFila não pode ser nulo,");
        }

		ParametroGBO parametroGBO = parametroGBOService.findByParam("fromconsultacaso");
                
		try {
			return getDAO().buscaCasosFiltroPorFilaSemAtendente(parametroGBO.getValor(), configuracaoFila.getSqlWhere());
		} catch (DataException e) {
			throw new ServiceException("Erro ao tentar buscar os casos ordenados pela fila.", e);
		}
	}
	
	/**
	 * Busca os casos de uma fila ordenando os mesmos pela regra configurada. Se
	 * não existir nenhuma configuração os casos serão ordenados pela
	 * propriedade dataInicio.
	 * 
	 * @param configuracaoFila
	 * @return
	 * @throws ServiceException
	 */
	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<Caso> buscaCasosFiltroPorFilaSemAtendente(
			ConfiguracaoFila configuracaoFila, Integer top) throws ServiceException, ValidationException {
		if (configuracaoFila == null) {
			throw new ValidationException("A configura\u00E7\u00E3o do caso deve ser informada.");
		}
        if (configuracaoFila.getSqlWhere()==null) {
            throw  new ValidationException("O WHERE na ConfiguracaoFila não pode ser nulo,");
        }

		ParametroGBO parametroGBO = parametroGBOService.findByParam("fromconsultacaso");
                
		try {
			return getDAO().buscaCasosFiltroPorFilaSemAtendente(parametroGBO.getValor(), configuracaoFila.getSqlWhere(), top);
		} catch (DataException e) {
			throw new ServiceException("Erro ao tentar buscar os casos ordenados pela fila.", e);
		}
	}

	@Override
	public Caso calculaSla(Caso caso, Date data) throws ServiceException {

		if (caso == null || data == null) {
			throw new ServiceException("O caso e a data não podem ser nulos.");
		}
		
		boolean dataEncerramento = caso.getDataEncerramento() == null;
		boolean dataFimSla = caso.getDataFimSla() == null;

		if (dataFimSla && dataEncerramento) {
			caso.setDataFimSla(data);
		} else if (dataFimSla && !dataEncerramento) {
			caso.setDataFimSla(caso.getDataEncerramento());
		}

		caso = slaService.loadSla(caso);

		if (dataFimSla) {
			caso.setDataFimSla(null);
		}
		return caso;
	}

	@Override
	public Caso verificaSlaMaiorParametro(Caso caso, long slaParam) throws ServiceException {
            
		boolean dataEncerramento = caso.getDataEncerramento() == null;
		boolean dataFimSla = caso.getDataFimSla() == null;

		if (dataFimSla && dataEncerramento) {
			caso.setDataFimSla(getDataBanco());
		} else if (dataFimSla && !dataEncerramento) {
			caso.setDataFimSla(caso.getDataEncerramento());
		}


		caso = slaService.verificaSlaMaiorParametro(caso, slaParam);

		if (caso != null && dataFimSla) {
			caso.setDataFimSla(null);
		}
		return caso;
	}
	
	@Override
	public Caso verificaSlaMenorParametro(Caso caso, long slaParam)
			throws ServiceException {
            
		boolean dataEncerramento = caso.getDataEncerramento() == null;
		boolean dataFimSla = caso.getDataFimSla() == null;

		if (dataFimSla && dataEncerramento) {
			caso.setDataFimSla(getDataBanco());
		} else if (dataFimSla && !dataEncerramento) {
			caso.setDataFimSla(caso.getDataEncerramento());
		}

		caso = slaService.verificaSlaMenorParametro(caso, slaParam);

		if (caso != null && dataFimSla) {
			caso.setDataFimSla(null);
		}
		return caso;
	}

	@Override
	public List<Caso> carregaSlas(List<Caso> casos) throws ServiceException {
            
		Date data = getDataBanco();
		
		for (Caso caso : casos) {
			caso = carregaSla(data, caso);
		}

		return casos;
	}

	@Override
	public Caso carregaSla(Date data, Caso caso) throws ServiceException {
		if (data == null || caso == null || caso.getIdCaso() == null) {
			throw new ServiceException("O caso e a data não podem ser nulos para calcular o SLA");
		}
		
		boolean casoAberto = caso.getDataFimSla() == null;
		if (casoAberto) {
			caso.setDataFimSla(data);
		}
		caso = slaService.loadSla(caso);

		if (casoAberto) {
			caso.setDataFimSla(null);
		}
		return caso;
	}
	
	@Override
	public Caso carregaSlaEmailCaso(Caso caso) throws ServiceException {
		Date data = getDataBanco();
		
		carregaSla(data, caso);
		emailService.loadIconCaso(caso);
		
		return caso;
	}
        
    @Override
    public List<Caso> carregaEmails(List<Caso> casos) throws ServiceException {
        emailService.loadEmails(casos);
        return casos;
    }
    
    @Override
    public List<Caso> carregaIconeEmails(List<Caso> casos) throws ServiceException {
        emailService.loadIconeEmails(casos);
        return casos;
    }
        

	/**
	 * Busca todos os casos que estão ativos na fila de um atendente.
	 * 
	 * @param atendente
	 * @return
	 * @throws ServiceException
	 */
	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<Caso> buscaTodosCasosAtivosAtendente(Atendente atendente)
			throws ServiceException {
		try {
			List<Caso> casoList = getDAO().buscaTodosCasosAtivosAtendente(atendente);
			carregaSlas(casoList);
            carregaIconeEmails(casoList);
			
            for (Caso caso : casoList) {
				carregaStatus(caso);
				List<Agendamento> agendamento = agendamentoService.buscaAtivosPeloCaso(caso);
				if (agendamento != null && agendamento.size() > 0) {
					caso.setAgendamento(agendamento.get(0));
				} else {
					caso.setAgendamento(new Agendamento());
				}
			}
			return casoList;
		} catch (DataException e) {
			throw new ServiceException("Erro ao buscar todos os casos ativos para o atendente: "+ atendente.getIdAtendente(), e);
		}
	}
	
	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public Caso buscaProximoCasoAgendadoFila(List<ConfiguracaoFila> confList) throws ServiceException {
		if (confList == null || confList.isEmpty()) {
			return null;
		}
        try {
            List<Caso> casoList = getDAO().buscaProximoCasoAgendadoFila(confList);
            
            if (casoList != null && casoList.size() > Integer.valueOf(0)) {
                Caso caso = casoList.get(0);
                caso.setAgendamentos(agendamentoService.buscaPeloCaso(caso));
            	return caso;
            }

        } catch (DataException e) {
             throw new ServiceException("Erro ao buscar o proximo caso agendado da fila.", e);
        }
		
		return null;
	}

	/**
	 * Carrega o status do caso.
	 * 
	 * @param caso
	 * @throws ServiceException
	 */
	private void carregaStatus(Caso caso) throws ServiceException {
		try {
			caso.setStatus(statusService.findByPk(caso.getStatus()));
		} catch (ServiceException e) {
			throw new ServiceException("Erro ao buscar o status do caso", e);
		}
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public void retiraFilaCaso(ConfiguracaoFila configuracaoFila) throws ServiceException {
		try {
			getDAO().retiraFilaCaso(configuracaoFila);
		} catch (DataException e) {
			throw new ServiceException("Problema ao retirar a configura\u00E7\u00E3o da fila do caso.", e);
		}
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<Caso> buscaCasosOrdernadosPorFilaSemAtendente(ConfiguracaoFila confFila, Integer quantidadeCasos)
			throws ServiceException, ValidationException {
		if (confFila == null) {
			throw new ValidationException("O campo confFila n\u00E3o pode ser nulo.");
		}

		ParametroGBO parametroGBO = parametroGBOService.findByParam(Constantes.TB_CASO_ESPECIALISTA);

		try {
			return getDAO().buscaCasosOrdernadosPorFilaSemAtendente(parametroGBO.getValor(), confFila.getSqlOrder(), confFila,quantidadeCasos);
		} catch (DataException e) {
			throw new ServiceException("Falha ao buscar os da fila ordenados conforme configura\u00E7\u00E3o.",e);
		}
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<Caso> buscaCasosAtivosPorConfiguracaoFila(
			ConfiguracaoFila configuracaoFila) throws ServiceException {
		try {
			return getDAO().buscaCasosAtivosPorConfiguracaoFila(configuracaoFila);
		} catch (DataException e) {
			throw new ServiceException("Erro ao buscar Casos.", e);
		}
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public Caso buscaCasoAgendado(Atendente atendente) throws ServiceException, ValidationException {
		try {
			List<Caso> casoList = getDAO().buscaCasoAgendado(atendente);
			if (casoList == null || casoList.isEmpty()) {
				return null;
			} else {
				Caso caso = casoList.get(0);
				// Desativar o agendamento.
				agendamentoService.inativar(caso);
				
				caso.setAgendamentos(agendamentoService.buscaPeloCaso(caso));
				
				return caso;
			}
		} catch (DataException e) {
			throw new ServiceException("Erro ao buscar Caso.", e);
		}
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<Caso> buscaPorStatus(Status status) throws ServiceException {

		try {
			List<Caso> casos = getDAO().buscaPorStatus(status);
			if (casos != null && !casos.isEmpty()) {

				for (Caso caso : casos) {
					if (caso.getConfiguracaoFila() != null
							&& caso.getConfiguracaoFila().getPK() != null) {
						caso.setConfiguracaoFila(configuracaoFilaService.findByPk(caso.getConfiguracaoFila()));
					}
					if (caso.getStatus() != null
							&& caso.getStatus().getPK() != null) {
						caso.setStatus(statusService.findByPk(caso.getStatus()));
					}

				}
			}
			return casos;
		} catch (DataException e) {
			throw new ServiceException("Erro ao buscar Casos.", e);
		}
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public Caso load(Caso caso) throws ServiceException {

        try {
			if (caso == null) {
				throw new ServiceException("Caso informado esta nulo.");
			}
			return getDAO().load(caso);
        } catch (DataException e) {
            throw new ServiceException("Erro ao carregar caso.", e);
        }
    }
        
    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public Boolean retiraCasoAtendentesInativos() throws ServiceException, ValidationException {
        ParametroGBO parametroGBO = parametroGBOService.findByParam(Constantes.TEMPO_RETIRA_CASO_FILA_ATENDENTE);
                
        List<Caso> casoList = buscaCasoEmAtendimento();
        carregaSlas(casoList);
        
        for (Caso caso : casoList) {
            Log ultimoLog = null;
            List<Log> logList = logService.findHistorico(caso);
            if (logList != null && !logList.isEmpty()) {
                ultimoLog = logList.get(logList.size()-1);
                
                String slaCasoSplit[] = caso.getSlaEmMinutos().split(":");
                String slalogSplit[] = ultimoLog.getSlaLog().split(":");
                
                Integer slaCaso = (Integer.valueOf(slaCasoSplit[0]) * 60) + Integer.valueOf(slaCasoSplit[1]);
                Integer slaLog = (Integer.valueOf(slalogSplit[0]) * 60) + Integer.valueOf(slalogSplit[1]);
                
                if (slaCaso - slaLog > (Integer.valueOf(parametroGBO.getValor()) * 60)) {
                    caso.setAtendente(null);
                    caso.setConfiguracaoFila(null);
                    caso.setFlagClassifica(Boolean.TRUE);
                    configuracaoFilaService.removeFilaClassificaoCaso(caso);
                    
                    Log log = new Log();
                    log.setCaso(caso);
                    log.setDescricao("Caso retirado do atendente por ficar inativo.");
                    log.setConfiguracaoFila(caso.getConfiguracaoFila());
                    logService.saveLogAnexos(log);
                    update(caso);
                }
            }
        }
        
        return true;
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<Caso> buscaCasoEmAtendimento() throws ServiceException {
        try {
            return getDAO().buscaCasoEmAtendimento();
        } catch (DataException ex) {
            throw new ServiceException("Erro ao buscar os casos em atendimento.",ex);
        }
    }
    
    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void finalizaCaso(Caso caso, String userLogin) throws ServiceException, ValidationException {
        
        Date dataBanco = getDataBanco();
        caso.setFlagFinalizado(Boolean.TRUE);
        caso.setFlagEmAtendimento(Boolean.FALSE);
        caso.setDataEncerramento(dataBanco);
        if (caso.getDataFimSla() == null) {
            caso.setDataFimSla(dataBanco);
        }
        update(caso);
        
        configuracaoFilaService.removeFilaClassificaoCaso(caso);
        
        List<Agendamento> agendamentoList = agendamentoService.buscaAtivosPeloCaso(caso);
        if (agendamentoList != null && !agendamentoList.isEmpty()) {
        	agendamentoService.inativar(caso);
        }
        
        logService.saveLog(caso, "Caso finalizado pelo usuário: " + userLogin + " na tela de caso_fechado");
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void delegaCasoAtendente(Caso caso, Atendente atendente, String supervisorLogin) throws ServiceException, ValidationException {
    	try {
	    	Caso casoUpdate = getDAO().findByPk(caso);
	    	
	    	if (casoEstaEmAtendimento(casoUpdate)) {
	    		throw new ValidationException("Caso de c\u00F3digo " + caso.getIdExterno() + " em atendimento.");
	    	}
	    	if (casoUpdate.getFlagFinalizado()) {
	    		throw new ValidationException("Caso de c\u00F3digo " + caso.getIdExterno() + " já finalizado.");
	    	}
	    	
	    	if(casoUpdate.getConfiguracaoFila() == null){
	    		throw new ValidationException("Caso de c\u00F3digo " + caso.getIdExterno() + " não possui fila de atendimento.");
	    	}
	    	
	    	List<EquipeFila> equipeFilas = equipeFilaService.buscaEquipeFilaPelaPrioridade(atendente.getEquipe());
	    	
	    	boolean possuiFila = false;
	    	for (EquipeFila equipeFila : equipeFilas) {
	    		if (equipeFila.getConfiguracaoFila().getIdConfiguracaoFila().equals(casoUpdate.getConfiguracaoFila().getIdConfiguracaoFila())) {
	    			possuiFila = true;
	    		}
	    	}
	    	
	    	if (!possuiFila) {
	    		throw new ValidationException("Caso de c\u00F3digo " + caso.getIdExterno() + " foi alterado. A fila em que o mesmo foi classificado não pode ser atendida pelo analista selecionado.");
	    	}
	    	
	    	casoUpdate.setAtendente(atendente);
	        update(casoUpdate);
	        
	        Log log = new Log();
	        log.setDescricao("Caso enviado para o atendente: "+atendente.getLogin()+". Pelo Supervisor: "+ supervisorLogin);
	        log.setCaso(casoUpdate);
	        log.setStatus(casoUpdate.getStatus());
	        log.setConfiguracaoFila(casoUpdate.getConfiguracaoFila());
	        logService.saveLogAnexos(log);
    	} catch (ValidationException e) {
    		throw e;
    	} catch (Exception e) {
			throw new ServiceException("Erro ao delegar casos.",e);
		}
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public Integer quantidadeCasosFechados(Integer idAtendente, Integer idFila, Date dataInicial, Date dataFinal) throws ServiceException {
    	try {
    		return getDAO().quantidadeCasosFechados(idAtendente, idFila, dataInicial, dataFinal);
    	} catch (DataException e) {
			throw new ServiceException(e);
		}
    }

    
    @Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<Caso> buscaCasoReclassificaReabertura() throws ServiceException {
    	try {
    		return getDAO().buscaCasoReclassificaReabertura();
    	} catch (Exception e) {
			throw new ServiceException("Erro ao buscar todos os casos reabertos e reclassificados",e);
		}
    }

	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<Caso> findCasoEmAtendimento(Atendente atendente) throws ServiceException {
		try {
			return getDAO().findCasoEmAtendimento(atendente);
		} catch (DataException ex) {
			throw new ServiceException("Erro ao buscar casos em atendimento por atendente", ex);
		}
	}
    
	@Override
	public void atualizaFlagEmAtendimentoParaFalse(Atendente atendente) throws ServiceException {
		try {
			
			List<Atendente> listaAtendente = new ArrayList<Atendente>();
			listaAtendente.add(atendente);
			atualizaFlagEmAtendimentoParaFalse(listaAtendente);
		} catch (Exception ex) {
			throw new ServiceException("Erro ao finalizar flag em atendimento por um atendente", ex);
		}
	}	
	
	
	@Override
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void atualizaFlagEmAtendimentoParaFalse(List<Atendente> listaAtendente) throws ServiceException {
		try {
			getDAO().atualizaFlagEmAtendimentoParaFalse(listaAtendente);
		} catch (Exception ex) {
			throw new ServiceException("Erro ao finalizar flag em atendimento por uma lista de atendentes", ex);
		}
	}
	
	@Override
	public boolean casoEstaEmAtendimento(Caso caso) throws ServiceException {
		caso = findByPk(caso);
		
		if (caso == null || caso.getFlagEmAtendimento() == null) {
			return false;
		}
		
		return caso.getFlagEmAtendimento();
	}
	
	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public boolean validaStatusCaso(Caso caso) throws ServiceException, ValidationException {
		try {
			if (caso != null && caso.getStatus() != null) {
				Caso casoValida = getDAO().findByPk(caso);
				if (casoValida != null && casoValida.getStatus() != null) {
					if (caso.getStatus().getIdStatus().equals(casoValida.getStatus().getIdStatus())) {
						return true;
					} else {
						return false;
					}
				} else {
					throw new ValidationException("Não foi possivel identificar o status do caso");
				}
			} else {
				throw new ValidationException("Não foi possivel identificar o status do caso");
			}
		} catch (DataException e) {
			throw new ServiceException("Erro ao validar o status do caso",e);
		}
	}
	
	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<Caso> atendentePossuiCasoEmAtendimento(String loginAtendente) throws ServiceException {
		try {
			Atendente atendente = atendenteService.findByLogin(loginAtendente);
			return getDAO().atendentePossuiCasoEmAtendimento(atendente);
		} catch (Exception e) {
			throw new ServiceException("Erro ao buscar os casos em atendimento do atendente",e);
		}
	}
	
	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public boolean validaSeCasoEstaSendoProcessadoPeloSpa(Caso caso) throws ServiceException {
		try {
			
			ParametroGBO parametroFlagProcessandoSpa = parametroGBOService.findByParam(Constantes.FLAG_PROCESSANDO_SPA);
			if(parametroFlagProcessandoSpa == null || StringUtils.isBlank(parametroFlagProcessandoSpa.getValor())) {
				throw new ValidationException("Parametro de configuração do processamento do Spa não existe na base de dados.");
			}
			if(Boolean.valueOf(parametroFlagProcessandoSpa.getValor()).equals(Boolean.FALSE)) {
				return Boolean.FALSE;
			}
			ParametroGBO parametroTabelaImportacaoCaso = parametroGBOService.findByParam(Constantes.TABELA_IMPORTACAO_CASO);
			if(parametroTabelaImportacaoCaso == null || StringUtils.isBlank(parametroTabelaImportacaoCaso.getValor())) {
				throw new ValidationException("Parametro de tabela temporaria de importação não existe na base de dados.");
			}
			
			return getDAO().validaSeCasoEstaSendoProcessadoPeloSpa(caso, parametroTabelaImportacaoCaso.getValor());
			
		} catch (Exception e) {
			throw new ServiceException("Erro ao buscar os casos em atendimento do atendente",e);
		}
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<Caso> buscaCasosSLAFimDia() throws ServiceException {
		try { 
			return getDAO().buscaCasosSLAFimDia();
		} catch (Exception e) {
			throw new ServiceException("Erro ao buscar os casos com data fim sla",e);
		}
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<Caso> buscaCasosSLAFimDia(Date dataBusca) throws ServiceException {
		try { 
			return getDAO().buscaCasosSLAFimDia(dataBusca);
		} catch (Exception e) {
			throw new ServiceException("Erro ao buscar os casos com data fim sla",e);
		}
	}

	@Override
	public void flush() {
		getDAO().flush();
	}
	
	@Override
	public List<AtendenteCasoStatusTO> buscarQuantidadeCasosAtendidosPorStatus() throws ServiceException {
		try{
			final List<AtendenteCasoStatusTO> list = getDAO().buscarQuantidadeCasosAtendidosPorStatus();
			
			if(list != null && !list.isEmpty()){
				List<Integer> idsStatus = new ArrayList<>();
				List<Integer> idsAtendentes = new ArrayList<>();
				
				for (AtendenteCasoStatusTO atdCasos : list) {
					if(! idsAtendentes.contains(atdCasos.getIdAtendente())){
						idsAtendentes.add(atdCasos.getIdAtendente());
					}
					
					for (CasoStatusTO casoStat : atdCasos.getListCasos()) {
						if(! idsStatus.contains(casoStat.getIdStatus())){
							idsStatus.add(casoStat.getIdStatus());
						}
					}
				}
				
				List<Status> stList = statusService.findByPkIn(idsStatus);
				List<Atendente> atList = atendenteService.findByPkIn(idsAtendentes);
				
				for (AtendenteCasoStatusTO atdCasos : list) {
					for (CasoStatusTO casoStat : atdCasos.getListCasos()) {
						for (Status st : stList) {
							if(casoStat.getIdStatus().equals(st.getIdStatus())){
								casoStat.setNomeStatus(st.getNome());
								break;
							}
						}					
					}
					
					for (Atendente at : atList) {
						if(atdCasos.getIdAtendente().equals(at.getIdAtendente())){
							atdCasos.setNomeAtendente(at.getNome());
							break;
						}
					}
				}
			}
			
			return list;
			
		}catch (DataException e){
			throw new ServiceException(e);
		}
	}

	@Override
	public List<Caso> buscarTodosCasosPendentesDoCliente(Atendente atendente, Integer idCaso) throws ServiceException {
		List<ParametroGBO> params = parametroGBOService.findByParam(Constantes.TB_CASO_ESPECIALISTA, Constantes.SQL_WHERE_CASOS_PENDENTES_MESMO_CLIENTE);

		try {
			/* Valores padrão */
			String tbcasoespecialista = "tb_caso_sau";
			String sqlWhere = "WHERE Caso.ID_CASO = ?";
			
			for (ParametroGBO parametroGBO : params) {
				tbcasoespecialista = Constantes.TB_CASO_ESPECIALISTA.equals(parametroGBO.getNome()) ? parametroGBO.getValor() : tbcasoespecialista;
				sqlWhere = Constantes.SQL_WHERE_CASOS_PENDENTES_MESMO_CLIENTE.equals(parametroGBO.getNome()) ? parametroGBO.getValor() : sqlWhere;
			}
			
			return getDAO().buscarTodosCasosPendentesDoCliente(atendente, tbcasoespecialista, sqlWhere, idCaso);
			
		} catch (DataException e) {
			throw new ServiceException("Falha ao buscar todos casos pendentes do cliente.",e);
		}
	}

	@Override
	public Caso buscarCasoPorIdExterno(String idExterno) throws ServiceException {
		try { 
			return getDAO().buscarCasoPorIdExterno(idExterno);
		} catch (Exception e) {
			throw new ServiceException("Erro ao buscar os casos por IdExterno", e);
		}
	}

	@Override
	public void atuaizarVencimentoSlaByFinalizado(Boolean casosFinalizados) throws ServiceException {
		try { 
			List<Caso> casos = getDAO().buscarCasoSemVencimentoSlaByFinalizado(casosFinalizados);
			
			for (Caso caso : casos) {
				caso = slaService.loadSla(caso);
				getDAO().atualizarDataVencimentoSla(caso);
			}
			
		} catch (Exception e) {
			throw new ServiceException("Erro ao atualizar vencimento de sla", e);
		}
	}
	
	@Override
	public List<String> buscaColunasTabelaCaso() throws ServiceException {
		try {
			return getDAO().buscaColunasTabelaCaso();
		} catch (Exception e) {
			throw new ServiceException("Erro ao buscar colunas da tabela tb_caso", e);
		}
	}
	
}
