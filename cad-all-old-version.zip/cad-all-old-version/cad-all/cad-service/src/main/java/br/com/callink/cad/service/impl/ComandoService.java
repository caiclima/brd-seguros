package br.com.callink.cad.service.impl;

import java.util.Date;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import br.com.callink.cad.dao.IComandoDAO;
import br.com.callink.cad.pojo.Comando;
import br.com.callink.cad.pojo.ParametroComando;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.service.IComandoService;
import br.com.callink.cad.service.IParametroComandoService;
import br.com.callink.cad.service.IStatusService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 * @author Rogerio Moreira [rogeriom@swb.com.br]
 * 
 */
@Stateless
public class ComandoService extends GenericGboService<Comando, IComandoDAO>
        implements IComandoService {

    private static final long serialVersionUID = 1L;

    @Inject
    private IComandoDAO comandoDAO;
    
    @EJB
    private IStatusService statusService;
    
    @EJB
    private IParametroComandoService parametroComandoService;
    
    @Override
	protected IComandoDAO getDAO() {
		return comandoDAO;
	}
    
    
    @Override
    public void save(Comando comando) throws ServiceException, ValidationException {
        validacoesComando(comando);
        super.save(comando);
    }

    @Override
    public void update(Comando comando) throws ServiceException, ValidationException {
        validacoesComando(comando);
        super.update(comando);
    }

    /**
     * @param comando
     * @throws ServiceException
     * @throws ValidationException 
     */
    private void validacoesComando(Comando comando) throws ValidationException {
        if (comando == null) {
            throw new ValidationException("O comando n\u00E3o pode ser nulo.");
        }
        if (comando.getFlagAtivo() == null) {
            comando.setFlagAtivo(Boolean.TRUE);
        }
        if (comando.getBeanName() == null || comando.getNome() == null
                || comando.getBeanName().isEmpty() || comando.getNome().isEmpty()) {
            throw new ValidationException("Os campos obrigat\u00F3rios devem ser preenchidos.");
        }

        comando.setDataCriacao(new Date());
    }

    @Override
    public List<Comando> findByExample(Comando object) throws ServiceException {
        return loadStatus(super.findByExample(object));
    }

    @Override
    public List<Comando> findAll() throws ServiceException {
        return loadStatus(super.findAll());
    }

    private List<Comando> loadStatus(List<Comando> comandoList) throws ServiceException{
        for (Comando cmd : comandoList) {
            if (cmd.getStatus() != null && cmd.getStatus().getIdStatus() != null) {
                cmd.setStatus(statusService.findByPk(cmd.getStatus()));
            }
        }
        return comandoList;
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<Comando> findAtivos() throws ServiceException {
        try {
            return getDAO().findAtivos("Comando.NOME");
        } catch (DataException ex) {
            throw new ServiceException("Erro ao buscar comandos.", ex);
        }
    }

    @Override
    public void inativar(Comando comando) throws ServiceException, ValidationException {
        if (comando.getPK() == null) {
			throw new ValidationException("Falha ao inativar: chave primaria n\u00E3o informada.");
        } else {
            comando.setFlagAtivo(Boolean.FALSE);
            update(comando);
        }
    }
    
    @Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<Comando> findByExample(Comando example, String order) throws ServiceException {
        try {
            return getDAO().findByExample(example, order);
        } catch (DataException ex) {
            throw new ServiceException("Erro ao buscar comandos.", ex);
        }
    }

    @Override
    public void delete(Comando comando) throws ServiceException, ValidationException {
    	
    	ParametroComando parametroComando = new ParametroComando();
    	parametroComando.setComando(comando);
    	List<ParametroComando> parametros = parametroComandoService.findByExample(parametroComando);
    	
    	for (ParametroComando param : parametros) {
			parametroComandoService.delete(param);
		}
    	super.delete(comando);
    }
}
