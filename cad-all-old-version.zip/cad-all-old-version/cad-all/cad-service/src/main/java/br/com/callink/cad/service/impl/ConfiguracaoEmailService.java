package br.com.callink.cad.service.impl;

import java.util.List;
import java.util.Properties;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.dao.IConfiguracaoEmailDAO;
import br.com.callink.cad.pojo.ConfiguracaoEmail;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.service.IConfiguracaoEmailService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.util.Constantes;
import br.com.callink.cad.util.EncryptionUtils;

@Stateless
public class ConfiguracaoEmailService extends GenericGboService<ConfiguracaoEmail, IConfiguracaoEmailDAO> implements IConfiguracaoEmailService {
	
	private static final long serialVersionUID = 1L;

	@Inject
	private IConfiguracaoEmailDAO configuracaoEmailDAO;
	
	@Override
	protected IConfiguracaoEmailDAO getDAO() {
		return configuracaoEmailDAO;
	}
	
	@Override
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void save(ConfiguracaoEmail configuracaoEmail) throws ServiceException, ValidationException {
		validaCampos(configuracaoEmail);
		configuracaoEmail.setDataCriacao(getDataBanco());
		tirarEspacosString(configuracaoEmail);
		configuracaoEmail.setSenha(EncryptionUtils.encrypt(configuracaoEmail.getSenha()));
		super.save(configuracaoEmail);
	}
	
	@Override
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void update(ConfiguracaoEmail configuracaoEmail) throws ServiceException, ValidationException {
		validaCampos(configuracaoEmail);
		tirarEspacosString(configuracaoEmail);
		configuracaoEmail.setSenha(EncryptionUtils.encrypt(configuracaoEmail.getSenha()));
		super.update(configuracaoEmail);
	}
	
	@Override
	public void inativar(ConfiguracaoEmail configuracaoEmail) throws ServiceException {
		configuracaoEmail.setFlagAtivo(Boolean.FALSE);
		try {
			getDAO().update(configuracaoEmail);
		} catch (DataException e) {
			throw new ServiceException("N\u00E3o foi poss\u00EDvel alterar o configuracaoEmail.",e);
		}
	}
	
	private void tirarEspacosString(ConfiguracaoEmail configuracaoEmail) {
		configuracaoEmail.setEmail(configuracaoEmail.getEmail().trim());
		configuracaoEmail.setSenha(configuracaoEmail.getSenha().trim());
		configuracaoEmail.setFolder(configuracaoEmail.getFolder().trim());
		configuracaoEmail.setPop(configuracaoEmail.getPop().trim());
		configuracaoEmail.setSmtp(configuracaoEmail.getSmtp().trim());
		configuracaoEmail.setProtocolStore(configuracaoEmail.getProtocolStore().trim());
		configuracaoEmail.setAssinatura(configuracaoEmail.getAssinatura().trim());
	}

	private void validaCampos(ConfiguracaoEmail configuracaoEmail) throws ValidationException, ServiceException {
		if (configuracaoEmail == null) {
			throw new ValidationException("A Configuracao de Email n\u00E3o pode ser nula.");
		}
		if (StringUtils.isEmpty(configuracaoEmail.getEmail())) {
			throw new ValidationException("Favor informar o email.");
		}
		if (StringUtils.isEmpty(configuracaoEmail.getSenha())) {
			throw new ValidationException("Favor informar a senha.");
		}
		if (StringUtils.isEmpty(configuracaoEmail.getSmtp())) {
			throw new ValidationException("Favor informar o smtp.");
		}
		if (StringUtils.isEmpty(configuracaoEmail.getPop())) {
			throw new ValidationException("Favor informar o pop.");
		}
		if (StringUtils.isEmpty(configuracaoEmail.getFolder())) {
			throw new ValidationException("Favor informar a pasta.");
		}
		if (StringUtils.isEmpty(configuracaoEmail.getProtocolStore())) {
			throw new ValidationException("Favor informar o protocol store.");
		}
		if (configuracaoEmail.getPorta() == null) {
			throw new ValidationException("Favor informar a porta imap.");
		}
		if (configuracaoEmail.getAssinatura() == null) {
			throw new ValidationException("Favor informar o assinatura.");
		}
		if (configuracaoEmail.getFlagAtivo() == null) {
			throw new ValidationException("Favor informar o campo ativo.");
		}
		if (configuracaoEmail.getFlagPrincipal() == null) {
			throw new ValidationException("Favor informar o campo principal.");
		}
		if(configuracaoEmail.getFlagPrincipal()) {
			verificaConfiguracaoPrincipal(configuracaoEmail.getIdConfiguracaoEmail());
		}
	}
	
	private void verificaConfiguracaoPrincipal(Integer idConfiguracaoEmail) throws ValidationException, ServiceException {
		ConfiguracaoEmail ce = new ConfiguracaoEmail();
		ce.setFlagAtivo(Boolean.TRUE);
		ce.setFlagPrincipal(Boolean.TRUE);
		List<ConfiguracaoEmail> list = findByExample(ce);
		if(list != null && !list.isEmpty() && (idConfiguracaoEmail == null || !idConfiguracaoEmail.equals(list.get(0).getIdConfiguracaoEmail()))) {
			throw new ValidationException("Já existe um email principal cadastrado!");
		}
	}
	
	@Override
    public Properties enviaEmailProperties(ConfiguracaoEmail configuracaoEmail) {
        Properties props = new Properties();
        props.put(Constantes.PARAMETRO_EMAIL_USUARIO, configuracaoEmail.getEmail().trim());
        props.put(Constantes.PARAMETRO_EMAIL_SENHA, EncryptionUtils.decrypt(configuracaoEmail.getSenha().trim()));
        props.put(Constantes.PARAMETRO_EMAIL_SMTPHOST, configuracaoEmail.getSmtp().trim());
        props.put(Constantes.PARAMETRO_EMAIL_POPHOST, configuracaoEmail.getPop().trim());
        props.put(Constantes.PARAMETRO_EMAIL_FOLDER, configuracaoEmail.getFolder().trim());
        props.put(Constantes.PARAMETRO_EMAIL_PROTOCOLSTORE, configuracaoEmail.getProtocolStore().trim());
        props.put(Constantes.PARAMETRO_EMAIL_IMAPPORT, configuracaoEmail.getPorta());
        props.put("mail.transport.protocol", "smtp");
        props.put("mail.smtp.host", configuracaoEmail.getSmtp().trim());
        props.put("mail.smtp.auth", String.valueOf(Boolean.TRUE));
        return props;
    }
	
	@Override
	public List<ConfiguracaoEmail> findByIds(List<Integer> ids) throws ServiceException {
		try {
			return getDAO().findByIds(ids);
		} catch (DataException e) {
			throw new ServiceException("N\u00E3o foi poss\u00EDvel buscar as configuracaoEmail.",e);
		}
	}
	
	@Override
	public void validarSave(ConfiguracaoEmail configuracaoEmail) throws ValidationException {
	}

	@Override
	public void validarUpdate(ConfiguracaoEmail configuracaoEmail) throws ValidationException {
	}

	@Override
	public void validarDelete(ConfiguracaoEmail object) throws ValidationException {
	}

	@Override
	public List<ConfiguracaoEmail> findByExample(ConfiguracaoEmail example,
			String order) throws ServiceException {
		try {
			return getDAO().findByExample(example, order);
		} catch (DataException e) {
			throw new ServiceException("N\u00E3o foi poss\u00EDvel buscar a configuracaoEmail.",e);
		}
	}
	
	@Override
	public ConfiguracaoEmail buscarConfPrincipal() throws ServiceException {
		try {
			ConfiguracaoEmail example = new ConfiguracaoEmail();
			example.setFlagAtivo(Boolean.TRUE);
			example.setFlagPrincipal(Boolean.TRUE);
		
			List<ConfiguracaoEmail> confs = getDAO().findByExample(example);
			
			return confs == null || confs.size() == 0 ? null : confs.get(0);
		} catch (DataException e) {
			throw new ServiceException("Erro ao buscar configuração de e-mail principal. Motivo: " + e.getMessage(), e);
		}
				
	}
}
