package br.com.callink.cad.service.impl;

import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import br.com.callink.cad.dao.IConfiguracaoFilaDAO;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.pojo.LogSlaCaso;
import br.com.callink.cad.pojo.SlaFila;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.service.ICasoService;
import br.com.callink.cad.service.IConfiguracaoFilaPersistService;
import br.com.callink.cad.service.IConfiguracaoFilaService;
import br.com.callink.cad.service.ILogService;
import br.com.callink.cad.service.ILogSlaCasoService;
import br.com.callink.cad.service.IParametroGBOService;
import br.com.callink.cad.service.ISlaFilaService;
import br.com.callink.cad.service.ISlaService;
import br.com.callink.cad.service.exception.ServiceException;

/**
 * 
 * @author brunomt [brunoam@swb.com.br]
 *
 */
@Stateless
public class ConfiguracaoFilaPersistService extends GenericGboService<ConfiguracaoFila, IConfiguracaoFilaDAO> implements IConfiguracaoFilaPersistService {
	
	private static final long serialVersionUID = -3240547866981260832L;

	private Logger logger = Logger.getLogger(ConfiguracaoFilaPersistService.class.getName());
	
	
	@Inject
	private IConfiguracaoFilaDAO configuracaoFilaDAO;
	
	@EJB
	private ICasoService casoService;
	@EJB
	private ILogService logService;
	@EJB
    private IParametroGBOService parametroGBOService;
	@EJB
	private ISlaFilaService slaFilaService;
	@EJB
	private ILogSlaCasoService logSlaCasoService;
	@EJB
	private IConfiguracaoFilaService configuracaoFilaService;
	@EJB(beanName="SlaTipoFilaService")
    private ISlaService slaService;
	@Override
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void update (ConfiguracaoFila configuracaoFila) throws ServiceException {
		try {
			configuracaoFilaService.update(configuracaoFila);	
		} catch (Exception e) {
			throw new ServiceException("Erro ao salvar a configuracao fila;",e);
		}
		
	}
	
	@Override
	protected IConfiguracaoFilaDAO getDAO() {
		return configuracaoFilaDAO;
	}
	
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	private void insereCasoNaFila(Caso caso, ConfiguracaoFila configuracaoFila) throws ServiceException {
		try {
            //Deleta qualquer ocorrencia do caso na fila.
            removeFilaClassificaoCaso(caso);
                        
			//Se a fila já existe, só inclui o caso na fila
			getDAO().insereCasoFila(caso, configuracaoFila);
		} catch (DataException e) {
			throw new ServiceException("Erro ao salvar o caso na fila.",e);
		}
	}
	
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	private void removeFilaClassificaoCaso(Caso caso) throws ServiceException {
		try {
			getDAO().removeFilaClassificaoCaso(caso);
		}catch(DataException e) {
			throw new ServiceException("Erro ao remover fila de classifica\u00E7\u00E3o.", e);
		}
	}
	
	/**
	 * Remove os casos que estão em uma configuração de fila. Atualiza os casos para que o build consiga atualizar os mesmos.
	 * 
	 * @param configuracaoFilas
	 * @param casoService 
	 * @throws ServiceException
	 */
	@Override
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void removeCasosFilasBuild(List<ConfiguracaoFila> configuracaoFilas) throws ServiceException {
		for (ConfiguracaoFila confFila : configuracaoFilas) {
			try {
				getDAO().removeCasosClassificacaoFila(confFila);
				casoService.retiraFilaCaso(confFila);
			} catch (DataException e) {
				throw new ServiceException("N\u00E3o foi poss\u00EDvel limpar a fila.",e);
			}
		}
	}
	
	/**
	 * Busca sla_fila ativo para uma configuração. Caso não encontre, será criado um SLA padrão.
	 * 
	 * @param idConfiguracao
	 * @return SlaFila
	 * @throws ServiceException
	 */
	private SlaFila buscaOuCriaSla(ConfiguracaoFila configuracaoFila) throws ServiceException {
		try {
	        Properties propertiesApp = new Properties();
	        propertiesApp.load(SlaTipoFilaService.class.getResourceAsStream("/config/gbo.properties"));
	        
	        SlaFila slaFila = slaFilaService.findSlaFilaByConfFilaAndDataFimNull(configuracaoFila);
	        
	        //Verifica se o slaFila é um objeto vazio.
	        if (slaFila == null || slaFila.getIdSlaFila() == null || slaFila.getIdSlaFila() < 1) {
	        	slaFila = new SlaFila();
	        	slaFila.setConfiguracaoFila(configuracaoFila);
	        	slaFila.setDataFinal(null);
	        	slaFila.setDataInicial(new Date(System.currentTimeMillis()));
	        	slaFila.setSla(Integer.parseInt(parametroGBOService.findByParam(propertiesApp.getProperty("parametro.temposla")).getValor()));
	        	slaFila.setDescricao("SLA padrão");
	        	
	        	slaFilaService.save(slaFila);
	        }
	        
			return slaFila;
		} catch (Exception ex) {
			throw new ServiceException("Erro ao verifica sla fila em ConfiguracaoFilaService",ex);
		}
	}

	
	public void persistClassificaCasos(List<Caso> casoList, ConfiguracaoFila confFila) throws ServiceException {
		
		try {
			
			for (Caso caso : casoList) {
	            insereCasoNaFila(caso, confFila);
	            caso.setConfiguracaoFila(confFila);
	            caso.setFlagClassifica(false);
	            
	            SlaFila slaFilaAnterior = caso.getSlaFila();
	
	            //Insere um sla_fila existente para a configuração ou cria um sla_fila padrão definido por parametros.
	            SlaFila slaFila = buscaOuCriaSla(caso.getConfiguracaoFila());
	            caso.setSlaFila(slaFila);
	            
	            //Verifica se zera SLA
	            if (slaFila.getFlagIniciaSLA() != null && slaFila.getFlagIniciaSLA() && 
	            		(caso.getSlaFila() != null && caso.getSlaFila().getIdSlaFila() != null)) {
	            	LogSlaCaso logSlaCaso = new LogSlaCaso();
	            	logSlaCaso.setDataAbertura(caso.getDataAbertura());
	            	
	            	caso.setDataAbertura(getDataBanco());
	            	
	            	//Cria log com SLA antigo, data abertura antiga, e nova data de abertura
	            	logSlaCaso.setCaso(caso);
	            	logSlaCaso.setDataAlteracao(caso.getDataAbertura());
	            	if (slaFilaAnterior != null) {
		            	logSlaCaso.setSlaFila(slaFilaAnterior);
		            	logSlaCaso.setConfiguracaoFila(slaFilaAnterior.getConfiguracaoFila());
		            	
		            	//Calcula o SLA do caso.		            	
		            	Caso casoCalcSla = new Caso();
		            	casoCalcSla.setDataAbertura(logSlaCaso.getDataAbertura());
		            	casoCalcSla.setDataCadastro(caso.getDataCadastro());
		            	casoCalcSla.setIdExterno(caso.getIdExterno());
		            	casoCalcSla.setSlaFila(slaFilaAnterior);
		            	slaService.loadSla(casoCalcSla);
		            	
		            	logSlaCaso.setPercentualGasto(casoCalcSla.getPorcentagemSla());
		            	logSlaCaso.setTempoSla(retornaSlaMinutos(casoCalcSla.getSlaEmMinutos()));
		            	
		            	logSlaCasoService.save(logSlaCaso);
	            	}
	            	
	            }
	
	            casoService.update(caso);
	
	            logService.saveLog(caso, "Caso classificado com sucesso para a fila: "+confFila.getNome());
	        }
		
		} catch (Exception e) {
    		logger.log(Level.SEVERE, "Erro ao limpar tabela de historico dos casos.", e);
		}
	}

	private Integer retornaSlaMinutos(String slaEmMinutos) {
		if (slaEmMinutos == null) {
			return 0;
		}
		
		String[] str = slaEmMinutos.split(":");
		Integer minutos = 0;
		try {
			minutos = (Integer.valueOf(str[0]) * 60) + Integer.valueOf(str[1]);
		} catch (Exception e) {
			logger.info("SLA em minutos não pode ser calculado");
		}
		return minutos;
	}
}
