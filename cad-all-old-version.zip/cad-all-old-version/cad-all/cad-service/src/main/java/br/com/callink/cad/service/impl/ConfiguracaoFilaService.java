package br.com.callink.cad.service.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import br.com.callink.cad.dao.IConfiguracaoFilaDAO;
import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.pojo.Equipe;
import br.com.callink.cad.pojo.EquipeFila;
import br.com.callink.cad.pojo.HistoricoGbo;
import br.com.callink.cad.pojo.ParametroGBO;
import br.com.callink.cad.pojo.SlaFila;
import br.com.callink.cad.pojo.StatusAtendente;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.service.IAtendenteService;
import br.com.callink.cad.service.ICasoService;
import br.com.callink.cad.service.IConfiguracaoFilaPersistService;
import br.com.callink.cad.service.IConfiguracaoFilaService;
import br.com.callink.cad.service.IEquipeFilaService;
import br.com.callink.cad.service.IEquipeService;
import br.com.callink.cad.service.IHistoricoGboService;
import br.com.callink.cad.service.IParametroGBOService;
import br.com.callink.cad.service.ISlaFilaService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.service.repository.ControleStatusAtendentes;
import br.com.callink.cad.util.Constantes;

import com.google.gson.Gson;

/**
 * 
 * @author brunomt [brunoam@swb.com.br]
 *
 */
@Stateless
public class ConfiguracaoFilaService extends GenericGboService<ConfiguracaoFila, IConfiguracaoFilaDAO> implements IConfiguracaoFilaService {
	
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(ConfiguracaoFilaService.class.getName());
	
	@Inject
	private IConfiguracaoFilaDAO configuracaoFilaDAO;
	
	@EJB
	private ICasoService casoService;
	@EJB
    private IParametroGBOService parametroGBOService;
	@EJB
	private IHistoricoGboService historicoGboService;
	@EJB
	private IAtendenteService atendenteService;
	@EJB
	private IEquipeService equipeService;
	@EJB
	private ISlaFilaService slaFilaService;
	@EJB
	private IEquipeFilaService equipeFilaService;
	@EJB
	private IConfiguracaoFilaPersistService configuracaoFilaPersistService;
	
	@Override
	protected IConfiguracaoFilaDAO getDAO() {
		return configuracaoFilaDAO;
	}
        
	@Override
	public void save(ConfiguracaoFila configuracaoFila) throws ServiceException, ValidationException {
		validaSaveUpdateFila(configuracaoFila);
		
		if (!configuracaoFila.getFlagAtivo()) {
			configuracaoFila.setPrioridade(null);
		} else {
			inserePrioridade(configuracaoFila);
		}
		super.save(configuracaoFila);
		
		salvaHistoricoAlteracao(configuracaoFila);
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	private void salvaHistoricoAlteracao(ConfiguracaoFila configuracaoFila)
			throws ServiceException, ValidationException {
		Gson gson = new Gson();
		HistoricoGbo historicoGbo = new HistoricoGbo();
		historicoGbo.setHistorico(gson.toJson(configuracaoFila));
		historicoGbo.setLoginUsuario(configuracaoFila.getLoginUsuario());
		historicoGbo.setIdTabelaOrigem(configuracaoFila.getPK());
		
		historicoGboService.save(historicoGbo, "telaConfiguracaoFila");
	}

	private void inserePrioridade(ConfiguracaoFila configuracaoFila) throws ServiceException {
		Integer confFilaPrioridade=null;
		//Inserir maior Prioridade depois o usuário organiza.
		List<ConfiguracaoFila> confList = buscaFilaAtivaPorPrioridade();
		if (confList != null && confList.size() > 0) {
			confFilaPrioridade = confList.get(confList.size()-1).getPrioridade();
		} else {
			confFilaPrioridade = Integer.valueOf(0);
		}
		confFilaPrioridade++;
		configuracaoFila.setPrioridade(confFilaPrioridade);
	}
	
	@Override
	public void update(ConfiguracaoFila configuracaoFila) throws ServiceException, ValidationException {
		validaSaveUpdateFila(configuracaoFila);
		
		if (!configuracaoFila.getFlagAtivo()) {
			configuracaoFila.setPrioridade(null);
		}
		
		if (configuracaoFila.getFlagAtivo() && configuracaoFila.getPrioridade() == null) {
			inserePrioridade(configuracaoFila);
		}
		
		validaBuldFlagAtivo(configuracaoFila);
		
		salvaHistoricoAlteracao(configuracaoFila);
		
		super.update(configuracaoFila);
	}

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	private void validaBuldFlagAtivo(ConfiguracaoFila configuracaoFila)
			throws ServiceException {
		try {
			ConfiguracaoFila configuracaoFilaValida = getDAO().findByPk(configuracaoFila);
			
			if (!configuracaoFilaValida.getSqlWhere().equals(configuracaoFila.getSqlWhere()) 
					&& (configuracaoFilaValida.getFlagAtivo() && configuracaoFila.getFlagAtivo())) {
				configuracaoFila.setFlagBuild(Boolean.TRUE);
			}
			
			if (configuracaoFilaValida.getFlagAtivo() && !configuracaoFila.getFlagAtivo()) {
				
				try {
					getDAO().removeCasosClassificacaoFila(configuracaoFila);
					casoService.retiraFilaCaso(configuracaoFila);
				} catch (DataException e) {
					throw new ServiceException("Erro ao inativar a fila. Falha ao remover os casos.",e);
				}
			}
			
		} catch (DataException e) {
			throw new ServiceException("Erro ao validar se a fila necessita de BUILD",e);
		}
	}

	/**
	 * @param configuracaoFila
	 * @throws ServiceException
	 */
	private void validaSaveUpdateFila(ConfiguracaoFila configuracaoFila) throws ValidationException, ServiceException {
		if (configuracaoFila == null) {
			throw new ValidationException("A configura\u00E7\u00E3o da fila n\u00E3o pode ser nula.");
		}
		
		if (StringUtils.isEmpty(configuracaoFila.getNome())	|| configuracaoFila.getFlagAtivo() == null ) {
			throw new ValidationException("Todos os campos obrigat\u00F3rios para cadastrar a fila devem ser preenchidos.");
		}
		
		configuracaoFila.setDataCriacao(getDataBanco());
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void insereCasoNaFila(Caso caso, ConfiguracaoFila configuracaoFila) throws ServiceException {
		try {
            //Deleta qualquer ocorrencia do caso na fila.
            removeFilaClassificaoCaso(caso);
                        
			//Se a fila já existe, só inclui o caso na fila
			getDAO().insereCasoFila(caso, configuracaoFila);
		} catch (DataException e) {
			throw new ServiceException("Erro ao salvar o caso na fila.",e);
		}
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<ConfiguracaoFila> buscaFilaAtivaPorPrioridade()	throws ServiceException {
		try {
			return getDAO().buscaFilaAtivaPorPrioridade();
		} catch (DataException e) {
			throw new ServiceException("Falha ao buscar as filas ordenadas",e);
		}
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<ConfiguracaoFila> buscaFilaBuildPorPrioridade()	throws ServiceException {
		try {
			return getDAO().buscaFilaBuildPorPrioridade();
		} catch (DataException e) {
			throw new ServiceException("erro ao buscar as filas que precisam de build.",e);
		}
	}
	
	@Override
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void removeFilaClassificaoCaso(Caso caso) throws ServiceException {
		try {
			getDAO().removeFilaClassificaoCaso(caso);
		}catch(DataException e) {
			throw new ServiceException("Erro ao remover fila de classifica\u00E7\u00E3o.", e);
		}
	}
	
	private List<Caso> buscaCasosFiltroPorFilaSemAtendente(ConfiguracaoFila configuracaoFila) throws ServiceException {
		try {
			return casoService.buscaCasosFiltroPorFilaSemAtendente(configuracaoFila);
		}catch (ValidationException e) {
	        throw new ServiceException("Erro ao tentar enfilerar casos", e);
        }catch(ServiceException e) {
	        throw new ServiceException("Erro ao tentar enfilerar casos", e);
	    }
	}
	
	/**
	 * Realiza a classificação dos casos. Busca as filas e solcita aos serviços especializados que faça a inserção.
	 */
	@Override
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
    public void classificaCasos() throws ServiceException {
        
        Properties propertiesApp = new Properties();
        
        try {
            propertiesApp.load(ConfiguracaoFilaService.class.getResourceAsStream("/config/gbo.properties"));

            boolean flagProcessandoSPA = Boolean.valueOf(parametroGBOService.findByParam(
                            propertiesApp.getProperty("parametro.spa.processando")).getValor()) == null
                                    ? false : Boolean.valueOf(parametroGBOService.findByParam(
                                            propertiesApp.getProperty("parametro.spa.processando")).getValor());
            //Verifica se o SPA não está carregando os mailings
            if (!flagProcessandoSPA) {
                //Guardando as filas que necessitam de build para atualização.
                List<ConfiguracaoFila> configuracaoFilaBuild = buscaFilaBuildPorPrioridade();
                //Removendo os casos das filas que necessitam de build.
                configuracaoFilaPersistService.removeCasosFilasBuild(configuracaoFilaBuild);
                //Buscando todas as filas cadastradas e inserindo os casos nessas filas.
                List<ConfiguracaoFila> configuracaoFilasEnfileiramento = buscaFilaAtivaPorPrioridade();
                
                List<Caso> casoListPersist = new ArrayList<Caso>();
                Integer contadorPersist = 1;
                //Busca os casos que se encaixam na configuração dessa fila.
                for(ConfiguracaoFila confFila : configuracaoFilasEnfileiramento) { 
                    List<Caso> casoList = buscaCasosFiltroPorFilaSemAtendente(confFila);
                    
                    casoListPersist = new ArrayList<Caso>();
                    //Vamos inserir esses casos em uma fila e fazer update no caso.
                    for (Caso caso : casoList) {
                    	
                    	casoListPersist.add(caso);
                    	if(contadorPersist == 100) {
                    		
                    		//persist a lista de objetos 
                    		configuracaoFilaPersistService.persistClassificaCasos(casoListPersist, confFila);
                    		contadorPersist = 1;
                    		casoListPersist = new ArrayList<Caso>();
                    	} else {
                    		contadorPersist ++;
                    	}
                    }
                    
                    if(casoListPersist != null && !casoListPersist.isEmpty()) {
                    	
                    	//persist a lista de objetos 
                    	configuracaoFilaPersistService.persistClassificaCasos(casoListPersist, confFila);
                    }
                    
                }
                
                //Atualizando as filas para que não seja feito o build das mesmas.
                for (ConfiguracaoFila configuracaoFila : configuracaoFilaBuild) {
                        configuracaoFila.setFlagBuild(false);
                        configuracaoFilaPersistService.update(configuracaoFila);
                }
            } else {
                LOGGER.info("CLASSIFICA CASO - AGUARDANDO IMPORTAÇÃO SPA.");
            }
        } catch (IOException e) {
            throw new ServiceException("Erro ao tentar enfilerar casos", e);
        }catch (ValidationException e) {
	        throw new ServiceException("Erro ao tentar enfilerar casos", e);
        }catch(ServiceException e) {
	        throw new ServiceException("Erro ao tentar enfilerar casos", e);
	    }
    }
	
	@Override
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void preparaReaberturasLiberaCasos() throws ServiceException {
		try {
			
	        Properties propertiesApp = new Properties();
            propertiesApp.load(ConfiguracaoFilaService.class.getResourceAsStream("/config/gbo.properties"));

            ParametroGBO parametroGBOProcessando = parametroGBOService.findByParam(propertiesApp.getProperty("parametro.spa.processando"));
            boolean flagProcessandoSPA = parametroGBOProcessando != null ? Boolean.valueOf(parametroGBOProcessando.getValor()) : false;
            
            ParametroGBO parametroGBO = parametroGBOService.findByParam(Constantes.PARAMETRO_REABRE_CASO_ATENDENTE);
            boolean reabreCasoAtendente = parametroGBO != null ? Boolean.valueOf(parametroGBO.getValor()) : false;
            //Verifica se o SPA não está carregando os maillings
            if (!flagProcessandoSPA) {
				
				List<Caso> casoReaberturaReclassifica = casoService.buscaCasoReclassificaReabertura();
				
				List<StatusAtendente> statusAtendentes = ControleStatusAtendentes.getMapStatusAtendente(new ArrayList<ConfiguracaoFila>(), new ArrayList<Atendente>(), new ArrayList<Equipe>(), new Date());
				if (statusAtendentes != null && !statusAtendentes.isEmpty() && reabreCasoAtendente) {
					for (StatusAtendente statusAtendente : statusAtendentes) {
						List<Caso> casoRemove = new ArrayList<Caso>();
						for (Caso caso : casoReaberturaReclassifica) {
							if (caso.getAtendente() != null && caso.getAtendente().getIdAtendente() != null
									&& statusAtendente.getIdAtendente() != null	&& statusAtendente.getIdAtendente().getIdAtendente() != null 
									&& caso.getAtendente().getIdAtendente().equals(statusAtendente.getIdAtendente().getIdAtendente())) {
		
								//Validando se o atendente está ativo.
								Atendente atendente = atendenteService.findByPk(caso.getAtendente());
								if (atendente != null && atendente.getIdAtendente() != null && atendente.getFlagAtivo()) {
								
									//Validando se o atendente ainda pertence a equipe
									Equipe equipe = equipeService.findByPk(atendente.getEquipe());
									if (equipe != null && equipe.getIdEquipe() != null && equipe.getFlagAtivo()) {
									
										caso.setFlagReclassificaReabertura(Boolean.FALSE);
										caso.setFlagClassifica(Boolean.FALSE);
										casoService.update(caso);
										casoRemove.add(caso);
									}
								}
							}
						}
						
						casoReaberturaReclassifica.removeAll(casoRemove);
						
						if (casoReaberturaReclassifica.isEmpty()) {
							break;
						}
					}	
				}
				
				if (casoReaberturaReclassifica != null && !casoReaberturaReclassifica.isEmpty()) {
					
					for (Caso caso : casoReaberturaReclassifica) {
						caso.setFlagReclassificaReabertura(Boolean.FALSE);
						caso.setAtendente(null);
						caso.setConfiguracaoFila(null);
						
						casoService.update(caso);
					}
					
				}
            }
		} catch (Exception e) {
			throw new ServiceException("Erro ao preparar os casos reabertos.",e);
		}
		
	}

	/**
	 * Busca sla_fila ativo para uma configuração. Caso não encontre, será criado um SLA padrão.
	 * 
	 * @param idConfiguracao
	 * @return SlaFila
	 * @throws ServiceException
	 */
	private SlaFila buscaOuCriaSla(ConfiguracaoFila configuracaoFila) throws ServiceException {
		try {
	        Properties propertiesApp = new Properties();
	        propertiesApp.load(SlaTipoFilaService.class.getResourceAsStream("/config/gbo.properties"));
	        
	        SlaFila slaFila = slaFilaService.findSlaFilaByConfFilaAndDataFimNull(configuracaoFila);
	        
	        //Verifica se o slaFila é um objeto vazio.
	        if (slaFila == null || slaFila.getIdSlaFila() == null || slaFila.getIdSlaFila() < 1) {
	        	slaFila = new SlaFila();
	        	slaFila.setConfiguracaoFila(configuracaoFila);
	        	slaFila.setDataFinal(null);
	        	slaFila.setDataInicial(new Date(System.currentTimeMillis()));
	        	slaFila.setSla(Integer.parseInt(parametroGBOService.findByParam(propertiesApp.getProperty("parametro.temposla")).getValor()));
	        	slaFila.setDescricao("SLA padrão");
	        	
	        	slaFilaService.save(slaFila);
	        }
	        
			return slaFila;
		} catch (Exception ex) {
			throw new ServiceException("Erro ao verifica sla fila em ConfiguracaoFilaService",ex);
		}
	}

	@Override
	public List<ConfiguracaoFila> buscaProximaFilaAtendimentoAtendente(Atendente atendente) throws ServiceException, ValidationException {
        
		List<ConfiguracaoFila> configuracaoFilaList = new ArrayList<ConfiguracaoFila>();
		List<EquipeFila> equipeFilas = equipeFilaService.buscaEquipeFilaPelaPrioridade(atendente.getEquipe());
		if (equipeFilas == null || equipeFilas.isEmpty()) {
			throw new ValidationException("O atendente n\u00E3o possui nenhuma fila configurada. Favor solicitar que as configura\u00E7\u00F5es sejam realizadas corretamente.");
		}
        
		Equipe equipe = equipeService.findByPk(atendente.getEquipe());
		
		if (equipe.getFlagPrioridade()) {
            for (EquipeFila equipeFila : equipeFilas) {
                configuracaoFilaList.add(equipeFila.getConfiguracaoFila());
            }
		} else {
		    double totalCasosAtendidos = 1;
		    double totalNrocasos = 0;
		
		    for (EquipeFila equipeFila : equipeFilas) {
		        totalCasosAtendidos += equipeFila.getQuantidadeCasoAtendido();
		        totalNrocasos += equipeFila.getQuantidadeCasoFila();
		    }
		    
		    for (EquipeFila equipeFila : equipeFilas) {
		
		        double v1 = (equipeFila.getQuantidadeCasoFila() / totalNrocasos) * 100;
		
		        double v2 = (100 / totalCasosAtendidos) * equipeFila.getQuantidadeCasoAtendido();
		
		        Double vlrOrdem = v1 - v2 > 0 ? v1 * totalNrocasos : v1;
		        equipeFila.setOrdemFila(vlrOrdem);
		
		    }
			
			EquipeFila[] sortEquipeFila = equipeFilas.toArray(new EquipeFila[equipeFilas.size()]);
	                
	        Arrays.sort(sortEquipeFila, new Comparator<EquipeFila>() {
	            @Override
	            public int compare(EquipeFila t, EquipeFila t1) {
	                return t1.getOrdemFila().compareTo(t.getOrdemFila());
	            }
	        });
	
	        for (EquipeFila equipeFila : sortEquipeFila) {
	            configuracaoFilaList.add(equipeFila.getConfiguracaoFila());
	        }
		}	
		return configuracaoFilaList;
	}


	@Override
	public void inativar(ConfiguracaoFila configuracaoFila, String usuario)	throws ServiceException, ValidationException {
		
		if (configuracaoFila == null) {
			throw new ValidationException("A configura\u00E7\u00E3o da fila n\u00E3o pode ser nula.");
		}
		configuracaoFila.setFlagAtivo(Boolean.FALSE);
		configuracaoFila.setLoginUsuario(usuario);
		update(configuracaoFila);
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<ConfiguracaoFila> buscaFilaPorPrioridade() throws ServiceException {
		try {
			return getDAO().buscaFilaPorPrioridade();
		} catch (DataException e) {
			throw new ServiceException("Falha ao buscar as filas ordenadas",e);
		}
	}

	@Override
	public void diminuirPrioridade(ConfiguracaoFila configuracaoFila, String usuario) throws ServiceException, ValidationException {
		List<ConfiguracaoFila> confList = buscaFilaAtivaPorPrioridade();
		Integer confFilaIndice = confList.lastIndexOf(configuracaoFila);
		if (confList.size() > (confFilaIndice+1)) {
			ConfiguracaoFila conFilaProximo = confList.get(confFilaIndice+1);
			Integer prioridadeAlterada = configuracaoFila.getPrioridade();
			configuracaoFila.setPrioridade(conFilaProximo.getPrioridade());
			conFilaProximo.setPrioridade(prioridadeAlterada);
			
			configuracaoFila.setLoginUsuario(usuario);
			conFilaProximo.setLoginUsuario(usuario);
			
			update(configuracaoFila);
			update(conFilaProximo);
		}
	}

	@Override
	public void aumentarPrioridade(ConfiguracaoFila configuracaoFila, String usuario) throws ServiceException, ValidationException {
		List<ConfiguracaoFila> confList = buscaFilaAtivaPorPrioridade();
		Integer confFilaIndice = confList.lastIndexOf(configuracaoFila);
		if (confList.size() > confFilaIndice && Integer.valueOf((confFilaIndice-1)) >=0 ) {
			ConfiguracaoFila conFilaAnterior = confList.get(confFilaIndice-1);
			Integer prioridadeAlterada = configuracaoFila.getPrioridade();
			configuracaoFila.setPrioridade(conFilaAnterior.getPrioridade());
			conFilaAnterior.setPrioridade(prioridadeAlterada);
			
			configuracaoFila.setLoginUsuario(usuario);
			conFilaAnterior.setLoginUsuario(usuario);
			
			update(configuracaoFila);
			update(conFilaAnterior);
		}
	}
	
	@Override
	public List<ConfiguracaoFila> buscaQueAindaNaoForamAdicionadosByEquipe(Equipe equipe) throws ServiceException{
		
		List<EquipeFila> equipeFilaList = equipeFilaService.buscaEquipeFilaListByEquipeEConfiguracaoFilaTudo(equipe, null);
		List<ConfiguracaoFila> configuracaoFilaList = findAtivos(null);
		
		for (Iterator<ConfiguracaoFila> iterator = configuracaoFilaList.iterator(); iterator.hasNext();) {
			ConfiguracaoFila configuracaoFilaItem = (ConfiguracaoFila) iterator.next();
			
			for (EquipeFila equipeFila : equipeFilaList) {
				if(configuracaoFilaItem.equals(equipeFila.getConfiguracaoFila())){
					iterator.remove();
				}
			}
			
		}
		
		return configuracaoFilaList;
	}

	@Override
	public List<ConfiguracaoFila> findByExample(ConfiguracaoFila configuracaoFila, String order) throws ServiceException {
		
		try {
			return getDAO().findByExample(configuracaoFila, order);
		} catch (DataException e) {
			throw new ServiceException(e);
		}
	}
	
	@Override
	public List<ConfiguracaoFila> findAll(String order) throws ServiceException {
		try {
			return getDAO().findAll(order);
		} catch (DataException e) {
			throw new ServiceException(e);
		}
	}

	@Override
	public ConfiguracaoFila buscaConfiguracaoFilaPadraoCasosImportados() throws ServiceException {
		return findByPk(new ConfiguracaoFila(Constantes.ID_CONFIG_FILA_PADRAO_DE_CASOS_IMPORTADAS));
	}
	
}
