package br.com.callink.cad.service.impl;

import javax.ejb.Stateless;
import javax.inject.Inject;
import br.com.callink.cad.dao.IContatoDAO;
import br.com.callink.cad.pojo.ContatoTelefone;
import br.com.callink.cad.service.IContatoService;

@Stateless
public class ContatoService extends GenericGboService<ContatoTelefone, IContatoDAO> implements IContatoService {

	private static final long serialVersionUID = 1L;

	@Inject
	private IContatoDAO contatoDAO;

	@Override
	protected IContatoDAO getDAO() {
		return contatoDAO;
	}

}
