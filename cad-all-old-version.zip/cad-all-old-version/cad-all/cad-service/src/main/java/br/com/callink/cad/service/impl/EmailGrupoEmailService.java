/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.service.impl;

import br.com.callink.cad.dao.IEmailGrupoEmailDAO;
import br.com.callink.cad.pojo.Email;
import br.com.callink.cad.pojo.EmailGrupoEmail;
import br.com.callink.cad.pojo.GrupoEmail;
import br.com.callink.cad.service.IEmailGrupoEmailService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;

/**
 *
 * @author Luiz Gustavo F. (luizgf@swb.com.br)
 */
@Stateless
public class EmailGrupoEmailService extends GenericGboService<EmailGrupoEmail, IEmailGrupoEmailDAO> implements IEmailGrupoEmailService {

	private static final long serialVersionUID = 3426487832053194221L;
	
	@Inject
	private IEmailGrupoEmailDAO emailGrupoEmailDAO;
	
	@Override
	protected IEmailGrupoEmailDAO getDAO() {
		return emailGrupoEmailDAO;
	}
	
    @Override
    public void salvaDestinatariosEmail(Email email, List<GrupoEmail> destinatarios) throws ServiceException, ValidationException {
        for (GrupoEmail grupoEmail : email.getListaDestinatarios()) {
            EmailGrupoEmail emailGrupoEmail = new EmailGrupoEmail();
            emailGrupoEmail.setEmail(email);
            emailGrupoEmail.setGrupoEmail(grupoEmail);
            super.save(emailGrupoEmail);
        }
    }

}
