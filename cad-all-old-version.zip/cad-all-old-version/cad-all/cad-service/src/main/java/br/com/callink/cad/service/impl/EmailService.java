/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.service.impl;

import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.dao.IEmailDAO;
import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.pojo.Anexo;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.ConfiguracaoEmail;
import br.com.callink.cad.pojo.Email;
import br.com.callink.cad.pojo.GrupoAnexo;
import br.com.callink.cad.pojo.Log;
import br.com.callink.cad.pojo.ParametroGBO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.service.ICasoService;
import br.com.callink.cad.service.IConfiguracaoEmailService;
import br.com.callink.cad.service.IEmailGrupoEmailService;
import br.com.callink.cad.service.IEmailService;
import br.com.callink.cad.service.IGrupoAnexoService;
import br.com.callink.cad.service.IGrupoEmailService;
import br.com.callink.cad.service.ILogService;
import br.com.callink.cad.service.IParametroGBOService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.util.Constantes;
import br.com.callink.cad.util.PropertieUtils;

/**
 *
 * @author Luiz Gustavo (luizgf@swb.com.br)
 */
@Stateless
public class EmailService extends GenericGboService<Email, IEmailDAO> implements IEmailService {
    
	private static final long serialVersionUID = 1L;
	
	@Inject
	private IEmailDAO emailDAO;
	
	@EJB
	private IGrupoEmailService grupoEmailService;
	@EJB
	private IGrupoAnexoService grupoAnexoService;
	@EJB
	private IParametroGBOService parametroGBOService;
	@EJB
	private ICasoService casoService;
	@EJB
	private ILogService logService;
	@EJB
	private  IEmailGrupoEmailService emailGrupoEmailService;
	@EJB
	private IConfiguracaoEmailService configEmailService;
	
	private String separadorInicial;
	private String separadorFinal;
	
	@Override
	protected IEmailDAO getDAO() {
		return emailDAO;
	}
	
	private Logger logger = Logger.getLogger(EmailService.class.getName());
	
	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public void envia(Email email, Caso caso, Acao acao) throws ServiceException, ValidationException {
        try {
            email.setFlagEnvio(Boolean.TRUE);
            email.setFlagEnvioPendente(Boolean.TRUE);
            email.setDataEnvio(getDataBanco());
            email.setFlagErroEnvio(Boolean.FALSE);
            email.setFlagPossuiCaso(Boolean.TRUE);
            email.setFlagLido(Boolean.TRUE);
            email.setConteudo(new String(email.getConteudo().getBytes("UTF-8"), "UTF-8"));
            this.save(email);
            
            String descricaoGruposEmail = "";
            
            if (email.getListaDestinatarios() != null && !email.getListaDestinatarios().isEmpty()) {
                descricaoGruposEmail = grupoEmailService.getDescricaoFromListaGrupoEmail(email.getListaDestinatarios());
                emailGrupoEmailService.salvaDestinatariosEmail(email, email.getListaDestinatarios());
            }

            //se for email resposta
            if (email.getPai() != null && email.getPai().getIdEmail() != null) {
                email.setDescricaoLog("Email respondido de: " + email.getPai().getRemetente());
                
                if (!StringUtils.isBlank(descricaoGruposEmail)) {
                    email.setDescricaoLog(email.getDescricaoLog() + " - Grupos de email adicionados na resposta: " + descricaoGruposEmail);
                }
                
            } else {
                email.setDescricaoLog("Email enviado para departamento(s): " + descricaoGruposEmail);
            }
            
            logService.saveLogEmail(caso, email, acao);
        } catch (UnsupportedEncodingException ex) {
            throw new ServiceException("Erro ao realizar o encode do conteúdo.",ex);
        }
        
    }
    
    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void save(Email object) throws ServiceException, ValidationException {
        if (StringUtils.isNotEmpty(object.getMensagemHtml().toString()) && object.getConteudo() == null) {
            object.setConteudo(object.getMensagemHtml().toString());
        } else if (StringUtils.isNotEmpty(object.getMensagemTxt().toString()) && object.getConteudo() == null) {
            object.setConteudo(object.getMensagemTxt().toString());
        }
        
        if (object.getGrupoAnexo() != null && object.getGrupoAnexo().getIdGrupoAnexo() == null) {
            grupoAnexoService.save(object.getGrupoAnexo());
        }
        
        if((object.getGrupoAnexo() != null) && (object.getGrupoAnexo().getAnexoList() == null || object.getGrupoAnexo().getAnexoList().isEmpty())){
        	object.setGrupoAnexo(null);
        }
        
        object.setDataEnvio(getDataBanco());
        super.save(object);
    }
    
    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void salvaReceivedMails(List<Email> emails) throws ServiceException, ValidationException {
        
        String chaveDiretorio = PropertieUtils.getPropertieByArquivoAndChave(
                Constantes.CAMINHO_ARQUIVO_PROPERTIES_CONFIGURACAO_TELA,
                Constantes.NOME_ARQUIVO_PROPERTIE,
                Constantes.CHAVE_DIRETORIO_ANEXO);
        
        if (StringUtils.isBlank(chaveDiretorio)) {
            throw new ValidationException("Diret\u00F3rio para salvar anexo n\u00E3o est\u00E1 cadastrado.");
        }
        String diretorio = parametroGBOService.findByParam(chaveDiretorio).getValor();
        
        for (Email mail : emails) {
        	try {
	            if (mail.getAssunto() != null) {
	                
	            	GrupoAnexo grupoAnexo = new GrupoAnexo();
	            	
	                if (mail.getListaAnexos() != null && mail.getListaAnexos().size() > 0) {
	                    
	                    grupoAnexo.setAnexoList(mail.getListaAnexos());
	                    
	                    for (Anexo anexo : grupoAnexo.getAnexoList()) {
	                        anexo.setDiretorio(diretorio);
	                    }
	                    
	                    grupoAnexoService.save(grupoAnexo);
	                    mail.setGrupoAnexo(grupoAnexo);
	                }
	                
	                buscarSeparadores();
	                int inicio = mail.getAssunto().indexOf(separadorInicial) + 1;
	                int fim = mail.getAssunto().indexOf(separadorFinal);
	                
	                String manifestacao = null;
	                Caso caso = null;
	                if (fim > 0 && fim > inicio) {
	                    manifestacao = mail.getAssunto().substring(inicio, fim);
	                    caso = casoService.buscarCasoPorIdExterno(manifestacao);
	                }
	                
	                if (caso != null) {
	                    
	                    mail.setFlagPossuiCaso(Boolean.TRUE);
	                    this.save(mail);
	                    
						Caso casoMail = casoService.load(caso);
						
	                    Log log = new Log();
	                    //log.setGrupoAnexo(mail.getGrupoAnexo());
	                    log.setGrupoAnexo(grupoAnexo);
	                    log.setCaso(casoMail);
	                    log.setDescricao("EMAIL RECEBIDO");
	                    log.setEmail(mail);
	                    log.setStatus(log.getCaso().getStatus());
	                    log.setConfiguracaoFila(casoMail.getConfiguracaoFila());
	                    logService.saveImediatoLogAnexos(log);
	                    
	                } else {
	                    
	                    mail.setFlagPossuiCaso(Boolean.FALSE);
	                    this.save(mail);
	                    
	                }
	            }
	        } catch (Exception e) {
	        	logger.log(Level.SEVERE, "Erro ao salvar e-mail.", e);
			}
        }
        
    }
    
    private void buscarSeparadores() throws ServiceException {
    	if (separadorInicial == null) {
    		ParametroGBO param = parametroGBOService.findByParam(Constantes.SEPARADOR_INICIAL);
    		if (param == null) {
    			throw new ServiceException("Parâmetro " + Constantes.SEPARADOR_INICIAL + " não cadastrado.");
    		}
    		
    		separadorInicial = param.getValor();
    	}
    	
    	if (separadorFinal == null) {
    		ParametroGBO param = parametroGBOService.findByParam(Constantes.SEPARADOR_FINAL);
    		if (param == null) {
    			throw new ServiceException("Parâmetro " + Constantes.SEPARADOR_FINAL + " não cadastrado.");
    		}
    		
    		separadorFinal = param.getValor();
    	}
	}

	@Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<Email> findEmailsEnvioPendente() throws ServiceException {
        try {
            Email email = new Email();
            email.setFlagEnvioPendente(Boolean.TRUE);
            email.setFlagEnvio(Boolean.TRUE);
            email.setFlagErroEnvio(Boolean.FALSE);
            return getDAO().findByExample(email);
        } catch (DataException e) {
            throw new ServiceException("Erro ao buscar emails a serem enviados.", e);
        }
    }
    
    @Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<Email> findEmailsFromCaso(Caso caso) throws ServiceException {
        try {
            return getDAO().findEmailsFromCaso(caso);
        } catch (DataException ex) {
            throw new ServiceException("Erro ao buscar emails associados a este caso.", ex);
        }
    }
    
    @Override
    public Boolean existemEmailsNaoLidos(List<Email> emails) {
        Boolean retorno = Boolean.FALSE;
        if (emails == null || emails.isEmpty()) {
            return retorno;
        }
        for (Email email : emails) {
            if (email.getFlagLido() != null && !email.getFlagLido()) {
                retorno = Boolean.TRUE;
            }
        }
        return retorno;
    }
    
    @Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<Email> findEmailsSemCaso() throws ServiceException {
        try {
            return getDAO().findEmailsSemCaso();
        } catch (DataException ex) {
            throw new ServiceException("Erro ao buscar emails que não estão associados a casos.", ex);
        }
    }
    
    @Override
    public void loadEmails(List<Caso> casos) throws ServiceException {
        if (casos == null || casos.isEmpty()) {
            return;
        }
        for (Caso caso : casos) {
            caso.setEmails(findEmailsFromCaso(caso));
        }
    }
    
    @Override
    public void loadIconeEmails(List<Caso> casos) throws ServiceException {
        if (casos == null || casos.isEmpty()) {
            return;
        }
        for (Caso caso : casos) {
            loadIconCaso(caso);
        }
    }

    @Override
	public void loadIconCaso(Caso caso) throws ServiceException {
    	if (caso == null || caso.getIdCaso() == null) {
    		throw new ServiceException("O caso nao pode ser nulo para carregar o ICON SLA.");
    	}
    	
		List<Email> emailsCaso = findEmailsFromCaso(caso);
		caso.setPossuiEmailNaoLido(existemEmailsNaoLidos(emailsCaso));
		caso.setIconeEmail(caso.getPossuiEmailNaoLido() ? Constantes.ICONE_RECEBEU_EMAIL : Constantes.ICONE_NAO_RECEBEU_EMAIL);
	}
    
    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void lerEmail(Email email, Caso caso) throws ServiceException, ValidationException {
        
        if (email == null || caso == null || email.getPK() == null || caso.getPK() == null) {
            return;
        }
        if (email.getFlagLido() != null && email.getFlagLido()) {
            return;
        }
        if (email.getFlagEnvio()) {
            return;
        }
        
        caso = casoService.findByPk(caso);
        
        email.setFlagLido(Boolean.TRUE);
        try {
            updateFlagLido(email);
            
        } catch (ServiceException ex) {
            throw new ServiceException("Erro ao ler email.", ex);
        }
        
        Log log = new Log();
        log.setGrupoAnexo(email.getGrupoAnexo());
        log.setCaso(caso);
        log.setDescricao("Leitura de email do remetente " + email.getRemetente());
        log.setAtendente(caso.getAtendente());
        log.setStatus(caso.getStatus());
        logService.saveLogAnexos(log);
    }
    
    @Override
    public Properties enviaEmailProperties() {
        Properties props = PropertieUtils.getPropertieByNomeArquivo(Constantes.CAMINHO_ARQUIVO_PROPERTIES_CONFIGURACAO_TELA + Constantes.NOME_ARQUIVO_PROPERTIE);
        props.put("mail.transport.protocol", "smtp");
        props.put("mail.smtp.host", props.getProperty(Constantes.PARAMETRO_EMAIL_SMTPHOST));
        props.put("mail.smtp.auth", String.valueOf(Boolean.TRUE));
        return props;
    }
    
    @Override
    public Properties recebeEmailProperties() {
        return PropertieUtils.getPropertieByNomeArquivo(Constantes.CAMINHO_ARQUIVO_PROPERTIES_CONFIGURACAO_TELA + Constantes.NOME_ARQUIVO_PROPERTIE);
    }
    
    @Override
    public void update(Email email) throws ServiceException, ValidationException {
        if (email == null || email.getIdEmail() == null) {
            throw new ServiceException("Erro ao atualizar email.");
        }
        super.update(email);
    }
    
    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void associaEmailCaso(Email email, Caso caso, String loginAtendente) throws ServiceException, ValidationException {
        
        try {

            Log log = new Log();
            log.setCaso(caso);
            log.setDescricao("Email - " + email.getPK() + " associado ao caso - " + caso.getPK() + " pelo usuário - " + loginAtendente);
            log.setEmail(email);
            logService.saveLogAnexos(log);
            
            email.setFlagPossuiCaso(Boolean.TRUE);
            update(email);
            
            
        } catch (ServiceException e) {
            throw new ServiceException("Erro ao associar email a Caso.", e);
        }
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void updateFlagLido(Email email) throws ServiceException {
        try {
            getDAO().updateFlagLido(email);
        } catch (DataException ex) {
            throw new ServiceException("Erro ao realizar o update no flag lido.", ex);
        }
    }

	@Override
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void updateFlagDesativado(Email email) throws ServiceException {
		try {
			getDAO().updateFlagDesativado(email);
		} catch (Exception e) {
			throw new ServiceException("Erro ao realizar update no email.",e);
		}
	}
	
	@Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<Email> findEmailsFromCasoByFlagEnvio(Caso caso, Boolean flagEnvio) throws ServiceException {
        try {
            return getDAO().findEmailsFromCasoByFlagEnvio(caso, flagEnvio);
        } catch (DataException ex) {
            throw new ServiceException("Erro ao buscar emails do caso.", ex);
        }
    }
	
	@Override
	public List<Email> findEmailsSemCasoByExample(Email email, Date dataInicio,
			Date dataFim) throws ServiceException {

		try {
			return getDAO().findEmailsSemCasoByExample(email, dataInicio, dataFim);
		} catch (DataException ex) {
			throw new ServiceException("Erro ao buscar emails do caso.", ex);
		}
	}
	
	@Override
	public String buscarDiretorioAnexos() {
		try {
			String chaveDiretorio = PropertieUtils
					.getPropertieByArquivoAndChave(
							Constantes.CAMINHO_ARQUIVO_PROPERTIES_CONFIGURACAO_TELA,
							Constantes.NOME_ARQUIVO_PROPERTIE,
							Constantes.CHAVE_DIRETORIO_ANEXO);

			if (StringUtils.isBlank(chaveDiretorio)) {
				throw new ValidationException(
						"Diret\u00F3rio para salvar anexo n\u00E3o est\u00E1 cadastrado.");
			}
			
			return parametroGBOService.findByParam(chaveDiretorio).getValor();

		} catch (Exception e) {
			e.printStackTrace();
			return "C:\\TMP";
		}
	}
	
	@Override
	public List<ConfiguracaoEmail> buscarConfigsEmails() throws ServiceException {
		try{
			ConfiguracaoEmail example = new ConfiguracaoEmail();
			example.setFlagAtivo(Boolean.TRUE);
			return configEmailService.findByExample(example);
		}catch(Exception e){
			throw new ServiceException("Erro ao buscar configurações de e-mails ativas. Motivo: " + e.getMessage(), e);
		}
	}
	
	@Override
	public GrupoAnexo salvarGrupoAnexo(Email email, String diretorioAnexo) throws ServiceException {
		try{
			GrupoAnexo grupoAnexo = new GrupoAnexo();
			List<Anexo> anexos = email.getListaAnexos();
			
			if (anexos != null && !anexos.isEmpty()) {
				
				grupoAnexo.setAnexoList(anexos);
				
				for (Anexo anexo : grupoAnexo.getAnexoList()) {
					anexo.setDiretorio(diretorioAnexo);
				}
				
				grupoAnexoService.save(grupoAnexo);
			}
			
			email.setGrupoAnexo(grupoAnexo);
			
			return grupoAnexo;
			
		}catch(Exception e){
			throw new ServiceException("Erro ao salvar grupo anexo. Motivo: " + e.getMessage(), e);
		}
	}
	
	@Override
	public void associarEmailAoCaso(Email email, Caso caso)	throws ValidationException, ServiceException {
		 Log log = new Log();
         log.setGrupoAnexo(email.getGrupoAnexo());
         log.setCaso(caso);
         log.setDescricao("EMAIL RECEBIDO");
         log.setEmail(email);
         log.setStatus(log.getCaso().getStatus());
         log.setConfiguracaoFila(caso.getConfiguracaoFila());
         
         logService.saveImediatoLogAnexos(log);
	}

}
