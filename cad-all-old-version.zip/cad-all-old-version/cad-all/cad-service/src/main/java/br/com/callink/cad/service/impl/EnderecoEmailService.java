/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.service.impl;

import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import br.com.callink.cad.dao.IEnderecoEmailDAO;
import br.com.callink.cad.pojo.EnderecoEmail;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.service.IEnderecoEmailService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 *
 * @author Luiz Gustavo (luizgf@swb.com.br)
 */
@Stateless
public class EnderecoEmailService extends GenericGboService<EnderecoEmail, IEnderecoEmailDAO> 
                                    implements IEnderecoEmailService {
    
	private static final long serialVersionUID = 7952839906515952119L;
	
	@Inject
	private IEnderecoEmailDAO enderecoEmailDAO;
	
	@Override
	protected IEnderecoEmailDAO getDAO() {
		return enderecoEmailDAO;
	}
	
    @Override
    public void save(EnderecoEmail enderecoEmail) throws ServiceException, ValidationException {
        enderecoEmail.setDataCriacao(getDataBanco());
        super.save(enderecoEmail);
    }
    
    @Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<EnderecoEmail> findByExample(EnderecoEmail enderecoEmail, String order) throws ServiceException {
		try {
			return getDAO().findByExample(enderecoEmail, order);
		} catch (DataException e) {
			throw new ServiceException("Erro ao buscar Endereco email.", e);
		}
	}
    
}
