package br.com.callink.cad.service.impl;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import br.com.callink.cad.dao.IEquipeFilaDAO;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.pojo.Equipe;
import br.com.callink.cad.pojo.EquipeFila;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.service.IConfiguracaoFilaService;
import br.com.callink.cad.service.IEquipeFilaService;
import br.com.callink.cad.service.IEquipeService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

@Stateless
public class EquipeFilaService extends GenericGboService<EquipeFila, IEquipeFilaDAO> implements IEquipeFilaService {
	private static final long serialVersionUID = 1L;

	@Inject
	private IEquipeFilaDAO equipeFilaDAO;
	
	@EJB
	private IEquipeService equipeService;
	
	@EJB
	private IConfiguracaoFilaService configuracaoFilaService;
	
	@Override
	protected IEquipeFilaDAO getDAO() {
		return equipeFilaDAO;
	}
	
	
	@Override
	public void save(EquipeFila equipeFila) throws ServiceException, ValidationException {
		if (	equipeFila == null
				|| equipeFila.getQuantidadeCasoFila() == null
				|| equipeFila.getEquipe() == null
				|| equipeFila.getEquipe().getPK() == null
				|| equipeFila.getConfiguracaoFila() == null
				|| equipeFila.getConfiguracaoFila().getPK() == null) {
			throw new ValidationException("\u00C9 necess\u00E1rio preencher todos os campos obrigat\u00F3rios.");
		}
		
		if (buscaByEquipeAndConfiguracaoFila(equipeFila.getEquipe(), equipeFila.getConfiguracaoFila()) != null) {
			throw new ValidationException("Equipe j\u00E1 est\u00E1 associada a fila.");
		}
		equipeFila.setQuantidadeCasoAtendido(0);
		
		reiniciaContadorFilasEquipe(equipeFila);
		
		super.save(equipeFila);
	}

	//Zerar todas filas da equipe para reiniciar o contador.
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	private void reiniciaContadorFilasEquipe(EquipeFila equipeFila) throws ServiceException {
		EquipeFila equipeFilaFind = new EquipeFila();
		equipeFilaFind.setEquipe(equipeFila.getEquipe());
		
		try {
			List<EquipeFila> equipeFilaList = getDAO().findByExample(equipeFilaFind);
			
			if (equipeFilaList != null && !equipeFilaList.isEmpty()) {
				for (EquipeFila equipeFilaZerar : equipeFilaList) {
					equipeFilaZerar.setQuantidadeCasoAtendido(Integer.valueOf(0));
					
					getDAO().update(equipeFilaZerar);
				}
			}
			
		} catch (DataException e) {
			throw new ServiceException("Erro ao zerar todas as filas de atendimento da equipe.",e);
		}
				
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<EquipeFila> buscaEquipeFilaPelaPrioridade(Equipe equipe) throws ServiceException {
		try {
			return getDAO().buscaEquipeFilaPelaPrioridade(equipe);
		} catch (DataException e) {
			throw new ServiceException("Erro ao buscar EquipeFilas.", e);
		}
	}
	
	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public EquipeFila buscaByEquipeAndConfiguracaoFila(Equipe equipe, ConfiguracaoFila configuracaoFila) throws ServiceException, ValidationException{
		try {
			
			if (equipe == null
					|| equipe.getPK() == null
					|| configuracaoFila == null
					|| configuracaoFila.getPK() == null) {
				throw new ValidationException(	"Campos obrigat\u00F3rios devem ser informado.");
			}
			return getDAO().buscaByEquipeAndConfiguracaoFila(equipe, configuracaoFila);
		} catch (DataException e) {
			throw new ServiceException("Erro ao buscar EquipeFila.", e);
		}
	}
	
	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<EquipeFila> buscaEquipeFilaListByEquipeEConfiguracaoFila(Equipe equipe, ConfiguracaoFila configuracaoFila) throws ServiceException{
		try {
			return getDAO().buscaByEquipeFilaListByEquipeEConfiguracaoFila(equipe, configuracaoFila);
		} catch (DataException e) {
			throw new ServiceException("Erro ao buscar EquipeFilas.", e);
		}
		
	}
	
	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<EquipeFila> buscaEquipeFilaListByEquipeEConfiguracaoFilaTudo(Equipe equipe, ConfiguracaoFila configuracaoFila) throws ServiceException {
		List<EquipeFila> equipeFilaList = buscaEquipeFilaListByEquipeEConfiguracaoFila(equipe, configuracaoFila);
		for (EquipeFila equipeFila : equipeFilaList) {
			equipeFila.setEquipe(equipeService.findByPk(equipeFila.getEquipe()));
			equipeFila.setConfiguracaoFila(configuracaoFilaService.findByPk(equipeFila.getConfiguracaoFila()));
		}
		return equipeFilaList;
	}
	    
	@Override
	public void delete(EquipeFila equipeFila) throws ServiceException, ValidationException {
		
		reiniciaContadorFilasEquipe(equipeFila);
		super.delete(equipeFila);
	}
        
	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<EquipeFila> buscaPorEquipeList(List<Equipe> equipeList)
			throws ServiceException {
		try {
			return getDAO().buscaPorEquipeList(equipeList);
		} catch (DataException ex) {
			throw new ServiceException("Erro ao buscar equipeFila.", ex);
		}
	}

    @Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<EquipeFila> findFilasByEquipe(Equipe equipe) throws ServiceException {
		try {
			return getDAO().findFilasByEquipe(equipe);
		} catch (DataException ex) {
			throw new ServiceException("Erro ao buscar equipeFila.", ex);
		}
	}

    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void limpaEquipeFila(Equipe equipe) throws ServiceException {
    	try {
    		getDAO().limpaEquipeFila(equipe);
        } catch (DataException ex) {
            throw new ServiceException("Falha ao excluir equipeFila.", ex);
        }
    }

}
