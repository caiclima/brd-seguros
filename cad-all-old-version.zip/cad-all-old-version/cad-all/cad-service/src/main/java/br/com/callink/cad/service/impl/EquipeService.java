package br.com.callink.cad.service.impl;

import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.dao.IEquipeDAO;
import br.com.callink.cad.pojo.Equipe;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.service.IEquipeService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 * @author Rogerio Moreira [rogeriom@swb.com.br]
 * 
 */
@Stateless
public class EquipeService extends GenericGboService<Equipe, IEquipeDAO>
        implements IEquipeService {

    private static final long serialVersionUID = 1L;
    
    @Inject
    private IEquipeDAO equipeDAO;
    
    @Override
	protected IEquipeDAO getDAO() {
		return equipeDAO;
	}
    

    @Override
    public void save(Equipe equipe) throws ServiceException, ValidationException {
    	validaEquipe(equipe);
    	equipe.setDataCriacao(getDataBanco());
    	super.save(equipe);
    }
    
    @Override
    public void update(Equipe equipe) throws ServiceException, ValidationException {
    	validaEquipe(equipe);
    	equipe.setDataCriacao(getDataBanco());
    	super.update(equipe);
    }

	/**
	 * @param equipe
	 * @throws ServiceException
	 */
	private void validaEquipe(Equipe equipe) throws ValidationException {
		if (equipe == null) {
    		throw new ValidationException("A equipe n\u00E3o pode ser nula.");
    	}
    	if (StringUtils.isEmpty(equipe.getNome())) {
    		throw new ValidationException("O nome deve ser informado.");
    	}
    	if (equipe.getFlagPrioridade() == null) {
    		equipe.setFlagPrioridade(Boolean.FALSE);
    	}
	}
    
    @Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<Equipe> findAtivos() throws ServiceException {
        try {
            return getDAO().findAtivos();
        } catch (DataException ex) {
            throw new ServiceException("Erro ao buscar equipes", ex);
        }
    }

    @Override
    public void inativar(Equipe equipe) throws ServiceException, ValidationException {
        if (equipe == null || equipe.getPK() == null) {
            throw new ValidationException("Falha ao excluir: chave primaria n\u00E3o informada.");
        } else {
            equipe.setFlagAtivo(Boolean.FALSE);
            this.update(equipe);
        }
    }
    
    @Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<Equipe> findByExample(Equipe example, String order) throws ServiceException {
        try {
            return getDAO().findByExample(example, order);
        } catch (DataException ex) {
            throw new ServiceException("Erro ao buscar equipes", ex);
        }
    }

}
