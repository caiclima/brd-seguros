package br.com.callink.cad.service.impl;

import java.util.List;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;
import org.apache.commons.lang.StringUtils;
import br.com.callink.cad.dao.IEventoLigacaoDAO;
import br.com.callink.cad.pojo.EventoLigacao;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.service.IEventoLigacaoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

@Stateless
public class EventoLigacaoService extends GenericGboService<EventoLigacao, IEventoLigacaoDAO> implements IEventoLigacaoService {

	private static final long serialVersionUID = 1L;

	@Inject
	private IEventoLigacaoDAO eventoDAO;

	@Override
	protected IEventoLigacaoDAO getDAO() {
		return eventoDAO;
	}

	private void valida(EventoLigacao evento) throws ValidationException {
		if (evento == null) {
			throw new ValidationException("O evento deve ser preenchido.");
		}
		if (StringUtils.isEmpty(evento.getNome())) {
			throw new ValidationException("O nome do evento deve ser preenchido.");
		}
	}

	@Override
	public List<EventoLigacao> findByExample(EventoLigacao object) throws ServiceException {
		try {
			return getDAO().findByExample(object);
		} catch (DataException ex) {
			throw new ServiceException("Erro ao buscar Evento", ex);
		}
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void save(EventoLigacao evento) throws ServiceException, ValidationException {
		valida(evento);
		
		evento.setDataCriacao(getDataBanco());
		super.save(evento);
	}
	
	@Override
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void update(EventoLigacao object) throws ServiceException, ValidationException {
		valida(object);
		
		super.update(object);
	}

	@Override
	public List<EventoLigacao> findAtivosExceto(EventoLigacao pojo) throws ServiceException {
		try {
			return getDAO().findAtivosExceto(pojo);
		} catch (DataException ex) {
			throw new ServiceException("Erro ao buscar Evento", ex);
		}
	}
	
	@Override
	public List<EventoLigacao> findByEvento(EventoLigacao eventoLigacao) throws ServiceException {
		try {
			return getDAO().findByEvento(eventoLigacao);
		} catch (DataException ex) {
			throw new ServiceException("Erro ao buscar Eventos", ex);
		}
	}
	
}
