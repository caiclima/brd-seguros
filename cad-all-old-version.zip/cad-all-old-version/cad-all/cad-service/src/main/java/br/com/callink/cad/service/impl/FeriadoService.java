package br.com.callink.cad.service.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.dao.IFeriadoDAO;
import br.com.callink.cad.pojo.Feriado;
import br.com.callink.cad.service.IFeriadoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

@Stateless
public class FeriadoService extends GenericGboService<Feriado, IFeriadoDAO>
        implements IFeriadoService {

    private static final long serialVersionUID = 6470807891664447056L;

    @Inject
    private IFeriadoDAO feriadoDAO;

    @Override
    protected IFeriadoDAO getDAO() {
        return feriadoDAO;
    }

    @Override
    public void save(Feriado feriado) throws ServiceException, ValidationException {

        validacoesFeriado(feriado);
        try {
            List<Feriado> feriadoList = findByExample(feriado);

            if (feriadoList == null || !feriadoList.isEmpty()) {
                throw new ValidationException("O feriado j\u00E1 est\u00E1 cadastrado.");
            }

            super.save(feriado);

        } catch (ServiceException e) {
            throw new ServiceException("Erro ao salvar Feriado.", e);
        }
    }

    @Override
    public void update(Feriado feriado) throws ServiceException, ValidationException {
        validacoesFeriado(feriado);
        super.update(feriado);
    }

    @Override
    public List<Feriado> findAll() throws ServiceException {

        List<Feriado> feriadoList = super.findAll();
        List<Feriado> ferList = new ArrayList();

        for (Feriado fer : feriadoList) {
            if (fer.getFlagFixo() != null && fer.getFlagFixo()) {
                Calendar cal = Calendar.getInstance();
                int anoAtual = cal.get(Calendar.YEAR);
                cal.setTime(fer.getDataFeriado());
                int anoFeriado = cal.get(Calendar.YEAR);
                if (anoFeriado != anoAtual) {
                    cal.set(Calendar.YEAR, anoAtual);
                    Feriado feriado = new Feriado();
                    feriado.setDataFeriado(cal.getTime());
                    feriado.setFlagFixo(fer.getFlagFixo());
                    feriado.setFlagNacional(fer.getFlagNacional());
                    feriado.setLoginUsuario(fer.getLoginUsuario());
                    feriado.setNomeFeriado(fer.getNomeFeriado());
                    ferList.add(feriado);
                }
            }
        }
        feriadoList.addAll(ferList);
        return feriadoList;
    }

    /**
     * @param feriado
     * @throws ServiceException
     */
    private void validacoesFeriado(Feriado feriado) throws ValidationException {
        if (feriado == null || StringUtils.isBlank(feriado.getNomeFeriado())
                || feriado.getDataFeriado() == null
                || feriado.getFlagFixo() == null) {
            throw new ValidationException("Os campos obrigat\u00F3rios para Feriado n\u00E3o foram preenchidos.");
        }
    }
    
    @Override
    public Boolean isFeriado(Date date) throws ServiceException{
    	try{
    		return feriadoDAO.isFeriado(date);
    	}catch(Exception e){
    		e.printStackTrace();
    		throw new ServiceException("Erro ao verificar feriado. Motivo: " + e.getMessage());
    	}
	}

}
