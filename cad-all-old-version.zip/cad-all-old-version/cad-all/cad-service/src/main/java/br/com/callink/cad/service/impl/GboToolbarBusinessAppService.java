package br.com.callink.cad.service.impl;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.LogLigacoes;
import br.com.callink.cad.pojo.ParametroGBO;
import br.com.callink.cad.repository.MensagemToolbar;
import br.com.callink.cad.service.IGboToolbarBusinessAppService;
import br.com.callink.cad.service.ILogLigacoesService;
import br.com.callink.cad.service.IParametroGBOService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.util.Constantes;
import br.com.callink.toolbar.businessappintegrator.service.provider.ToolBarServerServiceProvider;
import br.com.callink.toolbar.commons.message.MessageTO;
import br.com.callink.toolbar.commons.message.enun.TypeHostEnum;
import br.com.callink.toolbar.commons.message.request.cache.RequestCache;
import br.com.callink.toolbar.commons.message.request.impl.BusinessDialRequest;
import br.com.callink.toolbar.commons.message.request.impl.HostRequest;
import br.com.callink.toolbar.commons.message.request.impl.MessengerRequest;

/**
 * Como o RequestCache esta no mesmo conteiner do projeto gbo e gbo-sau o java ira identificar o 
 * RequestCache statico e a thread de ler a fila do RequestProcess que esta no gbo-sau ira conseguir enxergar os 
 * dados passados neste service. Mesmo importando somente o projeto toolbar-business-integrator-api
 * 
 * */
@Stateless
public class GboToolbarBusinessAppService implements IGboToolbarBusinessAppService {
	
	@EJB
	private ILogLigacoesService logLigacoesService;
	@EJB
	private IParametroGBOService parametroGBOService;
	
	
	@Override
	public void enviaLigacaoToolbar(String telefone, String atendente, Caso caso) throws ServiceException {
		
		validaRegrasDeDiscagem(telefone,atendente, caso);
		
		BusinessDialRequest busDial = new BusinessDialRequest(new MessageTO());
		busDial.setPhoneNumber(telefone);
		busDial.setUserSSO(atendente);
		
		RequestCache.offer(busDial);
	}
	
	private void validaRegrasDeDiscagem(String telefone, String atendente, Caso caso) throws ServiceException {
		try {
			List<LogLigacoes> logList = logLigacoesService.findByUserSSOTelefone(atendente, telefone);
			
			/*
			 * Se já foi realizada alguma ligação para o telefone
			 */
			if (logList != null && !logList.isEmpty()) {
				/*
				 * O atendente só poderá discar novamente se todos os outros telefones tiverem tentativa de contato
				 */
				boolean houveTentativas = logLigacoesService.existeTentativaDeContatoParaTodosOutrosTelefonesPorCaso(caso, telefone);

				if (! houveTentativas) {
					throw new ServiceException("Ainda não é possível ligar para o telefone selecionado. Pois NÃO foi realizado nenhuma tentativa de contato para os outros telefones.");
				}
				
				List<ParametroGBO> params = parametroGBOService.findByParam(Constantes.TEMPOLIGACAO, Constantes.QTD_LIGACOES_TELEFONE);
				Date dataAtual = parametroGBOService.getDataBanco();
				
				for (ParametroGBO parametroGBO : params) {
					if(Constantes.TEMPOLIGACAO.equals(parametroGBO.getNome())){
						Calendar data = new GregorianCalendar();
						data.setTime(dataAtual);

						/*
						 * O atendente só poderá discar novamente depois do tempo em segundos configurado por parâmetro
						 */
						Calendar dataLog = new GregorianCalendar();
						dataLog.setTime(logList.get(0).getDataInicio());
						dataLog.add(Calendar.SECOND, Integer.valueOf(parametroGBO.getValor()));

						if (dataLog.after(data)) {
							throw new ServiceException("Ainda não é possível ligar para o telefone selecionado. Esperar o tempo necessário. Aproximadamente: " + parametroGBO.getValor() + " segundos.");
						}
					}
					else if(Constantes.QTD_LIGACOES_TELEFONE.equals(parametroGBO.getNome())){
						Integer qtdTotal = Integer.valueOf(parametroGBO.getValor());
						Integer qtdLigacoes = logLigacoesService.findQtdTentativaDeContatoPorTelefoneEData(telefone, dataAtual);
						qtdLigacoes = qtdLigacoes == null ? 0 : qtdLigacoes;
						
						/*
						 * O atendente só poderá discar novamente se não tiver excedido o número máximo de tentativas por dia
						 */
						if(qtdLigacoes == qtdTotal){
							throw new ServiceException("Ainda não é possível ligar para o telefone selecionado. Excedeu o número máximo de tentativas diárias.");
						}
					}
				}
			}
			
		} catch (Exception e) {
			throw new ServiceException(e);
		}
	}

	@Override
	public void enviaMensagemToolbar(MensagemToolbar mensagemToolbar) throws ServiceException {
		
		MessengerRequest messengerRequest = new MessengerRequest(new MessageTO());
		
		if(mensagemToolbar == null || mensagemToolbar.getUsuarioSSOEmitente() == null ||
				mensagemToolbar.getUsuarioSSORemetente() == null || mensagemToolbar.getMensagem() == null) {
			throw new ServiceException("Argumentos inv\u00E1lidos");
		}
		
		messengerRequest.setUserSSO(mensagemToolbar.getUsuarioSSORemetente());
		messengerRequest.setMessage(mensagemToolbar.getMensagem());
		messengerRequest.setDateSent(new Date());
		messengerRequest.setUserSent(mensagemToolbar.getUsuarioSSOEmitente());
		
		RequestCache.offer(messengerRequest);
	}
	
	@Override
	public void enviaMensagemToolbarAtendentes(MensagemToolbar mensagemToolbar) throws ServiceException {
		
		if(mensagemToolbar == null || mensagemToolbar.getMensagem() == null ||
				mensagemToolbar.getUsuarioSSOEmitente() == null || mensagemToolbar.getAnalistasAtendentes() == null) {
			throw new ServiceException("Argumentos inv\u00E1lidos");
		}
		
		Date dataEnvio = new Date();
		if(mensagemToolbar.getAnalistasAtendentes() != null) {
			for(Atendente atendente : mensagemToolbar.getAnalistasAtendentes()) {
				MessengerRequest messengerRequest = new MessengerRequest(new MessageTO());
				
				messengerRequest.setMessage(mensagemToolbar.getMensagem());
				messengerRequest.setDateSent(dataEnvio);
				messengerRequest.setUserSent(mensagemToolbar.getUsuarioSSOEmitente());
				
				messengerRequest.setUserSSO(atendente.getLogin());
				
				RequestCache.offer(messengerRequest);
			}
		}
		
		
	}

	@Override
	public void enviaPaginaTrativa(String ip, String porta, String userSSO, String host) throws ServiceException {
    	
        HostRequest hostRequest = new HostRequest(new MessageTO());
        hostRequest.setIpAddress(ip);
        hostRequest.setPort(Integer.valueOf(porta));
        hostRequest.setUserSSO(userSSO);
        hostRequest.setBlockAllRequestBrowser(true);
        hostRequest.setDisposition(false);
        hostRequest.setTimeDisposition(null);
        hostRequest.setHost(host);
        hostRequest.setTypeHost(TypeHostEnum.HOME.getIdTypeHostEnum());

        try {
			ToolBarServerServiceProvider.hostRequest(hostRequest);
		} catch (Exception e) {
			throw new ServiceException("Erro ao enviar a tela de trativa.",e);
		}		
	}
}
