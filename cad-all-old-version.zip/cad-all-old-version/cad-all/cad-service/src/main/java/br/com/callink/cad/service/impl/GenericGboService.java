package br.com.callink.cad.service.impl;

import java.util.Date;
import java.util.List;

import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import br.com.callink.cad.dao.IGenericCadDAO;
import br.com.callink.cad.pojo.entity.IEntity;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;



@SuppressWarnings("rawtypes")
public abstract class GenericGboService<T extends IEntity, DAO extends IGenericCadDAO<T>>{

	protected abstract DAO getDAO();

    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<T> findAll() throws ServiceException {
        try {
            return getDAO().findAll();
        } catch (DataException e) {
            throw new ServiceException(e);
        }
    }

    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public T findByPk(Object object) throws ServiceException {
        try {
            return getDAO().findByPk(object);
        } catch (DataException e) {
            throw new ServiceException(e);
        }
    }

    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void save(T object) throws ServiceException, ValidationException {
        try {
            getDAO().save(object);
        } catch (DataException e) {
            throw new ServiceException(e);
        }
    }

    public void saveOrUpdate(T object) throws ServiceException, ValidationException {
        try {
             if (getDAO().possuiIdComValor(object)) {
                update(object);
            } else {
                save(object);
            }
        }catch (ValidationException e) {
            throw e;
        } catch (ServiceException e) {
        	throw e;
        } catch (Exception e) {
            throw new ServiceException(e);
        }
    }

    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void update(T object) throws ServiceException, ValidationException {
        try {
            getDAO().update(object);
        } catch (DataException e) {
            throw new ServiceException(e);
        }
    }

    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void delete(T object) throws ServiceException, ValidationException {
        try {
            getDAO().delete(object);
        } catch (DataException e) {
            throw new ServiceException(e);
        }
    }

    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public T get(T object) throws ServiceException {
        try {
            return getDAO().findByPk(object);
        } catch (DataException e) {
            throw new ServiceException(e);
        }
    }

    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public T load(T object) throws ServiceException{
        try {
            return getDAO().findByPk(object);
        } catch (DataException e) {
            throw new ServiceException(e);
        }
    }

    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<T> findByExample(T object) throws ServiceException {
        try {
            return getDAO().findByExample(object);
        } catch (DataException e) {
            throw new ServiceException(e);
        }
    }
    
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<T> findByExample(T object, String order) throws ServiceException {
		try {
			return getDAO().findByExample(object, order);
		} catch (DataException e) {
			throw new ServiceException(e);
		}
	}
    
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public Date getDataBanco() throws ServiceException{
    	
    	try {
			return getDAO().getDataBanco();
		} catch (DataException e) {
			 throw new ServiceException(e);
		}
    }
    
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<T> findAtivos(String object) throws ServiceException {
        try {
            return getDAO().findAtivos(object);
        } catch (DataException e) {
            throw new ServiceException(e);
        }
    }
    
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<T> findAtivos() throws ServiceException {
        try {
            return getDAO().findAtivos();
        } catch (DataException e) {
            throw new ServiceException(e);
        }
    }
    
}
