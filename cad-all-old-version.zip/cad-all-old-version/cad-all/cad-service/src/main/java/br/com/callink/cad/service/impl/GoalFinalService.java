package br.com.callink.cad.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import br.com.callink.cad.dao.IGoalFinalDAO;
import br.com.callink.cad.pojo.GoalFinal;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.service.IGoalFinalService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 * 
 * @author miller
 *
 */
@Stateless
public class GoalFinalService extends GenericGboService<GoalFinal, IGoalFinalDAO> implements
		IGoalFinalService {

	private static final long serialVersionUID = 5597889198685749014L;
	
	@Inject
	private IGoalFinalDAO goalFinalDAO;
	
	@Override
	protected IGoalFinalDAO getDAO() {
		return goalFinalDAO;
	}
	
	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<GoalFinal> buscaGoalsAtivos() throws ServiceException {
		try {
			return getDAO().buscaGoalsAtivos();
		} catch (DataException e) {
			throw new ServiceException(e);
		}
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<GoalFinal> buscaHistoricoGoals() throws ServiceException {
		try {
			return getDAO().buscaHistoricoGoals();
		} catch (DataException e) {
			throw new ServiceException(e);
		}
	}
	
	@Override
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void saveGoal(GoalFinal goalFinal) throws ServiceException {
		try {
			goalFinal.setDataInicial(new Date(getDataBanco().getTime()));
			getDAO().save(goalFinal);
		} catch (DataException e) {
			throw new ServiceException(e);
		}
	}
	
	@Override
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void editarGoalFinal(List<GoalFinal> listGoal) throws ServiceException, ValidationException {
		try {
			List<GoalFinal> listGoalsAtuais = getDAO().buscaGoalsAtivos();
			List<GoalFinal> listaAtualizar = new ArrayList<GoalFinal>();
			
				if (listGoal != null && listGoal.size() > 0 && listGoalsAtuais != null && listGoalsAtuais.size() > 0) {
				for (GoalFinal goalFinal : listGoal) {
					for (GoalFinal goalAtual : listGoalsAtuais) {
						//Verifica se o id é o mesmo para comparar se houve alteração dos valores
						if (goalFinal.getIdGoalFinal().equals(goalAtual.getIdGoalFinal())) {
							//Verifica se foi feita alguma alteração de valor de goal final ou inicial ou do valor do nome
							if (!goalFinal.getGoalFinal().equals(goalAtual.getGoalFinal())
									|| !goalFinal.getGoalInicial().equals(goalAtual.getGoalInicial())
									|| !goalFinal.getDescricao().equals(goalAtual.getDescricao() )     
									|| !goalFinal.getNomeImagem().equals(goalAtual.getNomeImagem())) {
								listaAtualizar.add(goalFinal);
							}
							break;
						}
					}
				}
			}
			
			if (listaAtualizar.size() > 0) {
				for (GoalFinal goal : listaAtualizar) {
					getDAO().updateDataFinalPorId(goal.getIdGoalFinal());
					goal.setIdGoalFinal(null);
					goal.setDataInicial(new Date(System.currentTimeMillis()));
					super.save(goal);
				}
			}
			
		} catch (DataException ex) {
			throw new ServiceException(ex);
		}
	}
	
	@Override
	public boolean validaRangeGoalFinal(List<GoalFinal> listaValidar) {
    	
    	if (listaValidar != null && listaValidar.size() > 1) {
        	Collections.sort(listaValidar);
        	Double goalFinalAnterior = listaValidar.get(0).getGoalFinal();
        	
        	for (int i=1; i < listaValidar.size(); i++) {
        		if (listaValidar.get(i).getGoalInicial() <= goalFinalAnterior
        				|| listaValidar.get(i).getGoalFinal() <= listaValidar.get(i).getGoalInicial()) {
        			return false;
        		} else {
        			goalFinalAnterior = listaValidar.get(i).getGoalFinal();
        		}
        	}
    	}
    	
    	return true;
    }

}
