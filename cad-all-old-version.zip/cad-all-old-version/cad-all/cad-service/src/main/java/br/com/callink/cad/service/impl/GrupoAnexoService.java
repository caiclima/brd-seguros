package br.com.callink.cad.service.impl;

import java.util.Date;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import br.com.callink.cad.dao.IGrupoAnexoDAO;
import br.com.callink.cad.pojo.Anexo;
import br.com.callink.cad.pojo.GrupoAnexo;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.service.IAnexoService;
import br.com.callink.cad.service.IGrupoAnexoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 * @author Ednaldo Caic [ednaldo@swb.com.br]
 * 
 */
@Stateless
public class GrupoAnexoService extends GenericGboService<GrupoAnexo, IGrupoAnexoDAO> implements
        IGrupoAnexoService {

    private static final long serialVersionUID = 1L;
    
    @Inject
    private IGrupoAnexoDAO grupoAnexoDAO;
    
    @EJB
    private IAnexoService anexoService;
    
    @Override
	protected IGrupoAnexoDAO getDAO() {
		return grupoAnexoDAO;
	}

    @Override
    public void save(GrupoAnexo grupoAnexo) throws ServiceException, ValidationException {

        if (grupoAnexo != null && grupoAnexo.getAnexoList() != null && !grupoAnexo.getAnexoList().isEmpty()) {
            grupoAnexo.setNome("log");
            grupoAnexo.setDescricao("log descricao");
            if (grupoAnexo.getPK() == null) {
                super.save(grupoAnexo);
            } else {
                super.update(grupoAnexo);
            }

            Date dataAtual = getDataBanco();
            if (grupoAnexo.getAnexoList() != null) {
                for (Anexo anexo : grupoAnexo.getAnexoList()) {
                    if (anexo.getPK() == null) {

                        anexo.setGrupoAnexo(grupoAnexo);
                        anexo.setNomeFake(grupoAnexo.getPK() + anexo.getNomeReal());
                        anexo.setDataCriacao(dataAtual);
                        anexoService.save(anexo);
                    }
                }
            }
        }

    }

    @Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public GrupoAnexo buscaPorNome(String nomeGrupo) throws ServiceException {
        try {
            return getDAO().buscaPorNome(nomeGrupo);
        } catch (DataException e) {
            throw new ServiceException(e);
        }
    }

}
