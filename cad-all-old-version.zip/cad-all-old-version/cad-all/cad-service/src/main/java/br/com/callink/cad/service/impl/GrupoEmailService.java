/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.dao.IGrupoEmailDAO;
import br.com.callink.cad.pojo.AssociaGrupoEmail;
import br.com.callink.cad.pojo.EmailGrupoEmail;
import br.com.callink.cad.pojo.GrupoEmail;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.service.IAssociaGrupoEmailService;
import br.com.callink.cad.service.IEmailGrupoEmailService;
import br.com.callink.cad.service.IGrupoEmailService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.util.Constantes;

/**
 *
 * @author Luiz Gustavo (luizgf@swb.com.br)
 */
@Stateless
public class GrupoEmailService extends GenericGboService<GrupoEmail, IGrupoEmailDAO>
        implements IGrupoEmailService {

	private static final long serialVersionUID = 7874453533694759037L;
	
	@Inject
	private IGrupoEmailDAO grupoEmailDAO;
	
	@EJB
    private IAssociaGrupoEmailService associaGrupoEmailService;
    @EJB
    private IEmailGrupoEmailService emailGrupoEmailService;
    
	
	@Override
	protected IGrupoEmailDAO getDAO() {
		return grupoEmailDAO;
	}
	
    @Override
    public void save(GrupoEmail grupoEmail) throws ServiceException, ValidationException {
        grupoEmail.setDataCriacao(getDataBanco());
        super.save(grupoEmail);
    }

    /**
     * Retorna a descrição de uma lista de grupo de email, ou seja a descrição das mesmas concatenadas,
     * separadas por vírgula.
     * @param listaGrupoEmail
     * @return 
     */
    @Override
    public String getDescricaoFromListaGrupoEmail(List<GrupoEmail> listaGrupoEmail) {
        if (listaGrupoEmail == null || listaGrupoEmail.isEmpty()) {
            return null;
        }
        StringBuilder departamentos = new StringBuilder();
        for (GrupoEmail grupoEmail : listaGrupoEmail) {
            if (StringUtils.isEmpty(departamentos.toString())) {
                departamentos.append(grupoEmail.getDescricao());
            } else {
                departamentos.append(Constantes.VIRGULA).append(Constantes.ESPACO).append(grupoEmail.getDescricao());
            }
        }
        return departamentos.toString();
    }
    
    @Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<GrupoEmail> findByExample(GrupoEmail grupoEmail, String order) throws ServiceException {
		try {
			return getDAO().findByExample(grupoEmail, order);
		} catch (DataException e) {
			throw new ServiceException("Erro ao buscar Grupo Email.", e);
		}
	}
    
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void delete(GrupoEmail object) throws ServiceException,ValidationException {
		AssociaGrupoEmail associaGrupoEmail = new AssociaGrupoEmail();
		associaGrupoEmail.setGrupoEmail(object);
		List<AssociaGrupoEmail> grupos = associaGrupoEmailService.findByExample(associaGrupoEmail);

		if (grupos != null && !grupos.isEmpty()) {
			throw new ValidationException("Não foi possivel excluir este Grupo. Verifique se não há emails associados a ele antes de fazer a exclusão.");
		}

		EmailGrupoEmail emailGrupoEmail = new EmailGrupoEmail();
		emailGrupoEmail.setGrupoEmail(object);

		List<EmailGrupoEmail> emailGrupoEmails = new ArrayList<EmailGrupoEmail>();
		emailGrupoEmails = emailGrupoEmailService.findByExample(emailGrupoEmail);

		for (EmailGrupoEmail emails : emailGrupoEmails) {
			emailGrupoEmailService.delete(emails);
		}
		super.delete(object);
	}
    
}
