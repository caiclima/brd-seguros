/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.service.impl;

import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import br.com.callink.cad.dao.IGrupoEquipeFilaDAO;
import br.com.callink.cad.pojo.GrupoEquipe;
import br.com.callink.cad.pojo.GrupoEquipeFila;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.service.IGrupoEquipeFilaService;
import br.com.callink.cad.service.exception.ServiceException;

/**
 *
 * @author Rogerio
 */
@Stateless
public class GrupoEquipeFilaService extends GenericGboService<GrupoEquipeFila, IGrupoEquipeFilaDAO> implements IGrupoEquipeFilaService {

	private static final long serialVersionUID = -8886427035788086112L;

	@Inject
	private IGrupoEquipeFilaDAO grupoEquipeFilaDAO;
	
	
	@Override
	protected IGrupoEquipeFilaDAO getDAO() {
		return grupoEquipeFilaDAO;
	}
	
    @Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<GrupoEquipeFila> grupoEquipeFilaList(GrupoEquipe grupoEquipe) throws ServiceException {
        try {
            return getDAO().grupoEquipeFilaList(grupoEquipe);
        } catch (DataException ex) {
            throw new ServiceException("Erro ao buscar GrupoEquipeFila.", ex);
        }
    }
    
    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void limpaGrupoEquipeFila(GrupoEquipe grupoEquipe) throws ServiceException {
        try {
        	getDAO().limpaGrupoEquipeFila(grupoEquipe);
        } catch (DataException ex) {
            throw new ServiceException("Erro ao excluir GrupoEquipeFila.", ex);
        }
    }

}
