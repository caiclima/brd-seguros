/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.service.impl;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.dao.IGrupoEquipeDAO;
import br.com.callink.cad.pojo.Equipe;
import br.com.callink.cad.pojo.EquipeFila;
import br.com.callink.cad.pojo.GrupoEquipe;
import br.com.callink.cad.pojo.GrupoEquipeFila;
import br.com.callink.cad.service.IEquipeFilaService;
import br.com.callink.cad.service.IEquipeService;
import br.com.callink.cad.service.IGrupoEquipeFilaService;
import br.com.callink.cad.service.IGrupoEquipeService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 *
 * @author Rogerio
 */
@Stateless
public class GrupoEquipeService extends GenericGboService<GrupoEquipe, IGrupoEquipeDAO> implements IGrupoEquipeService {

	private static final long serialVersionUID = 4286035240318353582L;
	
	@Inject
	private IGrupoEquipeDAO grupoEquipeDAO;
	
	@EJB
	private IEquipeFilaService equipeFilaService;
	
	@EJB
	private IEquipeService equipeService;
	
	@EJB
	private IGrupoEquipeFilaService grupoGrupoEquipeFilaService;
	
	@Override
	protected IGrupoEquipeDAO getDAO() {
		return grupoEquipeDAO;
	}
	
    @Override
    public void save(GrupoEquipe grupoEquipe) throws ServiceException, ValidationException {
        if (grupoEquipe == null || StringUtils.isEmpty(grupoEquipe.getNome())) {
            throw new ValidationException("O nome deve ser informado.");
        }
        super.save(grupoEquipe); 
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void associaEquipeFila(GrupoEquipe grupoEquipe, List<Equipe> equipes) throws ServiceException, ValidationException {
        for (Equipe eq : equipes) {
            equipeFilaService.limpaEquipeFila(eq);
            if(grupoEquipe.getFlagPrioridade() && !eq.getFlagPrioridade()){
                eq.setFlagPrioridade(Boolean.TRUE);
                equipeService.saveOrUpdate(eq);
            }
            for (GrupoEquipeFila gef : grupoEquipe.getGrupoEquipeFilaList()) {
                EquipeFila ef = new EquipeFila(eq, gef.getConfiguracaoFila());
                ef.setQuantidadeCasoFila(gef.getQuantidadeCasoFila());
                equipeFilaService.save(ef);
            }
        }
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void delete(GrupoEquipe object) throws ServiceException, ValidationException {
        grupoGrupoEquipeFilaService.limpaGrupoEquipeFila(object);
        super.delete(object); 
    }

    
}
