package br.com.callink.cad.service.impl;

import javax.ejb.Stateless;
import javax.inject.Inject;

import br.com.callink.cad.dao.IHistoricoDadosCasoDAO;
import br.com.callink.cad.pojo.HistoricoDadosCaso;
import br.com.callink.cad.service.IHistoricoDadosCasoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

@Stateless
public class HistoricoDadosCasoService extends GenericGboService<HistoricoDadosCaso, IHistoricoDadosCasoDAO> implements IHistoricoDadosCasoService {
	
	private static final long serialVersionUID = 1L;
	
	@Inject
	private IHistoricoDadosCasoDAO historicoDadosCasoDAO;
	
	@Override
	protected IHistoricoDadosCasoDAO getDAO() {
		return historicoDadosCasoDAO;
	}
	
	@Override
	public void save(HistoricoDadosCaso histDadosCaso) throws ServiceException, ValidationException {
		
		histDadosCaso.setDataCadastro(getDataBanco());
		super.save(histDadosCaso);
	}

}
