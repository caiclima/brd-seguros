package br.com.callink.cad.service.impl;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.inject.Inject;

import br.com.callink.cad.dao.IHistoricoGboDAO;
import br.com.callink.cad.pojo.HistoricoGbo;
import br.com.callink.cad.pojo.TelaGbo;
import br.com.callink.cad.service.IHistoricoGboService;
import br.com.callink.cad.service.ITelaGboService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

@Stateless
public class HistoricoGboService extends GenericGboService<HistoricoGbo, IHistoricoGboDAO>implements IHistoricoGboService{

	private static final long serialVersionUID = -1491999239669100070L;

	@Inject
	private IHistoricoGboDAO historicoGboDAO;
	
	@EJB
	private ITelaGboService telaGboService;
	
	@Override
	protected IHistoricoGboDAO getDAO() {
		return historicoGboDAO;
	}
	
	@Override
	public void save(HistoricoGbo historicoGbo, String nomeTela) throws ServiceException, ValidationException{
		
		try {
			TelaGbo telaGbo = telaGboService.findByNomeTela(nomeTela);
			if(telaGbo == null){
				throw new ValidationException("Erro ao salvar historico - NOME DA TELA NAO EXISTE NA BASE DE DADOS!");
			}
			historicoGbo.setTelaGbo(telaGbo);
			
			historicoGbo.setDataCriacao(getDataBanco());
			
			this.save(historicoGbo);
			
		} catch (ServiceException e) {
			throw new ServiceException(e);
		}
	}
	
	@Override
	public void save (HistoricoGbo historicoGbo) throws ServiceException, ValidationException{
		if(historicoGbo.getTelaGbo() == null 
				|| historicoGbo.getTelaGbo().getPK() == null 
				|| historicoGbo.getIdTabelaOrigem() == null
				|| historicoGbo.getLoginUsuario() == null){
			throw new ValidationException("Erro ao salvar HistoricoCad - Campos obrigat\u00F3rios!");
		}
		
		historicoGbo.setDataCriacao(getDataBanco());
		super.save(historicoGbo);
	}

}
