package br.com.callink.cad.service.impl;

import java.util.Date;
import java.util.List;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;
import br.com.callink.cad.dao.ILogLigacoesDAO;
import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.LogLigacoes;
import br.com.callink.cad.repository.MarcacaoLogs;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.service.ILogLigacoesService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

@Stateless
public class LogLigacoesService extends GenericGboService<LogLigacoes, ILogLigacoesDAO> implements ILogLigacoesService {
            
	private static final long serialVersionUID = 1L;

	@Inject
	private ILogLigacoesDAO logLigacoesDAO;
	
	@Override
	protected ILogLigacoesDAO getDAO() {
		return logLigacoesDAO;
	}
	
	@Override
    public void saveLogLigacoes(LogLigacoes logLigacoes) throws ServiceException {
    	 if (logLigacoes.getRamal() == null || logLigacoes.getTelefoneCliente() == null
         		|| logLigacoes.getCanalEntrada() == null || logLigacoes.getCallID() == null
         		|| logLigacoes.getDataInicio() == null) {
             throw new ServiceException("Todos os campos obrigat\u00F3rios devem ser preenchidos.");
         }
         
        MarcacaoLogs.offer(logLigacoes);
    }
	
	@Override
    public void saveInicioLogLigacoesRealizada(LogLigacoes logLigacoes) throws ServiceException {
    	 if (logLigacoes.getRamal() == null || logLigacoes.getTelefoneCliente() == null
         		|| logLigacoes.getDataInicio() == null) {
             throw new ServiceException("Todos os campos obrigat\u00F3rios devem ser preenchidos.");
         }
         
        MarcacaoLogs.offer(logLigacoes);
    }
	
	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<LogLigacoes> findByCallIDAndDateEndNull(String callID) throws ServiceException {
		try {
			return getDAO().findByCallIDAndDateEndNull(callID);
		} catch (DataException e) {
			throw new ServiceException("Erro ao buscar logLigacoes por callID e data final vazia", e);
		}
	}
	
	@Override
	public List<LogLigacoes> findByUserSSOTelefone(String userSSO, String telefone) throws ServiceException {
		try {
			return getDAO().findByUserSSOTelefone(userSSO,telefone);
		} catch (DataException e) {
			throw new ServiceException("Erro ao buscar logLigacoes por callID e data final vazia", e);
		}
	}
	
	
	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<LogLigacoes> findByCallIdNullForUserSSO(String userSSO, String telefone) throws ServiceException {
		try {
			return getDAO().findByCallIdNullForUserSSO(userSSO, telefone);
		} catch (DataException e) {
			throw new ServiceException("Erro ao buscar logLigacoes por userSSO(login) e callID vazio e data final vazia", e);
		}
	}
	
	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<LogLigacoes> findByFilters(String idCaso, String flagEntrante, Date inicio, Date fim, List<Atendente> atendenteList) throws ServiceException, ValidationException {
		try {
			
			if ((inicio != null && fim == null) || (inicio == null && fim != null)) {
				throw new ValidationException("Os campos de datas não foram preenchidos corretamente");
			} 
			
			if (inicio == null && fim == null && (idCaso == null || idCaso.isEmpty())) {
				throw new ValidationException("Favor preencha no mínimo o campo idCaso ou os campos de data inicio e fim.");
			}
			
			return getDAO().findByFilters(idCaso, flagEntrante, inicio, fim, atendenteList);
		} catch (DataException e) {
			throw new ServiceException("Erro ao buscar logLigacoes por findByFilters", e);
		}
	}

	@Override
	public Boolean existeTentativaDeContatoPorCaso(Caso caso) throws ServiceException, ValidationException {
		try {
			
			if (caso == null || caso.getIdCaso() == null) {
				throw new ValidationException("O campo caso não foi preenchido corretamente.");
			}
			
			return getDAO().existeTentativaDeContatoPorCaso(caso);
			
		} catch (DataException e) {
			throw new ServiceException("Erro ao executar existeTentativaDeContatoPorCaso", e);
		}
	}

	@Override
	public Boolean existeTentativaDeContatoParaTodosTelefonesPorCasoEData(Caso caso, Date data) throws ServiceException, ValidationException {
		try {
			
			if (caso == null || caso.getIdCaso() == null) {
				throw new ValidationException("O campo caso não foi preenchido corretamente.");
			}
			
			return getDAO().existeTentativaDeContatoParaTodosTelefonesPorCasoEData(caso, data);
			
		} catch (DataException e) {
			throw new ServiceException("Erro ao executar existeTentativaDeContatoParaTodosTelefonesPorCasoEData", e);
		}
	}

	@Override
	public Boolean existeContatoComSucessoPorCaso(Caso caso) throws ServiceException, ValidationException {
		try {
			
			if (caso == null || caso.getIdCaso() == null) {
				throw new ValidationException("O campo caso não foi preenchido corretamente.");
			}
			
			return getDAO().existeContatoComSucessoPorCaso(caso);
			
		} catch (DataException e) {
			throw new ServiceException("Erro ao executar existeContatoComSucessoPorCaso", e);
		}
	}

	@Override
	public Boolean existeTentativaDeContatoParaTodosOutrosTelefonesPorCaso(Caso caso, String telefone) throws ServiceException, ValidationException {
		try {
			
			if (caso == null || caso.getIdCaso() == null) {
				throw new ValidationException("O campo caso não foi preenchido corretamente.");
			}
			
			if (telefone == null || telefone.isEmpty()) {
				throw new ValidationException("O campo telefone não foi preenchido corretamente.");
			}
			
			return getDAO().existeTentativaDeContatoParaTodosOutrosTelefonesPorCaso(caso, telefone);
			
		} catch (DataException e) {
			throw new ServiceException("Erro ao executar existeTentativaDeContatoParaTodosOutrosTelefonesPorCaso", e);
		}
	}

	@Override
	public Integer findQtdTentativaDeContatoPorTelefoneEData(String telefone, Date data) throws ServiceException, ValidationException {
		try {
			
			if (telefone == null || telefone.isEmpty()) {
				throw new ValidationException("O campo telefone não foi preenchido corretamente.");
			}
			if (data == null) {
				throw new ValidationException("O campo dataAtual não foi preenchido corretamente.");
			}
			
			return getDAO().findQtdTentativaDeContatoPorTelefoneEData(telefone, data);
			
		} catch (DataException e) {
			throw new ServiceException("Erro ao executar findQtdTentativaDeContatoPorTelefoneEData", e);
		}
	}

}
