package br.com.callink.cad.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import br.com.callink.cad.dao.ILogDAO;
import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.pojo.Anexo;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.Email;
import br.com.callink.cad.pojo.GrupoAnexo;
import br.com.callink.cad.pojo.Log;
import br.com.callink.cad.pojo.LogSlaCaso;
import br.com.callink.cad.pojo.Status;
import br.com.callink.cad.repository.MarcacaoLogs;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.service.IAnexoService;
import br.com.callink.cad.service.IGrupoAnexoService;
import br.com.callink.cad.service.ILogService;
import br.com.callink.cad.service.ILogSlaCasoService;
import br.com.callink.cad.service.ISlaService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.coreutils.util.date.DateUtils;

@Stateless
public class LogService extends GenericGboService<Log, ILogDAO> implements ILogService {

	private static final long serialVersionUID = 1L;

	@Inject
	private ILogDAO logDAO;
	
	@EJB(beanName="SlaTipoFilaService") 
	private ISlaService slaService;
	@EJB
	private IAnexoService anexoService;
	@EJB
	private IGrupoAnexoService grupoAnexoService;
	@EJB
	private ILogSlaCasoService logSlaCasoService;
	
	@Override
	protected ILogDAO getDAO() {
		return logDAO;
	}
	
    @Override
    public void save(Log log) throws ServiceException, ValidationException {
        if (log.getDescricao() == null) {
            throw new ValidationException("Todos os campos obrigat\u00F3rios devem ser preenchidos.");
        }
        if (log.getDataLog() == null) {
            log.setDataLog(getDataBanco());
        }
        
        if (log.getGrupoAnexo() != null
        		&& ((log.getGrupoAnexo().getIdGrupoAnexo() != null && log.getGrupoAnexo().getIdGrupoAnexo().equals(Integer.valueOf(0))) 
        		|| (log.getGrupoAnexo().getIdGrupoAnexo() == null))) {
            log.setGrupoAnexo(null);
        }
        
        super.save(log);
    }
    
    @Override
    public void update(Log object) throws ValidationException {
    	throw new ValidationException("Imposs\u00EDvel alterar os dados do LOG.");
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<Log> findHistorico(Caso caso) throws ServiceException {
        try {
            
            List<Log> logs = getDAO().findHistorico(caso);

            if (logs == null || logs.isEmpty()) {
                return new ArrayList<Log>();
            }
            
            // Busca histórico de alteração de SLA do caso
            List<LogSlaCaso> logsSla = logSlaCasoService.findLogSlaByCaso(caso);
            
            for (Log log : logs) {
            	Date dataAbertura = caso.getDataAbertura();
            	
            	// Se a data do log for antes da data de abertura do caso, pega o histórico de alteração do SLA.
            	// Pega a última data que for antes da data do log, e seta na data de abertura.
            	if (caso.getDataAbertura().compareTo(log.getDataLog()) > 0) {
            		for (LogSlaCaso logSlaCaso : logsSla) {
            			if (logSlaCaso.getDataAbertura().compareTo(log.getDataLog()) > 0) {
            				continue;
            			} else {
            				dataAbertura = logSlaCaso.getDataAbertura();
            				break;
            			}
            		}
            	}
            	
                //seta o SLA de acordo c/ a data do log atual em relação à data de abertura
                log.setSlaLog(slaService.calculaSlaIntervaloEmMinutos(dataAbertura, log.getDataLog()));
                
                if(log.getGrupoAnexo() != null && log.getGrupoAnexo().getPK() != null){
                    log.getGrupoAnexo().setAnexoList(anexoService.buscaPorGrupoAnexo(log.getGrupoAnexo()));
                } else {
                    log.setGrupoAnexo(new GrupoAnexo());
                    log.getGrupoAnexo().setAnexoList(new ArrayList<Anexo>());
                }
                
                //se existe proximo log
                int i = logs.indexOf(log);
                if (i < logs.size() - 1) {
                    //tempo gasto => tempo do log atual até proximo log (caso exista proximo)
                    log.setTempoGasto(slaService.formataSegundosEmHMS(DateUtils.getSecondsBetweenDates(log.getDataLog(), logs.get(i+1).getDataLog()).longValue()));
                }
                else {
                    //se caso ja finalizado, tempo gasto => data ultimo log até data data encerramento
                    if (caso.getDataEncerramento() != null) {
                        log.setTempoGasto(slaService.formataSegundosEmHMS(DateUtils.getSecondsBetweenDates(log.getDataLog(), caso.getDataEncerramento()).longValue()));
                    }
                    else {
                    //caso nao foi finalizado, tempo gasto => tempo do log atual até a data do banco (pois é o ultimo log)
                        log.setTempoGasto(slaService.formataSegundosEmHMS(DateUtils.getSecondsBetweenDates(log.getDataLog(), getDataBanco()).longValue()));
                    }
                }
            }
            
            return logs;
            
        } catch (DataException ex) {
            throw new ServiceException("Erro ao buscar hist\u00F3rico do caso", ex);
        }
    }
            
    @Override
    public void saveLog(Caso caso, String descricao) throws ServiceException {
            Log log = new Log();
            log.setCaso(caso);
            log.setStatus(caso.getStatus());
            if (caso.getAtendente() != null && caso.getAtendente().getIdAtendente() != null) {
                    log.setAtendente(caso.getAtendente());
            }
            log.setConfiguracaoFila(caso.getConfiguracaoFila());
            log.setDescricao(descricao);
            log.setDataLog(getDataBanco());
            MarcacaoLogs.offer(log);
    }

    @Override
    public void saveLogAnexos(Log log) throws ServiceException, ValidationException {
        validaLogAnexo(log);
        salvaLog(log);
    }
    
    @Override
    public void saveLogDocumento(Log log) throws ServiceException, ValidationException {
        validaLogDocumento(log);
        salvaLog(log);
    }

	@Override
    public void saveImediatoLogAnexos(Log log) throws ValidationException, ServiceException {
        validaLogAnexo(log);
        save(log);
    }
	
	private void validaLogDocumento(Log log) throws ServiceException, ValidationException {
		if (log == null) {
			throw new ValidationException("O log n\u00E3o pode ser nulo.");
		}

		if (log.getCaso() == null || log.getCaso().getIdCaso() == null) {
			throw new ValidationException("O caso n\u00E3o pode ser nulo.");
		}
		
		if (log.getAcao() == null || log.getAcao().getIdAcao() == null) {
			throw new ValidationException("A a\u00E7\u00E3o n\u00E3o pode ser nula.");
		}
		
		if (log.getAtendente() == null || log.getAtendente().getIdAtendente() == null) {
			throw new ValidationException("O atendente n\u00E3o pode ser nulo.");
		}
		
		if (log.getDescricao() == null || log.getDescricao().isEmpty()) {
			throw new ValidationException("O campo Observa\u00E7\u00E3o n\u00E3o pode ser nulo!");
		}

	}

    private void validaLogAnexo(Log log) throws ServiceException, ValidationException {
        if (log == null) {
            throw new ValidationException("O log n\u00E3o pode ser nulo.");
        }
        
        if (log.getCaso() == null || log.getCaso().getIdCaso() == null) {
            throw new ValidationException("O caso n\u00E3o pode ser nulo.");
        }
        
        if (log.getDescricao() == null || log.getDescricao().isEmpty()) {
            throw new ValidationException("O campo Observa\u00E7\u00E3o n\u00E3o pode ser nulo!");
        }
        
        if (log.getGrupoAnexo() != null && log.getGrupoAnexo().getIdGrupoAnexo() == null
        		&& log.getGrupoAnexo().getAnexoList() != null && !log.getGrupoAnexo().getAnexoList().isEmpty()) {
            grupoAnexoService.save(log.getGrupoAnexo());
        }
    }
        
    private void salvaLog(Log log) throws ServiceException {
        try {
            if (log.getStatus() == null && log.getCaso() != null && log.getCaso().getStatus() != null) {
               log.setStatus(log.getCaso().getStatus());
            }
            
            if (log.getConfiguracaoFila() == null && log.getCaso() != null && log.getCaso().getConfiguracaoFila() != null) {
                log.setConfiguracaoFila(log.getCaso().getConfiguracaoFila());
            }
            
            log.setDataLog(getDataBanco());
            MarcacaoLogs.offer(log);
            
        } catch (ServiceException ex) {
            throw new ServiceException("Erro ao salvar o log.",ex);
        }
    }
    
    @Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public void saveLogEmail(Caso caso, Email email, Acao acao) throws ServiceException {
        try {
            Log log = new Log();
            log.setCaso(caso);
            log.setStatus(caso.getStatus());
            if (!email.isEmailSistema()) {
                log.setAtendente(caso.getAtendente());
            }
            log.setEmail(email);
            log.setAcao(acao);
            log.setDescricao(email.getDescricaoLog());
            log.setDataLog(getDataBanco());
            log.setDetalhe(email.getDestinatarioParaExibicao());
            log.setConfiguracaoFila(caso.getConfiguracaoFila());
            MarcacaoLogs.offer(log);
        } catch (Exception ex) {
            throw new ServiceException("Erro ao salvar o log.",ex);
        }
    }

    
    @Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<Log> findHistoricoEmail(Caso caso) throws ServiceException {
        try {
            List<Log> historicoEmail = getDAO().findHistoricoEmail(caso);
            return historicoEmail;
        } catch (DataException ex) {
            throw new ServiceException(ex);
        } 
    }
    
    @Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public Integer countLogByCasoAndData(Caso caso, Date dataInicial, Date dataFinal) throws ServiceException {
    	try {
    		return getDAO().countLogByCasoAndData(caso, dataInicial, dataFinal);
    	} catch (Exception ex) {
    		throw new ServiceException(ex);
    	}
    }
    
    @Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public Integer countLogByCasoAndDataAndStatus(Caso caso, Date dataInicial, Date dataFinal, List<Status> statusList) throws ServiceException {
    	try {
    		return getDAO().countLogByCasoAndDataAndStatus(caso, dataInicial, dataFinal, statusList);
    	} catch (Exception ex) {
    		throw new ServiceException(ex);
    	}
    }
    
    @Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<Log> findLogsFromCaso(Caso caso, Date dataAlteracao) throws ServiceException {
        try {
            return getDAO().findLogsFromCaso(caso, dataAlteracao);
        } catch (DataException ex) {
            throw new ServiceException("Erro ao buscar emails associados a este caso.", ex);
        }
    }

}
