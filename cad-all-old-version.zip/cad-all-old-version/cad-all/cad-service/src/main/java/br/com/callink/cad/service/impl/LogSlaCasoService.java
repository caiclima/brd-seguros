package br.com.callink.cad.service.impl;

import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;

import br.com.callink.cad.dao.ILogSlaCasoDAO;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.LogSlaCaso;
import br.com.callink.cad.service.ILogSlaCasoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

@Stateless
public class LogSlaCasoService extends GenericGboService<LogSlaCaso, ILogSlaCasoDAO> implements ILogSlaCasoService {

	private static final long serialVersionUID = 1L;
	
	@Inject
	private ILogSlaCasoDAO logSlaCasoDAO;
	
	@Override
	protected ILogSlaCasoDAO getDAO() {
		return logSlaCasoDAO;
	}
	
	@Override
    public void save(LogSlaCaso logSlaCaso) throws ServiceException, ValidationException {
        if (logSlaCaso.getDataAlteracao() == null) {
        	logSlaCaso.setDataAlteracao(getDataBanco());
        }
        super.save(logSlaCaso);
    }
	
	public List<LogSlaCaso> findLogSlaByCaso(Caso caso) throws ServiceException {
		try {
			return getDAO().findLogSlaByCaso(caso);
		} catch (Exception e) {
			throw new ServiceException(e);
		}
	}
	
}
