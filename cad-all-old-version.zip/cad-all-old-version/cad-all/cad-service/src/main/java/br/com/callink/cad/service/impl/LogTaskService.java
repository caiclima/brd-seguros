package br.com.callink.cad.service.impl;

import javax.ejb.Stateless;
import javax.inject.Inject;

import br.com.callink.cad.dao.ILogTaskDAO;
import br.com.callink.cad.pojo.LogTask;
import br.com.callink.cad.service.ILogTaskService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

@Stateless
public class LogTaskService extends GenericGboService<LogTask, ILogTaskDAO> implements ILogTaskService {
	
	private static final long serialVersionUID = 1L;

	@Inject
	private ILogTaskDAO logTaskDAO;
	
	@Override
	protected ILogTaskDAO getDAO() {
		return logTaskDAO;
	}
	
	@Override
	public void save(LogTask logTask) throws ServiceException, ValidationException {
		if (logTask == null) {
			throw new ValidationException("O log não pode ser nulo.");
		}
		
		if (logTask.getDataInicial() == null || logTask.getDataFinal() == null || 
				logTask.getTotalRegistros() == null || logTask.getMnmExecutor() == null || 
				logTask.getMnmExecutor().isEmpty()) {
			throw new ValidationException("Os dados do log não foram preenchidos corretamente.");
		}
		super.save(logTask);
	}

}
