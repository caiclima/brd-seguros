/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import br.com.callink.cad.dao.IMetaUphDAO;
import br.com.callink.cad.enumeration.ImagesnMetaEnum;
import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.CabUph;
import br.com.callink.cad.pojo.Equipe;
import br.com.callink.cad.pojo.EquipeFila;
import br.com.callink.cad.pojo.GoalFinal;
import br.com.callink.cad.pojo.MetaUph;
import br.com.callink.cad.pojo.StatusAtendente;
import br.com.callink.cad.repository.MetasUphCache;
import br.com.callink.cad.repository.to.CabMetaTO;
import br.com.callink.cad.repository.to.EquipeMetaTO;
import br.com.callink.cad.repository.to.MetaFilaTO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.service.IAtendenteService;
import br.com.callink.cad.service.ICabUphService;
import br.com.callink.cad.service.ICasoService;
import br.com.callink.cad.service.IConfiguracaoFilaService;
import br.com.callink.cad.service.IEquipeFilaService;
import br.com.callink.cad.service.IEquipeService;
import br.com.callink.cad.service.IGoalFinalService;
import br.com.callink.cad.service.IMetaUphService;
import br.com.callink.cad.service.IStatusAtendenteService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.coreutils.util.date.DateUtils;

/**
 *
 * @author swb.miller
 */
@Stateless
public class MetaUphService extends GenericGboService<MetaUph, IMetaUphDAO> implements IMetaUphService {

	private static final long serialVersionUID = -6035540044793503339L;
	private Date dataBancoAtual;
	private List<GoalFinal> listGoalFinal;
	
	@Inject
	private IMetaUphDAO metaUphDAO;
	@EJB
	private IEquipeService equipeService;
	@EJB
	private IAtendenteService atendenteService;
	@EJB
	private IEquipeFilaService equipeFilaService;
	@EJB
	private IStatusAtendenteService statusAtendenteService;
	@EJB
	private ICasoService casoService;
	@EJB
	private ICabUphService cabUphService;
	@EJB
	private IConfiguracaoFilaService configuracaoFilaService;
	@EJB
	private IMetaUphService metaUphService;
	@EJB
	private IGoalFinalService goalFinalService;
	
	@Override
	protected IMetaUphDAO getDAO() {
		return metaUphDAO;
	}
	
	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<MetaUph> findMetaByCabUph(CabUph cab) throws ServiceException {
        try { 
            return getDAO().findMetaByCabUph(cab);
        } catch(DataException e) {
            throw new ServiceException(e);       
        }
    }
    
    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void calculaMetasUph() throws ServiceException {
    	
    	listGoalFinal = goalFinalService.buscaGoalsAtivos();
    	
    	Map<String, CabMetaTO> mapCabMeta = new HashMap<String, CabMetaTO>();
    	dataBancoAtual = getDataBanco();
    	
    	try {
    		List<Equipe> equipes = equipeService.findAtivos(null);
    		    		for(Equipe equipe: equipes) {

                    List<Atendente> atendentes = atendenteService.buscaAtendentesPorEquipe(equipe);
                    List<EquipeFila> equipeFilas = equipeFilaService.findFilasByEquipe(equipe);    			

                    List<EquipeMetaTO> equipeMetaListTO = new ArrayList<EquipeMetaTO>();

                    for(EquipeFila equipeFila: equipeFilas) {

                        EquipeMetaTO equipeMetaTO = new EquipeMetaTO();

                        equipeMetaTO.setCasosFechados(Integer.valueOf(0));
                        equipeMetaTO.setTempoTotalEquipe(Double.valueOf(0d));

                        equipeMetaListTO.add(equipeMetaTO);

                        for(Atendente atendente: atendentes) {

                                MetaFilaTO metaFilaTo = new MetaFilaTO();

                                //tempo total atendente em todas as filas
                                List<StatusAtendente> listStatusTotal = statusAtendenteService.
                                                buscaStatusAtendenteByUserEquipe(null,
                                                equipe, atendente, DateUtils.addFirstTimeInDate(new Date()), DateUtils.addLastTimeInDate(new Date()));

                                Double tempoTotalAtendenteTodasFilas = Double.valueOf(tempoGastoAtendente(listStatusTotal));

                                //tempo total atendente na fila
                                List<StatusAtendente> listStatus = statusAtendenteService.
                                                buscaStatusAtendenteByUserEquipe(equipeFila.getConfiguracaoFila(),
                                                equipe, atendente, DateUtils.addFirstTimeInDate(new Date()), DateUtils.addLastTimeInDate(new Date()));

                                Double tempoTotalAtendente = Double.valueOf(tempoGastoAtendente(listStatus));
                                Integer casosFechadosAtendente = casoService.quantidadeCasosFechados(atendente.getIdAtendente(), 
                                                equipeFila.getConfiguracaoFila().getIdConfiguracaoFila(), 
                                                DateUtils.addFirstTimeInDate(new Date()), DateUtils.addLastTimeInDate(new Date()));
                                equipeMetaTO.setCasosFechados(equipeMetaTO.getCasosFechados() + casosFechadosAtendente);

                                //converte de milisegundos para hora
                                Double tmo = (tempoTotalAtendente / Double.valueOf(1000 * 60 * 60))  / Double.valueOf( casosFechadosAtendente );

                                Double uphRealizado = 1 / tmo;

                                if(uphRealizado.equals(Double.NaN) || uphRealizado.equals(Double.NEGATIVE_INFINITY ) 
                                                || uphRealizado.equals(Double.POSITIVE_INFINITY) ) {
                                        uphRealizado = 0d;
                                }

                                CabUph cab = cabUphService.findUltimaMetaConfigura(equipeFila.getConfiguracaoFila());
                                Double uphMeta =  cab != null ? cab.getMeta() : 0d; 

                                metaFilaTo.setUph(uphRealizado);
                                metaFilaTo.setMeta(uphMeta);
                                metaFilaTo.setFila(configuracaoFilaService.findByPk(equipeFila.getConfiguracaoFila()));
                                metaFilaTo.setIndiceGoal(uphMeta.equals(0d) ? 0d : (uphRealizado / uphMeta) );
                                metaFilaTo.setLogin(atendente.getLogin());

                                if( cab != null ){
                            	   montaRegraGoal(metaFilaTo.getIndiceGoal(), 
                                                metaUphService.findMetaByCabUph(cab), metaFilaTo, tempoTotalAtendente, tempoTotalAtendenteTodasFilas);
                                } else {
                                	metaFilaTo.setImagemGoal(ImagesnMetaEnum.CINZA.getCaminho());
                                	metaFilaTo.setGoalFinal(0d);
                                }

                                equipeMetaTO.setTempoTotalEquipe(equipeMetaTO.getTempoTotalEquipe() + tempoTotalAtendente);
                                metaFilaTo.setEquipeMetaTO(equipeMetaTO);
                                
                                if (mapCabMeta.containsKey(atendente.getLogin())) {
                                    mapCabMeta.get(atendente.getLogin()).getListaMetaFilaTO().add(metaFilaTo);
                                } else {
                                    CabMetaTO cabMetaTO = new CabMetaTO();
                                    cabMetaTO.setListaMetaFilaTO(new ArrayList<MetaFilaTO>());
                                    cabMetaTO.getListaMetaFilaTO().add(metaFilaTo);
                                    cabMetaTO.setIdAtendente(atendente.getIdAtendente());
                                    mapCabMeta.put(atendente.getLogin(), cabMetaTO);
                                }

                                if(tempoTotalAtendente == 0) {
                                        metaFilaTo.setImagemGoal(ImagesnMetaEnum.CINZA.getCaminho());
                                }
                        }
                        
                        equipeMetaTO.setUphEquipe(equipeMetaTO.getCasosFechados() == 0 ? 0d
									: 1 / ((equipeMetaTO.getTempoTotalEquipe() / Double
											.valueOf(1000 * 60 * 60)) / equipeMetaTO
											.getCasosFechados()));
                    }
    		}
    		
            calculaGMediaPonderadaFinal(mapCabMeta);
                            
            MetasUphCache.criaMapMetas(mapCabMeta); 
    		
    	} catch (ServiceException e) {
			throw new ServiceException(e);
		} catch (Exception e) {
			throw new ServiceException("Erro Inesperado, favor entrar em contato com o administrador", e);
		}
    	
    }
    

    /**
    * calcula regra de goal/indice do atendente na fila
    * 
    * @param indiceGoal
    * @param metasUph
    * @return
    */
	private String montaRegraGoal(Double indiceGoal, List<MetaUph> metasUph, MetaFilaTO metaTO, Double tempoTotalAtendente, Double tempoTotalAtendenteTodasFilas) {

		Collections.sort(metasUph);
		
		List<Double> metas = new ArrayList<Double>();
		
		for(MetaUph meta: metasUph) {
			metas.add(meta.getMeta());
		}
		
		Collections.sort(metas);
		Double ind = indiceGoal * 100d;
		int retorno = Collections.binarySearch(metas, ind);
		
		//incrementa + 1 e retorna numero positivo
		retorno = Math.abs(++retorno);
		if(metasUph.size() < retorno) {
			MetaUph meta = metasUph.get(metasUph.size());
            metaTO.setImagemGoal(ImagesnMetaEnum.convertDescToImagem(meta.getNomeImagem()));
            metaTO.setGoalFinal(tempoTotalAtendenteTodasFilas != 0 ? meta.getGoal() * (tempoTotalAtendente / tempoTotalAtendenteTodasFilas) : 0d);
		} else {
			retorno = retorno == 0 ? 0 : retorno - 1;
			MetaUph meta = metasUph.get(retorno);
			metaTO.setImagemGoal(ImagesnMetaEnum.convertDescToImagem(meta.getNomeImagem()));
			metaTO.setGoalFinal(tempoTotalAtendenteTodasFilas != 0 ? meta.getGoal() * (tempoTotalAtendente / tempoTotalAtendenteTodasFilas) : 0d);
		}
		return metaTO.getImagemGoal();
		
	}

	
	/**
     * calcula tempo gasto do atendente em uma determinada fila
     * 
     * @param listStatusAtendente
     * @return
     */
    private Long tempoGastoAtendente(List<StatusAtendente> listStatusAtendente) {
    	
    	Long tempo = 0l;
    	for(StatusAtendente statusAtendente: listStatusAtendente) {
    		if(statusAtendente != null 	&& statusAtendente.getDataInicio() != null ) {
    			long dateFinal = statusAtendente.getDataFim() == null ? dataBancoAtual.getTime() : statusAtendente.getDataFim().getTime();
    			tempo += dateFinal - statusAtendente.getDataInicio().getTime();
    		}
    	}
    	return tempo;
    }

    private void calculaGMediaPonderadaFinal(Map<String, CabMetaTO> mapCabMeta) {
        
       for (Map.Entry<String, CabMetaTO> entry: mapCabMeta.entrySet()) {
    	   
    	   Double somaGoals = 0d;
    	   CabMetaTO cabMetaTO = entry.getValue();
    	   
    	   for (Iterator<MetaFilaTO> iterator = cabMetaTO.getListaMetaFilaTO().iterator(); iterator.hasNext();) {
    		   MetaFilaTO type = iterator.next();
    		   somaGoals += type.getGoalFinal();
			
    	   }
    	   
    	   cabMetaTO.setgMediaPonderadaFinal(somaGoals);
    	   for(GoalFinal goal: listGoalFinal) {
    		   
    		   if(somaGoals >= goal.getGoalInicial() && somaGoals <= goal.getGoalFinal()) {
    			  cabMetaTO.setImageGFinal(goal.getNomeImagem());
    			  break;
    		   } 
    		   
    		   if(somaGoals >= goal.getGoalFinal()) {
    			   cabMetaTO.setImageGFinal(goal.getNomeImagem());
    			   break;
    		   }
    	   }
       }
    }
}
