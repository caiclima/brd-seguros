package br.com.callink.cad.service.impl;

import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import br.com.callink.cad.dao.IParametroComandoDAO;
import br.com.callink.cad.pojo.Comando;
import br.com.callink.cad.pojo.ParametroComando;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.service.IParametroComandoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 * @author Rogerio Moreira [rogeriom@swb.com.br]
 * 
 */
@Stateless
public class ParametroComandoService extends GenericGboService<ParametroComando, IParametroComandoDAO>
        implements IParametroComandoService {

    private static final long serialVersionUID = 1L;
 
    @Inject
    private IParametroComandoDAO parametroComandoDAO;
    
    @Override
	protected IParametroComandoDAO getDAO() {
		return parametroComandoDAO;
	}
    
    @Override
    public void save(ParametroComando parametroComando) throws ServiceException, ValidationException {
    	validarParametroComando(parametroComando);
    	super.save(parametroComando);
    }
    
    @Override
    public void update(ParametroComando parametroComando) throws ServiceException, ValidationException {
    	validarParametroComando(parametroComando);
    	super.update(parametroComando);
    }

	/**
	 * @param parametroComando
	 * @throws ServiceException
	 */
	private void validarParametroComando(ParametroComando parametroComando)
			throws ValidationException, ServiceException {
		if (parametroComando == null) {
    		throw new ValidationException("O ParametroComando n\u00E3o pode ser nulo.");
    	}
    	if (parametroComando.getComando() == null || parametroComando.getNome() == null 
    			|| parametroComando.getValor() == null || parametroComando.getNome().isEmpty() 
    			|| parametroComando.getValor().isEmpty()) {
    		throw new ValidationException("Os campos do parametro devem ser preenchidos corretamente.");
    	}
    	
    	parametroComando.setDataCriacao(getDataBanco());
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<ParametroComando> buscaPorComando(Comando comando) throws ServiceException, ValidationException {
		
		if (comando == null || comando.getIdComando() == null) {
			throw new ValidationException("O comando n\u00E3o pode ser nulo.");
		}
		
		ParametroComando parametroComando = new ParametroComando();
		parametroComando.setComando(comando);
		
		try {
			return getDAO().findByExample(parametroComando);
		} catch (DataException e) {
			throw new ServiceException("Erro ao buscar os parametros de um comando",e);
		}
	}
	
	@Override
	public ParametroComando buscaPorComandoNome(Comando comando, String nomeParametro) throws ServiceException, ValidationException {
		if (comando == null || comando.getIdComando() == null) {
			throw new ValidationException("O comando n\u00E3o pode ser nulo.");
		}
		if (nomeParametro == null || nomeParametro.isEmpty()) {
			throw new ValidationException("O nome do parametro n\u00E3o pode ser nulo.");
		}
		
		ParametroComando parametroComando = new ParametroComando();
		parametroComando.setComando(comando);
		parametroComando.setNome(nomeParametro);
		
		try {
			List<ParametroComando> parametros = getDAO().findByExample(parametroComando);
			if (parametros != null && parametros.size() > 0) {
				return parametros.get(0);
			}
		} catch (DataException e) {
			throw new ServiceException("Erro ao buscar os parametros de um comando",e);
		}
		return null;
	}

}
