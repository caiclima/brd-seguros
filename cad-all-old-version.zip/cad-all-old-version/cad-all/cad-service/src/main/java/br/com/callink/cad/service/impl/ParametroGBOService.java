package br.com.callink.cad.service.impl;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import br.com.callink.cad.dao.IParametroGBODAO;
import br.com.callink.cad.pojo.Feriado;
import br.com.callink.cad.pojo.HistoricoGbo;
import br.com.callink.cad.pojo.ParametroGBO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.service.IFeriadoService;
import br.com.callink.cad.service.IHistoricoGboService;
import br.com.callink.cad.service.IParametroGBOService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.util.Constantes;

import com.google.gson.Gson;
/**
 * 
 * @author brunoam
 */
@Stateless
public class ParametroGBOService extends GenericGboService<ParametroGBO, IParametroGBODAO> implements IParametroGBOService {
	
	private static final long serialVersionUID = 1L;

	@Inject
	private IParametroGBODAO parametroGBODAO;
	
	@EJB
	private IHistoricoGboService historicoGboService;
	
	@EJB
	private IFeriadoService feriadoService;
	
	@Override
	protected IParametroGBODAO getDAO() {
		return parametroGBODAO;
	}
	
    @Override
	public void save(ParametroGBO parametro) throws ServiceException, ValidationException {
		validacoesParametro(parametro);
		
		super.save(parametro);
		salvaHistoricoAlteracao(parametro); 
	}

    @TransactionAttribute(TransactionAttributeType.REQUIRED)
	private void salvaHistoricoAlteracao(ParametroGBO parametro) throws ServiceException, ValidationException {
		Gson gson = new Gson();
		HistoricoGbo historicoGbo = new HistoricoGbo();
		historicoGbo.setHistorico(gson.toJson(parametro));
		historicoGbo.setLoginUsuario(parametro.getLoginUsuario());
		historicoGbo.setIdTabelaOrigem(parametro.getPK());
		historicoGboService.save(historicoGbo, "telaParametro");
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public ParametroGBO findByParam(String key) throws ServiceException {
		try {
              return getDAO().findByParam(key);
		} catch (DataException e) {
          throw new ServiceException("Erro ao buscar parametro", e);
		}
	}
	
	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<ParametroGBO> findByParam(String... key) throws ServiceException {
		try {
              return getDAO().findByParam(key);
		} catch (DataException e) {
          throw new ServiceException("Erro ao buscar parametro", e);
		}
	}
	
	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<ParametroGBO> findParamStartsWithKey(String key) throws ServiceException {
		try {
              return getDAO().findParamStartsWithKey(key);
		} catch (DataException e) {
          throw new ServiceException("Erro ao buscar parametro", e);
		}
	}
	
	@Override
	public void update(ParametroGBO parametro) throws ServiceException, ValidationException {
		validacoesParametro(parametro);
		salvaHistoricoAlteracao(parametro); 
		super.update(parametro);
	}

	/**
	 * @param parametro
	 * @throws ServiceException
	 */
	private void validacoesParametro(ParametroGBO parametro) throws ValidationException, ServiceException {
		if (parametro == null) {
			throw new ValidationException("O Parametro n\u00E3o pode ser nulo.");
		}
		if (parametro.getNome() == null || parametro.getValor() == null ||
				parametro.getNome().isEmpty() || parametro.getValor().isEmpty()) {
			throw new ValidationException("Os campos do parametro devem ser informados.");
		}
		
		parametro.setDataAlteracao(getDataBanco());
	}

    @Override
    public Boolean contabilizaDataAtual() throws ServiceException {
        Calendar cal = Calendar.getInstance();
        return contabilizaData(cal);
    }
    
    @Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public Boolean contabilizaData(Calendar calendar) throws ServiceException {
        Boolean sabado = Boolean.valueOf(findByParam(Constantes.CONTA_SABADO).getValor());
        Boolean domingo = Boolean.valueOf(findByParam(Constantes.CONTA_DOMINGO).getValor());
        
        Map<String, Feriado> feriadoMap = new HashMap<String, Feriado>();
        DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        for (Feriado dta : feriadoService.findAll()) {
        	feriadoMap.put(df.format(dta.getDataFeriado()),	dta);
        }
        
        boolean validaSabado = calendar.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY ? sabado : Boolean.TRUE;
        boolean validaDomingo = calendar.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY ? domingo : Boolean.TRUE;
        
        if (!validaSabado || !validaDomingo) {
            return false;
        }
        
        if (feriadoMap.containsKey(df.format(calendar.getTime()))) {
            return false;
        }
        
        return true;
    }
    
    @Override
    public boolean buscarParametroBooleano(String nomeParametro){
    	try{
    		ParametroGBO param = findByParam(nomeParametro);
    		
    		return param == null ? false : 
    				("1".equals(param.getValor()) ? true : false);
    	}catch(Exception e){
    		e.printStackTrace();
    		return false;
    	}
	}
	
 }
