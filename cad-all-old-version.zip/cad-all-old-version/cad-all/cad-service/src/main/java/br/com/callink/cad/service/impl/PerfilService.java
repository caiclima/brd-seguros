package br.com.callink.cad.service.impl;

import br.com.callink.cad.dao.IPerfilDAO;
import br.com.callink.cad.pojo.Perfil;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.service.IPerfilService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;

/**
 * @author Rogerio Moreira [rogeriom@swb.com.br]
 * 
 */
@Stateless
public class PerfilService extends GenericGboService<Perfil, IPerfilDAO> implements IPerfilService {

    private static final long serialVersionUID = 1L;

    @Inject
    private IPerfilDAO perfilDAO;
    
    @Override
	protected IPerfilDAO getDAO() {
		return perfilDAO;
	}
    
    @Override
    public void save(Perfil perfil) throws ServiceException, ValidationException {
    	validaPerfil(perfil);
    	super.save(perfil);
    }

	private void validaPerfil(Perfil perfil) throws ServiceException, ValidationException {
		if (perfil == null) {
    		throw new ValidationException("O perfil n\u00E3o pode ser nulo.");
    	}
    	if (StringUtils.isBlank(perfil.getNome())) {
    		throw new ValidationException("Campo Nome \u00E9 obrigat\u00F3rio.");
    	}
    	perfil.setDataCriacao(getDataBanco());
	}
    
    @Override
    public void update(Perfil perfil) throws ServiceException, ValidationException {
    	validaPerfil(perfil);
    	super.update(perfil);
    }
    
    @Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<Perfil> findAtivos() throws ServiceException {
        try {
            return getDAO().findAtivos();
        } catch (DataException ex) {
            throw new ServiceException("Erro ao buscar Perfis", ex);
        }
    }

    @Override
    public void inativar(Perfil perfil) throws ServiceException, ValidationException {
        if (perfil.getPK() == null) {
            throw new ValidationException("Falha ao inativar: chave primaria n\u00E3o informada.");
        } else {
            perfil.setFlagAtivo(Boolean.FALSE);
            this.update(perfil);
        }
    }

	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public Perfil findByPk(Object object) throws ServiceException {
		try {
			return getDAO().findByPk(object);
		} catch (DataException e) {
			 throw new ServiceException("Erro ao buscar por PK", e);
		}
	}

}
