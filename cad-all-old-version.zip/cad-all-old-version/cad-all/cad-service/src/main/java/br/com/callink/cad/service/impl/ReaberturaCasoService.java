package br.com.callink.cad.service.impl;

import br.com.callink.cad.dao.IReaberturaCasoDAO;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.ReaberturaCaso;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.service.IReaberturaCasoService;
import br.com.callink.cad.service.exception.ServiceException;

import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

@Stateless
public class ReaberturaCasoService extends GenericGboService<ReaberturaCaso, IReaberturaCasoDAO> implements IReaberturaCasoService {
	
	
	private static final long serialVersionUID = 1L;
	
	@Inject
	private IReaberturaCasoDAO reaberturaCasoDAO;
	
	@Override
	protected IReaberturaCasoDAO getDAO() {
		return reaberturaCasoDAO;
	}
	
    @Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<ReaberturaCaso> findByCaso(Caso caso) throws ServiceException {
        try {
        	if (caso == null || caso.getIdCaso() == null) {
        		return null;
        	}
            return getDAO().findByCaso(caso);
        } catch (DataException ex) {
            throw  new ServiceException("Erro ao busca as reaberturas do caso",ex);
        }
    }

}
