package br.com.callink.cad.service.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import br.com.callink.cad.dao.IRelatorioCasosFechadosDAO;
import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.Equipe;
import br.com.callink.cad.pojo.ParametroGBO;
import br.com.callink.cad.pojo.RelatorioCasosFechados;
import br.com.callink.cad.repository.to.CasoFechadoTO;
import br.com.callink.cad.repository.to.DetalheCasoFechadoTO;
import br.com.callink.cad.service.IAtendenteService;
import br.com.callink.cad.service.ICasoService;
import br.com.callink.cad.service.IEquipeService;
import br.com.callink.cad.service.IParametroGBOService;
import br.com.callink.cad.service.IRelatorioCasosFechadosService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.util.Constantes;

@Stateless
public class RelatorioCasosFechadosService extends GenericGboService<RelatorioCasosFechados, IRelatorioCasosFechadosDAO> implements IRelatorioCasosFechadosService {
	
	private static final long serialVersionUID = 1L;
        
    public static final Integer POR_HORA = 1;
    public static final Integer POR_EQUIPE = 2;
    public static final Integer POR_ANALISTA = 3;
    
    @EJB
    private IAtendenteService atendenteService;
    @EJB
    private ICasoService casoService;
    @EJB
    private IParametroGBOService parametroGBOService;
    @EJB
    private IEquipeService equipeService;
     
    @Inject
    private IRelatorioCasosFechadosDAO relatorioCasosFechadosDAO;
    
    @Override
	protected IRelatorioCasosFechadosDAO getDAO() {
		return relatorioCasosFechadosDAO;
	}
    
	private static final Logger LOGGER = Logger.getLogger(RelatorioCasosFechadosService.class.getName());
	
	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<RelatorioCasosFechados> buscaCasosFechadosDia(Date dataBusca) throws ServiceException {
		try {
			return getDAO().buscaCasosFechadosDia(dataBusca);
		} catch (Exception e) {
			throw new ServiceException("Erro ao buscar os casos fechados no dia",e);
		}
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<RelatorioCasosFechados> buscaCasosFechadosDia()	throws ServiceException {
		try {
			return getDAO().buscaCasosFechadosDia();
		} catch (Exception e) {
			throw new ServiceException("Erro ao buscar os casos fechados no dia",e);
		}
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void geraCasosFechadosDia() throws ServiceException {
		try {
			Date dataAtual = new Date();
			Date dataFim = getDataBanco();
			List<Caso> casosFechados = casoService.buscaCasosSLAFimDia(dataAtual);
			
			for(Caso caso : casosFechados) {
				casoService.calculaSla(caso, dataFim);
			}
			
			List<RelatorioCasosFechados> relatorioCasosFechados = geraRelatorioCasosFechados(casosFechados, dataAtual);
			
			limpaDiaAtual(dataAtual);
			
			for (RelatorioCasosFechados relatorio : relatorioCasosFechados) {
				getDAO().save(relatorio);
			}
		} catch (Exception e) {
			throw new ServiceException("Erro ao buscar casos fechados no dia",e);
		}
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void limpaDiaAtual(Date dataAtual) throws ServiceException {
		try {
			getDAO().limpaDiaAtual(dataAtual);
		} catch (Exception e) {
			throw new ServiceException("Erro ao limpar os dados",e);
		}
	}

	private List<RelatorioCasosFechados> geraRelatorioCasosFechados(List<Caso> casosFechados, Date dataAtual) {
		
		List<RelatorioCasosFechados> relatorioCasosFechados = new ArrayList<RelatorioCasosFechados>();
		
		for (Caso caso : casosFechados) {
			RelatorioCasosFechados relatorioCasoFechado = new RelatorioCasosFechados();
			relatorioCasoFechado.setAtendente(caso.getAtendente() != null ? caso.getAtendente().getLogin():null);
			relatorioCasoFechado.setDataFim(caso.getDataFimSla());
			relatorioCasoFechado.setEquipeNome(caso.getAtendente() != null ? caso.getAtendente().getEquipe().getNome() : "");
			relatorioCasoFechado.setFilaNome(caso.getConfiguracaoFila() != null ? caso.getConfiguracaoFila().getNome() : "");
			relatorioCasoFechado.setFlagDentroPrazo(caso.getPorcentagemSla() > 100 ? Boolean.FALSE : Boolean.TRUE);
			relatorioCasoFechado.setIdAtendente(caso.getAtendente() != null ? caso.getAtendente().getIdAtendente() :null);
			relatorioCasoFechado.setIdCaso(caso.getIdCaso());
			relatorioCasoFechado.setIdEquipe(caso.getAtendente() != null ? caso.getAtendente().getEquipe().getIdEquipe():null);
			relatorioCasoFechado.setIdExterno(caso.getIdExterno());
			relatorioCasoFechado.setIdFila(caso.getConfiguracaoFila() != null ? caso.getConfiguracaoFila().getIdConfiguracaoFila():null);
			relatorioCasoFechado.setSla(caso.getPorcentagemSla());
			relatorioCasoFechado.setDataCadastro(dataAtual);
			relatorioCasosFechados.add(relatorioCasoFechado);
		}
		
		return relatorioCasosFechados;
	}
        
        @Override
        public CasoFechadoTO retornaTotal(List<CasoFechadoTO> casosList) {
            if (casosList == null) {
                return null;
            }
            CasoFechadoTO casoTotal = null;
            for (CasoFechadoTO casoFechadoTO : casosList) {
                if (casoFechadoTO.getRangeHora().equals("TOTAL")) {
                    casoTotal = casoFechadoTO;
                }
            }
            if (casoTotal != null) {
                casosList.remove(casoTotal);
            }
            return casoTotal;
        }
        
	@Override
	public List<CasoFechadoTO> retornaCasosFechados(Integer qtdDias, Integer divisaoRelatorio, String equipe) throws ServiceException {
		
		ParametroGBO parametroGBO = parametroGBOService.findByParam(Constantes.FECHADO_POR_HORA);
		List<CasoFechadoTO> casoFechadoTOList = new ArrayList<CasoFechadoTO>();
		
		int horaInicio = Integer.valueOf(0);
		int horaFim = Integer.valueOf(0);
		
		List<RelatorioCasosFechados> casosFechados = buscaCasosFechadosDia();
		Map<String, String> nomesFilasComFinalizacao = new HashMap<String, String>();
		
		CasoFechadoTO casoFechadoTOtotal = new CasoFechadoTO();
		casoFechadoTOtotal.setRangeHora("TOTAL");
		
		if (parametroGBO != null && parametroGBO.getValor() != null) {
			String horas[] = parametroGBO.getValor().split(";");
			
			try {
				horaInicio = Integer.valueOf(horas[0]);
				horaFim = Integer.valueOf(horas[1]);
			} catch (Exception e) {
				horaInicio = Integer.valueOf("7");
				horaFim = Integer.valueOf("22");
				
				LOGGER.log(Level.SEVERE, "Erro ao definir os valores de horas no relatorio de Casos Fechados", e);
			}
			
		} else {
			horaInicio = Integer.valueOf("7");
			horaFim = Integer.valueOf("22");
		}
		
		iniciaCasoFechado(casoFechadoTOList , horaInicio, horaFim, casosFechados, divisaoRelatorio, equipe, casoFechadoTOtotal);
		
                
		for(RelatorioCasosFechados relatorioCasosFechados : casosFechados) {
                    addCasoRangeHora(casoFechadoTOList, relatorioCasosFechados, nomesFilasComFinalizacao, casoFechadoTOtotal, divisaoRelatorio, equipe);
		}
		
		casoFechadoTOList.add(casoFechadoTOtotal);
		
		return casoFechadoTOList;
	}

	private void insereTodasFilasComFinalizacaoPorRangeHora(List<CasoFechadoTO> casoFechadoTOList, List<RelatorioCasosFechados> casosFechados, CasoFechadoTO casoFechadoTOtotal) {
		if (casoFechadoTOList != null) {
			for(CasoFechadoTO casoFechadoTO : casoFechadoTOList) {
				for (RelatorioCasosFechados relatorioCasosFechados : casosFechados) {
					Boolean insereDetalhe = true;
					for (DetalheCasoFechadoTO detalheCasoFechadoTO : casoFechadoTO.getCasosFechadosPorTipo()) {
						if (relatorioCasosFechados.getFilaNome().equals(detalheCasoFechadoTO.getTipoCaso())) {
							insereDetalhe = false;
							break;
						}
					}
					
					if (insereDetalhe) {
						DetalheCasoFechadoTO detalheCasoFechadoTO = new DetalheCasoFechadoTO();
						detalheCasoFechadoTO.setTipoCaso(relatorioCasosFechados.getFilaNome());
						casoFechadoTO.getCasosFechadosPorTipo().add(detalheCasoFechadoTO);
					}
					
				}
			}
		    if (!casoFechadoTOList.isEmpty() && casoFechadoTOList.get(0) != null) {
		        for (DetalheCasoFechadoTO detalhe : casoFechadoTOList.get(0).getCasosFechadosPorTipo()) {
		            DetalheCasoFechadoTO detalheCasoFechadoTO = new DetalheCasoFechadoTO();
		            detalheCasoFechadoTO.setTipoCaso(detalhe.getTipoCaso());
		            casoFechadoTOtotal.getCasosFechadosPorTipo().add(detalheCasoFechadoTO);
		        }
		    }
		}
	}

	private void addCasoRangeHora(List<CasoFechadoTO> casoFechadoTOList, RelatorioCasosFechados relatorioCasosFechados, Map<String, String> nomesFilasComFinalizacao, 
			CasoFechadoTO casoFechadoTOtotal, Integer divisaoRelatorio, String equipe) {
		
		for (CasoFechadoTO casoFechadoTO : casoFechadoTOList) {
            switch (divisaoRelatorio) {
                case 1:
                    Calendar calendar = new GregorianCalendar();
                    calendar.setTime(relatorioCasosFechados.getDataFim());
                    if (casoFechadoTO.getHoraInicio().equals(calendar.get(Calendar.HOUR_OF_DAY))) {
                        insereAdicionaCasoFechado(relatorioCasosFechados, casoFechadoTO, nomesFilasComFinalizacao);
                        addTotal(relatorioCasosFechados, casoFechadoTOtotal, nomesFilasComFinalizacao);
                    }
                    break;
                case 2:
                    if (casoFechadoTO.getRangeHora().equals(relatorioCasosFechados.getEquipeNome())) {
                        insereAdicionaCasoFechado(relatorioCasosFechados, casoFechadoTO, nomesFilasComFinalizacao);
                        addTotal(relatorioCasosFechados, casoFechadoTOtotal, nomesFilasComFinalizacao);
                    }
                    break;
                case 3:
                    if (casoFechadoTO.getRangeHora().equals(relatorioCasosFechados.getAtendente())) {
                        insereAdicionaCasoFechado(relatorioCasosFechados, casoFechadoTO, nomesFilasComFinalizacao);
                        addTotal(relatorioCasosFechados, casoFechadoTOtotal, nomesFilasComFinalizacao);
                    }
                    break;
                    }
            }
	}
		

	private void addTotal(RelatorioCasosFechados relatorioCasosFechados, CasoFechadoTO casoFechadoTOtotal, Map<String, String> nomesFilasComFinalizacao) {
		insereAdicionaCasoFechado(relatorioCasosFechados, casoFechadoTOtotal, nomesFilasComFinalizacao);
	}

	private void insereAdicionaCasoFechado(RelatorioCasosFechados relatorioCasosFechados, CasoFechadoTO casoFechadoTO, Map<String, String> nomesFilasComFinalizacao) {
		DetalheCasoFechadoTO encontrouDetalhe = null;
		for(DetalheCasoFechadoTO detalheCasoFechadoTOitem : casoFechadoTO.getCasosFechadosPorTipo()) {
			if (detalheCasoFechadoTOitem.getTipoCaso().equals(relatorioCasosFechados.getFilaNome())) {
				encontrouDetalhe = detalheCasoFechadoTOitem;
				break;
			}
		}
		
		if (encontrouDetalhe == null) {
			DetalheCasoFechadoTO deCasoFechadoTO = new DetalheCasoFechadoTO();
			deCasoFechadoTO.setTipoCaso(relatorioCasosFechados.getFilaNome());
			if (relatorioCasosFechados.getFlagDentroPrazo()) {
				deCasoFechadoTO.addFechadoDentroPrazo();
			} else {
				deCasoFechadoTO.addFechadoForaPrazo();
			}
			casoFechadoTO.getCasosFechadosPorTipo().add(deCasoFechadoTO);
			nomesFilasComFinalizacao.put(relatorioCasosFechados.getFilaNome(), relatorioCasosFechados.getFilaNome());
		} else {
			if (relatorioCasosFechados.getFlagDentroPrazo()) {
				encontrouDetalhe.addFechadoDentroPrazo();
			} else {
				encontrouDetalhe.addFechadoForaPrazo();
			}
		}
	}

	private void iniciaCasoFechado(List<CasoFechadoTO> casoFechadoTOList, int horaInicio, int horaFim, List<RelatorioCasosFechados> casosFechados, 
			Integer divisaoRelatorio, String equipe, CasoFechadoTO casoFechadoTOtotal) throws ServiceException {

        switch (divisaoRelatorio) {
            case 1:
                while (horaInicio < horaFim) {
                    CasoFechadoTO casoFechadoTO = new CasoFechadoTO();
                    casoFechadoTO.setRangeHora(horaInicio +" - "+(horaInicio+1));
                    casoFechadoTO.setHoraInicio(horaInicio);
                    casoFechadoTO.setHoraFim(horaInicio+1);
                    horaInicio++;

                    casoFechadoTOList.add(casoFechadoTO);

                }
                break;
            case 2:
            	List<Equipe> equipeList = equipeService.findAtivos("Equipe.NOME");
            	
                for (Equipe eqp : equipeList) {
                    CasoFechadoTO casoFechadoTOitem = new CasoFechadoTO();
                    casoFechadoTOitem.setRangeHora(eqp.getNome());
                    horaInicio++;

                    casoFechadoTOList.add(casoFechadoTOitem);
                }
                break;
            case 3:
            	List<Atendente> atendentes = new ArrayList<Atendente>();
            	Equipe equipeFind = new Equipe();
        		equipeFind.setNome(equipe);
        		try {
        			List<Equipe> equipes = equipeService.findByExample(equipeFind);
            		if (equipes != null && !equipes.isEmpty()) {
            			atendentes = atendenteService.buscaAtendentesPorEquipe(equipes.get(0));
            		}
            	} catch (Exception e) {
					throw new ServiceException("Erro ao buscar os casos fechados por atendente.",e);
				}
                
                
                
                for (Atendente atd : atendentes) {
                	if (atd.getFlagAtivo() != null && atd.getFlagAtivo()) {
	                    CasoFechadoTO casoFechadoTOitem = new CasoFechadoTO();
	                    casoFechadoTOitem.setRangeHora(atd.getLogin());
	                    casoFechadoTOList.add(casoFechadoTOitem);
                	}
                }
                
                break;
        }
        insereTodasFilasComFinalizacaoPorRangeHora(casoFechadoTOList, casosFechados, casoFechadoTOtotal);
	}

}
