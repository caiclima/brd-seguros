package br.com.callink.cad.service.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;
import br.com.callink.cad.dao.IRelatorioTempoGeralDAO;
import br.com.callink.cad.pojo.AtendenteStatus;
import br.com.callink.cad.pojo.RelatorioTempoGeral;
import br.com.callink.cad.repository.to.RelatorioDadosTempoGeralTO;
import br.com.callink.cad.repository.to.RelatorioDadosTempoGeralTOTela;
import br.com.callink.cad.repository.to.RelatorioDinamicoTempoGeralTO;
import br.com.callink.cad.service.IAtendenteStatusService;
import br.com.callink.cad.service.IRelatorioTempoGeralService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.util.Data;
import br.com.callink.cad.util.DateUtils;
import br.com.callink.cad.util.NumberUtils;

@Stateless
public class RelatorioTempoGeralService extends GenericGboService<RelatorioTempoGeral, IRelatorioTempoGeralDAO> implements IRelatorioTempoGeralService {
	
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = Logger.getLogger(RelatorioTempoGeralService.class.getName());
        
    @Inject
    private IRelatorioTempoGeralDAO relatorioTempoGeralDAO;
    
    @EJB
    private IAtendenteStatusService atendenteStatusService;
    
    @Override
	protected IRelatorioTempoGeralDAO getDAO() {
		return relatorioTempoGeralDAO;
	}
	

	@Override
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void geraTempoGeralDia() throws ServiceException {
		try {
			Date dataInicio = getDAO().findUltimaHoraRelatorioTempoGeral();

			// Se for a primeira geração do relatório (dataInicio == null) gerar apenas do dia anterior (quantDias = 1)
			Long dados = dataInicio == null ? 1 : new Long(Data.diferencaEmDias(new Date(), dataInicio));
			
			int quantDias = dados.intValue();
			
			for(int i = quantDias; i > 0 ; i--) {
				
				Date dataAtual = null;
				if(dataAtual == null) {
					Calendar calFinal = Calendar.getInstance();
					calFinal.setTime(new Date());
					calFinal.set(Calendar.HOUR_OF_DAY, 00);
					calFinal.set(Calendar.MINUTE, 00);
					calFinal.set(Calendar.SECOND, 00);
					calFinal.set(Calendar.MILLISECOND, 000);
					
					calFinal.add(Calendar.DAY_OF_MONTH, -i);
					
					dataAtual = calFinal.getTime();
				}
				
				getDAO().geraRelatorioTempoGeral(dataAtual);
				
			}
			
		} catch (Exception e) {
			throw new ServiceException("Erro ao buscar casos fechados no dia",e);
		}
	}	
	
	@Override
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void limpaDiaAtual(Date dataAtual) throws ServiceException {
		try {
			getDAO().limpaDiaAtual(dataAtual);
		} catch (Exception e) {
			throw new ServiceException("Erro ao limpar os dados",e);
		}
	}
	
	public Date findUltimaHoraRelatorioTempoGeral() throws ServiceException {
		
		try {
			return getDAO().findUltimaHoraRelatorioTempoGeral();
		} catch (Exception e) {
			throw new ServiceException("Erro ao buscar ultima data", e);
		}
		
	}
	
	private List<RelatorioTempoGeral> findListRelatorioTempoGeral(int mes, int ano, int idEquipe) throws ServiceException {
		try {
			return getDAO().findListRelatorioTempoGeral(mes, ano, idEquipe);
		} catch (Exception e) {
			throw new ServiceException("Erro ao buscar findListRelatorioTempoGeral", e);
		}
	}
	
	public List<RelatorioDadosTempoGeralTOTela> findDadosRelatorioTempoGeral(int mes, int ano, int idEquipe) throws ServiceException {
		try {
			Map<Integer, RelatorioDadosTempoGeralTO> mapDiaListDadosTempoGeralTOs = new HashMap<Integer, RelatorioDadosTempoGeralTO>();
			
			List<AtendenteStatus> listAtendenteStatus = atendenteStatusService.findAll();
			List<RelatorioTempoGeral> listRelatorioTempoGerals = findListRelatorioTempoGeral(mes, ano, idEquipe);
			
			for(RelatorioTempoGeral relatorioTempoGeral : listRelatorioTempoGerals) {
				
				RelatorioDadosTempoGeralTO relatorioDadosTempoGeralTO = null;
				
				int dia = 0;
				if(relatorioTempoGeral.getData() != null) {
					Calendar calendar = Calendar.getInstance();
					calendar.setTime(relatorioTempoGeral.getData());
					dia = calendar.get(Calendar.DAY_OF_MONTH);
				}
				
				boolean containsDados = mapDiaListDadosTempoGeralTOs.containsKey(dia);
				if(containsDados) {
					relatorioDadosTempoGeralTO = mapDiaListDadosTempoGeralTOs.get(dia);
				} else {
					relatorioDadosTempoGeralTO = new RelatorioDadosTempoGeralTO();
				}
				
				RelatorioDinamicoTempoGeralTO relatorioDinamicoTempoGeralTO = new RelatorioDinamicoTempoGeralTO();
				relatorioDinamicoTempoGeralTO.setIdStatus(relatorioTempoGeral.getIdStatus());
				relatorioDinamicoTempoGeralTO.setStatus(relatorioTempoGeral.getStatus());
				relatorioDinamicoTempoGeralTO.setTempo(relatorioTempoGeral.getTempo());
				
				if(relatorioDadosTempoGeralTO.getListDinamicoTempoGeralTOs() != null) {
					
					relatorioDadosTempoGeralTO.getListDinamicoTempoGeralTOs().add(relatorioDinamicoTempoGeralTO);
				} else {
					
					List<RelatorioDinamicoTempoGeralTO> listRelatorioDinamicoTempoGeralTO = new ArrayList<RelatorioDinamicoTempoGeralTO>();
					listRelatorioDinamicoTempoGeralTO.add(relatorioDinamicoTempoGeralTO);
					relatorioDadosTempoGeralTO.setListDinamicoTempoGeralTOs(listRelatorioDinamicoTempoGeralTO);
				}
				
				relatorioDadosTempoGeralTO.setData(relatorioTempoGeral.getData());
				relatorioDadosTempoGeralTO.setDiaData(dia);
				relatorioDadosTempoGeralTO.setPorcentTempoPausaDia(relatorioTempoGeral.getPorcentTempoPausaDia());
				relatorioDadosTempoGeralTO.setPorcentTempoOciosoDia(relatorioTempoGeral.getPorcentTempoOciosoDia());
				relatorioDadosTempoGeralTO.setPorcentTempoProdutivoDia(relatorioTempoGeral.getPorcentTempoProdutivoDia());
				relatorioDadosTempoGeralTO.setQtdAgenteLogadoDia(relatorioTempoGeral.getQtdAgenteLogadoDia());
				relatorioDadosTempoGeralTO.setTempoLogadoDia(relatorioTempoGeral.getTempoLogadoDia());
				relatorioDadosTempoGeralTO.setTempoPausaDia(relatorioTempoGeral.getTempoPausaDia());
				relatorioDadosTempoGeralTO.setTempoOciosoDia(relatorioTempoGeral.getTempoOciosoDia());
				relatorioDadosTempoGeralTO.setTempoProdutivoDia(relatorioTempoGeral.getTempoProdutivoDia());
				
				
				if(!containsDados) {
					mapDiaListDadosTempoGeralTOs.put(dia, relatorioDadosTempoGeralTO);
				}
				
			}
			
			List<RelatorioDadosTempoGeralTOTela> list = montaCamposRelatorioTempoGerais(mapDiaListDadosTempoGeralTOs, listAtendenteStatus);
			return list; 
		} catch (Exception e) {
			throw new ServiceException("Erro ao buscar findListRelatorioTempoGeral", e);
		}
	}


	private List<RelatorioDadosTempoGeralTOTela> montaCamposRelatorioTempoGerais(
			Map<Integer, RelatorioDadosTempoGeralTO> mapDiaListDadosTempoGeralTOs,
			List<AtendenteStatus> listAtendenteStatus) {
		int contPosicao = 0;
		Map<String, RelatorioDadosTempoGeralTOTela> mapRelatorioDadosTempoGeralTODois = new HashMap<String, RelatorioDadosTempoGeralTOTela>();
		mapRelatorioDadosTempoGeralTODois.put("Qtde de agentes logados", new RelatorioDadosTempoGeralTOTela("Qtde de agentes logados", "0", contPosicao++));
		mapRelatorioDadosTempoGeralTODois.put("Tempo em Logado", new RelatorioDadosTempoGeralTOTela("Tempo em Logado", "00:00", contPosicao++));
		
		for(AtendenteStatus atendenteStatus : listAtendenteStatus) {
			mapRelatorioDadosTempoGeralTODois.put(atendenteStatus.getNomeStatus(), new RelatorioDadosTempoGeralTOTela(atendenteStatus.getNomeStatus().toLowerCase(), "00:00", contPosicao++));
		}
		
		mapRelatorioDadosTempoGeralTODois.put("Tempo Produtivo", new RelatorioDadosTempoGeralTOTela("Tempo Produtivo", "00:00", contPosicao++));
		mapRelatorioDadosTempoGeralTODois.put("%Tempo Produtivo", new RelatorioDadosTempoGeralTOTela("%Tempo Produtivo", "0%", contPosicao++));
		mapRelatorioDadosTempoGeralTODois.put("Tempo em Pausa", new RelatorioDadosTempoGeralTOTela("Tempo em Pausa", "00:00", contPosicao++));
		mapRelatorioDadosTempoGeralTODois.put("% Tempo em Pausa", new RelatorioDadosTempoGeralTOTela("% Tempo em Pausa", "0%", contPosicao++));
		mapRelatorioDadosTempoGeralTODois.put("Tempo Ocioso", new RelatorioDadosTempoGeralTOTela("Tempo Ocioso", "00:00", contPosicao++));
		mapRelatorioDadosTempoGeralTODois.put("% Tempo Ocioso", new RelatorioDadosTempoGeralTOTela("% Tempo Ocioso", "0%", contPosicao++));
		
		for(int dia = 1; dia <= 31; dia++) {
			
			RelatorioDadosTempoGeralTO relatorioDadosTempoGeralTO = mapDiaListDadosTempoGeralTOs.get(dia);
			if(relatorioDadosTempoGeralTO != null) {
				
				if(relatorioDadosTempoGeralTO != null) {
					setMapDadosDia(dia, relatorioDadosTempoGeralTO.getQtdAgenteLogadoDia()+"", mapRelatorioDadosTempoGeralTODois.get("Qtde de agentes logados"));
					somaTotal(dia, relatorioDadosTempoGeralTO.getQtdAgenteLogadoDia(), 0.0, mapRelatorioDadosTempoGeralTODois.get("Qtde de agentes logados"), false);
					
					setMapDadosDia(dia, DateUtils.formataTempo(relatorioDadosTempoGeralTO.getTempoLogadoDia()), mapRelatorioDadosTempoGeralTODois.get("Tempo em Logado"));
					somaTotal(dia, relatorioDadosTempoGeralTO.getTempoLogadoDia(), 0.0, mapRelatorioDadosTempoGeralTODois.get("Tempo em Logado"), true);
					
					setMapDadosDia(dia, DateUtils.formataTempo(relatorioDadosTempoGeralTO.getTempoProdutivoDia()), mapRelatorioDadosTempoGeralTODois.get("Tempo Produtivo"));
					somaTotal(dia, relatorioDadosTempoGeralTO.getTempoProdutivoDia(), 0.0, mapRelatorioDadosTempoGeralTODois.get("Tempo Produtivo"), true);
					
					setMapDadosDia(dia, NumberUtils.formataPorcentagem(relatorioDadosTempoGeralTO.getPorcentTempoProdutivoDia()), mapRelatorioDadosTempoGeralTODois.get("%Tempo Produtivo"));
					somaTotal(dia, 0l, relatorioDadosTempoGeralTO.getPorcentTempoProdutivoDia(), mapRelatorioDadosTempoGeralTODois.get("%Tempo Produtivo"), true);
					
					setMapDadosDia(dia, DateUtils.formataTempo(relatorioDadosTempoGeralTO.getTempoPausaDia()), mapRelatorioDadosTempoGeralTODois.get("Tempo em Pausa"));
					somaTotal(dia, relatorioDadosTempoGeralTO.getTempoPausaDia(), 0.0, mapRelatorioDadosTempoGeralTODois.get("Tempo em Pausa"), true);
					
					setMapDadosDia(dia, NumberUtils.formataPorcentagem(relatorioDadosTempoGeralTO.getPorcentTempoPausaDia()), mapRelatorioDadosTempoGeralTODois.get("% Tempo em Pausa"));
					somaTotal(dia, 0l, relatorioDadosTempoGeralTO.getPorcentTempoPausaDia(), mapRelatorioDadosTempoGeralTODois.get("% Tempo em Pausa"), true);
					
					setMapDadosDia(dia, DateUtils.formataTempo(relatorioDadosTempoGeralTO.getTempoOciosoDia()), mapRelatorioDadosTempoGeralTODois.get("Tempo Ocioso"));
					somaTotal(dia, relatorioDadosTempoGeralTO.getTempoOciosoDia(), 0.0, mapRelatorioDadosTempoGeralTODois.get("Tempo Ocioso"), true);
					
					setMapDadosDia(dia, NumberUtils.formataPorcentagem(relatorioDadosTempoGeralTO.getPorcentTempoOciosoDia()), mapRelatorioDadosTempoGeralTODois.get("% Tempo Ocioso"));
					somaTotal(dia, 0l, relatorioDadosTempoGeralTO.getPorcentTempoOciosoDia(), mapRelatorioDadosTempoGeralTODois.get("% Tempo Ocioso"), true);
					
					for(RelatorioDinamicoTempoGeralTO relatorioDinamicoTempoGeralTO : relatorioDadosTempoGeralTO.getListDinamicoTempoGeralTOs()) {
						
						RelatorioDadosTempoGeralTOTela relatorioDadosTempoGeralTODois = mapRelatorioDadosTempoGeralTODois.get(relatorioDinamicoTempoGeralTO.getStatus());
						
						if(relatorioDadosTempoGeralTODois != null) {
							
							setMapDadosDia(dia, DateUtils.formataTempo(relatorioDinamicoTempoGeralTO.getTempo()), relatorioDadosTempoGeralTODois);
							somaTotal(dia, relatorioDinamicoTempoGeralTO.getTempo(), 0.0, relatorioDadosTempoGeralTODois, true);
						}
					}
				}
			} 
		}
		
		calculaPorcentagemTotal(mapRelatorioDadosTempoGeralTODois);
		
		List<RelatorioDadosTempoGeralTOTela> list = new ArrayList<RelatorioDadosTempoGeralTOTela>(mapRelatorioDadosTempoGeralTODois.values());
		Collections.sort(list);
		return list;
	}


	private void somaTotal(int dia, long dados, 
			double dadosDouble, 
			RelatorioDadosTempoGeralTOTela relatorioDadosTempoGeralTOTela,
			boolean formatText) {
		
		if(dados != 0l) {
			
			long valorTotal = relatorioDadosTempoGeralTOTela.getValorTotalSomaLong() + dados;
			relatorioDadosTempoGeralTOTela.setValorTotalSomaLong(valorTotal);
			relatorioDadosTempoGeralTOTela.setValorTotal(formatText ? DateUtils.formataTempo(valorTotal) : valorTotal+"");
			
		} else if(dadosDouble != 0.0) {
			
			double valorTotal = relatorioDadosTempoGeralTOTela.getValorTotalSomaDouble() + dadosDouble;
			relatorioDadosTempoGeralTOTela.setValorTotalSomaDouble(valorTotal);
			relatorioDadosTempoGeralTOTela.setValorTotal(formatText ? NumberUtils.formataPorcentagem(valorTotal) : valorTotal+"");
			
		}
	}
	
	private void calculaPorcentagemTotal(Map<String, RelatorioDadosTempoGeralTOTela> mapRelatorioDadosTempoGeralTODois) {
		
		double tempoLogado = mapRelatorioDadosTempoGeralTODois.get("Tempo em Logado").getValorTotalSomaLong();
		
		RelatorioDadosTempoGeralTOTela relatorioDadosTempoGeralTOPorcentagemTempoProdutivo = mapRelatorioDadosTempoGeralTODois.get("%Tempo Produtivo");
		double tempoProdutivo = mapRelatorioDadosTempoGeralTODois.get("Tempo Produtivo").getValorTotalSomaLong();
		
		relatorioDadosTempoGeralTOPorcentagemTempoProdutivo.setValorTotalSomaDouble((tempoProdutivo / tempoLogado) * 100);
		relatorioDadosTempoGeralTOPorcentagemTempoProdutivo.setValorTotal(NumberUtils.formataPorcentagem(relatorioDadosTempoGeralTOPorcentagemTempoProdutivo.getValorTotalSomaDouble()));
		
		
		RelatorioDadosTempoGeralTOTela relatorioDadosTempoGeralTOPorcentagemTempoPausa = mapRelatorioDadosTempoGeralTODois.get("% Tempo em Pausa");
		double tempoPausa = mapRelatorioDadosTempoGeralTODois.get("Tempo em Pausa").getValorTotalSomaLong();
		
		relatorioDadosTempoGeralTOPorcentagemTempoPausa.setValorTotalSomaDouble((tempoPausa / tempoLogado) * 100);
		relatorioDadosTempoGeralTOPorcentagemTempoPausa.setValorTotal(NumberUtils.formataPorcentagem(relatorioDadosTempoGeralTOPorcentagemTempoPausa.getValorTotalSomaDouble()));
		
		
		RelatorioDadosTempoGeralTOTela relatorioDadosTempoGeralTOPorcentagemTempoOcioso = mapRelatorioDadosTempoGeralTODois.get("% Tempo Ocioso");
		double tempoOcioso = mapRelatorioDadosTempoGeralTODois.get("Tempo Ocioso").getValorTotalSomaLong();
		
		relatorioDadosTempoGeralTOPorcentagemTempoOcioso.setValorTotalSomaDouble((tempoOcioso / tempoLogado) * 100);
		relatorioDadosTempoGeralTOPorcentagemTempoOcioso.setValorTotal(NumberUtils.formataPorcentagem(relatorioDadosTempoGeralTOPorcentagemTempoOcioso.getValorTotalSomaDouble()));
	}
	
	private void setMapDadosDia(int dia, String dados,
			RelatorioDadosTempoGeralTOTela relatorioDadosTempoGeralTOTela) {
		
		if(dia == 1)
			relatorioDadosTempoGeralTOTela.setValor1(dados);
		else if(dia == 1)
			relatorioDadosTempoGeralTOTela.setValor1(dados);
		else if(dia == 2)
			relatorioDadosTempoGeralTOTela.setValor2(dados);
		else if(dia == 3)
			relatorioDadosTempoGeralTOTela.setValor3(dados);
		else if(dia == 4)
			relatorioDadosTempoGeralTOTela.setValor4(dados);
		else if(dia == 5)
			relatorioDadosTempoGeralTOTela.setValor5(dados);
		else if(dia == 6)
			relatorioDadosTempoGeralTOTela.setValor6(dados);
		else if(dia == 7)
			relatorioDadosTempoGeralTOTela.setValor7(dados);
		else if(dia == 8)
			relatorioDadosTempoGeralTOTela.setValor8(dados);
		else if(dia == 9)
			relatorioDadosTempoGeralTOTela.setValor9(dados);
		else if(dia == 10)
			relatorioDadosTempoGeralTOTela.setValor10(dados);
		else if(dia == 11)
			relatorioDadosTempoGeralTOTela.setValor11(dados);
		else if(dia == 12)
			relatorioDadosTempoGeralTOTela.setValor12(dados);
		else if(dia == 13)
			relatorioDadosTempoGeralTOTela.setValor13(dados);
		else if(dia == 14)
			relatorioDadosTempoGeralTOTela.setValor14(dados);
		else if(dia == 15)
			relatorioDadosTempoGeralTOTela.setValor15(dados);
		else if(dia == 16)
			relatorioDadosTempoGeralTOTela.setValor16(dados);
		else if(dia == 17)
			relatorioDadosTempoGeralTOTela.setValor17(dados);
		else if(dia == 18)
			relatorioDadosTempoGeralTOTela.setValor18(dados);
		else if(dia == 19)
			relatorioDadosTempoGeralTOTela.setValor19(dados);
		else if(dia == 20)
			relatorioDadosTempoGeralTOTela.setValor20(dados);
		else if(dia == 21)
			relatorioDadosTempoGeralTOTela.setValor21(dados);
		else if(dia == 22)
			relatorioDadosTempoGeralTOTela.setValor22(dados);
		else if(dia == 23)
			relatorioDadosTempoGeralTOTela.setValor23(dados);
		else if(dia == 24)
			relatorioDadosTempoGeralTOTela.setValor24(dados);
		else if(dia == 25)
			relatorioDadosTempoGeralTOTela.setValor25(dados);
		else if(dia == 26)
			relatorioDadosTempoGeralTOTela.setValor26(dados);
		else if(dia == 27)
			relatorioDadosTempoGeralTOTela.setValor27(dados);
		else if(dia == 28)
			relatorioDadosTempoGeralTOTela.setValor28(dados);
		else if(dia == 29)
			relatorioDadosTempoGeralTOTela.setValor29(dados);
		else if(dia == 30)
			relatorioDadosTempoGeralTOTela.setValor30(dados);
		else if(dia == 31)
			relatorioDadosTempoGeralTOTela.setValor31(dados);
	}
	
	
}
