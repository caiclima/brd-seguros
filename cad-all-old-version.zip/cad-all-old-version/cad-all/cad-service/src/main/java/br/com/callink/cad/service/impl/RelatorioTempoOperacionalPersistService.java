package br.com.callink.cad.service.impl;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.inject.Inject;

import br.com.callink.cad.dao.IRelatorioTempoOperacionalDAO;
import br.com.callink.cad.pojo.RelatorioTempoOperacional;
import br.com.callink.cad.service.IRelatorioTempoOperacionalPersistService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

@Stateless
@Local(IRelatorioTempoOperacionalPersistService.class)
public class RelatorioTempoOperacionalPersistService extends GenericGboService<RelatorioTempoOperacional, IRelatorioTempoOperacionalDAO> implements IRelatorioTempoOperacionalPersistService {

    private static final long serialVersionUID = 5794476028670209602L;
    
    private Logger logger = Logger.getLogger(RelatorioTempoOperacionalPersistService.class.getName());
    
    @Inject
    private IRelatorioTempoOperacionalDAO relatorioTempoOperacionalDAO;
    
    @Override
	protected IRelatorioTempoOperacionalDAO getDAO() {
		return relatorioTempoOperacionalDAO;
	}
    
    public void deleteAll() throws ServiceException, ValidationException {
    	try {
    		getDAO().limpaRelatorioAnterior();
    	} catch (Exception e) {
    		logger.log(Level.SEVERE, "Erro ao limpar tabela de historico dos casos.", e);
		}
    }
        
    public void persistDadosRelatorio(List<RelatorioTempoOperacional> relatorioList) throws ServiceException, ValidationException {
    	
    	for(RelatorioTempoOperacional registro : relatorioList) {
	    	try {
        	    getDAO().save(registro);
	    	} catch (Exception e) {
	    		logger.log(Level.SEVERE, "Erro ao limpar tabela de historico dos casos.", e);
			}
    	}
    }
}
