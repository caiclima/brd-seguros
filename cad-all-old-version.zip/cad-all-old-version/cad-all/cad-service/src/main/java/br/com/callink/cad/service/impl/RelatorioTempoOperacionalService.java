/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.logging.Logger;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import br.com.callink.cad.dao.IRelatorioTempoOperacionalDAO;
import br.com.callink.cad.pojo.LogTask;
import br.com.callink.cad.pojo.ParametroGBO;
import br.com.callink.cad.pojo.RelatorioTempoOperacional;
import br.com.callink.cad.pojo.StatusAtendente;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.service.ILogTaskService;
import br.com.callink.cad.service.IParametroGBOService;
import br.com.callink.cad.service.IRelatorioTempoOperacionalPersistService;
import br.com.callink.cad.service.IRelatorioTempoOperacionalService;
import br.com.callink.cad.service.IStatusAtendenteService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.util.Constantes;

/**
 *
 * @author brunomt
 */
@Stateless
public class RelatorioTempoOperacionalService extends GenericGboService<RelatorioTempoOperacional, IRelatorioTempoOperacionalDAO> implements IRelatorioTempoOperacionalService {

	
	private static final long serialVersionUID = -3001174726589738829L;
	private Logger logger = Logger.getLogger(RelatorioTempoOperacionalService.class.getName());
	@Inject
	private IRelatorioTempoOperacionalDAO relatorioTempoOperacionalDAO;
	
	@EJB
	private IParametroGBOService parametroGBOService;
	
	@EJB
	private IStatusAtendenteService statusAtendenteService;
	
	@EJB
	private ILogTaskService logTaskService;
	
	@EJB
	private IRelatorioTempoOperacionalPersistService relatorioTempoOperacionalPersistService;
	
	@Override
	protected IRelatorioTempoOperacionalDAO getDAO() {
		return relatorioTempoOperacionalDAO;
	}
	
    @Override
    public List<RelatorioTempoOperacional> retornaLoginsUsuariosSSO(Date data1, Date data2) throws ServiceException, ValidationException {
        try {
            ParametroGBO parametroGBO = parametroGBOService.findByParam(Constantes.ID_SUPERVISOR);
            
            if (parametroGBO == null || parametroGBO.getValor() == null) {
                throw  new ValidationException("Erro ao buscar parametro '" + Constantes.ID_SUPERVISOR
                		+ "' para retornar LoginUsuarioSSO");
            }
            
            ParametroGBO paramLinkedServerName = parametroGBOService.findByParam(Constantes.LINKED_SERVER_NAME);
            
            String linkedServerName = paramLinkedServerName != null ? paramLinkedServerName.getValor() : null;
            
           	return getDAO().retornaLoginsUsuariosSSO(data1, data2, Integer.valueOf(parametroGBO.getValor()), linkedServerName);

        } catch (DataException ex) {
            throw new ServiceException("Erro ao buscar os logins dos usuários.",ex);
        }
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
    public void geraRelatorioTempoOperacionalOntem() throws ServiceException, ValidationException {
        Calendar cal = new GregorianCalendar();
        cal.setTime(getDataBanco());
        cal.add(Calendar.DAY_OF_MONTH, -1);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 1);
        
        Calendar calFim = new GregorianCalendar();
        calFim.setTime(getDataBanco());
        calFim.add(Calendar.DAY_OF_MONTH, -1);
        calFim.set(Calendar.HOUR_OF_DAY, 23);
        calFim.set(Calendar.MINUTE, 59);
        calFim.set(Calendar.SECOND, 59);
        
        
        geraRelatorioTempoOperacionalDatas(cal.getTime(), calFim.getTime());
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
    public void geraRelatorioTempoOperacionalDatas(Date dataInicio, Date dataFim) throws ServiceException,ValidationException {
		ParametroGBO parametroGBO = null;
    	
		LogTask logTask = new LogTask();
    	logTask.setDataInicial(getDataBanco());
    	logTask.setMnmExecutor(Constantes.PARAM_SEMAFORO_TEMPO_OPERACIONAL);
		
        try {
			parametroGBO = parametroGBOService.findByParam(Constantes.PARAM_SEMAFORO_TEMPO_OPERACIONAL);
			
			if (parametroGBO == null || parametroGBO.getIdParametroGBO() == null) {
				throw new ValidationException("Nao foi possivel identificar o parametro GBO ULTIMA_TRATATIVA. Favor cadastrar o mesmo.");
			}
			
			parametroGBO.setValor(Constantes.FALSE);
			parametroGBOService.saveOrUpdate(parametroGBO);
			
			relatorioTempoOperacionalPersistService.deleteAll();
			
			atualizaDataUltimoRelatorio();
			
            List<StatusAtendente> statusAtendenteList = statusAtendenteService.buscaTodosStatusAtendenteEntreDatas(dataInicio, dataFim);

            List<RelatorioTempoOperacional> relatorioTempoOperacionalList = retornaLoginsUsuariosSSO(dataInicio, dataFim);
        
            if (statusAtendenteList != null) {
                if (relatorioTempoOperacionalList == null) {
                    relatorioTempoOperacionalList = new ArrayList<>();
                }
                for (StatusAtendente statusAtendente : statusAtendenteList) {
                    RelatorioTempoOperacional relatorioTempoOperacional = new RelatorioTempoOperacional();
                    relatorioTempoOperacional.setDataFim(statusAtendente.getDataFim());
                    relatorioTempoOperacional.setDataInicio(statusAtendente.getDataInicio());
                    if (statusAtendente.getIdAtendente() != null) {
                    	relatorioTempoOperacional.setLogin(statusAtendente.getIdAtendente().getLogin());
                    	relatorioTempoOperacional.setNomeAtendente(statusAtendente.getIdAtendente().getNome());
                    	relatorioTempoOperacional.setStatusAtendente(statusAtendente.getIdAtendenteStatus().getNomeStatus());
                        relatorioTempoOperacional.setIdEquipe(statusAtendente.getIdEquipe().getIdEquipe());
                    }
                    
                    relatorioTempoOperacionalList.add(relatorioTempoOperacional);
                }
            }
            if (relatorioTempoOperacionalList != null) {
            	logTask.setTotalRegistros(relatorioTempoOperacionalList.size());
            	
            	int contPersistDadosRelatorio = 1;
            	List<RelatorioTempoOperacional> relatorioListPersist = new ArrayList<RelatorioTempoOperacional>();
            	
	            for (RelatorioTempoOperacional relatorioTempoOperacional : relatorioTempoOperacionalList) {
	            	relatorioListPersist.add(relatorioTempoOperacional);
	            	if(contPersistDadosRelatorio >= 250) {
	            		relatorioTempoOperacionalPersistService.persistDadosRelatorio(relatorioListPersist);
	            		
	            		contPersistDadosRelatorio = 1;
	            		relatorioListPersist = new ArrayList<RelatorioTempoOperacional>();
	            	} else {
	            		contPersistDadosRelatorio ++;
	            	}
	            }
	            
	            if(relatorioListPersist != null && !relatorioListPersist.isEmpty() ) {
	            	relatorioTempoOperacionalPersistService.persistDadosRelatorio(relatorioListPersist);
	            }
	            
            } else {
            	logTask.setTotalRegistros(Integer.valueOf(0));
            }
            
            logTask.setDataFinal(getDataBanco());
            logTaskService.save(logTask);
            
			parametroGBO.setValor(Constantes.TRUE);
			parametroGBOService.saveOrUpdate(parametroGBO);
            
        } catch (ServiceException ex) {
            throw new ServiceException("Erro ao gerar o Relatorio Tempo Operacional.",ex);
        }
    }

    private ParametroGBO getParametroGBOUltimaExecucao() throws ServiceException {
        try {
            return parametroGBOService.findByParam("executouRelatorioTempoOperacional");
        } catch (ServiceException e) {
            throw new ServiceException("Erro ao buscar data da ultima execucao do relatorio Qlikview", e);
        }
    }

    @Override
    public Date getDataUltimoRelatorio() throws ServiceException {
        return getParametroGBOUltimaExecucao().getDataAlteracao();
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
    public void geraRelatorioParametroTempoOperacional() throws ServiceException, ValidationException {
    	logger.info("RelatorioTempoOperacionalService - INICIO relatorio QlikView");
    	Date dataUltimo = getDataUltimoRelatorio();
    	
    	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    	
    	try {
    		if (!dateFormat.parse(dateFormat.format(dataUltimo))
    				.before(dateFormat.parse(dateFormat.format(getDataBanco())))) {
    			dataUltimo = dateFormat.parse(dateFormat.format(getDataBanco()));
    		}
        } catch (ParseException ex) {
        	throw new ServiceException("Erro ao fazer parse da data ", ex);
        }
    	
        geraRelatorioTempoOperacionalDatas(dataUltimo, getDataBanco());
        logger.info("RelatorioTempoOperacionalService - FIM relatorio QlikView");
    }
    
    private void atualizaDataUltimoRelatorio() throws ServiceException, ValidationException {
        ParametroGBO ultimaExecucao = getParametroGBOUltimaExecucao();
        ultimaExecucao.setValor("OK");
        parametroGBOService.saveOrUpdate(ultimaExecucao);
    }

}
