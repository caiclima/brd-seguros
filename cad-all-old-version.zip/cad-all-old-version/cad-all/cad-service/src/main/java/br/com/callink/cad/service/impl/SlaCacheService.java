package br.com.callink.cad.service.impl;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.Lock;
import javax.ejb.LockType;
import javax.ejb.Schedule;
import javax.ejb.Singleton;
import javax.ejb.Startup;

import br.com.callink.cad.pojo.Feriado;
import br.com.callink.cad.pojo.SlaFila;
import br.com.callink.cad.repository.SlaFilaConfiguracao;
import br.com.callink.cad.service.IFeriadoService;
import br.com.callink.cad.service.IParametroGBOService;
import br.com.callink.cad.service.ISlaCacheService;
import br.com.callink.cad.service.ISlaFilaService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.util.Constantes;

@Startup
@Singleton
@Lock(LockType.READ)
public class SlaCacheService implements ISlaCacheService {

	private Map<String, Feriado> feriadoMap;
	private Boolean domingo;
	private Boolean sabado;
	private Integer tmpOK;
	private Integer tmpAtencao;
	private Integer inicioContagem;
	
	@EJB
	private IParametroGBOService parametroGBOService;
	@EJB
	private IFeriadoService feriadoService;
	@EJB
	private ISlaFilaService slaFilaService;	
	
	@PostConstruct
	@Lock(LockType.WRITE)
	private void init() throws ServiceException {
		
		try {
			DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
			List<SlaFila> listSlaFila = null;
			
			feriadoMap = new HashMap<String, Feriado>();
			
			listSlaFila = slaFilaService.findAll();
			
			//Verifica se não foi encontrado nenhum dado na tabela tb_sla_fila
			if (listSlaFila == null || listSlaFila.size() < 1) {
				throw new ServiceException("Não foi encontrado nenhum sla fila");
			} else {
				for (SlaFila slaFila : listSlaFila) {
					SlaFilaConfiguracao.setSlaFilaCache(slaFila);
				}
			}
			
			try {
				sabado = Boolean.valueOf(parametroGBOService.findByParam(Constantes.CONTA_SABADO).getValor());
				
				sabado = sabado == null ? Boolean.FALSE : sabado;
			} catch (Exception ex) {
				sabado = false;
				new Exception("Erro ao buscar parâmetro 'contasabado' ", ex).printStackTrace();
			}
			try {
				domingo = Boolean.valueOf(parametroGBOService.findByParam(Constantes.CONTA_DOMINGO).getValor());
				
				domingo = domingo == null ? Boolean.FALSE : domingo;
			} catch (Exception ex) {
				domingo = false;
				new Exception("Erro ao buscar parâmetro 'contadomingo' ", ex).printStackTrace();
			}
			try {
				inicioContagem = Integer.valueOf(parametroGBOService.findByParam(Constantes.INICIO_SLA).getValor());
				
				inicioContagem = inicioContagem == null ? Integer.valueOf(1) : inicioContagem;
			} catch (Exception ex) {
				inicioContagem = 1;
				new Exception("Erro ao buscar parâmetro 'iniciosla' ", ex).printStackTrace();
			}
			try {
				tmpOK = Integer.parseInt(parametroGBOService.findByParam(Constantes.TEMPO_OK).getValor());
				
				tmpOK = tmpOK == null ? Integer.valueOf(50) : tmpOK;
			} catch (Exception ex) {
				tmpOK = 50;
				new Exception("Erro ao buscar parâmetro 'tempook' ", ex).printStackTrace();
			}
			try {
				tmpAtencao = Integer.parseInt(parametroGBOService.findByParam(Constantes.TEMPO_ATENCAO).getValor());
				
				tmpAtencao = tmpAtencao == null ? 85 : tmpAtencao;
			} catch (Exception ex) {
				tmpAtencao = 85;
				new Exception("Erro ao buscar parâmetro 'tempoatencao' ", ex).printStackTrace();
			}
			
			for (Feriado dta : feriadoService.findAll()) {
				feriadoMap.put(df.format(dta.getDataFeriado()),dta);
			}

		} catch (ServiceException ex) {
			throw new ServiceException("Erro ao Iniciar Sla.", ex);
		}

	}
	
	@Override
	public Map<String, Feriado> getFeriado() throws ServiceException {
		return feriadoMap;
	}

	@Override
	public Boolean getSabado() throws ServiceException {
		return sabado;
	}

	@Override
	public Boolean getDomingo() throws ServiceException {
		return domingo;
	}

	@Override
	public Integer getTempoOk() throws ServiceException {
		return tmpOK;
	}

	@Override
	public Integer getTempoAtencao() throws ServiceException {
		return tmpAtencao;
	}

	@Override
	public Integer getInicioContagem() throws ServiceException {
		return inicioContagem;
	}

	@Override
	@Schedule(minute = "*/240", hour = "*", info = "Task para atualizar essa cache")
	public void recarrega() throws ServiceException {
		init();		
	}

}
