/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.service.impl;

import java.util.Date;
import java.util.List;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;
import br.com.callink.cad.dao.ISlaFilaDAO;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.pojo.SlaFila;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.service.ISlaFilaService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.util.Constantes;

/**
 *
 * @author swb.miller
 */
@Stateless
public class SlaFilaService extends GenericGboService<SlaFila, ISlaFilaDAO> implements ISlaFilaService {

	private static final long serialVersionUID = -630844222657012564L;

	@Inject
	private ISlaFilaDAO slaFilaDAO;
	
	@Override
	protected ISlaFilaDAO getDAO() {
		return slaFilaDAO;
	}
	
	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<SlaFila> findSlaFilaByConfFila(ConfiguracaoFila conf) throws ServiceException {
        try {
          return getDAO().findSlaFilaByConfFila(conf);
        } catch (DataException e) {
            throw  new ServiceException("Erro ao buscar sla por uma determinada fila", e);
        }
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<SlaFila> findAllSlafila() throws ServiceException {
         try {
          return getDAO().findAllSlafila();
        } catch (DataException e) {
            throw  new ServiceException("Erro ao buscar todas sla. ", e);
        }
    }
    
    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public SlaFila saveLogSlaFila(SlaFila slaFilaAntiga, SlaFila slaFilaNova) throws ServiceException {
        try {
        
            slaFilaAntiga.setDataFinal(new Date(System.currentTimeMillis()));
            getDAO().update(slaFilaAntiga);
            
            slaFilaNova.setDataInicial(new Date(System.currentTimeMillis()));
            slaFilaNova.setDataFinal(null);
            getDAO().save(slaFilaNova);
            
            return slaFilaNova;

        } catch(DataException e) {
            throw new ServiceException("Erro ao salvar log da sla. ", e);
        }
    }
    
    @Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public SlaFila findSlaFilaByConfFilaAndDataFimNull(ConfiguracaoFila configuracaoFila) throws ServiceException, ValidationException {
    	List<SlaFila> listSlaFila = null;
		
		try {
			listSlaFila = getDAO().findSlaFilaByConfFilaAndDataFimNull(configuracaoFila);
		} catch (DataException e) {
			throw new ServiceException("Erro ao buscar sla por configuracao e com data final vazia.", e);
		}
		
		if (listSlaFila == null || listSlaFila.size() < 1) {
			return new SlaFila();
		}
		
		return listSlaFila.get(0);
    }
    
    @Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<SlaFila> findSlaFilaList(ConfiguracaoFila configFila, Integer sla,String descricao) throws ServiceException {
    	List<SlaFila> listSlaFila = null;
		
		try {
			listSlaFila = getDAO().findSlaFilaList(configFila, sla, descricao);
		} catch (DataException ex) {
			throw new ServiceException("Erro ao buscar sla fila por parametros digitados pelo usuario", ex);
		}
		
		return listSlaFila;
    }
    
    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void save(SlaFila slaFila) throws ServiceException {
    	SlaFila slaFilaAtiva = null;

    	try {
    		slaFilaAtiva = findSlaFilaByConfFilaAndDataFimNull(slaFila.getConfiguracaoFila());
    		
    		if (slaFilaAtiva != null && slaFilaAtiva.getIdSlaFila() != null && slaFilaAtiva.getIdSlaFila() > 0) {
    				slaFilaAtiva.setDataFinal(new Date(System.currentTimeMillis()));
    				update(slaFilaAtiva);
    		}
        	
        	super.save(slaFila);
    	} catch (Exception ex) {
    		throw new ServiceException("Erro ao salvar SLA", ex);
    	}
    }

	@Override
	public SlaFila buscaSlaFilaPadraoCasosImportados() throws ServiceException {
		return findByPk(new SlaFila(Constantes.ID_SLA_FILA_PADRAO_DE_CASOS_IMPORTADAS));
	}

}
