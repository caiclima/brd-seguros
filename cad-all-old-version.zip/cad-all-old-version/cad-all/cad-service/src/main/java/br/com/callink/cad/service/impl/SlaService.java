/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.service.impl;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.Stateless;

import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.Feriado;
import br.com.callink.cad.service.IFeriadoService;
import br.com.callink.cad.service.IParametroGBOService;
import br.com.callink.cad.service.ISlaService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.util.Constantes;
import br.com.callink.coreutils.util.date.DateUtils;

/**
 * 
 * @author Rogério Moreira de Andrade. [rogeriom@swb.com.br]
 */
@Stateless
public class SlaService extends AbstractSlaService implements ISlaService {

	private Properties propertiesApp;
	private Map<String, Feriado> feriadoMap;
	private Boolean domingo;
	private Boolean sabado;
	private Long tmpOK;
	private Long tmpAtencao;
	private Integer inicioContagem;

	@EJB
	private IParametroGBOService parametroGBOService;
	
	@EJB
	private IFeriadoService feriadoService;
	
	public SlaService() {
	}

	@PostConstruct
	public void initSlaService() throws ServiceException {
		try {
			DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
			propertiesApp = new Properties();
			propertiesApp.load(SlaService.class.getResourceAsStream("/config/gbo.properties"));

			String tempoSlaOK = parametroGBOService.findByParam(propertiesApp.getProperty("parametro.tempook")).getValor();
			String tempoSlaAtencao = parametroGBOService.findByParam(propertiesApp.getProperty("parametro.tempoatencao")).getValor();

			tmpOK = new Long(tempoSlaOK) * 60;
			tmpAtencao = new Long(tempoSlaAtencao) * 60;

			sabado = Boolean.valueOf(parametroGBOService.findByParam(propertiesApp.getProperty("parametro.contasabado")).getValor());
			domingo = Boolean.valueOf(parametroGBOService.findByParam(propertiesApp.getProperty("parametro.contadomingo")).getValor());

			inicioContagem = Integer.valueOf(parametroGBOService.findByParam(propertiesApp.getProperty("parametro.iniciosla")).getValor());
			feriadoMap = new HashMap<String, Feriado>();

			for (Feriado dta : feriadoService.findAll()) {
				feriadoMap.put(df.format(dta.getDataFeriado()),dta);
			}
		} catch (IOException ex) {
			throw new ServiceException("Arquivo de propriedades n\u00E3o encontrado", ex);
		} catch (ServiceException ex) {
			throw new ServiceException("Erro ao Iniciar Sla.", ex);
		}
	}

	@Override
	public Map<String, Feriado> getFeriados() throws ServiceException {
		return feriadoMap == null ? new HashMap<String, Feriado>() : feriadoMap;
	}
        

    @Override
    public Date inicioContagem(Date dataInicio) throws ServiceException {
        if (inicioContagem > 0) {
            Calendar cal = Calendar.getInstance();
            cal.setTime(dataInicio);
            try {
                cal.add(Calendar.DAY_OF_MONTH, inicioContagem);
            } catch (NumberFormatException e) {
                throw new ServiceException("Erro ao converter o valor.", e);
            }
            return DateUtils.addFirstTimeInDate(cal.getTime());
        } else {
            return dataInicio;
        }
    }

	@Override
	public Boolean conbilizaSabados() throws ServiceException {
		return sabado == null ? Boolean.FALSE : sabado;
	}

	@Override
	public Boolean conbilizaDomingos() throws ServiceException {
		return domingo == null ? Boolean.FALSE : domingo;
	}
        
    @Override
    public String calculaSlaIntervaloEmMinutos(Date inicio, Date fim) throws ServiceException {
        return formataMinutosEmHorasMinutos(getMinutosSlaIntervalo(inicio,fim, inicioContagem));
    }
    
    @Override
    public Long calculaSlaInterValo(Date inicio, Date fim) throws ServiceException {
        return getMinutosSlaIntervalo(inicio,fim, inicioContagem);
    }
        
	@Override
	public Caso loadSla(Caso caso) throws ServiceException {

		Long sla = calculaSlaMinutos(caso.getDataAbertura(), caso.getDataFimSla(), inicioContagem);

		if (sla < tmpOK) {
			caso.setIconeSla(Constantes.ICONE_OK);
		} else if (sla < tmpAtencao) {
			caso.setIconeSla(Constantes.ICONE_ATENCAO);
		} else {
			caso.setIconeSla(Constantes.ICONE_ATRASADO);
		}

        Date inicioSla = inicioContagem(caso.getDataAbertura());
        Long slaMilisec = tmpAtencao * 60 * 1000;
        caso.setDataVencimentoSla(new Date(inicioSla.getTime() + slaMilisec));
                
		caso.setSlaEmMinutos(formataMinutosEmHorasMinutos(sla));

		return caso;
	}

	@Override
	public Caso verificaSlaMaiorParametro(Caso caso, long slaParam)
			throws ServiceException {

		Long sla = calculaSlaMinutos(caso.getDataAbertura(), caso.getDataFimSla(), inicioContagem);

		if (sla.longValue() > slaParam) {
			return null;
		}

		if (sla < tmpOK) {
			caso.setIconeSla(Constantes.ICONE_OK);
		} else if (sla < tmpAtencao) {
			caso.setIconeSla(Constantes.ICONE_ATENCAO);
		} else {
			caso.setIconeSla(Constantes.ICONE_ATRASADO);
		}
                
        Date inicioSla = inicioContagem(caso.getDataAbertura());
        Long slaMilisec = tmpAtencao * 60 * 1000;
        caso.setDataVencimentoSla(new Date(inicioSla.getTime() + slaMilisec));
                
		caso.setSlaEmMinutos(formataMinutosEmHorasMinutos(sla));
		return caso;

	}
	
	@Override
	public Caso verificaSlaMenorParametro(Caso caso, long slaParam)
			throws ServiceException {

		Long sla = calculaSlaMinutos(caso.getDataAbertura(), caso.getDataFimSla(), inicioContagem);

		if (sla.longValue() < slaParam) {
			return null;
		}

		if (sla < tmpOK) {
			caso.setIconeSla(Constantes.ICONE_OK);
		} else if (sla < tmpAtencao) {
			caso.setIconeSla(Constantes.ICONE_ATENCAO);
		} else {
			caso.setIconeSla(Constantes.ICONE_ATRASADO);
		}

		caso.setSlaEmMinutos(formataMinutosEmHorasMinutos(sla));
		return caso;

	}

	@Override
	public void verificaSlaMaiorParametroList(List<Caso> casoLlist, long sla)
			throws ServiceException {

		for (Caso caso2 : casoLlist) {
			verificaSlaMaiorParametro(caso2, sla);
		}
	}
	
	@Override
	public Double calcularPorcentagem(Double tempoSlaEmMinutos,
			Long tempoAtualEmMinutos) throws ServiceException {
		return null;
	}

	@Override
	public Integer retornaSlaMinutos(String slaEmMinutos) throws ServiceException {
		try {
			if (slaEmMinutos == null) {
				return 0;
			}

			String[] str = slaEmMinutos.split(":");
			Integer minutos = 0;

			minutos = (Integer.valueOf(str[0]) * 60) + Integer.valueOf(str[1]);
			return minutos;
			
		} catch (Exception e) {
			throw new ServiceException("SLA em minutos não pode ser calculado");
		}
	}
}
