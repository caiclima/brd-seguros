/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.service.impl;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.pojo.Feriado;
import br.com.callink.cad.pojo.SlaFila;
import br.com.callink.cad.repository.SlaFilaConfiguracao;
import br.com.callink.cad.service.IParametroGBOService;
import br.com.callink.cad.service.ISlaCacheService;
import br.com.callink.cad.service.ISlaFilaService;
import br.com.callink.cad.service.ISlaService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.util.Constantes;
import br.com.callink.coreutils.util.date.DateUtils;

/**
 * @author José Araújo (joseap@swb.com.br)
 */
@Stateless
public class SlaTipoFilaService extends AbstractSlaService implements ISlaService {

	@EJB
	private ISlaFilaService slaFilaService;
	@EJB 
	private ISlaCacheService slaCacheService;
	@EJB
	private IParametroGBOService parametroGBOService;
	
	public SlaTipoFilaService() {
	}

	
	@Override
	public Map<String, Feriado> getFeriados() throws ServiceException {
		return slaCacheService.getFeriado() == null ? new HashMap<String, Feriado>() : slaCacheService.getFeriado();
	}

    @Override
    public Date inicioContagem(Date dataInicio) throws ServiceException {
    	Integer inicioContagem = slaCacheService.getInicioContagem();
    	
        if (inicioContagem != null && inicioContagem > 0) {
            Calendar cal = Calendar.getInstance();
            cal.setTime(dataInicio);
            try {
                cal.add(Calendar.DAY_OF_MONTH, inicioContagem);
            } catch (NumberFormatException e) {
                throw new ServiceException("Erro ao converter o valor.", e);
            }
            return DateUtils.addFirstTimeInDate(cal.getTime());
        } else {
            return dataInicio;
        }
    }

	@Override
	public Boolean conbilizaSabados() throws ServiceException {
		Boolean sabado = slaCacheService.getSabado();
		
		return sabado == null ? Boolean.FALSE : sabado;
	}

	@Override
	public Boolean conbilizaDomingos() throws ServiceException {
		Boolean domingo = slaCacheService.getDomingo();
		
		return domingo == null ? Boolean.FALSE : domingo;
	}
        
    @Override
    public String calculaSlaIntervaloEmMinutos(Date inicio, Date fim) throws ServiceException {
        return formataMinutosEmHorasMinutos(getMinutosSlaIntervalo(inicio,fim, slaCacheService.getInicioContagem()));
    }
    
    @Override
    public Long calculaSlaInterValo(Date inicio, Date fim) throws ServiceException {
        return getMinutosSlaIntervalo(inicio,fim, slaCacheService.getInicioContagem());
    }
        
	@Override
	public Caso loadSla(Caso caso) throws ServiceException {
		try {
			SlaFila slaFila = caso.getSlaFila();
	
			if (caso.getSlaFila() == null || caso.getSlaFila().getIdSlaFila() == null || caso.getSlaFila().getIdSlaFila() < 1) {
				SlaFila slaProvisorio = new SlaFila();
				slaProvisorio.setConfiguracaoFila(new ConfiguracaoFila(0));
				slaProvisorio.setDataInicial(new Date(System.currentTimeMillis()));
				try {
					slaProvisorio.setSla(
							Integer.parseInt(parametroGBOService.findByParam(Constantes.TEMPO_SLA).getValor()));
				} catch (NullPointerException ex) {
					slaProvisorio.setSla(48);
				}
				slaProvisorio.setIdSlaFila(0);
				
				caso.setSlaFila(slaProvisorio);
			} else {
				//Verifica se o Sla Fila não esta em cache
				if (SlaFilaConfiguracao.getSlaFilaCache(slaFila.getIdSlaFila()) == null) {
					slaFila = slaFilaService.findByPk(caso.getSlaFila());
					SlaFilaConfiguracao.setSlaFilaCache(slaFila);
					
					caso.setSlaFila(slaFila);
				} else {
					caso.setSlaFila(SlaFilaConfiguracao.getSlaFilaCache(slaFila.getIdSlaFila()));
				}
			}
	
			Long slaAtualEmMinutos = calculaSlaMinutos(caso.getDataAbertura(), caso.getDataFimSla(), slaCacheService.getInicioContagem());
			Double slaFilaEmMinutos = calculaSlaFilaBancoEmMinutos(caso);
			Double porcentagem = calcularPorcentagem(slaFilaEmMinutos, slaAtualEmMinutos);
			
			if (porcentagem <= slaCacheService.getTempoOk()) {
				caso.setIconeSla(Constantes.ICONE_OK);
			} else if (porcentagem < slaCacheService.getTempoAtencao()) {
				caso.setIconeSla(Constantes.ICONE_ATENCAO);
			} else {
				caso.setIconeSla(Constantes.ICONE_ATRASADO);
			}
	
            Date inicioSla = inicioContagem(caso.getDataAbertura());
            Long slaMilisec = slaFilaEmMinutos.longValue() * 60 * 1000;
            if (slaMilisec > 0L) {
                caso.setDataVencimentoSla(calcularDataVencimentoSla(inicioSla, slaMilisec));
            }
                      
			caso.setSlaEmMinutos(formataMinutosEmHorasMinutos(slaAtualEmMinutos));
			caso.setPorcentagemSla(porcentagem);

		} catch (ServiceException e) {
			throw new ServiceException("Erro ao tentar buscar slaFila em SlaTipoFilaService.loadSla", e);
		}

		return caso;
	}
	
	private Date calcularDataVencimentoSla(Date dataInicio, Long sla) throws ServiceException{
		Long slaDecorrido = 0L;
		
		Calendar calendarFim = Calendar.getInstance();
		calendarFim.setTime(dataInicio);
		calendarFim.add(Calendar.DATE, 1);
		Date dataFim = DateUtils.addFirstTimeInDate(calendarFim.getTime());
		
		while(true){
			if(contaDia(dataInicio)){
				Long incrementoSla = (dataFim.getTime() - dataInicio.getTime()) >  
										(sla - slaDecorrido) ? sla - slaDecorrido : 
										 dataFim.getTime() - dataInicio.getTime();
				
				slaDecorrido = slaDecorrido + incrementoSla;

				if(slaDecorrido.compareTo(sla) == 0){
					return new Date(dataInicio.getTime() + incrementoSla);
				}
				
				dataInicio = new Date(dataFim.getTime());
				
				calendarFim.setTime(dataInicio);
				calendarFim.add(Calendar.DATE, 1);
				dataFim = DateUtils.addFirstTimeInDate(calendarFim.getTime());
			}else{
				dataInicio = new Date(dataFim.getTime());
				
				calendarFim.setTime(dataInicio);
				calendarFim.add(Calendar.DATE, 1);
				dataFim = DateUtils.addFirstTimeInDate(calendarFim.getTime());
			}
		}
		
	}

	private Boolean contaDia(Date data) throws ServiceException {
		if (containsFeriado(getFeriados(), data)) {
            return Boolean.FALSE;
        }
		
		Calendar cal = Calendar.getInstance();
		cal.setTime(data);

        if(cal.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY
        	&& !conbilizaSabados()){
        	
        	return Boolean.FALSE;
        }
        
        if(cal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY
        	&& !conbilizaDomingos()){
        	
        	return Boolean.FALSE;
        }
        
        return Boolean.TRUE;
        
	}


	private boolean containsFeriado(Map<String, Feriado> feriados, Date data) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		
		if(feriados == null || feriados.isEmpty()){
			return false;
		}
		
		if(feriados.containsKey(sdf.format(data))){
			return true;
		}
		
		for (Feriado feriado : feriados.values()) {
			Calendar calFeriado = Calendar.getInstance();
			calFeriado.setTime(feriado.getDataFeriado());
			
			Calendar calData = Calendar.getInstance();
			calData.setTime(data);
			
			if(feriado.getFlagFixo()
				&& calFeriado.get(Calendar.DATE) == calData.get(Calendar.DATE)
				&& calFeriado.get(Calendar.MONTH) == calData.get(Calendar.MONTH)){
				
				return true;
			}
		}
		
		return false;
	}


	@Override
	public Caso verificaSlaMaiorParametro(Caso caso, long slaParam)
			throws ServiceException {

		Long slaAtualEmMinutos = calculaSlaMinutos(caso.getDataAbertura(), caso.getDataFimSla(), slaCacheService.getInicioContagem());
		Double slaFilaEmMinutos = calculaSlaFilaBancoEmMinutos(caso);
		Double porcentagem = calcularPorcentagem(slaFilaEmMinutos, slaAtualEmMinutos);

		if (slaAtualEmMinutos.longValue() > slaParam) {
			return null;
		}
		
		if (porcentagem <= slaCacheService.getTempoOk()) {
			caso.setIconeSla(Constantes.ICONE_OK);
		} else if (porcentagem < slaCacheService.getTempoAtencao()) {
			caso.setIconeSla(Constantes.ICONE_ATENCAO);
		} else {
			caso.setIconeSla(Constantes.ICONE_ATRASADO);
		}

		caso.setSlaEmMinutos(formataMinutosEmHorasMinutos(slaAtualEmMinutos));
		caso.setPorcentagemSla(porcentagem);
		return caso;

	}

	/**
	 * Calcula sla fila retornado pelo banco de dados em minutos
	 * @param caso
	 * @return
	 */
	private Double calculaSlaFilaBancoEmMinutos(Caso caso) {
		//Verifica se caso esta vazio ou não contem um sla
		if (caso == null || caso.getSlaFila() == null) {
			return 0.00;
		} else {
			//Verifica se o id sla é menor que um e se o sla é diferente de nulo,
			//o que significa que é um sla criado automaticamente.
			if (caso.getSlaFila().getIdSlaFila() < 1 && caso.getSlaFila().getSla() != null) {
				return Double.valueOf(caso.getSlaFila().getSla() *60);
			}
			
			//Verifica se o sla esta no cache
			if (caso.getSlaFila().getSla() == null && SlaFilaConfiguracao.getSlaFilaCache(caso.getSlaFila().getIdSlaFila()) == null) {
				return 0.00;
			}
		}
		
		caso.setSlaFila(SlaFilaConfiguracao.getSlaFilaCache(caso.getSlaFila().getIdSlaFila()));
		
		return Double.valueOf(caso.getSlaFila().getSla() *60);
	}
	
	@Override
	public Caso verificaSlaMenorParametro(Caso caso, long slaParam)
			throws ServiceException {

		Long slaAtualEmMinutos = calculaSlaMinutos(caso.getDataAbertura(), caso.getDataFimSla(), slaCacheService.getInicioContagem());
		Double slaFilaEmMinutos = calculaSlaFilaBancoEmMinutos(caso);
		Double porcentagem = calcularPorcentagem(slaFilaEmMinutos, slaAtualEmMinutos);

		if (slaAtualEmMinutos.longValue() < slaParam) {
			return null;
		}
		
		if (porcentagem <= slaCacheService.getTempoOk()) {
			caso.setIconeSla(Constantes.ICONE_OK);
		} else if (porcentagem < slaCacheService.getTempoAtencao()) {
			caso.setIconeSla(Constantes.ICONE_ATENCAO);
		} else {
			caso.setIconeSla(Constantes.ICONE_ATRASADO);
		}

		caso.setSlaEmMinutos(formataMinutosEmHorasMinutos(slaAtualEmMinutos));
		caso.setPorcentagemSla(porcentagem);
		return caso;

	}

	@Override
	public void verificaSlaMaiorParametroList(List<Caso> casoLlist, long sla)
			throws ServiceException {

		for (Caso caso2 : casoLlist) {
			verificaSlaMaiorParametro(caso2, sla);
		}
	}
	
	/**
	 * Calcula a porcentagem do sla atual
	 * 
	 * @param tempoSlaEmMinutos
	 * @param tempoAtualEmMinutos
	 * @return porcentagemCalculada
	 */
	@Override
	public Double calcularPorcentagem(Double tempoSlaEmMinutos, Long tempoAtualEmMinutos) throws ServiceException {
		try {
			DecimalFormat df = new DecimalFormat("0.00");
			Double porcentagemCalculada = null;
			if (tempoSlaEmMinutos > 0) {
				porcentagemCalculada = Double.valueOf((tempoAtualEmMinutos*100)/tempoSlaEmMinutos);
			} else {
				porcentagemCalculada = 0D;
			}
			return new Double(df.format(porcentagemCalculada).replace(",", "."));
		} catch (Exception ex) {
			throw new ServiceException("Erro ao calcular a porcentagem do SLA", ex);
		}
	}


	@Override
	public void initSlaService() throws ServiceException {
		// TODO Auto-generated method stub
		
	}


	@Override
	public Integer retornaSlaMinutos(String slaEmMinutos) throws ServiceException {
		try {
			if (slaEmMinutos == null) {
				return 0;
			}

			String[] str = slaEmMinutos.split(":");
			Integer minutos = 0;

			minutos = (Integer.valueOf(str[0]) * 60) + Integer.valueOf(str[1]);
			return minutos;
			
		} catch (Exception e) {
			throw new ServiceException("SLA em minutos não pode ser calculado");
		}
	}
}
