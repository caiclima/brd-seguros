package br.com.callink.cad.service.impl;

import java.util.Date;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import br.com.callink.cad.dao.IStatusAtendenteDAO;
import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.AtendenteStatus;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.pojo.Equipe;
import br.com.callink.cad.pojo.ParametroGBO;
import br.com.callink.cad.pojo.StatusAtendente;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.service.IAtendenteService;
import br.com.callink.cad.service.IAtendenteStatusService;
import br.com.callink.cad.service.ICasoService;
import br.com.callink.cad.service.IParametroGBOService;
import br.com.callink.cad.service.IStatusAtendenteService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.service.repository.ControleStatusAtendentes;
import br.com.callink.cad.util.Constantes;

/**
 *
 * @author brunomt
 */
@Stateless
public class StatusAtendenteService extends GenericGboService<StatusAtendente, IStatusAtendenteDAO> implements IStatusAtendenteService {
	
	private static final long serialVersionUID = 1L;

	@Inject
	private IStatusAtendenteDAO statusAtendenteDAO;
	
	@EJB
	private IAtendenteService atendenteService;
	
	@EJB
	private IAtendenteStatusService atendenteStatusService;
	
	@EJB
	private IParametroGBOService parametroGBOService;
	
	@EJB
	private ICasoService casoService;
	
	@Override
	protected IStatusAtendenteDAO getDAO() {
		return statusAtendenteDAO;
	}
	
	@Override
    public void save(StatusAtendente statusAtendente) throws ServiceException, ValidationException {
        try {
            validaStatusAtendimento(statusAtendente.getIdAtendente());
            
            Integer idUltimoStatusAtendente = getDAO().buscaUltimoStatusAtendente(statusAtendente.getIdAtendente());
            
            StatusAtendente ultimoStatusAtendente = new StatusAtendente();
            ultimoStatusAtendente.setPK(idUltimoStatusAtendente);
            
            ultimoStatusAtendente = getDAO().findByPk(ultimoStatusAtendente);
            
            if (ultimoStatusAtendente != null && ultimoStatusAtendente.getIdStatusAtendente()!= null 
            		&& ultimoStatusAtendente.getIdStatusAtendente()!= 0 && ultimoStatusAtendente.getDataFim() == null) {
            		
            	ultimoStatusAtendente.setDataFim(statusAtendente.getDataBanco());
                super.update(ultimoStatusAtendente);
            }
            
            if (statusAtendente.isFlagInicio()) {
                statusAtendente.setDataInicio(statusAtendente.getDataBanco());
                super.save(statusAtendente);
            }
        } catch (DataException ex) {
            throw new ServiceException("Erro ao salvar a marcação StatusAtendente",ex);
        }
    }

    @Override
    public void salvarNovoStatusAtendendimento(Caso caso, Atendente atendente, AtendenteStatus atendenteStatus, Boolean flagInicio) throws ServiceException, ValidationException {
        if (flagInicio == null) {
            throw new ValidationException("Informar o flagInicio. O mesmo não pode ser nulo.");
        }
        if (flagInicio && (atendenteStatus == null || atendenteStatus.getIdAtendenteStatus() == null)) {
            throw new ValidationException("Para criar uma nova marcação é necessário informar o campo atendenteStatus.");
        }
        
        validaStatusAtendimento(atendente);
        
        StatusAtendente statusAtendente = new StatusAtendente();
        statusAtendente.setDataBanco(getDataBanco());
        statusAtendente.setIdAtendente(atendente);
        statusAtendente.setIdAtendenteStatus(atendenteStatus);
        if (caso != null && caso.getIdCaso() != null) {
            statusAtendente.setIdCaso(caso);
            statusAtendente.setIdConfiguracaoFila(caso.getConfiguracaoFila());
        }
        statusAtendente.setIdEquipe(atendente.getEquipe());
        statusAtendente.setFlagInicio(flagInicio);
        
        if (flagInicio) {
            statusAtendente.setDataInicio(statusAtendente.getDataBanco());
        }
        
        ControleStatusAtendentes.offerStatusAtendente(statusAtendente);
    }
    
    private void validaStatusAtendimento(Atendente atendente) throws ValidationException, ServiceException {
        if (atendente == null || atendente.getIdAtendente() == null) {
            throw  new ValidationException("O atendente não pode ser nulo.");
        } else {        
            if (atendente.getEquipe() == null || atendente.getEquipe().getIdEquipe() == null) {
                atendente = atendenteService.findByPk(atendente);
                
                if (atendente.getEquipe() == null || atendente.getEquipe().getIdEquipe() == null) {
                    throw new ValidationException("A equipeFila não pode ser nula.");
                }
            }
        }
    }

    @Override
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void salvaStatusAtendimentoDisponivel(Atendente atendente) throws ServiceException {
        try {
            ParametroGBO parametroGBO = parametroGBOService.findByParam(Constantes.ATENDENTE_STATUS_DISPONIVEL);
            ParametroGBO parametroGBOSup = parametroGBOService.findByParam(Constantes.ID_SUPERVISOR);
            
            if (atendente == null || atendente.getPerfil() == null || atendente.getPerfil().getIdPerfil() == null ||
            		(parametroGBOSup != null && atendente.getPerfil().getIdPerfil().equals(Integer.valueOf(parametroGBOSup.getValor())))) {
                return;
            }
            
            salvaStatusAtendimentoStatus(atendente, Integer.valueOf(parametroGBO.getValor()), Boolean.TRUE, null);
        } catch(Exception ex) {
            throw new ServiceException("Erro ao criar o statusAtendimento disponível.",ex);
        }
    }

    /**
     * 
     * @param atendente
     * @param atendenteStatus
     * @param flagInicia
     * @param caso 
     * @throws ValidationException 
     */
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
    private void salvaStatusAtendimentoStatus(Atendente atendente, Integer idAtendenteStatus, Boolean flagInicia, Caso caso) throws ServiceException, ValidationException {
        try {
            AtendenteStatus atendenteStatus = new AtendenteStatus();
            atendenteStatus.setPK(idAtendenteStatus);
            atendenteStatus = atendenteStatusService.findByPk(atendenteStatus);
            
            salvarNovoStatusAtendendimento(caso, atendente, atendenteStatus, flagInicia);
        } catch (ServiceException ex) {
            throw new ServiceException("Erro ao criar o statusAtendimento disponível.",ex);
        }
    }
    
    @Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public void salvaStatusAtendimentoAtendimento(Atendente atendente, Caso caso) throws ServiceException, ValidationException {
        ParametroGBO parametroGBO = parametroGBOService.findByParam(Constantes.ATENDENTE_STATUS_ATENDIMENTO);

        salvaStatusAtendimentoStatus(atendente, Integer.valueOf(parametroGBO.getValor()), Boolean.TRUE, caso);
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<StatusAtendente> buscaTodosStatusAtendenteEntreDatas(Date data1, Date data2) throws ServiceException {
        try {
             return getDAO().buscaTodosStatusAtendenteEntreDatas(data1, data2);
        } catch (DataException ex) {
            throw new ServiceException("Erro ao buscar os status dos atendentes.",ex);
        }
    }
    
    @Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<StatusAtendente> buscaStatusAtendenteByAtendente(Atendente atendente, Date dataInicial, 
			Date dataFinal) throws ServiceException {
		try {
			return getDAO().buscaStatusAtendenteByAtendente(atendente, dataInicial, dataFinal);
		} catch (DataException ex) {
			throw new ServiceException("Erro ao buscar os status dos atendentes.", ex);
		}

	}
    
    @Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<StatusAtendente> buscaStatusAtendenteByUserEquipe(ConfiguracaoFila fila, Equipe equipe, Atendente atendente,
			Date dataInicial, Date dataFinal) throws ServiceException {
		try {
			return getDAO().buscaStatusAtendenteByUserEquipe(fila, equipe, atendente, dataInicial, dataFinal);
		} catch (DataException ex) {
			throw new ServiceException("Erro ao buscar os status dos atendentes.", ex);
		}

	}
    
    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void alteraStatusToolbarGBO(String loginAtendente, Integer idStatusToolbar) throws ServiceException, ValidationException {
    	
    	Atendente atendente = atendenteService.findByLogin(loginAtendente);
    	
    	if (atendente == null) {
    		throw new ServiceException("O atendente " + loginAtendente + " não pode ser localizado.");
    	}
    	
    	List<Caso> casoList = casoService.atendentePossuiCasoEmAtendimento(loginAtendente);
    	AtendenteStatus atendenteStatus = atendenteStatusService.buscaAtendenteStatusIdToolbar(idStatusToolbar);
    	
    	if (atendenteStatus == null) {
    		return;
    	}
    	StringBuilder st = new StringBuilder();
    	if (casoList != null && !casoList.isEmpty()) {
    		//Indica que o cliente solicitou uma alteração de status. Ele não irá solicitar um novo caso automaticamente.
    		ControleStatusAtendentes.addListAtendenteAltStatus(atendente, Boolean.TRUE);
    		
    		st.append("Existe casos em atendimento para o atendente. Caso: ").append(casoList.get(0).getIdExterno());
    		throw new ServiceException(st.toString());
    	} else {
    		salvarNovoStatusAtendendimento(null, atendente, atendenteStatus, Boolean.TRUE);
    	}
    	
    }
    
    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void alteraStatusToolbarGBODisponivel(String loginAtendente) throws ServiceException {
    	
    	Atendente atendente = atendenteService.findByLogin(loginAtendente);
    	if (atendente == null) {
    		throw new ServiceException("O atendente não pode ser localizado.");
    	}
    	
    	List<Caso> casoList = casoService.atendentePossuiCasoEmAtendimento(loginAtendente);
    	if (casoList != null && !casoList.isEmpty()) {
    		return;
    	} else {
    		salvaStatusAtendimentoDisponivel(atendente);
    	}
    }

	@Override
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void finalizaStatusAtendenteSemDataFim() throws ServiceException {
		try {
			getDAO().finalizaStatusAtendenteSemDataFim();
		} catch (Exception e) {
			throw new ServiceException("Erro ao finalizar os status dos atendentes.",e);
		}
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<StatusAtendente> buscaStatusAtendenteByStatus(AtendenteStatus atendenteStatus, Integer tempoSegundos) throws ServiceException {
		if (atendenteStatus == null || tempoSegundos == null) {
			throw new ServiceException("Os parametros não podem ser nulos.");
		}
		try {
			 List<StatusAtendente> statusAtendentes = getDAO().buscaStatusAtendenteByStatus(atendenteStatus, tempoSegundos);
			 
			 return statusAtendentes;
		} catch (Exception e) {
			throw new ServiceException("Erro ao buscar os atendenteStatus",e);
		}
	}

}

