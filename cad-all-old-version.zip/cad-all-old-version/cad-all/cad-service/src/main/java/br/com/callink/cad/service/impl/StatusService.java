package br.com.callink.cad.service.impl;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.dao.IStatusDAO;
import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.pojo.Status;
import br.com.callink.cad.pojo.StatusAcao;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.service.IAcaoService;
import br.com.callink.cad.service.IStatusService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.util.Constantes;

/**
 * 
 * @author brunomt [brunoam@swb.com.br]
 * 
 */
@Stateless
public class StatusService extends GenericGboService<Status, IStatusDAO> implements IStatusService {

	private static final long serialVersionUID = 1L;

	@Inject
	private IStatusDAO statusDAO;
	
	@EJB
	private IAcaoService acaoService;
	
	@Override
	protected IStatusDAO getDAO() {
		return statusDAO;
	}
	
	@Override
	public void save(Status status) throws ServiceException, ValidationException {

		if (status == null || StringUtils.isBlank(status.getNome())
				|| StringUtils.isBlank(status.getDescricao())
				|| status.getFlagAtivo() == null
				|| status.getFlagPausado() == null
				|| status.getFlagMostraRegua() == null) {
			throw new ValidationException("Campos obrigat\u00F3rios do Status devem ser preenchidos.");
		}

		status.setDataCriacao(getDataBanco());

		if (status.getPK() == null) {
			super.save(status);
		} else {
			super.update(status);
		}
	}

	@Override
	public void update(Status status) throws ServiceException, ValidationException {
		if (status == null || StringUtils.isBlank(status.getNome())
				|| StringUtils.isBlank(status.getDescricao())
				|| status.getFlagAtivo() == null
				|| status.getFlagPausado() == null
				|| status.getFlagMostraRegua() == null) {
			throw new ValidationException("Campos obrigat\u00F3rios do Status devem ser preenchidos.");
		}
		super.update(status);
	}

	@Override
	public void inativar(Status status) throws ServiceException, ValidationException {
		status.setFlagAtivo(false);
		super.update(status);
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void associa(StatusAcao statusAcao) throws ServiceException, ValidationException {

		if (statusAcao.getStatusAcaoId() == null
				|| statusAcao.getStatusAcaoId().getIdAcao() == null
				|| statusAcao.getStatusAcaoId().getIdAcao().getIdAcao() == null
				|| statusAcao.getStatusAcaoId().getIdStatus() == null
				|| statusAcao.getStatusAcaoId().getIdStatus().getIdStatus() == null) {
			throw new ValidationException("Os campos Status e A\u00E7\u00E3o devem ser preenchidos.");
		}

		try {
			if (getDAO().find(statusAcao.getStatusAcaoId().getIdAcao(), statusAcao.getStatusAcaoId().getIdStatus()).isEmpty()) {
				getDAO().associa(statusAcao);
			} else {
				throw new ValidationException("Associa\u00E7\u00E3o j\u00E1.");
			}
		} catch (DataException ex) {
			throw new ServiceException("Erro ao associar Status A\u00E7\u00E3o", ex);
		}
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void excluiAssociacao(StatusAcao statusAcao) throws ServiceException, ValidationException {

		if (statusAcao.getStatusAcaoId() == null
				|| statusAcao.getStatusAcaoId().getIdAcao() == null
				|| statusAcao.getStatusAcaoId().getIdAcao().getIdAcao() == null
				|| statusAcao.getStatusAcaoId().getIdStatus() == null
				|| statusAcao.getStatusAcaoId().getIdStatus().getIdStatus() == null) {
			throw new ValidationException("Os campos Status e A\u00E7\u00E3o devem ser preenchidos.");
		}
		try {
			getDAO().excluiAssociacao(statusAcao);
		} catch (DataException ex) {
			throw new ServiceException("Erro ao excluir Associa\u00E7\u00E3o", ex);
		}
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<StatusAcao> findByStatus(Status status) throws ServiceException, ValidationException {
		try {
			return loadStatusAcao(getDAO().findByStatus(status));
		} catch (DataException ex) {
			throw new ServiceException("Erro ao buscar Status e A\u00E7\u00E3o", ex);
		}
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<StatusAcao> findByAcao(Acao acao) throws ServiceException, ValidationException {
		try {
			return loadStatusAcao(getDAO().findByAcao(acao));
		} catch (DataException ex) {
			throw new ServiceException("Erro ao buscar Status e A\u00E7\u00E3o", ex);
		}
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<StatusAcao> find(Acao acao, Status status)
			throws ServiceException, ValidationException {
		try {
			return loadStatusAcao(getDAO().find(acao, status));
		} catch (DataException ex) {
			throw new ServiceException("Erro ao buscar Status e A\u00E7\u00E3o", ex);
		}
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<StatusAcao> findAllStatusAcao() throws ServiceException, ValidationException {
		try {
			return loadStatusAcao(getDAO().findAllStatusAcao());
		} catch (DataException ex) {
			throw new ServiceException("Erro ao buscar Status e A\u00E7\u00E3o", ex);
		}
	}

	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	private List<StatusAcao> loadStatusAcao(List<StatusAcao> lista) throws ServiceException, ValidationException {
		if (lista != null && lista.size() > 0) {
			try {
				for (int i = 0; i < lista.size(); i++) {
					StatusAcao temp = lista.get(i);
					temp.getStatusAcaoId().setIdAcao(acaoService.load(temp.getStatusAcaoId().getIdAcao()));
					temp.getStatusAcaoId().setIdStatus(load(temp.getStatusAcaoId().getIdStatus()));
					lista.set(i, temp);
				}

			} catch (ServiceException ex) {
				throw new ServiceException("Erro ao buscar Status e A\u00E7\u00E3o", ex);
			}
		}
		return lista;
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public Status findStatusByNomeStatus(String nomeStatus) throws ServiceException {
		try {
			return getDAO().findStatusByNomeStatus(nomeStatus);
		} catch (DataException e) {
			throw new ServiceException("Erro ao buscar Status", e);
		}
	}
	
	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<Status> findAll(String order) throws ServiceException {
		try {
			return getDAO().findAll(order);
		} catch (DataException ex) {
			throw new ServiceException("Erro ao buscar Status", ex);
		}
	}
	
	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<Status> findByExample(Status example, String order) throws ServiceException {
		try {
			return getDAO().findByExample(example, order);
		} catch (DataException ex) {
			throw new ServiceException("Erro ao buscar Status", ex);
		}
	}

	@Override
	public Status buscaStatusPadraoCasosImportados() throws ServiceException {
		return findByPk(new Status(Constantes.ID_STATUS_PADRAO_DE_CASOS_IMPORTADAS));
	}

	@Override
	public List<Status> findByPkIn(List<Integer> st) throws ServiceException {
		try {
			return getDAO().findByPkIn(st);
		} catch (DataException ex) {
			throw new ServiceException("Erro ao buscar Status", ex);
		}
	}
	
	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<Status> findByNomes(List<String> nomesList) throws ServiceException {
		try {
              return getDAO().findByNomes(nomesList);
		} catch (DataException e) {
          throw new ServiceException("Erro ao buscar status", e);
		}
	}
	
	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<Status> findExcludeByNomes(List<String> nomesList) throws ServiceException {
		try {
              return getDAO().findExcludeByNomes(nomesList);
		} catch (DataException e) {
          throw new ServiceException("Erro ao buscar status", e);
		}
	}
	
	@Override
	public List<Status> findAtivos() throws ServiceException {
		try {
			Status status = new Status();
			status.setFlagAtivo(Boolean.TRUE);
			return getDAO().findByExample(status, "Status.NOME");
		} catch (DataException e) {
			throw new ServiceException("Erro ao buscar status", e);
		}
	}

}
