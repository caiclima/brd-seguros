package br.com.callink.cad.service.impl;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import br.com.callink.cad.dao.ITelaGboDAO;
import br.com.callink.cad.pojo.TelaGbo;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.service.ITelaGboService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

@Stateless
public class TelaGboService extends GenericGboService<TelaGbo, ITelaGboDAO>  implements ITelaGboService{

	private static final long serialVersionUID = 6994305703466520663L;
	
	@Inject
	private ITelaGboDAO telaGboDAO;
	
	@Override
	protected ITelaGboDAO getDAO() {
		return telaGboDAO;
	}
	
	@Override
	public void inativa(TelaGbo telaGbo) throws ServiceException{
		try {
			getDAO().update(telaGbo);
		} catch (DataException e) {
			throw new ServiceException("ERRO - Ao remover Tela",e);
		}
	}
	
	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public TelaGbo findByNomeTela(String mnemonico) throws ServiceException{
		try {
			return getDAO().findByNomeTela(mnemonico);
		} catch (DataException e) {
			throw new ServiceException("Erro ao buscar Tela", e);
		}
	}
	
	@Override
	public void save(TelaGbo telaGbo) throws ServiceException, ValidationException{
		try {
			TelaGbo telaGboPesquisa = findByNomeTela(telaGbo.getNomeTela());
			if(telaGboPesquisa!= null){
				throw new ValidationException("Nome da tela j\u00E1 est\u00E1 cadastrada!");
			}
			super.save(telaGbo);
		} catch (ServiceException e) {
			throw new ServiceException(e);
		}
	}

}
