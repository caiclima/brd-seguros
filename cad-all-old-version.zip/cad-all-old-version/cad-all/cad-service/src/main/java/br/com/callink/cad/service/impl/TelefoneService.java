package br.com.callink.cad.service.impl;

import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import br.com.callink.cad.dao.ITelefoneDAO;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.Telefone;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.service.ITelefoneService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.util.Constantes;

/**
 * @author Rogerio Moreira [rogeriom@swb.com.br]
 * 
 */
@Stateless
public class TelefoneService extends GenericGboService<Telefone, ITelefoneDAO> implements ITelefoneService {

    private static final long serialVersionUID = 1L;
    
    @Inject
    private ITelefoneDAO telefoneDAO;
    
    @Override
	protected ITelefoneDAO getDAO() {
		return telefoneDAO;
	}
    
    @Override
    public void saveListTel(List<Telefone> telefones) throws ServiceException {
    	try {
    		getDAO().deletarTelefonesAusentes(telefones);
    		
	    	for (Telefone tel : telefones) {
	    		saveOrUpdate(tel);
	    	}
    	} catch (Exception e) {
    		throw new ServiceException("Erro ao salvar telefones", e);
    	}
    }
    
	@Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void save(Telefone object) throws ServiceException, ValidationException {
    	configuraTelefone(object);
    	super.save(object);
    }
    
    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void update(Telefone object) throws ServiceException, ValidationException {
    	configuraTelefone(object);
    	super.update(object);
    }

    /*
     * Retira mascaras
     */
	private void configuraTelefone(Telefone tel) {
		tel.setTelefone(tel.getTelefone().replaceAll("\\D", ""));
	}
    
    @Override
    public List<Telefone> buscaTelefoneCaso(Caso caso) throws ServiceException {
    	try {
    		return getDAO().buscaTelefoneCaso(caso);
    	} catch (Exception e) {
    		throw new ServiceException("Erro ao buscar os telefones do caso");
    	}
    }
    
    public static Telefone validaTelefone(String numeroTelefone) throws ServiceException{
    	String telefoneSoNumero = TelefoneService.formataRemocaoCaracteresEspeciais(numeroTelefone);
    	if(telefoneSoNumero.length() == Constantes.DEZ){
    		return new Telefone(telefoneSoNumero.substring( 0, Constantes.DOIS), telefoneSoNumero.substring(Constantes.DOIS, telefoneSoNumero.length()));
    	} else if(telefoneSoNumero.length() == Constantes.ONZE){
    		return new Telefone(telefoneSoNumero.substring(0, Constantes.TRES), telefoneSoNumero.substring(Constantes.TRES, telefoneSoNumero.length()));
    	} else {
    		throw new ServiceException("N\u00FAmero de telefone informado inv\u00E1lido!");
    	}
    }
    
    
    private static String formataRemocaoCaracteresEspeciais(String valor) {

		if (	valor.indexOf('(') != - Constantes.UM || valor.indexOf(')') != - Constantes.UM
				|| valor.indexOf('-') != - Constantes.UM ) {

			StringBuffer valorAux = new StringBuffer();
			for (int i = 0; i < valor.length(); i++){
				if ((valor.charAt(i) != '(') && (valor.charAt(i) != ')')
						&& (valor.charAt(i) != '-')){
					valorAux.append(valor.charAt(i));
				}
			}

			return valorAux.toString();
		}
		return valor;
	}

	@Override
	public List<Telefone> findTelefonesNaoTabulados(List<Telefone> telefoneList) throws ServiceException {
		try {
			if(telefoneList != null && !telefoneList.isEmpty()){
				return getDAO().findTelefonesNaoTabulados(telefoneList);
			}
			
			return null;
    	} catch (DataException e) {
    		throw new ServiceException("Erro ao buscar os telefones nao tabulados");
    	}
	}
	
	@Override
	public Boolean existeContatoNaoTabulado(Caso caso) throws ServiceException, ValidationException {
		try {
			if(caso == null || caso.getIdCaso() == null){
				throw new ValidationException("É obrigatório informar o caso!");
			}
			
			return getDAO().existeContatoNaoTabulado(caso);
			
    	} catch (DataException e) {
    		throw new ServiceException("Erro ao buscar os telefones nao tabulados");
    	}
	}

	@Override
	public void deletarTelefonesCaso(Caso caso) throws ServiceException {
		try{
			getDAO().deletarTelefonesCaso(caso);
		}catch(Exception e){
			e.printStackTrace();
			throw new ServiceException("Erro ao deletar os telefones do caso. Motivo: " + e.getMessage());
		}
	}
	
}
