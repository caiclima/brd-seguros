package br.com.callink.cad.service.impl;

import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import br.com.callink.cad.dao.ITempoAtendimentoCasoDAO;
import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.TempoAtendimentoCaso;
import br.com.callink.cad.repository.MarcacaoLogs;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.service.ITempoAtendimentoCasoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 * Serviço que realiza a marcação do tempo que um usuário está em atendimento.
 * @author brunomt
 *
 */
@Stateless
public class TempoAtendimentoCasoService extends GenericGboService<TempoAtendimentoCaso, ITempoAtendimentoCasoDAO> implements
        ITempoAtendimentoCasoService {

    private static final long serialVersionUID = 1L;

    @Inject
    private ITempoAtendimentoCasoDAO tempoAtendimentoCasoDAO;
    
    @Override
	protected ITempoAtendimentoCasoDAO getDAO() {
		return tempoAtendimentoCasoDAO;
	}
    
    /**
     * Se for enviado um tempoAtendimento com flagInicio true iremos gravar essa nova marcação. Se for enviado false entendemos que é para
     * apenas finalizar a última marcação.
     * O campo DATA_MARCACAO do TempoAtendimentoCaso deve ser informado no momento de oferecer o mesmo. Caso esse campo esteja nulo será retornada
     * um ServiceException
     * @throws ValidationException 
     */
    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void save(TempoAtendimentoCaso tempoAtendimentoCaso) throws ServiceException, ValidationException {

        if (tempoAtendimentoCaso == null) {
            throw new ValidationException("O tempo atendimento n\u00E3o pode ser nulo.");
        }
        if (tempoAtendimentoCaso.getDataMarcacao() == null) {
            throw new ValidationException("O campo dataMarcacao do TempoAtendimentoCaso n\u00E3o pode ser nulo.");
        }

        Boolean insere = true;
        try {
            Integer ultimaIdMarcacao = getDAO().findUltimaMarcacaoAtendente(tempoAtendimentoCaso.getAtendente());
            if (ultimaIdMarcacao != null && !ultimaIdMarcacao.equals(0)) {
                TempoAtendimentoCaso tempoAtendimentoCasoValida = new TempoAtendimentoCaso();
                tempoAtendimentoCasoValida.setPK(ultimaIdMarcacao);
                tempoAtendimentoCasoValida = getDAO().findByPk(tempoAtendimentoCasoValida);

                if (tempoAtendimentoCaso.getFlagInicio() && (tempoAtendimentoCasoValida.getDataFim() == null)
                        && tempoAtendimentoCasoValida.getAtendente().equals(tempoAtendimentoCaso.getAtendente())
                        && tempoAtendimentoCasoValida.getCaso().equals(tempoAtendimentoCaso.getCaso())) {
                    insere = false;
                } else {
                    if (!tempoAtendimentoCaso.getFlagInicio() && tempoAtendimentoCasoValida.getDataFim() == null) {
                        tempoAtendimentoCasoValida.setFlagInicio(Boolean.FALSE); //obs: a flag não é salva em banco
                        tempoAtendimentoCasoValida.setDataFim(tempoAtendimentoCaso.getDataMarcacao()); //data fim da marcação => data atual
                        tempoAtendimentoCasoValida.setAcao(tempoAtendimentoCaso.getAcao());
                        super.update(tempoAtendimentoCasoValida);
                    }
                }
            }
        } catch (DataException e) {
            throw new ServiceException("Erro ao buscar a \u00FAltima marca\u00E7\u00E3o.", e);
        }
        //Se for enviado um tempoAtendimento com flagInicio true iremos gravar essa nova marcação. Se for enviado false entendemos que é para
        //apenas finalizar a última marcação.
        if (insere && tempoAtendimentoCaso.getFlagInicio()) {
            tempoAtendimentoCaso.setDataInicio(tempoAtendimentoCaso.getDataMarcacao());
            super.save(tempoAtendimentoCaso);
        }
    }

    @Override
    public void update(TempoAtendimentoCaso tempoAtendimentoCaso) throws ValidationException {
        throw new ValidationException("N\u00E3o \u00E9 poss\u00EDvel fazer altera\u00E7\u00F5es em uma marca\u00E7\u00E3o. Favor solicitar o save de uma nova marca\u00E7\u00E3o.");
    }

    @Override
    public void salvaMarcacaoAtendimento(Caso caso, Acao acao, Atendente atendente, Boolean inicioFim) throws ServiceException {
        TempoAtendimentoCaso tempoAtendimentoCaso = new TempoAtendimentoCaso();
        if (caso != null) {
            tempoAtendimentoCaso.setCaso(caso);
        }

        tempoAtendimentoCaso.setAtendente(atendente);
        tempoAtendimentoCaso.setFlagInicio(inicioFim);

        if (acao != null) {
            tempoAtendimentoCaso.setAcao(acao);
        }

        tempoAtendimentoCaso.setDataMarcacao(getDataBanco());

        MarcacaoLogs.offer(tempoAtendimentoCaso);

    }

	@Override
	public List<TempoAtendimentoCaso> findByCaso(Caso caso) throws ServiceException {
		try {
			return getDAO().findByCaso(caso);
		} catch(DataException e) {
			throw new ServiceException(e);
		}
	}

}
