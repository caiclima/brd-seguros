package br.com.callink.cad.service.impl;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.dao.ITipoAcaoDAO;
import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.pojo.AcaoTipoAcao;
import br.com.callink.cad.pojo.Status;
import br.com.callink.cad.pojo.TipoAcao;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.service.IAcaoService;
import br.com.callink.cad.service.ITipoAcaoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

@Stateless
public class TipoAcaoService extends GenericGboService<TipoAcao, ITipoAcaoDAO> implements ITipoAcaoService {
	
	private static final long serialVersionUID = 1L;
	
	@Inject
	private ITipoAcaoDAO tipoAcaoDAO;
	
	@EJB
	private IAcaoService acaoService;
	
	
	@Override
	protected ITipoAcaoDAO getDAO() {
		return tipoAcaoDAO;
	}
	
	@Override
	public void save(TipoAcao tipoAcao) throws ServiceException, ValidationException {
		
		try {
			validaTipoAcao(tipoAcao);
			if (tipoAcao.getFlagAtivo() == null) {
				tipoAcao.setFlagAtivo(Boolean.TRUE);
			}
			tipoAcao.setDataAlteracao(getDataBanco());
			super.save(tipoAcao);
		} catch (ServiceException e) {
			throw new ServiceException("Falha ao salvar Objeto", e);
		}
	}
	
	@Override
	public void update(TipoAcao tipoAcao) throws ServiceException, ValidationException {

		try {
			validaTipoAcao(tipoAcao);
			if (tipoAcao.getFlagAtivo() == null) {
				tipoAcao.setFlagAtivo(Boolean.TRUE);
			}
			tipoAcao.setDataAlteracao(getDataBanco());
			super.update(tipoAcao);
		} catch (ServiceException e) {
			throw new ServiceException("Falha ao atualizar Objeto", e);
		}
	}

	@Override
	public void inativar(TipoAcao tipoAcao) throws ServiceException, ValidationException {
		if (tipoAcao == null) {
			throw new ValidationException("O Tipo A\u00E7\u00E3o n\u00E3o pode ser nulo.");
		}
		tipoAcao.setFlagAtivo(Boolean.FALSE);
		this.update(tipoAcao);
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void associa(AcaoTipoAcao acaoTipoAcao) throws ServiceException, ValidationException {

		if (acaoTipoAcao.getAcaoTipoAcaoId() == null || acaoTipoAcao.getAcaoTipoAcaoId().getIdAcao() == null || acaoTipoAcao.getAcaoTipoAcaoId().getIdAcao().getIdAcao() == null
				|| acaoTipoAcao.getAcaoTipoAcaoId().getIdTipoAcao() == null	|| acaoTipoAcao.getAcaoTipoAcaoId().getIdTipoAcao().getIdTipoAcao() == null) {
			throw new ValidationException("Os campos TipoA\u00E7\u00E3o e A\u00E7\u00E3o devem ser preenchidos.");
		}

		try {
			if (getDAO().find(acaoTipoAcao.getAcaoTipoAcaoId().getIdAcao(), acaoTipoAcao.getAcaoTipoAcaoId().getIdTipoAcao()).isEmpty()) {
				getDAO().associa(acaoTipoAcao);
			} else {
				throw new ValidationException("Associa\u00E7\u00E3o j\u00E1 cadastrada.");
			}
		} catch (DataException ex) {
			throw new ServiceException(ex);
		}		
	}
	

	@Override
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void excluiAssociacao(AcaoTipoAcao acaoTipoAcao) throws ServiceException, ValidationException {

		if (acaoTipoAcao.getAcaoTipoAcaoId() == null
				|| acaoTipoAcao.getAcaoTipoAcaoId().getIdAcao() == null
				|| acaoTipoAcao.getAcaoTipoAcaoId().getIdAcao().getIdAcao() == null
				|| acaoTipoAcao.getAcaoTipoAcaoId().getIdTipoAcao() == null
				|| acaoTipoAcao.getAcaoTipoAcaoId().getIdTipoAcao().getIdTipoAcao() == null) {
			throw new ValidationException("Os campos TipoA\u00E7\u00E3o e A\u00E7\u00E3o devem ser preenchidos.");
		}
		try {
			getDAO().excluiAssociacao(acaoTipoAcao);
		} catch (DataException ex) {
			throw new ServiceException("Erro ao excluir Associa\u00E7\u00E3o", ex);
		}
	}
	

	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<AcaoTipoAcao> find(Acao acao, TipoAcao tipoAcao) throws ServiceException, ValidationException {
		try {
			return loadAcaoTipoAcao(getDAO().find(acao, tipoAcao));
		} catch (DataException ex) {
			throw new ServiceException("Erro ao buscar A\u00E7\u00E3o e TipoA\u00E7\u00E3o", ex);
		}
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<AcaoTipoAcao> findAllAcaoTipoAcao() throws ServiceException, ValidationException {
		try {
			return loadAcaoTipoAcao(getDAO().findAllAcaoTipoAcao());
		} catch (DataException ex) {
			throw new ServiceException("Erro ao buscar A\u00E7\u00E3o e TipoA\u00E7\u00E3o", ex);
		}
	}

	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	private List<AcaoTipoAcao> loadAcaoTipoAcao(List<AcaoTipoAcao> lista) throws ServiceException, ValidationException {
		
		if (lista != null && lista.size() > 0) {
			try {
				for (int i = 0; i < lista.size(); i++) {
					AcaoTipoAcao temp = lista.get(i);
					temp.getAcaoTipoAcaoId().setIdAcao(acaoService.load(temp.getAcaoTipoAcaoId().getIdAcao()));
					temp.getAcaoTipoAcaoId().setIdTipoAcao(load(temp.getAcaoTipoAcaoId().getIdTipoAcao()));
					lista.set(i, temp);
				}

			} catch (ServiceException ex) {
				throw new ServiceException("Erro ao buscar Status e A\u00E7\u00E3o", ex);
			}
		}
		return lista;
	}
	
	@Override
	@TransactionAttribute(TransactionAttributeType.SUPPORTS)
	public List<TipoAcao> findTipoAcaoPeloStatus(Status status) throws ServiceException, ValidationException {
		
		if (status == null || status.getIdStatus() == null) {
			throw new ValidationException("O status não pode ser nulo.");
		}
		
		try {
			return getDAO().findTipoAcaoPeloStatus(status);
		} catch (DataException e) {
			throw new ServiceException(e);
		}
	}

	private void validaTipoAcao(TipoAcao tipoAcao) throws ServiceException, ValidationException {
		if (tipoAcao==null) {
			throw new ValidationException("O Tipo A\u00E7\u00E3o n\u00E3o pode ser nulo.");
		}
		if (StringUtils.isBlank(tipoAcao.getNome())) {
			throw new ValidationException("O nome do Tipo A\u00E7\u00E3o n\u00E3o pode ser nulo.");
		}
		if (tipoAcao.getFlagAtivo() == null) {
			tipoAcao.setFlagAtivo(Boolean.TRUE);
		}
		tipoAcao.setDataAlteracao(getDataBanco());
	}

	@Override
	public List<TipoAcao> findByExample(TipoAcao tipoAcao, String order) throws ServiceException{
		try {
			return getDAO().findByExample(tipoAcao, order);
		} catch (DataException e) {
			throw new ServiceException(e);
		}
	}
	
}
