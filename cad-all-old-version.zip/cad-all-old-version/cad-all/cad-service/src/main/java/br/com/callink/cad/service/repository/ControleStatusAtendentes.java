package br.com.callink.cad.service.repository;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

import br.com.callink.cad.enumeration.ImagesnMetaEnum;
import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.AtendenteStatus;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.pojo.Equipe;
import br.com.callink.cad.pojo.StatusAtendente;
import br.com.callink.cad.repository.MetasUphCache;
import br.com.callink.cad.repository.RelatorioStatusAtendente;
import br.com.callink.cad.repository.to.CabMetaTO;
import br.com.callink.cad.repository.to.MetaFilaTO;
import br.com.callink.coreutils.util.date.DateUtils;
import br.com.callink.coreutils.util.string.StringHelper;

/**
 *
 * @author brunomt
 */
public final class ControleStatusAtendentes {
	
	
	private ControleStatusAtendentes(){}
	
    public static final int TEMPOEXPIRACONTADOR = 21600;
    
    private static Queue<StatusAtendente> statusAtendenteQueue = new ConcurrentLinkedQueue<StatusAtendente>();
    private static Map<Integer, StatusAtendente> mapStatusAtendente = new ConcurrentHashMap<Integer, StatusAtendente>();
    private static Integer diaRelatorio;
    private static Queue<Atendente> pingAtendente = new ConcurrentLinkedQueue<Atendente>();
    private static Map<Integer, Date> mapPingAtendente = new ConcurrentHashMap<Integer, Date>();
    
    //Controla se um atendente solicitou a alteração de status. Nesse caso não será solicitado um novo caso para o mesmo
    private static Map<Integer, Boolean> listAtendenteAltStatus = new ConcurrentHashMap<Integer, Boolean>();
    
    public static synchronized void addListAtendenteAltStatus(Atendente atendente, boolean solicitaAltStatus) {
    	listAtendenteAltStatus.put(atendente.getIdAtendente(), solicitaAltStatus);
    }
    
    public static synchronized Boolean atendenteSolicitouAlteracaoStatus(Atendente atendente) {
    	Boolean valor = listAtendenteAltStatus.get(atendente.getIdAtendente());
    	
    	if (valor == null) {
    		return Boolean.FALSE;
    	}
    	
    	if(valor) {
    		addListAtendenteAltStatus(atendente, Boolean.FALSE);
    	}
    	
    	return valor;
    }
    
    public static synchronized void offerPingAtendente(Atendente atendente) {
        pingAtendente.offer(atendente);
    }
    
    public static synchronized Atendente pollPingAtendente() {
        return pingAtendente.poll();
    }
    
    public static synchronized void atualizaMap() {
        Integer sizeAtual = pingAtendente.size();
        
        for (int i = 0;i<sizeAtual;i++) {
            Atendente atendente = pollPingAtendente();
            if (atendente != null && atendente.getIdAtendente() != null && atendente.getDataPingAtendente() != null) {
                mapPingAtendente.put(atendente.getIdAtendente(), atendente.getDataPingAtendente());
            }
        }
    }
    
    public static synchronized StatusAtendente getStatusAtendenteAtualPausa(Integer idAtendente) {
    	return mapStatusAtendente.get(idAtendente);
    }
    
    /**
     * Envia a Data para validar o status
     * @param data 
     */
    public static synchronized List<Atendente> validaFinalizaStatusAtendente(Date data, Integer minutosFinalizaSessao) {
        List<Integer> intKey = new ArrayList<Integer>();
        List<Atendente> atendenteRemoveList = new ArrayList<Atendente>();
        
        for (Map.Entry<Integer, Date> entry : mapPingAtendente.entrySet()) {
            if (DateUtils.getMinutesBetweenDates((Date)entry.getValue(), data) > minutosFinalizaSessao) {
                StatusAtendente statusAtendenteRemove = new StatusAtendente();
                Integer idAtendente = entry.getKey();
                Atendente atendente = new Atendente();
                atendente.setIdAtendente(idAtendente);
                
                statusAtendenteRemove.setIdAtendente(atendente);
                statusAtendenteRemove.setFlagInicio(false);
                statusAtendenteRemove.setDataBanco(data);
                
                atendenteRemoveList.add(atendente);
                
                offerStatusAtendente(statusAtendenteRemove);
                
                intKey.add(entry.getKey());
            }
        }
        
        for (Integer key : intKey) {
            mapPingAtendente.remove(key);
        }
        
        return atendenteRemoveList;
    }
    
    public static synchronized void offerStatusAtendente(StatusAtendente statusAtendente) {
        if (statusAtendente != null && 
                statusAtendente.getIdAtendente() != null && 
                statusAtendente.getIdAtendente().getIdAtendente() != null) {
            statusAtendenteQueue.offer(statusAtendente);

            if (statusAtendente.isFlagInicio()) {
            	
                Calendar data = new GregorianCalendar();
                data.setTime(statusAtendente.getDataBanco());
                if (diaRelatorio == null) {
                    diaRelatorio = data.get(Calendar.DAY_OF_MONTH);
                }

                if (diaRelatorio != data.get(Calendar.DAY_OF_MONTH)) {
                    diaRelatorio = data.get(Calendar.DAY_OF_MONTH);
                }

                mapStatusAtendente.put(statusAtendente.getIdAtendente().getIdAtendente(), statusAtendente);
            } else {
                mapStatusAtendente.remove(statusAtendente.getIdAtendente().getIdAtendente());
            }
        }
    }

    public static synchronized StatusAtendente pollStatusAtendente() {
        return statusAtendenteQueue.poll();
    }


    public static synchronized List<StatusAtendente> getMapStatusAtendente(List<ConfiguracaoFila> configuracaoFilaSelecionadoList, List<Atendente> atendenteSelecionadoList, List<Equipe> equipeSelecionadoList, Date dataAtual) {
        List<StatusAtendente> statusAtendenteList = new ArrayList<StatusAtendente>();

        for (Map.Entry<Integer, StatusAtendente> entry : mapStatusAtendente.entrySet()) {
            if (((configuracaoFilaSelecionadoList == null || configuracaoFilaSelecionadoList.isEmpty())
                    && (atendenteSelecionadoList == null || atendenteSelecionadoList.isEmpty())
                    && (equipeSelecionadoList == null || equipeSelecionadoList.isEmpty()))
                    || (entry.getValue().getIdConfiguracaoFila() != null && configuracaoFilaSelecionadoList != null && configuracaoFilaSelecionadoList.contains(entry.getValue().getIdConfiguracaoFila()))
                    || (entry.getValue().getIdAtendente() != null && atendenteSelecionadoList != null && atendenteSelecionadoList.contains(entry.getValue().getIdAtendente()))
                    || (entry.getValue().getIdEquipe() != null && equipeSelecionadoList != null && equipeSelecionadoList.contains(entry.getValue().getIdEquipe()))) {

                StatusAtendente statusAtendente = entry.getValue();
                
                statusAtendente.setTempoDecorrido(formataSegundosEmHMS(DateUtils.getSecondsBetweenDates(statusAtendente.getDataInicio(), dataAtual).longValue()));
                
                CabMetaTO cabMetaTO = MetasUphCache.montaListaByUser(statusAtendente.getIdAtendente().getLogin());
                List<MetaFilaTO> metaFilas = null;
                if(cabMetaTO != null ) {
	                 metaFilas = cabMetaTO.getListaMetaFilaTO();
	                 statusAtendente.setGoal(ImagesnMetaEnum.convertDescToImagem(cabMetaTO.getImageGFinal()));
                } else {
                	 metaFilas = new ArrayList<MetaFilaTO>();
                	 statusAtendente.setGoal(ImagesnMetaEnum.convertDescToImagem(ImagesnMetaEnum.CINZA.getDescricao()));
                }
                
                statusAtendente.setMetasUph(metaFilas);
                statusAtendenteList.add(statusAtendente);
                if (DateUtils.getSecondsBetweenDates(statusAtendente.getDataInicio(), dataAtual) >= TEMPOEXPIRACONTADOR) {
                    StatusAtendente statusAtendenteRemove = new StatusAtendente();
                    statusAtendenteRemove.setIdAtendente(statusAtendente.getIdAtendente());
                    statusAtendenteRemove.setFlagInicio(false);
                    
                    offerStatusAtendente(statusAtendenteRemove);
                }
            }
        }
        return statusAtendenteList;
    }
    
    public static synchronized List<StatusAtendente> getFilterMapStatusAtendenteOrder(List<StatusAtendente> listStatusAtendentes, List<Integer> listIdStatusAtendentes, String order) {
    	
    	List<StatusAtendente> listStatusAtendentesReturn = new ArrayList<StatusAtendente>();
    	if(listStatusAtendentes != null) {
    		
    		for(StatusAtendente statusAtendente : listStatusAtendentes) {
    			
    			if(listIdStatusAtendentes != null && !listIdStatusAtendentes.isEmpty()) {
    				
    				if(statusAtendente.getIdAtendenteStatus() != null && listIdStatusAtendentes.contains(statusAtendente.getIdAtendenteStatus().getIdAtendenteStatus())) {
    					listStatusAtendentesReturn.add(statusAtendente);
    				}
    			} else {
    				
    				listStatusAtendentesReturn.add(statusAtendente);
    			}
    		}
    		
    		if(!StringHelper.isEmpty(order)) {
            	if(order.equalsIgnoreCase("LOGIN")) {
                	Collections.sort(listStatusAtendentesReturn, new Comparator<StatusAtendente>() {

                        public int compare(StatusAtendente st1, StatusAtendente st2) {
                            return st1.getIdAtendente().getLogin().compareTo(st2.getIdAtendente().getLogin());
                        }
                    });
                } else if(order.equalsIgnoreCase("TEMPO_STATUS")) {
                	Collections.sort(listStatusAtendentesReturn, new Comparator<StatusAtendente>() {

                        public int compare(StatusAtendente st1, StatusAtendente st2) {
                            return st2.getTempoDecorrido().compareTo(st1.getTempoDecorrido());
                        }
                    });
                }
            }
    	}
    	
    	return listStatusAtendentesReturn;
    }
    
    public static synchronized RelatorioStatusAtendente getRelatorioStatusAtendente(Atendente atendente, List<StatusAtendente> listStatusAtendentes, Date dataAtual) {
    	
    	Map<Integer, Long> mapTempoDecorritoByIdAtendenteStatus = new HashMap<Integer, Long>();
    	Map<Integer, StatusAtendente> mapStatusAtendenteByIdAtendenteStatus = new HashMap<Integer, StatusAtendente>();
    	
    	
    	RelatorioStatusAtendente relatorioStatusAtendente = new RelatorioStatusAtendente();
    	
    	for(StatusAtendente statusAtendente : listStatusAtendentes) {
    		Long tempoDecorrido = 0L;
    		if(statusAtendente.getIdAtendenteStatus() != null) {
    			
    			AtendenteStatus atendenteStatus = statusAtendente.getIdAtendenteStatus();
    			
    			if(mapTempoDecorritoByIdAtendenteStatus.containsKey(atendenteStatus.getIdAtendenteStatus())) {
    				
    				tempoDecorrido = mapTempoDecorritoByIdAtendenteStatus.get(atendenteStatus.getIdAtendenteStatus());
    				
    				if(statusAtendente.getDataFim() != null) {
    					tempoDecorrido += DateUtils.getSecondsBetweenDates(statusAtendente.getDataInicio(), statusAtendente.getDataFim()).longValue();
    				} else {
    					tempoDecorrido += DateUtils.getSecondsBetweenDates(statusAtendente.getDataInicio(), dataAtual).longValue();
    				}
    				
    				statusAtendente.setTempoDecorrigoLong(tempoDecorrido);
    				statusAtendente.setTempoDecorrido(formataSegundosEmHMS(tempoDecorrido));
    				
    				mapTempoDecorritoByIdAtendenteStatus.put(atendenteStatus.getIdAtendenteStatus(), tempoDecorrido);
    				mapStatusAtendenteByIdAtendenteStatus.put(atendenteStatus.getIdAtendenteStatus(), statusAtendente);
    				
    			} else {
    				
    				tempoDecorrido = 0L;
    				
    				if(statusAtendente.getDataFim() != null) {
    					tempoDecorrido = DateUtils.getSecondsBetweenDates(statusAtendente.getDataInicio(), statusAtendente.getDataFim()).longValue();
    				} else {
    					tempoDecorrido = DateUtils.getSecondsBetweenDates(statusAtendente.getDataInicio(), dataAtual).longValue();
    				}
    				
    				statusAtendente.setTempoDecorrigoLong(tempoDecorrido);
    				statusAtendente.setTempoDecorrido(formataSegundosEmHMS(tempoDecorrido));
    				
    				mapTempoDecorritoByIdAtendenteStatus.put(atendenteStatus.getIdAtendenteStatus(), tempoDecorrido);
    				mapStatusAtendenteByIdAtendenteStatus.put(atendenteStatus.getIdAtendenteStatus(), statusAtendente);
    			}
    		}
    		
    	}
    	
    	Long tempoTotalAtendente = somaList(mapTempoDecorritoByIdAtendenteStatus.values());
    	relatorioStatusAtendente.setAtendente(atendente);
    	relatorioStatusAtendente.setStatusAtendenteList(new ArrayList<StatusAtendente>(mapStatusAtendenteByIdAtendenteStatus.values()));
    	relatorioStatusAtendente.setTempoTotalAtendente(formataSegundosEmHMS(tempoTotalAtendente));
    	
    	return relatorioStatusAtendente;
    }
   
    
	public static String formataSegundosEmHMS(Long segundos) {
        String horaMinutoSegundo = "";
        if (segundos != null) {
            horaMinutoSegundo = segundos < 0 ? "-" : "";
            segundos = Math.abs(segundos);
            Long segundo = Long.valueOf(segundos % 60);
            Long minutos = Long.valueOf(segundos / 60);
            Long minuto = Long.valueOf(minutos % 60);
            Long hora = Long.valueOf(minutos / 60);
            
            StringBuilder sb = new StringBuilder();
            if (hora.toString().length() < 2) {
                sb.append("0");
            }
            sb.append(hora);
            sb.append(":");
            if (minuto.toString().length() < 2) {
                sb.append("0");
            }
            sb.append(minuto);
            sb.append(":");
            if (segundo.toString().length() < 2) {
                sb.append("0");
            }
            sb.append(segundo);
            
            horaMinutoSegundo = sb.toString();
        }
        return horaMinutoSegundo;
    }
	
	private static Long somaList(Collection<Long> listaLong){
		
		Long result = 0L;
		for (Long long1 : listaLong) {
			result = result + long1;
		}
		return result;
	}
	
	
}
