package br.com.callink.gbo.service.test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import br.com.callink.cad.pojo.CabUph;
import br.com.callink.gbo.service.test.service.impl.AcaoServiceTest;
import br.com.callink.gbo.service.test.service.impl.AtendenteServiceTest;
import br.com.callink.gbo.service.test.service.impl.CabUphServiceTest;
import br.com.callink.gbo.service.test.service.impl.ComandoServiceTest;
import br.com.callink.gbo.service.test.service.impl.ConfiguracaoFilaServiceTeste;
import br.com.callink.gbo.service.test.service.impl.EquipeServiceTest;
import br.com.callink.gbo.service.test.service.impl.ParametroComandoServiceTest;
import br.com.callink.gbo.service.test.service.impl.PerfilServiceTest;
import br.com.callink.gbo.service.test.service.impl.StatusServiceTest;


@RunWith(Suite.class)
@Suite.SuiteClasses({ CabUphServiceTest.class
//	ConfiguracaoFilaServiceTeste.class,
//	AcaoServiceTest.class,
//	ComandoServiceTest.class,
//	StatusServiceTest.class,
//	PerfilServiceTest.class,
//	EquipeServiceTest.class,
//	ParametroComandoServiceTest.class,
//	AtendenteServiceTest.class
	})
public class AllServiceTest {

}
