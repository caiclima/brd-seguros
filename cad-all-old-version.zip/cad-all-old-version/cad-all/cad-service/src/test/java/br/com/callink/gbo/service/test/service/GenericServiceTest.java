package br.com.callink.gbo.service.test.service;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import br.com.callink.cad.service.IGenericGboService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.gbo.service.test.util.FactoryUtil;

/**
 * @author rafaelps - swb
 */
@SuppressWarnings("rawtypes")
public abstract class GenericServiceTest<Service extends IGenericGboService> {

    private Class<?> clazz;

    public GenericServiceTest() {
        clazz = getClazz();
    }

    public abstract Class<?> getClazz();

    @SuppressWarnings({"unchecked"})
    protected Service getServiceInstance() {
        return (Service) FactoryUtil.getServiceFactory().getService(
                (Class<?>) clazz);
    }

    @Test
    public void getService() {
        Assert.assertNotNull("Object not found in context...",
                getServiceInstance());
    }

    @Test
    public void findAll() {
        try {
            List entities = getServiceInstance().findAll();

            System.out.println("entities.size() = "
                    + (entities != null ? entities.size() : 0) + " from "
                    + clazz.getName() + "");
        } catch (ServiceException e) {
            e.printStackTrace();
            throw new AssertionError();
        }
    }
}
