package br.com.callink.gbo.service.test.service.impl;

import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.pojo.AcaoComando;
import br.com.callink.cad.pojo.Comando;
import br.com.callink.cad.service.IAcaoService;
import br.com.callink.cad.service.IComandoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.gbo.service.test.service.GenericServiceTest;
import br.com.callink.gbo.service.test.util.FactoryUtil;

public class AcaoServiceTest extends GenericServiceTest<IAcaoService> {

    @Override
    public Class<?> getClazz() {
        return Acao.class;
    }
    private static Acao acao;
    private static AcaoComando acaoComando;

    @Before
    public void insert() {
        acao = new Acao();
        String teste = null;
        try {

            IComandoService comandoServ = (IComandoService) FactoryUtil.getServiceFactory().getService(Comando.class);
            List<Comando> comandos = comandoServ.findAll();
            Comando comando = null;
            if (comandos != null && !comandos.isEmpty()) {
                comando = comandos.get(0);
            }

            acao.setDataCriacao(getServiceInstance().getDataBanco());
            acao.setFlagAtivo(true);
            acao.setNome("Acao Teste");
            acao.setDescricao("Acao inserida atraves de AcaoServiceTest");
            acao.setUrlPage("minha URL");
            acao.setLoginUsuario("swb");

            getServiceInstance().save(acao);

            acaoComando = new AcaoComando(acao, comando);

            getServiceInstance().associa(acaoComando);

            teste = "Teste Executado com Sucesso";
        } catch (ServiceException ex) {
            Logger.getLogger(AcaoServiceTest.class.getName()).log(Level.SEVERE, null, ex);
        }

        Assert.assertNotNull("Falha ao inserir entidade Acao...", teste);
    }

    @After
    public void delete() {
        String valido = null;
        try {
            getServiceInstance().excluiAssociacao(acaoComando);
            getServiceInstance().delete(acao);
            valido = "Valido";
        } catch (ServiceException ex) {
            valido = null;
            ex.printStackTrace();
        }
        Assert.assertNotNull("Falha metodo delete", valido);
    }

    @Test
    public void update() {
        acao.setDataCriacao(new Date());
        acao.setFlagAtivo(false);
        acao.setNome("Acao Teste Update");
        acao.setDescricao("Feito update atraves de AcaoServiceTest");
        String valido = null;
        try {
            getServiceInstance().update(acao);
            valido = "Valido";
        } catch (ServiceException ex) {
            valido = null;
            ex.printStackTrace();
        }
        Assert.assertNotNull("Falha metodo update", valido);
    }

    @Test
    public void load() {
        String valido = null;
        Acao acaoLoad = new Acao();
        acaoLoad.setIdAcao(acao.getPK());
        try {
            acaoLoad = getServiceInstance().load(acaoLoad);
            valido = "Valido";
        } catch (ServiceException ex) {
            valido = null;
            ex.printStackTrace();
        }
        Assert.assertNotNull("Falha metodo load", valido);
    }

    @Test
    public void findByExemplo() {
        Acao acaofind = new Acao();
        acaofind.setFlagAtivo(true);
        acaofind.setNome("Acao Teste");
        acaofind.setDescricao("Acao inserida atraves de AcaoServiceTest");
        String valido = null;
        try {
            List<Acao> list = getServiceInstance().findByExample(acaofind);
            if (list != null && !list.isEmpty()) {
                valido = "Valido";
            }
        } catch (ServiceException ex) {
            valido = null;
            ex.printStackTrace();
        }
        Assert.assertNotNull("Falha metodo findByExeplo", valido);
    }

    @Test
    public void findByComando() throws ServiceException {
        List<AcaoComando> list = getServiceInstance().findByComando(acaoComando.getComando());
        Assert.assertNotNull("Falha ao consultar entidade StatusAcao...", list);
    }

    @Test
    public void findByAcao() throws ServiceException {
        List<AcaoComando> list = getServiceInstance().findByAcao(acao);
        Assert.assertNotNull("Falha ao consultar entidade StatusAcao...", list);
    }
}
