package br.com.callink.gbo.service.test.service.impl;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import br.com.callink.cad.pojo.Agendamento;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.service.IAgendamentoService;
import br.com.callink.cad.service.ICasoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.gbo.service.test.service.GenericServiceTest;
import br.com.callink.gbo.service.test.util.FactoryUtil;


public class AgendamentoServiceTest extends GenericServiceTest<IAgendamentoService> {
    
	private static Agendamento agendamento;
	
	private static Caso caso = null;
	
	@Override
    public Class<?> getClazz() {
        return Agendamento.class;
    }
    
    
    
    @Before
    public void insert() {
        String teste = null;
        try {
            
            if (caso == null) {
            	ICasoService casoServ = (ICasoService) FactoryUtil.getServiceFactory().getService(Caso.class);
                List<Caso> casos = casoServ.findAll();
                caso = casos.get(0);
            }
            
            
            Calendar dataAgendamento = Calendar.getInstance();
            dataAgendamento.set(Calendar.DAY_OF_MONTH, dataAgendamento.get(Calendar.DAY_OF_MONTH) +1);
            
            agendamento = new Agendamento();
            agendamento.setDataAgendamento(dataAgendamento.getTime());
            agendamento.setFlagAtivo(true);
            agendamento.setDataCadastro(new Date());
            agendamento.setLoginUsuario("teste");
            agendamento.setDescricao("teste de agendamento");
            agendamento.setCaso(caso);
            
            
            getServiceInstance().save(agendamento);
            teste = "Teste Executado com Sucesso";
        } catch (ServiceException ex) {
            Logger.getLogger(AgendamentoServiceTest.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        Assert.assertNotNull("Falha ao inserir entidade Perfil...", teste);
    }
    
    @After
    public void delete() {
        String valido = null;
        try {
            getServiceInstance().delete(agendamento);
            valido = "Valido";
        } catch (ServiceException ex) {
            valido = null;
            ex.printStackTrace();
        }
        Assert.assertNotNull("Falha metodo delete", valido);
    }
    
    @Test
    public void update() {
        
        agendamento.setDataAgendamento(new Date());
        agendamento.setFlagAtivo(true);
        agendamento.setDataCadastro(new Date());
        String valido = null;
        try {
            getServiceInstance().update(agendamento);
            valido = "Valido";
        } catch (ServiceException ex) {
            valido = null;
            ex.printStackTrace();
        }
        Assert.assertNotNull("Falha metodo update", valido);
    }
    
    @Test
    public void load() {
        String valido = null;
        Agendamento agendamentoLoad = new Agendamento();
        agendamentoLoad.setIdAgendamento(agendamento.getIdAgendamento());
        try {
            agendamentoLoad = getServiceInstance().load(agendamentoLoad);
            valido = "Valido";
        } catch (ServiceException ex) {
            valido = null;
            ex.printStackTrace();
        }
        Assert.assertNotNull("Falha metodo load", valido);
    }
    
    @Test
    public void findByExemplo() {
        Agendamento agendamentofind = new Agendamento();
        agendamentofind.setDataAgendamento(agendamento.getDataAgendamento());
        agendamentofind.setFlagAtivo(true);
        agendamentofind.setDataCadastro(agendamento.getDataCadastro());
        String valido = null;
        try {
            List<Agendamento> list = getServiceInstance().findByExample(agendamentofind);
            if (list != null && !list.isEmpty()) {
                valido = "Valido";
            }
        } catch (ServiceException ex) {
            valido = null;
            ex.printStackTrace();
        }
        Assert.assertNotNull("Falha metodo findByExeplo", valido);
    }
    
    @Test
    public void buscaPeloCaso() throws ServiceException{
    	Caso caso = new Caso(43177);
    	Assert.assertNotNull(getServiceInstance().buscaPeloCaso(caso));
    }
}
