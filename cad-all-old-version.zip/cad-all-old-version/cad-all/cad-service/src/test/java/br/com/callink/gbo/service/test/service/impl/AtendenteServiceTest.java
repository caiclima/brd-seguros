package br.com.callink.gbo.service.test.service.impl;

import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.pojo.Equipe;
import br.com.callink.cad.pojo.Perfil;
import br.com.callink.cad.service.IAtendenteService;
import br.com.callink.cad.service.IEquipeService;
import br.com.callink.cad.service.IPerfilService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.impl.ConfiguracaoFilaService;
import br.com.callink.gbo.service.test.service.GenericServiceTest;
import br.com.callink.gbo.service.test.util.FactoryUtil;

public class AtendenteServiceTest extends GenericServiceTest<IAtendenteService> {

	private static Atendente atendente;
	
	private static Equipe equipe = null;
	private static Perfil perfil = null;
	
    @Override
    public Class<?> getClazz() {
        return Atendente.class;
    }
    

    @Before
    public void insert() {

        String teste = null;
        try {
            atendente = new Atendente();

            if(equipe == null) {
	            IEquipeService equipeServ = (IEquipeService) FactoryUtil.getServiceFactory().getService(Equipe.class);
	            List<Equipe> equipes = equipeServ.findAtivos();
	            if (equipes != null && !equipes.isEmpty()) {
	                equipe = equipes.get(0);
	               
	            }
            }
            equipe.setIdEquipe(equipe.getIdEquipe());            

            if(perfil == null) {
            	IPerfilService perfilServ = (IPerfilService) FactoryUtil.getServiceFactory().getService(Perfil.class);
                perfil = perfilServ.findAll().get(0);
            }

            atendente.setDataCriacao(new Date());
            atendente.setEquipe(equipe);
            atendente.setFlagAtivo(true);
            atendente.setLogin("m");
            atendente.setPerfil(perfil);
            getServiceInstance().save(atendente);
            teste = "Teste Executado com Sucesso";
        } catch (ServiceException ex) {
            Logger.getLogger(AtendenteServiceTest.class.getName()).log(Level.SEVERE, null, ex);
        }
        Assert.assertNotNull("Falha ao inserir entidade Perfil...", teste);
    }

    @After
    public void delete() {
        String valido = null;
        try {
            getServiceInstance().delete(atendente);
            valido = "Valido";
        } catch (ServiceException ex) {
            valido = null;
            ex.printStackTrace();
        }
        Assert.assertNotNull("Falha metodo delete", valido);
    }

    @Test
    public void update() throws ServiceException {
        atendente.setDataCriacao(new Date());
        atendente.setFlagAtivo(true);
        atendente.setLogin("Login teste Update");
        String valido = null;
        try {
            getServiceInstance().update(atendente);
            valido = "Valido";
        } catch (ServiceException ex) {
            valido = null;
            ex.printStackTrace();
        }
        Assert.assertNotNull("Falha metodo update", valido);
    }

    @Test
    public void load() {
        Atendente atendenteLoad = new Atendente();
        atendenteLoad.setIdAtendente(atendente.getIdAtendente());
        String valido = null;
        try {
            getServiceInstance().load(atendenteLoad);
            valido = "Valido";
        } catch (ServiceException ex) {
            valido = null;
            ex.printStackTrace();
        }
        Assert.assertNotNull("Falha metodo load", valido);
    }

    @Test
    public void findByExemplo() {
        Atendente atendenteFind = new Atendente();
        atendenteFind.setFlagAtivo(true);
        atendenteFind.setLogin("Login teste");
        Atendente.class.getFields();

        String valido = null;
        try {
            List<Atendente> list = getServiceInstance().findByExample(atendenteFind);
            if (list != null && !list.isEmpty()) {
                valido = "Valido";
            }
        } catch (ServiceException ex) {
            valido = null;
            ex.printStackTrace();
        }
        Assert.assertNotNull("Falha metodo findByExeplo", valido);
    }
    
    @Test
    public void findByExampleAll() throws ServiceException {
    	List<Atendente> atendenteList = getServiceInstance().findByExampleAll(atendente);
    	Assert.assertNotNull(atendenteList.get(0).getEquipe().getNome());
    }
    
	@Test
    public void buscaPorFila() throws ServiceException{
    	List<ConfiguracaoFila> configuracaoFilaList = new ConfiguracaoFilaService().findAtivos(null);
    	if(!configuracaoFilaList.isEmpty()){
    		List<Atendente> atendenteList = getServiceInstance().buscaPorFila(configuracaoFilaList.get(0));
    		Assert.assertNotNull(atendenteList);
    	}
    }
	
	@Test
	public void buscaAtendentesPorEquipe() throws ServiceException {
		
		Equipe equipe = new Equipe();
		equipe.setPK(2981);
		getServiceInstance().buscaAtendentesPorEquipe(equipe);
	}
	
    
}
