package br.com.callink.gbo.service.test.service.impl;

import br.com.callink.cad.pojo.AtendenteStatus;
import br.com.callink.cad.service.IAtendenteStatusService;
import br.com.callink.gbo.service.test.service.GenericServiceTest;

/**
 *
 * @author brunomt
 */
public class AtendenteStatusServiceTest extends GenericServiceTest<IAtendenteStatusService> {

    @Override
    public Class<?> getClazz() {
        return AtendenteStatus.class;
    }
    
}
