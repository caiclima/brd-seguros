package br.com.callink.gbo.service.test.service.impl;

import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.AtendimentoCaso;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.pojo.Status;
import br.com.callink.cad.service.IAtendenteService;
import br.com.callink.cad.service.IAtendimentoCasoService;
import br.com.callink.cad.service.ICasoService;
import br.com.callink.cad.service.IConfiguracaoFilaService;
import br.com.callink.cad.service.IStatusService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.gbo.service.test.service.GenericServiceTest;
import br.com.callink.gbo.service.test.util.FactoryUtil;

public class AtendimentoCasoServiceTest extends GenericServiceTest<IAtendimentoCasoService> {

	private static Caso caso = null;
	private static Atendente atendente = null;
	private static Status status = null;
	private static ConfiguracaoFila configuracaoFila = null;
	
	
    @Override
    public Class<?> getClazz() {
        return AtendimentoCaso.class;
    }
    private static AtendimentoCaso atendimentoCaso;
    
    private static List<AtendimentoCaso> atendimentoCasoList;

    @Before
    public void insert() throws ServiceException {
    	
    	if(atendimentoCasoList == null) {
    		atendimentoCasoList = getServiceInstance().findAll();
    	}
    	
        String teste = null;
        try {
            
            if (caso == null) {
            	ICasoService casoServ = (ICasoService) FactoryUtil.getServiceFactory().getService(Caso.class);
                List<Caso> casos = casoServ.findAll();
                caso = casos.get(0);
            }
            
            if (atendente == null) {
            	IAtendenteService atendenteServ = (IAtendenteService) FactoryUtil.getServiceFactory().getService(Atendente.class);
                List<Atendente> atendentes = atendenteServ.findAtivos();
                atendente = atendentes.get(0);
            }

            if (status == null) {
            	IStatusService statusServ = (IStatusService) FactoryUtil.getServiceFactory().getService(Status.class);
                List<Status> statusList = statusServ.findAll();
                status = statusList.get(0);
            }
            
            if(configuracaoFila == null) {
            	IConfiguracaoFilaService configuracaoFilaService = (IConfiguracaoFilaService) FactoryUtil.getServiceFactory().getService(ConfiguracaoFila.class);
                configuracaoFila = configuracaoFilaService.findAtivos(null).get(0);
            }
            atendimentoCaso = new AtendimentoCaso();
            atendimentoCaso.setCaso(caso);
            atendimentoCaso.setConfiguracaoFila(configuracaoFila);
            atendimentoCaso.setDataMarcacao(new Date());
            atendimentoCaso.setFlgInicio(Boolean.TRUE);
            atendimentoCaso.setAtendente(atendente);
            atendimentoCaso.setStatus(status);

            getServiceInstance().save(atendimentoCaso);
            teste = "Teste Executado com Sucesso";
        } catch (ServiceException ex) {
            Logger.getLogger(AtendimentoCasoServiceTest.class.getName()).log(Level.SEVERE, null, ex);
        }

        Assert.assertNotNull("Falha ao inserir entidade Perfil...", teste);
    }

    @After
    public void delete() {
        String valido = null;
        try {
            getServiceInstance().delete(atendimentoCaso);
            valido = "Valido";
        } catch (ServiceException ex) {
            valido = null;
            ex.printStackTrace();
        }
        Assert.assertNotNull("Falha metodo delete", valido);
    }

    @Test(expected=ServiceException.class)
    public void update() throws ServiceException {
    	//Não será possível fazer alterações na marcação do atendimento.
        atendimentoCaso.setFlgInicio(Boolean.FALSE);
        atendimentoCaso.setDataMarcacao(new Date());
        getServiceInstance().update(atendimentoCaso);
    }

    @Test
    public void load() {
        String valido = null;
        AtendimentoCaso atendimentoCasoLoad = new AtendimentoCaso();
        atendimentoCasoLoad.setIdAtendimentoCaso(atendimentoCaso.getPK());
        try {
            atendimentoCasoLoad = getServiceInstance().load(atendimentoCasoLoad);
            valido = "Valido";
        } catch (ServiceException ex) {
            valido = null;
            ex.printStackTrace();
        }
        Assert.assertNotNull("Falha metodo load", valido);
    }
    
    @Test
    public void findAtendimentoCasoByCaso() throws ServiceException{
		Assert.assertNotNull(getServiceInstance().findAtendimentoCasoByCaso(atendimentoCasoList.get(0).getCaso()));
    }
    
    @Test
    public void calculaTempoAtendimentoByCaso () throws ServiceException{
		Assert.assertNotNull(getServiceInstance().calculaTempoAtendimentoByCaso(atendimentoCasoList.get(0).getCaso()));
    }
}
