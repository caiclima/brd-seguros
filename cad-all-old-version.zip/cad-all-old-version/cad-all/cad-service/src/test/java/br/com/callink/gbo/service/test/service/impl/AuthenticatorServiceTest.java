/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.gbo.service.test.service.impl;

import org.junit.Test;

import br.com.callink.cad.service.IAuthenticatorService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.impl.AuthenticatorService;
import br.com.callink.coreutils.infra.util.BeanFactory;

/**
 *
 * @author brunomt
 */
public class AuthenticatorServiceTest {
    
    @Test
    public void autenticaUsuario() throws ServiceException {
        try {
            IAuthenticatorService authencatorService = (IAuthenticatorService) BeanFactory.getInstance().getBean("authenticatorService");
            authencatorService.authentica("desenvolvimento", "BradescoCallink01", AuthenticatorService.AD);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    
}
