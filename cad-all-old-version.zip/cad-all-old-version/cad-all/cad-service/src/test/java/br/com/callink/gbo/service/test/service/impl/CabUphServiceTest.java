/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.gbo.service.test.service.impl;

import java.util.Date;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;

import br.com.callink.cad.pojo.CabUph;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.service.ICabUphService;
import br.com.callink.cad.service.IConfiguracaoFilaService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.gbo.service.test.service.GenericServiceTest;
import br.com.callink.gbo.service.test.util.FactoryUtil;

/**
 *
 * @author miller
 * 
 */
public class CabUphServiceTest extends GenericServiceTest<ICabUphService> {

    private static CabUph cabUph;
    private static ConfiguracaoFila  configuracaofila  = null;
    
    @Override
    public Class<?> getClazz() {
        return CabUph.class;
    }
    
    
    @Before
    public void insert() throws ServiceException {
        
        cabUph = new CabUph();

        IConfiguracaoFilaService configuracaoFilaService = 
                (IConfiguracaoFilaService) FactoryUtil.getServiceFactory().getService(ConfiguracaoFila.class);
         
        configuracaofila = configuracaoFilaService.findAll().get(0);
        
        cabUph.setDescricao("descricao");
        cabUph.setDataInicial(new Date());
        cabUph.setDataFinal(new Date());
        cabUph.setConfiguracaoFila(configuracaofila);
        cabUph.setLogiUsuario("swb");
        
        getServiceInstance().save(cabUph);

        Assert.assertNotNull(cabUph.getIdCabUph());
    }
    
    @After
    public void delete() throws ServiceException {
    	getServiceInstance().delete(cabUph);
    }

}
