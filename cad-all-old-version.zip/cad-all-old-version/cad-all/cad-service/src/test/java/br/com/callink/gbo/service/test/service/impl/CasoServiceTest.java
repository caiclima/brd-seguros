package br.com.callink.gbo.service.test.service.impl;

import java.util.Date;
import java.util.List;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.pojo.Status;
import br.com.callink.cad.service.IAtendenteService;
import br.com.callink.cad.service.ICasoService;
import br.com.callink.cad.service.IConfiguracaoFilaService;
import br.com.callink.cad.service.IStatusService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.gbo.service.test.service.GenericServiceTest;
import br.com.callink.gbo.service.test.util.FactoryUtil;

public class CasoServiceTest extends GenericServiceTest<ICasoService> {

	private static Caso caso;
	
	private static List<Caso> casoList;
	private static List<Atendente> atendenteList;

	@Override
	public Class<?> getClazz() {
		return Caso.class;
	}

	@Before
	public void preparaObjeto() throws ServiceException {
		
		if(casoList == null) {
			casoList = getServiceInstance().findAll();
		}
		if(atendenteList == null) {
			IAtendenteService atendenteService = (IAtendenteService) FactoryUtil.getServiceFactory().getService(Atendente.class);
			atendenteList = atendenteService.findAll();
		}
		
		caso = preparaCaso();

		getServiceInstance().save(caso);
		Assert.assertNotNull("Falha ao salvar entidade Caso...", caso.getPK());
	}

	private Caso preparaCaso() throws ServiceException {
		Caso casoPersist = new Caso();

		IStatusService statusService = (IStatusService) FactoryUtil.getServiceFactory().getService(Status.class);
		casoPersist.setStatus(statusService.findAll().get(0));
		casoPersist.setDataAbertura(new Date());
		casoPersist.setFlagClassifica(false);
		casoPersist.setFlagFinalizado(false);

//		IConfiguracaoFilaService configuracaoFilaService = (IConfiguracaoFilaService) FactoryUtil.getServiceFactory().getService(ConfiguracaoFila.class);
//		casoPersist.setConfiguracaoFila(configuracaoFilaService.findAtivos().get(0));
		
		return casoPersist;
	}

	@After
	public void deletaObjeto() throws ServiceException {
		getServiceInstance().delete(caso);
	}

	@Test
	public void update() throws ServiceException {
		caso.setDataEncerramento(new Date());
		getServiceInstance().update(caso);
	}

	@Test
	public void findById() throws ServiceException {
		Caso c = getServiceInstance().findByPk(caso);

		Assert.assertNotNull("Falha ao buscar entidade Caso...", c.getPK());
	}

	@Test
	public void findByExample() throws ServiceException {
		Caso casoFind = new Caso();
		casoFind.setIdCaso(caso.getIdCaso());
		List<Caso> casoList = getServiceInstance().findByExample(casoFind);
		Assert.assertNotNull("Falha ao buscar entidade Caso...", casoList);
	}
	@Test
	public void buscaCasosFiltroPorFilaSemAtendente() throws ServiceException {
		IConfiguracaoFilaService configuracaoFilaService = (IConfiguracaoFilaService) FactoryUtil.getServiceFactory().getService(ConfiguracaoFila.class);
		List<ConfiguracaoFila> configuracaoFilaList = configuracaoFilaService.buscaFilaAtivaPorPrioridade();
		getServiceInstance().buscaCasosFiltroPorFilaSemAtendente(configuracaoFilaList.get(0));
	}
	
	@Test
	public void buscaCasosOrdernadosPorFilaSemAtendente() throws ServiceException {
		IConfiguracaoFilaService configuracaoFilaService = (IConfiguracaoFilaService) FactoryUtil.getServiceFactory().getService(ConfiguracaoFila.class);
		List<ConfiguracaoFila> configuracaoFilaList = configuracaoFilaService.findAll();
		getServiceInstance().buscaCasosOrdernadosPorFilaSemAtendente(configuracaoFilaList.get(0), 5);
	}

	@Test
	public void testaSla() throws ServiceException {
		Caso cas = casoList.get(0);
		cas = getServiceInstance().calculaSla(cas);
		Assert.assertNotNull("Falha ao calcular Sla entidade Caso...", cas.getSlaEmMinutos());
	}

	@Test
	public void testaSlaList() throws ServiceException {
		if (casoList.size() > 10) {
			casoList = casoList.subList(0, 10);
		}
		casoList = getServiceInstance().carregaSlas(casoList);
		Caso cas = casoList.get(0);
		Assert.assertNotNull("Falha ao calcular Sla entidade Caso...", cas.getSlaEmMinutos());
	}
	
	@Test
	public void buscaTodosCasosAtivosAtendente() throws ServiceException {
		List<Caso> casoList = getServiceInstance().buscaTodosCasosAtivosAtendente(atendenteList.get(0));
		
		Assert.assertNotNull(casoList);
	}
	
	@Test
	public void buscaCasoAgendado() throws ServiceException {
		getServiceInstance().buscaCasoAgendado(atendenteList.get(0));
	}
	
	@Test
	public void buscaCasoFimSLA() throws ServiceException {
		List<Caso> casoList = getServiceInstance().buscaCasosSLAFimDia();
	}
	
	@Test
	public void buscaCasoFimSLAData() throws ServiceException {
		List<Caso> casoList = getServiceInstance().buscaCasosSLAFimDia(new Date());
	}
	
}
