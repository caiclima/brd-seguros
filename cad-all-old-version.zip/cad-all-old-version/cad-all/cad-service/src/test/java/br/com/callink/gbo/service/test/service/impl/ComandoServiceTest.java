package br.com.callink.gbo.service.test.service.impl;

import java.util.Date;
import java.util.List;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import br.com.callink.cad.pojo.Comando;
import br.com.callink.cad.service.IComandoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.gbo.service.test.service.GenericServiceTest;

public class ComandoServiceTest extends GenericServiceTest<IComandoService> {

    @Override
    public Class<?> getClazz() {
        return Comando.class;
    }
    private static Comando comando;

    @Before
    public void insert() {
        comando = new Comando();
        comando.setDataCriacao(new Date());
        comando.setFlagAtivo(false);
        comando.setNome("Comando Teste");
        comando.setDescricao("Comando inserido atraves de ComandoServiceTest");
        comando.setBeanName("br.com.callink.gbo.pojo.Comando");
        try {
            getServiceInstance().save(comando);
        } catch (ServiceException ex) {
            ex.printStackTrace();
        }
        Assert.assertNotNull("Falha metodo save", comando.getPK());
    }

    @Test
    public void findByExemplo() {
        Comando cmdo = new Comando();
        cmdo.setFlagAtivo(false);
        cmdo.setNome("Comando Teste");
        cmdo.setDescricao("Comando inserido atraves de ComandoServiceTest");
        cmdo.setBeanName("br.com.callink.gbo.pojo.Comando");
        String valido = null;
        try {
            List<Comando> list = getServiceInstance().findByExample(cmdo);
            if (list != null && !list.isEmpty()) {
                valido = "Valido";
            }

        } catch (ServiceException ex) {
            valido = null;
            ex.printStackTrace();
        }
        Assert.assertNotNull("Falha metodo findByExeplo", valido);
    }

    @Test
    public void load() {

        Comando cmdo = new Comando();
        cmdo.setIdComando(comando.getPK());
        String valido = null;
        try {
            getServiceInstance().load(cmdo);
            valido = "Valido";
        } catch (ServiceException ex) {
            valido = null;
            ex.printStackTrace();
        }
        Assert.assertNotNull("Falha metodo load", valido);
    }

    @Test
    public void update() {
        comando.setFlagAtivo(false);
        comando.setDataCriacao(new Date());
        comando.setNome("Teste Update");
        comando.setDescricao("Comando inserida atraves de ComandoServiceTest");
        comando.setBeanName("br.com.callink.gbo.pojo.Comando");
        String valido = null;
        try {
            getServiceInstance().update(comando);
            valido = "Valido";
        } catch (ServiceException ex) {
            valido = null;
            ex.printStackTrace();
        }
        Assert.assertNotNull("Falha metodo update", valido);
    }

    @After
    public void delete() {
        String valido = null;
        try {
            getServiceInstance().delete(comando);
            valido = "Valido";
        } catch (ServiceException ex) {
            valido = null;
            ex.printStackTrace();
        }
        Assert.assertNotNull("Falha metodo delete", valido);
    }
}
