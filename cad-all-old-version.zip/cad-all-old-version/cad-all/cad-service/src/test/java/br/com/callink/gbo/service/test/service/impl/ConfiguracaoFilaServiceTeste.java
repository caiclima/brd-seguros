package br.com.callink.gbo.service.test.service.impl;

import java.util.List;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.pojo.EquipeFila;
import br.com.callink.cad.service.IAtendenteService;
import br.com.callink.cad.service.IConfiguracaoFilaService;
import br.com.callink.cad.service.IEquipeFilaService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.gbo.service.test.service.GenericServiceTest;
import br.com.callink.gbo.service.test.util.FactoryUtil;

public class ConfiguracaoFilaServiceTeste extends GenericServiceTest<IConfiguracaoFilaService> {

    private static ConfiguracaoFila configuracaoFila;
    
    private static List<ConfiguracaoFila> configuracaoFilas;

    @Override
    public Class<?> getClazz() {
        return ConfiguracaoFila.class;
    }

    @Before
    public void preparaObjeto() throws ServiceException {
    	
    	if(configuracaoFilas == null) {
    		configuracaoFilas = getServiceInstance().buscaFilaAtivaPorPrioridade();
    	}
    	
        configuracaoFila = new ConfiguracaoFila();
        configuracaoFila.setNome("FILARECLAMACAO");
        configuracaoFila.setDescricao("Fila dos atendentes de reclamações");
        configuracaoFila.setFlagAtivo(true);
        configuracaoFila.setLoginUsuario("teste");

        getServiceInstance().save(configuracaoFila);
        Assert.assertNotNull("Falha ao inserir entidade ConfiguracaoFila...", configuracaoFila.getPK());
    }

    @Test
    public void findById() throws ServiceException {
        ConfiguracaoFila confFila = getServiceInstance().findByPk(configuracaoFila);
        Assert.assertNotNull("Falha ao inserir entidade ConfiguracaoFila...", confFila.getPK());
    }
    
    @Test
    public void buscaFilaAtivaPorPrioridade() throws ServiceException {
    	Assert.assertNotNull(configuracaoFilas);
    }
    
    @Test
    public void buscaFilaAtivaBuildPorPrioridade() throws ServiceException {
    	List<ConfiguracaoFila> configuracaoFilas = getServiceInstance().buscaFilaBuildPorPrioridade();
    	Assert.assertNotNull(configuracaoFilas);
    }
    
    @Test 
    public void aumentarPrioridade() throws ServiceException {
    	ConfiguracaoFila configuracaoFila = configuracaoFilas.get(0);
    	
    	getServiceInstance().aumentarPrioridade(configuracaoFila, "swb.bruno");
    }
    
    @Test
    public void diminuirPrioridade() throws ServiceException {
    	ConfiguracaoFila configuracaoFila = configuracaoFilas.get(0);
    	
    	getServiceInstance().diminuirPrioridade(configuracaoFila, "swb.bruno");
    }
    
    @Test
    public void classificaCasos() throws ServiceException {
    	deletaObjeto();
    	getServiceInstance().classificaCasos();
    }

    @Test
    public void buscaProximaFilaAtendimentoAtendente() throws ServiceException {
    	IEquipeFilaService equipeFilaService = (IEquipeFilaService) FactoryUtil.getServiceFactory().getService(EquipeFila.class);
    	List<EquipeFila> equipeFilaList = equipeFilaService.findAll();
    	IAtendenteService atendenteService = (IAtendenteService) FactoryUtil.getServiceFactory().getService(Atendente.class);
    	Atendente atendente = new Atendente();
    	atendente.setEquipe(equipeFilaList.get(0).getEquipe());
    	List<Atendente> atendenteList = atendenteService.findByExample(atendente);
    	List<ConfiguracaoFila> configuracaoFilaList = getServiceInstance().buscaProximaFilaAtendimentoAtendente(atendenteList.get(0));
    	Assert.assertNotNull(configuracaoFilaList);
    }
    
    @After
    public void deletaObjeto() throws ServiceException {
        getServiceInstance().delete(configuracaoFila);
    }
}
