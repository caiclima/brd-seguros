package br.com.callink.gbo.service.test.service.impl;

import java.util.Date;
import java.util.List;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.Email;
import br.com.callink.cad.pojo.GrupoEmail;
import br.com.callink.cad.service.IEmailService;
import br.com.callink.cad.service.IGrupoEmailService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.util.ReceiveMail;
import br.com.callink.gbo.service.test.service.GenericServiceTest;
import br.com.callink.gbo.service.test.util.FactoryUtil;

/**
 *
 * @author Luiz Gustavo (luizgf@swb.com.br)
 */
public class EmailServiceTest extends GenericServiceTest<IEmailService> {

    private static Email email;

    @Override
    public Class<?> getClazz() {
        return Email.class;
    }

    @Before
    public void preparaObjeto() throws ServiceException {
        email = criaObjeto();
        getServiceInstance().save(email);
        Assert.assertNotNull("Falha ao salvar entidade Caso...", email.getPK());
    }

    private Email criaObjeto() throws ServiceException {
        Email objEmail = new Email();
        objEmail.setRemetente("teste remetente");
        objEmail.setDestinatario("teste destinatario");
        objEmail.setAssunto("assunto teste");
        objEmail.setDataEnvio(new Date());
        objEmail.setConteudo("conteudo email");
        IGrupoEmailService geService = (IGrupoEmailService) FactoryUtil.getServiceFactory().getService(GrupoEmail.class);
        List<GrupoEmail> grupoEmailList = geService.findAll();
        GrupoEmail grupoEmail = null;
        if (grupoEmailList != null && !grupoEmailList.isEmpty()) {
            grupoEmail = grupoEmailList.get(0);
        }
        objEmail.setGrupoEmail(grupoEmail);
        return objEmail;
    }

    @After
    public void deletaObjeto() throws ServiceException {
        getServiceInstance().delete(email);
    }

    @Test
    public void findById() throws ServiceException {
        Email emailFind = (Email) getServiceInstance().findByPk(email);
        Assert.assertNotNull("Falha ao salvar entidade Email...", emailFind.getPK());
    }

    @Test
    public void findByExample() throws ServiceException {
        Email emailFind = new Email();
        emailFind.setAssunto(email.getAssunto());
        List<Email> emailList = getServiceInstance().findByExample(emailFind);
        Assert.assertNotNull("Falha ao busca entidade Email...", emailList);
    }

    @Test
    public void lerEmails() throws Exception {

        ReceiveMail receiveMail = new ReceiveMail(getServiceInstance().recebeEmailProperties());
        getServiceInstance().salvaReceivedMails(receiveMail.listaEmail());
        receiveMail.close();
    }

    @Test
    public void buscaEmailsCaso() throws ServiceException {
        Caso caso = new Caso();
        caso.setIdCaso(168668);
        List<Email> emails = getServiceInstance().findEmailsFromCaso(caso);
        Assert.assertNotNull(emails);
    }
}
