package br.com.callink.gbo.service.test.service.impl;

import java.util.Properties;

import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.URLName;

import com.sun.mail.pop3.POP3Store;

public class EmailTeste {

//	    protected Logger log = Logger.getLogger(getClass());
	    private String username;
	    private String password;
	    private String server;
	    private String port;
//	    private TypeProtocol typeProtocol;
	    private Store store = null;
	    private Folder folder;
	    private Message[] messages;
	    private Folder[] folders;
	    private Session session;
		/**
		 * @param args
		 * @throws MessagingException 
		 */
	    
//	    @Test
		public void conectaServer() throws MessagingException {
	    	try {
	        String SSL_FACTORY = "javax.net.ssl.SSLSocketFactory";

	        Properties props = new Properties();
	        props.setProperty("mail.store.protocol", "pop3");
	        props.setProperty("mail.pop3.socketFactory.class", SSL_FACTORY);
	        props.setProperty("mail.pop3.socketFactory.fallback", "false");
	        props.put("mail.smtp.port", "995");
	        props.put("mail.pop3.disabletop", "true");

	        URLName url = new URLName("pop3", "webmail.ihostexchange.net", Integer.parseInt("995"), "", "callink@datora.net", "C@11ink");
	        
	        System.out.println("Conectando Servidor");
	        
	        session = Session.getInstance(props, null);
	        session.setDebug(true);
	        store = new POP3Store(session, url);
	        store.connect();

	        System.out.println("Concectado ao servidor ... desconectando");
	        
	        store.close();
	        
	        System.out.println("Desconectando...");
	    	} catch (Exception e) {
				e.printStackTrace();
			}
		}

}

	
