package br.com.callink.gbo.service.test.service.impl;

import java.util.Date;
import java.util.List;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import br.com.callink.cad.pojo.EnderecoEmail;
import br.com.callink.cad.service.IEnderecoEmailService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.gbo.service.test.service.GenericServiceTest;

/**
 *
 * @author Luiz Gustavo (luizgf@swb.com.br)
 */
public class EnderecoEmailServiceTest extends GenericServiceTest<IEnderecoEmailService> {
    private static EnderecoEmail enderecoEnderecoEmail;
	
	@Override
	public Class<?> getClazz() {
		return EnderecoEmail.class;
	}
	
	@Before
	public void preparaObjeto() throws ServiceException {
		enderecoEnderecoEmail = criaObjeto();
		getServiceInstance().save(enderecoEnderecoEmail);
		Assert.assertNotNull("Falha ao salvar entidade Caso...", enderecoEnderecoEmail.getPK());		
	}

	private EnderecoEmail criaObjeto() throws ServiceException {
		EnderecoEmail objEnderecoEmail = new EnderecoEmail();
		objEnderecoEmail.setDataCriacao(new Date());
                objEnderecoEmail.setFlagAtivo(Boolean.TRUE);
                objEnderecoEmail.setDescricao("Endereco email teste");
                objEnderecoEmail.setEnderecoEmail("email@email.com");
                return objEnderecoEmail;
	}
	
	@After
	public void deletaObjeto() throws ServiceException {
		getServiceInstance().delete(enderecoEnderecoEmail);
	}
	
	@Test
	public void findById() throws ServiceException {
		EnderecoEmail enderecoEnderecoEmailFind = (EnderecoEmail) getServiceInstance().findByPk(enderecoEnderecoEmail);
		Assert.assertNotNull("Falha ao salvar entidade EnderecoEmail...", enderecoEnderecoEmailFind.getPK());
	}
	
	@Test
	public void findByExample() throws ServiceException {
		EnderecoEmail enderecoEnderecoEmailFind = new EnderecoEmail();
		enderecoEnderecoEmailFind.setEnderecoEmail(enderecoEnderecoEmail.getEnderecoEmail());
		List<EnderecoEmail> enderecoEnderecoEmailList = getServiceInstance().findByExample(enderecoEnderecoEmailFind);
		Assert.assertNotNull("Falha ao busca entidade EnderecoEmail...", enderecoEnderecoEmailList);
	}
	
	@Test
	public void update() throws ServiceException {
		enderecoEnderecoEmail.setDescricao("update no enderecoEnderecoEmail");
		getServiceInstance().update(enderecoEnderecoEmail);
		EnderecoEmail enderecoEnderecoEmailValido = (EnderecoEmail) getServiceInstance().findByPk(enderecoEnderecoEmail);
		Assert.assertEquals(enderecoEnderecoEmail.getDescricao(), enderecoEnderecoEmailValido.getDescricao());
	}
}
