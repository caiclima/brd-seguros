package br.com.callink.gbo.service.test.service.impl;

import java.util.List;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.pojo.Equipe;
import br.com.callink.cad.pojo.EquipeFila;
import br.com.callink.cad.service.IConfiguracaoFilaService;
import br.com.callink.cad.service.IEquipeFilaService;
import br.com.callink.cad.service.IEquipeService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.gbo.service.test.service.GenericServiceTest;
import br.com.callink.gbo.service.test.util.FactoryUtil;

public class EquipeFilaServiceTest extends GenericServiceTest<IEquipeFilaService> {

	private static EquipeFila equipeFila;
	
	private static Equipe equipe = null;
	private static ConfiguracaoFila configuracaoFila  = null;
	
	@Override 
	public Class<?> getClazz() {
		return EquipeFila.class;
	}
	
	@Before 
	public void preparaObjeto() throws ServiceException {
		
		equipeFila = geraEquipeFila();
		EquipeFila ef = getServiceInstance().buscaByEquipeAndConfiguracaoFila(equipeFila.getEquipe(), equipeFila.getConfiguracaoFila());
		if(ef == null){
			getServiceInstance().save(equipeFila);
		} else {
			equipeFila = ef;
		}
		
		
		Assert.assertNotNull("Falha ao salvar entidade EquipeFila...", equipeFila.getPK());
	}

	private EquipeFila geraEquipeFila() throws ServiceException {
		EquipeFila eqFila = new EquipeFila();
		eqFila.setQuantidadeCasoFila(100);
		
		if(equipe == null) {
			IEquipeService equipeService = (IEquipeService) FactoryUtil.getServiceFactory().getService(Equipe.class);
			equipe = equipeService.findAll().get(0);
		}
		eqFila.setEquipe(equipe);
		
		if(configuracaoFila == null) {
			IConfiguracaoFilaService confFilaService = (IConfiguracaoFilaService) FactoryUtil.getServiceFactory().getService(ConfiguracaoFila.class);
			configuracaoFila = confFilaService.findAll().get(0);
		}
		
		eqFila.setConfiguracaoFila(configuracaoFila);
		
		return eqFila;
	}
	
	@After
	public void deletaObjeto() throws ServiceException {
		getServiceInstance().delete(equipeFila);
	}
	
	@Test
	public void findById() throws ServiceException {
		EquipeFila  eqFila = getServiceInstance().findByPk(equipeFila);
		
		Assert.assertNotNull("Falha ao buscar entidade EquipeFila...", eqFila.getPK());
	}
	
	@Test
	public void findByExample() throws ServiceException {
		EquipeFila eqFila = new EquipeFila();
		eqFila.setEquipe(equipeFila.getEquipe());		
		
		List<EquipeFila> eqFilaList = getServiceInstance().findByExample(eqFila);
		
		Assert.assertNotNull("Falha ao buscar entidade EquipeFila...", eqFilaList);
	}
	
	@Test
	public void buscaEquipeFilaPelaPrioridade() throws ServiceException {
		List<EquipeFila> equipeFilas = getServiceInstance().findAll();
		IEquipeService equipeService = (IEquipeService) FactoryUtil.getServiceFactory().getService(Equipe.class);
		Equipe equipe = equipeService.findByPk(equipeFilas.get(0).getEquipe());
		
		List<EquipeFila> equipeFilaTest = getServiceInstance().buscaEquipeFilaPelaPrioridade(equipe);
		
		Assert.assertNotNull("Falha ao busca EquipeFila Equipe pela Fila e Pela Prioridade ...", equipeFilaTest);
	}
	
	@Test
	public void update() throws ServiceException {
		equipeFila.setQuantidadeCasoFila(11);
		getServiceInstance().update(equipeFila);
		
		EquipeFila eqValida = getServiceInstance().findByPk(equipeFila);
		
		Assert.assertEquals(equipeFila.getQuantidadeCasoFila(), eqValida.getQuantidadeCasoFila());
	}
	
	@Test
	public void buscaByEquipeAndConfiguracaoFila() throws ServiceException{
		EquipeFila ef = getServiceInstance().buscaByEquipeAndConfiguracaoFila(equipeFila.getEquipe(), equipeFila.getConfiguracaoFila());
		Assert.assertNotNull(ef);
	}
	
	@Test
	public void findFilasByEquipe() throws ServiceException {
		
		Equipe equipe = new Equipe();
		equipe.setPK(2981);
		
		getServiceInstance().findFilasByEquipe(equipe);
	}
	
}
