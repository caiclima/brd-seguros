package br.com.callink.gbo.service.test.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import br.com.callink.cad.pojo.Feriado;
import br.com.callink.cad.service.IFeriadoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.gbo.service.test.service.GenericServiceTest;

public class FeriadoServiceTest extends GenericServiceTest<IFeriadoService> {

	private static Feriado feriado;
	private static Feriado FeriadoReveillon = null;
	private static String dataNatal = "25/12/1970";
	private static String dataReveillon = "01/01/1970";
	private static SimpleDateFormat formatador = new SimpleDateFormat("dd/MM/yyyy");
	
    @Override
    public Class<?> getClazz() {
        return Feriado.class;
    }
    
    @Before
    public void insertRegistro() {

        try {
        	if(FeriadoReveillon == null){
        		List<Feriado> feriadoList = getServiceInstance().findByExample(new Feriado(formatador.parse(dataReveillon), null));
        		if(feriadoList == null || feriadoList.isEmpty()){
	        		FeriadoReveillon = new Feriado(formatador.parse(dataReveillon), Boolean.TRUE);
	        		FeriadoReveillon.setNomeFeriado("Reveillon");
	        		getServiceInstance().save(FeriadoReveillon);
        		} else {
        			FeriadoReveillon = feriadoList.get(0);
        		}
        	}
        	
            feriado = new Feriado();
			feriado.setDataFeriado(formatador.parse(dataNatal));
			feriado.setFlagNacional(Boolean.TRUE);
			feriado.setNomeFeriado("Natal");
			feriado.setLoginUsuario("swb.bruno");
            
            getServiceInstance().save(feriado);
            
            Assert.assertNotNull("Falha ao inserir entidade Perfil...", feriado.getPK());
            
        } catch (ParseException ex) {
        	Logger.getLogger(FeriadoServiceTest.class.getName()).log(Level.SEVERE, null, ex);
		} catch (ServiceException ex) {
            Logger.getLogger(FeriadoServiceTest.class.getName()).log(Level.SEVERE, null, ex);
        } 
    }

    
    @Test
    public void findByExemplo() {
    	
    	try {
    		Feriado feriadoPesquisa = new Feriado();
    		feriadoPesquisa.setDataFeriado(feriado.getDataFeriado());
			List<Feriado> list = getServiceInstance().findByExample(feriadoPesquisa);
			
			Assert.assertNotNull(list);
			
		} catch (ServiceException e) {
			Logger.getLogger(FeriadoServiceTest.class.getName()).log(Level.SEVERE, null, e);
		}
    }
    
    @After
    public void removeRegistro() throws ParseException{
    	
    	try {
        	Date data = formatador.parse(dataNatal);
			feriado.setDataFeriado(data);
			
    		List<Feriado> list = getServiceInstance().findByExample(feriado);
    		feriado = list.get(0);
			getServiceInstance().delete(feriado);
			
		} catch (ServiceException e) {
			Logger.getLogger(FeriadoServiceTest.class.getName()).log(Level.SEVERE, null, e);
		}
    }
}
