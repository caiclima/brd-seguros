package br.com.callink.gbo.service.test.service.impl;

import java.util.Date;
import java.util.List;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import br.com.callink.cad.pojo.GoalFinal;
import br.com.callink.cad.service.IGoalFinalService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.gbo.service.test.service.GenericServiceTest;

public class GoalFinalServiceTest extends GenericServiceTest<IGoalFinalService> {

	private static GoalFinal goalFinal;
	
	@Override
	public Class<?> getClazz() {
		return GoalFinal.class;
	}

	
	@Before
	public void insert() throws ServiceException {
		if(goalFinal == null) {
			goalFinal = new GoalFinal();
			goalFinal.setDataInicial(new Date());
			goalFinal.setDescricao("teste");
			goalFinal.setGoalFinal(1.99d);
			goalFinal.setGoalInicial(0d);
			goalFinal.setLoginUsuario("swb.millermiranda");
			getServiceInstance().saveGoal(goalFinal);
		}
	}
	
	@Test
	public void buscaAtivos() throws ServiceException {
		List<GoalFinal> list = getServiceInstance().buscaGoalsAtivos();
		Assert.assertNotNull(list);
	}
	
	@After
	public void deleta() throws ServiceException {
		getServiceInstance().delete(goalFinal);
	}	
}
