package br.com.callink.gbo.service.test.service.impl;

import java.util.Date;
import java.util.List;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import br.com.callink.cad.pojo.GrupoEmail;
import br.com.callink.cad.service.IGrupoEmailService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.gbo.service.test.service.GenericServiceTest;

/**
 *
 * @author Luiz Gustavo (luizgf@swb.com.br)
 */
public class GrupoEmailServiceTest extends GenericServiceTest<IGrupoEmailService> {
    
    private static GrupoEmail grupoEmail;
	
	@Override
	public Class<?> getClazz() {
		return GrupoEmail.class;
	}
	
	@Before
	public void preparaObjeto() throws ServiceException {
		grupoEmail = criaObjeto();
		getServiceInstance().save(grupoEmail);
		Assert.assertNotNull("Falha ao salvar entidade Caso...", grupoEmail.getPK());		
	}

	private GrupoEmail criaObjeto() throws ServiceException {
		GrupoEmail objGrupoEmail = new GrupoEmail();
		objGrupoEmail.setDataCriacao(new Date());
                objGrupoEmail.setFlagAtivo(Boolean.TRUE);
		objGrupoEmail.setDescricao("descricao teste");
                return objGrupoEmail;
	}
	
	@After
	public void deletaObjeto() throws ServiceException {
		getServiceInstance().delete(grupoEmail);
	}
	
	@Test
	public void findById() throws ServiceException {
		GrupoEmail grupoEmailFind = (GrupoEmail) getServiceInstance().findByPk(grupoEmail);
		Assert.assertNotNull("Falha ao salvar entidade GrupoEmail...", grupoEmailFind.getPK());
	}
	
	@Test
	public void findByExample() throws ServiceException {
		GrupoEmail grupoEmailFind = new GrupoEmail();
		grupoEmailFind.setDescricao(grupoEmail.getDescricao());
		List<GrupoEmail> grupoEmailList = getServiceInstance().findByExample(grupoEmailFind);
		Assert.assertNotNull("Falha ao busca entidade GrupoEmail...", grupoEmailList);
	}
	
	@Test
	public void update() throws ServiceException {
		grupoEmail.setDescricao("update no grupoEmail");
		getServiceInstance().update(grupoEmail);
		GrupoEmail grupoEmailValido = (GrupoEmail) getServiceInstance().findByPk(grupoEmail);
		Assert.assertEquals(grupoEmail.getDescricao(), grupoEmailValido.getDescricao());
	}
	
	@Test
	public void getDescricaoFromListaGrupoEmail() throws ServiceException {
		List<GrupoEmail> grupoEmail = getServiceInstance().findAll();
		getServiceInstance().getDescricaoFromListaGrupoEmail(grupoEmail);
	}
}
