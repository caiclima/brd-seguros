package br.com.callink.gbo.service.test.service.impl;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import br.com.callink.cad.pojo.GrupoEquipe;
import br.com.callink.cad.service.IGrupoEquipeService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.gbo.service.test.service.GenericServiceTest;

public class GrupoEquipeServiceTest extends GenericServiceTest<IGrupoEquipeService> {
    
    @Override       
    public Class<?> getClazz() {
        return GrupoEquipe.class;
    }
    private static GrupoEquipe equipe;
    
    @Before
    public void insert() {
        equipe = new GrupoEquipe();
        equipe.setFlagPrioridade(false);
        equipe.setNome("EQUIPE TESTE");
        
        String teste = null;
        try {
            getServiceInstance().save(equipe);
            teste = "Teste Executado com Sucesso";
        } catch (ServiceException ex) {
            Logger.getLogger(GrupoEquipeServiceTest.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        Assert.assertNotNull("Falha ao inserir entidade Perfil...", teste);
    }
    
    @After
    public void delete() {
        String valido = null;
        try {
            getServiceInstance().delete(equipe);
            valido = "Valido";
        } catch (ServiceException ex) {
            valido = null;
            ex.printStackTrace();
        }
        Assert.assertNotNull("Falha metodo delete", valido);
    }
    
    @Test
    public void update() {
        equipe.setFlagPrioridade(false);
        equipe.setNome("Equipe Teste Update");
        String valido = null;
        try {
            getServiceInstance().update(equipe);
            valido = "Valido";
        } catch (ServiceException ex) {
            valido = null;
            ex.printStackTrace();
        }
        Assert.assertNotNull("Falha metodo update", valido);
    }
    
//    @Test
//    public void load() {
//        Equipe equipeLoad = new Equipe();
//        equipeLoad.setIdEquipe(equipe.getIdGrupoEquipe());
//        String valido = null;
//        try {
//            getServiceInstance().load(equipeLoad);
//            valido = "Valido";
//        } catch (ServiceException ex) {
//            valido = null;
//            ex.printStackTrace();
//        }
//        Assert.assertNotNull("Falha metodo load", valido);
//    }
    
    @Test
    public void findByExemplo() {
        GrupoEquipe equipeLoad = new GrupoEquipe();
        equipeLoad.setNome("EQUIPE TESTE");
        String valido = null;
        try {
            List<GrupoEquipe> list = getServiceInstance().findByExample(equipeLoad);
            if (list != null && !list.isEmpty()) {
                valido = "Valido";
            }
            
        } catch (ServiceException ex) {
            valido = null;
            ex.printStackTrace();
        }
        Assert.assertNotNull("Falha metodo findByExeplo", valido);
    }
}
