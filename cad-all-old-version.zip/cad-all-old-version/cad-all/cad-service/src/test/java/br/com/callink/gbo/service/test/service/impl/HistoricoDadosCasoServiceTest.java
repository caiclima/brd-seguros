package br.com.callink.gbo.service.test.service.impl;

import java.util.Date;
import java.util.List;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.HistoricoDadosCaso;
import br.com.callink.cad.service.IAtendenteService;
import br.com.callink.cad.service.ICasoService;
import br.com.callink.cad.service.IHistoricoDadosCasoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.gbo.service.test.service.GenericServiceTest;
import br.com.callink.gbo.service.test.util.FactoryUtil;

import com.google.gson.Gson;

public class HistoricoDadosCasoServiceTest extends GenericServiceTest<IHistoricoDadosCasoService>{

	private static HistoricoDadosCaso historicoDadosCaso = new HistoricoDadosCaso();
	
	private static Caso caso = null;
	private static Atendente atendente = null;
	
	@Override
	public Class<?> getClazz() {
		return HistoricoDadosCaso.class;
	}
	
	@Before
	public void preparaObjeto() throws ServiceException {
		
		if(caso == null) {
			ICasoService casoService = (ICasoService) FactoryUtil.getServiceFactory().getService(Caso.class);
			caso = casoService.findAll().get(0);
		}
		if(atendente == null) {
			IAtendenteService atendenteService = (IAtendenteService) FactoryUtil.getServiceFactory().getService(Atendente.class);
			atendente = atendenteService.findAll().get(0);
		}
		
		historicoDadosCaso = criaObjeto();
		getServiceInstance().save(historicoDadosCaso);
		Assert.assertNotNull("Falha ao salvar entidade historicoDadosCaso...", historicoDadosCaso.getPK());		
	}
	
	@After
	public void deletaObjeto() throws ServiceException {
		getServiceInstance().delete(historicoDadosCaso);
	}

	private HistoricoDadosCaso criaObjeto() throws ServiceException {
		HistoricoDadosCaso histDadosCaso = new HistoricoDadosCaso();
		
		histDadosCaso.setCaso(caso);
		histDadosCaso.setAtendente(atendente);
		Gson gson = new Gson();
		histDadosCaso.setCasoJson(gson.toJson(caso));
		
		return histDadosCaso;
	}
	
	@Test
	public void findById() throws ServiceException {
		HistoricoDadosCaso histDadosCaso = getServiceInstance().findByPk(historicoDadosCaso);
		Assert.assertNotNull("Falha ao buscar entidade historicoDadosCaso...", histDadosCaso.getPK());
	}
	
	@Test
	public void update() throws ServiceException {
		historicoDadosCaso.setDataCadastro(new Date());
		getServiceInstance().update(historicoDadosCaso);
	}
	
	@Test
	public void findByExample() throws ServiceException {
		HistoricoDadosCaso hCaso = new HistoricoDadosCaso();
		hCaso.setCaso(historicoDadosCaso.getCaso());
		
		List<HistoricoDadosCaso> listCaso = getServiceInstance().findByExample(hCaso);
		Assert.assertNotNull("Falha ao buscar entidade historicoDadosCaso...", listCaso);
	}	
}
