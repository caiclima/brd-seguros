package br.com.callink.gbo.service.test.service.impl;

import java.util.Date;
import java.util.List;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;

import br.com.callink.cad.pojo.HistoricoGbo;
import br.com.callink.cad.pojo.TelaGbo;
import br.com.callink.cad.service.IHistoricoGboService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.impl.TelaGboService;
import br.com.callink.gbo.service.test.service.GenericServiceTest;

public class HistoricoGboServiceTest extends GenericServiceTest<IHistoricoGboService> {

    @Override
    public Class<?> getClazz() {
        return HistoricoGbo.class;
    }
    private static HistoricoGbo historicoGbo;
    private static TelaGbo telaGbo = null;
    

    @Before
    public void insert() throws ServiceException {
    	
    	if(telaGbo == null){
    		List<TelaGbo> telaGboList = new TelaGboService().findAll();
    		if(telaGboList != null && !telaGboList.isEmpty()){
    			telaGbo = telaGboList.get(0);
    		} else {
    			telaGbo = new TelaGbo();
    			telaGbo.setNomeTela("telaNova");
    		}
    	}
    	
    	historicoGbo = new HistoricoGbo();
    	historicoGbo.setDataCriacao(new Date());
    	historicoGbo.setHistorico("O usuario xxx fez alterou a fila!");
    	historicoGbo.setLoginUsuario("xxx.calllink");
    	historicoGbo.setIdTabelaOrigem(222);
    	historicoGbo.setTelaGbo(telaGbo);
    	
    	getServiceInstance().save(historicoGbo, telaGbo.getNomeTela());
    	Assert.assertNotNull(telaGbo.getIdTelaGbo());
    }

    @After
    public void delete() throws ServiceException {
    	getServiceInstance().delete(historicoGbo);
    }

//    @Test
    public void saveUm() throws ServiceException {
    	HistoricoGbo historicoGboUm = new HistoricoGbo();
    	historicoGboUm.setHistorico("O usuario yyy alterou a fila!");

    	List<HistoricoGbo> historicoGboList = getServiceInstance().findByExample(historicoGboUm);
    	if(historicoGboList != null && historicoGboList.isEmpty()){
        	historicoGboUm.setDataCriacao(new Date());
        	historicoGboUm.setLoginUsuario("yyy.callink");
        	historicoGboUm.setIdTabelaOrigem(20);
        	
    		getServiceInstance().save(historicoGboUm, telaGbo.getNomeTela());
    	} else {
    		historicoGboUm = historicoGboList.get(0);
    	}
    	Assert.assertNotNull(historicoGboUm.getPK());
    }
}
