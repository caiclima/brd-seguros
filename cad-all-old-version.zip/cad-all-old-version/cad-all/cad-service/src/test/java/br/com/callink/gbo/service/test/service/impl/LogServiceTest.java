package br.com.callink.gbo.service.test.service.impl;

import java.util.List;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.Log;
import br.com.callink.cad.pojo.Status;
import br.com.callink.cad.service.IAtendenteService;
import br.com.callink.cad.service.ICasoService;
import br.com.callink.cad.service.ILogService;
import br.com.callink.cad.service.IStatusService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.gbo.service.test.service.GenericServiceTest;
import br.com.callink.gbo.service.test.util.FactoryUtil;

public class LogServiceTest extends GenericServiceTest<ILogService> {

	private static Log log;
	
	private static Caso caso = null;
	private static Atendente atendente = null;
	private static Status status = null;
	
	@Override
	public Class<?> getClazz() {
		return Log.class;
	}
	
	@Before
	public void preparaObjeto() throws ServiceException {
		log = criaObjeto();
		getServiceInstance().save(log);
		
		Assert.assertNotNull("Falha ao salvar entidade Caso...", log.getPK());		
	}

	private Log criaObjeto() throws ServiceException {
		
		if(caso == null) {
			ICasoService casoService = (ICasoService) FactoryUtil.getServiceFactory().getService(Caso.class);
			caso = casoService.findAll().get(0);
		}
		if(atendente == null) {
			IAtendenteService atendenteService = (IAtendenteService) FactoryUtil.getServiceFactory().getService(Atendente.class);
			atendente = atendenteService.findAll().get(0);
			
		}
		if(status == null) {
			IStatusService statusService = (IStatusService) FactoryUtil.getServiceFactory().getService(Status.class);
			status = statusService.findAll().get(0);
		}
		
		Log logPersist = new Log();
		
		logPersist.setCaso(caso);
		logPersist.setAtendente(atendente);
		logPersist.setStatus(status);
		
		logPersist.setDescricao("Teste criação do LOG");

		return logPersist;
	}
	
	@After
	public void deletaObjeto() throws ServiceException {
		getServiceInstance().delete(log);
	}
	
	@Test
	public void findById() throws ServiceException {
		Log logFind = getServiceInstance().findByPk(log);
		
		Assert.assertNotNull("Falha ao salvar entidade Caso...", logFind.getPK());
	}
	
	@Test
	public void findByExample() throws ServiceException {
		Log logFind = new Log();
		logFind.setAtendente(log.getAtendente());
		List<Log> logList = getServiceInstance().findByExample(logFind);
		Assert.assertNotNull("Falha ao salvar entidade Caso...", logList);
	}
	
	@Test (expected=ServiceException.class)
	public void update() throws ServiceException {
		log.setDescricao("update no log");
		getServiceInstance().update(log);
		Log logValid = getServiceInstance().findByPk(log);
		Assert.assertEquals(log.getDescricao(), logValid.getDescricao());
	}	
}
