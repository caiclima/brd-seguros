package br.com.callink.gbo.service.test.service.impl;

import br.com.callink.cad.pojo.LogTask;
import br.com.callink.cad.service.ILogTaskService;
import br.com.callink.gbo.service.test.service.GenericServiceTest;

public class LogTaskServiceTest extends GenericServiceTest<ILogTaskService> {

	@Override
	public Class<?> getClazz() {
		return LogTask.class;
	}

}
