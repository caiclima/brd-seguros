

 
package br.com.callink.gbo.service.test.service.impl;

import org.junit.Assert;

import br.com.callink.cad.pojo.MetaUph;
import br.com.callink.cad.repository.MetasUphCache;
import br.com.callink.cad.service.IMetaUphService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.gbo.service.test.service.GenericServiceTest;

/**
 *
 * @author swb.miller
 */
public class MetaUphServiceTest extends GenericServiceTest<IMetaUphService> {

    private static MetaUph metaUph;

    @Override
    public Class<?> getClazz() {
        return MetaUph.class;
    }

    public void preparaObjeto() throws ServiceException {
        //metaUph = criaObjeto();
        getServiceInstance().save(metaUph);
        Assert.assertNotNull("Falha ao salvar entidade Caso...", metaUph.getPK());
    }

//    @Test
    public void calculaMetasUph() throws ServiceException {
    	getServiceInstance().calculaMetasUph();
    	Assert.assertNotNull(MetasUphCache.montaListaByUser("swb.millermiranda"));
    }

}
