package br.com.callink.gbo.service.test.service.impl;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import br.com.callink.cad.pojo.Comando;
import br.com.callink.cad.pojo.ParametroComando;
import br.com.callink.cad.service.IComandoService;
import br.com.callink.cad.service.IParametroComandoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.gbo.service.test.service.GenericServiceTest;
import br.com.callink.gbo.service.test.util.FactoryUtil;

public class ParametroComandoServiceTest extends GenericServiceTest<IParametroComandoService> {
    
	private static Comando comando = null;
	
    @Override
    public Class<?> getClazz() {
        return ParametroComando.class;
    }
    private static ParametroComando parametroComando;
    
    @Before
    public void insert() {
        String teste = null;
        try {
            parametroComando = new ParametroComando();
            parametroComando.setNome("Acao Teste");
            parametroComando.setValor("Valor Comando de teste");
            
            if(comando == null) {
            	IComandoService comandoServ = (IComandoService) FactoryUtil.getServiceFactory().getService(Comando.class);
            	List<Comando> comandos = comandoServ.findAll();
                if (comandos != null && !comandos.isEmpty()) {
                    comando = comandos.get(0);
                }
            }
            
            parametroComando.setComando(comando);
            getServiceInstance().save(parametroComando);
            teste = "Teste Executado com Sucesso";
        } catch (ServiceException ex) {
            Logger.getLogger(ParametroComandoServiceTest.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        Assert.assertNotNull("Falha ao inserir entidade ParametroComando...", teste);
    }
    
    @After
    public void delete() {
        String valido = null;
        try {
            getServiceInstance().delete(parametroComando);
            valido = "Valido";
        } catch (ServiceException ex) {
            valido = null;
            ex.printStackTrace();
        }
        Assert.assertNotNull("Falha metodo delete", valido);
    }
    
    @Test
    public void update() {
        
        parametroComando.setNome("Acao Teste");
        parametroComando.setValor("Valor Comando de teste update");
        parametroComando.setValor("valor do comando de teste");
        String valido = null;
        try {
            getServiceInstance().update(parametroComando);
            valido = "Valido";
        } catch (ServiceException ex) {
            valido = null;
            ex.printStackTrace();
        }
        Assert.assertNotNull("Falha metodo update", valido);
    }
    
    @Test
    public void load() {
        String valido = null;
        ParametroComando parametroComandoLoad = new ParametroComando();
        parametroComandoLoad.setIdParametroComando(parametroComando.getPK());
        try {
            parametroComandoLoad = getServiceInstance().load(parametroComandoLoad);
            valido = "Valido";
        } catch (ServiceException ex) {
            valido = null;
            ex.printStackTrace();
        }
        Assert.assertNotNull("Falha metodo load", valido);
    }
    
    @Test
    public void findByExemplo() {
        ParametroComando parametroComandoFind = new ParametroComando();
        parametroComando.setNome("Acao Teste");
        parametroComando.setValor("Valor Comando de teste");
        String valido = null;
        try {
            List<ParametroComando> list = getServiceInstance().findByExample(parametroComandoFind);
            if (list != null && !list.isEmpty()) {
                valido = "Valido";
            }
        } catch (ServiceException ex) {
            valido = null;
            ex.printStackTrace();
        }
        Assert.assertNotNull("Falha metodo findByExeplo", valido);
    }
}
