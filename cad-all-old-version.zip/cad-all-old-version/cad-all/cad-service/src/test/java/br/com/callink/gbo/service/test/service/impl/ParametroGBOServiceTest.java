package br.com.callink.gbo.service.test.service.impl;

import java.io.IOException;
import java.util.Properties;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;

import br.com.callink.cad.pojo.ParametroGBO;
import br.com.callink.cad.service.IParametroGBOService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.gbo.service.test.service.GenericServiceTest;

public class ParametroGBOServiceTest extends GenericServiceTest<IParametroGBOService> {

	private Properties propertiesApp;
	
	@Override
	public Class<?> getClazz() {
		return ParametroGBO.class;
	}
	
	@Before
	public void preparaTest() throws IOException {
		propertiesApp = new Properties();
		propertiesApp.load(getClass().getResourceAsStream("/config/gbo.properties"));
	}
	
	@Test
	public void findByParametro() throws ServiceException {
		ParametroGBO parametroGBO = getServiceInstance().findByParam(propertiesApp.getProperty("parametro.contasabado"));
		Assert.assertNotNull(parametroGBO);
	}

}
