package br.com.callink.gbo.service.test.service.impl;

import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import br.com.callink.cad.pojo.Perfil;
import br.com.callink.cad.service.IPerfilService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.gbo.service.test.service.GenericServiceTest;

public class PerfilServiceTest extends GenericServiceTest<IPerfilService> {

    @Override
    public Class<?> getClazz() {
        return Perfil.class;
    }
    private static Perfil perfil;

    @Before
    public void insert() throws ServiceException {
        perfil = new Perfil();
        perfil.setDataCriacao(new Date());
        perfil.setFlagAtivo(true);
        perfil.setNome("Perfil Teste");

        String teste = null;
        try {
            getServiceInstance().save(perfil);
            teste = "Teste Executado com Sucesso";
        } catch (ServiceException ex) {
            Logger.getLogger(PerfilServiceTest.class.getName()).log(Level.SEVERE, null, ex);
        }
        getServiceInstance().save(perfil);

        Assert.assertNotNull("Falha ao inserir entidade Perfil...", teste);
    }

    @After
    public void delete() throws ServiceException {
        getServiceInstance().delete(perfil);
    }

    @Test
    public void save() {
        String valido = "Valido";
        try {
            List<Perfil> list = getServiceInstance().findAtivos();
            if (list == null || list.size() == 1) {
                Perfil perfilSave = new Perfil();
                perfilSave.setDataCriacao(new Date());
                perfilSave.setFlagAtivo(true);
                perfilSave.setNome("EQUIPE TESTE");
                getServiceInstance().save(perfilSave);
            }
        } catch (ServiceException ex) {
            valido = null;
            Logger.getLogger(PerfilServiceTest.class.getName()).log(Level.SEVERE, null, ex);
        }
        Assert.assertNotNull("Falha teste save", valido);
    }

    @Test
    public void update() {
        perfil.setDataCriacao(new Date());
        perfil.setFlagAtivo(true);
        perfil.setNome("Perfil Teste Update");
        String valido = null;
        try {
            getServiceInstance().update(perfil);
            valido = "Valido";
        } catch (ServiceException ex) {
            valido = null;
            ex.printStackTrace();
        }
        Assert.assertNotNull("Falha metodo update", valido);
    }

    @Test
    public void load() {
        Perfil perfilLoad = new Perfil();
        perfilLoad.setIdPerfil(perfil.getIdPerfil());
        String valido = null;
        try {
            getServiceInstance().load(perfilLoad);
            valido = "Valido";
        } catch (ServiceException ex) {
            valido = null;
            ex.printStackTrace();
        }
        Assert.assertNotNull("Falha metodo load", valido);
    }

    @Test
    public void findByExemplo() {
        Perfil perfilFind = new Perfil();
        perfilFind.setFlagAtivo(true);
        perfilFind.setNome("Perfil Teste");
        String valido = null;
        try {
            List<Perfil> list = getServiceInstance().findByExample(perfil);
            if (list != null && !list.isEmpty()) {
                valido = "Valido";
            }
        } catch (ServiceException ex) {
            valido = null;
            ex.printStackTrace();
        }
        Assert.assertNotNull("Falha metodo findByExeplo", valido);
    }
}
