package br.com.callink.gbo.service.test.service.impl;

import java.util.Date;
import java.util.List;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;

import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.ReaberturaCaso;
import br.com.callink.cad.service.ICasoService;
import br.com.callink.cad.service.IReaberturaCasoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.gbo.service.test.service.GenericServiceTest;
import br.com.callink.gbo.service.test.util.FactoryUtil;

/**
 * Teste para uma ReaberturaCaso
 * @author brunomt
 *
 */
public class ReaberturaCasoServiceTest extends GenericServiceTest<IReaberturaCasoService> {

	private static ReaberturaCaso reaberturaCaso;
	private static List<Caso> casoList;
	@Override
	public Class<?> getClazz() {
		return ReaberturaCaso.class;
	}

	@Before
	public void criaObjeto() throws ServiceException {
		reaberturaCaso = new ReaberturaCaso();
		ICasoService casoService = (ICasoService) FactoryUtil.getServiceFactory().getService(Caso.class);
		if (casoList == null) {
			casoList = casoService.findAll();
		}
		reaberturaCaso.setCaso(casoList.get(0));
		reaberturaCaso.setDataReabertura(new Date());
		reaberturaCaso.setMotivoReabertura("TESTE DE REABERTURA");
		getServiceInstance().save(reaberturaCaso);
		
		Assert.assertNotNull(reaberturaCaso.getIdReaberturaCaso());
	}
	
	@Test
	public void findById() throws ServiceException {
		ReaberturaCaso reaberturaCasoValida = getServiceInstance().findByPk(reaberturaCaso);
		Assert.assertNotNull(reaberturaCasoValida.getIdReaberturaCaso());
	}
	
	@Test
	public void findByExample() throws ServiceException {
		ReaberturaCaso reaberturaCasoBusca = new ReaberturaCaso();
		reaberturaCasoBusca.setCaso(reaberturaCaso.getCaso());
		
		List<ReaberturaCaso> reaberturaList = getServiceInstance().findByExample(reaberturaCasoBusca);
		Assert.assertNotNull(reaberturaList);
	}
	
	@Test
	public void findByCaso() throws ServiceException {
		getServiceInstance().findByCaso(casoList.get(0));
	}

	public void deletaObjeto() throws ServiceException {
		getServiceInstance().delete(reaberturaCaso);
	}
	
}
