package br.com.callink.gbo.service.test.service.impl;

import java.util.Date;

import org.junit.Test;

import br.com.callink.cad.pojo.RelatorioCasosFechados;
import br.com.callink.cad.service.IRelatorioCasosFechadosService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.impl.RelatorioCasosFechadosService;
import br.com.callink.gbo.service.test.service.GenericServiceTest;

public class RelatorioCasosFechadosServiceTest extends GenericServiceTest<IRelatorioCasosFechadosService> {

	@Override
	public Class<?> getClazz() {
		return RelatorioCasosFechados.class;
	}
	
	@Test
	public void buscaCasosFechadosDia() throws ServiceException {
		getServiceInstance().buscaCasosFechadosDia();
	}
	
	@Test
	public void buscaCasosFechadosDiaEnviado() throws ServiceException {
		getServiceInstance().buscaCasosFechadosDia(new Date());
	}
	
	@Test
	public void geraCasosFechadosDia() throws ServiceException {
		getServiceInstance().geraCasosFechadosDia();
	}
	
	@Test
	public void retornaCasosFechadosPorHora() throws ServiceException {
		getServiceInstance().retornaCasosFechados(1, RelatorioCasosFechadosService.POR_HORA, null);
	}
	
	@Test
	public void retornaCasosFechadosPorEquipe() throws ServiceException {
		getServiceInstance().retornaCasosFechados(1, RelatorioCasosFechadosService.POR_EQUIPE, null);
	}
	
	@Test
	public void retornaCasosFechadosPorAnalista() throws ServiceException {
		getServiceInstance().retornaCasosFechados(1, RelatorioCasosFechadosService.POR_ANALISTA, "EQUIPE_RECLAMACAO");
	}
	
//	@Test
	public void limpaDados() throws ServiceException {
		getServiceInstance().limpaDiaAtual(new Date());
	}

}
