/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.gbo.service.test.service.impl;

import java.util.Calendar;
import java.util.Date;

import org.junit.Test;

import br.com.callink.cad.pojo.RelatorioTempoOperacional;
import br.com.callink.cad.service.IRelatorioTempoOperacionalService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.gbo.service.test.service.GenericServiceTest;

/**
 *
 * @author brunomt
 */
public class RelatorioTempoOperacionalServiceTest extends GenericServiceTest<IRelatorioTempoOperacionalService> {

    @Override
    public Class<?> getClazz() {
        return RelatorioTempoOperacional.class;
    }
    
    @Test
    public void buscaLoginSSO() throws ServiceException {
        Date dataFim = getServiceInstance().getDataBanco();
        Calendar cal = Calendar.getInstance();
        cal.setTime(dataFim);
        cal.add(Calendar.DAY_OF_MONTH, -1);
        Date dataInicio = cal.getTime();
        
        getServiceInstance().retornaLoginsUsuariosSSO(dataInicio, dataFim);
    }
    
    @Test
    public void geraRelatorioParametroTempoOperacional() throws ServiceException {
        getServiceInstance().geraRelatorioParametroTempoOperacional();
        
    }
    
    @Test
    public void geraRelatorioEntreDatas() throws ServiceException {

        getServiceInstance().geraRelatorioParametroTempoOperacional();
    }
            
   
    
}
