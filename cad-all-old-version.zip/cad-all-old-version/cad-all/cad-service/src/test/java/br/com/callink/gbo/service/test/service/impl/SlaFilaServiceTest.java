package br.com.callink.gbo.service.test.service.impl;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.pojo.SlaFila;
import br.com.callink.cad.service.IConfiguracaoFilaService;
import br.com.callink.cad.service.ISlaFilaService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.gbo.service.test.service.GenericServiceTest;
import br.com.callink.gbo.service.test.util.FactoryUtil;

public class SlaFilaServiceTest extends GenericServiceTest<ISlaFilaService>{

	private static SlaFila slaFila;
	private static ConfiguracaoFila fila;
	
	@Override
	public Class<?> getClazz() {
		return SlaFila.class;
	}
	
	@Before
	public void criaObjecto() throws ServiceException {
		
		IConfiguracaoFilaService configuracaoFilaService =
				(IConfiguracaoFilaService) FactoryUtil.getServiceFactory().
				getService(ConfiguracaoFila.class);
		
		fila = configuracaoFilaService.findAll().get(0);
		slaFila = new SlaFila();
	    slaFila.setConfiguracaoFila(fila);
	    slaFila.setDescricao("teste");
	    slaFila.setSla(10);
		getServiceInstance().save(slaFila);
		
		Assert.assertNotNull(slaFila);
	}
	
//	@Test
	public void findSlabyFila() throws ServiceException {
		Assert.assertNotNull(getServiceInstance().findSlaFilaByConfFila(fila));
	}
	
	@Test
	public void findAllSla() throws ServiceException {
		Assert.assertNotNull(getServiceInstance().findAllSlafila());
	}
	
	@After
	public void deleta() throws ServiceException {
		getServiceInstance().delete(slaFila);
	}
}
