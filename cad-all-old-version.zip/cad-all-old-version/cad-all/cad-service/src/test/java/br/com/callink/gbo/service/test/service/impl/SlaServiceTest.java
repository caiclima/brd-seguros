/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.gbo.service.test.service.impl;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import junit.framework.Assert;

import org.junit.Test;

import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.service.ISlaService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.coreutils.infra.util.BeanFactory;

/**
 * 
 * @author Rogério Moreira de Andrade. [rogeriom@swb.com.br]
 */
public class SlaServiceTest {

    @Test
    public void calculaSla() throws ParseException, ServiceException {
       
            Caso caso = new Caso();
            DateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
            caso.setDataAbertura(df.parse("01/11/2011 00:00:00"));
            caso.setDataFimSla(df.parse("03/11/2011 00:00:00"));

            BeanFactory bean = BeanFactory.getInstance();
            ISlaService slaService = (ISlaService) bean.getBean("slaService");
            
            Long tempo = slaService.calculaSlaMinutos(caso.getDataAbertura(), caso.getDataFimSla());
            Long minutosDia = (long) 1440;

            Assert.assertEquals("Erro ao calcular SLA", minutosDia, tempo);
            
    }
}
