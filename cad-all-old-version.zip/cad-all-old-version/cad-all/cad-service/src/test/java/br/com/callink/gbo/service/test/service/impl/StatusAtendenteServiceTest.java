package br.com.callink.gbo.service.test.service.impl;

import java.util.Calendar;
import java.util.Date;

import org.junit.Test;

import br.com.callink.cad.pojo.AtendenteStatus;
import br.com.callink.cad.pojo.StatusAtendente;
import br.com.callink.cad.service.IStatusAtendenteService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.gbo.service.test.service.GenericServiceTest;

/**
 *
 * @author brunomt
 */
public class StatusAtendenteServiceTest extends GenericServiceTest<IStatusAtendenteService> {

    @Override
    public Class<?> getClazz() {
        return StatusAtendente.class;
    }
    
    @Test
    public void buscaTodosStatusAtendente() throws ServiceException {
        
        Date dataFim = getServiceInstance().getDataBanco();
        Calendar cal = Calendar.getInstance();
        cal.setTime(dataFim);
        cal.add(Calendar.DAY_OF_MONTH, -1);
        Date dataInicio = cal.getTime();
        
        
        getServiceInstance().buscaTodosStatusAtendenteEntreDatas(dataInicio, dataFim);
    }
    
    @Test
    public void finalizaStatusAtendenteSemDataFim() throws ServiceException {
    	getServiceInstance().finalizaStatusAtendenteSemDataFim();
    }
    
    @Test 
    public void buscaStatusAtendenteByStatus() throws ServiceException {
    	
    	AtendenteStatus atendenteStatus = new AtendenteStatus();
    	atendenteStatus.setIdAtendenteStatus(1);
    	
    	getServiceInstance().buscaStatusAtendenteByStatus(atendenteStatus, 30);
    }
     
}
