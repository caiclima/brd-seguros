package br.com.callink.gbo.service.test.service.impl;

import java.util.List;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.pojo.Status;
import br.com.callink.cad.pojo.StatusAcao;
import br.com.callink.cad.service.IAcaoService;
import br.com.callink.cad.service.IStatusService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.gbo.service.test.service.GenericServiceTest;
import br.com.callink.gbo.service.test.util.FactoryUtil;

/**
 * Teste para um {@link Status}
 * @author brunomt [brunoam@swb.com.br]
 *
 */
public class StatusServiceTest extends GenericServiceTest<IStatusService> {

	private static Status status;
        private static StatusAcao statusacao;
	
	@Override
	public Class<?> getClazz() {
		return Status.class;
	}
	
	@Before
	public void preparaObjeto() throws ServiceException {
		status = new Status();
		status.setNome("STATUS TESTE");
		status.setDescricao("Status em que o CASO está finalizado");
		status.setFlagAtivo(true);
		status.setFlagContaSla(true);
		status.setFlagPausado(false);
        IAcaoService acaoServ = (IAcaoService) FactoryUtil.getServiceFactory().getService(Acao.class);
        List<Acao> casos = acaoServ.findAll();
        Acao acao = null;
        if (casos != null && !casos.isEmpty()) {
            acao = casos.get(0);
        }
                       
		getServiceInstance().save(status);
                
        statusacao = new StatusAcao(status, acao);
        
        getServiceInstance().associa(statusacao);
                
		Assert.assertNotNull("Falha ao inserir entidade Status...", status.getPK());
	}
	
	@Test
	public void findById() throws ServiceException {
		Status st = getServiceInstance().findByPk(status);
		Assert.assertNotNull("Falha ao buscar pelo ID Status...", st.getPK());
	}
	
	@Test(expected=ServiceException.class)
	public void saveError() throws ServiceException {
		Status st = new Status();
		st.setNome("STATUS ERRO");
		
		getServiceInstance().save(st);
	}
	
	@Test
	public void update() throws ServiceException {
		status.setNome("STATUS ALTERADO");
		getServiceInstance().update(status);
	}
	
	@Test
	public void inativar() throws ServiceException {
		getServiceInstance().inativar(status);
	}
	
    @Test
	public void findByStatus() throws ServiceException {
		List<StatusAcao> list = getServiceInstance().findByStatus(status);
		Assert.assertNotNull("Falha ao consultar entidade StatusAcao...", list);
	}
        
    @Test
	public void findByAcao() throws ServiceException {
		List<StatusAcao> list = getServiceInstance().findByAcao(statusacao.getIdAcao());
		Assert.assertNotNull("Falha ao consultar entidade StatusAcao...", list);
	}        
	
    @After
	public void deletaObjeto() throws ServiceException {
        getServiceInstance().excluiAssociacao(statusacao);
		getServiceInstance().delete(status);
	}

}
