package br.com.callink.gbo.service.test.service.impl;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import br.com.callink.cad.pojo.TelaGbo;
import br.com.callink.cad.service.ITelaGboService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.gbo.service.test.service.GenericServiceTest;

public class TelaGboServiceTest extends GenericServiceTest<ITelaGboService> {

	private static final String nomeTelaMonitor = "telaMonitorTeste";
	private static final String nomeTelaStatus = "telaStatusTeste";
	
    @Override
    public Class<?> getClazz() {
        return TelaGbo.class;
    }
    
    private static TelaGbo telaGbo;

    @Before
    public void insert() throws ServiceException {
    	telaGbo = new TelaGbo();
    	telaGbo.setNomeTela(nomeTelaMonitor);
    	getServiceInstance().save(telaGbo);
    	Assert.assertNotNull(telaGbo.getIdTelaGbo());
    }

    @After
    public void delete() throws ServiceException {
    	getServiceInstance().delete(telaGbo);
    }
    
    @Test
    public void inativa() throws ServiceException {
    	getServiceInstance().inativa(telaGbo);
    }

    @Test
    public void findTelaPorNome() throws ServiceException {
    	getServiceInstance().findByNomeTela(nomeTelaMonitor);
    }
    
}
