package br.com.callink.gbo.service.test.service.impl;

import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.pojo.AcaoTipoAcao;
import br.com.callink.cad.pojo.Status;
import br.com.callink.cad.pojo.TipoAcao;
import br.com.callink.cad.service.IAcaoService;
import br.com.callink.cad.service.IStatusService;
import br.com.callink.cad.service.ITipoAcaoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.gbo.service.test.service.GenericServiceTest;
import br.com.callink.gbo.service.test.util.FactoryUtil;

public class TipoAcaoServiceTest extends GenericServiceTest<ITipoAcaoService> {
    
    @Override
    public Class<?> getClazz() {
        return TipoAcao.class;
    }
    private static TipoAcao tipoAcao;
    
    @Before
    public void insert() {
        tipoAcao = new TipoAcao();
        tipoAcao.setDataAlteracao(new Date());
        tipoAcao.setFlagAtivo(true);
        tipoAcao.setNome("TIPOACAO TESTE");
        
        String teste = null;
        try {
            getServiceInstance().save(tipoAcao);
            teste = "Teste Executado com Sucesso";
        } catch (ServiceException ex) {
            Logger.getLogger(TipoAcaoServiceTest.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        Assert.assertNotNull("Falha ao inserir entidade TipoAcao...", teste);
    }
    
    @After
    public void delete() {
        String valido = null;
        try {
            getServiceInstance().delete(tipoAcao);
            valido = "Valido";
        } catch (ServiceException ex) {
            valido = null;
            ex.printStackTrace();
        }
        Assert.assertNotNull("Falha metodo delete", valido);
    }
    
    @Test
    public void update() {
        tipoAcao.setDataAlteracao(new Date());
        tipoAcao.setFlagAtivo(false);
        tipoAcao.setNome("TipoAcao Teste Update");
        String valido = null;
        try {
            getServiceInstance().update(tipoAcao);
            valido = "Valido";
        } catch (ServiceException ex) {
            valido = null;
            ex.printStackTrace();
        }
        Assert.assertNotNull("Falha metodo update", valido);
    }
    
    @Test
    public void load() {
        TipoAcao tipoAcaoLoad = new TipoAcao();
        tipoAcaoLoad.setIdTipoAcao(tipoAcao.getIdTipoAcao());
        String valido = null;
        try {
            getServiceInstance().load(tipoAcaoLoad);
            valido = "Valido";
        } catch (ServiceException ex) {
            valido = null;
            ex.printStackTrace();
        }
        Assert.assertNotNull("Falha metodo load", valido);
    }
    
    @Test
    public void findByExemplo() {
        TipoAcao tipoAcaoLoad = new TipoAcao();
        tipoAcaoLoad.setNome(tipoAcao.getNome());
        String valido = null;
        try {
            List<TipoAcao> list = getServiceInstance().findByExample(tipoAcaoLoad);
            if (list != null && !list.isEmpty()) {
                valido = "Valido";
            }
            
        } catch (ServiceException ex) {
            valido = null;
            ex.printStackTrace();
        }
        Assert.assertNotNull("Falha metodo findByExeplo", valido);
    }
    
    @Test
    public void associaDeleta() throws ServiceException {
    	IAcaoService acaoService =  (IAcaoService) FactoryUtil.getServiceFactory().getService(Acao.class);
    	List<Acao> listAcao = acaoService.findAtivos();
    	AcaoTipoAcao acaoTipoAcao = new AcaoTipoAcao();
    	acaoTipoAcao.setIdAcao(listAcao.get(0));
    	acaoTipoAcao.setIdTipoAcao(tipoAcao);
    	
    	getServiceInstance().associa(acaoTipoAcao);
    	
    	List<AcaoTipoAcao> acaoTipoAcaos = getServiceInstance().find(null, null);
    	Assert.assertNotNull("Falha metodo find", acaoTipoAcaos.get(0).getIdAcao());
    	
    	getServiceInstance().excluiAssociacao(acaoTipoAcao);
    }
    
    @Test
    public void findTipoAcaoPeloStatus() throws ServiceException {
    	IStatusService statuService =  (IStatusService) FactoryUtil.getServiceFactory().getService(Status.class);
    	List<Status> statusList = statuService.findAtivos(null);
    	List<TipoAcao> tipoAcaoList = getServiceInstance().findTipoAcaoPeloStatus(statusList.get(0));
    	Assert.assertNotNull("Falha metodo find", tipoAcaoList);
    }
}
