package br.com.callink.cad.enumeration;


public enum ImagesnMetaEnum {

	VERMELHO ("Vermelho", "Circle_Red.png"),
	AMARELO ("Amarelo", "Circle_Yellow.png"),
	LARANJA ("Laranjado", "Circle_Orange.png"),
	VERDE ("Verde", "Circle_Green.png"),
	AZUL ("Azul", "Circle_Blue.png"),
	CINZA ("Cinza", "Circle_Gray.png" );
	
	private final String descricao;
	private final String nomeImagem;

	ImagesnMetaEnum(String descricao, String nomeImagem) {
		this.descricao = descricao;
		this.nomeImagem = nomeImagem;
	}

	public String getCaminho() {
		return this.nomeImagem;
	}
	
	public String getDescricao() {
		return this.descricao;
	}
	
	@Override
	public String toString() {
		return this.nomeImagem;
	}
	
	public static String convertDescToImagem(String nomeImagem) {
		
		if(nomeImagem != null) {
			if(ImagesnMetaEnum.AMARELO.getDescricao().equalsIgnoreCase(nomeImagem)) {
			 	return ImagesnMetaEnum.AMARELO.getCaminho();
			} else if(ImagesnMetaEnum.LARANJA.getDescricao().equalsIgnoreCase(nomeImagem)) {
			 	return ImagesnMetaEnum.LARANJA.getCaminho();
			} else if(ImagesnMetaEnum.VERDE.getDescricao().equalsIgnoreCase(nomeImagem)) {
			 	return ImagesnMetaEnum.VERDE.getCaminho();
			} else if(ImagesnMetaEnum.VERMELHO.getDescricao().equalsIgnoreCase(nomeImagem)) {
			 	return ImagesnMetaEnum.VERMELHO.getCaminho();
			} else if(ImagesnMetaEnum.AZUL.getDescricao().equalsIgnoreCase(nomeImagem)) {
			 	return ImagesnMetaEnum.AZUL.getCaminho();
			}
		}
		
		return ImagesnMetaEnum.CINZA.getCaminho();
	}
}
