package br.com.callink.cad.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public final class ArquivoUtils {

	
	private ArquivoUtils(){}
	
    public static void gravarArquivo(String nomeArquivo, String caminho, byte[] dados) throws IOException {


        File diretorio = new File(caminho);
        if (!diretorio.exists()) {
            diretorio.mkdirs();
        }
        File arquivo = new File(diretorio, nomeArquivo);
        FileOutputStream fos = new FileOutputStream(arquivo);
        try {
            fos.write(dados);
        } catch (IOException e) {
            throw new IOException("Erro ao salvar arquivo.", e);
        } finally {
            fos.close();
        }
    }

    public static byte[] getBytesArquivo(String caminhoArquivo) throws IOException {
        byte[] byteArray = null;
        File file = new File(caminhoArquivo);
        if (file.exists()) {
            FileInputStream fli = new FileInputStream(file);
            try {
                byteArray = new byte[fli.available()];
                fli.read(byteArray);
            } finally {
                fli.close();
            }
        }
        return byteArray;
    }
}
