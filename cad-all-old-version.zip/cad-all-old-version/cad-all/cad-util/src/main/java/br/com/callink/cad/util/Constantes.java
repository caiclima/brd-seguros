package br.com.callink.cad.util;

public interface Constantes {

	public static final String STATUS_PENDENTE = "PENDENTE DE CHECAGEM";

	public static final String NOVA_LINHA = "\n";

	public static final int TAM_CPF_COMPLETO = 11;
	public static final int TAM_CNPJ_COMPLETO = 14;

	public static final int TAM_CPF_SEM_DIGITO_VERIFICADOR = 9;
	public static final int TAM_CNPJ_SEM_DIGITO_VERIFICADOR = 12;

	public static final String ICONE_OK = "sla_ok";
	public static final String ICONE_ATENCAO = "sla_atencao";
	public static final String ICONE_ATRASADO = "sla_atrasado";

	public static final String CPF = "cpf";
	public static final String CNPJ = "cnpj";

	public static final String WITH_NO_LOCK = " with(nolock) ";

	public static final int UM = 1;
	public static final int DOIS = 2;
	public static final int TRES = 3;
	public static final int QUATRO = 4;
	public static final int CINCO = 5;
	public static final int SEIS = 6;
	public static final int SETE = 7;
	public static final int OITO = 8;
	public static final int NOVE = 9;
	public static final int DEZ = 10;
	public static final int ONZE = 11;
	public static final int DOZE = 12;
	public static final int QUATORZE = 14;
	public static final int MINUTOS_DIA = 1440;

	public static final String CAMINHO_ARQUIVO_PROPERTIES_CONFIGURACAO_TELA = "/config/";
	public static final String NOME_ARQUIVO_PROPERTIE = "gbo.properties";

	public static final String CHAVE_NOME_TELA_CONFIGURACAO_FILA = "parametro.tela.configuracao.fila";
	public static final String CHAVE_NOME_TELA_FILTRO_FILA = "parametro.tela.filtro.fila";
	public static final String CHAVE_NOME_STATUS_OUTRA_JUNCAO = "parametro.status.outra.juncao";
	public static final String CHAVE_NOME_ACAO_FINALIZAR = "parametro.acao.finalizar";
	public static final String CHAVE_NOME_ACAO_ENVIAR_EMAIL = "parametro.acao.enviarEmail";
	public static final String CHAVE_NOME_ACAO_FINALIZAR_CASO_STGM = "parametro.acao.finalizarCasoSTGM";

	public static final String CHAVE_DIRETORIO_ANEXO = "parametro.diretorio.anexo";

	public static final String NOME_STATUS_EM_CLASSIFICACAO = "parametro.status.EmClassificacao";
	public static final String NOME_STATUS_AG_ATENDIMENTO = "parametro.status.AgAtendimento";
	public static final String RELATORIO_OBJETO = "relatorio.objeto";

	public static final String COMANDO_EM_EXECUCAO = "comandoEmExecucao";
	public static final String STATUS_AGUARDANDO_ANALISE = "AGUARDANDO ANÁLISE";
	public static final String STATUS_REABERTO = "REABERTO";
	public static final String STATUS_OUTRA_JUNCAO = "OUTRA JUNCAO";
	public static final String STATUS_EM_ATENDIMENTO = "EM ATENDIMENTO";

	public static final String ID_SUPERVISOR = "idsupervisor";

	public static final String QTD_MAX_CLASSIFICACOES = "classificacaocount";

	public static final String ID_STATUS_CADASTRO_MANUAL = "idstatuscadastromanual";

	public static final String ID_EVENTO_FINALIZA_CPF_CNPJ_INVALIDO = "ideventofinalizacpfcnpjinvalido";

	public static final String HORA_EXECUCAO_RETIRA_FILA = "horaexecucaoretirafila";
	public static final String TEMPO_RETIRA_CASO_FILA_ATENDENTE = "temporetiracasofilaatendente";
	public static final String TEMPO_SLA = "temposla";
	public static final String INICIO_SLA = "iniciosla";
	public static final String TEMPO_OK = "tempook";
	public static final String TEMPO_ATENCAO = "tempoatencao";
	public static final String LISTA_STRING_VAZIA = "[]";

	public static final String ACAO = "acao";
	public static final String FINALIZAAUTOMATICO = "finalizaautomatico";

	public static final String TEMPO_ESTOURADO = "tempoestourado";

	public static final String CONTA_DOMINGO = "contadomingo";
	public static final String CONTA_SABADO = "contasabado";

	public static final String TEMPO_SCHEDULE_EVOLUCAO_CASO = "temposcheduleevolucaocaso";
	public static final String TEMPO_SCHEDULE_CASOS_ABERTOS = "temposchedulecasosabertos";
	public static final String TEMPO_SCHEDULE_CASOS_CLASSIFICADOS = "temposchedulecasosclassificados";
	public static final String TEMPO_SCHEDULE_FILA_ATENDIMENTO = "temposchedulefilaatendimento";
	public static final String ATENDENTE_STATUS_DISPONIVEL = "idatendentestatusdisponivel";
	public static final String ATENDENTE_STATUS_ATENDIMENTO = "idatendentestatusatendimento";

	public static final String TEMPO_EXPIRA_SESSION = "tempoExpiraSession";

	public static final String SEPARADOR_INICIAL = "separador_inicial";
	public static final String SEPARADOR_FINAL = "separador_final";

	public static final String PARAMETRO_EMAIL_USUARIO = "parametro.email.usuario";
	public static final String PARAMETRO_EMAIL_SENHA = "parametro.email.senha";
	public static final String PARAMETRO_EMAIL_SMTPHOST = "parametro.email.smtpHost";
	public static final String PARAMETRO_EMAIL_POPHOST = "parametro.email.popHost";
	public static final String PARAMETRO_EMAIL_FOLDER = "parametro.email.folder";
	public static final String PARAMETRO_EMAIL_PROTOCOLSTORE = "parametro.email.protocolStore";
	public static final String PARAMETRO_EMAIL_IMAPPORT = "parametro.email.imapPort";
	public static final String PARAMETRO_RECEBIMENTO_EMAIL = "parametro.email.recebeEmail";
	
	public static final String PARAMETRO_CONTEUDO_EMAIL_FECHADO = "conteudoEmailCasoFechado";

	public static final String PARAMETRO_ASSINATURA_EMAIL = "assinaturaEmail";

	public static final String ICONE_RECEBEU_EMAIL = "new-mail";
	public static final String ICONE_NAO_RECEBEU_EMAIL = "no-mail";

	public static final String BR = "<br/>";
	public static final String VIRGULA = ",";
	public static final String ESPACO = " ";

	public static final String PARAM_SEMAFORO_TEMPO_OPERACIONAL = "semaforoTempoOperacional";

	public static final String PARAMETRO_REABRE_CASO_ATENDENTE = "reabreCasoAtendente";

	public static final String TRUE = "true";
	public static final String FALSE = "false";

	public static final String FLAG_CONTROLE_STATUS = "flaControleStatusGBO";

	public static final String FLAG_INICIA_BAPP_TOOLBAR = "flagIniciaBAppToolbar";
	public static final String FLAG_PROCESSANDO_SPA = "flagProcessandoSPA";
	public static final String URL_SISTEMA = "urlGbo";
	public static final String TABELA_IMPORTACAO_CASO = "tabelaImportCaso";
	public static final String FECHADO_POR_HORA = "fechadoPorHora";

	public static final String PORTA_TOOLBAR_BAPP = "portaToolbarBapp";
        
    public static final String PARAMETRO_JUNCAO_ATRAZO = "parametroJuncaoAtrazada";
	
	public static final String TEMPO_DISPONIVEL_ENVIA_CASO = "tempoDisponivelEnviaCaso";
	public static final String PORTA_TOOLBAR_SERVER = "portaToolbarServer";
	public static final String IP_TOOLBAR_SERVER = "ipToolbarServer";
	public static final String URL_TRATATIVA_GBO = "urlTratativaGBO";
	public static final String PAUSA_NAO_IDENTIFICADA = "0";

	public static final Integer ID_STATUS_PADRAO_DE_CASOS_IMPORTADAS = 1;
	public static final Integer ID_CONFIG_FILA_PADRAO_DE_CASOS_IMPORTADAS = 1;
	public static final Integer ID_SLA_FILA_PADRAO_DE_CASOS_IMPORTADAS = 1;
	
	public static final String ID_RELATORIO_TEMPO_GERAL_OPERADOR_SUMARIZADO	= "id_relatorio_tempo_geral_operador_sumarizado";
	public static final String PERCENTUAL_TEMPO_OCIOSO = "perc_tempo_ocioso";
	public static final String PERCENTUAL_TEMPO_PAUSA = "perc_tempo_pausa";
	public static final String PERCENTUAL_TEMPO_PRODUTIVO = "perc_tempo_produtivo";
	public static final String PRIMEIRO_LOGIN = "primeiro_login";
	public static final String ULTIMO_LOGIN = "ultimo_login";
	public static final String TEMPO_LOGADO = "tempo_logado";
	public static final String TEMPO_PAUSA = "tempo_pausa";
	public static final String TEMPO_PRODUTIVO = "tempo_produtivo";
	
	public static final String SUPERVISOR = "supervisor";
	public static final String LOGIN_ATENDENTE = "login_atendente";
	public static final String ID_ATENDENTE = "id_atendente";
	public static final String ID_EQUIPE = "id_equipe";
	public static final String NOME_EQUIPE = "nome_equipe";
	public static final String DATA = "data";
	

	public static final String FLAG_RENDER_COL_UPH = "flagRenderColUph";
	public static final String FLAG_RENDER_COL_GOAL = "flagRenderColGoal";
        
    public static final String PARAMETRO_ID_STATUS_FINALIZADO = "idStatusFinalizado";
        
    public static final String PARAMETRO_STATUS_ORIGEM_FINALIZADO = "statusOrigemFinalizado";

	public static final String TEMPOLIGACAO = "tempoProximaLigacao";
	
	public static final String QTD_LIGACOES_TELEFONE = "qtdLigacoesPorTelefone";
        
    public static final String PARAMETRO_QTD_MAX_EDICAO_TELEFONE_CASO = "qtdMaximaEdicaoTelefoneCaso";

	public static final String FLAG_AUTO_ASSOCIAR_CASOS_MESMO_CLIENTE = "associaAutomaticamenteCasosMesmoCliente";

	public static final String SQL_WHERE_CASOS_PENDENTES_MESMO_CLIENTE = "filtroCasosPendentesMesmoCliente";
	
	public static final String TB_CASO_ESPECIALISTA = "tbcasoespecialista";
	
	public static final String KEEP_ALIVE_TIME = "emailKeepAliveTime";
	
	public static final String PARAM_FROM_CONSULTA_CASO = "fromconsultacaso";
	public static final String PARAM_FILTER_CONSULTA_CASO = "filterconsultacaso";
	public static final String PARAM_LIMITE_LINHA_ARQUIVO_IMPORT = "limiteLinhaArquivoImport";
	public static final String PARAM_TYPE_NOT_ALLOWED = "tipodearquivonaosuportado";
	public static final String PARAM_LENGTH_NOT_ALLOWED = "tamanhodearquivonaosuportado";
	
	public static final String DIRETORIO_ANEXO = "diretorioAnexo";
	
	public static final int NRO_REGISTROS_COMMIT = 500;
	
	public static final String URL_CACHE_SERVLET ="url_cache_servlet";
	
	public static final String LINKED_SERVER_NAME = "linked_server_name";
}
