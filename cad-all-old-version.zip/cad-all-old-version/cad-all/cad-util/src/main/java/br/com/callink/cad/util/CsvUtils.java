package br.com.callink.cad.util;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/**
 * @author Fabio Borges de Oliveira <fabio@callink.com.br>
 */
public class CsvUtils extends FileUtils {

	private static String delimiter = ";";
	private static String newLine = "\n";

	public CsvUtils(String fileName, String directoryName) {
		super(fileName, directoryName);
	}

	public File createFile(Object[] objects) throws Exception {
		
		FileWriter fileWriter = null; 
		
		try{	
			if (!file.exists()) {
				if (file.getParentFile() != null && !file.getParentFile().exists()) {
					file.getParentFile().mkdirs();
				}
		
				try {
					file.createNewFile();
				} catch (IOException ex) {
					throw new Exception(ex);
				}
			}
		
			fileWriter = new FileWriter(file);
			fileWriter.write(createContents(objects).toString());
			fileWriter.close();
		
			return file;
		
		}catch (IOException e) {
			throw new Exception(e);
		}finally{
			if(fileWriter!= null){
				fileWriter.close();
			}
		}	
	}

	public StringBuffer createContents(Object[] objects) {

		StringBuffer sb = new StringBuffer();

		for (Object row : objects) {
			Object[] line = (Object[]) row;

			for (Object valueLine : line) {
				sb.append(valueLine);
				sb.append(CsvUtils.delimiter);
			}

			sb.append(newLine);
		}

		return sb;
	}
}