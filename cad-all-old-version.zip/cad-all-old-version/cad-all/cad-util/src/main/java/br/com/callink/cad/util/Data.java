package br.com.callink.cad.util;

import java.util.Date;

public final class Data {

	private Data(){}
	
	
	public static long diferencaEmDias(Date dataFim, Date dataInicio) {

		long diferenca = dataFim.getTime() - dataInicio.getTime();

		// Quantidade de milissegundos em um dia
		int tempoDia = 1000 * 60 * 60 * 24;
		return diferenca / tempoDia;
	}
        
        /**
         * Converte uma string hhh:mm em minutos.
         * @param horasMinutos
         * @return 
         */
        public static Integer retornaMinutos(String horasMinutos) {
            if (horasMinutos == null || horasMinutos.isEmpty()) {
                return null;
            }
            String horaMinutoSplit[] = horasMinutos.split(":");
            
            return Integer.valueOf(horaMinutoSplit[0]) * 60 + Integer.valueOf(horaMinutoSplit[1]) ;
        }
        
        public static Long retornaMinutos(Integer horas, Integer minutos ) {
            if ((horas != null && !horas.equals(Integer.valueOf(0))) || (minutos != null && !minutos.equals(Integer.valueOf(0)))) {
                return (long) ((horas * 60) + minutos);
            }

            return null;
        }

}
