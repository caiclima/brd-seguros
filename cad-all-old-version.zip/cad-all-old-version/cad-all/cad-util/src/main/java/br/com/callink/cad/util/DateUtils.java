/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.xml.bind.ValidationException;

/**
 * @author Fabio Borges de Oliveira <fabio@callink.com.br>
 * @data 29/05/2009
 * @hora 17:40:31
 */
public final class DateUtils {
	
	private DateUtils() {
    }
	/**
	 * Formato padrao de data para banco de dados yyyy-MM-dd HH:mm:ss
	 */
	public static final String FORMAT_DB_DEFAULT = "yyyy-MM-dd HH:mm:ss";

    /**
     * Metodo que retorna o dia de ontem
     * @return Integer
     */
    public static Integer getDayOfYesterday() {
        return getDateOfYesterday().get(Calendar.DATE);
    }

    /**
     * Metodo que retorna o dia de hoje
     * @return
     */
    public static Integer getDayOfToday() {
        Calendar calendar = getCalendar();
        return calendar.get(Calendar.DATE);
    }

    /**
     * Metodo que retorna a data de ontem
     * @return Calendar
     */
    public static Calendar getDateOfYesterday() {
        Calendar calendar = getCalendar();
        calendar.add(Calendar.DATE, -1);

        return calendar;
    }

    private static Calendar getCalendar() {
        return Calendar.getInstance();
    }

    /**
     * Metodos que retorna diferenï¿½a em dias entre dois periodo quaisquer.
     * @param c1 Calendar
     * @param c2 Calendar
     * @return quantidade de dias
     */
    public static Integer getDaysBetweenDates(Calendar c1, Calendar c2) {
        long m1 = c1.getTimeInMillis();
        long m2 = c2.getTimeInMillis();
        return (int) ((m2 - m1) / (24 * 60 * 60 * 1000));
    }

    /**
     * Metodos que retorna diferenï¿½a em dias entre dois periodo quaisquer.
     * @param d1 Date
     * @param d2 Date
     * @return quantidade de dias
     */
    public static Integer getDaysBetweenDates(Date d1, Date d2) {
        Calendar c1 = getCalendar();
        c1.setTime(d1);

        Calendar c2 = getCalendar();
        c2.setTime(d2);

        return getDaysBetweenDates(c1, c2);
    }

    /**
     * Metodos que retorna diferenï¿½a em dias entre dois periodo quaisquer.
     * @param c1 Calendar
     * @param d2 Date
     * @return quantidade de dias
     */
    public static Integer getDaysBetweenDates(Calendar c1, Date d2) {
        Calendar c2 = getCalendar();
        c2.setTime(d2);

        return getDaysBetweenDates(c1, c2);
    }

    /**
     * Metodos que retorna diferenï¿½a em dias entre dois periodo quaisquer.
     * @param d1 Date
     * @param c2 Calendar
     * @return quantidade de dias
     */
    public static Integer getDaysBetweenDates(Date d1, Calendar c2) {
        Calendar c1 = getCalendar();
        c1.setTime(d1);

        return getDaysBetweenDates(c1, c2);
    }

    /**
     * Metodos que retorna diferenï¿½a em minutos entre dois periodo quaisquer.
     * @param c1
     * @param c2
     * @return
     */
    public static Integer getMinutesBetweenDates(Calendar c1, Calendar c2) {
        long m1 = c1.getTimeInMillis();
        long m2 = c2.getTimeInMillis();
        return (int) ((m2 - m1) / (60 * 1000));
    }

    /**
     * Metodos que retorna diferenï¿½a em minutos entre dois periodo quaisquer.
     * @param d1
     * @param d2
     * @return
     */
    public static Integer getMinutesBetweenDates(Date d1, Date d2) {
        Calendar c1 = getCalendar();
        c1.setTime(d1);

        Calendar c2 = getCalendar();
        c2.setTime(d2);

        return getMinutesBetweenDates(c1, c2);
    }

    /**
     * Metodos que retorna diferenï¿½a em secundos entre dois periodo quaisquer.
     * @param c1
     * @param c2
     * @return
     */
    public static Integer getSecondsBetweenDates(Calendar c1, Calendar c2) {
        long m1 = c1.getTimeInMillis();
        long m2 = c2.getTimeInMillis();
        return (int) ((m2 - m1) / (1000));
    }

    /**
     * Metodos que retorna diferenï¿½a em minutos entre dois periodo quaisquer.
     * @param d1
     * @param d2
     * @return
     */
    public static Integer getSecondsBetweenDates(Date d1, Date d2) {
        Calendar c1 = getCalendar();
        c1.setTime(d1);

        Calendar c2 = getCalendar();
        c2.setTime(d2);

        return getSecondsBetweenDates(c1, c2);
    }

    /**
     * Metodo que retorna um calendar com a primeira hora do dia atual
     * @return
     */
    public static Calendar getFirstTimeOfDayCurrency() {
        Calendar c1 = getCalendar();
        c1.set(Calendar.AM_PM, Calendar.AM);
        c1.set(Calendar.HOUR, 0);
        c1.set(Calendar.HOUR_OF_DAY, 0);
        c1.set(Calendar.MINUTE, 0);
        c1.set(Calendar.SECOND, 0);
        c1.set(Calendar.MILLISECOND, 0);

        return c1;
    }

    /**
     * Metodo que adiciona a uma determinada data a primeira hora do dia
     * @param date
     * @return
     */
    public static Date addFirstTimeInDate(Date date) {
        if (date == null) {
            return date;
        }

        Calendar c1 = getCalendar();
        c1.setTime(date);
        c1.set(Calendar.AM_PM, Calendar.AM);
        c1.set(Calendar.HOUR, 0);
        c1.set(Calendar.HOUR_OF_DAY, 0);
        c1.set(Calendar.MINUTE, 0);
        c1.set(Calendar.SECOND, 0);
        c1.set(Calendar.MILLISECOND, 0);

        return c1.getTime();
    }

    /**
     * Metodo que retorna um calendar com a maior hora da data atual
     * @return
     */
    public static Calendar getLastTimeOfDayCurrency() {
        Calendar c1 = getCalendar();
        c1.set(Calendar.AM_PM, Calendar.PM);
        c1.set(Calendar.HOUR, 23);
        c1.set(Calendar.HOUR_OF_DAY, 23);
        c1.set(Calendar.MINUTE, 59);
        c1.set(Calendar.SECOND, 59);
        c1.set(Calendar.MILLISECOND, 999);

        return c1;
    }

    /**
     * Metodo que adiciona a uma determinada data a ultima hora do dia
     * @param date
     * @return
     */
    public static Date addLastTimeInDate(Date date) {
        if (date == null) {
            return date;
        }

        Calendar c1 = getCalendar();
        c1.setTime(date);
        c1.set(Calendar.AM_PM, Calendar.PM);
        c1.set(Calendar.HOUR, 23);
        c1.set(Calendar.HOUR_OF_DAY, 23);
        c1.set(Calendar.MINUTE, 59);
        c1.set(Calendar.SECOND, 59);
        c1.set(Calendar.MILLISECOND, 999);

        return c1.getTime();
    }

    /**
     * 
     * @return
     */
    public static String getYearFormated() {
        return "" + getCalendar().get(Calendar.YEAR);
    }

    /**
     *
     * @return
     */
    public static String getMonthFormated() {
        String mesAtual = ("00" + (getCalendar().get(Calendar.MONTH) + 1));
        return mesAtual.substring(mesAtual.length() - 2);
    }

    /**
     *
     * @return
     */
    public static String getDayFormated() {
        String diaAtual = ("00" + getCalendar().get(Calendar.DAY_OF_MONTH));
        return diaAtual.substring(diaAtual.length() - 2);
    }

    /**
     *
     * @param data
     * @return
     * @throws java.lang.Exception
     */
    public static String formatDate(Date data) throws ParseException {
        return format(data, "dd/MM/yyyy");
    }

    /**
     *
     * @param data
     * @return
     * @throws java.lang.Exception
     */
    public static String formatDateTime(Date data) throws ParseException {
        return format(data, "dd/MM/yyyy HH:mm:ss");
    }

    /**
     *
     * @param data
     * @param pattern
     * @return
     * @throws java.lang.Exception
     */
    public static String format(Date data, String pattern) throws ParseException {
        SimpleDateFormat df = new SimpleDateFormat(pattern);
        if (data.getClass().isAssignableFrom(Date.class)) {
            return df.format(data);
        } else {
            return df.format(df.parse(data.toString()));
        }
    }

    /**
     * Metodo que recebe uma determinada quantidade minutos e converter este minutos para o formato (HH:mm).
     * @param minutes
     * @return
     */
    public static String getHoursByMinutes(Object minutes) {
        if (minutes instanceof Double) {
            minutes = ((Double) minutes).intValue();
        }

        if (minutes != null) {
            Integer min = Integer.valueOf(minutes.toString().replace("-", ""));

            String m = String.valueOf(min % 60);
            if (m.length() == 1) {
                m = "0" + m;
            }

            String h = String.valueOf((min / 60));
            if (h.length() == 1) {
                h = "0" + h;
            }

            if (minutes.toString().contains("-")) {
                return "-" + h + ":" + m;
            } else {
                return h + ":" + m;
            }
        } else {
            return "00:00";
        }
    }

    /**
     * Metodo que recebe uma determinada quantidade milisegundos e converter este milisegundos para o formato (HH:mm:ss.ms).
     * @param minutes
     * @return
     */
    public static String getHoursByMilisegundos(Long miliseconds) {

        if (miliseconds != null) {

            Long sec = Long.valueOf(miliseconds.toString().replace("-", ""));

            String ms = String.valueOf(sec % 1000);
            if (ms.length() == 1) {
                ms = "0" + ms;
            }

            String s = String.valueOf((sec / 1000) % 60);
            if (s.length() == 1) {
                s = "0" + s;
            }

            String m = String.valueOf((sec / (60 * 1000)) % 60);
            if (m.length() == 1) {
                m = "0" + m;
            }

            String h = String.valueOf((sec / (60 * 1000)) / 60);
            if (h.length() == 1) {
                h = "0" + h;
            }

            return h + ":" + m + ":" + s + "." + ms;
        } else {
            return "00:00:00.000";
        }
    }
    
    /**
	 * Configura hora, minuto, segundo e milisegundo enviados na data passada como argumento.
	 * @param date
	 * @param hour
	 * @param minute
	 * @param second
	 * @param millisecond
	 * @return Date
	 */
	public static Date setTime(Date date, int hour, int minute, int second, int millisecond) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.set(Calendar.HOUR_OF_DAY, hour);
		calendar.set(Calendar.MINUTE, minute);
		calendar.set(Calendar.SECOND, second);
		calendar.set(Calendar.MILLISECOND, millisecond);
		return calendar.getTime();
	}
	
	/**
	 * Configura hora, minuto, segundo e milisegundo enviados na data passada como argumento.
	 * @param date
	 * @param hour
	 * @param minute
	 * @param second
	 * @param millisecond
	 * @return Calendar
	 */
	public static Calendar setTimeCalendar(Date date, int hour, int minute, int second, int millisecond) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.set(Calendar.HOUR_OF_DAY, hour);
		calendar.set(Calendar.MINUTE, minute);
		calendar.set(Calendar.SECOND, second);
		calendar.set(Calendar.MILLISECOND, millisecond);
		return calendar;
	}
	
	/**
	 * Muda a hora e minuto da data enviada
	 * @param data
	 * @param hora
	 * @return Date
	 */
	public static Date mudarHora(Date data, String hora) { 
		try {
			SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy HH:mm");
			return df.parse(new SimpleDateFormat("dd-MM-yyyy").format(data) + " " + hora);
		}
		catch (ParseException p){
			throw new RuntimeException(p);
		}
	}
	
	/**
     * Retorna a diferenea em minutos entre duas datas.
     *
     * @param start
     * @param end
     * @return
     */
    public static Long getMinutesDiff(Date start, Date end) {

        Calendar cStart = new GregorianCalendar();
        cStart.setLenient(false);
        cStart.setTime(start);
        cStart.clear(Calendar.SECOND);
        cStart.clear(Calendar.MILLISECOND);

        Calendar cEnd = new GregorianCalendar();
        cEnd.setLenient(false);
        cEnd.setTime(end);
        cEnd.clear(Calendar.SECOND);
        cEnd.clear(Calendar.MILLISECOND);

        Long diff = cEnd.getTimeInMillis() - cStart.getTimeInMillis();

        return diff / (60 * 1000);
    }
    
    /**
     * Esse metodo formata uma quantidade de minutos em uma <i>string</i> no formato <b>HH...H:mm</b>.
     *
     * @param minutos
     * @return
     */
	public static String formataMinutoEmHoraMinuto(Long minutos) {
		if (minutos == null) {
			return null;
		}
		String minutosHora = null;
        minutos = Math.abs(minutos);
        Long minuto = Long.valueOf(minutos % 60);
        Long hora = Long.valueOf(minutos / 60);
        
        minutosHora = (hora.toString().length() < 2 ? "0" + hora : hora) + ":" + (minuto.toString().length() < 2 ? "0" + minuto : minuto);
        
        return minutosHora;
    }
	
	/**
     * Passando um periodo definido como D = dia, S=semana, M=mes a função
     * devolve uma lista com dois elementos, o primeiro é a data inicial e o
     * segundo é a data final
     *
     * @param periodo
     * @return
     * @throws ValidationException
     */
    public static List<Calendar> buscaDataPorPeriodo(String periodo) throws ValidationException {
        Calendar dataInicial = null;
        Calendar dataFinal = null;
        Calendar dataAtual = new GregorianCalendar();
        Calendar dataOntem = new GregorianCalendar(dataAtual.get(Calendar.YEAR), dataAtual.get(Calendar.MONTH), (dataAtual.get(Calendar.DAY_OF_MONTH) - 1), Integer.valueOf("0"), Integer.valueOf("0"),
                Integer.valueOf("0"));
        Calendar dataAnteOntem = new GregorianCalendar(dataAtual.get(Calendar.YEAR), dataAtual.get(Calendar.MONTH), (dataAtual.get(Calendar.DAY_OF_MONTH) - 1), Integer.valueOf("0"),
                Integer.valueOf("0"), Integer.valueOf("0"));
        if (periodo.equalsIgnoreCase("D-1")) {
            dataInicial = new GregorianCalendar(dataOntem.get(Calendar.YEAR), dataOntem.get(Calendar.MONTH),
                    ((dataOntem.get(Calendar.DAY_OF_WEEK)) == (Calendar.SUNDAY)) ? ((dataAnteOntem.get(Calendar.DAY_OF_MONTH) <= 0) ? 1 : (dataAnteOntem.get(Calendar.DAY_OF_MONTH)))
                    : ((dataOntem.get(Calendar.DAY_OF_MONTH) <= 0) ? 1 : (dataOntem.get(Calendar.DAY_OF_MONTH))), Integer.valueOf("0"), Integer.valueOf("0"), Integer.valueOf("0"));
            dataFinal = new GregorianCalendar(dataAtual.get(Calendar.YEAR), dataAtual.get(Calendar.MONTH), dataAtual.get(Calendar.DAY_OF_MONTH), Integer.valueOf("0"), Integer.valueOf("0"),
                    Integer.valueOf("0"));
        } else if (periodo.equalsIgnoreCase("D")) {
            dataInicial = new GregorianCalendar(dataAtual.get(Calendar.YEAR), dataAtual.get(Calendar.MONTH), dataAtual.get(Calendar.DAY_OF_MONTH), Integer.valueOf("0"), Integer.valueOf("0"),
                    Integer.valueOf("0"));
            dataFinal = new GregorianCalendar(dataAtual.get(Calendar.YEAR), dataAtual.get(Calendar.MONTH), dataAtual.get(Calendar.DAY_OF_MONTH), Integer.valueOf("23"), Integer.valueOf("59"),
                    Integer.valueOf("59"));
        } else if (periodo.equalsIgnoreCase("S")) {
            dataInicial = new GregorianCalendar(dataAtual.get(Calendar.YEAR), dataAtual.get(Calendar.MONTH), (dataAtual.get(Calendar.DAY_OF_MONTH) - 7) <= 0 ? 1
                    : (dataAtual.get(Calendar.DAY_OF_MONTH) - 7), Integer.valueOf("0"), Integer.valueOf("0"), Integer.valueOf("0"));
            dataFinal = new GregorianCalendar(dataAtual.get(Calendar.YEAR), dataAtual.get(Calendar.MONTH), dataAtual.get(Calendar.DAY_OF_MONTH), Integer.valueOf("23"), Integer.valueOf("59"),
                    Integer.valueOf("59"));
        } else if (periodo.equalsIgnoreCase("M")) {
            dataInicial = new GregorianCalendar(dataAtual.get(Calendar.YEAR), dataAtual.get(Calendar.MONTH), 1, Integer.valueOf("0"), Integer.valueOf("0"), Integer.valueOf("0"));
            dataFinal = new GregorianCalendar(dataAtual.get(Calendar.YEAR), dataAtual.get(Calendar.MONTH), dataAtual.getActualMaximum(Calendar.DAY_OF_MONTH), Integer.valueOf("23"),
                    Integer.valueOf("59"), Integer.valueOf("59"));
        } else {
            throw new ValidationException("Periodo informado invalido");
        }
        return Arrays.asList(dataInicial, dataFinal);
    }
    
    /**
     * busca ultimo dia do mes e ano
     * 
     * @param mes
     * @param ano
     * @return
     * @throws ValidationException
     */
    public static int buscaUltimoDiaData(int mes, int ano) throws ValidationException {
    	Calendar cal = Calendar.getInstance();
    	cal.set(Calendar.MONTH, mes-1);
    	cal.set(Calendar.YEAR, ano);
    	
    	return cal.getActualMaximum(Calendar.DAY_OF_MONTH);
    }

    /**
     * Formata segundos em HH:mm:ss
     * 
     * @param segundos
     * @return
     */
	public static String formataTempo(long segundos) {
		Integer elapsed = (int) segundos;
		if(elapsed != null) {
		
		    int ss = elapsed % 60;
		    elapsed /= 60;
		    int min = elapsed % 60;
		    elapsed /= 60;
		    int hh = elapsed;
		    return strzero(hh) + ":" + strzero(min) + ":" + strzero(ss);
		} else {
			return "00:00:00";
		}
	}
	
	private static String strzero(int n) {
	    if(n < 10)
	      return "0" + String.valueOf(n);
	    return String.valueOf(n);
	}
}
