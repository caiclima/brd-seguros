/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.util;

/**
 *
 * @author Luiz Gustavo (luizgf@swb.com.br)
 */
public class EmailException extends Exception {

    public EmailException(Throwable thrwbl) {
        super(thrwbl);
    }

    public EmailException(String string, Throwable thrwbl) {
        super(string, thrwbl);
    }

    public EmailException(String string) {
        super(string);
    }

    public EmailException() {
    }
    
}
