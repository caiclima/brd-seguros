/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.util;

import br.com.callink.cad.pojo.Email;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author Luiz Gustavo F. (luizgf@swb.com.br)
 */
public final class EmailUtils {
    
    private static final String BR = "<br/>";
    private static final String ABRE_REMETENTE = BR+BR+BR+"----- ";
    private static final String FECHA_REMETENTE = " escreveu: -----"+BR+BR;
    private static final String ABRE_BLOCK_QUOTE = "<blockquote style=\"padding-right:0px;padding-left:5px;margin-left:5px;border-left:#000000 2px solid;margin-right:0px\">";
    private static final String ASSUNTO = BR+"Assunto: ";
    private static final String DATA = BR+"Data: ";
    private static final String FECHA_BLOCK_QUOTE = "</blockquote>";
    public static final String PREFIXO_ASSUNTO_EMAIL_RESPOSTA = "RE:";
    private static final String REGEX_EMAIL = "^[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{2,4}$";
    
    private EmailUtils(){}
    
    public static String anexaHistoricoEmail(Email email) {
        DateFormat df = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
        String data = df.format(email.getDataEnvio());
        StringBuilder retorno =  new StringBuilder()
                .append(ABRE_REMETENTE).append(email.getRemetente())
                .append(FECHA_REMETENTE)
                .append(ABRE_BLOCK_QUOTE)
                .append(ASSUNTO).append(email.getAssunto())
                .append(DATA).append(data)
                .append(BR).append(BR)
                .append(email.getConteudo())
                .append(FECHA_BLOCK_QUOTE);
        return retorno.toString();
    }
    
    public static boolean validarEmail(String email)  
    {  
        boolean isEmailIdValid = false;  
        if (email != null && !email.isEmpty()) {  
            Pattern pattern = Pattern.compile(REGEX_EMAIL, Pattern.CASE_INSENSITIVE);  
            Matcher matcher = pattern.matcher(email.trim());  
            if (matcher.matches()) {  
                isEmailIdValid = true;  
            }  
        }  
        return isEmailIdValid;  
    }  
}
