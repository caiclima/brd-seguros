package br.com.callink.cad.util;

import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.security.PrivateKey;
import java.security.PublicKey;

import javax.crypto.Cipher;

public class EncryptionUtils {

	public static final String ALGORITHM = "RSA";

	public static final String PRIVATE_KEY_FILE = "private.key";

	public static final String PUBLIC_KEY_FILE = "public.key";

	public static String encrypt(String text) {
		byte[] cipherText = null;
		try {
			ObjectInputStream inputStream = new ObjectInputStream(
					Thread.currentThread().getContextClassLoader().getResourceAsStream(PUBLIC_KEY_FILE));
			final PublicKey publicKey = (PublicKey) inputStream.readObject();
			// get an RSA cipher object and print the provider
			final Cipher cipher = Cipher.getInstance(ALGORITHM);
			// encrypt the plain text using the public key
			cipher.init(Cipher.ENCRYPT_MODE, publicKey);
			cipherText = cipher.doFinal(text.getBytes());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return _doCiphered(cipherText);
	}

	private static String _doCiphered(byte[] ciphered) {
		try {
			String cipheredString = new String();

			int i;
			for (i = 0; i < ciphered.length; i++) {
				cipheredString += (((int) ciphered[i]) + 500);
			}

			return cipheredString;
		} catch (NullPointerException e) {
			return null;
		}
	}

	private static byte[] _doNewCiphered(String cipheredString) {
		try {
			byte[] cipheredNew = new byte[cipheredString.length() / 3];

			int i, j, k;
			for (k = 0, i = 0, j = 3; k < cipheredString.length() / 3; k++, i += 3, j += 3) {
				cipheredNew[k] = (byte) (Integer.parseInt(cipheredString
						.substring(i, j)) - 500);
			}

			return cipheredNew;
		} catch (NullPointerException e) {
			return null;
		}
	}

	public static String decrypt(String text) {
		byte[] dectyptedText = null;
		try {
			ObjectInputStream inputStream = new ObjectInputStream(
					Thread.currentThread().getContextClassLoader().getResourceAsStream(PRIVATE_KEY_FILE));
			final PrivateKey privateKey = (PrivateKey) inputStream.readObject();
			// get an RSA cipher object and print the provider
			final Cipher cipher = Cipher.getInstance(ALGORITHM);

			// decrypt the text using the private key
			cipher.init(Cipher.DECRYPT_MODE, privateKey);
			dectyptedText = cipher.doFinal(_doNewCiphered(text));
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return new String(dectyptedText);
	}
}