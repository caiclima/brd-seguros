package br.com.callink.cad.util;

import java.io.File;

/**
 * @author Fabio Borges de Oliveira <fabio@callink.com.br>
 */
public abstract class FileUtils {

	protected File file;
	private String fileName;
	private String directoryName;

	public FileUtils(String fileName, String directoryName) {

		this.fileName = fileName;
		this.directoryName = directoryName;
		this.file = new File(getCompleteFileName());
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getDirectoryName() {
		return directoryName;
	}

	public void setDirectoryName(String directoryName) {
		this.directoryName = directoryName;
	}

	public File getFile() {
		return file;
	}

	public void setFile(File file) {
		this.file = file;
	}

	public abstract File createFile(Object[] objects) throws Exception;

	protected String getCompleteFileName() {
		StringBuffer completeFileName = new StringBuffer();

		if (directoryName != null && !directoryName.trim().equals("")) {
			completeFileName.append(directoryName);
		}

		completeFileName.append(fileName);

		return completeFileName.toString();
	}
}