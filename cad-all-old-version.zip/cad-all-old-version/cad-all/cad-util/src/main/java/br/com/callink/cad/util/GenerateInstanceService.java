package br.com.callink.cad.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.naming.InitialContext;

public final class GenerateInstanceService {
	
	private static List<Properties> listProperties;
	
	private GenerateInstanceService(){}
	
	public static Object getInstanceObject(String variable) throws Exception {
		try {
		
			Object object = null;
			
			if(variable != null) {
				
				@SuppressWarnings("rawtypes")
				Class classe = Class.forName(loadFile(variable));
				
				StringBuilder dadosLookup = new StringBuilder();
				dadosLookup.append("java:module/");
				dadosLookup.append(classe.getSimpleName());
				
				InitialContext initialContext = new InitialContext();
				object = initialContext.lookup(dadosLookup.toString());
				
			}
			
			return object;
		
		} catch (Exception e) {
			throw new Exception("Falha ao gerar instancia de objeto", e);
		}
	}
	
	private static String loadFile(String chave) throws Exception { 
		try {
			String property = null;
			
			for(Properties properties : getProperties()) {
				if(properties != null) {
					property = properties.getProperty(chave);
					
					if(property != null) {
						return property;
					}
				}
			}
			
			return property;
			
	    } catch (IOException ex) {  
	        throw new Exception(ex);
	    }  
	}
	
	private static List<Properties> getProperties() throws IOException {
		if(listProperties == null) {
			
			listProperties = new ArrayList<Properties>();
			
			Properties properties = new Properties();
			properties.load(GenerateInstanceService.class.getClassLoader().getResourceAsStream("config/application.properties"));
			
			String propertiesDados = properties.getProperty("context.files");
			
			String[] names = propertiesDados.split(",");
			
			for(String properti : names) {
				if(properti != null) {
					properties = new Properties();
					properties.load(GenerateInstanceService.class.getClassLoader().getResourceAsStream(properti.trim()));
					listProperties.add(properties);
				}
			}
			
		}
		return listProperties;
	}

}
