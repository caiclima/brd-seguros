package br.com.callink.cad.util;

import java.text.DecimalFormat;

public class NumberUtils {

	public static String formataPorcentagem(Double valor) {
		if (valor.isNaN()) {
			return "0%";
		}
		DecimalFormat decimal = new DecimalFormat("0.0");
		return decimal.format(valor) + "%";
	}
}
