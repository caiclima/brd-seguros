/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.mail.Address;
import javax.mail.BodyPart;
import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Part;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.internet.MimeUtility;

import br.com.callink.cad.pojo.Anexo;
import br.com.callink.cad.pojo.ConfiguracaoEmail;
import br.com.callink.cad.pojo.Email;

/**
 *
 * @author ubuntu
 */
public class ReceiveMail {

	private Properties properties;
	private static final String SEPARADOR = ", ";
	
    public ReceiveMail(Properties properties) {
    	this.properties = properties;
    	carregaProperties();
    }
    
    public ReceiveMail() {
	}

	private void carregaProperties(){
    	this.username = properties.getProperty(Constantes.PARAMETRO_EMAIL_USUARIO);
        this.password = properties.getProperty(Constantes.PARAMETRO_EMAIL_SENHA);
        this.popHost = properties.getProperty(Constantes.PARAMETRO_EMAIL_POPHOST);
        this.protocolStore = properties.getProperty(Constantes.PARAMETRO_EMAIL_PROTOCOLSTORE);
        this.receiveFolder = properties.getProperty(Constantes.PARAMETRO_EMAIL_FOLDER);
        String porta = properties.getProperty(Constantes.PARAMETRO_EMAIL_IMAPPORT);
    	if (porta != null && !porta.trim().isEmpty()) {
    		this.portaReceive = Integer.valueOf(porta);
    	}
    }
    
    private static int byteBuffer = 4096;
    private Folder folder;
    private Store store;
    private String username;
    private String password;
    private String popHost;
    private String protocolStore;
    private String receiveFolder;
    private int portaReceive;
    private Logger logger = Logger.getLogger(ReceiveMail.class.getName());
    
    public List<Email> listaEmail() throws MessagingException  {

        List<Email> listaEmail = new ArrayList<Email>();

        // Create empty properties
        Properties props = getProperties();
        // Get session
        Session session = Session.getInstance(props, null);
        
        // Get the store
        store = session.getStore(protocolStore);
        store.connect(popHost, portaReceive, username, password);

        // Get folder
        folder = store.getFolder(receiveFolder);
        folder.open(Folder.READ_WRITE);

        Message message[] = folder.getMessages();

        for (Message msgm : message) {
        	Email email = new Email();
        	try {
	        	Integer anexoManual = Integer.valueOf(1);
	            email.setRemetente(MimeUtility.decodeText(msgm.getFrom()[0].toString()));
	            email.setAssunto(msgm.getSubject() != null ? MimeUtility.decodeText(msgm.getSubject()) : "Sem assunto");
	            email.setFlagEnvioPendente(Boolean.FALSE);
	            email.setFlagLido(Boolean.FALSE);
	            email.setFlagErroEnvio(Boolean.FALSE);
	            email.setFlagEnvio(Boolean.FALSE);
	            email.setDestinatario(username);
            
                processaMensagem(msgm, email, anexoManual);

                listaEmail.add(email);
                msgm.setFlag(Flags.Flag.DELETED, true);
               
            } catch (Exception ex) {
                StringBuilder str = new StringBuilder();
                str.append("Erro ao processar mensagem");
                if (email != null) {
                    if (email.getAssunto() != null && !email.getAssunto().isEmpty()) {
                        str.append(" | Assunto: ");
                        str.append(email.getAssunto());
                    }
                    
                    if (email.getRemetente() != null && !email.getRemetente().isEmpty()) {
                        str.append(" | Remetente: ");
                        str.append(email.getRemetente());
                    }
                }
                logger.log(Level.SEVERE, str.toString(), ex);
            }
        }
        return listaEmail;
    }

    public void close() throws MessagingException, InterruptedException  {
    	Thread.sleep(2000);
        if (folder != null && folder.isOpen()) {
            folder.expunge();
            folder.close(false);
        }
        if (store != null) {
            store.close();
        }
    }

    private void preparaImputStreamAnexo(String fileName, BodyPart anexos, Anexo anx, Object obj, Email email) throws IOException, MessagingException {
        
    	if (fileName == null) {
            String type = anexos.getContentType();
            String[] name = type.split("(name\\*\\=.*'){1}");
            if (name.length > 1) {
                anx.setNomeReal(name[1]);
            }
        }

        InputStream is = anexos.getInputStream();

        byte[] b = new byte[byteBuffer];

        ByteArrayOutputStream bs = new ByteArrayOutputStream();

        int byteRead;
        
        while ((byteRead = is.read(b)) != -1) {
            bs.write(b, 0, byteRead);
        }

        anx.setDados(bs.toByteArray());
        email.getListaAnexos().add(anx);
        
        is.close();
        bs.close();
    }

    private void processaMensagem(Message msgm, Email email, Integer anexoManual) throws Exception  {

        if (Multipart.class.isInstance(msgm.getContent())) {

            Multipart parts = (Multipart) msgm.getContent();
            processaMensagem(parts, email, anexoManual);

        } else {
            processaMensagemText(null, msgm, email);
        }

    }

    private void processaMensagem(Multipart parts, Email email, Integer anexoManual) throws Exception {
    	
        for (int j = 0; j < parts.getCount(); j++) {

            BodyPart p = parts.getBodyPart(j);
           
            if (Multipart.class.isInstance(p.getContent())) {

                processaMensagem((Multipart) p.getContent(), email, anexoManual);

            } else {

                String disposition = p.getDisposition();
                if (Part.ATTACHMENT.equalsIgnoreCase(disposition)) {

                    processaAnexo(p, email, anexoManual);

                } else {

                    processaMensagemText(p, null, email);

                }
            }

        }
    }

    private void processaAnexo(BodyPart anexos, Email email, Integer anexoManual) throws Exception {

        Object obj = anexos.getContent();
        
        Anexo anx = new Anexo();
        String fileName = "";
        if ( anexos.getFileName() == null ) {
        	try {
        		fileName = "Anexo"+anexoManual+anexos.getContentType().substring(anexos.getContentType().lastIndexOf("."), anexos.getContentType().length());
        	} catch (Exception e) {
				logger.log(Level.SEVERE, "Erro ao definir o nome do anexo. Gerando um nome aleatório.");
				fileName = "Anexo"+anexoManual;
			}
        	anexoManual++;
        } else {
        	fileName = MimeUtility.decodeText(anexos.getFileName());
        }
        anx.setNomeReal(fileName);
        preparaImputStreamAnexo(fileName, anexos, anx, obj, email);
        
    }

    private void processaMensagemText(BodyPart mensagem, Message messge, Email email) throws Exception {

        String contentType = mensagem == null ? (messge == null ? "" : messge.getContentType()) : mensagem.getContentType();
        Object content = mensagem == null ? (messge == null ? "" : messge.getContent()) : mensagem.getContent();
        if (contentType.contains("text/html")) {

            email.getMensagemHtml().append(MimeUtility.decodeText(content.toString()));

        } else if (contentType.contains("text/plain")) {

            email.getMensagemTxt().append(MimeUtility.decodeText(content.toString()));

        }
    }
    
	public static String removeAcentos(String str) {
		str = Normalizer.normalize(str, Normalizer.Form.NFD);
		str = str.replaceAll("[^0-9a-zA-ZéúíóáÉÚÍÓÁèùìòàÈÙÌÒÀõãñÕÃÑêûîôâÊÛÎÔÂëÿüïöäËYÜÏÖÄçÇ\\s]+?", "");
		return str;
	}
	
	public List<Email> listaConfiguracaoEmail(List<ConfiguracaoEmail> configEmails) throws MessagingException  {

        List<Email> listaEmail = new ArrayList<Email>();
        
        for (ConfiguracaoEmail configEmail : configEmails) {
	
	        // Create empty properties
	        Properties props = getProperties();
	        // Get session
	        Session session = Session.getInstance(props, null);
	        
	        // Get the store
	        store = session.getStore(configEmail.getProtocolStore().trim());
	        store.connect(configEmail.getPop(), configEmail.getPorta(), configEmail.getEmail(), EncryptionUtils.decrypt(configEmail.getSenha().trim()));
	
	        // Get folder
	        folder = store.getFolder(configEmail.getFolder());
	        folder.open(Folder.READ_WRITE);
	
	        Message message[] = folder.getMessages();
	
	        for (Message msgm : message) {
	        	Email email = new Email();
	        	try {
		        	Integer anexoManual = Integer.valueOf(1);
		            email.setRemetente(MimeUtility.decodeText(msgm.getFrom()[0].toString()));
		            email.setAssunto(msgm.getSubject() != null ? MimeUtility.decodeText(msgm.getSubject()) : "Sem assunto");
		            email.setFlagEnvioPendente(Boolean.FALSE);
		            email.setFlagLido(Boolean.FALSE);
		            email.setFlagErroEnvio(Boolean.FALSE);
		            email.setFlagEnvio(Boolean.FALSE);
		           
		            if (msgm.getRecipients(Message.RecipientType.TO) != null && msgm.getRecipients(Message.RecipientType.TO).length > 0) {
		            	
		            	email.setDestinatario("");
			            
		            	for (Address address : msgm.getRecipients(Message.RecipientType.TO)) {
			            	email.setDestinatario(email.getDestinatario().concat(address.toString()).concat(SEPARADOR));
			            }
		            	
			            email.setDestinatario(email.getDestinatario().substring(0, email.getDestinatario().trim().length() -1));
		            }
		            
		            if (msgm.getRecipients(Message.RecipientType.CC) != null && msgm.getRecipients(Message.RecipientType.CC).length > 0) {
		            	
		            	email.setDestinatarioCopia("");
			            
		            	for (Address address : msgm.getRecipients(Message.RecipientType.CC)) {
			            	email.setDestinatarioCopia(email.getDestinatarioCopia().concat(address.toString()).concat(SEPARADOR));
			            }
		            	
			            email.setDestinatarioCopia(email.getDestinatarioCopia().substring(0, email.getDestinatarioCopia().trim().length() -1 ));
		            }
	            
	                processaMensagem(msgm, email, anexoManual);
	
	                listaEmail.add(email);
	                msgm.setFlag(Flags.Flag.DELETED, true);
	            } catch (Exception ex) {
	                StringBuilder str = new StringBuilder();
	                str.append("Erro ao processar mensagem");
	                if (email != null) {
	                    if (email.getAssunto() != null && !email.getAssunto().isEmpty()) {
	                        str.append(" | Assunto: ");
	                        str.append(email.getAssunto());
	                    }
	                    
	                    if (email.getRemetente() != null && !email.getRemetente().isEmpty()) {
	                        str.append(" | Remetente: ");
	                        str.append(email.getRemetente());
	                    }
	                }
	                logger.log(Level.SEVERE, str.toString(), ex);
	            } finally {
	    	        try {
	    	            close();
	    	        } catch (Exception ex) {
	    	        	logger.log(Level.SEVERE, "Erro ao fechar Folder MSG", ex);
	    	        }
	            }
	        }
	    }

        return listaEmail;
    }
	
	private Properties getProperties() {
		Properties props = new Properties();
        props.put("mail.imaps.partialfetch", false);
        return props;
	}
	
	public List<Email> fetchEmails(ConfiguracaoEmail configEmail) throws MessagingException  {

        List<Email> listaEmail = new ArrayList<Email>();
	
        // Create empty properties
        Properties props = getProperties();
        // Get session
        Session session = Session.getInstance(props, null);
        
        // Get the store
        store = session.getStore(configEmail.getProtocolStore().trim());
        store.connect(configEmail.getPop(), configEmail.getPorta(), configEmail.getEmail(), EncryptionUtils.decrypt(configEmail.getSenha().trim()));

        // Get folder
        folder = store.getFolder(configEmail.getFolder());
        folder.open(Folder.READ_WRITE);

        Message message[] = folder.getMessages();
        
        for (Message msgm : message) {
        	Email email = new Email();
        	try {
	        	Integer anexoManual = Integer.valueOf(1);
	            email.setRemetente(MimeUtility.decodeText(msgm.getFrom()[0].toString()));
	            email.setAssunto(msgm.getSubject() != null ? MimeUtility.decodeText(msgm.getSubject()) : "Sem assunto");
	            email.setFlagEnvioPendente(Boolean.FALSE);
	            email.setFlagLido(Boolean.FALSE);
	            email.setFlagErroEnvio(Boolean.FALSE);
	            email.setFlagEnvio(Boolean.FALSE);
	           
	            if (msgm.getRecipients(Message.RecipientType.TO) != null && msgm.getRecipients(Message.RecipientType.TO).length > 0) {
	            	
	            	email.setDestinatario("");
		            
	            	for (Address address : msgm.getRecipients(Message.RecipientType.TO)) {
		            	email.setDestinatario(email.getDestinatario().concat(address.toString()).concat(SEPARADOR));
		            }
	            	
		            email.setDestinatario(email.getDestinatario().substring(0, email.getDestinatario().trim().length() -1));
	            }
	            
	            if (msgm.getRecipients(Message.RecipientType.CC) != null && msgm.getRecipients(Message.RecipientType.CC).length > 0) {
	            	
	            	email.setDestinatarioCopia("");
		            
	            	for (Address address : msgm.getRecipients(Message.RecipientType.CC)) {
		            	email.setDestinatarioCopia(email.getDestinatarioCopia().concat(address.toString()).concat(SEPARADOR));
		            }
	            	
		            email.setDestinatarioCopia(email.getDestinatarioCopia().substring(0, email.getDestinatarioCopia().trim().length() -1));
	            }
            
                processaMensagem(msgm, email, anexoManual);

                listaEmail.add(email);
                msgm.setFlag(Flags.Flag.DELETED, true);
            } catch (Exception ex) {
                StringBuilder str = new StringBuilder();
                str.append("Erro ao processar mensagem");
                if (email != null) {
                    if (email.getAssunto() != null && !email.getAssunto().isEmpty()) {
                        str.append(" | Assunto: ");
                        str.append(email.getAssunto());
                    }
                    
                    if (email.getRemetente() != null && !email.getRemetente().isEmpty()) {
                        str.append(" | Remetente: ");
                        str.append(email.getRemetente());
                    }
                }
                logger.log(Level.SEVERE, str.toString(), ex);
            } 
        }
        
        try {
            close();
        } catch (Exception ex) {
        	logger.log(Level.SEVERE, "Erro ao fechar Folder MSG", ex);
        }

        return listaEmail;
    }
	
}
