/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.util;

/**
 *
 * @author Luiz Gustavo (luizgf@swb.com.br)
 */
import java.util.List;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;

import br.com.callink.cad.pojo.Anexo;
import br.com.callink.cad.pojo.Email;

public class SendEmail {

    public SendEmail() {
        
    }
    private String smtpAuthUser;
    private String smtpAuthPw;
    private Properties props;

    public void send(String remetente, String destinatario, String assunto, String conteudo, Properties properties) throws EmailException {
        try {
        	this.props = properties;
            this.smtpAuthUser = properties.getProperty(Constantes.PARAMETRO_EMAIL_USUARIO);
            this.smtpAuthPw = properties.getProperty(Constantes.PARAMETRO_EMAIL_SENHA);
            String contentType = "text/html; charset=\"utf-8\"";

            Session mailSession = null;

            Authenticator auth = new SMTPAuthenticator();
            mailSession = Session.getInstance(props, auth);

            Transport transport = mailSession.getTransport();

            MimeMessage message = new MimeMessage(mailSession);
            message.setSubject(assunto);

            message.setContent(conteudo, contentType);
            message.setFrom(new InternetAddress(remetente));
            String[] adresses = destinatario.split(", ");
            for (int i = 0; i < adresses.length; i++) {
                message.addRecipient(Message.RecipientType.TO, new InternetAddress(adresses[i]));
            }
            message.saveChanges();

            transport.connect();
            transport.sendMessage(message, message.getRecipients(Message.RecipientType.TO));
            transport.close();
        } catch (MessagingException ex) {
            throw new EmailException("Erro ao enviar email.", ex);
        }
    }

    public void send(String remetente, String destinatario, String assunto, String conteudo, List<Anexo> listaAnexo, Properties properties) throws EmailException {
        try {
        	this.props = properties;
            this.smtpAuthUser = properties.getProperty(Constantes.PARAMETRO_EMAIL_USUARIO);
            this.smtpAuthPw = properties.getProperty(Constantes.PARAMETRO_EMAIL_SENHA);
            String contentType = "text/html; charset=\"utf-8\"";

            Session mailSession = null;

            Authenticator auth = new SMTPAuthenticator();
            mailSession = Session.getInstance(props, auth);

            Transport transport = mailSession.getTransport();

            MimeMessage message = new MimeMessage(mailSession);
            message.setSubject(assunto);
            message.setFrom(new InternetAddress(remetente));
            destinatario.replaceAll("[ ]", "");
            
            Boolean contemVirgula = destinatario.contains(",");
            Boolean contemPontoVirgula = destinatario.contains(";");
            
            if (contemVirgula) {
		    	for(String dest : destinatario.split(",")) {
		    		if (dest.contains(";")) {
		    			for (String destVir : dest.split(";")) {
		    				message.addRecipient(Message.RecipientType.TO, new InternetAddress(destVir));
		    			}
		    		} else {
		    			message.addRecipient(Message.RecipientType.TO, new InternetAddress(dest));
		    		}
		    	}
            } else {
            	if (contemPontoVirgula) {
    		    	for(String dest : destinatario.split(";")) {
   		    			message.addRecipient(Message.RecipientType.TO, new InternetAddress(dest));
    		    	}
            	} else {
            		message.addRecipient(Message.RecipientType.TO, new InternetAddress(destinatario));
            	}
            }
            
            	
            if (listaAnexo != null && listaAnexo.size() > 0) {
                MimeMultipart mp = new MimeMultipart();

                MimeBodyPart stringConteudo = new MimeBodyPart();
                stringConteudo.setContent(conteudo, contentType);
                mp.addBodyPart(stringConteudo);
                
                for (Anexo anx : listaAnexo) {

                    MimeBodyPart mbp = new MimeBodyPart();
                    mbp.setFileName(anx.getNomeReal());
                    DataSource dts = new ByteArrayDataSource(anx.getDados(), "application/octet-stream");
                    mbp.setDataHandler(new DataHandler(dts));
                    mp.addBodyPart(mbp);

                }

                message.setContent(mp);
            }else{
                message.setContent(conteudo, contentType);
            }

            message.saveChanges();

            transport.connect();
            transport.sendMessage(message, message.getRecipients(Message.RecipientType.TO));
            transport.close();
        } catch (Exception ex) {
            throw new EmailException("Erro ao enviar email.", ex);
        }
    }
    
    public void send(Email email, List<Anexo> listaAnexo, Properties properties) throws EmailException {
        try {
        	this.props = properties;
            this.smtpAuthUser = properties.getProperty(Constantes.PARAMETRO_EMAIL_USUARIO);
            this.smtpAuthPw = properties.getProperty(Constantes.PARAMETRO_EMAIL_SENHA);
            String contentType = "text/html; charset=\"utf-8\"";

            Session mailSession = null;

            Authenticator auth = new SMTPAuthenticator();
            mailSession = Session.getInstance(props, auth);

            Transport transport = mailSession.getTransport();

            MimeMessage message = new MimeMessage(mailSession);
            message.setSubject(email.getAssunto());
            message.setFrom(new InternetAddress(email.getRemetente()));
           
            setDestinatarios(email, message);
            	
            if (listaAnexo != null && listaAnexo.size() > 0) {
                MimeMultipart mp = new MimeMultipart();

                MimeBodyPart stringConteudo = new MimeBodyPart();
                stringConteudo.setContent(email.getConteudo(), contentType);
                mp.addBodyPart(stringConteudo);
                
                for (Anexo anx : listaAnexo) {

                    MimeBodyPart mbp = new MimeBodyPart();
                    mbp.setFileName(anx.getNomeReal());
                    DataSource dts = new ByteArrayDataSource(anx.getDados(), "application/octet-stream");
                    mbp.setDataHandler(new DataHandler(dts));
                    mp.addBodyPart(mbp);

                }

                message.setContent(mp);
            }else{
                message.setContent(email.getConteudo(), contentType);
            }

            message.saveChanges();

            transport.connect();
            transport.sendMessage(message, message.getRecipients(Message.RecipientType.TO));
            transport.close();
        } catch (Exception ex) {
            throw new EmailException("Erro ao enviar email.", ex);
        }
    }

	private void setDestinatarios(Email email, MimeMessage message) throws MessagingException, AddressException {
		String destinatarios = email.getDestinatario();
		String destinatariosCC = email.getDestinatarioCopia();
		String destinatariosCCo = email.getDestinatarioCopiaOculta();
		
		if(destinatarios != null){
			for (String destinatario : destinatarios.replaceAll("[ ]", "").replaceAll(";", ",").split(",")) {
				message.addRecipient(Message.RecipientType.TO, new InternetAddress(destinatario));
			}
		}
		
		if(destinatariosCC != null){
			for (String destinatario : destinatariosCC.replaceAll("[ ]", "").replaceAll(";", ",").split(",")) {
				message.addRecipient(Message.RecipientType.CC, new InternetAddress(destinatario));
			}
		}
		
		if(destinatariosCCo != null){
			for (String destinatario : destinatariosCCo.replaceAll("[ ]", "").replaceAll(";", ",").split(",")) {
				message.addRecipient(Message.RecipientType.BCC, new InternetAddress(destinatario));
			}
		}
	}

    private class SMTPAuthenticator extends javax.mail.Authenticator {

        @Override
        public PasswordAuthentication getPasswordAuthentication() {
            String username = smtpAuthUser;
            String password = smtpAuthPw;
            return new PasswordAuthentication(username, password);
        }
    }
}