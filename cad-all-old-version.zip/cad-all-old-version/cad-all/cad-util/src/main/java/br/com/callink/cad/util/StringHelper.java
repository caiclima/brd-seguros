package br.com.callink.cad.util;

/**
 * Classe utilitária StringHelper, tem por objetivo facilitar o trabalho com
 * Strings
 * 
 * @author Marco Túlio G. Moura
 */
public abstract class StringHelper {

	public static boolean isNullOrEmpty(String string) {
		return string == null || string.trim().isEmpty();
	}
	
	public static String retirarEspacosEmBranco(String str){
		return str == null ? str : str.replaceAll("\\s{2,}", " ").trim();
	}

}
