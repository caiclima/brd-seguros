/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.backbean;

import java.util.List;

import javax.ejb.EJB;

import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.Email;
import br.com.callink.cad.pojo.Log;
import br.com.callink.cad.pojo.LogLigacoes;
import br.com.callink.cad.service.IAtendenteService;
import br.com.callink.cad.service.ICasoService;
import br.com.callink.cad.service.IEmailService;
import br.com.callink.cad.service.ILogLigacoesService;
import br.com.callink.cad.service.ILogService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 *
 * @author Rogério Moreira de Andrade
 */
public abstract class AbstractAtendenteCasoBB<T extends Caso, SERVICE extends ICasoService> extends CadGenericCrud<T, SERVICE> implements IAtendenteCasoBB{

	private static final long serialVersionUID = 1L;
	private List<Log> historicoCaso;
	private List<LogLigacoes> logLigacoesList;
    private List<Log> historicoEmailCaso;
    private Email emailSelecionado;
    private Atendente atendente;
    private String usuarioAtual;
    
    @EJB
    private IEmailService emailService;
    @EJB
    private ILogService logService;
    @EJB
    private ILogLigacoesService logLigacoesService;
    @EJB
    private IAtendenteService atendenteService;
    
    /*public AbstractAtendenteCasoBB() {
        super();
    }*/
    
    public void atualizaHistorico() {
        try {
            if (getPojo() != null) {
                this.historicoCaso = logService.findHistorico(getPojo());
            }
        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }
    }
    
    public void atualizaHistoricoLigacoes() {
    	try {
            if (getPojo() != null) {
                this.setLogLigacoesList(logLigacoesService.findByFilters(getPojo().getIdExterno(), null, null, null, null));
            }
        }catch (ValidationException ex) {
            error(ex.getMessage());
        }catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }
    }
  
    public void atualizaHistoricoEmails() {
        try {
            if (getPojo() != null) {
                this.historicoEmailCaso = logService.findHistoricoEmail(getPojo());
            }
        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }
    }
  
    public List<Log> getHistoricoCaso() {
        return historicoCaso;
    }

    public void setHistoricoCaso(List<Log> historicoCaso) {
        this.historicoCaso = historicoCaso;
    }

    public List<Log> getHistoricoEmailCaso() {
        return historicoEmailCaso;
    }

    public void setHistoricoEmailCaso(List<Log> historicoEmailCaso) {
        this.historicoEmailCaso = historicoEmailCaso;
    }

    public Email getEmailSelecionado() {
        return emailSelecionado;
    }

    public void setEmailSelecionado(Email emailSelecionado) {
        this.emailSelecionado = emailSelecionado;
    }
    
    public void visualizarEmail(Email email) {
        setEmailSelecionado(email);
        if (email.getGrupoAnexo() != null && email.getGrupoAnexo().getIdGrupoAnexo() != null) {
        	buscaAnexos(email.getGrupoAnexo().getIdGrupoAnexo());
        }
        try {
            emailService.lerEmail(email, getPojo());
        } catch (ValidationException e) {
			error(e);
		}catch (ServiceException ex) {
			logger.error(ex);
            error(ex);
        }
    }
    
    public String getDestinatarioSelecionado() {
        if (emailSelecionado == null) {
            return null;
        }
        return emailSelecionado.getDestinatario();
    }
    
    public String getRemetenteOuDestinatario(Email email) {
        if (email.getFlagEnvio() == null) {
            return null;
        }
        return email.getFlagEnvio() ? //foi enviado pelo gbo? 
                email.getDestinatarioParaExibicao() == null ? //mostra destinatario p/ exibiçao se houver
                email.getDestinatario() : email.getDestinatarioParaExibicao() //senao mostra o campo destinatario
                : email.getRemetente(); //se foi recebido mostra remetente
    }
    
    public Atendente getAtendente() {
        try {
        	if (atendente == null) {
        		atendente = atendenteService.findByLogin(getLoginUsuario()); 
        	}
            usuarioAtual = getLoginUsuario(); 
        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }
        return atendente;
    }

	public final String getUsuarioAtual() {
		return usuarioAtual;
	}

	public final void setUsuarioAtual(String usuarioAtual) {
		this.usuarioAtual = usuarioAtual;
	}

	public final void setAtendente(Atendente atendente) {
		this.atendente = atendente;
	}

	public List<LogLigacoes> getLogLigacoesList() {
		return logLigacoesList;
	}

	public void setLogLigacoesList(List<LogLigacoes> logLigacoesList) {
		this.logLigacoesList = logLigacoesList;
	}
    
    

}
