package br.com.callink.cad.backbean;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.model.SelectItem;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.pojo.TipoAcao;
import br.com.callink.cad.service.IAcaoService;
import br.com.callink.cad.service.ITipoAcaoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.util.JSFUtil;

/**
 * 
 * @author Ednaldo Caic [ednaldo@swb.com.br]
 * @since 09/01/2012
 */
@ManagedBean
@ViewScoped
public class AcaoBB extends CadGenericCrud<Acao, IAcaoService> {

	private static final long serialVersionUID = 1L;
	private List<TipoAcao> tipoAcaoList;
	
	private String flagAtivo;
	
	@EJB
	private IAcaoService acaoService;
	@EJB
	private ITipoAcaoService tipoAcaoService;
	
	@PostConstruct
	public void init(){
		try {
			setPojos(getService().findAtivos());
			novo();
            getPojo().setFlagAtivo(Boolean.TRUE);
            setFlagAtivo(Boolean.TRUE.toString());
		} catch (ServiceException ex) {
			logger.error(ex);
			error(ex);
		}
	}
	
	@Override
	public void novo() {
		setPojo(new Acao());
		tipoAcaoList = null;
		getPojo().setFlagAtivo(Boolean.TRUE);
	}

	@Override
	public String salvar() {
		getPojo().setLoginUsuario(getUserInfo().getUserLogin());
		return super.salvar();
	}

	public void alteraValorPojo(Acao acao) {
		super.setPojo(acao);
	}

	public String excluir(Acao acao) {
		try {
			try {
				getService().delete(acao);
			} catch (ValidationException e) {
				error(e.getMessage());
			}
			filtrar();
		} catch (ServiceException ex) {
			logger.error(ex);
			error(ex);
		}
		return null;
	}
	
	public void findAll() {
		try {
			setPojos(getService().findByExample(getPojo()));
		} catch (ServiceException ex) {
			logger.error(ex);
			error(ex);
		}
	}

	/**
	 * @return the tipoAcaoList
	 */
	public final List<SelectItem> getTipoAcaoList() {
		if (tipoAcaoList == null) {
			try {
				tipoAcaoList = tipoAcaoService.findAtivos("TipoAcao.NOME");
			} catch (ServiceException e) {
				logger.error(e);
				error(e);
			}
		}
		return JSFUtil.toSelectItemConsulta(tipoAcaoList);
	}

	/**
	 * @param tipoAcaoList the tipoAcaoList to set
	 */
	public final void setTipoAcaoList(List<TipoAcao> tipoAcaoList) {
		this.tipoAcaoList = tipoAcaoList;
	}
	
	@Override
	protected IAcaoService getService() {
		return acaoService;
	}
	
	public String getFlagAtivo() {
		return flagAtivo;
	}

	public void setFlagAtivo(String flagAtivo) {
		this.flagAtivo = flagAtivo;
		
		if(StringUtils.isBlank(flagAtivo)){
			getPojo().setFlagAtivo(null);
		}else{
			getPojo().setFlagAtivo(Boolean.valueOf(flagAtivo));
		}
	}
	
}
