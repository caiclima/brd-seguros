/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.backbean;

import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.pojo.AcaoComando;
import br.com.callink.cad.pojo.Comando;
import br.com.callink.cad.service.IAcaoService;
import br.com.callink.cad.service.IComandoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

/**
 *
 * @author Rogério Moreira de Andrade. [rogeriom@swb.com.br]
 */
@ManagedBean
@ViewScoped
public class AcaoComandoBB extends CadGenericCrud<Acao, IAcaoService> {

	private static final long serialVersionUID = -3475531829434864640L;
	
    private AcaoComando acaoComando;
    private List<AcaoComando> acaoComandoList;
    private List<Acao> listaAcao;
    private List<Comando> listaComando;
    
    @EJB
    private IAcaoService acaoService;
    @EJB
    private IComandoService comandoService;

    @PostConstruct
    public void init() {
    	novo();
    }

    @Override
    public String salvar() {
        try {
            getService().associa(acaoComando);
            filtrar();
        }catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException ex) {
			logger.error(ex);
            error(ex);
        }
        return null;
    }

    public void excluir(AcaoComando acaoComando) {
        try {
            getService().excluiAssociacao(acaoComando);
            filtrar();
        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }
    }

    public void filtrarAcao() {
        try {
            Acao acao = acaoComando.getAcao();
            acao.setFlagAtivo(Boolean.TRUE);
            listaAcao = getService().findByExample(acao, "Acao.NOME");

        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }
    }

    public void filtrarComando() {
        try {
            Comando comando = acaoComando.getComando();
            comando.setFlagAtivo(Boolean.TRUE);
            listaComando = comandoService.findByExample(comando, "Comando.NOME");

        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }
    }

    @Override
    public void novo() {
        setPojo(new Acao());
        this.acaoComando = new AcaoComando(new Acao(), new Comando());
        this.acaoComandoList = new ArrayList<AcaoComando>();
        this.listaAcao = new ArrayList<Acao>();
        this.listaComando = new ArrayList<Comando>();
        
		try {
			this.acaoComandoList = getService().findByExample(acaoComando.getAcao(), acaoComando.getComando());
		} catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException e) {
			logger.error(e);
			error(e);
		}
    }

    @Override
    public String filtrar() {
        try {
          this.acaoComandoList = getService().findByExample(acaoComando.getAcao(), acaoComando.getComando());
        } catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException ex) {
			logger.error(ex);
            error(ex);
        }
        return null;

    }

    public void setAcao(Acao acao) {
        this.acaoComando.setAcao(acao);
    }

    public void setComando(Comando comando) {
        this.acaoComando.setComando(comando);
    }

    public List<AcaoComando> getAcaoComandoList() {
        return acaoComandoList;
    }

    public void setAcaoComandoList(List<AcaoComando> acaoComandoList) {
        this.acaoComandoList = acaoComandoList;
    }

    public AcaoComando getAcaoComando() {
        return acaoComando;
    }

    public void setAcaoComando(AcaoComando acaoComando) {
        this.acaoComando = acaoComando;
    }

    public List<Acao> getListaAcao() {
        return listaAcao;
    }

    public void setListaAcao(List<Acao> listaAcao) {
        this.listaAcao = listaAcao;
    }

    public List<Comando> getListaComando() {
        return listaComando;
    }

    public void setListaComando(List<Comando> listaComando) {
        this.listaComando = listaComando;
    }
    
    @Override
	protected IAcaoService getService() {
		return acaoService;
	}
}
