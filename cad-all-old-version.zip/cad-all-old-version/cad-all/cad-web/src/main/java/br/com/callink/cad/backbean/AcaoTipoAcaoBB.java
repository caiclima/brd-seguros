/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.backbean;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.pojo.AcaoTipoAcao;
import br.com.callink.cad.pojo.AcaoTipoAcaoId;
import br.com.callink.cad.pojo.TipoAcao;
import br.com.callink.cad.service.IAcaoService;
import br.com.callink.cad.service.ITipoAcaoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 *
 * @author Bruno. [brunoam@swb.com.br]
 */
@ManagedBean
@ViewScoped
public class AcaoTipoAcaoBB extends CadGenericCrud<TipoAcao, ITipoAcaoService> {

	private static final long serialVersionUID = 5670454269978023306L;
	
	private AcaoTipoAcao acaoTipoAcao;
    private List<AcaoTipoAcao> acaoTipoAcaoList;
    private List<Acao> listaAcao;
    private List<TipoAcao> listaTipoAcao;
    
    @EJB
    private ITipoAcaoService tipoAcaoService;
    @EJB
    private IAcaoService acaoService;

    @PostConstruct
    public void init() {
    	novo();
        filtrar();
    }

    @Override
    public String salvar() {
        try {
            getService().associa(acaoTipoAcao);
            filtrar();
        } catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException ex) {
			logger.error(ex);
            error(ex);
        }
        return null;
    }

    public void excluir(AcaoTipoAcao acaoTipoAcao) {
        try {
            getService().excluiAssociacao(acaoTipoAcao);
            filtrar();
        } catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException ex) {
			logger.error(ex);
            error(ex);
        }
    }

    public void filtrarAcao() {
        try {
            Acao acao = acaoTipoAcao.getAcaoTipoAcaoId().getIdAcao();
            acao.setFlagAtivo(Boolean.TRUE);
            listaAcao = acaoService.findByExample(acao, "Acao.NOME");

        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }
    }

    public void filtrarTipoAcao() {
        try {
            TipoAcao tipoAcao = acaoTipoAcao.getAcaoTipoAcaoId().getIdTipoAcao();
            tipoAcao.setFlagAtivo(Boolean.TRUE);
            listaTipoAcao = getService().findByExample(tipoAcao, "TipoAcao.NOME");

        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }
    }

    @Override
    public void novo() {
        this.acaoTipoAcao = new AcaoTipoAcao();
        this.acaoTipoAcao.setAcaoTipoAcaoId(new AcaoTipoAcaoId(new TipoAcao(), new Acao()));
        this.acaoTipoAcaoList = new ArrayList<AcaoTipoAcao>();
        this.listaAcao = new ArrayList<Acao>();
        this.listaTipoAcao = new ArrayList<TipoAcao>();
    }

    @Override
    public String filtrar() {
        try {
            Acao acao = acaoTipoAcao.getAcaoTipoAcaoId().getIdAcao();
            TipoAcao tipoAcao = acaoTipoAcao.getAcaoTipoAcaoId().getIdTipoAcao();
            boolean isAcao = acao != null && acao.getIdAcao() != null;
            boolean isTipoAcao = tipoAcao != null && tipoAcao.getIdTipoAcao() != null;

            if (isAcao && !isTipoAcao) {
                acaoTipoAcaoList = getService().find(acao,null);
            } else if (!isAcao && isTipoAcao) {
            	acaoTipoAcaoList = getService().find(null,tipoAcao);
            } else if (isAcao && isTipoAcao) {
            	acaoTipoAcaoList = getService().find(acao, tipoAcao);
            } else {
            	acaoTipoAcaoList = getService().findAllAcaoTipoAcao();
            }
        } catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException ex) {
			logger.error(ex);
            error(ex);
        }
        return null;

    }

	/**
	 * @return the acaoTipoAcao
	 */
	public final AcaoTipoAcao getAcaoTipoAcao() {
		return acaoTipoAcao;
	}

	/**
	 * @param acaoTipoAcao the acaoTipoAcao to set
	 */
	public final void setAcaoTipoAcao(AcaoTipoAcao acaoTipoAcao) {
		this.acaoTipoAcao = acaoTipoAcao;
	}

	/**
	 * @return the acaoTipoAcaoList
	 */
	public final List<AcaoTipoAcao> getAcaoTipoAcaoList() {
		return acaoTipoAcaoList;
	}

	/**
	 * @param acaoTipoAcaoList the acaoTipoAcaoList to set
	 */
	public final void setAcaoTipoAcaoList(List<AcaoTipoAcao> acaoTipoAcaoList) {
		this.acaoTipoAcaoList = acaoTipoAcaoList;
	}

	/**
	 * @return the listaAcao
	 */
	public final List<Acao> getListaAcao() {
		return listaAcao;
	}

	/**
	 * @param listaAcao the listaAcao to set
	 */
	public final void setListaAcao(List<Acao> listaAcao) {
		this.listaAcao = listaAcao;
	}

	/**
	 * @return the listaTipoAcao
	 */
	public final List<TipoAcao> getListaTipoAcao() {
		return listaTipoAcao;
	}

	/**
	 * @param listaTipoAcao the listaTipoAcao to set
	 */
	public final void setListaTipoAcao(List<TipoAcao> listaTipoAcao) {
		this.listaTipoAcao = listaTipoAcao;
	}

    public final void setAcao(Acao acao) {
    	acaoTipoAcao.getAcaoTipoAcaoId().setIdAcao(acao);
    }
    
    public final void setTipoAcao(TipoAcao tipoAcao) {
    	acaoTipoAcao.getAcaoTipoAcaoId().setIdTipoAcao(tipoAcao);
    }
    
    @Override
	protected ITipoAcaoService getService() {
		return tipoAcaoService;
	}
}
