package br.com.callink.cad.backbean;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.model.SelectItem;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.Equipe;
import br.com.callink.cad.pojo.Perfil;
import br.com.callink.cad.service.IAtendenteService;
import br.com.callink.cad.service.IEquipeService;
import br.com.callink.cad.service.IPerfilService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.util.JSFUtil;

/**
 * 
 * @author brunomt [brunoam@swb.com.br]
 * 
 */
@ManagedBean
@ViewScoped
public class AtendenteBB extends CadGenericCrud<Atendente, IAtendenteService> {
	private static final long serialVersionUID = 1L;

	private Atendente atendenteFind;
	private List<Perfil> perfilList;
	private List<Equipe> equipeList;
	
	private String flagAtivo;
	
	@EJB
	private IPerfilService perfilService;
	@EJB
	private IEquipeService equipeService;

	private transient Perfil perfilSelecionado;
	
	@EJB
	private IAtendenteService atendenteService;
	
	@PostConstruct
    public void init() {
		setPojo(new Atendente());
		atendenteFind = new Atendente();
		equipeList = new ArrayList<Equipe>();
		perfilList = new ArrayList<Perfil>();
		
		novaTela();
	}
	
    public void novaTela() {
    	try {
			perfilList = perfilService.findAtivos();
			equipeList = equipeService.findAtivos();
		} catch (ServiceException e) {
			logger.error(e);
			error(e);
		}
		
    	setAtendenteFind(new Atendente());	
    	getAtendenteFind().setFlagAtivo(true);
    	
    	novo();
    	getPojo().setFlagAtivo(true);
	}

	@Override
    public String salvar() {
        String ret = super.salvar();
        if (getPojo().getIdAtendente() != null) {
        	novaTela();
        	pesquisar();
        }
        return ret;
    }
	
	public void pesquisar() {
		try {
                    List<Atendente> atendentes = getService().findByExampleAll(atendenteFind);
                    if(atendentes != null){
                            setPojos(atendentes);
                    } else {
                            setPojos(new ArrayList<Atendente>());
                    }
		} catch (ServiceException e) {
			logger.error(e);
			error(e);
		}
	}

	public String excluir(Atendente atendente) {
        try {
            getService().delete(atendente);
            filtrar();

        } catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException ex) {
			logger.error(ex);
            error(ex);
        }
        return null;
    }
    
    public void alterar(Atendente atendente) {
    	if (atendente.getEquipe() != null && atendente.getEquipe().getFlagAtivo()!= null &&  !atendente.getEquipe().getFlagAtivo()) {
    		equipeList.add(atendente.getEquipe());
    	}
    	if (atendente.getPerfil() != null && atendente.getPerfil().getFlagAtivo() != null && !atendente.getPerfil().getFlagAtivo()) {
    		perfilList.add(atendente.getPerfil());
    	}
    	
    	setPojo(atendente);
    }
    
    @Override
	public void novo() {
		setPojo(new Atendente());
	}

	public void setAtendenteFind(Atendente atendenteFind) {
		this.atendenteFind = atendenteFind;
	}

	public Atendente getAtendenteFind() {
		return atendenteFind;
	}

	public void setPerfilList(List<Perfil> perfilList) {
		this.perfilList = perfilList;
	}

	public List<SelectItem> getPerfilList() {
		return JSFUtil.toSelectItemConsulta(perfilList);
	}

	public void setEquipeList(List<Equipe> equipeList) {
		this.equipeList = equipeList;
	}

	public List<SelectItem> getEquipeList() {
		return JSFUtil.toSelectItemConsulta(equipeList);
	}

	public void setPerfilSelecionado(Perfil perfilSelecionado) {
		this.perfilSelecionado = perfilSelecionado;
	}

	public Perfil getPerfilSelecionado() {
		return perfilSelecionado;
	}
	
	@Override
	protected IAtendenteService getService() {
		return atendenteService;
	}
	
	public String getFlagAtivo() {
		return flagAtivo;
	}

	public void setFlagAtivo(String flagAtivo) {
		this.flagAtivo = flagAtivo;
		
		if(StringUtils.isBlank(flagAtivo)){
			atendenteFind.setFlagAtivo(null);
		}else{
			atendenteFind.setFlagAtivo(Boolean.valueOf(flagAtivo));
		}
	}

}
