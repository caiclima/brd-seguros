package br.com.callink.cad.backbean;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.pojo.AtendenteStatus;
import br.com.callink.cad.service.IAtendenteStatusService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 * 
 * @author brunomt [brunoam@swb.com.br]
 * 
 */
@ManagedBean
@ViewScoped
public final class AtendenteStatusBB extends CadGenericCrud<AtendenteStatus, IAtendenteStatusService> {
    
	private static final long serialVersionUID = 1L;
	
	private String flagAtivo;
	
	@EJB
	private IAtendenteStatusService atendenteStatusService;
	
    @PostConstruct
    public void init() {
    	novo();
    }

    @Override
    public void novo() {
        try {
            setPojo(new AtendenteStatus());
            setPojos(getService().findAll());
            getPojo().setFlagAtivo(Boolean.TRUE);
            
            
        } catch (ServiceException ex) {
        	logger.error(ex);
            error(ex);
        }
    }
    
    @Override
    public String salvar() {
    	if (getPojo().getIdStatusToolbar() == 0) {
    		getPojo().setIdStatusToolbar(null);
    	}
        String ret = super.salvar();
        if (getPojo().getPK() != null) {
            novo();
            try {
				setPojos(getService().findByExample(getPojo(), "AtendenteStatus.NOME_STATUS"));
			} catch (ServiceException e) {
				logger.error(e);
				error(e);
			}
        }
        return ret;
    }
    
    public void inativar(AtendenteStatus atendenteStatus) {
        try {
            getService().inativar(atendenteStatus);
            setPojos(getService().findByExample(getPojo(), "AtendenteStatus.NOME_STATUS"));
        } catch (ValidationException e) {
			error(e.getMessage());
		}catch (ServiceException ex) {
			logger.error(ex);
            error(ex);
        }
    }
    
    public void pesquisar() {
    	try {
			setPojos(getService().findByExample(getPojo(), "AtendenteStatus.NOME_STATUS"));
		} catch (ServiceException e) {
			logger.error(e);
			error(e);
		}
    }
    
    public void alteraValorPojo(AtendenteStatus atendenteStatus) {
        setPojo(atendenteStatus);
    }
    
    @Override
	protected IAtendenteStatusService getService() {
		return atendenteStatusService;
	}
    
    
    public String getFlagAtivo() {
		return flagAtivo;
	}

	public void setFlagAtivo(String flagAtivo) {
		this.flagAtivo = flagAtivo;
		
		if(StringUtils.isBlank(flagAtivo)){
			getPojo().setFlagAtivo(null);
		}else{
			getPojo().setFlagAtivo(Boolean.valueOf(flagAtivo));
		}
	}
    
}