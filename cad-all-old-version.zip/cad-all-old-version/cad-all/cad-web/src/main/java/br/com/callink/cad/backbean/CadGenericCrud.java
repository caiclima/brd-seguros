/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.backbean;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.ejb.EJB;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.servlet.ServletContext;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.richfaces.event.FileUploadEvent;
import org.richfaces.model.UploadedFile;

import br.com.callink.cad.pojo.Anexo;
import br.com.callink.cad.pojo.GrupoAnexo;
import br.com.callink.cad.pojo.ParametroGBO;
import br.com.callink.cad.pojo.Util.ReflectionUtils;
import br.com.callink.cad.pojo.entity.IEntity;
import br.com.callink.cad.service.IAnexoService;
import br.com.callink.cad.service.IGenericGboService;
import br.com.callink.cad.service.IParametroGBOService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.util.BundleHelper;
import br.com.callink.cad.util.Constantes;
import br.com.callink.cad.util.PropertieUtils;
import br.com.callink.sso.authlib.ws.session.WsSsoSession;
import br.com.callink.sso.authlib.ws.web.webobject.WSUserInfo;

/**
 *
 * @author Ednaldo Caic [ednaldo@swb.com.br]
 */
@SuppressWarnings("rawtypes")
public abstract class CadGenericCrud<T extends IEntity<Integer>, SERVICE extends IGenericGboService> extends GenericCrud {

    private static final long serialVersionUID = 1L;
    private List<T> pojos;
    private ParametroGBO diretorio;
    private GrupoAnexo grupoAnexo;
    private boolean mostraPanelAnexo;
    private String urlDownload;
    private T pojo;

    public abstract void novo();

    protected abstract SERVICE getService();
    
    public T getPojo(){
    	return pojo;
    }

    public void setPojo(T pojo){
    	this.pojo = pojo;
    }
    
    @EJB
    private IParametroGBOService parametroGboService;
    
    @EJB
    private IAnexoService anexoService;
    
    
    public CadGenericCrud() {
        HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        setUrlDownload(request.getContextPath() + "/downloadAnexo");

        setGrupoAnexo(new GrupoAnexo());
        getGrupoAnexo().setAnexoList(new ArrayList<Anexo>());
    }

    protected void error(Exception exception, boolean splitMensage) {
        if (splitMensage) {
            String mensagens = exception.getCause() != null ? exception.getCause().getMessage() : exception.getMessage();
            String[] spplit = mensagens.split(";");
            for (String msgm : spplit) {
                super.error(msgm);
            }
        } else {
            super.error(exception);
        }
    }

    protected void setErrorMessage(String message) {
        setResponseObj(new Object[2]);
        getResponseObj()[0] = Boolean.FALSE;
        getResponseObj()[1] = message;
        error(getResponseObj()[1].toString());
    }

    protected Boolean checkIsEmptyAndSetErrorMessage(String string,
            String message) {

        if (string == null || string.isEmpty()) {
            setErrorMessage(message);
            return Boolean.TRUE;
        } else {
            return Boolean.FALSE;
        }
    }

    protected Boolean checkIsEmptyAndSetErrorMessage(Enum enum1, String message) {

        if (enum1 == null) {
            setErrorMessage(message);
            return Boolean.TRUE;
        } else {
            return Boolean.FALSE;
        }
    }

    protected Boolean checkIsEmptyAndSetErrorMessage(IEntity<?> entity,
            String message) {

        if (entity == null || entity.getPK() == null) {
            setErrorMessage(message);
            return Boolean.TRUE;
        } else {
            return Boolean.FALSE;
        }
    }

    protected int getNewTempId() {
        return (int) (Math.random() * -10000);
    }

    @SuppressWarnings("unchecked")
	protected void resetTempId(List<IEntity<?>> list) {
        if (list != null && !list.isEmpty()) {

            for (IEntity pojoLocal : list) {

                if (pojoLocal.getPK() == null) {
                    pojoLocal.setPK(getNewTempId());
                }
            }
        }
    }

    @SuppressWarnings("unchecked")
	protected void clearTempId(List<IEntity<?>> list) {
        if (list != null && !list.isEmpty()) {

            for (IEntity pojoLocal : list) {

                if (pojoLocal.getPK() != null && ((Integer) pojoLocal.getPK()) < 0) {
                    pojoLocal.setPK(null);
                }
            }
        }
    }

    protected void resetTempId(List list, String propertyIdName) {

        if (list != null && !list.isEmpty()) {

            for (Object pojoLocal : list) {

                try {
                    Field field = ReflectionUtils.getField(pojoLocal, propertyIdName);
                    ReflectionUtils.setValue(pojoLocal, field, getNewTempId());
                } catch (Exception ex) {
                    error(ex);
                }
            }
        }
    }

    protected void clearTempId(List list, String propertyIdName) {

        if (list != null && !list.isEmpty()) {

            for (Object object : list) {

                try {
                    Field field = ReflectionUtils.getField(object,
                            propertyIdName);
                    Object value = ReflectionUtils.getValue(object, field);
                    if (value != null && ((Integer) value) < 0) {
                        ReflectionUtils.setValue(object, field, null);
                    }
                } catch (Exception ex) {
                    error(ex);
                }
            }
        }
    }

    @SuppressWarnings("unchecked")
	public String salvar() {
        try {
            getService().saveOrUpdate(getPojo());
            novo();
            info(BundleHelper.getMessage("MSG_Save_Success", "bundleGbo"));
            filtrar();
        }catch (ValidationException ex) {
        	error(ex.getMessage());
        } catch (ServiceException ex) {
        	logger.error("Erro ao salvar objeto", ex);
        	error(ex.getMessage());
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    public String excluir() {
        try {
            getService().delete(getPojo());
            novo();
            info(BundleHelper.getMessage("MSG_Delete_Success", "bundleGbo"));
        }catch (ValidationException ex) {
        	error(ex.getMessage());
        }catch (ServiceException ex) {
        	logger.error("Erro ao salvar objeto", ex);
            error(ex.getMessage());
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    public String excluir(T pojo) {
        try {
            getService().delete(pojo);
            if (getPojos() != null) {
                getPojos().remove(pojo);
            }
            novo();
            info(BundleHelper.getMessage("MSG_Delete_Success", "bundleGbo"));
        }catch (ValidationException ex) {
        	error(ex.getMessage());
        }catch (ServiceException ex) {
        	logger.error("Erro ao salvar objeto", ex);
            error(ex.getMessage());
        }
        return null;
    }

    public void editar(T pojo) {
        setPojo(pojo);
    }

	@SuppressWarnings("unchecked")
	public String filtrar() {
        try {
            setPojos(getService().findByExample(getPojo()));
            if (getPojos() == null || getPojos().isEmpty()) {
                info(BundleHelper.getMessage("MSG_Not_Search", "bundleGbo"));
            }
        } catch (ServiceException ex) {
            logger.error(ex);
            info(BundleHelper.getMessage("MSG_Not_Search", "bundleGbo"));
        }
        return null;
    }
    
    protected ServletContext getServletContext() {
        return (ServletContext) getExternalContext().getContext();
    }

    protected HttpServletResponse getResponse() {
        return (HttpServletResponse) getExternalContext().getResponse();
    }

    protected HttpServletRequest getRequest() {
        return (HttpServletRequest) getExternalContext().getRequest();
    }

    // Metodos para download de arquivos
    protected void forceDownload(StringBuffer buffer, String fileName)
            throws IOException {
        forceDownload(buffer.toString().getBytes(), fileName);
    }

    protected void forceDownload(byte[] bs, String fileName) throws IOException {
        write(new ByteArrayInputStream(bs), fileName);
    }

    protected void forceDownload(File file) throws IOException {
        write(new FileInputStream(file), file.getName());
    }

    private void write(InputStream inputStream, String fileName) {
        HttpServletResponse response = getResponse();
        response.setContentType("application/force-download");
        response.addHeader("Content-Disposition", "attachment; filename=\""
                + fileName + "\"");

        try {

            BufferedInputStream in = new BufferedInputStream(inputStream);
            ServletOutputStream out = response.getOutputStream();

            int i = in.read();
            do {
                out.write(i);
                i = in.read();
            } while (i != -1);

            in.close();
            out.close();
        } catch (IOException e) {
            error(e);
        }
    }

    // Metodos para acesso às informações do usuário logado
    protected WsSsoSession getWsSsoSession() {
        return (WsSsoSession) getExternalContext().getSessionMap().get(
                "ssoSession");
    }

    protected WSUserInfo getUserInfo() {
        WsSsoSession wsSsoSession = getWsSsoSession();
        if(wsSsoSession !=null){
        	return wsSsoSession.getUserInfo();
        }
        
        return null;
    }

    public String getLoginUsuario() {
    	  WsSsoSession wsSsoSession = getWsSsoSession();
          if(wsSsoSession !=null && wsSsoSession.getUserInfo() != null){
          	return wsSsoSession.getUserInfo().getUserLogin();
          }
          
          return null;
    }

    public String getNomeUsuario() {
    	WsSsoSession wsSsoSession = getWsSsoSession();
        if(wsSsoSession !=null){
        	return wsSsoSession.getUserInfo().getUserName();
        }
        
        return null;
    }

    public void removeAnexo(Anexo anexo) {
        if (getGrupoAnexo() != null && getGrupoAnexo().getAnexoList() != null) {
            
        	for (Iterator<Anexo> iterator = getGrupoAnexo().getAnexoList().iterator(); iterator.hasNext();) {
    			if (iterator.next().getNomeReal().equals(anexo.getNomeReal())) {
    				iterator.remove();
    			}
    		}
        }
    }

    public void limpaAnexos() {
        setGrupoAnexo(new GrupoAnexo());
        getGrupoAnexo().setAnexoList(new ArrayList<Anexo>());
        setMostraPanelAnexo(Boolean.FALSE);
    }

    public void removeTodosAnexo() {
        setGrupoAnexo(new GrupoAnexo());
        getGrupoAnexo().setAnexoList(new ArrayList<Anexo>());
    }

    public void adicionaAnexo(FileUploadEvent event) throws Exception {

        UploadedFile item = event.getUploadedFile();

        if (diretorio == null || StringUtils.isBlank(diretorio.getValor())) {

            String chaveDiretorio = PropertieUtils.getPropertieByArquivoAndChave(
                    Constantes.CAMINHO_ARQUIVO_PROPERTIES_CONFIGURACAO_TELA,
                    Constantes.NOME_ARQUIVO_PROPERTIE,
                    Constantes.CHAVE_DIRETORIO_ANEXO);
            if (StringUtils.isBlank(chaveDiretorio)) {
                throw new ServiceException(
                        "Diret\u00F3rio para salvar anexo n\u00E3o est\u00E1 cadastrado.");
            }

            diretorio = parametroGboService.findByParam(chaveDiretorio);
        }

        Anexo anexo = new Anexo();
        anexo.setNomeReal(item.getName());
        anexo.setDados(item.getData());
        anexo.setTamanho(item.getData().length);
        anexo.setDiretorio(diretorio.getValor());

        if (item.getName().contains("\\")) {
            int posicao = item.getName().lastIndexOf("\\") + 1;
            anexo.setNomeReal(item.getName().substring(posicao, item.getName().length()));
        }

        if (grupoAnexo == null) {
            grupoAnexo = new GrupoAnexo();
            grupoAnexo.setAnexoList(new ArrayList<Anexo>());
        }

        if(grupoAnexo.getAnexoList() == null){
        	grupoAnexo.setAnexoList(new ArrayList<Anexo>());
        }
        
        grupoAnexo.getAnexoList().add(anexo);
    }

    public void mostraPanelAnexo() {
        setMostraPanelAnexo(Boolean.TRUE);
    }

    public void buscaAnexos(Integer idGrupoAnexo) {
        try {
            Anexo anexo = new Anexo();
            anexo.setGrupoAnexo(new GrupoAnexo(idGrupoAnexo));
            getGrupoAnexo().setAnexoList(anexoService.findByExample(anexo));

            if (!getGrupoAnexo().getAnexoList().isEmpty()) {
                HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();

                // COLOCA O OBJETO DO RELATORIO NA SESSAO
                if (request.getSession(false) != null) {
                    request.getSession().setAttribute("arquivo",
                            getGrupoAnexo().getAnexoList());
                } else {
                    error("Sess\u00E3o expirada!");
                }
            }
        } catch (ServiceException e) {
            error("Erro ao buscar anexos.");
        }
    }

    public String baixarAnexo(Anexo anexo) {
        return "/downloadAnexo";
    }

    public final ParametroGBO getDiretorio() {
        return diretorio;
    }

    public final void setDiretorio(ParametroGBO diretorio) {
        this.diretorio = diretorio;
    }

    public final GrupoAnexo getGrupoAnexo() {
        return grupoAnexo;
    }

    public final void setGrupoAnexo(GrupoAnexo grupoAnexo) {
        this.grupoAnexo = grupoAnexo;
    }

    public final boolean isMostraPanelAnexo() {
        return mostraPanelAnexo;
    }

    public final void setMostraPanelAnexo(boolean mostraPanelAnexo) {
        this.mostraPanelAnexo = mostraPanelAnexo;
    }

    public final String getUrlDownload() {
        return urlDownload;
    }

    public final void setUrlDownload(String urlDownload) {
        this.urlDownload = urlDownload;
    }

	public List<T> getPojos() {
		return pojos;
	}

	public void setPojos(List<T> pojos) {
		this.pojos = pojos;
	}
	
	public List<SelectItem> getSelectSimNao(){
		
		List<SelectItem> selects = new ArrayList<SelectItem>();
		selects.add(new SelectItem(null, ""));
		selects.add(new SelectItem("false", "Não"));
		selects.add(new SelectItem("true", "Sim"));
		return selects;
	}
	
	/**
	 * Sobrescrever para validar extensao e tamanho
	 * @param anexo
	 * @throws Exception
	 */
	protected void validaAnexo(Anexo anexo) throws Exception {

	}
	
}
