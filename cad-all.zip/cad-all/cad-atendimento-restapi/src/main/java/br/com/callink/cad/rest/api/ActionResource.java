package br.com.callink.cad.rest.api;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import javax.annotation.security.DenyAll;
import javax.annotation.security.RolesAllowed;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.dto.ResultTO;
import br.com.callink.cad.engine.command.executor.IExecutorCommandService;
import br.com.callink.cad.enun.CamposRegraEditCasoEnum;
import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.pojo.Agendamento;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.Causa;
import br.com.callink.cad.pojo.Email;
import br.com.callink.cad.pojo.Evento;
import br.com.callink.cad.pojo.EventoLigacao;
import br.com.callink.cad.pojo.GrupoEmail;
import br.com.callink.cad.pojo.OutraArea;
import br.com.callink.cad.pojo.Status;
import br.com.callink.cad.pojo.Telefone;
import br.com.callink.cad.pojo.TemplateArquivo;
import br.com.callink.cad.pojo.TipoCaso;
import br.com.callink.cad.pojo.Usuario;
import br.com.callink.cad.repository.to.CampoDinamicoTO;
import br.com.callink.cad.repository.to.CreateNewChildCaseTO;
import br.com.callink.cad.repository.to.UpdatePhoneClientTO;
import br.com.callink.cad.rest.api.inject.InjectEJB;
import br.com.callink.cad.rest.api.multipart.FormDataMultiPartUtils;
import br.com.callink.cad.service.IAcaoService;
import br.com.callink.cad.service.ICasoService;
import br.com.callink.cad.service.IEventoService;
import br.com.callink.cad.service.IGrupoEmailService;
import br.com.callink.cad.service.ITipoCasoService;
import br.com.callink.cad.service.IUploadFileService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.service.utils.ServiceResponse;
import br.com.callink.cad.util.CollectionUtils;

import com.sun.jersey.multipart.FormDataBodyPart;
import com.sun.jersey.multipart.FormDataMultiPart;
import com.sun.jersey.multipart.FormDataParam;

/**
 * 
 * @author swb_halan
 * 
 */
@Path("/action")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@DenyAll
public class ActionResource extends GenericResource {
	
	@InjectEJB(ejbName = "ExecutorCommandService")
	private IExecutorCommandService executor;

	@InjectEJB(ejbName = "EventoService")
	private IEventoService eventoService;

	@InjectEJB(ejbName = "TipoCasoService")
	private ITipoCasoService tipoCasoService;
	
	@InjectEJB(ejbName = "CasoService")
	private ICasoService casoService;

	@InjectEJB(ejbName = "GrupoEmailService")
	private IGrupoEmailService grupoEmailService;

	@InjectEJB(ejbName = "UploadFileService")
	private IUploadFileService uploadFileService;
	
	@InjectEJB(ejbName = "AcaoService")
	private IAcaoService acaoService;
	
	@Context
	private HttpServletRequest rawRequest;
	

	private HttpServletRequest getRawRequest() {
		return this.rawRequest;
	}
	
	@Path("/noteActionCases/{idAcao}")
	@POST
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	@Produces(MediaType.TEXT_PLAIN)
	@RolesAllowed({ "EXECUTAR_ACAO_CASO" })
	public Response noteActionCases(FormDataMultiPart multiPart, @FormDataParam("idCaso") Integer idCaso, @FormDataParam("idUsuario") Integer idUsuario,
			@FormDataParam("idAcao") Integer idAcao, @FormDataParam("observacao") String observacao, @FormDataParam("dataAgendamento") Long timedataAgendamento)
			throws Exception {

		final Caso caso = new Caso(idCaso);
		final Usuario usuario = new Usuario(idUsuario);
		final Acao acao = new Acao(idAcao);
		
		final Map<String, Object> mapParametros = new HashMap<String, Object>();

		if (StringUtils.isBlank(observacao)) {
			fail("Campo Observa\u00E7\u00E3o \u00E9 obrigat\u00F3rio.", "MSG_observation_required");
		}
		if (timedataAgendamento != null && timedataAgendamento < executor.getDataBanco().getTime()) {
			fail("Data do agendamento deve ser maior do que a data Atual.", "MSG_schedule_date_before_current_date");
		}
		if (caso != null && caso.getIdCaso() == null) {
			fail("Caso não pode ser nulo.", "MSG_case_null");
		}
		if (acao != null && acao.getIdAcao() == null) {
			fail("Ação não pode ser nula.", "MSG_action_null");
		}
		if (usuario != null && usuario.getIdUsuario() == null) {
			fail("Usuario não pode ser nulo.", "MSG_user_null");
		}
		
		verifyRequestUser(getRawRequest(),idUsuario);

		Set<FormDataMultiPartUtils.File> files = FormDataMultiPartUtils.getFiles(multiPart);

		if (!CollectionUtils.isEmpty(files)) {
			List<Properties> propFiles = new ArrayList<Properties>();
			for (FormDataMultiPartUtils.File file : files) {
				final byte[] buffer = readBytes(file.getIn());
				final String fileName = file.getName();
				uploadFileService.validateNotAllowedFile(fileName, buffer.length);

				Properties prop = new Properties();
				prop.put(fileName, buffer);
				propFiles.add(prop);
			}
			mapParametros.put(IExecutorCommandService.PARAM_FILES, propFiles);
		}

		if (timedataAgendamento != null) {
			Agendamento agendamento = new Agendamento();
			agendamento.setDataAgendamento(new Date(timedataAgendamento));
			agendamento.setDescricao(observacao);

			mapParametros.put(IExecutorCommandService.PARAM_AGENDAMENTO, agendamento);
		}

		mapParametros.put(IExecutorCommandService.PARAM_ACAO, acao);
		mapParametros.put(IExecutorCommandService.PARAM_USUARIO, usuario);
		mapParametros.put(IExecutorCommandService.PARAM_CASO, caso);
		mapParametros.put(IExecutorCommandService.PARAM_OBSERVACAO, observacao);

		executor.execute(mapParametros);

		return Response.ok("{}").build();
	}

	@Path("/finishCases")
	@POST
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	@Produces(MediaType.TEXT_PLAIN)
	@RolesAllowed({ "EXECUTAR_ACAO_CASO" })
	public Response finishCases(FormDataMultiPart multiPart, @FormDataParam("idCaso") Integer idCaso, @FormDataParam("idStatus") Integer idStatus,
			@FormDataParam("idUsuario") Integer idUsuario, @FormDataParam("idAcao") Integer idAcao, @FormDataParam("observacao") String observacao,
			@FormDataParam("idCausa") Integer idCausa) throws Exception {

		Caso caso = new Caso(idCaso);
		caso.setStatus(new Status(idStatus));
		Causa causa = new Causa(idCausa);
		Acao acao = new Acao(idAcao);
		Usuario usuario = new Usuario(idUsuario);
		
		if (StringUtils.isBlank(observacao)) {
			fail("Campo Observa\u00E7\u00E3o \u00E9 obrigat\u00F3rio.", "MSG_observation_required");
		}
		if (caso != null && caso.getIdCaso() == null) {
			fail("Caso não pode ser nulo.", "MSG_case_null");
		}
		if (causa != null && causa.getIdCausa() == null) {
			fail("Causa não pode ser nula.", "MSG_cause_null");
		}
		if (acao != null && acao.getIdAcao() == null) {
			fail("Ação não pode ser nula.", "MSG_action_null");
		}
		if (usuario != null && usuario.getIdUsuario() == null) {
			fail("Usuario não pode ser nulo.", "MSG_user_null");
		}
		
		verifyRequestUser(getRawRequest(),idUsuario);
		
		Map<String, Object> mapParametros = new HashMap<String, Object>();

		Set<FormDataMultiPartUtils.File> files = FormDataMultiPartUtils.getFiles(multiPart);

		if (!CollectionUtils.isEmpty(files)) {
			List<Properties> propFiles = new ArrayList<Properties>();
			for (FormDataMultiPartUtils.File file : files) {
				final byte[] buffer = readBytes(file.getIn());
				final String fileName = file.getName();
				uploadFileService.validateNotAllowedFile(fileName, buffer.length);

				Properties prop = new Properties();
				prop.put(fileName, buffer);
				propFiles.add(prop);
			}
			mapParametros.put(IExecutorCommandService.PARAM_FILES, propFiles);
		}

		mapParametros.put(IExecutorCommandService.PARAM_ACAO, acao);
		mapParametros.put(IExecutorCommandService.PARAM_CASO, caso);
		mapParametros.put(IExecutorCommandService.PARAM_CAUSA, causa);
		mapParametros.put(IExecutorCommandService.PARAM_USUARIO, usuario);
		mapParametros.put(IExecutorCommandService.PARAM_OBSERVACAO, observacao);

		executor.execute(mapParametros);

		return Response.ok("{}").build();
	}

	@Path("/pendingAnotherArea/{idAcao}")
	@POST
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	@Produces(MediaType.TEXT_PLAIN)
	@RolesAllowed({ "EXECUTAR_ACAO_CASO" })
	public Response pendingAnotherArea(FormDataMultiPart multiPart, @FormDataParam("idCaso") Integer idCaso, @FormDataParam("idOutraArea") Integer idOutraArea,
			@FormDataParam("idUsuario") Integer idUsuario, @FormDataParam("idAcao") Integer idAcao, @FormDataParam("observacao") String observacao,
			@FormDataParam("dataAgendamento") Long timedataAgendamento) throws Exception {

		Acao acao = new Acao(idAcao);
		Usuario usuario = new Usuario(idUsuario);
		Caso caso = new Caso(idCaso);
		OutraArea outraArea = new OutraArea(idOutraArea);
		
		Map<String, Object> mapParametros = new HashMap<String, Object>();

		if (StringUtils.isBlank(observacao)) {
			fail("Campo Observa\u00E7\u00E3o \u00E9 obrigat\u00F3rio.", "MSG_observation_required");
		}
		if (timedataAgendamento != null && timedataAgendamento < executor.getDataBanco().getTime()) {
			fail("Data do agendamento deve ser maior do que a data atual.", "MSG_schedule_date_before_current_date");
		}
		if (acao != null && acao.getIdAcao() == null) {
			fail("A\u00E7\u00E3o n\u00E3o pode ser nula.", "MSG_action_null");
		}
		if (caso != null && caso.getIdCaso() == null) {
			fail("Caso n\u00E3o pode ser nulo.", "MSG_case_null");
		}
		if (outraArea != null && outraArea.getIdOutraArea() == null) {
			fail("Outra area n\u00E3o pode ser nula.", "MSG_other_area_null");
		}
		if (usuario != null && usuario.getIdUsuario() == null) {
			fail("Usuario n\u00E3o pode ser nulo.", "MSG_user_null");
		}
		
		verifyRequestUser(getRawRequest(),idUsuario);

		Set<FormDataMultiPartUtils.File> files = FormDataMultiPartUtils.getFiles(multiPart);

		if (!CollectionUtils.isEmpty(files)) {
			List<Properties> propFiles = new ArrayList<Properties>();
			for (FormDataMultiPartUtils.File file : files) {
				final byte[] buffer = readBytes(file.getIn());
				final String fileName = file.getName();
				uploadFileService.validateNotAllowedFile(fileName, buffer.length);

				Properties prop = new Properties();
				prop.put(fileName, buffer);
				propFiles.add(prop);
			}
			mapParametros.put(IExecutorCommandService.PARAM_FILES, propFiles);
		}

		Agendamento agendamento = new Agendamento();
		if (timedataAgendamento != null) {
			agendamento.setDataAgendamento(new Date(timedataAgendamento));
			agendamento.setDescricao(observacao);

			mapParametros.put(IExecutorCommandService.PARAM_AGENDAMENTO, agendamento);
		}

		mapParametros.put(IExecutorCommandService.PARAM_ACAO, acao);
		mapParametros.put(IExecutorCommandService.PARAM_USUARIO, usuario);
		mapParametros.put(IExecutorCommandService.PARAM_CASO, caso);
		mapParametros.put(IExecutorCommandService.PARAM_OBSERVACAO, observacao);
		mapParametros.put(IExecutorCommandService.PARAM_OUTRA_AREA, outraArea);

		executor.execute(mapParametros);
		
		return Response.ok("{}").build();
	}

	@Path("/categorizecase/{idAcao}")
	@POST
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	@Produces(MediaType.TEXT_PLAIN)
	@RolesAllowed({ "EXECUTAR_ACAO_CASO" })
	public Response categorizeCase(FormDataMultiPart multiPart, @FormDataParam("idCaso") Integer idCaso, @FormDataParam("idEvento") Integer idEvento,
			@FormDataParam("idUsuario") Integer idUsuario, @FormDataParam("idAcao") Integer idAcao, @FormDataParam("observacao") String observacao,
			@FormDataParam("idTipoCaso") Integer idTipoCaso, @FormDataParam("loginSupervisor") String loginSupervisor,
			@FormDataParam("senhaSupervisor") String senhaSupervisor) throws Exception {

		Acao acao = new Acao(idAcao);
		Usuario usuario = new Usuario(idUsuario);
		Caso caso = new Caso(idCaso);
		Evento evento = new Evento(idEvento);
		TipoCaso tipoCaso = new TipoCaso(idTipoCaso);
		
		Map<String, Object> mapParametros = new HashMap<String, Object>();

		if (StringUtils.isBlank(observacao)) {
			fail("Campo Observa\u00E7\u00E3o \u00E9 obrigat\u00F3rio.", "MSG_observation_required");
		}
		if (acao != null && acao.getIdAcao() == null) {
			fail("A\u00E7\u00E3o n\u00E3o pode ser nula.", "MSG_action_null");
		}
		if (caso != null && caso.getIdCaso() == null) {
			fail("Caso n\u00E3o pode ser nulo.", "MSG_case_null");
		}
		if (usuario != null && usuario.getIdUsuario() == null) {
			fail("Usuario n\u00E3o pode ser nulo.", "MSG_user_null");
		}
		if (evento != null && evento.getIdEvento() == null) {
			fail("Evento n\u00E3o pode ser nulo.", "MSG_event_null");
		}
		if (tipoCaso != null && tipoCaso.getIdTipoCaso() == null) {
			fail("Tipo caso n\u00E3o pode ser nulo.", "MSG_case_type_null");
		}
		
		verifyRequestUser(getRawRequest(),idUsuario);

		Set<FormDataMultiPartUtils.File> files = FormDataMultiPartUtils.getFiles(multiPart);

		if (!CollectionUtils.isEmpty(files)) {
			List<Properties> propFiles = new ArrayList<Properties>();
			for (FormDataMultiPartUtils.File file : files) {
				final byte[] buffer = readBytes(file.getIn());
				final String fileName = file.getName();
				uploadFileService.validateNotAllowedFile(fileName, buffer.length);

				Properties prop = new Properties();
				prop.put(fileName, buffer);
				propFiles.add(prop);
			}
			mapParametros.put(IExecutorCommandService.PARAM_FILES, propFiles);
		}

		mapParametros.put(IExecutorCommandService.PARAM_ACAO, acao);
		mapParametros.put(IExecutorCommandService.PARAM_USUARIO, usuario);
		mapParametros.put(IExecutorCommandService.PARAM_CASO, caso);
		mapParametros.put(IExecutorCommandService.PARAM_OBSERVACAO, observacao);
		mapParametros.put(IExecutorCommandService.PARAM_EVENTO, evento);
		mapParametros.put(IExecutorCommandService.PARAM_TIPO_CASO, tipoCaso);
		mapParametros.put(IExecutorCommandService.PARAM_LOGIN_SUPERVISOR, loginSupervisor);
		mapParametros.put(IExecutorCommandService.PARAM_SENHA_SUPERIVSOR, senhaSupervisor);

		executor.execute(mapParametros);
		
		return Response.ok("{}").build();
	}

	@SuppressWarnings("unchecked")
	@Path("/updatePhoneClient/{idAcao}")
	@PUT
	@RolesAllowed({ "EXECUTAR_ACAO_CASO" })
	public Response updatePhoneClient(UpdatePhoneClientTO updatePhoneClientTO) throws Exception {

		String observacao = updatePhoneClientTO.getObservacao();
		Acao acao = new Acao(updatePhoneClientTO.getIdAcao());
		Usuario usuario = new Usuario(updatePhoneClientTO.getIdUsuario());
		Caso caso = new Caso(updatePhoneClientTO.getIdCaso());

		Map<String, Object> mapParametros = new HashMap<String, Object>();

		if (StringUtils.isBlank(observacao)) {
			fail("Campo Observa\u00E7\u00E3o \u00E9 obrigat\u00F3rio.", "MSG_observation_required");
		}
		if (acao != null && acao.getIdAcao() == null) {
			fail("A\u00E7\u00E3o n\u00E3o pode ser nula.", "MSG_action_null");
		}
		if (caso != null && caso.getIdCaso() == null) {
			fail("Caso n\u00E3o pode ser nulo.", "MSG_case_null");
		}
		if (usuario != null && usuario.getIdUsuario() == null) {
			fail("Usuario n\u00E3o pode ser nulo.", "MSG_user_null");
		}
		if (updatePhoneClientTO.getListTelefone() == null || updatePhoneClientTO.getListTelefone().isEmpty()) {
			fail("Telefones n\u00E3o pode ser nulo.", "MSG_phones_null");
		}
		
		verifyRequestUser(getRawRequest(),usuario.getIdUsuario());
		
		final ResultTO<Boolean> bol = (ResultTO<Boolean>) casoService.exigeSenhaDeSupervisorParaAtualizarTelefones(caso.getIdCaso()).getData();
		if (bol.getValor()) {
			casoService.validaDadosSupervisor(updatePhoneClientTO.getLoginSupervisor(), updatePhoneClientTO.getSenhaSupervisor());
		}

		mapParametros.put(IExecutorCommandService.PARAM_ACAO, acao);
		mapParametros.put(IExecutorCommandService.PARAM_USUARIO, usuario);
		mapParametros.put(IExecutorCommandService.PARAM_CASO, caso);
		mapParametros.put(IExecutorCommandService.PARAM_OBSERVACAO, observacao);
		mapParametros.put(IExecutorCommandService.PARAM_TELEFONES, updatePhoneClientTO.getListTelefone());

		executor.execute(mapParametros);
		return Response.ok("{}").build();
	}

	@Path("/createnewchildcase/{idAcao}")
	@PUT
	@RolesAllowed({ "EXECUTAR_ACAO_CASO" })
	public Response createNewChildCase(CreateNewChildCaseTO createNewChildCaseTO) throws Exception {

		Acao acao = new Acao(createNewChildCaseTO.getIdAcao());
		Usuario usuario = new Usuario(createNewChildCaseTO.getIdUsuario());
		Caso caso = new Caso(createNewChildCaseTO.getIdCaso());
		String observacao = createNewChildCaseTO.getObservacao();

		Map<String, Object> mapParametros = new HashMap<String, Object>();

		if (StringUtils.isBlank(observacao)) {
			fail("Campo Observa\u00E7\u00E3o \u00E9 obrigat\u00F3rio.", "MSG_observation_required");
		}
		if (acao != null && acao.getIdAcao() == null) {
			fail("A\u00E7\u00E3o n\u00E3o pode ser nula.", "MSG_action_null");
		}
		if (caso != null && caso.getIdCaso() == null) {
			fail("Caso n\u00E3o pode ser nulo.", "MSG_case_null");
		}
		if (usuario != null && usuario.getIdUsuario() == null) {
			fail("Usuario n\u00E3o pode ser nulo.", "MSG_user_null");
		}
		verifyRequestUser(getRawRequest(),usuario.getIdUsuario());
		mapParametros.put(IExecutorCommandService.PARAM_ACAO, acao);
		mapParametros.put(IExecutorCommandService.PARAM_USUARIO, usuario);
		mapParametros.put(IExecutorCommandService.PARAM_CASO, caso);
		mapParametros.put(IExecutorCommandService.PARAM_OBSERVACAO, observacao);

		executor.execute(mapParametros);
		return Response.ok("{}").build();
	}

	@Path("/sendemail")
	@POST
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	@Produces(MediaType.TEXT_PLAIN)
	@RolesAllowed({ "EXECUTAR_ACAO_CASO" })
	public Response sendEmail(
			FormDataMultiPart multiPart, 
			@FormDataParam("destinatario") String destinatario,
			@FormDataParam("destinatarioParaExibicao") String destinatarioParaExibicao, 
			@FormDataParam("conteudo") String conteudo,
			@FormDataParam("assunto") String assunto,
			@FormDataParam("idAcao") Integer idAcao, 
			@FormDataParam("idUsuario") Integer idUsuario, 
			@FormDataParam("idCaso") Integer idCaso,
			@FormDataParam("listIdGroupEmailTO") List<FormDataBodyPart> bparts, 
			@FormDataParam("destinatarioCopia") String destinatarioCopia,
			@FormDataParam("caixaEmail") String caixaEmail)	throws Exception {

		if (idUsuario == null) {
			fail("Obrigatorio informar o id do usuário", "MSG_user_id_required");
		}

		if (idCaso == null) {
			fail("Obrigatorio informar o id do caso", "MSG_case_id_required");
		}

		if (idAcao == null) {
			fail("Obrigatorio informar o id da ação", "MSG_action_id_required");
		}

		if (StringUtils.isBlank(conteudo)) {
			fail("O conteudo do email deve ser preenchido.", "MSG_email_content_required");
		}
		
		if (destinatarioCopia != null && !destinatarioCopia.isEmpty() && destinatarioCopia.length() > 4000) {
			fail("Campo de destinat\u00e1rios em c\u00d3pia excedeu tamanho m\u00e1ximo.", "MSG_cc_destination_exceeds_max_size");
		}
		
		verifyRequestUser(getRawRequest(),idUsuario);

		Map<String, Object> mapParametros = new HashMap<String, Object>();
		Acao acao = new Acao(idAcao);
		Usuario user = new Usuario(idUsuario);
		Caso caso = new Caso(idCaso);

		Email email = mountParameter(multiPart, destinatario, destinatarioParaExibicao, conteudo, assunto, bparts, destinatarioCopia, mapParametros);

		mapParametros.put(IExecutorCommandService.PARAM_ACAO, acao);
		mapParametros.put(IExecutorCommandService.PARAM_USUARIO, user);
		mapParametros.put(IExecutorCommandService.PARAM_CASO, caso);
		mapParametros.put(IExecutorCommandService.PARAM_EMAIL, email);
		mapParametros.put(IExecutorCommandService.PARAM_CAIXA_EMAIL, caixaEmail);

		executor.execute(mapParametros);
		return Response.ok("{}").build();
	}

	private Email mountParameter(FormDataMultiPart multiPart, String destinatario, String destinatarioParaExibicao, String conteudo, String assunto, List<FormDataBodyPart> bparts, String destinatarioCopia, Map<String, Object> mapParametros) throws Exception, ServiceException, IOException, ValidationException {
		List<Integer> listIdsGrupoEmails = new ArrayList<Integer>();
		if (!CollectionUtils.isEmpty(bparts)) {
			for (FormDataBodyPart bpart : bparts) {
				if (!StringUtils.isEmpty(bpart.getValue())) {
					listIdsGrupoEmails.add((Integer) unmarshall(bpart.getValue().replaceAll("[^0-9]*", ""),Integer.class));
				}
			}
		}
		
		if (CollectionUtils.isEmpty(listIdsGrupoEmails) && StringUtils.isBlank(destinatario)) {
			fail("Nenhum destinatário foi selecionado.", "MSG_no_destination_informed");
		}
		
		List<GrupoEmail> listGrupoEmails = null;
		if (!CollectionUtils.isEmpty(listIdsGrupoEmails)) {
			listGrupoEmails = grupoEmailService.findGrupoEmailListId(listIdsGrupoEmails);
		}

		Email email = new Email();
		email.setListaDestinatarios(listGrupoEmails);
		email.setDestinatarioParaExibicao(destinatarioParaExibicao);
		email.setConteudo(conteudo);
		email.setAssunto(assunto);

		// Verifica se foi incluido algum destinatario manualmente
		if (destinatario != null && !destinatario.isEmpty()) {
			email.setDestinatario(destinatario);
		}
		// Verifica se foi incluido algum destinatario de copia manualmente
		if (destinatarioCopia != null && !destinatarioCopia.isEmpty()) {
			email.setDestinatarioCopia(destinatarioCopia);
		}

		Set<FormDataMultiPartUtils.File> files = FormDataMultiPartUtils.getFiles(multiPart);

		if (!CollectionUtils.isEmpty(files)) {
			List<Properties> propFiles = new ArrayList<Properties>();
			for (FormDataMultiPartUtils.File file : files) {
				final byte[] buffer = readBytes(file.getIn());
				final String fileName = file.getName();
				uploadFileService.validateNotAllowedFile(fileName, buffer.length);

				Properties prop = new Properties();
				prop.put(fileName, buffer);
				propFiles.add(prop);
			}
			mapParametros.put(IExecutorCommandService.PARAM_FILES, propFiles);
		}
		return email;
	}
	
	@Path("/template/sendemail")
	@POST
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	@Produces(MediaType.TEXT_PLAIN)
	@RolesAllowed({ "EXECUTAR_ACAO_CASO" })
	public Response sendEmailTemplate(FormDataMultiPart multiPart, @FormDataParam("destinatario") String destinatario,
			@FormDataParam("destinatarioParaExibicao") String destinatarioParaExibicao, @FormDataParam("conteudo") String conteudo,@FormDataParam("assunto") String assunto,
			@FormDataParam("idAcao") Integer idAcao, @FormDataParam("idUsuario") Integer idUsuario, @FormDataParam("idCaso") Integer idCaso,
			@FormDataParam("listIdGroupEmailTO") List<FormDataBodyPart> bparts, @FormDataParam("destinatarioCopia") String destinatarioCopia,
			@FormDataParam("caixaEmail") String caixaEmail,@FormDataParam("idTemplateArquivo") Integer idTemplateArquivo)
					throws Exception {

		if (idUsuario == null) {
			fail("Obrigatorio informar o id do usuário", "MSG_user_id_required");
		}

		if (idCaso == null) {
			fail("Obrigatorio informar o id do caso", "MSG_case_id_required");
		}

		if (idAcao == null) {
			fail("Obrigatorio informar o id da ação", "MSG_action_id_required");
		}
		if (idTemplateArquivo == null) {
			fail("Obrigatorio informar o id do TemplateArquivo", "MSG_email_template_required");
		}

		if (StringUtils.isBlank(conteudo)) {
			fail("O conteudo do email deve ser preenchido.", "MSG_email_content_required");
		}
		
		if (destinatarioCopia != null && !destinatarioCopia.isEmpty() && destinatarioCopia.length() > 4000) {
			fail("Campo de destinat\u00e1rios em c\u00d3pia excedeu tamanho m\u00e1ximo.", "MSG_cc_destination_exceeds_max_size");
		}
		
		verifyRequestUser(getRawRequest(),idUsuario);

		Map<String, Object> mapParametros = new HashMap<String, Object>();
		Acao acao = new Acao(idAcao);
		Usuario user = new Usuario(idUsuario);
		Caso caso = new Caso(idCaso);
		TemplateArquivo template = new TemplateArquivo(idTemplateArquivo);

		Email email = mountParameter(multiPart, destinatario, destinatarioParaExibicao, conteudo, assunto, bparts, destinatarioCopia, mapParametros);

		mapParametros.put(IExecutorCommandService.PARAM_ACAO, acao);
		mapParametros.put(IExecutorCommandService.PARAM_USUARIO, user);
		mapParametros.put(IExecutorCommandService.PARAM_CASO, caso);
		mapParametros.put(IExecutorCommandService.PARAM_EMAIL, email);
		mapParametros.put(IExecutorCommandService.PARAM_CAIXA_EMAIL, caixaEmail);
		mapParametros.put(IExecutorCommandService.PARAM_TEMPLATE_ARQUIVO, template);

		executor.execute(mapParametros);
		return Response.ok("{}").build();
	}

	@Path("/categorizephonecall/{idAcao}")
	@POST
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	@Produces(MediaType.TEXT_PLAIN)
	public Response categorizePhoneCall(FormDataMultiPart multiPart, @FormDataParam("observacao") String observacao,
			@FormDataParam("idTelefone") Integer idTelefone, @FormDataParam("idEventoLigacao") Integer idEventoLigacao,
			@FormDataParam("idAcao") Integer idAcao, @FormDataParam("idUsuario") Integer idUsuario, @FormDataParam("idCaso") Integer idCaso) throws Exception {
		
		Acao acao = new Acao(idAcao);
		Usuario usuario = new Usuario(idUsuario);
		Caso caso = new Caso(idCaso);
		EventoLigacao evento = new EventoLigacao(idEventoLigacao);
		Telefone telefone = new Telefone(idTelefone);

		Map<String, Object> mapParametros = new HashMap<String, Object>();
		
		if (StringUtils.isBlank(observacao)) {
			fail("Campo Observa\u00E7\u00E3o \u00E9 obrigat\u00F3rio.", "MSG_observation_required");
		}
		if (acao != null && acao.getIdAcao() == null) {
			fail("A\u00E7\u00E3o n\u00E3o pode ser nula.", "MSG_action_null");
		}
		if (caso != null && caso.getIdCaso() == null) {
			fail("Caso n\u00E3o pode ser nulo.", "MSG_case_null");
		}
		if (usuario != null && usuario.getIdUsuario() == null) {
			fail("Usuario n\u00E3o pode ser nulo.", "MSG_user_null");
		}
		if (evento != null && evento.getIdEventoLigacao() == null) {
			fail("Evento n\u00E3o pode ser nulo.", "MSG_event_null");
		}
		if (telefone != null && telefone.getIdTelefone() == null) {
			fail("Telefone n\u00E3o pode ser nulo.", "MSG_phone_null");
		}
		verifyRequestUser(getRawRequest(),idUsuario);
		Set<FormDataMultiPartUtils.File> files = FormDataMultiPartUtils.getFiles(multiPart);

		if (!CollectionUtils.isEmpty(files)) {
			List<Properties> propFiles = new ArrayList<Properties>();
			for (FormDataMultiPartUtils.File file : files) {
				final byte[] buffer = readBytes(file.getIn());
				final String fileName = file.getName();
				uploadFileService.validateNotAllowedFile(fileName, buffer.length);

				Properties prop = new Properties();
				prop.put(fileName, buffer);
				propFiles.add(prop);
			}
			mapParametros.put(IExecutorCommandService.PARAM_FILES, propFiles);
		}

		mapParametros.put(IExecutorCommandService.PARAM_ACAO, acao);
		mapParametros.put(IExecutorCommandService.PARAM_USUARIO, usuario);
		mapParametros.put(IExecutorCommandService.PARAM_CASO, caso);
		mapParametros.put(IExecutorCommandService.PARAM_OBSERVACAO, observacao);
		mapParametros.put(IExecutorCommandService.PARAM_EVENTO, evento);
		mapParametros.put(IExecutorCommandService.PARAM_TELEFONE, telefone);

		executor.execute(mapParametros);
		return Response.ok("{}").build();
	}

	@Path("/case/edit/{idAcao}")
	@POST
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	@Produces(MediaType.TEXT_PLAIN)
	@RolesAllowed({ "EXECUTAR_ACAO_CASO" })
	public Response updateCaso(FormDataMultiPart multiPart, @FormDataParam("idCaso") Integer idCaso, @FormDataParam("idUsuario") Integer idUsuario,
			@FormDataParam("idAcao") Integer idAcao, @FormDataParam("observacao") String observacao, @FormDataParam("listaCamposDinamicos") List<FormDataBodyPart> bparts) throws Exception {
		final Caso caso = new Caso(idCaso);
		final Usuario usuario = new Usuario(idUsuario);
		final Acao acao = new Acao(idAcao);
		
		List<CampoDinamicoTO> campos = new ArrayList<CampoDinamicoTO>();
		if (!CollectionUtils.isEmpty(bparts)) {
			for (FormDataBodyPart bpart : bparts) {
				if (!StringUtils.isEmpty(bpart.getValue())) {
					campos.add((CampoDinamicoTO) unmarshall(bpart.getValue(), CampoDinamicoTO.class));
				}
			}
		}

		Map<String, Object> mapParametros = new HashMap<String, Object>();

		if (acao != null && acao.getIdAcao() == null) {
			fail("A\u00E7\u00E3o n\u00E3o pode ser nula.", "MSG_action_null");
		}
		if (caso != null && caso.getIdCaso() == null) {
			fail("Caso n\u00E3o pode ser nulo.", "MSG_case_null");
		}
		if (usuario != null && usuario.getIdUsuario() == null) {
			fail("Usuario n\u00E3o pode ser nulo.", "MSG_user_null");
		}
		if (StringUtils.isBlank(observacao)) {
			fail("Observacao n\u00E3o pode ser nulo.", "MSG_observation_null");
		}
		
		verifyRequestUser(getRawRequest(),usuario.getIdUsuario());
		if (CollectionUtils.hasValue(campos)) {
			mapParametros.put(IExecutorCommandService.PARAM_CAMPOS_LAYOUT_EDIT, campos);

			for (CampoDinamicoTO campo : campos) {
				if(StringUtils.isNotEmpty(campo.getValor())){
					campo.setValor(campo.getValor().trim());
				}
				if (CamposRegraEditCasoEnum.DATA_AGENDAMENTO.name().equals(campo.getTipoCampo())
						&& br.com.callink.cad.util.StringUtils.isNotEmpty(campo.getValor())) {
					Date data = new Date();
					data.setTime(Long.valueOf(campo.getValor()));
					
					Agendamento agendamento = new Agendamento();
					agendamento.setDataAgendamento(data);
					agendamento.setDescricao(observacao);
					mapParametros.put(IExecutorCommandService.PARAM_AGENDAMENTO, agendamento);
				}
			}
		}
		
		Set<FormDataMultiPartUtils.File> files = FormDataMultiPartUtils.getFiles(multiPart);

		if (!CollectionUtils.isEmpty(files)) {
			List<Properties> propFiles = new ArrayList<Properties>();
			for (FormDataMultiPartUtils.File file : files) {
				final byte[] buffer = readBytes(file.getIn());
				final String fileName = file.getName();
				uploadFileService.validateNotAllowedFile(fileName, buffer.length);

				Properties prop = new Properties();
				prop.put(fileName, buffer);
				propFiles.add(prop);
			}
			mapParametros.put(IExecutorCommandService.PARAM_FILES, propFiles);
		}
		
		mapParametros.put(IExecutorCommandService.PARAM_OBSERVACAO, observacao);
		mapParametros.put(IExecutorCommandService.PARAM_ACAO, acao);
		mapParametros.put(IExecutorCommandService.PARAM_USUARIO, usuario);
		mapParametros.put(IExecutorCommandService.PARAM_CASO, caso);

		executor.execute(mapParametros);
		return Response.ok("{}").build();
	}

	@Path("/allowsAttachment/{idAcao}")
	@GET
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	public ResultTO<Boolean> allowsAttachment(@PathParam(value = "idAcao") Integer idAcao) throws Exception {
		if (idAcao == null) {
			fail("Obrigatorio informar o id da acao", "MSG_action_id_required");
		}
		ServiceResponse serviceResponse = acaoService.findActionAllowsAttachment(idAcao);
		return new ResultTO<Boolean>((Boolean) serviceResponse.getData());
	}
	
	
	@Path("/{idAcao}")
	@GET
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	public Acao loadAcao(@PathParam(value = "idAcao") Integer idAcao) throws Exception {
		if (idAcao == null) {
			fail("Obrigatorio informar o id da acao", "MSG_action_id_required");
		}	
		Acao acao =  acaoService.findByPk(new Acao(idAcao));
		acao.setUsuarioAlteracao(null);
		acao.setUsuarioCriacao(null);
		acao.setLayoutEditCaso(null);
		acao.setOperacao(null);
		return  acao ;
	}
	
}
