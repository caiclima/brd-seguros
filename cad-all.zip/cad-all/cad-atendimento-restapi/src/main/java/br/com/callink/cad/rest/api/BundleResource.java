package br.com.callink.cad.rest.api;

import java.util.List;

import javax.annotation.security.DenyAll;
import javax.annotation.security.RolesAllowed;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import br.com.callink.cad.dto.BundleTO;
import br.com.callink.cad.dto.UsuarioLogadoDTO;
import br.com.callink.cad.rest.api.inject.InjectEJB;
import br.com.callink.cad.service.IParametroOperacaoBaselineService;
import br.com.callink.cad.service.utils.ServiceResponse;

/**
 * Classe de labels do bundle
 *
 * @author William D. Silva
 * 
 */
@Path("/baseline/resources")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@DenyAll
public class BundleResource extends GenericResource {

	@InjectEJB(ejbName = "ParametroOperacaoBaselineService")
	private IParametroOperacaoBaselineService parametroService;

	@Context
	private HttpServletRequest rawRequest;

	private HttpServletRequest getRawRequest() {
		return this.rawRequest;
	}

	@SuppressWarnings("unchecked")
	@Path("/{idUsuario}")
	@GET
	@RolesAllowed({ "BUSCAR_RECURSOS_BASELINE" })
	public List<BundleTO> getUserByOperation(@PathParam(value = "idUsuario") Integer idUsuario) throws Exception {

		verifyRequestUser(getRawRequest(), idUsuario);
		UsuarioLogadoDTO user = getLoggedUser(getRawRequest());
		ServiceResponse out = parametroService.getLabelCampos(user != null ? user.getIdUsuario() : null, idUsuario);

		return (List<BundleTO>) out.getData();
	}

}
