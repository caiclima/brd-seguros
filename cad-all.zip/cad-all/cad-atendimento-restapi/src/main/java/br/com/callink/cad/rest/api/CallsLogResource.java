package br.com.callink.cad.rest.api;

import java.util.List;

import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import br.com.callink.cad.dto.UsuarioLogadoDTO;
import br.com.callink.cad.repository.to.HistoricoLigacaoTO;
import br.com.callink.cad.service.ILogLigacoesService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.rest.api.inject.InjectEJB;
import br.com.callink.cad.rest.api.GenericResource;

/**
 * 
 * @author swb_halan
 * 
 */
@Path("/callslog")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@PermitAll
public class CallsLogResource extends GenericResource {

	@InjectEJB(ejbName = "LogLigacoesService")
	private ILogLigacoesService logLigacoesService;

	@Context
	private HttpServletRequest rawRequest;

	private HttpServletRequest getRawRequest() {
		return this.rawRequest;
	}

	//VALIDADO
	@Path("/cases/{id}/{lastId}/{maxResults}")
	@GET
	@RolesAllowed({ "BUSCAR_LOG_LIGACOES" })
	@SuppressWarnings("unchecked")
	public List<HistoricoLigacaoTO> getLogCases(@PathParam(value = "id") Integer id,
			@PathParam(value = "lastId") Integer ultimoId, @PathParam(value = "maxResults") Integer maxResults)
			throws ServiceException, ValidationException {
		if (id == null) {
			fail("id do caso nao pode ser nulo!", "MSG_case_id_required");
		}
		
		UsuarioLogadoDTO user = getLoggedUser(getRawRequest());
		
		return (List<HistoricoLigacaoTO>) logLigacoesService.buscaHistoricoLigacoesCaso(id, ultimoId, maxResults,user != null ? user.getIdUsuario() : null).getData();
	}

}
