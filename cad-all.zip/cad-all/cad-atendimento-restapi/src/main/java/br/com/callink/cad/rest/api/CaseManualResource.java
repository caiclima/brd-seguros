package br.com.callink.cad.rest.api;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import javax.annotation.security.PermitAll;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import br.com.callink.cad.dto.CasoManual;
import br.com.callink.cad.repository.to.CampoDinamicoTO;
import br.com.callink.cad.repository.to.LayoutCasoManualTO;
import br.com.callink.cad.rest.api.inject.InjectEJB;
import br.com.callink.cad.rest.api.multipart.FormDataMultiPartUtils;
import br.com.callink.cad.service.IAuthorizationService;
import br.com.callink.cad.service.ICamposCasoManualService;
import br.com.callink.cad.service.ICasoService;
import br.com.callink.cad.service.ILayoutCasoManualService;
import br.com.callink.cad.service.IUploadFileService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.util.CollectionUtils;
import br.com.callink.cad.util.StringUtils;

import com.sun.jersey.multipart.FormDataBodyPart;
import com.sun.jersey.multipart.FormDataMultiPart;
import com.sun.jersey.multipart.FormDataParam;

/**
 * 
 * @author miller
 * 
 */
@Path("/casemanual")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@PermitAll
public class CaseManualResource extends GenericResource implements ICaseManualResource {

	@InjectEJB(ejbName = "CamposCasoManualService")
	private ICamposCasoManualService camposCasoManualService;

	@InjectEJB(ejbName = "LayoutCasoManualService")
	private ILayoutCasoManualService layoutCasoManualService;

	@InjectEJB(ejbName = "CasoService")
	private ICasoService casoService;

	@InjectEJB(ejbName = "UploadFileService")
	private IUploadFileService uploadFileService;
	
	@InjectEJB(ejbName = "AuthorizationService")
	private IAuthorizationService authorizationService;
	
	@Context
	private HttpServletRequest rawRequest;

	private HttpServletRequest getRawRequest() {
		return this.rawRequest;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<CampoDinamicoTO> findFieldsCase(Integer idOperacao, Integer idTipoCaso) throws ServiceException {
		return (List<CampoDinamicoTO>) camposCasoManualService.findCamposDinamicosByLayout(idOperacao, idTipoCaso).getData();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<LayoutCasoManualTO> findLayoutPreview(Integer idUsuario) throws Exception {
		validaPausaUsuario(idUsuario);
		return (List<LayoutCasoManualTO>) layoutCasoManualService.buscaLayoutsDisponíveisParaAcessoRapido(idUsuario).getData();
	}

	@Override
	public CasoManual createMetaData(Integer idOperacao, Integer idTipoCaso, Integer idUsuario) throws Exception {
		validaPausaUsuario(idUsuario);
		
		CasoManual casoManual = (CasoManual) casoService.createMetadaDataCasoManual(idOperacao, idTipoCaso, idUsuario).getData();
		casoManual.setPossuiPrivilegioAnexo(hasAttachmentPrivilege(getRawRequest(), ATTACHMENT_PRIVILEGE_MANUAL_CASE));
		
		return casoManual;
	}
	
	@Override
	public CasoManual createMetaDataByLayout(Integer idLayout, Integer idUsuario) throws Exception {
		validaPausaUsuario(idUsuario);
		
		CasoManual casoManual = (CasoManual) casoService.createMetadaDataCasoManualById(idLayout, idUsuario).getData();
		casoManual.setPossuiPrivilegioAnexo(hasAttachmentPrivilege(getRawRequest(), ATTACHMENT_PRIVILEGE_MANUAL_CASE));
		
		return casoManual;
	}

	@Override
	public Object createCase(FormDataMultiPart multiPart, @FormDataParam("idOperacao") Integer idOperacao, @FormDataParam("idTipoCaso") Integer idTipoCaso, @FormDataParam("idUsuario") Integer idUsuario, @FormDataParam("idCasoExterno") String idCasoExterno, @FormDataParam("idCanal") Integer idCanal, @FormDataParam("idEvento") Integer idEvento,
			@FormDataParam("camposDinamicos") List<FormDataBodyPart> camposDinamicos, @FormDataParam("observacao") String observacao, @FormDataParam("dataAbertura") Long dataAbertura,@FormDataParam("idCasoPai") String idCasoPai) throws ServiceException {

		try {
			CasoManual caso = new CasoManual();
			List<Properties> propFiles = new ArrayList<Properties>();

			caso.setIdOperacao(idOperacao);
			caso.setIdTipoCaso(idTipoCaso);
			caso.setIdUsuario(idUsuario);
			caso.setIdCasoExterno(idCasoExterno);
			caso.setIdCanal(idCanal);
			caso.setIdEvento(idEvento);
			caso.setObservacao(observacao);
			caso.setIdExternoCasoPai(idCasoPai);
			if (dataAbertura != null) {
				caso.setDataAbertura(new Date(dataAbertura));
			}

			List<CampoDinamicoTO> campos = new ArrayList<CampoDinamicoTO>();
			if (!CollectionUtils.isEmpty(camposDinamicos)) {

				for (FormDataBodyPart item : camposDinamicos) {
					CampoDinamicoTO to = (CampoDinamicoTO) unmarshall(item.getValue(), CampoDinamicoTO.class);
					if(StringUtils.isNotEmpty(to.getValor())){
						to.setValor(to.getValor().trim());
					}
					campos.add(to);
				}
			}

			Set<FormDataMultiPartUtils.File> files = FormDataMultiPartUtils.getFiles(multiPart);

			if (!CollectionUtils.isEmpty(files)) {

				for (FormDataMultiPartUtils.File file : files) {
					final byte[] buffer = readBytes(file.getIn());
					final String fileName = file.getName();
					uploadFileService.validateNotAllowedFile(fileName, buffer.length);
					Properties prop = new Properties();
					prop.put(fileName, buffer);
					propFiles.add(prop);
				}
			}
			
			caso.setCamposDinamicos(campos);

			validaPausaUsuario(caso.getIdUsuario());
			return marshall(casoService.criaCasoManual(caso, propFiles).getData(), CasoManual.class);
			
		} catch (Exception e) {
			throw new ServiceException(e);
		}
	}
	
}
