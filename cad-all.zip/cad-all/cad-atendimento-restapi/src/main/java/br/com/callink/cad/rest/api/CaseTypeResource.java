package br.com.callink.cad.rest.api;

import java.util.List;
import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import br.com.callink.cad.repository.to.TipoCasoTO;
import br.com.callink.cad.rest.api.inject.InjectEJB;
import br.com.callink.cad.service.ITipoCasoService;

@Path("/casetype")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@PermitAll
public class CaseTypeResource extends GenericResource {

	@InjectEJB(ejbName = "TipoCasoService")
	private ITipoCasoService tipoCasoService;

	//VERIFIED
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	@GET
	@Path("/case/{idCaso}")
	public List<TipoCasoTO> findPossibleTypesByCase(@PathParam(value = "idCaso") Integer idCaso) throws Exception {
		return tipoCasoService.buscaPossiveisTiposPorCaso(idCaso);
	}
	
	//VERIFIED
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	@GET
	@Path("/operation/{idOperation}")
	public List<TipoCasoTO> findPossibleTypesByOperation(@PathParam(value = "idOperation") Integer idOperation) throws Exception {
		return tipoCasoService.buscaPossiveisTiposParaCasoManualPorOperacao(idOperation);
	}
}
