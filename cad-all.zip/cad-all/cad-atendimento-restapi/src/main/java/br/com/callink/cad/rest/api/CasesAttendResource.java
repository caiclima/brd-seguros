package br.com.callink.cad.rest.api;

import java.util.List;

import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import br.com.callink.cad.repository.to.CasoDetalhadoTO;
import br.com.callink.cad.rest.api.inject.InjectEJB;
import br.com.callink.cad.service.ICasoService;
import br.com.callink.cad.service.utils.ServiceResponse;

/**
 * 
 * @author swb_halan
 * 
 */
@Path("/casesAttend")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@PermitAll
public class CasesAttendResource extends GenericResource {

	@InjectEJB(ejbName = "CasoService")
	private ICasoService casoService;

	//VERIFIED
	@Path("/clientgroupedcases/{idCase}")
	@GET
	@RolesAllowed({ "CASO_ATENDIMENTO" })
	@SuppressWarnings("unchecked")
	public List<CasoDetalhadoTO> getClientGroupedCases(@PathParam(value = "idCase") Integer idCase) throws Exception {
		if (idCase == null) {
			fail("Obrigatorio informar o id do caso", "MSG_case_id_required");
		}

		ServiceResponse serviceResponse = casoService.buscarCasosAgrupadosPorClientes(idCase);
		return (List<CasoDetalhadoTO>) serviceResponse.getData();
	}

	//VERIFIED
	@Path("/countClientGroupedCases/{idCase}")
	@GET
	@RolesAllowed({ "CASO_ATENDIMENTO" })
	public Integer getCountClientGroupedCases(@PathParam(value = "idCase") Integer idCase) throws Exception {
		if (idCase == null) {
			fail("Obrigatorio informar o id do caso", "MSG_case_id_required");
		}

		ServiceResponse serviceResponse = casoService.contarCasosAgrupadosPorClientes(idCase);
		return (Integer) serviceResponse.getData();
	}

}
