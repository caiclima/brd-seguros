package br.com.callink.cad.rest.api;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import javax.annotation.security.DenyAll;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.dto.ResultTO;
import br.com.callink.cad.dto.UsuarioLogadoDTO;
import br.com.callink.cad.engine.command.executor.IExecutorCommandService;
import br.com.callink.cad.pojo.Anexo;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.Causa;
import br.com.callink.cad.pojo.ConfiguracaoCaixaEmail;
import br.com.callink.cad.pojo.Email;
import br.com.callink.cad.pojo.EmailModelo;
import br.com.callink.cad.pojo.GrupoAnexo;
import br.com.callink.cad.pojo.GrupoEmail;
import br.com.callink.cad.pojo.ObservacaoModelo;
import br.com.callink.cad.pojo.Usuario;
import br.com.callink.cad.repository.to.AcaoTipoAcaoCasoTO;
import br.com.callink.cad.repository.to.CasoAbertoAtendenteTO;
import br.com.callink.cad.repository.to.CasoDetalhadoTO;
import br.com.callink.cad.repository.to.ConteudoApoioTO;
import br.com.callink.cad.repository.to.DadosClassificaCasoTO;
import br.com.callink.cad.repository.to.DelegaCasoTO;
import br.com.callink.cad.repository.to.EmailTO;
import br.com.callink.cad.repository.to.GrupoEmailTO;
import br.com.callink.cad.repository.to.TelefoneTO;
import br.com.callink.cad.rest.api.inject.InjectEJB;
import br.com.callink.cad.rest.api.multipart.FormDataMultiPartUtils;
import br.com.callink.cad.service.ICampoDinamicoService;
import br.com.callink.cad.service.ICasoService;
import br.com.callink.cad.service.IConfiguracaoCaixaEmailService;
import br.com.callink.cad.service.IConteudoApoioService;
import br.com.callink.cad.service.IEmailModeloService;
import br.com.callink.cad.service.IEmailService;
import br.com.callink.cad.service.IGrupoEmailService;
import br.com.callink.cad.service.ILogService;
import br.com.callink.cad.service.IObservacaoModeloService;
import br.com.callink.cad.service.IOperacaoService;
import br.com.callink.cad.service.ITelefoneService;
import br.com.callink.cad.service.IUploadFileService;
import br.com.callink.cad.service.IUsuarioService;
import br.com.callink.cad.service.command.ICommand;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.service.utils.ServiceResponse;
import br.com.callink.cad.util.CollectionUtils;

import com.sun.jersey.multipart.FormDataBodyPart;
import com.sun.jersey.multipart.FormDataMultiPart;

/**
 * 
 */
@Path("/cases")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@DenyAll
public class CasesResource extends GenericResource implements ICasesResource {

	@InjectEJB(ejbName = "CasoService")
	private ICasoService casoService;

	@InjectEJB(ejbName = "LogService")
	private ILogService logService;

	@InjectEJB(ejbName = "CampoDinamicoService")
	private ICampoDinamicoService camposDinamicoService;

	@InjectEJB(ejbName = "GrupoEmailService")
	private IGrupoEmailService grupoEmailService;

	@InjectEJB(ejbName = "EmailService")
	private IEmailService emailService;

	@InjectEJB(ejbName = "ConteudoApoioService")
	private IConteudoApoioService conteudoApoioService;

	@InjectEJB(ejbName = "TelefoneService")
	private ITelefoneService telefoneService;

	@InjectEJB(ejbName = "UploadFileService")
	private IUploadFileService uploadFileService;

	@InjectEJB(ejbName = "UsuarioService")
	private IUsuarioService usuarioService;

	@InjectEJB(ejbName = "EnviaEmailCasoCommand")
	private ICommand command;

	@InjectEJB(ejbName = "ConfiguracaoCaixaEmailService")
	private IConfiguracaoCaixaEmailService configuracaoCaixaEmailService;

	@InjectEJB(ejbName = "OperacaoService")
	private IOperacaoService operacaoService;

	@InjectEJB(ejbName = "EmailModeloService")
	private IEmailModeloService emailModeloService;
	
	@InjectEJB(ejbName = "ObservacaoModeloService")
	private IObservacaoModeloService observacaoModeloService;

	@Context
	private HttpServletRequest rawRequest;

	private HttpServletRequest getRawRequest() {
		return this.rawRequest;
	}

	public Response ligarTel(TelefoneTO tel) throws Exception {
		if (tel.getIdCaso() == null) {
			fail("Nenhum caso foi informado!", "MSG_no_case_informed");
		}

		if (tel.getTelefoneCliente() == null) {
			fail("Nenhum telefone foi informado!", "MSG_no_phone_informed");
		}

		if (tel.getLoginUsuario() == null) {
			fail("Nenhum login usuario!", "MSG_no_user_login");
		}

		Usuario usuario = usuarioService.findByLogin(tel.getLoginUsuario());

		if (usuario != null) {
			verifyRequestUser(getRawRequest(), usuario.getIdUsuario());
		}

		telefoneService.ligarTel(tel);

		return Response.ok("{}").build();
	}

	@SuppressWarnings("unchecked")
	public ResultTO<Long> getCasesCountByUser(Integer id) throws Exception {
		if (id == null) {
			fail("id do usuario nao pode ser nulo!", "MSG_user_id_required");
		}
		verifyRequestUser(getRawRequest(), id);

		return (ResultTO<Long>) casoService.countCasosUsuario(id).getData();
	}

	public CasoAbertoAtendenteTO[] getCasesByUser(Integer id, Integer page, Integer maxresults) throws Exception {
		if (id == null) {
			fail("id do usuario nao pode ser nulo!", "MSG_user_id_required");
		}
		verifyRequestUser(getRawRequest(), id);
		return (CasoAbertoAtendenteTO[]) casoService.buscarCasosUsuario(id, page, maxresults).getData();
	}

	public CasoDetalhadoTO getCasesTable(Integer idCases) throws Exception {
		if (idCases == null) {
			fail("Obrigatorio informar o id do caso", "MSG_case_id_required");
		}

		ServiceResponse serviceResponse = casoService.buscaCasosPorIdTabela(idCases);
		return (CasoDetalhadoTO) serviceResponse.getData();
	}

	@SuppressWarnings("unchecked")
	public List<EmailTO> getEmailsOfCases(Integer idCases) throws Exception {
		if (idCases == null) {
			fail("Obrigatório informar o id do caso", "MSG_case_id_required");
		}

		ServiceResponse serviceResponse = logService.findEmailsFromCaso(idCases);
		return (List<EmailTO>) serviceResponse.getData();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<EmailModelo> buscaModelosEmailDisponiveisPorCaso(Integer idCaso) throws Exception {
		if (idCaso == null) {
			fail("Obrigatório informar o id do caso", "MSG_case_id_required");
		}

		ServiceResponse response = emailModeloService.buscaModelosDisponiveisPorCaso(idCaso);
		return (List<EmailModelo>) response.getData();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public Map<String, String> aplicarModeloEmail(Integer idEmailModelo, Integer idCaso) throws Exception {
		if (idCaso == null) {
			fail("Obrigatório informar o id do caso", "MSG_case_id_required");
		}

		final ServiceResponse response = emailModeloService.aplicarModeloEmail(idEmailModelo, idCaso);
		return (Map<String, String>) response.getData();
	}

	public EmailTO getClientGroupedCases(Integer idEmail) throws Exception {
		if (idEmail == null) {
			fail("Obrigatorio informar o id do caso", "MSG_case_id_required");
		}

		ServiceResponse serviceResponse = emailService.findIdEmailTO(idEmail);

		return (EmailTO) serviceResponse.getData();
	}

	@Override
	public EmailTO getDataToResponse(Integer idEmail) throws Exception {
		if (idEmail == null) {
			fail("Obrigatorio informar o id do caso", "MSG_case_id_required");
		}
		ServiceResponse serviceResponse = emailService.findDataToResponse(idEmail);

		return (EmailTO) serviceResponse.getData();
	}

	@SuppressWarnings("unchecked")
	public List<AcaoTipoAcaoCasoTO> getCasesActions(Integer id) throws Exception {
		if (id == null) {
			fail("id do caso nao pode ser nulo!", "MSG_case_id_required");
		}
		UsuarioLogadoDTO user = getLoggedUser(getRawRequest());
		ServiceResponse serviceResponse = casoService.buscaAcaoTipoAcaoCasoUser(id, user != null ? user.getIdUsuario() : null);
		return (List<AcaoTipoAcaoCasoTO>) serviceResponse.getData();
	}

	public CasoDetalhadoTO userRequestCase(Usuario usuario) throws Exception {
		if (usuario == null || usuario.getIdUsuario() == null) {
			fail("Obrigatorio informar o id do usu\u00E1rio", "MSG_user_id_required");
		}
		if (usuario != null) {
			verifyRequestUser(getRawRequest(), usuario.getIdUsuario());
		}

		validaPausaUsuario(usuario.getIdUsuario());

		ServiceResponse serviceResponse = casoService.solicitaCasoUsuarioAtendimento(usuario);
		CasoDetalhadoTO casoTO = (CasoDetalhadoTO) serviceResponse.getData();
		
		casoTO.setPossuiPrivilegioAnexoAcoes(hasAttachmentPrivilege(getRawRequest(), ATTACHMENT_PRIVILEGE_ACTIONS));
		casoTO.setPossuiPrivilegioAnexoEmail(hasAttachmentPrivilege(getRawRequest(), ATTACHMENT_PRIVILEGE_EMAIL));
		casoTO.setPossuiPrivilegioReplyAnexoEmail(hasAttachmentPrivilege(getRawRequest(), ATTACHMENT_PRIVILEGE_EMAIL_REPLY));
		casoTO.setPossuiPrivilegioReplyEmail(hasAttachmentPrivilege(getRawRequest(), SEND_EMAIL_REPLY));
		casoTO.setPossuiPrivilegioFowardEmail(hasAttachmentPrivilege(getRawRequest(), FOWARD_EMAIL));
		
		return casoTO;
	}

	@SuppressWarnings("unchecked")
	public List<Causa> getCasesCauses(Integer id) throws Exception {
		if (id == null) {
			fail("id do caso nao pode ser nulo!", "MSG_case_id_required");
		}
		UsuarioLogadoDTO user = getLoggedUser(getRawRequest());
		return (List<Causa>) casoService.buscaCausasCaso(id, user != null ? user.getIdUsuario() : null).getData();
	}

	public CasoDetalhadoTO nextCase(Usuario usuario) throws Exception {
		if (usuario == null || usuario.getIdUsuario() == null) {
			fail("Obrigatorio informar o id do usu\u00E1rio", "MSG_user_id_required");
		}
		if (usuario != null) {
			verifyRequestUser(getRawRequest(), usuario.getIdUsuario());
		}
		validaPausaUsuario(usuario.getIdUsuario());

		ServiceResponse serviceResponse = casoService.solicitaCasoEmAtendimentoUsuarioAtendimento(usuario);
		CasoDetalhadoTO casoTO = (CasoDetalhadoTO) serviceResponse.getData();
		
		casoTO.setPossuiPrivilegioAnexoAcoes(hasAttachmentPrivilege(getRawRequest(), ATTACHMENT_PRIVILEGE_ACTIONS));
		casoTO.setPossuiPrivilegioAnexoEmail(hasAttachmentPrivilege(getRawRequest(), ATTACHMENT_PRIVILEGE_EMAIL));
		casoTO.setPossuiPrivilegioReplyAnexoEmail(hasAttachmentPrivilege(getRawRequest(), ATTACHMENT_PRIVILEGE_EMAIL_REPLY));
		casoTO.setPossuiPrivilegioReplyEmail(hasAttachmentPrivilege(getRawRequest(), SEND_EMAIL_REPLY));
		casoTO.setPossuiPrivilegioFowardEmail(hasAttachmentPrivilege(getRawRequest(), FOWARD_EMAIL));
		
		return casoTO;
	}

	public CasoDetalhadoTO requestCase(CasoDetalhadoTO caso) throws Exception {
		if (caso == null || caso.getIdCaso() == null) {
			fail("Obrigatorio informar o id do caso", "MSG_case_id_required");
		}
		if (caso.getIdUsuario() == null) {
			fail("Obrigatorio informar o id do usu\u00E1rio", "MSG_user_id_required");
		}
		if (caso != null) {
			verifyRequestUser(getRawRequest(), caso.getIdUsuario());
		}
		validaPausaUsuario(caso.getIdUsuario());

		ServiceResponse serviceResponse = casoService.solicitaCasoParaAtendimento(caso);
		CasoDetalhadoTO casoTO = (CasoDetalhadoTO) serviceResponse.getData();
		
		casoTO.setPossuiPrivilegioAnexoAcoes(hasAttachmentPrivilege(getRawRequest(), ATTACHMENT_PRIVILEGE_ACTIONS));
		casoTO.setPossuiPrivilegioAnexoEmail(hasAttachmentPrivilege(getRawRequest(), ATTACHMENT_PRIVILEGE_EMAIL));
		casoTO.setPossuiPrivilegioReplyAnexoEmail(hasAttachmentPrivilege(getRawRequest(), ATTACHMENT_PRIVILEGE_EMAIL_REPLY));
		casoTO.setPossuiPrivilegioReplyEmail(hasAttachmentPrivilege(getRawRequest(), SEND_EMAIL_REPLY));
		casoTO.setPossuiPrivilegioFowardEmail(hasAttachmentPrivilege(getRawRequest(), FOWARD_EMAIL));
		
		return casoTO;
	}

	public DadosClassificaCasoTO dataForClassificationCase(Integer idCaso) throws Exception {
		if (idCaso == null) {
			fail("Obrigatorio informar o id do caso", "MSG_case_id_required");
		}
		UsuarioLogadoDTO user = getLoggedUser(getRawRequest());
		ServiceResponse serviceResponse = casoService.buscaDadosClassificar(idCaso, user != null ? user.getIdUsuario() : null);
		return (DadosClassificaCasoTO) serviceResponse.getData();
	}

	@SuppressWarnings("unchecked")
	public List<GrupoEmailTO> findEmailGroupForOperationCase(Integer idCaso) throws Exception {
		if (idCaso == null) {
			fail("Obrigatorio informar o id do caso", "MSG_case_id_required");
		}
		UsuarioLogadoDTO user = getLoggedUser(getRawRequest());

		ServiceResponse serviceResponse = grupoEmailService.findGrupoEmailForCaso(idCaso, user != null ? user.getIdUsuario() : null);
		return (List<GrupoEmailTO>) serviceResponse.getData();
	}

	public ConteudoApoioTO findContentSupportByCase(Integer idCase) throws Exception {
		if (idCase == null) {
			fail("Obrigatorio informar o id do caso", "MSG_case_id_required");
		}
		ServiceResponse serviceResponse = conteudoApoioService.findConteudoApoioByCaso(idCase);
		return (ConteudoApoioTO) serviceResponse.getData();
	}

	@SuppressWarnings("unchecked")
	public List<TelefoneTO> findPhonesByCase(Integer id) throws ServiceException, ValidationException {
		if (id == null) {
			fail("Obrigatorio informar o id do caso", "MSG_case_id_required");
		}
		UsuarioLogadoDTO user = getLoggedUser(getRawRequest());
		final ServiceResponse response = telefoneService.buscaTelefoneCaso(id, user != null ? user.getIdUsuario() : null);
		return (List<TelefoneTO>) response.getData();
	}

	@SuppressWarnings("unchecked")
	public List<TelefoneTO> findPhonesUncategorized(Integer id) throws ServiceException, ValidationException {
		if (id == null) {
			fail("Obrigatorio informar o id do caso", "MSG_case_id_required");
		}
		UsuarioLogadoDTO user = getLoggedUser(getRawRequest());
		final ServiceResponse response = telefoneService.findTelefonesNaoTabulados(id, user != null ? user.getIdUsuario() : null);
		return (List<TelefoneTO>) response.getData();
	}

	@SuppressWarnings("unchecked")
	@Override
	public ResultTO<Boolean> exigeSenhaDeSupervisorParaAtualizarTelefones(Integer idCaso) throws ValidationException, ServiceException {
		if (idCaso == null) {
			fail("O idCaso deve ser informado!", "MSG_case_id_required");
		}
		final ServiceResponse response = casoService.exigeSenhaDeSupervisorParaAtualizarTelefones(idCaso);
		return (ResultTO<Boolean>) response.getData();
	}

	@SuppressWarnings("unchecked")
	public ResultTO<Boolean> exigeSenhaDeSupervisorParaAssociacao(DelegaCasoTO to) throws Exception {
		if (to == null) {
			fail("Nenhum dado foi enviado!", "MSG_no_data_sent");
		}
		validaPausaUsuario(to.getIdUsuario());
		final ServiceResponse response = casoService.exigeSenhaDeSupervisorParaAssociacao(to);
		return (ResultTO<Boolean>) response.getData();
	}

	public Response associarCasoUsuario(DelegaCasoTO to) throws ServiceException, ValidationException {
		if (to == null) {
			fail("Nenhum dado foi enviado!", "MSG_no_data_sent");
		}

		UsuarioLogadoDTO user = getLoggedUser(getRawRequest());
		casoService.associarCasoUsuario(to, user != null ? user.getIdUsuario() : null);
		return Response.ok("{}").build();
	}

	@Override
	public Response responderEmail(FormDataMultiPart multiPart, Integer idEmailPai, String destinatario, String destinatarioCopia, String destinatarioParaExibicao, String conteudo, String assunto, Integer idUsuario, Integer idCaso, List<FormDataBodyPart> bparts) throws Exception {

		if (idEmailPai == null) {
			fail("Obrigatorio informar o id do email pai", "MSG_father_email_id_required");
		}

		if (idUsuario == null) {
			fail("Obrigatorio informar o id do usuário", "MSG_user_id_required");
		}

		if (idCaso == null) {
			fail("Obrigatorio informar o id do caso", "MSG_case_id_required");
		}

		if (StringUtils.isBlank(conteudo)) {
			fail("O conteudo do email deve ser preenchido.", "MSG_email_content_required");
		}

		if (destinatarioCopia != null && !destinatarioCopia.isEmpty() && destinatarioCopia.length() > 4000) {
			fail("Campo de destinat\u00e1rios em c\u00d3pia excedeu tamanho m\u00e1ximo.", "MSG_cc_destination_exceeds_max_size");
		}

		verifyRequestUser(getRawRequest(), idUsuario);

		List<Integer> listIdsGrupoEmails = new ArrayList<Integer>();
		if (!CollectionUtils.isEmpty(bparts)) {
			for (FormDataBodyPart bpart : bparts) {
				if (!StringUtils.isEmpty(bpart.getValue())) {
					listIdsGrupoEmails.add((Integer) unmarshall(bpart.getValue().replaceAll("[^0-9]*", ""), Integer.class));
				}
			}
		}

		if (CollectionUtils.isEmpty(listIdsGrupoEmails) && StringUtils.isBlank(destinatario)) {
			fail("Nenhum destinatário foi selecionado.", "MSG_no_destination_informed");
		}

		List<GrupoEmail> listGrupoEmails = null;
		if (!CollectionUtils.isEmpty(listIdsGrupoEmails)) {
			listGrupoEmails = grupoEmailService.findGrupoEmailListId(listIdsGrupoEmails);
		}

		Caso caso = new Caso(idCaso);
		caso = casoService.buscaCaso(caso);

		GrupoAnexo grupoAnexo = null;
		Set<FormDataMultiPartUtils.File> files = FormDataMultiPartUtils.getFiles(multiPart);

		if (!CollectionUtils.isEmpty(files)) {
			List<Properties> propFiles = new ArrayList<Properties>();
			for (FormDataMultiPartUtils.File file : files) {
				final byte[] buffer = readBytes(file.getIn());
				final String fileName = file.getName();
				uploadFileService.validateNotAllowedFile(fileName, buffer.length);

				Properties prop = new Properties();
				prop.put(fileName, buffer);
				propFiles.add(prop);
			}
			grupoAnexo = uploadFileService.createGrupoAnexo(propFiles, caso.getOperacao().getIdOperacao());
		}

		Email email = emailService.factoryReplyMail(idEmailPai, listGrupoEmails, destinatario, destinatarioParaExibicao, conteudo, assunto, grupoAnexo, destinatarioCopia);

		Map<String, Object> mapParametros = new HashMap<String, Object>();
		Usuario user = new Usuario(idUsuario);

		mapParametros.put(IExecutorCommandService.PARAM_USUARIO, user);
		mapParametros.put(IExecutorCommandService.PARAM_CASO, caso);
		mapParametros.put(IExecutorCommandService.PARAM_OPERACAO, caso.getOperacao());
		mapParametros.put(IExecutorCommandService.PARAM_EMAIL, email);
		mapParametros.put(ICommand.PARAM_IS_REPLY, Boolean.TRUE);
		
		if (grupoAnexo != null) {
			mapParametros.put(IExecutorCommandService.PARAM_GRUPO_ANEXO, grupoAnexo);
		}

		command.execute(mapParametros);

		return Response.ok("{}").build();
	}

	public CasoDetalhadoTO getCaseRequestUser(Integer idCase, Integer userId) throws Exception {

		UsuarioLogadoDTO user = getLoggedUser(getRawRequest());

		ServiceResponse response = null;

		verifyRequestUser(getRawRequest(), userId);

		if (user != null) {
			response = casoService.getCaso(user.getIdUsuario(), userId, idCase);
		}
		return (CasoDetalhadoTO) response.getData();
	};

	@SuppressWarnings("unchecked")
	@Override
	public List<ConfiguracaoCaixaEmail> getCaixasEmail(Integer idOperacao) throws Exception {
		return (List<ConfiguracaoCaixaEmail>) configuracaoCaixaEmailService.listarCaixasDeEmail(idOperacao).getData();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<CasoDetalhadoTO> getCasesAssociate(Integer idUsuario, Integer idCaso, Integer idOperacao) throws Exception {
		verifyRequestUser(getRawRequest(), idUsuario);

		if (idCaso != null) {
			return (List<CasoDetalhadoTO>) casoService.buscarCasosFilhos(idCaso).getData();
		}

		return null;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ObservacaoModelo> buscaModelosDeObservacaoDisponiveisPorCaso(Integer idCaso) throws Exception {
		if (idCaso == null) {
			fail("Obrigatório informar o id do caso", "MSG_case_id_required");
		}

		ServiceResponse response = observacaoModeloService.buscaModelosDisponiveisPorCaso(idCaso);
		return (List<ObservacaoModelo>) response.getData();
	}

	@Override
	public ResultTO<String> aplicarModeloObservacao(Integer idObservacaoModelo, Integer idCaso) throws Exception {
		if (idCaso == null) {
			fail("Obrigatório informar o id do caso", "MSG_case_id_required");
		}

		final ServiceResponse response = observacaoModeloService.aplicarModeloObservacao(idObservacaoModelo, idCaso);
		final String conteudo = (String) response.getData();
		
		return new ResultTO<String>(conteudo);
	}

	@Override
	public EmailTO getAnexoEmail(Integer idEmail) throws Exception {
		if (idEmail == null) {
			fail("Obrigatorio informar o id do caso", "MSG_case_id_required");
		}
		EmailTO emailTO = (EmailTO) emailService.findIdEmailTO(idEmail).getData();
		return emailTO;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Response fowardEmail(FormDataMultiPart multiPart, Integer idEmailPai, String destinatario, String destinatarioCopia, String destinatarioParaExibicao, String conteudo, String assunto, Integer idUsuario, Integer idCaso, List<FormDataBodyPart> bpartsGrupoEmail, List<FormDataBodyPart> bpartsAnexo) throws Exception {
		if (idEmailPai == null) {
			fail("Obrigatorio informar o id do email pai", "MSG_father_email_id_required");
		}

		if (idUsuario == null) {
			fail("Obrigatorio informar o id do usuário", "MSG_user_id_required");
		}

		if (idCaso == null) {
			fail("Obrigatorio informar o id do caso", "MSG_case_id_required");
		}

		if (StringUtils.isBlank(conteudo)) {
			fail("O conteudo do email deve ser preenchido.", "MSG_email_content_required");
		}

		if (destinatarioCopia != null && !destinatarioCopia.isEmpty() && destinatarioCopia.length() > 4000) {
			fail("Campo de destinat\u00e1rios em c\u00d3pia excedeu tamanho m\u00e1ximo.", "MSG_cc_destination_exceeds_max_size");
		}

		verifyRequestUser(getRawRequest(), idUsuario);

		List<Integer> listIdsGrupoEmails = new ArrayList<Integer>();
		if (!CollectionUtils.isEmpty(bpartsGrupoEmail)) {
			for (FormDataBodyPart bpart : bpartsGrupoEmail) {
				if (!StringUtils.isEmpty(bpart.getValue())) {
					listIdsGrupoEmails.add((Integer) unmarshall(bpart.getValue().replaceAll("[^0-9]*", ""), Integer.class));
				}
			}
		}

		if (CollectionUtils.isEmpty(listIdsGrupoEmails) && StringUtils.isBlank(destinatario)) {
			fail("Nenhum destinatário foi selecionado.", "MSG_no_destination_informed");
		}

		List<GrupoEmail> listGrupoEmails = null;
		if (!CollectionUtils.isEmpty(listIdsGrupoEmails)) {
			listGrupoEmails = grupoEmailService.findGrupoEmailListId(listIdsGrupoEmails);
		}
		
		List<String> listAnexo = new ArrayList<String>();
		if (!CollectionUtils.isEmpty(bpartsAnexo)) {
			for (FormDataBodyPart bpart : bpartsAnexo) {
				if (!StringUtils.isEmpty(bpart.getValue())) {
					listAnexo.add((String) unmarshall(bpart.getValue(), String.class));
				}
			}
		}
		
		Caso caso = new Caso(idCaso);
		caso = casoService.buscaCaso(caso);

		GrupoAnexo grupoAnexo = null;
		Set<FormDataMultiPartUtils.File> files = FormDataMultiPartUtils.getFiles(multiPart);

		if (!CollectionUtils.isEmpty(files)) {
			List<Anexo> anexos = new ArrayList<Anexo>();
			List<Properties> propFiles = new ArrayList<Properties>();
			for (FormDataMultiPartUtils.File file : files) {
				final byte[] buffer = readBytes(file.getIn());
				Anexo anexo = new Anexo();
				final String fileName = file.getName();
				uploadFileService.validateNotAllowedFile(fileName, buffer.length);
				anexo.setNomeReal(file.getName());
				anexo.setDados(buffer);
				anexos.add(anexo);
				Properties prop = new Properties();
				prop.put(fileName, buffer);
				propFiles.add(prop);
				
			}
			List<Properties> propFilesExistente = (List<Properties>) emailService.getAttachmentByEmail(idEmailPai, listAnexo,propFiles,anexos).getData();
			grupoAnexo = uploadFileService.createGrupoAnexo(propFilesExistente, caso.getOperacao().getIdOperacao());
		}else{
			List<Properties> propFilesExistente = (List<Properties>) emailService.getAttachmentByEmail(idEmailPai, listAnexo,null,null).getData();
			grupoAnexo = uploadFileService.createGrupoAnexo(propFilesExistente, caso.getOperacao().getIdOperacao());
		}

		Email email = emailService.factoryReplyMail(idEmailPai, listGrupoEmails, destinatario, destinatarioParaExibicao, conteudo, assunto, grupoAnexo, destinatarioCopia);

		Map<String, Object> mapParametros = new HashMap<String, Object>();
		Usuario user = new Usuario(idUsuario);

		mapParametros.put(IExecutorCommandService.PARAM_USUARIO, user);
		mapParametros.put(IExecutorCommandService.PARAM_CASO, caso);
		mapParametros.put(IExecutorCommandService.PARAM_OPERACAO, caso.getOperacao());
		mapParametros.put(IExecutorCommandService.PARAM_EMAIL, email);
		mapParametros.put(ICommand.PARAM_IS_FOWARD, Boolean.TRUE);
		if (grupoAnexo != null) {
			mapParametros.put(IExecutorCommandService.PARAM_GRUPO_ANEXO, grupoAnexo);
		}

		command.execute(mapParametros);

		return Response.ok("{}").build();
	}
}
