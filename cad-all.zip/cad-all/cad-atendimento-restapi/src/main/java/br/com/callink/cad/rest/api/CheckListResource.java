package br.com.callink.cad.rest.api;

import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import br.com.callink.cad.repository.to.CheckListTO;
import br.com.callink.cad.rest.api.inject.InjectEJB;
import br.com.callink.cad.service.IAssociaChecklistService;
import br.com.callink.cad.service.ICasoService;
import br.com.callink.cad.service.IResultadoChecklistService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.service.utils.ServiceResponse;

/**
 * 
 * @author swb_brunocamargo
 * 
 */
@Path("/checklist")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@PermitAll
public class CheckListResource extends GenericResource {

	@InjectEJB(ejbName = "AssociaChecklistService")
	private IAssociaChecklistService associaChecklistService;

	@InjectEJB(ejbName = "CasoService")
	private ICasoService casoService;

	@InjectEJB(ejbName = "ResultadoChecklistService")
	private IResultadoChecklistService resultadoChecklistService;

	@GET
	@Path("/action/{idAcao}/case/{idCase}/user/{idUser}")
	@RolesAllowed({ "BUSCAR_INFORMACOES_CHECKLIST" })
	public CheckListTO findFieldsCase(@PathParam(value = "idUser") Integer idUser,
			@PathParam(value = "idAcao") Integer idAcao, @PathParam(value = "idCase") Integer idCase)
			throws ServiceException, ValidationException {

		if (idUser == null) {
			fail("Usuário não pode ser nulo.", "MSG_user_null");
		}
		if (idCase == null) {
			fail("Caso não pode ser nulo.", "MSG_case_null");
		}
		if (idAcao == null) {
			fail("Ação não pode ser nula.", "MSG_action_null");
		}

		ServiceResponse serviceResponse = associaChecklistService.findCheckListByAcaoEvento(idUser, idCase, idAcao);
		return (CheckListTO) serviceResponse.getData();
	}

	@PUT
	@Path("/savechecklist")
	@RolesAllowed({ "BUSCAR_INFORMACOES_CHECKLIST" })
	public Response saveCheckList(CheckListTO checkListTO) throws ServiceException, ValidationException {
		resultadoChecklistService.saveRespostaCheckList(checkListTO);
		return Response.ok("{}").build();
	}

}
