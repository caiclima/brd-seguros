package br.com.callink.cad.rest.api;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import javax.annotation.security.DenyAll;
import javax.annotation.security.RolesAllowed;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.google.gson.Gson;

import br.com.callink.cad.pojo.Anexo;
import br.com.callink.cad.rest.api.inject.InjectEJB;
import br.com.callink.cad.service.IAnexoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.util.StringUtils;

@Path("/download")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@DenyAll
public class DownloadResource extends GenericResource {

	@InjectEJB(ejbName = "AnexoService")
	private IAnexoService anexoService;

	@Path("/attachment/{id}")
	@GET
	@Produces(MediaType.APPLICATION_OCTET_STREAM)
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	public Response download(@PathParam(value = "id") Integer attachmentId) throws ServiceException, IOException {
		if (attachmentId == null) {
			fail("O id do anexo NÂO pode ser NuLO!", "MSG_attachment_null");
		}
		
		FileInputStream fileInputStream = null;
		ByteArrayOutputStream stream = null;
		try {
			Anexo attachment = anexoService.findByPk(new Anexo(attachmentId));
			
			String diretorio = attachment.getDiretorio();
			if (! diretorio.substring(diretorio.length()-2).equals("\\")) {
				diretorio = diretorio + "\\";
			}

			File fileToDownload = new File(diretorio + attachment.getNomeFake());
			fileInputStream = new FileInputStream(fileToDownload);
			stream = new ByteArrayOutputStream();
			int i;
			while ((i = fileInputStream.read()) != -1) {
				stream.write(i);
			}
			
			return Response.ok(stream.toByteArray())
					.header("Content-Type", "application/force-download")
					.header("Content-Disposition", "attachment; filename=\"" + br.com.callink.cad.util.StringUtils.removeCaracteresInvalidosParaNomeDeArquivoWindows(attachment.getNomeReal()) + "\"")
					.type(MediaType.APPLICATION_OCTET_STREAM)
					.build();
			
		} finally {
			if (fileInputStream != null) {
				fileInputStream.close();
			}
			if (stream != null) {
				stream.close();
			}
		}
	}
	
	
	@Path("/bytes/{idAnexo}")
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	public String getBytes(@PathParam(value = "idAnexo") Integer idAnexo) throws ServiceException, IOException {
		if (idAnexo == null) {
			fail("O id do anexo NÂO pode ser NuLO!", "MSG_attachment_null");
		}
		
		FileInputStream fileInputStream = null;
		ByteArrayOutputStream stream = null;
		try {
			Anexo attachment = anexoService.findByPk(new Anexo(idAnexo));
			
			String diretorio = attachment.getDiretorio();
			if (! diretorio.substring(diretorio.length()-2).equals("\\")) {
				diretorio = diretorio + "\\";
			}

			File fileToDownload = new File(diretorio + attachment.getNomeFake());
			fileInputStream = new FileInputStream(fileToDownload);
			stream = new ByteArrayOutputStream();
			int i;
			while ((i = fileInputStream.read()) != -1) {
				stream.write(i);
			}
			
			String ret =  new sun.misc.BASE64Encoder().encode(stream.toByteArray());
			
			return ret;

		} finally {
			if (fileInputStream != null) {
				fileInputStream.close();
			}
			if (stream != null) {
				stream.close();
			}
		}
	}
}
