/**
 * 
 */
package br.com.callink.cad.rest.api;

import java.util.List;

import javax.annotation.security.DenyAll;
import javax.annotation.security.RolesAllowed;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import br.com.callink.cad.dto.UsuarioLogadoDTO;
import br.com.callink.cad.repository.to.CampoDinamicoTO;
import br.com.callink.cad.repository.to.LayoutEditCasoTO;
import br.com.callink.cad.rest.api.inject.InjectEJB;
import br.com.callink.cad.service.ILayoutEditCasoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.util.CollectionUtils;

/**
 * @author neppo_antonio
 *
 */
@Path("/dynamicfield")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@DenyAll
public class DynamicFieldResource extends GenericResource {

	@InjectEJB(ejbName = "LayoutEditCasoService")
	private ILayoutEditCasoService layoutEditCasoService;

	@Context
	private HttpServletRequest rawRequest;

	private HttpServletRequest getRawRequest() {
		return this.rawRequest;
	}

	/**
	 * Busca campos dinamicos
	 * 
	 * @param idAcao
	 * @param idCaso
	 * @return
	 * @throws ServiceException
	 * @throws ValidationException
	 */
	@Path("/action/{actionId}/case/{caseId}")
	@GET
	@RolesAllowed({ "EDICAO_CASOS" })
	public List<CampoDinamicoTO> getDynamicFields(@PathParam(value = "actionId") Integer idAcao, @PathParam(value = "caseId") Integer idCaso) throws ServiceException, ValidationException {
		if (idAcao == null) {
			fail("Id da acao nao pode ser nulo!", "MSG_action_id_required");
		}
		if (idCaso == null) {
			fail("Id do caso nao pode ser nulo!", "MSG_case_id_required");
		}
		UsuarioLogadoDTO user = getLoggedUser(getRawRequest());

		LayoutEditCasoTO layout = (LayoutEditCasoTO) layoutEditCasoService.findLayoutCaseEditByAcaoVerifyUser(idAcao, idCaso, user != null ? user.getIdUsuario() : null).getData();
		if (layout == null || CollectionUtils.isEmpty(layout.getListaCamposDinamicos())) {
			fail("Layout de edicao de caso nao encontrado!", "MSG_edit_layout_not_found");
		}
		return layout.getListaCamposDinamicos();
	}
}
