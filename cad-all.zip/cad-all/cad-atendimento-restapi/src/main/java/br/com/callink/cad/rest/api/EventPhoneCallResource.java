package br.com.callink.cad.rest.api;

import java.util.List;
import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import br.com.callink.cad.repository.to.EventoTO;
import br.com.callink.cad.rest.api.inject.InjectEJB;
import br.com.callink.cad.service.IEventoLigacaoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 * 
 * @author swb_samuel
 * 
 */
@Path("/eventphonecall")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@PermitAll
public class EventPhoneCallResource extends GenericResource {

	@InjectEJB(ejbName = "EventoLigacaoService")
	private IEventoLigacaoService eventoLigacaoService;

	@Path("/operation/{idOperacao}")
	@GET
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	public List<EventoTO> findParentsActivesByOperation(@PathParam(value = "idOperacao") Integer idOperacao) throws ServiceException, ValidationException {
		return eventoLigacaoService.buscaEventosPaisAtivosPorOperacao(idOperacao);
	}

	@Path("/perentevent/{idEventoPai}")
	@GET
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	public List<EventoTO> findChildrenActives(@PathParam(value = "idEventoPai") Integer idEventoPai) throws ServiceException, ValidationException {
		return eventoLigacaoService.buscaFilhosAtivos(idEventoPai);
	}

	@Path("/case/{idCaso}")
	@GET
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	public List<EventoTO> findPossibleParentsByCase(@PathParam(value = "idCaso") Integer idCaso) throws ServiceException, ValidationException {
		return eventoLigacaoService.buscaPossiveisEventosPaisPorCaso(idCaso);
	}
}