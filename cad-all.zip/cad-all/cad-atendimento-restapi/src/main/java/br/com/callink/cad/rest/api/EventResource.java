package br.com.callink.cad.rest.api;

import java.util.List;

import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import br.com.callink.cad.dto.UsuarioLogadoDTO;
import br.com.callink.cad.repository.to.EventoTO;
import br.com.callink.cad.repository.to.NoEventoTO;
import br.com.callink.cad.rest.api.inject.InjectEJB;
import br.com.callink.cad.service.IEventoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 * 
 * @author swb_samuel
 * 
 */
@Path("/event")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@PermitAll
public class EventResource extends GenericResource {

	@InjectEJB(ejbName = "EventoService")
	private IEventoService eventoService;
	
	@Context
	private HttpServletRequest rawRequest;

	private HttpServletRequest getRawRequest() {
		return this.rawRequest;
	}

	//VERIFIED
	@Path("/operation/{idOperacao}")
	@GET
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	public List<EventoTO> findParentsActivesByOperation(@PathParam(value = "idOperacao") Integer idOperacao) throws ServiceException, ValidationException {
		return eventoService.buscaEventosPaisAtivosPorOperacao(idOperacao);
	}

	//VERIFIED
	@Path("/perentevent/{idEventoPai}")
	@GET
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	public List<EventoTO> findChildrenActives(@PathParam(value = "idEventoPai") Integer idEventoPai) throws ServiceException, ValidationException {
		return eventoService.buscaFilhosAtivos(idEventoPai);
	}

	//VERIFIED
	@Path("/case/{idCaso}")
	@GET
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	public List<EventoTO> findPossibleParentsByCase(@PathParam(value = "idCaso") Integer idCaso) throws ServiceException, ValidationException {
		UsuarioLogadoDTO user = getLoggedUser(getRawRequest());
		return eventoService.buscaPossiveisEventosPaisPorCaso(idCaso,user != null ? user.getIdUsuario() : null);
	}
	
	@Path("/tree/case/{idCaso}")
	@GET
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	public NoEventoTO buscaArvoreEventosPorCaso(@PathParam(value = "idCaso") Integer idCaso)  throws ServiceException, ValidationException {
		UsuarioLogadoDTO user = getLoggedUser(getRawRequest());
		return eventoService.buscaArvoreEventosPorCaso(idCaso,user != null ? user.getIdUsuario() : null);
	}
}