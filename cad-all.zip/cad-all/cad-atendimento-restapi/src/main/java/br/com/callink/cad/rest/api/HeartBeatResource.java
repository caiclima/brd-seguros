package br.com.callink.cad.rest.api;

import java.util.Date;

import javax.annotation.security.PermitAll;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import br.com.callink.cad.dto.PingDTO;

/**
 * 
 * @author michael_rocha
 * 
 */
@Path("/srvp")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@PermitAll
public class HeartBeatResource {

	@Path("/")
	@GET
	@PermitAll
	public PingDTO get() {
		Date d = new Date();
		return new PingDTO(d.getTime(), d.toString());
	}
}