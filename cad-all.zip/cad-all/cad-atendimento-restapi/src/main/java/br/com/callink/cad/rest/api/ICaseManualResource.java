/**
 * 
 */
package br.com.callink.cad.rest.api;

import java.util.List;
import javax.annotation.security.RolesAllowed;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import br.com.callink.cad.dto.CasoManual;
import br.com.callink.cad.repository.to.CampoDinamicoTO;
import br.com.callink.cad.repository.to.LayoutCasoManualTO;
import br.com.callink.cad.service.exception.ServiceException;
import com.sun.jersey.multipart.FormDataBodyPart;
import com.sun.jersey.multipart.FormDataMultiPart;
import com.sun.jersey.multipart.FormDataParam;

/**
 * @author neppo_antonio
 *
 */
public interface ICaseManualResource {
	
	public final static String ATTACHMENT_PRIVILEGE_MANUAL_CASE = "ANEXAR_DOCUMENTOS_CASO_MANUAL";
	
	@GET
	@Path("/returnfields/{idOperacao}/casetype/{idCaseType}")
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	List<CampoDinamicoTO> findFieldsCase(@PathParam(value = "idOperacao") Integer idOperacao, @PathParam(value = "idCaseType") Integer idTipoCaso) throws ServiceException;
	
	@GET
	@Path("/layoutpreview/user/{idUsuario}")
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	List<LayoutCasoManualTO> findLayoutPreview(@PathParam(value = "idUsuario") Integer idUsuario) throws Exception;

	@GET
	@Path("/operation/{idOperacao}/typecase/{idTipoCaso}/user/{idUsuario}")
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	CasoManual createMetaData(@PathParam(value = "idOperacao") Integer idOperacao, @PathParam(value = "idTipoCaso") Integer idTipoCaso, @PathParam(value = "idUsuario") Integer idUsuario) throws Exception;
	
	@GET
	@Path("/layout/{idLayout}/user/{idUsuario}")
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	CasoManual createMetaDataByLayout(@PathParam(value = "idLayout") Integer idLayout, @PathParam(value = "idUsuario") Integer idUsuario) throws Exception;

	@Path("/new")
	@POST
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	@Produces(MediaType.TEXT_PLAIN)
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	Object createCase(FormDataMultiPart multiPart, @FormDataParam("idOperacao") Integer idOperacao, @FormDataParam("idTipoCaso") Integer idTipoCaso, @FormDataParam("idUsuario") Integer idUsuario, @FormDataParam("idCasoExterno") String idCasoExterno, @FormDataParam("idCanal") Integer idCanal, @FormDataParam("idEvento") Integer idEvento,
			@FormDataParam("camposDinamicos") List<FormDataBodyPart> camposDinamicos, @FormDataParam("observacao") String observacao, @FormDataParam("dataAbertura") Long dataAbertura,@FormDataParam("idCasoPai") String idCasoPai) throws ServiceException;

}