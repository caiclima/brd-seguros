/**
 * 
 */
package br.com.callink.cad.rest.api;

import java.util.List;
import java.util.Map;

import javax.annotation.security.RolesAllowed;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import br.com.callink.cad.dto.ResultTO;
import br.com.callink.cad.pojo.Causa;
import br.com.callink.cad.pojo.ConfiguracaoCaixaEmail;
import br.com.callink.cad.pojo.EmailModelo;
import br.com.callink.cad.pojo.ObservacaoModelo;
import br.com.callink.cad.pojo.Usuario;
import br.com.callink.cad.repository.to.AcaoTipoAcaoCasoTO;
import br.com.callink.cad.repository.to.CasoAbertoAtendenteTO;
import br.com.callink.cad.repository.to.CasoDetalhadoTO;
import br.com.callink.cad.repository.to.ConteudoApoioTO;
import br.com.callink.cad.repository.to.DadosClassificaCasoTO;
import br.com.callink.cad.repository.to.DelegaCasoTO;
import br.com.callink.cad.repository.to.EmailTO;
import br.com.callink.cad.repository.to.GrupoEmailTO;
import br.com.callink.cad.repository.to.TelefoneTO;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

import com.sun.jersey.multipart.FormDataBodyPart;
import com.sun.jersey.multipart.FormDataMultiPart;
import com.sun.jersey.multipart.FormDataParam;

/**
 * @author neppo_antonio
 *
 */
public interface ICasesResource {
	
	public final static String ATTACHMENT_PRIVILEGE_ACTIONS = "ANEXAR_DOCUMENTOS_ACOES";
	public final static String ATTACHMENT_PRIVILEGE_EMAIL = "ANEXAR_DOCUMENTOS_ENVIO_EMAIL";
	public final static String ATTACHMENT_PRIVILEGE_EMAIL_REPLY = "ANEXAR_DOCUMENTOS_ENVIO_EMAIL_RESPOSTA";
	public final static String SEND_EMAIL_REPLY = "ENVIO_EMAIL_RESPOSTA";
	public final static String FOWARD_EMAIL = "ENCAMINHAR_EMAIL";

	@Path("{id}/dialphone/")
	@PUT
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	public Response ligarTel(TelefoneTO tel) throws Exception;

	@Path("/quantity/users/{id}")
	@GET
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	public ResultTO<Long> getCasesCountByUser(@PathParam(value = "id") Integer id) throws Exception;

	@Path("/users/{id}/{page}/{maxresults}")
	@GET
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	public CasoAbertoAtendenteTO[] getCasesByUser(@PathParam(value = "id") Integer id, @PathParam(value = "page") Integer page, @PathParam(value = "maxresults") Integer maxresults) throws Exception;

	@Path("/cases/{idCases}")
	@GET
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	public CasoDetalhadoTO getCasesTable(@PathParam(value = "idCases") Integer idCases) throws Exception;

	@Path("/associate/{idUsuario}/{idCaso}/{idOperacao}")
	@GET
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	public  List<CasoDetalhadoTO> getCasesAssociate(@PathParam(value = "idUsuario") Integer idUsuario, @PathParam(value = "idCaso") Integer idCaso, @PathParam(value = "idOperacao") Integer idOperacao) throws Exception;

	@Path("/case/{idCase}/user/{userId}")
	@GET
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	public CasoDetalhadoTO getCaseRequestUser(@PathParam(value = "idCase") Integer idCase, @PathParam(value = "userId") Integer userId) throws Exception;

	@Path("/emailsofcases/{idCases}")
	@GET
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	public List<EmailTO> getEmailsOfCases(@PathParam(value = "idCases") Integer idCases) throws Exception;

	@Path("/email/{idEmail}")
	@PUT
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	public EmailTO getClientGroupedCases(@PathParam(value = "idEmail") Integer idEmail) throws Exception;

	@Path("/{id}/actions")
	@GET
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	public List<AcaoTipoAcaoCasoTO> getCasesActions(@PathParam(value = "id") Integer id) throws Exception;

	@Path("/userRequestCase/{idUser}")
	@PUT
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	public CasoDetalhadoTO userRequestCase(Usuario usuario) throws Exception;

	@Path("/{id}/causes")
	@GET
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	public List<Causa> getCasesCauses(@PathParam(value = "id") Integer id) throws Exception;

	@Path("/nextCase/{idUser}")
	@PUT
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	public CasoDetalhadoTO nextCase(Usuario usuario) throws Exception;

	@Path("/requestCase/{idUser}")
	@PUT
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	public CasoDetalhadoTO requestCase(CasoDetalhadoTO caso) throws Exception;

	@Path("/{id}/dataforclassification")
	@GET
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	public DadosClassificaCasoTO dataForClassificationCase(@PathParam(value = "id") Integer idCaso) throws Exception;

	@Path("/findemailgroupforoperationcase/{idCaso}")
	@GET
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	public List<GrupoEmailTO> findEmailGroupForOperationCase(@PathParam(value = "idCaso") Integer idCaso) throws Exception;

	@Path("/findcontentsupportbycase/{idCase}")
	@GET
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	public ConteudoApoioTO findContentSupportByCase(@PathParam(value = "idCase") Integer idCase) throws Exception;

	@Path("/{id}/phones")
	@GET
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	public List<TelefoneTO> findPhonesByCase(@PathParam(value = "id") Integer id) throws ServiceException, ValidationException;

	@Path("/{id}/phonesuncategorized")
	@GET
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	public List<TelefoneTO> findPhonesUncategorized(@PathParam(value = "id") Integer id) throws ServiceException, ValidationException;

	@Path("/requirespasswordmaster/user/{userId}")
	@PUT
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	public ResultTO<Boolean> exigeSenhaDeSupervisorParaAssociacao(DelegaCasoTO to) throws Exception;

	@Path("/requirespasswordmastertoupdatephone/{id}")
	@GET
	public ResultTO<Boolean> exigeSenhaDeSupervisorParaAtualizarTelefones(@PathParam(value = "id") Integer idEmail) throws ValidationException, ServiceException;

	@Path("/delegatecase/user/{userId}")
	@PUT
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	public Response associarCasoUsuario(DelegaCasoTO to) throws ServiceException, ValidationException;

	@Path("/email/datatoresponse/{id}")
	@GET
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	EmailTO getDataToResponse(@PathParam(value = "id") Integer idEmail) throws Exception;

	@Path("/replymail")
	@POST
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	@Produces(MediaType.TEXT_PLAIN)
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	public Response responderEmail(FormDataMultiPart multiPart, @FormDataParam("idEmailPai") Integer idEmailPai, @FormDataParam("destinatario") String destinatario,
			@FormDataParam("destinatarioCopia") String destinatarioCopia, @FormDataParam("destinatarioParaExibicao") String destinatarioParaExibicao, @FormDataParam("conteudo") String conteudo,
			@FormDataParam("assunto") String assunto, @FormDataParam("idUsuario") Integer idUsuario, @FormDataParam("idCaso") Integer idCaso,
			@FormDataParam("listIdGroupEmailTO") List<FormDataBodyPart> bparts) throws Exception;

	@Path("/caixas/operacao/{operationId}")
	@GET
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	public List<ConfiguracaoCaixaEmail> getCaixasEmail(@PathParam("operationId") Integer idOperacao) throws Exception;

	/**
	 * @param idCaso
	 * @return
	 * @throws Exception
	 */
	@Path("/email/template/case/{caseId}")
	@GET
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	List<EmailModelo> buscaModelosEmailDisponiveisPorCaso(@PathParam("caseId") Integer idCaso) throws Exception;

	@Path("/apply/email/template/{templateId}/case/{caseId}")
	@GET
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	Map<String, String> aplicarModeloEmail(@PathParam("templateId") Integer idEmailModelo, @PathParam("caseId") Integer idCaso) throws Exception;
	
	/**
	 * @param idCaso
	 * @return
	 * @throws Exception
	 */
	@Path("/observation/template/case/{caseId}")
	@GET
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	List<ObservacaoModelo> buscaModelosDeObservacaoDisponiveisPorCaso(@PathParam("caseId") Integer idCaso) throws Exception;
	
	@Path("/apply/observation/template/{templateId}/case/{caseId}")
	@GET
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	ResultTO<String> aplicarModeloObservacao(@PathParam("templateId") Integer idObservacaoModelo, @PathParam("caseId") Integer idCaso) throws Exception;
	
	
	@Path("/email/anexo/{idEmail}")
	@GET
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	public EmailTO getAnexoEmail(@PathParam(value = "idEmail") Integer idEmail) throws Exception;
	
	@Path("/fowardmail")
	@POST
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	@Produces(MediaType.TEXT_PLAIN)
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	public Response fowardEmail(FormDataMultiPart multiPart, @FormDataParam("idEmailPai") Integer idEmailPai, @FormDataParam("destinatario") String destinatario,
			@FormDataParam("destinatarioCopia") String destinatarioCopia, @FormDataParam("destinatarioParaExibicao") String destinatarioParaExibicao, @FormDataParam("conteudo") String conteudo,
			@FormDataParam("assunto") String assunto, @FormDataParam("idUsuario") Integer idUsuario, @FormDataParam("idCaso") Integer idCaso,
			@FormDataParam("listIdGroupEmailTO") List<FormDataBodyPart> bpartsGrupoEmail, @FormDataParam("listaAnexos") List<FormDataBodyPart> bpartsAnexo) throws Exception;
}
