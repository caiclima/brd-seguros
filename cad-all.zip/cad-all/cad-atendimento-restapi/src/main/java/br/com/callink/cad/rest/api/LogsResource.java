package br.com.callink.cad.rest.api;

import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import br.com.callink.cad.dto.UsuarioLogadoDTO;
import br.com.callink.cad.repository.to.HistoricoCasoAgrupadoTO;
import br.com.callink.cad.rest.api.inject.InjectEJB;
import br.com.callink.cad.service.ILogService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 * 
 * @author swb_halan
 * 
 */
@Path("/logs")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@PermitAll
public class LogsResource extends GenericResource {

	@InjectEJB(ejbName = "LogService")
	private ILogService logService;

	@Context
	private HttpServletRequest rawRequest;

	private HttpServletRequest getRawRequest() {
		return this.rawRequest;
	}

	// VERIFIED
	@Path("/cases/{id}/{lastId}/{maxResults}")
	@GET
	@RolesAllowed({ "BUSCAR_INFORMACOES_LOG" })
	public HistoricoCasoAgrupadoTO getCasesByUser(@PathParam(value = "id") Integer id, @PathParam(value = "lastId") Integer lastId, @PathParam(value = "maxResults") Integer maxResults) throws ServiceException, ValidationException {
		if (id == null) {
			fail("id do caso nao pode ser nulo!", "MSG_case_id_required");
		}
		if (lastId == null || maxResults == null) {
			fail("Necessario informar a pagina e a quantidade de retorno", "MSG_page_return_quantity_required");
		}

		UsuarioLogadoDTO user = getLoggedUser(getRawRequest());

		return (HistoricoCasoAgrupadoTO) logService.buscarLogCasoAgrupado(id, lastId, maxResults, Boolean.FALSE, user != null ? user.getIdUsuario() : null).getData();
	}

	// VERIFIED
	@Path("/cases/{id}/useronly/{confirm}/{lastId}/{maxResults}")
	@GET
	@RolesAllowed({ "BUSCAR_INFORMACOES_LOG" })
	public HistoricoCasoAgrupadoTO getCasesByUser(@PathParam(value = "id") Integer id, @PathParam(value = "confirm") Boolean flagComUsuario, @PathParam(value = "lastId") Integer lastId, @PathParam(value = "maxResults") Integer maxResults) throws ServiceException, ValidationException {
		if (id == null) {
			fail("id do caso nao pode ser nulo!", "MSG_case_id_required");
		}
		if (lastId == null || maxResults == null) {
			fail("Necessario informar a pagina e a quantidade de retorno", "MSG_page_return_quantity_required");
		}
		if (flagComUsuario == null) {
			flagComUsuario = Boolean.FALSE;
		}
		UsuarioLogadoDTO user = getLoggedUser(getRawRequest());

		return (HistoricoCasoAgrupadoTO) logService.buscarLogCasoAgrupado(id, lastId, maxResults, flagComUsuario, user != null ? user.getIdUsuario() : null).getData();
	}

}
