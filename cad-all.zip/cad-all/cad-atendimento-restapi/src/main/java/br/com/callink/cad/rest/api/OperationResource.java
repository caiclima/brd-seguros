package br.com.callink.cad.rest.api;

import java.util.List;

import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import br.com.callink.cad.pojo.Operacao;
import br.com.callink.cad.pojo.ParametroSistemaOperacao;
import br.com.callink.cad.rest.api.inject.InjectEJB;
import br.com.callink.cad.service.IOperacaoService;
import br.com.callink.cad.service.IParametroSistemaOperacaoService;
import br.com.callink.cad.service.exception.ServiceException;

@Path("/operation")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@PermitAll
public class OperationResource extends GenericResource {

	@InjectEJB(ejbName = "OperacaoService")
	private IOperacaoService operacaoService;

	@InjectEJB(ejbName = "ParametroSistemaOperacaoService")
	private IParametroSistemaOperacaoService parametroOperacao;

	@Context
	private HttpServletRequest rawRequest;

	private HttpServletRequest getRawRequest() {
		return this.rawRequest;
	}

	// VERIFIED
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	@GET
	@Path("/user/{idUser}")
	public List<Operacao> buscaOperacaoesUsuario(@PathParam(value = "idUser") Integer id) throws Exception {

		verifyRequestUser(getRawRequest(), id);
		return operacaoService.buscaOperacaoesUsuarioDetached(id);
	}

	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	@GET
	@Path("/{idOperacao}/parameter/{key}")
	public ParametroSistemaOperacao acessAction(@PathParam(value = "idOperacao") Integer idOperacao, @PathParam(value = "key") String key) throws ServiceException {

		ParametroSistemaOperacao findByParam = parametroOperacao.findByParam(key, idOperacao);
		findByParam.setOperacao(null);
		return findByParam;
	}

}
