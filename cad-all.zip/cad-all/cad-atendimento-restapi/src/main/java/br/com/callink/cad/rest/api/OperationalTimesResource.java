package br.com.callink.cad.rest.api;

import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import br.com.callink.cad.pojo.Usuario;
import br.com.callink.cad.repository.to.StatusAtualTO;
import br.com.callink.cad.repository.to.TemposOperacionaisTO;
import br.com.callink.cad.rest.api.inject.InjectEJB;
import br.com.callink.cad.service.IStatusUsuarioService;

/**
 * 
 * @author swb_halan
 * 
 */
@Path("/operationaltimes")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@PermitAll
public class OperationalTimesResource extends GenericResource {

	@InjectEJB(ejbName = "StatusUsuarioService")
	private IStatusUsuarioService statusUsuarioService;
	
	@Context
	private HttpServletRequest rawRequest;

	private HttpServletRequest getRawRequest() {
		return this.rawRequest;
	}

	//VERIFIED
	@Path("/users/{id}")
	@GET
	@RolesAllowed({ "BUSCAR_TEMPOS_OPERACIONAIS" })
	public TemposOperacionaisTO getByUser(@PathParam(value = "id") Integer id) throws Exception {
		if (id == null) {
			fail("id do usuario nao pode ser nulo!", "MSG_user_id_required");
		}
		verifyRequestUser(getRawRequest(), id);
		Usuario usuario = new Usuario();
		usuario.setIdUsuario(id);
		return (TemposOperacionaisTO) statusUsuarioService.geraRelatorioStatusUsuario(usuario).getData();
	}

	@Path("/user/{idUsuario}/currentstatus")
	@GET
	@RolesAllowed({ "CONTROLE_STATUS_USUARIO" })
	public StatusAtualTO statusAtualUsuario(@PathParam(value = "idUsuario") Integer idUsuario) throws Exception {
		if(idUsuario == null || idUsuario <= 0) {
			fail("Obrigatório informar o id do usuario", "MSG_user_id_required");
		}
		verifyRequestUser(getRawRequest(), idUsuario);
		return (StatusAtualTO) statusUsuarioService.buscaUltimoStatusUsuarioTO(idUsuario).getData();
	}
	
}
