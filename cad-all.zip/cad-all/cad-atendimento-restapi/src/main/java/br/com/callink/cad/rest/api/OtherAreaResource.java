package br.com.callink.cad.rest.api;

import java.util.List;

import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import br.com.callink.cad.repository.to.OutraAreaTO;
import br.com.callink.cad.rest.api.inject.InjectEJB;
import br.com.callink.cad.service.IOutraAreaService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.service.utils.ServiceResponse;

@Path("/otherArea")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@PermitAll
public class OtherAreaResource extends GenericResource {

	@InjectEJB(ejbName = "OutraAreaService")
	private IOutraAreaService outraAreaService;
	
	//VERIFIED
	@SuppressWarnings("unchecked")
	@Path("/cases/{id}")
	@GET
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	public List<OutraAreaTO> getCasesOtherAreas(@PathParam(value = "id") Integer id) throws ServiceException, ValidationException {
		if (id == null) {
			fail("Id do caso nao pode ser nulo!", "MSG_case_id_required");
		}
		ServiceResponse serviceResponse = outraAreaService.buscarOutrasAreasCaso(id);
		return (List<OutraAreaTO>) serviceResponse.getData();
	}
	
}
