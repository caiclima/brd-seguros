package br.com.callink.cad.rest.api;

import java.util.List;

import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import br.com.callink.cad.dto.UsuarioLogadoDTO;
import br.com.callink.cad.pojo.ResultadoQuestionario;
import br.com.callink.cad.repository.to.QuestionarioTO;
import br.com.callink.cad.repository.to.RespostaTO;
import br.com.callink.cad.repository.to.ResultadoQuestionarioTO;
import br.com.callink.cad.rest.api.inject.InjectEJB;
import br.com.callink.cad.service.ICasoService;
import br.com.callink.cad.service.IQuestionarioService;
import br.com.callink.cad.service.IRespostaService;
import br.com.callink.cad.service.IResultadoQuestionarioService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.service.utils.ServiceResponse;

/**
 * 
 * @author swb_brunocamargo
 * 
 */
@Path("/questionnaire")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@PermitAll
public class QuestionarioResource extends GenericResource {

	@InjectEJB(ejbName = "QuestionarioService")
	private IQuestionarioService questionarioService;

	@InjectEJB(ejbName = "CasoService")
	private ICasoService casoService;

	@InjectEJB(ejbName = "ResultadoQuestionarioService")
	private IResultadoQuestionarioService resultadoQuestionarioService;
	
	@InjectEJB(ejbName = "RespostaService")
	private IRespostaService respostaService;
	
	@Context
	private HttpServletRequest rawRequest;

	private HttpServletRequest getRawRequest() {
		return this.rawRequest;
	}
	
	@GET
	@Path("/list/case/{idCase}/user/{userId}")
	@RolesAllowed({ "VISUALIZAR_RESULTADO_QUESTIONARIO" })
	public List<ResultadoQuestionarioTO> carregaQuestionarios(@PathParam(value = "idCase") Integer idCaso, @PathParam(value = "userId") Integer userId) throws Exception {
		verifyRequestUser(getRawRequest(), userId);
		return resultadoQuestionarioService.questionariosRespondidos(idCaso);
	}

	@GET
	@Path("/result/{resultId}/user/{userId}")
	@RolesAllowed({ "BUSCAR_INFORMACOES_QUESTIONARIO" })
	public List<RespostaTO> carregaRespostas(@PathParam(value = "resultId") Integer resultId, @PathParam(value = "userId") Integer userId) throws Exception {
		verifyRequestUser(getRawRequest(), userId);
		return respostaService.buscaRespostasPorResultado(new ResultadoQuestionario(resultId));
	}

	@GET
	@Path("/action/{idAction}/case/{idCase}/user/{idUser}")
	@RolesAllowed({ "BUSCAR_INFORMACOES_QUESTIONARIO" })
	public QuestionarioTO findFieldsCase(@PathParam(value = "idAction") Integer idAcao, @PathParam(value = "idCase") Integer idCase, @PathParam(value = "idUser") Integer idUser) throws Exception {

		if (idUser == null) {
			fail("Usuário não pode ser nulo.", "MSG_user_null");
		}
		if (idCase == null) {
			fail("Caso não pode ser nulo.", "MSG_case_null");
		}

		verifyRequestUser(getRawRequest(), idUser);

		ServiceResponse serviceResponse = questionarioService.buscaQuestionarioPorCaso(idAcao, idCase, idUser);

		if (serviceResponse == null) {
			fail("Erro ao buscar questionário.", "MSG_questionnaire_search_error");
		}

		return (QuestionarioTO) serviceResponse.getData();
	}

	@PUT
	@Path("/saveissue")
	@RolesAllowed({ "BUSCAR_INFORMACOES_QUESTIONARIO" })
	public Response saveCheckList(QuestionarioTO questionarioTO) throws ServiceException, ValidationException {
		
		UsuarioLogadoDTO user = getLoggedUser(getRawRequest());
		
		resultadoQuestionarioService.saveRespostaQuestionario(questionarioTO,user != null ? user.getIdUsuario() : null);
		
		return Response.ok("{}").build();
	}

}
