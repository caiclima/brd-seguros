package br.com.callink.cad.rest.api;

import java.util.List;

import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import br.com.callink.cad.engine.command.executor.IExecutorCommandService;
import br.com.callink.cad.pojo.Usuario;
import br.com.callink.cad.repository.to.UsuarioStatusTO;
import br.com.callink.cad.rest.api.inject.InjectEJB;
import br.com.callink.cad.service.IStatusUsuarioService;
import br.com.callink.cad.service.IUsuarioLogadoService;
import br.com.callink.cad.service.IUsuarioStatusService;
import br.com.callink.cad.service.utils.ServiceResponse;

/**
 * 
 * @author swb_brunocamargo
 * 
 */
@Path("/status")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@PermitAll
public class StatusResource extends GenericResource {
	
	@InjectEJB(ejbName = "ExecutorCommandService")
	private IExecutorCommandService executor;
	
	@InjectEJB(ejbName = "UsuarioStatusService")
	private IUsuarioStatusService usuarioStatusService;
	
	@InjectEJB(ejbName = "UsuarioLogadoService")
	private IUsuarioLogadoService usuarioLogadoService;
	
	@InjectEJB(ejbName = "StatusUsuarioService")
	private IStatusUsuarioService statusUsuarioService;
	
	@Context
	private HttpServletRequest rawRequest;

	private HttpServletRequest getRawRequest() {
		return this.rawRequest;
	}
	
	@SuppressWarnings("unchecked")
	@Path("/findstatususer/{idUsuario}")
	@GET
	@RolesAllowed({ "CONTROLE_STATUS_USUARIO" })
	public List<UsuarioStatusTO> findStatusUser(@PathParam(value = "idUsuario") Integer idUsuario) throws Exception {
		
		if(idUsuario == null) {
			fail("Obrigatório informar o id do usuario", "MSG_user_id_required");
		}
		
		verifyRequestUser(getRawRequest(), idUsuario);
		
		ServiceResponse serviceResponse = usuarioStatusService.buscaStatusPausaUsuario(idUsuario);
		return (List<UsuarioStatusTO>) serviceResponse.getData();
		
	}
	
	
	@Path("/updatestatuspauseuser/{idUsuario}")
	@PUT
	@RolesAllowed({ "CONTROLE_STATUS_USUARIO" })
	public Response updateStatusPauseUser(UsuarioStatusTO usuarioStatusTO) throws Exception {
		
		if(usuarioStatusTO.getIdUsuario() == null) {
			fail("Obrigatório informar o id do usuario", "MSG_user_id_required");
		}
		
		if(usuarioStatusTO.getIdUsuarioStatus() == null) {
			fail("Obrigatório informar o id da pausa", "MSG_pause_id_required");
		}
		
		verifyRequestUser(getRawRequest(), usuarioStatusTO.getIdUsuario());
		Usuario usuario = new Usuario(usuarioStatusTO.getIdUsuario());
		
		ServiceResponse serviceResponse = statusUsuarioService.alterarStatusUsuarioPausa(usuarioStatusTO.getIdUsuario(), usuarioStatusTO.getIdUsuarioStatus());
		UsuarioStatusTO usuarioStatusTORetorno = (UsuarioStatusTO) serviceResponse.getData();
		
		if (usuarioStatusTORetorno.getMessage() != null && !usuarioStatusTORetorno.getMessage().isEmpty()) {
			fail(usuarioStatusTORetorno.getMessage());
		}
		usuarioLogadoService.solicitaAlteracaoStatus(usuario);
		
		return Response.ok("{}").build();
	}
	
	@Path("/updatestatuscontinuouser/{idUsuario}")
	@PUT
	@RolesAllowed({ "CONTROLE_STATUS_USUARIO" })
	public Response updateStatusContinuoUser(UsuarioStatusTO usuarioStatusTO) throws Exception {
		
		if(usuarioStatusTO.getIdUsuario() == null) {
			fail("Obrigatório informar o id do usuario", "MSG_user_id_required");
		}
		
		verifyRequestUser(getRawRequest(), usuarioStatusTO.getIdUsuario());
		
		statusUsuarioService.alterarStatusUsuarioDisponivel(usuarioStatusTO.getIdUsuario());
		return Response.ok("{}").build();
	}
}
