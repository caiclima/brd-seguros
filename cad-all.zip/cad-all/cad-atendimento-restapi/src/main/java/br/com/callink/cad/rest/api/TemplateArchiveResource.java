package br.com.callink.cad.rest.api;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.security.DenyAll;
import javax.annotation.security.RolesAllowed;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import br.com.callink.cad.pojo.Operacao;
import br.com.callink.cad.pojo.TemplateArquivo;
import br.com.callink.cad.rest.api.inject.InjectEJB;
import br.com.callink.cad.service.IOperacaoService;
import br.com.callink.cad.service.ITemplateArquivoService;

/**
 * Classe Template Arquivos
 *
 * @author William D. Silva
 * 
 */
@Path("/templateArchive/")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@DenyAll
public class TemplateArchiveResource extends GenericResource {

	@InjectEJB(ejbName = "TemplateArquivoService")
	private ITemplateArquivoService templateArquivoService;

	@InjectEJB(ejbName = "OperacaoService")
	private IOperacaoService operacaoService;

	@Path("/{idOperacao}")
	@GET
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	public List<TemplateArquivo> getTemplateAtivos(@PathParam(value = "idOperacao") Integer idOperacao) throws Exception {
		Operacao operacao = operacaoService.findByPk(new Operacao(idOperacao));

		List<Operacao> operacoes = new ArrayList<Operacao>();
		operacoes.add(operacao);
		List<TemplateArquivo> list = templateArquivoService.findAtivosPorOperacao(operacoes);
		if (list != null && !list.isEmpty()) {
			for (TemplateArquivo templateArquivo : list) {
				templateArquivo.setOperacao(null);
				templateArquivo.setUsuarioAlteracao(null);
				templateArquivo.setUsuarioCriacao(null);
			}
		}
		return list;
	}

}
