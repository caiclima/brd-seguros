package br.com.callink.cad.rest.api;

import javax.annotation.security.DenyAll;
import javax.annotation.security.RolesAllowed;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriInfo;

import br.com.callink.cad.rest.api.inject.InjectEJB;
import br.com.callink.cad.service.IParametroSistemaService;
import br.com.callink.cad.service.ITenantService;

/**
 * Classe de labels do bundle
 *
 * @author William D. Silva
 * 
 */
@Path("/tenant/")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@DenyAll
public class TenantResource extends GenericResource {

	@InjectEJB(ejbName = "ParametroSistemaService")
	private IParametroSistemaService parametroService;

	@InjectEJB(ejbName = "TenantService")
	private ITenantService tenantService;
	
	@Context
    private UriInfo uriInfo; 
     
     
    @Context
    private HttpServletRequest request; 

	@Path("/logo/{idOperacao}")
	@GET
	@RolesAllowed({ "BUSCAR_RECURSOS_BASELINE" })
	public String getLogo(@PathParam(value = "idOperacao") Integer idOperacao) throws Exception {

			String path = tenantService.getImageLogo(idOperacao);
			
		return String.format("{\"value\":\"%s\"}",path);
	}

}
