package br.com.callink.cad.rest.api;

import java.util.List;
import java.util.Map;
import javax.annotation.security.DenyAll;
import javax.annotation.security.RolesAllowed;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import br.com.callink.cad.dto.UsuarioLogadoDTO;
import br.com.callink.cad.pojo.Operacao;
import br.com.callink.cad.pojo.Usuario;
import br.com.callink.cad.repository.to.NotificacoesTO;
import br.com.callink.cad.repository.to.UsuarioTO;
import br.com.callink.cad.rest.api.inject.InjectEJB;
import br.com.callink.cad.rest.api.security.exception.ExpirationAccessException;
import br.com.callink.cad.service.IAuthenticationService;
import br.com.callink.cad.service.INotificacaoService;
import br.com.callink.cad.service.IOperacaoUsuarioService;
import br.com.callink.cad.service.IUsuarioService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.service.utils.ServiceResponse;
import br.com.callink.cad.util.StringUtils;
import br.com.callink.sso.authlib.utils.web.CookieManager;
import br.com.callink.sso.infrastructure.utils.constants.AuthConstants;
import br.com.callink.sso.infrastructure.utils.cryptography.engine.CryptographyEngine;
import br.com.callink.sso.infrastructure.utils.cryptography.impl.Base64Cryptographer;

/**
 * API de Usuários
 *
 * @author michael_rocha
 * 
 */
@Path("/users")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@DenyAll
public class UserResource extends GenericResource {

	@InjectEJB(ejbName = "UsuarioService")
	private IUsuarioService usuarioService;

	@InjectEJB(ejbName = "AuthenticationService")
	private IAuthenticationService authenticationService;

	@InjectEJB(ejbName = "NotificacaoService")
	private INotificacaoService notificacaoService;

	@InjectEJB(ejbName = "OperacaoUsuarioService")
	private IOperacaoUsuarioService operacaoUsuarioService;

	@Context
	private HttpServletRequest rawRequest;

	private HttpServletRequest getRawRequest() {
		return this.rawRequest;
	}

	protected String getAndDecryptFromAuthCookie(String key) {
		Cookie authCookie = getAuthCookie();

		if (authCookie == null) {
			throw new ExpirationAccessException("User data is partial or incorrect!");
		}

		Map<String, String> values = CookieManager.getMapFromCookie(authCookie, Boolean.TRUE);
		Base64Cryptographer b64 = new Base64Cryptographer();
		CryptographyEngine base64Eng = CryptographyEngine.getInstance(b64, b64);
		return base64Eng.decrypt(values.get(key));
	}

	private Cookie getAuthCookie() {
		Cookie[] cookies = getRawRequest().getCookies();
		if (cookies != null) {
			for (Cookie c : cookies) {
				if ("callink_sso_client".equals(c.getName())) {
					return c;
				}
			}
		}
		return null;
	}

	@Path("/loggeduser")
	@GET
	@RolesAllowed({ "BUSCAR_USUARIO_LOGADO" })
	public UsuarioLogadoDTO getLoggedUser() throws ServiceException, ValidationException {
		String userToken = getAndDecryptFromAuthCookie(AuthConstants.HOST_ID_KEY);
		String sessionToken = getAndDecryptFromAuthCookie(AuthConstants.SESSION_ID_KEY);
		String login = authenticationService.session(sessionToken, userToken).getLogin();

		if (!StringUtils.isEmpty(login)) {
			Usuario user = usuarioService.findByLogin(login);

			if (user == null) {
				fail("Usuário não encontrado! É necessário configurar o usuário no CAD!", "MSG_user_not_found");
			}
			UsuarioLogadoDTO to = new UsuarioLogadoDTO();
			to.setIdUsuario(user.getIdUsuario());
			to.setLogin(login);
			to.setNome(user.getNome());
			Operacao oper = operacaoUsuarioService.buscaOperacaoPrincipalPorUsuario(user.getIdUsuario());
			if (oper != null) {
				to.setIdOperacaoPrincipal(oper.getIdOperacao());
			}

			if (user != null) {
				return to;
			}
		}
		return null;
	}

	@Path("/keepuserlogged/{idUser}/processnotificactions")
	@PUT
	@RolesAllowed({ "BUSCAR_USUARIO_LOGADO" })
	public NotificacoesTO mantemUsuarioLogadoProcessaNotificacoes(Usuario user) throws Exception {

		if (user == null || user.getIdUsuario() == null) {
			fail("O Usuario precisa ser informado.", "MSG_user_null");
		}
		verifyRequestUser(getRawRequest(), user.getIdUsuario());
		
		ServiceResponse serviceResponse = notificacaoService.mantemUsuariologadoProcessaNotificacoes(user.getIdUsuario());
		NotificacoesTO notificacoesTO = null;
		if (serviceResponse != null) {
			notificacoesTO = (NotificacoesTO) serviceResponse.getData();
		}

		return notificacoesTO;

	}

	@SuppressWarnings("unchecked")
	@Path("/operation/{idOperation}")
	@GET
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	public List<UsuarioTO> getUserByOperation(@PathParam(value = "idOperation") Integer idOperation) throws ServiceException, ValidationException {
		return (List<UsuarioTO>) usuarioService.buscaPorOperacaoId(idOperation).getData();
	}
}
