package br.com.callink.cad.rest.api;

import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import br.com.callink.cad.dto.ResultTO;

/**
 * 
 * @author michael_rocha
 * 
 */
@Path("/version")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@PermitAll
public class VersionResource extends GenericResource {

	@Path("/{token}")
	@GET
	@RolesAllowed({"BUSCAR_VERSAO_VIA_TOKEN"})
	public int get(@PathParam(value = "token") int token) {
		return token;
	}
	
	@Path("/systemversion")
	@GET
	@RolesAllowed({ "BUSCAR_INFORMACOES_CASO" })
	public ResultTO<String> getSystemVersion() throws Exception {
		ResultTO<String> to = new ResultTO<String>();
		to.setValor(getMessage("LBL_version"));
		return to;
	}
	
}
