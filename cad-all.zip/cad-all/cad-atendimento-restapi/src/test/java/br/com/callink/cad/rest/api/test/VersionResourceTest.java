package br.com.callink.cad.rest.api.test;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import br.com.callink.generic.test.SSOTestSupport;



/**
 * 
 * @author michael_rocha
 *
 */
public class VersionResourceTest extends SSOTestSupport {
	
	
	@Before
	public void init(){
		super.login();
	}
	

	@Test
	public void testVersionToken() {
		/*
		 * request
		 */
		Integer token = 25;
		Integer returnedToken = get("/version/" + token, Integer.class);
		
		/*
		 * asserts
		 */
		Assert.assertNotNull(returnedToken);
		Assert.assertEquals(token, returnedToken);
	}
	

	@After
	public void cleanup(){
		super.logout();
	}
}