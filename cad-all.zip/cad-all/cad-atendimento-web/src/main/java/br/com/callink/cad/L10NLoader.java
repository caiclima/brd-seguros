package br.com.callink.cad;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 
 * @author michael_rocha
 * 
 */
public class L10NLoader extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String[] files;

	@Override
	public void init(ServletConfig config) throws ServletException {
		String bundlePrefixNames = config.getInitParameter("bundlePrefixNames");
		if (bundlePrefixNames != null) {
			this.files = bundlePrefixNames.split(",");
		}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String lang = request.getParameter("lang");

		if (lang != null) {
			response.setContentType("application/json");

			/*
			 * generate bundle from files
			 */
			StringBuffer dictionary = new StringBuffer(" { \"bundle\": { ");

			if (this.files != null) {
				for (int i = 0; i < this.files.length; i++) {
					String resource = String.format("%s%s.json", this.files[i], lang);
					InputStream in = Thread.currentThread().getContextClassLoader().getResourceAsStream(resource.trim());
					if (in != null) {
						dictionary.append(readFrom(in));
						dictionary.append(i == this.files.length - 1 ? "" : ",");
					}
				}
			}
			dictionary.append(" }} ");
			ServletOutputStream out = response.getOutputStream();
			writeTo(dictionary.toString().getBytes(), out);
			out.close();
		}
	}

	private String readFrom(InputStream is) throws IOException {
		BufferedReader br = null;
		StringBuilder sb = new StringBuilder();

		String line;
		try {

			br = new BufferedReader(new InputStreamReader(is));
			while ((line = br.readLine()) != null) {
				sb.append(line);
			}

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		return sb.toString();
	}

	private void writeTo(byte[] bytes, OutputStream out) throws IOException {
		out.write(bytes);
	}
}