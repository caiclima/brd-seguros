({
    baseUrl: ".",
    name: "main",
    out: "main/js/app.final.js",
    mainConfigFile: "main.js",
    fileExclusionRegExp: /^(r|build)\.js$/,
    preserveLicenseComments: false,
    logLevel: 0,
    include: "requirejs",
    optimize: "none",

    paths: {
        requirejs: "lib/require",
        jquery: "lib/jquery-1.11.0",
        angular: "lib/angular",
        ngRoute : 'lib/angular-route',
        bootstrap : "lib/bootstrap",

        /** by module **/
        /** UserModule **/
        UserModule: "modules/user/user.module",
        UserController: "modules/user/controllers/user.controller",
        

        /** LogModule **/
        LogService: "modules/log/services/log.service",
        LogModule: "modules/log/log.module"
        
    },

    shim: {
        'angular': {
            deps: ['jquery'],
            exports: 'angular'
        },
        'ngRoute': {
            deps: ['jquery','angular']
        }
    }
  })