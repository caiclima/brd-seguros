/*
 * module definitions 
 */

define(['angular', 'ActionButtonsDirective' ], 

	function(angular, ActionButtonsDirective){
		var _m = angular.module('ActionButtonsModule', ['UtilsModule']);
		_m.directive('actionButtons',ActionButtonsDirective );
		return _m;
});