    define( [ ], function()
    {            
        return ['$location', '$caseCheckerUtilsService', '$eventNamingUtilsService',
                    function($location, $caseCheckerUtils, $eventNaming){
          return {
            restrict: 'A',
            replace: true,
            templateUrl: 'app/scripts/modules/action_buttons/directives/templates/action.buttons.html',
            link: function(scope, element, attrs) {
                scope.pathTo = function(path) {
                    $location.path( path );
                };

                scope.noCase = false;
                scope.$on($eventNaming.NamespaceCaseChanged, function(event, Case) {
                    scope.noCase = $caseCheckerUtils.fakeCase(Case);
                });
            }
        };
    }];
});