define(['angular', 'ActionsComboDirective' ],

    function(angular, ActionsComboDirective){
        var _m = angular.module('ActionsComboModule', ['UiModule', 'UtilsModule']);
        _m.directive('actionsCombo', ActionsComboDirective );
        return _m;
});