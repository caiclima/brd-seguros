define( [ ], function()
{            
    return [
        '$location',
        '$dictionaryUtilsService', 
        '$stringUtilsService', 
        '$caseCheckerUtilsService', 
        '$eventNamingUtilsService',
        function($location, $dicUtils, $stringUtils, $caseCheckerUtils, $eventNaming){
         return {
            require: 'groupedCombo',
            link: function(scope, element, attrs, GroupedComboController) {

                scope.$on($eventNaming.NamespaceCaseChanged, function(event, Case) {
                    var enabled;
                    if(enabled = $caseCheckerUtils.realCase(Case)) {
                        var actionsGroupArray = Case[$dicUtils._TOCasesActionsList];
                        var comboActionsArray = [];

                        if(actionsGroupArray){
                            for (var i = 0; i < actionsGroupArray.length; ++i) {
                                var actionsGroup = actionsGroupArray[i];
                                var optGrp = {};
                                optGrp[$dicUtils._commandEn] = actionsGroup[$dicUtils._actionType];
                                optGrp[$dicUtils._actionsEn] = [];

                                for(var j = 0; j < actionsGroup[$dicUtils._actions].length; ++j) {
                                    var action = actionsGroup[$dicUtils._actions][j];

                                    var actionUri = $stringUtils.concatenate(
                                        action[$dicUtils._actionUri],
                                        '/',
                                        action[$dicUtils._actionId]);
                                    var opt = {};
                                    opt[$dicUtils._valueEn] = actionUri;
                                    opt[$dicUtils._nameEn] = action[$dicUtils._actionName];

                                    optGrp.actions.push(opt);
                                }
                                comboActionsArray.push(optGrp);
                            }
                        }
                        GroupedComboController.fillCombo(comboActionsArray);
                    }
                    GroupedComboController.toggleCombo(!enabled);
                });

                GroupedComboController.changeEvent(function(value) {
                    $location.path(value);
                });
            }            
        };
    }];
});