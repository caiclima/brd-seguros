/*
 * module definitions 
 */

define(['angular', 'ActionsMenuDirective' ], 

	function(angular, ActionsMenuDirective){
		var _m = angular.module('ActionsMenuModule', []);
		_m.directive('actionsMenu',ActionsMenuDirective );
		return _m;
});