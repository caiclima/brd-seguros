    define( [ ], function()
    {            
        return function(){        	
        	 return {
                restrict: 'A',
                transclude: true,
                replace: true,
                scope: true,
                templateUrl: 'app/scripts/modules/actions_menu/directives/templates/actions.menu.html',
                link: function(scope, element, attrs) {
                   
                }
                //templateUrl: 'template.html',
                
            };
        };

    });