/*
 * module definitions 
 */

define(['angular', 'BaselineTranslateLoaderService', 'BaselineTranslateLoaderFilter' ],
	function(angular, BaselineTranslateLoaderService, BaselineTranslateLoaderFilter){
		var _m = angular.module('BaselineTranslateLoaderModule', ['pascalprecht.translate']);
        _m.factory('$baselineTranslateLoaderService', BaselineTranslateLoaderService);
        _m.filter('translateNamespace', BaselineTranslateLoaderFilter);
		return _m;
});