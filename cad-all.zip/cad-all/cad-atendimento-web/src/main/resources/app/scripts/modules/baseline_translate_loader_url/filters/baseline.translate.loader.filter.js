define([], function() {
  return ['$baselineTranslateLoaderService', '$rootScope', function($baselineTranslateLoaderService, $rootScope) {
    return function(input, param) {
    	try{
	      var out = null;
	      var namespace = $rootScope.Namespace[param];
	
	      if(input != null && $baselineTranslateLoaderService.get() != null){
	    	  var d = $baselineTranslateLoaderService.get();
	    	  var properties = '';
	
	    	  $.each(input.split("."), function(index, value) {
	    	  	properties += "['" + value + "']";
	    	  });

              if(eval("d[namespace]") !== undefined){
                  return eval("d[namespace]" + properties);
              }
	      }
	      return out;
    	}catch(e){
    		return null;
    	}
    };
  }];
});