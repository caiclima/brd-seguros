define([], function() {
	var baselineTranslateLoaderService = function($rootScope, $resource, $requestUtils) {
		var f = {};
		
		f.data = {};
		
		f.get = function(){
			return f.data;
		};
		
		f.fullfill = function(userId){
			/*
			 * any additional dictionary data goes here
			 */
			var uri = '/api/baseline/resources/' + userId;
			var api = $resource($requestUtils.contextPath() + uri);
			
			api.query({}, function(namespaceBaselineData){
				if(namespaceBaselineData != null && namespaceBaselineData != undefined){
					for(i = 0; i < namespaceBaselineData.length; i++){
						o = namespaceBaselineData[i];
						
						if(f['data'][o.namespace] === undefined){
							f['data'][o.namespace] = {};
						}
						
						if(f['data'][o.namespace]['bundle'] === undefined){
							f['data'][o.namespace]['bundle'] = {};
						}
						
						if(f['data'][o.namespace]['bundle']['cad'] === undefined){
							f['data'][o.namespace]['bundle']['cad'] = {};
						}
					
						f['data'][o.namespace]['bundle']['cad'][o.key] = o.value;
					}
				}
				
			}, function(){
				// ignore
			});
		};
		
		return f;
	};

	return [ "$rootScope", "$resource", "$requestUtilsService", baselineTranslateLoaderService ];
});