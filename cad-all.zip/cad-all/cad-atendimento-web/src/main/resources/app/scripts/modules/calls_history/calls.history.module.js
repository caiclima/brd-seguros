/*
 * module definitions 
 */

define(['angular', 'CallsHistoryController', 'CallsHistoryRestService','CallsHistoryDirective' ],
	function(angular, CallsHistoryController,CallsHistoryRestService ,CallsHistoryDirective){
		var _m = angular.module('CallsHistoryModule', ['ngResource','UtilsModule','pascalprecht.translate','ngCookies', 'UiModule']);

        _m.directive('callsHistory', CallsHistoryDirective );
        _m.factory('$callsHistoryRestService', CallsHistoryRestService);
        _m.controller('CallsHistoryController', CallsHistoryController);

		return _m;
});