    define([], function() {

        var CallsHistoryController = function($scope, $rootScope, $callsHistoryRestService, $dic, $alert) {
            $scope.prettyHistory = [];
            $scope.maxResults = 100;
            
            $scope.sortById = function (a, b){
                return ((a.extraInfo.logId < b.extraInfo.logId) ? -1 : ((a.extraInfo.logId > b.extraInfo.logId) ? 1 : 0));
            }
            
            $scope.appendGeneralLogs = function() {
            	$scope.queryCallsHistory(true);   
            }
            
            $scope.queryCallsHistory = function(append){
                var urlParams = {};
                urlParams.caseId   = $rootScope.Namespace.Case.Current[$dic._caseId];
                urlParams.maxResults = $scope.maxResults;

				if ($scope.prettyHistory && $scope.prettyHistory.length) {
					var list = angular.copy($scope.prettyHistory);
					list.sort($scope.sortById);
					urlParams.lastId = list[0].extraInfo.logId;

				} else {
					urlParams.lastId = 0;
				}
               
                $callsHistoryRestService.query(urlParams,
                    function(history) {
                		_logs = [];
                        if(history){
                            for (var i = 0; i < history.length; ++i) {
                                var item  = history[i];
                                var prettyEntry = {};
                                prettyEntry["callID"]       = item[$dic._callID];
                                prettyEntry["loginUser"]    = item[$dic._loginUser];
                                prettyEntry["clientPhone"]  = item[$dic._clientPhone];
                                prettyEntry["channelInput"] = item[$dic._channelInput];
                                prettyEntry["branch"]       = item[$dic._branch];
                                prettyEntry["startDate"]    = item[$dic._startDate];
                                prettyEntry["endDate"]      = item[$dic._endDate];
								prettyEntry.extraInfo = {
									logId : item[$dic._logId]
								};

                                _logs.push(prettyEntry);
                            }
                        }
                        
                        if(append)
                            $.merge($scope.prettyHistory, _logs);
                        else 
                            $scope.prettyHistory = _logs;
                    },
                    function(error){
                        $alert.error(error.data.error);                       
                    });
            }
            $scope.queryCallsHistory(false);
        };

        return ["$scope", "$rootScope", "$callsHistoryRestService", "$dictionaryUtilsService","$alertUiService", CallsHistoryController];

    });