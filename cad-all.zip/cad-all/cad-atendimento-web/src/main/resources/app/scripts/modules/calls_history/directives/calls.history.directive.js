define([], function() 
{
    return ['$filter', function($filter) {
            return {
                restrict: 'A',
                templateUrl: 'app/scripts/modules/calls_history/directives/templates/calls.history.html',
                link: function(scope, element, attrs) {


                    scope.tableConfig = [{
                        title: $filter('translate')('bundle.cad.CALL_ID'),
                        breakWord: false
                    }, {
                        title: $filter('translate')('bundle.cad.USER_LOGIN'),
                        type: 'icon-text',
                        icon: "icon-user"
                    }, {
                        title: $filter('translate')('bundle.cad.CLIENT_PHONE'),
                        type: 'icon-text',
                        icon: "icon-earphone",
                        breakWord: false
                    }, {
                        title: $filter('translate')('bundle.cad.CHANNEL_INPUT')
                    }, {
                        title: $filter('translate')('bundle.cad.BRANCH')
                    }, {
                        title: $filter('translate')('bundle.cad.START_DATE'),
                        type: 'icon-text',
                        icon: "icon-calendar",
                        date: true,
                        breakWord: false
                    }, {
                        title: $filter('translate')('bundle.cad.END_DATE'),
                        type: 'icon-text',
                        icon: "icon-calendar",
                        date: true,
                        breakWord: false
                    }
                    ,{
                        type: 'hidden',
                    }];
                }
            };
        }
    ];
});