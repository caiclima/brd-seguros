define( [ ], function()
{
    var CallsHistoryRestService = function($resource, $stringUtils, $requestUtils, $dictionaryUtils)
    {
    	var caseId = 'caseId';
		var lastId = 'lastId';
		var maxResults = 'maxResults';

        var uri = $stringUtils.format('/api/callslog/cases/:{0}/:{1}/:{2} ', caseId, lastId, maxResults);

        var paramDefaults = {};
		paramDefaults.caseId = $stringUtils.format('@{0}', caseId);
		paramDefaults.lastId = $stringUtils.format('@{0}', lastId);
		paramDefaults.maxResults = $stringUtils.format('@{0}', maxResults);
		
        return $resource($requestUtils.contextPath() + uri, paramDefaults);
    };

    return [
        "$resource",
        "$stringUtilsService",
        "$requestUtilsService",
        "$dictionaryUtilsService",
        CallsHistoryRestService
    ];
});