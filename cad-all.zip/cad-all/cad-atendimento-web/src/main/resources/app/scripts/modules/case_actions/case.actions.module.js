define([
    'angular',
    'CaseNoteDirective',
    'CaseExternalPendencyDirective',
    'CaseEndDirective',
    'CaseActionsEndController',
    'CaseActionsExternalPendencyController',
    'CaseActionsNoteController',
    'CaseActionsRestService',
    'CaseActionsDataRestService',
    'CaseClassificationDirective',
    'CaseActionsClassificationController',
    'CaseActionsCommonsService',
    'CaseEmailSendingDirective', 
    'CaseEmailAddressSendingDirective',
    'CaseActionsEmailSendingController',
    'CaseActionsEmailTemplateSendingController',
    'CaseChecklistDirective',
    'CaseActionsChecklistController',
    'CaseActionsChecklistService',
    'CaseQuestionnaireDirective',
    'CaseEditDirective',
    'CaseActionsQuestionnaireController',
    'CaseActionsEditController',
    'CaseActionsEditService',
    'CaseActionsQuestionnaireService',
    'CasePhoneCallDirective',
    'CasePhoneCallController',
    'CaseActionsPhoneService',
    'CaseCommonsPhoneCallService',
    'CaseEditPhoneDirective',
    'CaseActionsEditPhoneController',
    'CaseCommonsEditPhoneService',
    'CaseEmailTemplateSending'],
    

	function(angular, 
           CaseNoteDirective,
           CaseExternalPendencyDirective,
           CaseEndDirective,
           CaseActionsEndController,
           CaseActionsExternalPendencyController,
           CaseActionsNoteController,
           CaseActionsRestService,
           CaseActionsDataRestService,
           CaseClassificationDirective,
           CaseActionsClassificationController,
           CaseActionsCommonsService,
           CaseEmailSendingDirective,
           CaseEmailAddressSendingDirective,
           CaseActionsEmailSendingController,
           CaseActionsEmailTemplateSendingController,
           CaseChecklistDirective,
           CaseActionsChecklistController,
           CaseActionsChecklistService,
           CaseQuestionnaireDirective,
           CaseEditDirective,
           CaseActionsQuestionnaireController,
           CaseActionsEditController,
           CaseActionsEditService,
           CaseActionsQuestionnaireService,
           CasePhoneCallDirective,
           CasePhoneCallController,
           CaseActionsPhoneService,
           CaseCommonsPhoneCallService,
           CaseEditPhoneDirective,
           CaseActionsEditPhoneController,
           CaseCommonsEditPhoneService,
           CaseEmailTemplateSending){

		var _m = angular.module('CaseActionsModule', [
                                                        'ngResource', 
                                                        'pascalprecht.translate',
                                                        'ngCookies', 
                                                        'SimpleFileUploadModule',
                                                        'UtilsModule',
                                                        'UiModule',
                                                        'CaseEventsModule',
                                                        'DynamicFieldsModule'
                                                    ]);

	_m.directive('caseNote',CaseNoteDirective );
	_m.directive('caseExternalPendency',CaseExternalPendencyDirective );
	_m.directive('caseEnd',CaseEndDirective );
    _m.directive('caseClassification', CaseClassificationDirective);
    _m.directive('caseEmailSending', CaseEmailSendingDirective);
    _m.directive('caseEmailAddressSending', CaseEmailAddressSendingDirective);
    _m.directive('caseChecklist', CaseChecklistDirective);
    _m.directive('caseQuestionnaire', CaseQuestionnaireDirective);
    _m.directive('caseEdit', CaseEditDirective);
    _m.directive('casePhoneCall', CasePhoneCallDirective);
    _m.directive('caseEditPhone', CaseEditPhoneDirective);
    _m.directive('caseEmailTemplateSending', CaseEmailTemplateSending);

	_m.controller('CaseActionsEndController', CaseActionsEndController);
    _m.controller('CaseActionsExternalPendencyController', CaseActionsExternalPendencyController);
    _m.controller('CaseActionsNoteController', CaseActionsNoteController);   
    _m.controller('CaseActionsClassificationController',CaseActionsClassificationController);
    _m.controller('CaseActionsEmailSendingController', CaseActionsEmailSendingController);
    _m.controller('CaseActionsEmailTemplateSendingController', CaseActionsEmailTemplateSendingController);
    _m.controller('CaseActionsChecklistController', CaseActionsChecklistController);
    _m.controller('CaseActionsQuestionnaireController', CaseActionsQuestionnaireController);  
    _m.controller('CaseActionsEditController', CaseActionsEditController);        
    _m.controller('CasePhoneCallController', CasePhoneCallController);
    _m.controller('CaseActionsEditPhoneController', CaseActionsEditPhoneController);    
    
    _m.factory('$caseActionsRestService', CaseActionsRestService);
    _m.factory('$caseActionsDataRestService', CaseActionsDataRestService);
    _m.factory('$caseActionsCommonsService', CaseActionsCommonsService);
    _m.factory('$caseActionsChecklistService', CaseActionsChecklistService);
    _m.factory('$caseActionsQuestionnaireService', CaseActionsQuestionnaireService);
    _m.factory('$caseActionsEditService', CaseActionsEditService);
    _m.factory('$casePhoneService', CaseActionsPhoneService);
    _m.factory('$caseCommonsPhoneCallService', CaseCommonsPhoneCallService);
    _m.factory('$caseCommonsEditPhoneService', CaseCommonsEditPhoneService);
    		
	return _m;
});