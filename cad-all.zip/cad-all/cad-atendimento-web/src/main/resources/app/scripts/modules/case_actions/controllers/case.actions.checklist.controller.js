define([], function() {
    var CaseActionsChecklistController = function($rootScope, $scope, $routeParams, $caseActionsRestService, $caseActionsDataRestService, $caseActionsChecklistService, $dictionaryUtils, $genericUtils, $alertUiService) {
        var caseId   = $rootScope.Namespace.Case.Current[$dictionaryUtils._caseId];
        var userId   = $rootScope.Namespace.User[$dictionaryUtils._userId];
        var actionId = $routeParams.actionId;

        $scope.checkListSaved = false;
        $scope.checking = undefined;

        $caseActionsDataRestService.fetchCheckList(
            actionId, caseId, userId,
            function(checklist) {
                var hasChecklist = $genericUtils.isNull(checklist[$dictionaryUtils._checkListId]);
                if(!hasChecklist) {
                    $scope.checklist = $caseActionsChecklistService.format(checklist[$dictionaryUtils._checkListQuestions]);                                
                    $scope.checklistName = checklist[$dictionaryUtils._description];
                    $scope.checklistId = checklist[$dictionaryUtils._checkListId];
                }
            },
            function(msg) {
                $alertUiService.error(msg.data ? msg.data.error : msg.error);;
            }
        );

        $scope.save = function() {
            $scope.checking = true;

            var payload = {};
            payload[$dictionaryUtils._caseId]             = caseId;
            payload[$dictionaryUtils._userId]             = userId;
            payload[$dictionaryUtils._actionId]           = actionId;
            payload[$dictionaryUtils._checkListId]        = $scope.checklistId;
            payload[$dictionaryUtils._checkListQuestions] = [];

            if($scope.checklist){
                for(var it = 0; it < $scope.checklist.length; ++it) {
                    var check = $scope.checklist[it];

                    if(!check.disabled) {
                        var sendingCheck = {};
                        sendingCheck[$dictionaryUtils._checkId]     = check.checkId;
                        sendingCheck[$dictionaryUtils._checkListId] = $scope.checklistId;
                        sendingCheck[$dictionaryUtils._answer]      = check.selectedAnswer;

                        payload[$dictionaryUtils._checkListQuestions].push(sendingCheck);
                    }
                }
            }

            $caseActionsRestService.saveChecklist(
                payload,
                function() {
                    $scope.checkListSaved = true;
                }, 
                function(msg) {
                    $alertUiService.error(msg.data ? msg.data.error : msg.error);
                    $scope.checking = false;
                });
        };
    };

    return ['$rootScope','$scope','$routeParams','$caseActionsRestService','$caseActionsDataRestService','$caseActionsChecklistService','$dictionaryUtilsService','$genericUtilsService','$alertUiService', CaseActionsChecklistController];
});