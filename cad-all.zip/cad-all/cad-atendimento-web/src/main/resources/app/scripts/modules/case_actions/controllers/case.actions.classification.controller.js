/*
*   resource declaration
*/
define([], function() {

    /*
    *   controller function declaration
    */
    var CaseActionsClassificationController = function( $rootScope,
                                                        $scope,
                                                        $routeParams,
                                                        $actionsRestService,
                                                        $dataRestService,
                                                        $actionsCommonsService,
                                                        $dictionaryUtils, 
                                                        $genericUtils, 
                                                        $comboFormatter,
                                                        $alert ) {
        /*
        *  Declare functions and variables
        */
        declareScopedVariables();
        declareScopedFunctions();
        /*
        *  Load page Data and Init its Elements
        */
        void function loadPageData() {
            /*
            *  Get namespace Object
            */
            var namespace = $rootScope.Namespace;
            /*
            *  Get current Case ID and User ID from Namespace
            */
            $scope.operationId = namespace.Case.Current[$dictionaryUtils._operationId];
            $scope.caseId = namespace.Case.Current[$dictionaryUtils._caseId];
            $scope.userId = namespace.User[$dictionaryUtils._userId];
            $scope.actionId = $routeParams.actionId;
            $scope.hasAttachmentPrivilegeActions = namespace.Case.Current[$dictionaryUtils._hasAttachmentPrivilegeActions];
            
            var urlParams = {};
            urlParams[$dictionaryUtils._actionId] = $scope.actionId;
            
            $scope.allowsAttachment = false;
            $actionsRestService.allowsAttachment(urlParams,
                    function(confirm){
            			$scope.allowsAttachment = confirm[$dictionaryUtils._value];
                    },
                    function(msg){
                    	$alert.error(msg.data ? msg.data.error : msg.error);
                    });
            
            /*
            *  Request initial Data
            */
            $dataRestService.dataToClassify(
                $scope.caseId,
                function(dataToClassify) {
                    $scope.caseTypesList = $comboFormatter.format(
                        dataToClassify[$dictionaryUtils._caseTypes],
                        $dictionaryUtils._caseTypeId,
                        $dictionaryUtils._name);

                    $scope.requirePasswordMaster = dataToClassify[$dictionaryUtils._requirePassword];
                },
                function(msg) {
                    $alert.error(msg.data ? msg.data.error : msg.error);
                }
            );

            $dataRestService.fetchObservationTemplate(
                $scope.caseId,
                function(templates) {
                    var list = [];
                    if(templates){
                        for(var it = 0; it < templates.length; ++it) {
                            var template = templates[it];
                            list.push({
                                id: template[$dictionaryUtils._observationTemplateId],
                                text: template[$dictionaryUtils._name],
                                content: template[$dictionaryUtils._observationTemplateContent]
                            });
                        }
                    }
                    $scope.action.templates = list;
                },
                function(msg) {
                    $alert.error(msg.data ? msg.data.error : msg.error);;
                }
            );

        }();

        function declareScopedFunctions() {
            /*
            *  This function will be called when user clicks Save Button
            */
            $scope.save = function(){
                var saveActionLogic = function(stateControl) {
                    $scope.action.classifying = true;

                    var payload = {};
                    payload[$dictionaryUtils._caseId]      = $scope.caseId;
                    payload[$dictionaryUtils._userId]      = $scope.userId;
                    payload[$dictionaryUtils._actionId]    = $scope.actionId;
                    payload[$dictionaryUtils._eventId]     = $scope.action.eventId;
                    payload[$dictionaryUtils._caseTypeId]  = $scope.action.caseTypeId;
                    payload[$dictionaryUtils._observation] = $scope.action.observation;

                    if($scope.action.loginMaster){
                    	payload[$dictionaryUtils._loginMaster] = $scope.action.loginMaster;
                    }
                    if($scope.action.passwordMaster){
                    	payload[$dictionaryUtils._passwordMaster] = $scope.action.passwordMaster;
                    }

                    $actionsRestService.categorizeCase(
                        payload,
                        function(ok) {
                            stateControl.success();
                        },
                        function(msg){
                            stateControl.failure(msg);
                            $scope.action.classifying = false;
                        });
                };

                var nextCaseLogic = function(newCase) {
                    var namespace = $rootScope.Namespace;
                    namespace.Case.ChangeCase(newCase);
                };

                $actionsCommonsService.saveAndRedirect(saveActionLogic, nextCaseLogic, $scope.userId);
            }
        }
        /*
        *
        */
        function declareScopedVariables() {
        	 /*
             *  Get namespace Object
             */
            var namespace = $rootScope.Namespace;

            $scope.remainingSelection = undefined;
            $scope.action = {
                classifying: undefined,
                observation: "",
                caseTypeId: namespace.Case.Current[$dictionaryUtils._caseTypeId],
                eventId: namespace.Case.Current[$dictionaryUtils._eventId],
                loginMaster: undefined,
                passwordMaster: undefined,
                templates: [],
                templateSelected: function(templateId) {
                    if(templateId != undefined){
                        $dataRestService.applyObservationTemplate(
                            templateId,
                            $scope.caseId,
                            function(val){
                                if(val){
                                    $scope.action.observation = val[$dictionaryUtils._value];
                                }
                            },
                            function(msg){
                                $alert.error(msg.data ? msg.data.error : msg.error);
                            }
                        );
                    }
                }
            };
        }
    };
    return [
        '$rootScope',
        '$scope',
        '$routeParams',
        '$caseActionsRestService',
        '$caseActionsDataRestService',
        '$caseActionsCommonsService',
        '$dictionaryUtilsService',
        '$genericUtilsService',
        '$comboPrettyFormatUtilsService',
        '$alertUiService',
        CaseActionsClassificationController];
});