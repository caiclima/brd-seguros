define([], function() {

    var CaseEditController = function ($rootScope,
                                       $scope,
                                       $routeParams,
                                       $dictionaryUtils,
                                       $comboFormatterUtils,
                                       $genericUtils,
                                       $restService,
                                       $actionsCommonsService,
                                       $alert,
                                       $treeviewService,
                                       $dynamicFieldsService,
                                       $caseActionsRestService,
                                       $dataRestService) {
		/*
		*	init variables
		*/
		var actionId = $routeParams.actionId;
		var caseId = $rootScope.Namespace.Case.Current[$dictionaryUtils._caseId];
        var userId = $rootScope.Namespace.User[$dictionaryUtils._userId];

        $scope._case = {
        	operationid: $rootScope.Namespace.Case.Current[$dictionaryUtils._operationId],
        	caseId: caseId
        };
        $scope.observation = {
        	text: ''
        };
		$scope.userSuggestedList = [];
		$scope.caseTypeList   	 = [];
		$scope.channelList 		 = [];
		$scope.eventList 		 = [];
		$scope.otherAreaList 	 = [];
		$scope.junctionList 	 = [];
		$scope.causeList 		 = [];
		$scope.dynamicFieldList  = [];
		$scope.statusList        = [];
        $scope.queueConfigList   = [];
        $scope.nomeLayout = [];
        $scope.editing = undefined;

        $scope.templates = [];
		$scope.templateSelected = function(templateId) {
			if(templateId != undefined){
				$dataRestService.applyObservationTemplate(
					templateId,
					$scope._case.caseId,
					function(val){
						if(val){
							$scope.observation.text = val[$dictionaryUtils._value];
						}
					},
					function(msg){
						$alert.error(msg.data ? msg.data.error : msg.error);
					}
				);
			}
		};
        
        $scope.hasAttachmentPrivilegeActions = $rootScope.Namespace.Case.Current[$dictionaryUtils._hasAttachmentPrivilegeActions];
        
        var urlParams = {};
        urlParams[$dictionaryUtils._actionId] = actionId;
        
        $scope.allowsAttachment = false;
        $caseActionsRestService.allowsAttachment(urlParams,
                function(confirm){
        			$scope.allowsAttachment = confirm[$dictionaryUtils._value];
                },
                function(msg){
                	$alert.error(msg.data ? msg.data.error : msg.error);
                });

		//automaticaly load field list
		var getFieldsAngSuggestions = function() {
			
			$restService.fieldsAngSuggestions(
				actionId, caseId, 
				function(fields) {
					if(! fields){
						return;
					}
					$scope.nomeLayout = fields[$dictionaryUtils._nameLayout];
					$scope.dynamicFieldList = $dynamicFieldsService.formatDynamicField(fields[$dictionaryUtils._dynamicFieldList], $rootScope.Namespace.Case.Current);
					$scope.junctionList = $comboFormatterUtils.format(fields[$dictionaryUtils._junctionList], $dictionaryUtils._junctionId, $dictionaryUtils._name);
					$scope.otherAreaList = $comboFormatterUtils.format(fields[$dictionaryUtils._externalAreaList], $dictionaryUtils._externalAreaId, $dictionaryUtils._name);
					$scope.caseTypeList = $comboFormatterUtils.format(fields[$dictionaryUtils._caseTypeList], $dictionaryUtils._caseTypeId, $dictionaryUtils._name);
					$scope.userSuggestedList = $comboFormatterUtils.format(fields[$dictionaryUtils._userSuggestedList], $dictionaryUtils._userId, $dictionaryUtils._login);
					$scope.channelList = $comboFormatterUtils.format(fields[$dictionaryUtils._channelList], $dictionaryUtils._channelId, $dictionaryUtils._name);
					$scope.causeList = $comboFormatterUtils.format(fields[$dictionaryUtils._reasonList], $dictionaryUtils._reasonId, $dictionaryUtils._name);
					$scope.statusList = $comboFormatterUtils.format(fields[$dictionaryUtils._statusList], $dictionaryUtils._statusId, $dictionaryUtils._name);
                    $scope.queueConfigList = $comboFormatterUtils.format(fields[$dictionaryUtils._queueConfigList], $dictionaryUtils._queueConfigId, $dictionaryUtils._name);
				},
				function(msg) {
					$alert.error(msg.data ? msg.data.error : msg.error);
				}
			);

            $dataRestService.fetchObservationTemplate(
				$scope._case.caseId,
                function(templates) {
                    var list = [];
                    if(templates){
                        for(var it = 0; it < templates.length; ++it) {
                            var template = templates[it];
                            list.push({
                                id: template[$dictionaryUtils._observationTemplateId],
                                text: template[$dictionaryUtils._name],
                                content: template[$dictionaryUtils._observationTemplateContent]
                            });
                        }
                    }
                    $scope.templates = list;
                },
                function(msg) {
                    $alert.error(msg.data ? msg.data.error : msg.error);;
                }
            );
		}();

		$scope.caseEditSave = function() {	
			var saveActionLogic = function(stateControl) {
                $scope.editing = true;

	            var payload = {};
	            payload[$dictionaryUtils._dynamicFieldList] = $dynamicFieldsService.formatFieldsToSend($scope.dynamicFieldList);
	            payload[$dictionaryUtils._caseId] = caseId;
	            payload[$dictionaryUtils._userId] = userId;
	            payload[$dictionaryUtils._actionId] = actionId;
	            payload[$dictionaryUtils._observation] = $scope.observation.text;
				
	            $caseActionsRestService.editCase(
					payload,
					function(ok) {
					   $scope.redirectingSuccess = true;
                       stateControl.success();						
					}, function(msg) {
						$alert.error(msg.data ? msg.data.error : msg.error);
                        $scope.editing = false;
					});
            };

			var nextCaseLogic = function(newCase) {
                var namespace = $rootScope.Namespace;
                namespace.Case.ChangeCase(newCase);
            };
			
            $actionsCommonsService.saveAndRedirect(saveActionLogic, nextCaseLogic, userId);
		}
	};
	return [
		'$rootScope',
		'$scope', 
		'$routeParams',
		'$dictionaryUtilsService', 
		'$comboPrettyFormatUtilsService',
		'$genericUtilsService',
		'$caseActionsEditService',
		'$caseActionsCommonsService',
		'$alertUiService',
		'$caseEventsTreeviewService',
		'$dynamicFieldsService',
		'$caseActionsRestService',
        '$caseActionsDataRestService',
		CaseEditController];
});