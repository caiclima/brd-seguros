define([], function() {

    var CaseActionsEditPhoneController = function ($rootScope,
                                                   $scope,
                                                   $routeParams,
                                                   $dictionaryUtils,
                                                   $restService,
                                                   $caseCommonsEditPhoneService,
                                                   $actionsCommonsService,
                                                   $dataRestService,
                                                   $alert) {
		/*
		*	init variables
		*/
		var actionId  = $routeParams.actionId;
		var caseId    = $rootScope.Namespace.Case.Current[$dictionaryUtils._caseId];
        var userId    = $rootScope.Namespace.User[$dictionaryUtils._userId];
        var userLogin = $rootScope.Namespace.User[$dictionaryUtils._login];

        $scope.phoneList = [];
        $scope.action = {
            editing: undefined,
            observation: undefined,
            loginMaster: undefined,
            passwordMaster: undefined,
            templates: [],
            templateSelected: function(templateId) {
                if(templateId != undefined){
                    $dataRestService.applyObservationTemplate(
                        templateId,
                        caseId,
                        function(val){
                            if(val){
                                $scope.action.observation = val[$dictionaryUtils._value];
                            }
                        },
                        function(msg){
                            $alert.error(msg.data ? msg.data.error : msg.error);
                        }
                    );
                }
            }
        };
        
		//automaticaly load phone list
		var load = function() {
			var urlParams = {};
            urlParams[$dictionaryUtils._caseId] = caseId;
            
            $restService.findContactList(urlParams, function(ret){
            	$scope.phoneList = $restService.toEditFormat(ret);
            	
            }, function(msg){
            	$alert.error(msg.data ? msg.data.error : msg.error);
            });

            $dataRestService.fetchObservationTemplate(
                caseId,
                function(templates) {
                    var list = [];
                    if(templates){
                        for(var it = 0; it < templates.length; ++it) {
                            var template = templates[it];
                            list.push({
                                id: template[$dictionaryUtils._observationTemplateId],
                                text: template[$dictionaryUtils._name],
                                content: template[$dictionaryUtils._observationTemplateContent]
                            });
                        }
                    }
                    $scope.action.templates = list;
                },
                function(msg) {
                    $alert.error(msg.data ? msg.data.error : msg.error);;
                }
            );
		}();

        $scope.editPhones = function(){
            $caseCommonsEditPhoneService.confirmAndEditPhones(caseId, userId, saveActionLogic, nextCaseLogic);
        };

        $scope.approvalAndEditPhones = function() {
            $actionsCommonsService.saveAndRedirect(saveActionLogic, nextCaseLogic, userId);
        };

        var saveActionLogic = function (stateControl) {
            $scope.action.editing = true;

            var payload = {};
            payload[$dictionaryUtils._caseId] = caseId;
            payload[$dictionaryUtils._actionId] = actionId;
            payload[$dictionaryUtils._userId] = userId;
            payload[$dictionaryUtils._observation] = $scope.action.observation;
            payload[$dictionaryUtils._loginMaster]    = $scope.action.loginMaster;
            payload[$dictionaryUtils._passwordMaster] = $scope.action.passwordMaster;
            payload[$dictionaryUtils._phoneList] = $restService.toServerFormat($scope.phoneList, userLogin);

            $restService.updateContactList(
                payload,
                function (ok) {
                    $scope.redirectingSuccess = true;
                    stateControl.success();
                }, function (msg) {
                    $alert.error(msg.data ? msg.data.error : msg.error);
                    $scope.action.editing = false;
                });
        };

        var nextCaseLogic = function(newCase) {
            var namespace = $rootScope.Namespace;
            namespace.Case.ChangeCase(newCase);
        };
	}
	return [
		'$rootScope',
		'$scope', 
		'$routeParams',
		'$dictionaryUtilsService',
		'$casePhoneService',
        '$caseCommonsEditPhoneService',
		'$caseActionsCommonsService',
        '$caseActionsDataRestService',
		'$alertUiService',
		CaseActionsEditPhoneController];
});