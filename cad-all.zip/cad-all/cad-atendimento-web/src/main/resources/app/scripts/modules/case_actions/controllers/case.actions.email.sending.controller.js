define([], function() {

    var CaseActionsEmailSendingController = function($rootScope, $scope, $routeParams, $restService, $dataRestService, $actionsCommonsService, $alertUiService, $dictionaryUtils) {

        var caseId   = $rootScope.Namespace.Case.Current[$dictionaryUtils._caseId];
        var operationId = $rootScope.Namespace.Case.Current[$dictionaryUtils._operationId];
        var userId   = $rootScope.Namespace.User[$dictionaryUtils._userId];
        var actionId = $routeParams.actionId;
        
        $scope.hasAttachmentPrivilegeEmail = $rootScope.Namespace.Case.Current[$dictionaryUtils._hasAttachmentPrivilegeEmail];
        
        var urlParams = {};
        urlParams[$dictionaryUtils._actionId] = actionId;
        
        $scope.allowsAttachment = false;
        $restService.allowsAttachment(urlParams,
                function(confirm){
        			$scope.allowsAttachment = confirm[$dictionaryUtils._value];
                },
                function(msg){
                	$alertUiService.error(msg.data ? msg.data.error : msg.error);
                });

        $scope.emailConfig = {
            content: '',
            subject: '',
            recipientsGroups: [],
            boxEmail: [],
            templates: [],
            selectedRecipientsGroups: [],
            recipients: '',
            carbonCopyRecipients: '',
            templateSelected: function(templateEmailId) {
            	if(templateEmailId != undefined){
            		$dataRestService.applyEmailTemplate(
        				templateEmailId, 
        				caseId, 
        				function(val){
        					if(val){
        						$scope.emailConfig.subject = val[$dictionaryUtils._subject];
                                $scope.emailConfig.content = val[$dictionaryUtils._emailContent];
        					}
        				}, 
        				function(msg){
        					$alertUiService.error(msg.data ? msg.data.error : msg.error);
        				}
            		);
            	}
            }
        };

        $scope.sending = undefined;

        $scope.sendEmail = function() {
            var saveActionLogic = function(stateControl) {
                $scope.sending = true;

                var payload = {};
                payload[$dictionaryUtils._caseId]         = caseId;
                payload[$dictionaryUtils._userId]         = userId;
                payload[$dictionaryUtils._actionId]       = actionId;

                payload[$dictionaryUtils._emailContent] = $scope.emailConfig.content;
                payload[$dictionaryUtils._subject] = $scope.emailConfig.subject;
                
                if($scope.emailConfig.recipients !== undefined && $scope.emailConfig.recipients !== '')
                    payload[$dictionaryUtils._to] = $scope.emailConfig.recipients;
                
                if($scope.emailConfig.carbonCopyRecipients !== undefined && $scope.emailConfig.carbonCopyRecipients !== '')
                    payload[$dictionaryUtils._carbonCopy] = $scope.emailConfig.carbonCopyRecipients;

                var toEmailGroup = [];
                $.each($scope.emailConfig.selectedRecipientsGroups, function(index, value){
                    var emailGroup = {};
                    emailGroup[$dictionaryUtils._emailGroupId] = parseInt(value);
                    toEmailGroup.push(emailGroup);
                });
                payload[$dictionaryUtils._toEmailGroup] = toEmailGroup;

                $restService.sendMail(
                    payload
                    ,function(success) {
                        stateControl.success();
                    }, function(msg){
                        stateControl.failure(msg);
                        $scope.sending = false;
                    });
            };

            var nextCaseLogic = function(newCase) {
                var namespace = $rootScope.Namespace;
                namespace.Case.ChangeCase(newCase);
            };

            $actionsCommonsService.saveAndRedirect(saveActionLogic, nextCaseLogic, userId);
        };
        
        $scope.sendEmailAddress = function() {
            var saveActionLogic = function(stateControl) {
                $scope.sending = true;

                var payload = {};
                payload[$dictionaryUtils._caseId]         = caseId;
                payload[$dictionaryUtils._userId]         = userId;
                payload[$dictionaryUtils._actionId]       = actionId;

                payload[$dictionaryUtils._emailContent] = $scope.emailConfig.content;
                payload[$dictionaryUtils._subject] = $scope.emailConfig.subject;
                payload[$dictionaryUtils._caixaEmail] = $scope.emailConfig.boxEmailId;
                
                if($scope.emailConfig.recipients !== undefined && $scope.emailConfig.recipients !== '')
                    payload[$dictionaryUtils._to] = $scope.emailConfig.recipients;
                
                if($scope.emailConfig.carbonCopyRecipients !== undefined && $scope.emailConfig.carbonCopyRecipients !== '')
                    payload[$dictionaryUtils._carbonCopy] = $scope.emailConfig.carbonCopyRecipients;

                var toEmailGroup = [];
                $.each($scope.emailConfig.selectedRecipientsGroups, function(index, value){
                    var emailGroup = {};
                    emailGroup[$dictionaryUtils._emailGroupId] = parseInt(value);
                    toEmailGroup.push(emailGroup);
                });
                payload[$dictionaryUtils._toEmailGroup] = toEmailGroup;

                $restService.sendMail(
                    payload
                    ,function(success) {
                        stateControl.success();
                    }, function(msg){
                        stateControl.failure(msg);
                        $scope.sending = false;
                    });
            };

            var nextCaseLogic = function(newCase) {
                var namespace = $rootScope.Namespace;
                namespace.Case.ChangeCase(newCase);
            }

            $actionsCommonsService.saveAndRedirect(saveActionLogic, nextCaseLogic, userId);
        }
        
        void function fetchEmailGroups() {
            $dataRestService.fetchEmailGroups(
                caseId,
                function(groups) {
                    var prettyGrps = [];
                    if(groups){
                        for(var it = 0; it < groups.length; ++it) {
                            var group = groups[it];
                            prettyGrps.push({
                                id: group[$dictionaryUtils._emailGroupId],
                                text: group[$dictionaryUtils._description]
                            });
                        }
                    }
                    $scope.emailConfig.recipientsGroups = prettyGrps;
                },
                function(msg) {
                    $alertUiService.error(msg.data ? msg.data.error : msg.error);
                });
        }();
        
        void function fetchEmailBox() {
            $dataRestService.fetchEmailBox(
                operationId,
                function(boxes) {
                    var prettyBoxes = [];
                    if(boxes){
                        for(var it = 0; it < boxes.length; ++it) {
                            var box = boxes[it];
                            prettyBoxes.push({
                            	id: box[$dictionaryUtils._emailBoxId],
                                text: box[$dictionaryUtils._nameConfig]
                            });
                        }
                    }
                    $scope.emailConfig.boxEmail = prettyBoxes;
                },
                function(msg) {
                    $alertUiService.error(msg.data ? msg.data.error : msg.error);;
                });
        }();
        
        void function fetchEmailTemplate() {
            $dataRestService.fetchEmailTemplate(
                caseId,
                function(templates) {
                    var list = [];
                    if(templates){
                        for(var it = 0; it < templates.length; ++it) {
                            var template = templates[it];
                            list.push({
                                id: template[$dictionaryUtils._emailTemplateId],
                                text: template[$dictionaryUtils._name],
                                subject: template[$dictionaryUtils._subject],
                                content: template[$dictionaryUtils._emailTemplateContent]
                            });
                        }
                    }
                    $scope.emailConfig.templates = list;
                },
                function(msg) {
                    $alertUiService.error(msg.data ? msg.data.error : msg.error);;
                });
        }();
    };

    return ['$rootScope', 
            '$scope',
            '$routeParams',
            '$caseActionsRestService',
            '$caseActionsDataRestService',
            '$caseActionsCommonsService',
            '$alertUiService', 
            '$dictionaryUtilsService', 
            CaseActionsEmailSendingController];
});