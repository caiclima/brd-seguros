define([], function() {

    var CaseActionsEndController = function($rootScope,
                                            $scope,
                                            $routeParams,
                                            $restService,
                                            $dataRestService,
                                            $actionsCommonsService,
                                            $dictionaryUtils,
                                            $comboFormatter,
                                            $alert ) {

        var caseId   = $rootScope.Namespace.Case.Current[$dictionaryUtils._caseId];
        var userId   = $rootScope.Namespace.User[$dictionaryUtils._userId];
        var actionId = $routeParams.actionId;

        //initializations
        $scope.action = {
            ending: undefined,
            observation : "",
            templates: [],
            templateSelected: function(templateId) {
                if(templateId != undefined){
                    $dataRestService.applyObservationTemplate(
                        templateId,
                        caseId,
                        function(val){
                            if(val){
                                $scope.action.observation = val[$dictionaryUtils._value];
                            }
                        },
                        function(msg){
                            $alert.error(msg.data ? msg.data.error : msg.error);
                        }
                    );
                }
            }
        };
        
        $scope.hasAttachmentPrivilegeActions = $rootScope.Namespace.Case.Current[$dictionaryUtils._hasAttachmentPrivilegeActions];
        
        var urlParams = {};
        urlParams[$dictionaryUtils._actionId] = actionId;
        
        $scope.allowsAttachment = false;
        $restService.allowsAttachment(urlParams,
                function(confirm){
        			$scope.allowsAttachment = confirm[$dictionaryUtils._value];
                },
                function(msg){
                	$alert.error(msg.data ? msg.data.error : msg.error);
                });

        //the action save function
        $scope.save = function(){
            var saveActionLogic = function(stateControl) {
                $scope.action.ending = true;

                var payload = {};
                payload[$dictionaryUtils._caseId]      = caseId;
                payload[$dictionaryUtils._userId]      = userId;
                payload[$dictionaryUtils._actionId]    = actionId;
                payload[$dictionaryUtils._reasonId]    = $scope.action.reasonId;
                payload[$dictionaryUtils._observation] = $scope.action.observation;
                
                $restService.end(
                    payload
                    ,function(success) {
                        stateControl.success();
                    }, function(msg){
                        stateControl.failure(msg);
                        $scope.action.ending = false;
                    });
            };

            var nextCaseLogic = function(newCase) {
                var namespace = $rootScope.Namespace;
                namespace.Case.ChangeCase(newCase);
            };

            $actionsCommonsService.saveAndRedirect(saveActionLogic, nextCaseLogic, userId);
        };

        $dataRestService.fetchObservationTemplate(
            caseId,
            function(templates) {
                var list = [];
                if(templates){
                    for(var it = 0; it < templates.length; ++it) {
                        var template = templates[it];
                        list.push({
                            id: template[$dictionaryUtils._observationTemplateId],
                            text: template[$dictionaryUtils._name],
                            content: template[$dictionaryUtils._observationTemplateContent]
                        });
                    }
                }
                $scope.action.templates = list;
            },
            function(msg) {
                $alert.error(msg.data ? msg.data.error : msg.error);;
            }
        );

        //load previous data
        $dataRestService.endingReasons(
            caseId, 
            function(data){
                $scope.endingReasons = $comboFormatter.format(data, $dictionaryUtils._reasonId, $dictionaryUtils._name);
            },
            function(msg){
                $alert.error(msg.data ? msg.data.error : msg.error);
            }
        );
    }
    return [
        '$rootScope',
        '$scope',
        '$routeParams',
        '$caseActionsRestService',
        '$caseActionsDataRestService',
        '$caseActionsCommonsService',
        '$dictionaryUtilsService',
        '$comboPrettyFormatUtilsService',
        '$alertUiService',
        CaseActionsEndController];
});