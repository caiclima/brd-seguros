define([], function() {

    var CaseActionsNoteController = function($rootScope,
                                             $scope,
                                             $routeParams,
                                             $restService,
                                             $actionsCommonsService,
                                             $dictionaryUtils,
                                             $genericUtils,
                                             $dataRestService,
                                             $alert){

        var caseId   = $rootScope.Namespace.Case.Current[$dictionaryUtils._caseId];
        var userId   = $rootScope.Namespace.User[$dictionaryUtils._userId];
        var actionId = $routeParams.actionId;

        /*
        *  Initializations
        */
        $scope.action = {
            noting: undefined,
            observation : "",
            templates: [],
            templateSelected: function(templateId) {
                if(templateId != undefined){
                    $dataRestService.applyObservationTemplate(
                        templateId,
                        caseId,
                        function(val){
                            if(val){
                                $scope.action.observation = val[$dictionaryUtils._value];
                            }
                        },
                        function(msg){
                            $alert.error(msg.data ? msg.data.error : msg.error);
                        }
                    );
                }
            }
        };

        $dataRestService.fetchObservationTemplate(
            caseId,
            function(templates) {
                var list = [];
                if(templates){
                    for(var it = 0; it < templates.length; ++it) {
                        var template = templates[it];
                        list.push({
                            id: template[$dictionaryUtils._observationTemplateId],
                            text: template[$dictionaryUtils._name],
                            content: template[$dictionaryUtils._observationTemplateContent]
                        });
                    }
                }
                $scope.action.templates = list;
            },
            function(msg) {
                $alert.error(msg.data ? msg.data.error : msg.error);;
            }
        );

        $scope.hasAttachmentPrivilegeActions = $rootScope.Namespace.Case.Current[$dictionaryUtils._hasAttachmentPrivilegeActions];
        
        var urlParams = {};
        urlParams[$dictionaryUtils._actionId] = actionId;
        
        $scope.allowsAttachment = false;
        $restService.allowsAttachment(urlParams,
                function(confirm){
        			$scope.allowsAttachment = confirm[$dictionaryUtils._value];
                },
                function(msg){
                	$alert.error(msg.data ? msg.data.error : msg.error);
                });

        /*
        *  This function will be called when user clicks Save Button
        */
        $scope.save = function(){
            var saveActionLogic = function(stateControl) {
                $scope.action.noting = true;

                var payload = {};
                payload = {};
                payload[$dictionaryUtils._caseId]      = caseId;
                payload[$dictionaryUtils._userId]      = userId;
                payload[$dictionaryUtils._actionId]    = actionId;
                payload[$dictionaryUtils._observation] = $scope.action.observation;

                var schedulingDate = $scope.action.schedulingDate;
                if(!$genericUtils.isNull(schedulingDate)) {
                    payload[$dictionaryUtils._schedulingDate] = $genericUtils.toServersDateFormat(schedulingDate);
                }

                $restService.note(
                    payload,
                    function(success) {
                        $scope.redirectingSuccess = true;
                        stateControl.success();
                    }, function(msg){
                        stateControl.failure(msg);
                        $scope.action.noting = false;
                    });    
            };

            var nextCaseLogic = function(newCase) {
                var namespace = $rootScope.Namespace;
                namespace.Case.ChangeCase(newCase);
            }

            $actionsCommonsService.saveAndRedirect(saveActionLogic, nextCaseLogic, userId);
        }
    }
    return [
        '$rootScope',
        '$scope',
        '$routeParams',
        '$caseActionsRestService',
        '$caseActionsCommonsService',
        '$dictionaryUtilsService',
        '$genericUtilsService',
        '$caseActionsDataRestService',
        '$alertUiService',
        CaseActionsNoteController];
});