define([], function() {

    var CasePhoneCallController = function($rootScope,
                                           $scope,
                                           $routeParams,
                                           $filter,
                                           $caseActionsRestService,
                                           $treeviewService,
                                           $commonsService,
                                           $restService,
                                           $actionsCommonsService,
                                           $dictionaryUtils,
                                           $genericUtils,
                                           $stringUtilsService,
                                           $dataRestService,
                                           $alert){

        /*
        *  Initializations
        */
        var userId   = $rootScope.Namespace.User[$dictionaryUtils._userId];
        var login    = $rootScope.Namespace.User[$dictionaryUtils._login];
        var actionId = $routeParams.actionId;
        
        $scope.phoneList = [];
        $scope.eventList = [];
        
        $scope._case = {
        	operationid: $rootScope.Namespace.Case.Current[$dictionaryUtils._operationId],
        	caseId: $rootScope.Namespace.Case.Current[$dictionaryUtils._caseId]
        };

        $scope.action = {
            calling: undefined,
            observation: undefined,
            phoneId: undefined,
            eventId: undefined,
            needcategorize: undefined,
            templates: [],
            templateSelected: function(templateId) {
                if(templateId != undefined){
                    $dataRestService.applyObservationTemplate(
                        templateId,
                        $scope._case.caseId,
                        function(val){
                            if(val){
                                $scope.action.observation = val[$dictionaryUtils._value];
                            }
                        },
                        function(msg){
                            $alert.error(msg.data ? msg.data.error : msg.error);
                        }
                    );
                }
            }
        };
        
        $scope.hasAttachmentPrivilegeActions = $rootScope.Namespace.Case.Current[$dictionaryUtils._hasAttachmentPrivilegeActions];
        
        var urlParams = {};
        urlParams[$dictionaryUtils._actionId] = actionId;
        
        $scope.allowsAttachment = false;
        $caseActionsRestService.allowsAttachment(urlParams,
                function(confirm){
        			$scope.allowsAttachment = confirm[$dictionaryUtils._value];
                },
                function(msg){
                	$alert.error(msg.data ? msg.data.error : msg.error);
                });
        
        urlParams = {};
        urlParams[$dictionaryUtils._caseId] = $scope._case.caseId; 

        var load = function(){
            $restService.findEventList().query(urlParams,
                function(list) {
                    if(! list){
                        return;
                    }
                    $scope.eventList = $treeviewService.treeNode(
                        list, path = [],
                        $dictionaryUtils._eventName,
                        $dictionaryUtils._eventId
                    );
                },
                function(msg) {
                    $alert.error(msg.data ? msg.data.error : msg.error);
                }
            );

            $dataRestService.fetchObservationTemplate(
                $scope._case.caseId,
                function(templates) {
                    var list = [];
                    if(templates){
                        for(var it = 0; it < templates.length; ++it) {
                            var template = templates[it];
                            list.push({
                                id: template[$dictionaryUtils._observationTemplateId],
                                text: template[$dictionaryUtils._name],
                                content: template[$dictionaryUtils._observationTemplateContent]
                            });
                        }
                    }
                    $scope.action.templates = list;
                },
                function(msg) {
                    $alert.error(msg.data ? msg.data.error : msg.error);;
                }
            );

            var findPhonesUncategorized = function(stateControl) {           
                $restService.findPhonesUncategorized(urlParams, function(val) {
                    if (val && val.length > 0) {                        
                        $scope.action.needcategorize = val[0][$dictionaryUtils._clientPhone];
                        $scope.action.phoneId        = val[0][$dictionaryUtils._phoneId];

                        var msg = $filter('translate')('bundle.cad.ALERT_PHONE_UNCATEGORIZED');

                        stateControl.failure({
                            warning: $stringUtilsService.format(msg, $scope.action.needcategorize)
                        });

                    } else {
                        stateControl.success();
                    }
                }, 
                function(msg){
                    stateControl.failure(msg);                       
                });
            };

            var updateContactList = function(val) {
                $scope.phoneList = $restService.toDialFormat(val, $scope._case.caseId, login, $scope.action);
            };

            $commonsService.load(findPhonesUncategorized, updateContactList, $scope._case.caseId);
        }();
        
        /*
        *  This function will be called when user clicks Save Button
        */
        $scope.save = function(){
            var saveActionLogic = function(stateControl) {
                $scope.action.calling = true;

                var payload = {};
                payload[$dictionaryUtils._caseId]      = $scope._case.caseId;
                payload[$dictionaryUtils._userId]      = userId;
                payload[$dictionaryUtils._actionId]    = actionId;
                payload[$dictionaryUtils._phoneId]     = $scope.action.phoneId;
                payload[$dictionaryUtils._callEventId] = $scope.action.eventId;
                payload[$dictionaryUtils._observation] = $scope.action.observation;

                $restService.categorizeContact(
                    payload,
                    function(success) {
                        $scope.redirectingSuccess = true;
                        stateControl.success();
                    }, function(msg){
                        stateControl.failure(msg);
                        $scope.action.calling = false;
                    });    
            };

            var nextCaseLogic = function(newCase) {
                var namespace = $rootScope.Namespace;
                namespace.Case.ChangeCase(newCase);
            };

            $actionsCommonsService.saveAndRedirect(saveActionLogic, nextCaseLogic, userId);
        }
    };
    return [
        '$rootScope',
        '$scope',
        '$routeParams',
        '$filter',
        '$caseActionsRestService',
        '$caseEventsTreeviewService',
        '$caseCommonsPhoneCallService',
        '$casePhoneService',
        '$caseActionsCommonsService',
        '$dictionaryUtilsService',
        '$genericUtilsService',
        '$stringUtilsService',
        '$caseActionsDataRestService',
        '$alertUiService',
        CasePhoneCallController];
});