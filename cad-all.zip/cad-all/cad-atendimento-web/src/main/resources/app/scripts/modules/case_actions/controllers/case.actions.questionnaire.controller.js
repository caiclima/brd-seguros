define([], function() {
    var CaseActionsQuestionnaireController = function($rootScope, $scope, $routeParams, $caseActionsRestService, $caseActionsDataRestService, $questionnaireService, $dictionaryUtils, $genericUtils, $alertUiService) {
        
    	var caseId   = $rootScope.Namespace.Case.Current[$dictionaryUtils._caseId];
        var userId   = $rootScope.Namespace.User[$dictionaryUtils._userId];
        var actionId = $routeParams.actionId;

        $scope.questionnaireSaved = false;
        $scope.responding = undefined;

        $caseActionsDataRestService.fetchQuestionnaire(
        	actionId, caseId, userId,
            function(questionnaire) {
                if(!$questionnaireService.isNullQuestionnaire(questionnaire)) {
                    $scope.questionnaire = $questionnaireService.format(questionnaire[$dictionaryUtils._questionnaireListQuestions]);
                    $scope.questionnaireName = questionnaire[$dictionaryUtils._description];
                    $scope.questionnaireId = questionnaire[$dictionaryUtils._questionnaireId];
                }
            },
            function(msg){
                $alertUiService.error(msg.data ? msg.data.error : msg.error);;
            });

        $scope.save = function() {
            $scope.responding = true;

            var payload = {};
            payload[$dictionaryUtils._caseId]             = caseId;
            payload[$dictionaryUtils._userId]             = userId;
            payload[$dictionaryUtils._actionId]           = actionId;
            payload[$dictionaryUtils._questionnaireId]    = $scope.questionnaireId;
            payload[$dictionaryUtils._questionnaireListQuestions] = [];

            if($scope.questionnaire){
                for(var it=0; it<$scope.questionnaire.length; ++it) {
                    var item = $scope.questionnaire[it];

                    if(!item.disabled) {
                        var sendingItem = {};
                        sendingItem[$dictionaryUtils._questionId] = item.questionId;

                        if(!$questionnaireService.isDateQuestion(item)) {
                            sendingItem[$dictionaryUtils._answer] = item.answer;
                        } else {
                            sendingItem[$dictionaryUtils._answer] = $genericUtils.toServersDateFormat(item.answer);
                        }

                        payload[$dictionaryUtils._questionnaireListQuestions].push(sendingItem);
                    }
                }
            }

            $caseActionsRestService.saveQuestionnaire(
                payload,
                function() {
                    $scope.questionnaireSaved = true;
                },
                function(msg) {
                    $alertUiService.error(msg.data ? msg.data.error : msg.error);
                    $scope.responding = false;
                });
        };
    };

    return ['$rootScope','$scope','$routeParams','$caseActionsRestService','$caseActionsDataRestService','$caseActionsQuestionnaireService','$dictionaryUtilsService', '$genericUtilsService', '$alertUiService', CaseActionsQuestionnaireController];
});