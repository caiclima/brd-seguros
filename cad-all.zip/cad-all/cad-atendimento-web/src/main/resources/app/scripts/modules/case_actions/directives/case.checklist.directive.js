define([], function(){
    var CaseChecklistDirective = function($comparatorUtils, $genericUtils, $filter) {
        return {
            restrict: 'A',
            replace: true,
            scope: {},
            controller: 'CaseActionsChecklistController',
            templateUrl: 'app/scripts/modules/case_actions/directives/templates/case.checklist.html',
            link: function(scope, element, attrs) {
                var boxBorder = $(element).parent().parent();

                scope.checkRemainingRequiredQuestions = function() {
                    var remaining = false;
                    if(scope.checklist){
                        for(var it = 0; it < scope.checklist.length; ++it) {
                            var entry = scope.checklist[it];
                            if(!entry.disabled) {
                                remaining = remaining || ($genericUtils.isNull(entry.selectedAnswer) || entry.selectedAnswer == '');
                            }
                        }
                    }
                    scope.remainingRequiredQuestions = remaining;
                }

                var unwatch = scope.$watch('checklist', function(newVal, oldVal) {
                    if(newVal === oldVal)
                        return;

                    boxBorder.show();
                    scope.checkRemainingRequiredQuestions();
                    
                    $('select','#checklistForm').on("change", function(e) {
                        var select = $(this);
                        var questionId = select.attr('question-id');
                        var value = select.val();

                        if(scope.checklist){
                            for(var it = 0; it < scope.checklist.length; ++it) {
                                var check = scope.checklist[it];
                                if(check.isChild) {
                                    if(questionId == check.childFields.parentId) {
                                        var refOperator = check.childFields.operator;
                                        var refAnswer = check.childFields.answer;

                                        var compared = $comparatorUtils.compare(value, refAnswer, refOperator);
                                        void function showChildCheck(compared) {
                                            check.disabled = !compared;
                                        }(compared);
                                    }
                                }
                            }
                        }
                        scope.checkRemainingRequiredQuestions();
                        scope.$digest();
                    });
                    
                    unwatch();
                });

                var unWatch1 = scope.$watch('checking', function(nV, oV){
                    if(nV != undefined){
                        scope.actionAttributes = {
                            disabled: nV,
                            disabledText: $filter('translate')('bundle.cad.SAVING')
                        };
                    }
                });

                scope.$on('$destroy', function(){
                    unWatch1();
                });
            }
        };
    };

    return ['$comparatorUtilsService','$genericUtilsService', '$filter', CaseChecklistDirective];
});