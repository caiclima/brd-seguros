define( [ ], function()
{            
    return ['$interval', '$filter', function($interval, $filter){
    	 return {
            restrict: 'A',
            replace: true,
            scope: {
            	selectedEvent: "=",
            	operationId: "=",
            	remainingSelection: "=?",
                caseTypes: '=',
                observation: '=',
                observationTemplates: '=',
                onTemplateSelected: '=',
                onSubmitted: '=',
                caseTypeId: '=',
                requireAuthorization: '=',
                loginMaster: '=',
                passwordMaster: '=',
                classifying: '=?',
                hasAttachmentPrivilegeActions: '=',
                allowsAttachment: '='
            },
            templateUrl: 'app/scripts/modules/case_actions/directives/templates/case.classification.html',
            link: function(scope, element, attrs) {
                var unWatch = scope.$watch('classifying', function(nV, oV){
                    if(nV != undefined){
                        scope.actionAttributes = {
                            disabled: nV,
                            disabledText: $filter('translate')('bundle.cad.SAVING')
                        };
                    }
                });

                var checker = $interval(function() {
                    if($("#uploadp")) {
                        //We must check whether element is ready
                        $('#uploadp').addClass('form-group');
                        $('#upload-title').addClass('col-sm-2 control-label');
                        $('#uploadf').addClass('col-sm-10');       
                        $interval.cancel(checker);
                    }

                }, 250, 0, false);
                
                scope.save = function() {
                	if(scope.requireAuthorization){
                		if(!scope.loginMaster && !scope.passwordMaster){
                			 $('#modalApprovalClassification').modal({
                                 show: true
                             });
                			 return;
                		}
                	}
                	
                	scope.onSubmitted();
                };

                scope.$on('$destroy', function(){
                    unWatch();
                });
            }
        };
    }];
});