define( [ ], function()
{            
	return ['$interval', '$filter', function($interval, $filter){
    	 return {
            restrict: 'A',
            replace: true,
            templateUrl: 'app/scripts/modules/case_actions/directives/templates/case.edit.html',
            scope:{
                datasource: '=',
                observation: '=',
                suggestionJunction: '=',
                suggestionOtherArea: '=',
                suggestionCaseType: '=',
                suggestionUser: '=',
                suggestionCause: '=',
                suggestionChannel: '=',
                suggestionStatus: '=',
                suggestionQueueConfig: '=',
                observationTemplates: '=',
                onTemplateSelected: '=',
                caseid: '=',
                editing: '=?',
                save: '=',
                hasAttachmentPrivilegeActions: '=',
                allowsAttachment: '='
            },
            link: function(scope, element, attrs) {
            	scope.remainingSelection = undefined;
            	scope.isMandatorySelectEvent = false;

                var unWatch = scope.$watch('editing', function(nV, oV){
                    if(nV != undefined){
                        scope.actionAttributes = {
                            disabled: nV,
                            disabledText: $filter('translate')('bundle.cad.SAVING')
                        };
                    }
                });

            	var checker = $interval(function() {
                    if($("#uploadp") && $('#uploadf') && $('#upload-title')) {
                        //We must check whether element is ready
                        $('#uploadp').addClass('form-group');
                        $('#upload-title').addClass('col-sm-2 control-label');
                        $('#uploadf').addClass('col-sm-10');       
                        $interval.cancel(checker);
                    }

                }, 250, 0, false);

                scope.$on('$destroy', function(){
                    unWatch();
                });
            }
        };
    }];
});