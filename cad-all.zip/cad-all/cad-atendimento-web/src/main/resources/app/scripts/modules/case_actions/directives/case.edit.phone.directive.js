define( [ ], function()
{            
    return ['$interval', '$filter', function($interval, $filter){
         return {
            restrict: 'A',
            templateUrl: 'app/scripts/modules/case_actions/directives/templates/case.edit.phone.html',
            scope: {
                approvalAndEditPhoneAction: '=',
                editPhoneAction: '=',
                loginMaster:  '=',
                passwordMaster:  '=',
                observation: '=',
                editing: '=?',
                contactList: '='
            },
            link: function(scope, element, attrs) {
                scope.phoneNumber = undefined;
                scope.itemPhone = undefined;

                scope.tableConfig = [{
                    title: $filter('translate')('bundle.cad.ID'),
                    width: '25%'
                },{
                    title: $filter('translate')('bundle.cad.PHONE_NUMBER'),
                    width: '65%'
                },{
                    type: 'button-toogle',
                    icon: 'icon-21-8',
                    width: '5%'
                }];

                var checker = $interval(function() {
                    var div = element.find('.content_tab_margin');
                    if(div && div.length > 0) {
                        div.css('margin-top','0px');
                        $interval.cancel(checker);
                    }
                }, 250, 0, false);

                var remove = function(e){
                    this.isActive = false;
                    $(e.target).closest('tr').hide();
                };

                scope.add = function(){
                	var entry = {};
                	if (scope.itemPhone) {
                		entry.phoneId = scope.itemPhone.phoneId;
                	} else {
                        entry.phoneId = undefined;
                	}
                	entry.phoneNumber = scope.phoneNumber;
                    entry.model = {
                    	isActive: true,
                        icon: 'form-remove',
                        show: true,
                        action: remove
                    };
                	scope.contactList.push(entry);
                	
                    scope.phoneNumber = undefined;
                    scope.itemPhone = undefined;
                };
                
                scope.doAction = function(){
                    scope.editPhoneAction();
                };

                var unWatch2 = scope.$watch('editing', function(nV, oV){
                    if(nV != undefined){
                        scope.actionAttributes = {
                            disabled: nV,
                            disabledText: $filter('translate')('bundle.cad.SAVING')
                        };
                    }
                });

                scope.$on('$destroy', function(){
                    unWatch2();
                });
            }
        };
    }];
});