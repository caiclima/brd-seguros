define([], function() {
    return ['$filter', '$alertUiService', '$interval', function($filter, $alertUiService, $interval) {
        return {
            restrict: 'A',
            templateUrl: 'app/scripts/modules/case_actions/directives/templates/case.email.sending.html',
            scope: {
                emailConfig: '=',
                sending: '=',
                sendEmail: '=',
                hasAttachmentPrivilegeEmail: '=',
                allowsAttachment: '='
            },
            link: function(scope,element, attrs) {
                var unWatch = scope.$watch('sending', function(nV, oV){
                    if(nV != undefined){
                        scope.actionAttributes = {
                            disabled: nV,
                            disabledText: $filter('translate')('bundle.cad.SENDING')
                        };
                    }
                });
                
                var unWatch1 = scope.$watch('emailConfig', function(nV, oV){
                    if(nV != undefined && nV.content != oV.content){
                    	$('#emailComponent').htmlarea('html', nV.content);
                    }
                }, true);

                var checker = $interval(function() {
                    if($("#uploadp")) {
                        //We must check whether element is ready
                        $('#uploadp').addClass('form-group');
                        $('#upload-title').addClass('col-sm-2 control-label');
                        $('#uploadf').addClass('col-sm-10');       
                        $interval.cancel(checker);
                    }

                }, 250, 0, false);
                
                scope.templateSelected = function(val) {
                	scope.emailConfig.templateSelected(val);
                };
                
                scope.prepareAndSend = function() {
                    /*
                    *  Get Email content
                    */
                    scope.emailConfig.content = $('#emailComponent').htmlarea('html');
                    /*
                    *  Get Recipients Groups
                    */
                    var recipientsGroups = $('#recipientsGroupsId').select2("val");

                    if(recipientsGroups && recipientsGroups.length > 0) {
                        recipientsGroups = $.grep(recipientsGroups, function(value, index){
                            return value !== 'undefined' && value !== '?' && value !== '';
                        });

                        scope.emailConfig.selectedRecipientsGroups = recipientsGroups;
                    } else {
                        scope.emailConfig.selectedRecipientsGroups = [];
                    }
                    /*
                    *  Get Recipients
                    */
                    scope.emailConfig.recipients = $('#emailRecipientsId').val();
                    /*
                     *  Get Recipients From Carbon Copies
                     */
                    scope.emailConfig.carbonCopyRecipients = $('#emailCarbonCopyRecipientsId').val();
                    try {
                    	if (scope.emailConfig.carbonCopyRecipients && scope.emailConfig.carbonCopyRecipients.length > 4000) {
                    		throw $filter('translate')('bundle.cad.CASE_EMAIL_CC_RECIPIENTS_ERROR');
                        }
                    } catch(e) {
                        $alertUiService.error(e);
                        return;
                    }
                    
                    /*
                    *  Validate Formulary
                    */
                    try {
                        if(scope.emailConfig.selectedRecipientsGroups
                            && scope.emailConfig.selectedRecipientsGroups.length == 0
                            && scope.emailConfig.recipients == '') {
                            throw $filter('translate')('bundle.cad.CASE_EMAIL_RECIPIENTS_ERROR');
                        }
                        if(scope.emailConfig.content == '') {
                            throw $filter('translate')('bundle.cad.CASE_EMAIL_CONTENT_ERROR');
                        }
                    } catch(e) {
                        $alertUiService.error(e);
                        return;
                    }
                    /*
                    *  Send event upperwards
                    */
                    scope.sendEmail();
                };

                scope.$on('$destroy', function(){
                    unWatch();
                    unWatch1();
                });

                $('#emailRecipientsId').tagsinput('refresh');
                $('#emailCarbonCopyRecipientsId').tagsinput('refresh');
            }
        };
    }];
});