define( [ ], function()
{            
    return ['$interval', '$filter', function($interval, $filter){
    	 return {
            restrict: 'A',
            replace: true,
            scope: {
                observation: '=',
                observationTemplates: '=',
                onTemplateSelected: '=',
                endingReasons: '=',
                reasonId: '=',
                ending: '=',
                save: '=',
                hasAttachmentPrivilegeActions: '=',
                allowsAttachment: '='
            },
            templateUrl: 'app/scripts/modules/case_actions/directives/templates/case.end.html',
            link: function(scope, element, attrs) {
                var checker = $interval(function() {
                    if($("#uploadp")) {
                        //We must check whether element is ready
                        $('#uploadp').addClass('form-group');
                        $('#upload-title').addClass('col-sm-2 control-label');
                        $('#uploadf').addClass('col-sm-10');       
                        $interval.cancel(checker);
                    }

                }, 250, 0, false); 

                var unWatch = scope.$watch('ending', function(nV, oV){
                    if(nV != undefined){
                        scope.actionAttributes = {
                            disabled: nV,
                            disabledText: $filter('translate')('bundle.cad.SAVING')
                        };
                    }
                });

                scope.$on('$destroy', function(){
                    unWatch();
                });
            }
        };
    }];
});