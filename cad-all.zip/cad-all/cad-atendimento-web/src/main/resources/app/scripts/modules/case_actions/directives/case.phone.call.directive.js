define( [ ], function()
{            
    return ['$filter', '$interval', function($filter, $interval){           
         return {
            restrict: 'A',
            templateUrl: 'app/scripts/modules/case_actions/directives/templates/case.phone.call.html',
            scope: {
                save: '=',
                context: '@',
                datasource: '=',
                observation: '=',
                observationTemplates: '=',
                onTemplateSelected: '=',
                operationid: '=',
                calling: '=',
                selectedEvent: '=',
                needcategorize: '=',
                hasAttachmentPrivilegeActions: '=',
                allowsAttachment: '='
            },
            link: function(scope, element, attrs) {
            	scope.isMandatorySelectEvent = true;
            	scope.remainingSelection = undefined;
            	
                scope.tableConfig = [{
                    width: '25%'
                },{
                    title: $filter('translate')('bundle.cad.CLIENT_PHONE'),
                    width: '70%'
                },{
                    width: '5%',
                    type: 'button',
                    icon: 'icon-earphone'
                }];

                var checker = $interval(function() {
                    if($("#uploadp") && $("#uploadp").length > 0) {
                        //We must check whether element is ready
                        $('#uploadp').addClass('form-group');
                        $('#upload-title').addClass('col-sm-2 control-label');
                        $('#uploadf').addClass('col-sm-10');       
                        $interval.cancel(checker);
                    }

                }, 250, 0, false);

                var unWatch = scope.$watch('calling', function(nV, oV){
                    if(nV != undefined){
                        scope.actionAttributes = {
                            disabled: nV,
                            disabledText: $filter('translate')('bundle.cad.SAVING')
                        };
                    }
                });

                scope.$on('$destroy', function(){
                    unWatch();
                });
            }
        };
    }];
});