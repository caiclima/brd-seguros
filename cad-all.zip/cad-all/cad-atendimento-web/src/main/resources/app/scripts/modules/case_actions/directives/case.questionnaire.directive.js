define([], function() {
    return ['$genericUtilsService','$stringUtilsService','$comparatorUtilsService', '$caseActionsQuestionnaireService', '$filter',
    function($genericUtils, $stringUtils, $comparatorUtils, $questionnaireService, $filter) {
        return {
            restrict: 'A',
            replace: true,
            scope: {},
            controller: "CaseActionsQuestionnaireController",
            templateUrl: 'app/scripts/modules/case_actions/directives/templates/case.questionnaire.html',
            link: function(scope, element, attrs) {
            	var hideBoxBorder = true;
            	if(attrs.hideWhenEmpty != undefined){
            		hideBoxBorder = scope.$eval(attrs.hideWhenEmpty);
            	}

				if (hideBoxBorder) {
					var boxBorder = $(element).parent().parent();
					boxBorder.hide();
				}

                var unwatch = scope.$watch('questionnaire', function(newVal, oldVal) {
                    if(newVal === oldVal)
                        return;
                    
    				if (hideBoxBorder) {
    					boxBorder.show();
    				}
    				
                    scope.checkRemainingRequiredQuestions();
                    unwatch();
                });

                scope.checkRemainingRequiredQuestions = function() {
                    var remaining = false;
                    if(scope.questionnaire){
                        for(var it = 0; it < scope.questionnaire.length; ++it) {
                            var item = scope.questionnaire[it];
                            if(!item.disabled && item.required && $questionnaireService.isSpecialValidationQuestion(item)) {
                                remaining = remaining || ($genericUtils.isNull(item.answer) || item.answer == '');
                            }
                        }
                    }
                    scope.remainingRequiredQuestions = remaining;
                }

                scope.onChoose = function(questionId) {
                    var question = function(questionId){
                        if(scope.questionnaire){
                            for(var it = 0; it < scope.questionnaire.length; ++it) {
                                var item = scope.questionnaire[it];
                                if(questionId == item.questionId) {
                                    return item;
                                }
                            }
                        }
                    }(questionId);

                    var value = $questionnaireService.getElValue(question);
                    var isMultiAnswer = $questionnaireService.isMultiAnswerQuestion(question);

                    if(isMultiAnswer) {
                        question.answer = value;
                    }

                    if(scope.questionnaire){
                        for(var it = 0; it < scope.questionnaire.length; ++it) {
                            var item = scope.questionnaire[it];
                            if(item.isChild) {
                                if(questionId == item.childFields.parentId) {
                                    var refOperator = item.childFields.operator;
                                    var refAnswer = item.childFields.answer;

                                    var compared = compare(value, isMultiAnswer, refAnswer, refOperator);
                                    void function showChildItem(compared) {
                                        item.disabled = !compared;
                                    }(compared);
                                }
                            }
                        }
                    }

                    scope.checkRemainingRequiredQuestions();

                    function compare(value, isMultiAnswer, refAnswer, refOperator) {
                        if(isMultiAnswer) {
                            return $comparatorUtils.like(value, refAnswer.split(";"), refOperator);
                        } else {
                            return $comparatorUtils.compare(value, refAnswer, refOperator);
                        }
                    }
                };

                var unWatch1 = scope.$watch('responding', function(nV, oV){
                    if(nV != undefined){
                        scope.actionAttributes = {
                            disabled: nV,
                            disabledText: $filter('translate')('bundle.cad.SAVING')
                        };
                    }
                });

                scope.$on('$destroy', function(){
                    unWatch1();
                });
            }
        };
    }];
});