define([], function() {
    var CaseActionsChecklistService = function($dictionaryUtils, $genericUtils, $stringUtils) {
        return {

            format: function(checklist) {
                var prettyList = [];

                for(var it = 0; it < checklist.length; ++it) {
                    var check = checklist[it];

                    var prettyEntry = {};
                    prettyEntry.question = check[$dictionaryUtils._description];
                    prettyEntry.selectedAnswer = check[$dictionaryUtils._defaultAnswer];
                    prettyEntry.checkId = check[$dictionaryUtils._checkId];

                    prettyEntry.availableAnswers = function(check) {
                        var objAnswers = {};
                        if(!$genericUtils.isNull(check[$dictionaryUtils._availableAnswers])) {
                            var answers = check[$dictionaryUtils._availableAnswers].split(";");                        
                            for(var it = 0; it < answers.length; ++it) {
                                var answer = answers[it];
                                objAnswers[answer] = answer;
                            }
                        }                        
                        return objAnswers;
                    }(check);

                    prettyEntry.isChild = function(check) {
                        return !$genericUtils.isNull(check[$dictionaryUtils._checkParentId]);
                    }(check);

                    if(prettyEntry.disabled = prettyEntry.isChild) {
                        prettyEntry.childFields = {
                            parentId: check[$dictionaryUtils._checkParentId],
                            operator: check[$dictionaryUtils._presentationOperator],
                            answer:  check[$dictionaryUtils._presentationAnswer],
                        };
                    }

                    prettyList.push(prettyEntry);
                }

                return prettyList;

            }
        };
    };

    return ['$dictionaryUtilsService', '$genericUtilsService', '$stringUtilsService', CaseActionsChecklistService];
});