define([], function() {
    return ['$q', '$casePhoneService', '$dictionaryUtilsService', '$alertUiService',
        function($q, $restService, $dic, $alert) {
            var _exceptionFn = function(msg) {
                var txt = msg.data === undefined ? msg.error : msg.data.error;

                if(txt){
                    $alert.error(txt);
                    return;
                }

                txt = msg.warning;

                if(txt){
                    $alert.warning(txt);
                }
            };

            return {
                load: function(actionFn, posFn, caseId) {
                    this._doAction(actionFn, posFn, caseId)
                            .catch(_exceptionFn)
                        .then(this._findPhones)
                            .catch(_exceptionFn);

                },

                _doAction: function(actionFn, posFn, caseId) {
                    var validatePromise = $q.defer();

                    var stateControl = {
                        success: function() {
                            validatePromise.resolve( {
                                caseId: caseId,
                                posFn: posFn
                            });
                        },
                        failure: function(msg) {
                            validatePromise.reject(msg);
                        }
                    };
                    
                    actionFn(stateControl);
                    return validatePromise.promise;                
                },

                _findPhones: function(resolved) {
                    if(resolved){
                        var urlParams = {};
                        urlParams[$dic._caseId] = resolved.caseId;  
                        $restService.findContactList(urlParams, resolved.posFn, _exceptionFn);
                    }
                }
            };
    }];
});