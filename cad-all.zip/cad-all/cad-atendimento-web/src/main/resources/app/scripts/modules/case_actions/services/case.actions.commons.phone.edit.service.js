/**
 * Created by swb_samuel on 16/10/2014.
 */
define([], function() {
    return ['$q', '$casePhoneService', '$caseActionsCommonsService', '$dictionaryUtilsService', '$alertUiService',
        function($q, $casePhoneService, $actionsCommonsService, $dic, $alert) {

            var _requiresPasswordMaster = function(caseId, userId, saveActionLogic, nextCaseLogic) {
                var validatePromise = $q.defer();

                var urlParams = {};
                urlParams[$dic._caseId] = caseId;

                $casePhoneService.requiresPasswordMasterToUpdate(urlParams,
                    function(confirm){
                        validatePromise.resolve( {
                            userId: userId,
                            saveActionLogic: saveActionLogic,
                            nextCaseLogic: nextCaseLogic,
                            confirm: confirm[$dic._value]
                        });
                    },
                    function(msg){
                        validatePromise.reject(msg);
                    });

                return validatePromise.promise;
            };

            var _confirmAndEditPhones = function(resolved) {
                if(resolved.confirm){
                    $('#modalApproval').modal({
                        show: true
                    });

                }else{
                    $actionsCommonsService.saveAndRedirect(resolved.saveActionLogic, resolved.nextCaseLogic, resolved.userId);
                }
            };

            var _exceptionFn = function(msg) {
                $alert.error(msg.data ? msg.data.error : msg.error);
            };

            return {
                confirmAndEditPhones: function(caseId, userId, saveActionLogic, nextCaseLogic) {
                    _requiresPasswordMaster(caseId, userId, saveActionLogic, nextCaseLogic)
                        .catch(_exceptionFn)
                            .then(_confirmAndEditPhones)
                        .catch(_exceptionFn);

                }
            };
        }];
});