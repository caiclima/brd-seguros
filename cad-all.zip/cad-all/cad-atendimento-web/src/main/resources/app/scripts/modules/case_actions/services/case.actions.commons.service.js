define([], function() {
    return ['$q', '$location', '$filter', '$caseViewRestService', '$caseCheckerUtilsService', '$alertUiService', '$stringUtilsService','$requestUtilsService','$dictionaryUtilsService','$resource',
        function($q, $location, $filter, $caseViewRestService, $caseCheckerUtilsService, $alertUiService, $stringUtilsService,$requestUtils,$dictionaryUtilsService,$resource) {
    	
	    	 var byActionId = function(uri) {
	             var path = $requestUtils.contextPath();
	             var url = $stringUtilsService.concatenate(path, uri);
	
	             var paramDefaults = {};
	             paramDefaults[$dictionaryUtilsService._actionId] = $stringUtilsService.format('@{0}',$dictionaryUtilsService._actionId);
	
	             return $resource(url, paramDefaults);
	         };
            return {
                saveAndRedirect: function(actionFn, nextCaseFn, userId) {

                    this._doAction(actionFn, nextCaseFn, userId)
                            .catch(function(msg) {
                            	var error = msg.data === undefined ? msg.error : msg.data.error;
                                $alertUiService.error(error);                          
                                return $q.defer().promise;
                            })
                        .then(this._nextCase)
                            .catch(function(msg) {
                            	var error = msg.data === undefined ? msg.error : msg.data.error;
                                $alertUiService.error(error);
                                $location.path('/case-pendency');
                            })
                        .then(this._redirect);
                },

                _doAction: function(actionFn, nextCaseFn, userId) {
                    var actionPromise = $q.defer();

                    var stateControl = {
                        success: function() {
                            var succeedMsg = $filter('translate')('bundle.cad.ACTION_SUCCEED');
                            var redirectionMsg = $filter('translate')('bundle.cad.ACTION_REDIRECTING');

                            $alertUiService.success($stringUtilsService.concatenate(succeedMsg,' ', redirectionMsg));
                            
                            nextCaseFn(undefined);

                            actionPromise.resolve( {
                                userId: userId,
                                nextCaseFn: nextCaseFn
                            });
                        },
                        failure: function(msg) {
                            actionPromise.reject(msg);
                        }
                    };
                    
                    actionFn(stateControl);

                    return actionPromise.promise;                
                },

                _nextCase: function(resolved) {
                    if(resolved !== undefined){
                        var nextCasePromise = $q.defer();

                        $caseViewRestService.nextCase(
                            resolved.userId,
                            function(newCase) {
                                resolved.nextCaseFn(newCase);
                                var hasCase = $caseCheckerUtilsService.realCase(newCase);
                                nextCasePromise.resolve(hasCase);
                            }, function(msg){
                                nextCasePromise.reject(msg);
                            }
                        );

                        return nextCasePromise.promise;
                    }
                },
                loadAction: function(actionId, successFn, errorFn) {
                	var uri = $stringUtilsService.format('/api/action/:{0}', $dictionaryUtilsService._actionId);

                    var params = {};
                    params[$dictionaryUtilsService._actionId] = actionId;

                    byActionId(uri).get(params, successFn, errorFn);
                },

                _redirect: function(hasCase) {
                    if(hasCase !== undefined){
                        $location.path(hasCase ? '/case-view' : '/case-pendency');
                    }
                }
            };
    }];
});