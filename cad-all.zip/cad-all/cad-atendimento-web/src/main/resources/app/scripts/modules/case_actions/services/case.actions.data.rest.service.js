define([], function() {
    
    var CaseActionsDataRestService = function($resource, $requestUtils, $stringUtils, $dicUtils)  {

        var byCaseResource = function(uri) {
            var path = $requestUtils.contextPath();
            var url = $stringUtils.concatenate(path, uri);

            var paramDefaults = {};
            paramDefaults[$dicUtils._caseId] = $stringUtils.format('@{0}',$dicUtils._caseId);

            return $resource(url, paramDefaults);
        };

        return {
            endingReasons: function(caseId, successFn, errorFn) {
                var uri = $stringUtils.format('/api/cases/:{0}/causes', $dicUtils._caseId);

                var params = {};
                params[$dicUtils._caseId] = caseId;

                byCaseResource(uri).query(params, successFn, errorFn);
            },

            externalAreas: function(caseId, successFn, errorFn) {
                var uri = $stringUtils.format('/api/otherArea/cases/:{0}', $dicUtils._caseId);

                var params = {};
                params[$dicUtils._caseId] = caseId;

                byCaseResource(uri).query(params, successFn, errorFn);
            },

            dataToClassify: function(caseId, successFn, errorFn) {
                var uri = $stringUtils.format('/api/cases/:{0}/dataforclassification', $dicUtils._caseId);

                var params = {};
                params[$dicUtils._caseId] = caseId;

                byCaseResource(uri).get(params, successFn, errorFn);
            },

            parentEvent: function(eventId, successFn, errorFn) {
                var path = $requestUtils.contextPath();
                //TODO: grammar error at endpoint
                var uri = $stringUtils.format('/api/event/perentevent/:{0}', $dicUtils._eventId);
                var url = $stringUtils.concatenate(path, uri);

                var paramDefaults = {};
                paramDefaults[$dicUtils._eventId] = $stringUtils.format('@{0}',$dicUtils._eventId);

                var params = {};
                params[$dicUtils._eventId] = eventId;

                $resource(url, paramDefaults).query(params, successFn, errorFn);
            },
            
            fetchEmailTemplate: function(caseId, successFn, errorFn) {
            	var uri = $stringUtils.format('/api/cases/email/template/case/:{0}', $dicUtils._caseId);

                var params = {};
                params[$dicUtils._caseId] = caseId;

                byCaseResource(uri).query(params, successFn, errorFn);
            },
            
            applyEmailTemplate: function(templateEmailId, caseId, successFn, errorFn) {
            	var uri = $stringUtils.format('/api/cases/apply/email/template/:{0}/case/:{1}', $dicUtils._emailTemplateId, $dicUtils._caseId);

                var params = {};
                params[$dicUtils._emailTemplateId] = templateEmailId;
                params[$dicUtils._caseId] = caseId;

                byCaseResource(uri).get(params, successFn, errorFn);
            },

            fetchEmailGroups: function(caseId, successFn, errorFn) {
                var uri = $stringUtils.format('/api/cases/findemailgroupforoperationcase/:{0}', $dicUtils._caseId);

                var params = {};
                params[$dicUtils._caseId] = caseId;

                byCaseResource(uri).query(params, successFn, errorFn);
            },
            
            fetchEmailBox: function(operationId, successFn, errorFn) {
                var uri = $stringUtils.format('/api/cases/caixas/operacao/:{0}', $dicUtils._operationId);

                var params = {};
                params[$dicUtils._operationId] = operationId;

                byCaseResource(uri).query(params, successFn, errorFn);
            },

            fetchCheckList: function(actionId, caseId, userId, successFn, errorFn) {
                var resource = function() {
                    var actionIdParam = $dicUtils._actionId;
                    var caseIdParam = $dicUtils._caseId;
                    var userIdParam = $dicUtils._userId;
                    
                    var uri = '/api/checklist/action/:{0}/case/:{1}/user/:{2}';
                    uri = $stringUtils.format(uri, actionIdParam, caseIdParam, userIdParam);

                    var path = $requestUtils.contextPath();
                    var url = $stringUtils.concatenate(path, uri);

                    var paramDefaults = {};
                    paramDefaults[$dicUtils._actionId] = $stringUtils.format('@{0}', actionIdParam);
                    paramDefaults[$dicUtils._caseId] = $stringUtils.format('@{0}', caseIdParam);
                    paramDefaults[$dicUtils._userId] = $stringUtils.format('@{0}', userIdParam);                    

                    return $resource(url, paramDefaults);
                }();
                
                var urlParams = {};
                urlParams[$dicUtils._actionId] = actionId;
                urlParams[$dicUtils._caseId] = caseId;
                urlParams[$dicUtils._userId] = userId;

                return resource.get(urlParams, successFn, errorFn);
            },

            fetchQuestionnaire: function(actionId, caseId, userId, successFn, errorFn) {
                var resource = function() {
                    var uri = $stringUtils.format('/api/questionnaire/action/:{0}/case/:{1}/user/:{2}', $dicUtils._actionId, $dicUtils._caseId, $dicUtils._userId);
                    var path = $requestUtils.contextPath();
                    var url = $stringUtils.concatenate(path, uri);

                    var paramDefaults = {};
                    paramDefaults[$dicUtils._actionId] = $stringUtils.format('@{0}',$dicUtils._actionId);
                    paramDefaults[$dicUtils._caseId] = $stringUtils.format('@{0}',$dicUtils._caseId);
                    paramDefaults[$dicUtils._userId] = $stringUtils.format('@{0}',$dicUtils._userId);

                    return $resource(url, paramDefaults);
                }();

                var params = {};
                params[$dicUtils._actionId] = actionId;
                params[$dicUtils._caseId] = caseId;
                params[$dicUtils._userId] = userId;

                resource.get(params, successFn, errorFn);
            },

            fetchObservationTemplate: function(caseId, successFn, errorFn) {
                var uri = $stringUtils.format('/api/cases/observation/template/case/:{0}', $dicUtils._caseId);

                var params = {};
                params[$dicUtils._caseId] = caseId;

                byCaseResource(uri).query(params, successFn, errorFn);
            },

            applyObservationTemplate: function(observationTemplateId, caseId, successFn, errorFn) {
                var uri = $stringUtils.format('/api/cases/apply/observation/template/:{0}/case/:{1}', $dicUtils._observationTemplateId, $dicUtils._caseId);

                var params = {};
                params[$dicUtils._observationTemplateId] = observationTemplateId;
                params[$dicUtils._caseId] = caseId;

                byCaseResource(uri).get(params, successFn, errorFn);
            }
        };
    };

    return ['$resource', 
            '$requestUtilsService', 
            '$stringUtilsService', 
            '$dictionaryUtilsService',
            CaseActionsDataRestService];
});