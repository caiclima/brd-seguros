define( [ ], function()
{
    var CaseEditRestService = function($resource, $stringUtils, $genericUtils, $requestUtils, $dictionaryUtils, $comboFormatterUtils)
    {
        return {
            fieldsAngSuggestions: function(actionId, caseId, successFn, errorFn) {
                var resource = function() {
                    var uri = '/api/case/edit/fields/action/:{0}/case/:{1}';
                    var actionIdParam = $dictionaryUtils._actionId;
                    var caseIdParam = $dictionaryUtils._caseId;
                    var formattedUri = $stringUtils.format(uri, actionIdParam, caseIdParam);

                    var paramDefaults = {};
                    paramDefaults[actionIdParam] = $stringUtils.format('@{0}',actionIdParam);
                    paramDefaults[caseIdParam] = $stringUtils.format('@{0}',caseIdParam);

                    return $resource($stringUtils.concatenate($requestUtils.contextPath(), formattedUri), paramDefaults);
                }();

                var urlParams = {};
                urlParams[$dictionaryUtils._actionId] = actionId;
                urlParams[$dictionaryUtils._caseId] = caseId;
                resource.get(urlParams, successFn, errorFn);                  
            },
            setValueForEvent: function(fields, value){
                if(fields){
                    $.each(fields, function(index, item){
                        switch(item.typeField) {
                            case 'ID_EVENTO':
                                item.value = value;
                                break;
                        }
                    });
                }
            }
        }
    };
    return [
        "$resource",
        "$stringUtilsService",
        '$genericUtilsService',
        "$requestUtilsService",
        "$dictionaryUtilsService",
        '$comboPrettyFormatUtilsService',
        CaseEditRestService];
});