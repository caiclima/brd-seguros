define([], function() {
    var CaseActionsPhoneService = function($fileUploadService, $dictionaryUtils, $genericUtils, $stringUtils, $resource, $requestUtils, $filter, $alert) {
        
        var dialPhone = function(payload, successFn, errorFn) {
            var caseId = payload[$dictionaryUtils._caseId];
            var uri = $stringUtils.format('/api/cases/:{0}/dialphone', caseId);

            return $resource($requestUtils.contextPath() + uri, {}, {
                'dial': {
                    method: 'PUT'
                }
            }).dial(payload, successFn, errorFn);
        };

        var send = function(uri, payload, _succesFn, _errorFn) {
            var path = $requestUtils.contextPath();
            var url = $stringUtils.concatenate(path, uri);

            $fileUploadService.upload(url, payload, function(response){
                 if(response == undefined || response.error == undefined){
                    _succesFn(response);
                 }else{
                    _errorFn(response);
                 }
            });
        };

        return {

           categorizeContact: function(payload, successFn, errorFn) {
                var actionId = payload[$dictionaryUtils._actionId];
                var uri = $stringUtils.format('/api/action/categorizephonecall/:{0}', actionId);
                send(uri, payload, successFn, errorFn);
            },
            
            updateContactList: function(payload, successFn, errorFn) {
                var actionId = payload[$dictionaryUtils._actionId];
                var uri = $stringUtils.format('/api/action/updatePhoneClient/:{0}', actionId);
                var url = $requestUtils.contextPath() + uri;
                
                return $resource(url, {}, {update: { method: 'PUT' } }).update(payload, successFn, errorFn);
            },

            requiresPasswordMasterToUpdate: function(urlParams, successFn, errorFn) {
                var path = $requestUtils.contextPath();
                var url = $stringUtils.concatenate(path, $stringUtils.format('/api/cases/requirespasswordmastertoupdatephone/:{0}', $dictionaryUtils._caseId));

                var paramDefaults = {};
                paramDefaults[$dictionaryUtils._caseId] = $stringUtils.format('@{0}',$dictionaryUtils._caseId);

                return $resource(url, paramDefaults).get(urlParams, successFn, errorFn);
            },

            findContactList: function(urlParams, successFn, errorFn) {
                var path = $requestUtils.contextPath();
                var url = $stringUtils.concatenate(path, $stringUtils.format('/api/cases/:{0}/phones', $dictionaryUtils._caseId));

                var paramDefaults = {};
                paramDefaults[$dictionaryUtils._caseId] = $stringUtils.format('@{0}',$dictionaryUtils._caseId);

                return $resource(url, paramDefaults).query(urlParams, successFn, errorFn);
            },

            findPhonesUncategorized: function(urlParams, successFn, errorFn) {
                var path = $requestUtils.contextPath();
                var url = $stringUtils.concatenate(path, $stringUtils.format('/api/cases/:{0}/phonesuncategorized', $dictionaryUtils._caseId));

                var paramDefaults = {};
                paramDefaults[$dictionaryUtils._caseId] = $stringUtils.format('@{0}',$dictionaryUtils._caseId);

                return $resource(url, paramDefaults).query(urlParams, successFn, errorFn);
            },

            findEventList: function() {
                var path = $requestUtils.contextPath();
                var url = $stringUtils.concatenate(path, $stringUtils.format('/api/eventphonecall/case/:{0}', $dictionaryUtils._caseId));
                var secondurl = $stringUtils.concatenate(path, $stringUtils.format('/api/eventphonecall/perentevent/:{0}', $dictionaryUtils._parentEventId));

                var paramDefaults = {};
                paramDefaults[$dictionaryUtils._caseId] = $stringUtils.format('@{0}',$dictionaryUtils._caseId);
                paramDefaults[$dictionaryUtils._parentEventId] = $stringUtils.format('@{0}',$dictionaryUtils._parentEventId);

                return $resource(url, paramDefaults, {
                    'findChildren' : {
                        url: secondurl,
                        method: 'GET', 
                        isArray: true 
                    } 
                });
            },
            
            toEditFormat: function(objectList) {
                var list = [];

                if(objectList){
                    $.each(objectList, function( index, item ) {
                        var entry = {};
                        entry.phoneId = item[$dictionaryUtils._phoneId];
                        entry.phoneNumber = item[$dictionaryUtils._phone];
                        entry.model = {
                            isActive: item[$dictionaryUtils._isActive],
                            show: true,
                            action: function(e){
                                this.isActive = false;
                                $(e.target).closest('tr').hide();
                            }
                        };
                        
                        list.push(entry);
                    }); 
                }                    
                return list;
            },

            toDialFormat: function(objectList, caseId, loginUser, output) {
                var list = [];

                if(objectList){
                    $.each(objectList, function( index, item ) {
                        var entry = {};
                        entry.phoneId = item[$dictionaryUtils._phoneId];
                        entry.phoneNumber = item[$dictionaryUtils._clientPhone];
                        entry.dial = {
                            action: function(){
                                var payload = {};
                                payload[$dictionaryUtils._clientPhone] = entry.phoneNumber;
                                payload[$dictionaryUtils._loginUser]   = loginUser;
                                payload[$dictionaryUtils._caseId]      = caseId;
                                
                                dialPhone(payload, function(obj){
                                    output.needcategorize = entry.phoneNumber;
                                    output.phoneId = entry.phoneId;                                  
                                },
                                function(msg){
                                   $alert.error(msg.data ? msg.data.error : msg.error);    
                                });
                            }
                        };
                        list.push(entry);
                    }); 
                }                    
                return list;
            },

            toServerFormat: function(objectList, loginUser) {
                var list = [];

                if(objectList){
                    $.each(objectList, function( index, item ) {
                        var entry = {};
                        entry[$dictionaryUtils._loginUser] = loginUser;
                        entry[$dictionaryUtils._isActive]  = item.model.isActive;
                        entry[$dictionaryUtils._phoneId]   = item.phoneId;
                        entry[$dictionaryUtils._phone]     = item.phoneNumber;

                        list.push(entry);
                    });
                }
                return list;
            }
        };
    };

    return ['$simpleFileUploadService','$dictionaryUtilsService', '$genericUtilsService', '$stringUtilsService', '$resource', '$requestUtilsService','$filter', '$alertUiService', CaseActionsPhoneService];
});