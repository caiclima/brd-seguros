define([], function() {

    var CaseActionsQuestionnaireService = function($filter, $dictionaryUtils, $genericUtils, $stringUtils) {

        var fieldRelation = function() {
            var obj = {};
            obj[$dictionaryUtils._answerType_OneLine]        = "INPUT";
            obj[$dictionaryUtils._answerType_MultLine]       = "TEXTAREA";
            obj[$dictionaryUtils._answerType_SingleChoice]   = "COMBOBOX";
            obj[$dictionaryUtils._answerType_MultipleChoice] = "CHECKBOX";
            return obj;
        }();

        var filterRelation = function() {
            var obj = {};
            obj[$dictionaryUtils._contentType_Text]    = "TEXT";
            obj[$dictionaryUtils._contentType_Date]    = "DATE";
            obj[$dictionaryUtils._contentType_Integer] = "INTEGER";
            obj[$dictionaryUtils._contentType_Decimal] = "DECIMAL";
            return obj;
        }();

        function getField(answerType) {
            return fieldRelation[answerType];
        }

        function getFilter(contentType) {
            return filterRelation[contentType];
        }

        return {
            format: function(questionnaire) {
                var prettyList = [];

                for(var it=0; it<questionnaire.length; ++it) {
                    var item = questionnaire[it];

                    var prettyQuestion = {};
                    prettyQuestion.question = item[$dictionaryUtils._description];
                    prettyQuestion.questionId = item[$dictionaryUtils._questionId];
                    prettyQuestion.answer = item[$dictionaryUtils._defaultAnswer];
                    prettyQuestion.required = item[$dictionaryUtils._required];

                    prettyQuestion.requirementMessage = function(item) {
                        var requirementMessage = item[$dictionaryUtils._requirementMessage];
                        requirementMessage = $stringUtils.concatenate(
                            $filter('translate')('bundle.cad.CASE_QUESTION_REQUIRED'),
                            requirementMessage !== undefined ? $stringUtils.concatenate(': ', requirementMessage) : ''
                        );
                        return requirementMessage;
                    }(item);
                    

                    prettyQuestion.isChild = function(item) {
                        return !$genericUtils.isNull(item[$dictionaryUtils._questionParentId]);
                    }(item);

                    prettyQuestion.availableAnswers = function(item) {
                        var objAnswers = {};
                        if(!$genericUtils.isNull(item[$dictionaryUtils._availableAnswers_Ew])) {
                            var answers = item[$dictionaryUtils._availableAnswers_Ew].split(";");                        
                            for(var it = 0; it < answers.length; ++it) {
                                var answerIt = answers[it];
                                objAnswers[answerIt] = answerIt;
                            }    
                        }
                        return objAnswers;
                    }(item);

                    prettyQuestion.field = function(item) {
                        var answerType = item[$dictionaryUtils._answerType];                        
                        return getField(answerType);
                    }(item);

                    prettyQuestion.filter = function(item) {
                        var contentType = item[$dictionaryUtils._contentType];
                        if(!$genericUtils.isNull(contentType)) {
                            return getFilter(contentType);
                        }
                    }(item);

                    void function caseMultiAnswerQuestion(prettyQuestion) {
                        if(prettyQuestion.field === 'CHECKBOX') {
                            prettyQuestion.multiAnswer = {};
                            for(var answer in prettyQuestion.availableAnswers) {
                                var checked = answer == prettyQuestion.answer;
                                prettyQuestion.multiAnswer[answer] = checked;
                            }
                        }
                    }(prettyQuestion);

                    void function caseChildQuestion(item, prettyQuestion) {
                        if(prettyQuestion.disabled = prettyQuestion.isChild) {
                            prettyQuestion.childFields = {
                                parentId: item[$dictionaryUtils._questionParentId],
                                operator: item[$dictionaryUtils._presentationOperator],
                                answer:  item[$dictionaryUtils._presentationAnswer],
                            };
                        }
                    }(item, prettyQuestion);
                    
                    
                    prettyList.push(prettyQuestion);
                }

                return prettyList;
            },

            getElValue: function(elModel) {
                if(elModel.field == 'CHECKBOX') {
                    var multiVal = '';
                    jQuery.each(elModel.multiAnswer, function(answerText, answerStatus) {
                        if(answerStatus) {
                            if(multiVal !== '') {
                                multiVal = $stringUtils.concatenate(multiVal, ';', answerText);
                            } else {
                                multiVal = answerText;
                            }
                        }
                    });
                    return multiVal;
                } else {
                    return elModel.answer;
                }
            },

            isMultiAnswerQuestion: function(elModel) {
                return elModel.field == 'CHECKBOX';
            },

            isDateQuestion: function(elModel) {
                return elModel.field == 'INPUT' && elModel.filter == 'DATE';
            },

            isSpecialValidationQuestion: function(elModel) {
                return (
                        (elModel.field == 'INPUT' && elModel.filter == 'DATE')
                        ||
                        (elModel.field == 'COMBOBOX')
                        ||
                        (elModel.field == 'CHECKBOX')
                       );
            },

            isNullQuestionnaire: function(questionnaire) {
                return $genericUtils.isNull(questionnaire[$dictionaryUtils._questionnaireId]);
            }
        };
    };

    return ['$filter','$dictionaryUtilsService', '$genericUtilsService', '$stringUtilsService', CaseActionsQuestionnaireService];
});