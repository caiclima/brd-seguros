define([],function() {   
    var CaseActionsRestService = function($resource, $requestUtils, $stringUtils, $dicUtils, $fileUploadService) {
        var defaultResource = function(uri, paramDefaults) {
            var path = $requestUtils.contextPath();
            var url = $stringUtils.concatenate(path, uri);
            return $resource(
                url,
                paramDefaults,
                {
                    updateCase: {
                        method: 'PUT',
                        params: paramDefaults
                    }
                }
            );
        };
        var send = function(uri, payload, _succesFn, _errorFn) {
            var path = $requestUtils.contextPath();
            var url = $stringUtils.concatenate(path, uri);

            $fileUploadService.upload(url, payload, function(response){
                 if(response == undefined || response.error == undefined){
                    _succesFn(response);
                 }else{
                    _errorFn(response);
                 }
            });
        };
        return {
            end: function(payload, _succesFn, _errorFn) {
                var uri = '/api/action/finishCases';                
                send(uri, payload, _succesFn, _errorFn);
            },
            
            note: function(payload, _succesFn, _errorFn) {
                var actionId = payload[$dicUtils._actionId];
                var uri = $stringUtils.format('/api/action/noteActionCases/{0}', actionId);

                send(uri, payload, _succesFn, _errorFn);
            },
            
            editCase: function(payload, _succesFn, _errorFn) {
                var actionId = payload[$dicUtils._actionId];
                var uri = $stringUtils.format('/api/action/case/edit/{0}', actionId);
                
                send(uri, payload, _succesFn, _errorFn);
            },

            externalPendency: function(payload, _succesFn, _errorFn) {                
                var actionId = payload[$dicUtils._actionId];
                var uri = $stringUtils.format('/api/action/pendingAnotherArea/{0}', actionId);

                send(uri, payload, _succesFn, _errorFn);
            },

            categorizeCase: function(payload, _succesFn, _errorFn) {
                var actionId = payload[$dicUtils._actionId];
                var uri = $stringUtils.format('/api/action/categorizecase/:{0}', actionId);

                send(uri, payload, _succesFn, _errorFn);
            },

            sendMail: function(payload, _succesFn, _errorFn) {
                var uri = '/api/action/sendemail';
                send(uri, payload, _succesFn, _errorFn);
            },

             sendMailTemplate: function(payload, _succesFn, _errorFn) {
                var uri = '/api/action/template/sendemail';
                send(uri, payload, _succesFn, _errorFn);
            },

            saveChecklist: function(payload, successFn, errorFn) {
                var uri = '/api/checklist/savechecklist';

                return $resource($requestUtils.contextPath() + uri, {}, {
                    'saveChecklist': {
                        method: 'PUT'
                    }
                }).saveChecklist(payload, successFn, errorFn);
            },

            saveQuestionnaire: function(payload, successFn, errorFn) {
                var uri = '/api/questionnaire/saveissue';

                return $resource($requestUtils.contextPath() + uri, {}, {
                    'saveQuestionnaire': {
                        method: 'PUT'
                    }
                }).saveQuestionnaire(payload, successFn, errorFn);
            },
            
            allowsAttachment: function(urlParams, successFn, errorFn) {
                var path = $requestUtils.contextPath();
                var url = $stringUtils.concatenate(path, $stringUtils.format('/api/action/allowsAttachment/:{0}', $dicUtils._actionId));

                var paramDefaults = {};
                paramDefaults[$dicUtils._actionId] = $stringUtils.format('@{0}', $dicUtils._actionId);

                return $resource(url, paramDefaults).get(urlParams, successFn, errorFn);
            }
        };
    }
   return [
            '$resource', 
            '$requestUtilsService', 
            '$stringUtilsService', 
            '$dictionaryUtilsService',
            '$simpleFileUploadService',
            CaseActionsRestService
        ];
});