define(
    [
        'angular', 
        'CaseAssociateViewController',
        'CaseAssociateViewDirective', 
        'CaseAssociateRestService',
        'CaseAssociatePrettyFormatService'
    ], 

	function(angular,
            CaseAssociateViewController,
            CaseAssociateViewDirective, 
            CaseAssociateRestService,
            CaseAssociatePrettyFormatService){
        
		var _m = angular.module('CaseAssociateModule', [ 
                                                        'pascalprecht.translate',
                                                        'ngCookies',
                                                        'ngResource',
                                                        'UtilsModule',
                                                        'UiModule'
                                                      ]);

		_m.directive('caseAssociateView',CaseAssociateViewDirective );
		_m.controller('CaseAssociateViewController', CaseAssociateViewController);
        _m.factory('$caseAssociateRestService', CaseAssociateRestService);
        _m.factory('$caseAssociatePrettyFormatService', CaseAssociatePrettyFormatService);

		
		return _m;
});