define([], function() {

	var CaseAssociateViewController = function($rootScope, $scope, $location, $restService, $dictionaryUtils, $caseViewRestService, $caseAssociatePrettyFormatService, $genericUtils, $eventNaming, $caseCheckerUtils, $alert, $filter) {

		declareScopedFunctions();

		
		var namespace = $rootScope.Namespace;        
        if(namespace.Loaded) {
        	$scope.userId = namespace.User[$dictionaryUtils._userId];
            $scope.query($scope.userId, namespace.Case.Current.idCaso, namespace.Case.Current.idOperacao);
        }

        function declareScopedFunctions() {
            var success = function(result){
            	if(!$scope.view){
        			$scope.view = [];
        		}
            	result = $caseAssociatePrettyFormatService.format(result);
                $scope.view.push.apply($scope.view, result);

            };

            var fail = function(msg){
                $alert.error(msg.data ? msg.data.error : msg.error);
               
            };

            $scope.query = function(userId, idCase, idOperation) {
                $restService.query(userId, idCase, idOperation,success,fail);
            }


        }

	};

	return [
        "$rootScope", 
        "$scope",
        "$location",
        "$caseAssociateRestService", 
        "$dictionaryUtilsService",
        '$caseViewRestService',
        "$caseAssociatePrettyFormatService",
        "$genericUtilsService",
        "$eventNamingUtilsService",
        '$caseCheckerUtilsService',
        '$alertUiService',
        '$filter',
        CaseAssociateViewController];
});