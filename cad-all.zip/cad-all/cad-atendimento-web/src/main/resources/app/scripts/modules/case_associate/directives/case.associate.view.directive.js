
define( [ ], function()
		{            
		    return ['$translate', '$compile',function($translate, $compile){
		    	 return {
		            restrict: 'A',
		            replace: true,
		            templateUrl: 'app/scripts/modules/case_associate/directives/templates/case.associate.view.html',
		            link: function(scope, element, attrs) {
		                /*
		                *  Create and load table asynchronously
		                */
		                $translate(['bundle.cad.ID',
		                            'bundle.cad.EXTERNAL_ID',
		                            'bundle.cad.OPERATION',                             
		                            'bundle.cad.QUEUE', 
		                            'bundle.cad.CASE_TYPE',
		                            'bundle.cad.EVENT',
		                            'bundle.cad.CHANNEL',
		                            'bundle.cad.STATUS',
		                            'bundle.cad.SLA',
		                            'bundle.cad.ACTION',
		                            'bundle.cad.CASE_ASSOCIATE'])

		                .then(function(labels) {

		                    scope.config = [{
		                        title: labels['bundle.cad.ID'],
		                        breakWord: false
		                    },{
		                        title: labels['bundle.cad.EXTERNAL_ID'],
		                        breakWord: false
		                    },{
		                        title: labels['bundle.cad.OPERATION'],
		                        width: '10%'
		                    }, {
		                        title: labels['bundle.cad.QUEUE'],
                                type: 'labelQueue',
                                width: '12%'
		                    }, {
		                        title: labels['bundle.cad.CASE_TYPE'],
		                        width: '10%'
		                    }, {
		                        title: labels['bundle.cad.EVENT'],
		                        width: '10%'
		                    }, {
		                        title: labels['bundle.cad.CHANNEL'],
		                    	width: '10%'
		                    }, {
		                        title: labels['bundle.cad.STATUS'],
                                type: 'label',
		                        width: '15%'
		                    }, {
		                        title: labels['bundle.cad.SLA'],
		                        type: 'icon-color',
		                        breakWord: false
		                    }];

		                    scope.msg = labels['bundle.cad.CASE_ASSOCIATE'];

		                    var tableEl = '<div table config="config" datasource="view" searchable="true" context="{{msg}}"></div>';
		                    $('div#associateView').replaceWith($compile(tableEl)(scope));
		                });             
		            }
		        };
		    }];
		});