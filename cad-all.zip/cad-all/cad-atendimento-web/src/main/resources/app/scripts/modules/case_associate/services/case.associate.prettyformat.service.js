define([],
    function () {
        return ["$dictionaryUtilsService",
            function ($Dic) {
                return {
                    format: function (objectList) {
                        var prettyList = [];
                        for (var it = 0; it < objectList.length; ++it) {
                            var object = objectList[it];
                            var pretty = {
                                caseId: object[$Dic._caseId],
                                externalId: object[$Dic._externalId],
                                operation: object[$Dic._operation],
                                queue : {
                                    title : object[$Dic._queueConfig],
                                    color : object[$Dic._filaColor]
                                },
                                manifestationType: object[$Dic._caseType],
                                events: object[$Dic._event],
                                channel: object[$Dic._channel],
                                status : {
                                    title : object[$Dic._status],
                                    color : object[$Dic._statusColor]
                                },
                                sla: {
                                    title: object[$Dic._slaInMinutes],
                                    color: object[$Dic._slaIcon]
                                }
                            };
                            prettyList.push(pretty);
                        }
                        return prettyList;
                    }
                };
            } ];
    });