define([], function(){

    var CaseAssociateRestService = function($resource, $requestUtils, $stringUtils, $dictionaryUtils) {

        var queryResource = function () {
        	 var userId = $dictionaryUtils._userId;
             var caseId = $dictionaryUtils._caseId;
             var operationId = $dictionaryUtils._operationId;
             
             var uri = $stringUtils.format("/api/cases/associate/:{0}/:{1}/:{2}", userId, caseId, operationId);

             var paramDefaults = {};
             paramDefaults[userId] = $stringUtils.format('@{0}', userId);
             paramDefaults[caseId] = $stringUtils.format('@{0}', caseId);
             paramDefaults[operationId] = $stringUtils.format('@{0}', operationId);
             
             return resource = $resource($requestUtils.contextPath() + uri, paramDefaults);
        }
        
        return {
        	 query: function( userId, idCase, idOperation, successFn, errorFn) {
                 var urlParams = {};
                 urlParams[$dictionaryUtils._userId]  = userId;
                 urlParams[$dictionaryUtils._caseId]  = idCase;
                 urlParams[$dictionaryUtils._operationId] = idOperation;

                 queryResource().query(urlParams, successFn, errorFn);
             },
        };
    };

    return [
        "$resource",
        "$requestUtilsService",
        "$stringUtilsService",
        "$dictionaryUtilsService",
        CaseAssociateRestService
    ];
});