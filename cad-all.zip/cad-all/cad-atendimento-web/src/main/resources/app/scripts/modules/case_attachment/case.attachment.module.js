/*
 * module definitions 
 */
define(['angular', 'CaseAttachmentPrettyFormatService', 'CaseAttachmentDirective' ],
	function(angular, CaseAttachmentPrettyFormatService, CaseAttachmentDirective){
		var _m = angular.module('CaseAttachmentModule', [
													   'pascalprecht.translate'
													  ,'ngCookies'
													  ,'UiModule']);

        _m.directive('caseAttachment', CaseAttachmentDirective );     
        _m.factory('$caseAttachmentFormatService', CaseAttachmentPrettyFormatService);   
		return _m;
});