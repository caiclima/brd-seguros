define( [ ], function()
{            
    return ['$filter', function($filter){           
         return {
            restrict: 'A',
            templateUrl: 'app/scripts/modules/case_attachment/directives/templates/case.attachment.html',
            scope: {
                datasource: '=',
                context: '@',
                isActionDelete: '=?'
            },
            link: function (scope, element, attrs) {

                if (scope.isActionDelete != undefined) {
                    scope.tableConfig = [{
                        width: '5%',
                        type: 'button',
                        icon: 'icon-22-3'
                    }, {
                        title: $filter('translate')('bundle.cad.ARCHIVE'),
                        width: '60%'
                    }, {
                        type: 'button-toogle',
                        icon: 'icon-21-8',
                        width: '5%'
                    }];
                } else {
                    scope.tableConfig = [{
                        width: '5%',
                        type: 'button',
                        icon: 'icon-22-3'
                    }, {
                        title: $filter('translate')('bundle.cad.ARCHIVE'),
                        width: '95%'
                    }];
                }

               
            }
        };
    }];
});