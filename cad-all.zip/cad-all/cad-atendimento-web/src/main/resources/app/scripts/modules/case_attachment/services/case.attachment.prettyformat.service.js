define([], function () {
    return [
        '$dictionaryUtilsService'
        , '$alertUiService'
        , '$stringUtilsService'
        , '$requestUtilsService'
        , function ($dic, $alert, $stringUtils, $requestUtils) {
            return {
                format: function (objectList) {
                    var attachments = [];

                    if (objectList) {
                        var queryString = '';

                        $.each(objectList, function (index, item) {
                            var entry = {};
                            entry.download = {
                                _uri: $stringUtils.format('/api/download/attachment/{0} ', item[$dic._attachmentId]),
                                action: function () {
                                    $('iframe.force-download').attr('src', $requestUtils.contextPath() + this._uri);
                                }
                            };
                            entry.realName = item[$dic._realNameAttachment];
                            attachments.push(entry);
                        });
                    }
                    return attachments;
                },

                toEditAttachment: function (objectList) {
                    var attachments = [];

                    if (objectList) {
                        var queryString = '';

                        $.each(objectList, function (index, item) {
                            var entry = {};
                            entry.download = {
                                _uri: $stringUtils.format('/api/download/attachment/{0} ', item[$dic._attachmentId]),
                                action: function () {
                                    $('iframe.force-download').attr('src', $requestUtils.contextPath() + this._uri);
                                }
                            };
                            entry.realName = item[$dic._realNameAttachment];
                            entry.model = {
                                isActive: item[$dic._isActive],
                                show: true,
                                action: function (e) {
                                    this.isActive = false;
                                    $(e.target).closest('tr').html("");
                                }
                            };
                            attachments.push(entry);
                        });
                    }
                    return attachments;
                }

            };
        }];
});