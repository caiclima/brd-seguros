/*
 * module definitions 
 */
define(['angular', 'CaseClientController', 'CaseClientFormatService','CaseClientCommonsService', 'CaseClientRestService','CaseClientDirective' ],
	function(angular, CaseClientController, CaseClientFormatService,CaseClientCommonsService, CaseClientRestService, CaseClientDirective){
		var _m = angular.module('CaseClientModule', [
													   'ngResource'
													  ,'UtilsModule'
													  ,'pascalprecht.translate'
													  ,'ngCookies'
													  ,'UiModule']);

        _m.directive('caseClient', CaseClientDirective );
        _m.factory('$caseClientRestService', CaseClientRestService);
        _m.factory('$caseClientCommonsService', CaseClientCommonsService);
        _m.factory('$caseClientFormatService', CaseClientFormatService);
        _m.controller('CaseClientController', CaseClientController);
        
		return _m;
});