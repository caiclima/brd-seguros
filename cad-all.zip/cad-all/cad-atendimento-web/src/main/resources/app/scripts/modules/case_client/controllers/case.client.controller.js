define([], function() {

    var CaseClientController = function($scope, $rootScope, $filter, $caseClientFormatService, $caseClientCommonsService, $caseClientRestService, $dic, $alert,$casePendencyRestService, $casePendencyFormat, $location, $caseCheckerUtils) {
        $scope.datasource  = [];
        $scope.delegate    = {};
        $scope.credentials = {};
        $scope.credentials = {
            loginMaster   : '',
            passwordMaster: ''
        };

        $scope.queryHistoryClient = function(){
            $scope.datasource = [];
            
            var urlParams = {};
            urlParams[$dic._caseId] = $rootScope.Namespace.Case.Current[$dic._caseId];                

            $caseClientRestService.getAll().query(urlParams,
                function(history) {
                    $scope.datasource = $caseClientFormatService.format(history, $rootScope.Namespace.User[$dic._userId]);
                }, 
                function(msg){
                    $alert.error(msg.data ? msg.data.error : msg.error);                       
                });
        };

        $scope.approvalAndDelegateCase = function(){
            $scope.delegate[$dic._cases]          = getSelectedCases();
            $scope.delegate[$dic._userId]         = $rootScope.Namespace.User[$dic._userId];   
            $scope.delegate[$dic._loginMaster]    = $scope.credentials.loginMaster;
            $scope.delegate[$dic._passwordMaster] = $scope.credentials.passwordMaster;
            
            var urlParams = {};
            urlParams[$dic._userId] = $rootScope.Namespace.User[$dic._userId];    

            $caseClientRestService.delegate().delegateCase(urlParams, $scope.delegate,
                onSuccess, 
                function(msg){
                    $alert.error(msg.data ? msg.data.error : msg.error);     
                });
        };

        $scope.delegateCase = function(){
            var cases  = getSelectedCases();
            var userId = $rootScope.Namespace.User[$dic._userId];  
            $caseClientCommonsService.confirmAndDelegateCase(cases, userId, onSuccess);
        };

        var onSuccess = function(content){
            $scope.queryHistoryClient();
            $alert.success($filter('translate')('bundle.cad.SUCCESS'));
            $casePendencyRestService.queryDefault($rootScope.Namespace.User[$dic._userId], function(pendingCases) {
            	pendingCases = $casePendencyFormat.format(pendingCases);
            	$rootScope.Namespace.Case.Pending.ChangePendingCases(pendingCases);
            },
            function(msg) {
                $alert.error(msg.data ? msg.data.error : msg.error);
            });
        }

        var getSelectedCases = function(){
            var _selectedCases  = [];
            $.each($scope.datasource, function( index, item ) {
                if(item.check.selected){
                   _selectedCases.push(item.caseId);
                }
            }); 
            return _selectedCases;           
        };

        $scope.queryHistoryClient();
    };

    return [
        "$scope"
      , "$rootScope"
      , "$filter" 
      , "$caseClientFormatService"
      , '$caseClientCommonsService'
      , "$caseClientRestService"
      , "$dictionaryUtilsService"
      , "$alertUiService"
      ,"$casePendencyRestService"
      ,"$casePendencyPrettyFormatService"
      ,"$location"
      ,"$caseCheckerUtilsService"
      , CaseClientController];

});