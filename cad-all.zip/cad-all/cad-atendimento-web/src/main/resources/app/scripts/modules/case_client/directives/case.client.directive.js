define( [ ], function()
{            
    return ['$filter', function($filter){           
         return {
            restrict: 'A',
            templateUrl: 'app/scripts/modules/case_client/directives/templates/case.client.html',
            scope: {
                datasource:                    '=',
                delegateCaseAction:            '=',
                credential:                    '=',
                approvalAndDelegateCaseAction: '='
            },
            link: function(scope,element, attrs) {
               scope.tableConfig = [{
                    type: 'check' 
               },{
                   title: $filter('translateNamespace')('bundle.cad.idCaso','OperacaoAtual'),
                   breakWord: false
               },{
                   title: $filter('translateNamespace')('bundle.cad.idExterno','OperacaoAtual'),
                   breakWord: false
               },{
                    title: $filter('translate')('bundle.cad.DATE'),
                    type: 'icon-text',
                    icon: 'icon-calendar',
                    date: true,
                    breakWord: false
                },{
                   title:  $filter('translateNamespace')('bundle.cad.usuario','OperacaoAtual'),
                   type: 'icon-text-default',
                   icon: 'icon-user',
                   default: "CAD"
                },{
                   title: $filter('translateNamespace')('bundle.cad.configuracaoFila','OperacaoAtual'),
                   width: '12%'
                },{
                   title: $filter('translateNamespace')('bundle.cad.tipoCaso','OperacaoAtual'),
                   width: '10%'
                },{
                   title: $filter('translate')('bundle.cad.EVENT'),
                   width: '10%'
                },{
                   title: $filter('translateNamespace')('bundle.cad.canal','OperacaoAtual'),
                   width: '10%'
                },{
                   title: $filter('translateNamespace')('bundle.cad.status','OperacaoAtual'),
                   type: "label",
                   breakWord: false
                },{
                    title: $filter('translate')('bundle.cad.SLA'),
                    type: 'icon-color',
                    breakWord: false
                }];
            }
        };
    }];
});