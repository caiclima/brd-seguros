define([], function() {
    return ['$q', '$caseClientRestService', '$dictionaryUtilsService', '$alertUiService',
        function($q, $caseClientRestService, $dic, $alert) {
            var _exceptionFn = function(msg) {
                $alert.error(msg.data ? msg.data.error : msg.error);
            };

            return {
                confirmAndDelegateCase: function(cases, userId, fnAfterDelegate) {
                    this._requiresPasswordMaster(cases, userId, fnAfterDelegate)
                            .catch(_exceptionFn)
                        .then(this._confirmAndDelegateCase)
                            .catch(_exceptionFn);

                },

                _requiresPasswordMaster: function(cases, userId, fnAfterDelegate) {
                    var validatePromise = $q.defer();

                    var delegate = {};
                    delegate[$dic._cases] = cases;
                    delegate[$dic._userId] = userId;

                    var urlParams = {};
                    urlParams[$dic._userId] = userId;    

                    $caseClientRestService.confirmation().requiresPasswordMaster(urlParams,delegate,
                        function(confirm){
                             validatePromise.resolve( {
                                delegate: delegate,
                                afterDelegate: fnAfterDelegate,
                                confirm: confirm[$dic._value]
                            });
                        },
                        function(msg){
                            validatePromise.reject(msg);                       
                        });

                    return validatePromise.promise;                
                },

                _confirmAndDelegateCase: function(resolved) {
                    if(resolved){
                        if(resolved.confirm){
                            $('#modalApproval').modal({
                                show: true
                            });

                        }else{
                            var urlParams = {};
                            urlParams[$dic._userId] = resolved.delegate[$dic._userId];

                            $caseClientRestService.delegate().delegateCase(urlParams, resolved.delegate,
                                resolved.afterDelegate, _exceptionFn);
                        }
                    }
                }
            };
    }];
});