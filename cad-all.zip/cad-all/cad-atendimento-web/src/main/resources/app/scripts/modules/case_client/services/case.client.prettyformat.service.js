define([], function() {
    return ['$location', '$dictionaryUtilsService', '$stringUtilsService', function($location, $dic, $stringUtils) {
        return {
            format: function(objectList, userId) {
                var prettyList = [];
                for(var it = 0; it < objectList.length; ++it) {
                    var item  = objectList[it];

                    var prettyEntry = {}; 
                    prettyEntry.check = {
                      selected: false,
                      disabled: item[$dic._isFinalized] || item[$dic._userId] == userId
                    };
                    prettyEntry.caseId        = item[$dic._caseId];
                    prettyEntry.externalId    = item[$dic._externalId];
                    prettyEntry.openingDate   = item[$dic._openingDate];
                    prettyEntry.user          = item[$dic._user];
                    prettyEntry.queueConfig   = item[$dic._queueConfig];
                    prettyEntry.caseType      = item[$dic._caseType];
                    prettyEntry.event         = item[$dic._event];
                    prettyEntry.channel       = item[$dic._channel];
                    prettyEntry.status        = {
                        title: item[$dic._status],
                        color: item[$dic._statusColor]
                    };
                    prettyEntry.slaInMinutes  = {
                        title: item[$dic._slaInMinutes],
                        color: item[$dic._slaIcon]
                    };
                                               
                    prettyList.push(prettyEntry);                           
                }                        
                return prettyList;
            }
        };
    }];
});