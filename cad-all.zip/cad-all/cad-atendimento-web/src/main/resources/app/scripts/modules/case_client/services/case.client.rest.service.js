define( [ ], function()
{
    var CaseClientRestService = function($resource, $stringUtils, $requestUtils, $dictionaryUtils)
    {
        return {       
            getAll: function(){
                var idCaso = $dictionaryUtils._caseId;
                var paramDefaults = {};
                paramDefaults[idCaso] = $stringUtils.format('@{0}',idCaso);       

                var uri = $stringUtils.format('/api/casesAttend/clientgroupedcases/:{0} ', idCaso);
                return $resource($requestUtils.contextPath() + uri, paramDefaults);
            },
            confirmation: function() {
                var idUsuario = $dictionaryUtils._userId;
                var paramDefaults = {};
                paramDefaults[idUsuario] = $stringUtils.format('@{0}',idUsuario);  

                var uri = $stringUtils.format('/api/cases/requirespasswordmaster/user/:{1}', idUsuario);
                return $resource($requestUtils.contextPath() + uri, paramDefaults, {
                    'requiresPasswordMaster': { method:'PUT', params: paramDefaults }
                });
            },
            delegate: function() {
                var idUsuario = $dictionaryUtils._userId;
                var paramDefaults = {};
                paramDefaults[idUsuario] = $stringUtils.format('@{0}',idUsuario);  

                var uri = $stringUtils.format('/api/cases/delegatecase/user/:{0}', idUsuario);
                return $resource($requestUtils.contextPath() + uri, paramDefaults, {
                    'delegateCase': { method:'PUT', params: paramDefaults }
                });
            }  
        }
    };

    return [
        "$resource",
        "$stringUtilsService",
        "$requestUtilsService",
        "$dictionaryUtilsService",
        CaseClientRestService
    ];
});