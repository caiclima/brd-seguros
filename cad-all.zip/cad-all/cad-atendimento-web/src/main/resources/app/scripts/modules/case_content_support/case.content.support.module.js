/*
 * module definitions 
 */
define(['angular', 'CaseContentSupportController', 'CaseContentSupportRestService','CaseContentSupportDirective'],
	function(angular, CaseContentSupportController, CaseContentSupportRestService, CaseContentSupportDirective){
		var _m = angular.module('CaseContentSupportModule', [
													   'ngResource'
													  ,'UtilsModule'
													  ,'pascalprecht.translate'
													  ,'ngCookies'
													  ,'UiModule']);

        _m.directive('contentSupport', CaseContentSupportDirective );
        _m.factory('$caseContentSupportRestService', CaseContentSupportRestService);
        _m.controller('CaseContentSupportController', CaseContentSupportController);
        
		return _m;
});