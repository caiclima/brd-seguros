define([], function() {

    var CaseContentSupportController = function($scope, $rootScope, $caseAttachmentFormatService, $caseContentSupportRestService, $stringUtils, $dic, $alert) {
        $scope.contentSupport  = {};
        $scope.attachments = [];
        
        $scope.getContentSupport = function(){            
            var urlParams = {};
            urlParams[$dic._caseId] = $rootScope.Namespace.Case.Current[$dic._caseId];                

            $caseContentSupportRestService.get(urlParams,
                function(content) {
                    $scope.contentSupport = {};
                    if(content && content[$dic._description]){
                       $scope.contentSupport.description = $stringUtils.replaceAll(content[$dic._description], "\"", "'");
                    }
                    if(content && content[$dic._attachments]){
                      $scope.attachments = $caseAttachmentFormatService.format(content[$dic._attachments]);
                    }
                }, 
                function(msg){
                    $alert.error(msg.data ? msg.data.error : msg.error);                       
                });
        };
        $scope.getContentSupport();
    };

    return [
        "$scope"
      , "$rootScope"
      , "$caseAttachmentFormatService"
      , "$caseContentSupportRestService"
      , "$stringUtilsService"
      , "$dictionaryUtilsService"
      , "$alertUiService"
      , CaseContentSupportController];

});