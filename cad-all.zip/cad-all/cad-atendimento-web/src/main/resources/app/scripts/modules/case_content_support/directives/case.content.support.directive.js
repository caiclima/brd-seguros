define( [ ], function()
{            
    return [function(){           
         return {
            restrict: 'A',
            replace: true,
            templateUrl: 'app/scripts/modules/case_content_support/directives/templates/case.content.support.html',
            scope: {
                content: '=',
                context: '@'
            },
            link: function(scope, element, attrs) {
            	var unwatch = scope.$watch('content', function(newVal, oldVal){
                    if(newVal === oldVal){
                        return;
                    } 
                    if(newVal){
                        $('.html-content').html(newVal);
                    }
                    
                    unwatch();
                });
            }
        };
    }];
});