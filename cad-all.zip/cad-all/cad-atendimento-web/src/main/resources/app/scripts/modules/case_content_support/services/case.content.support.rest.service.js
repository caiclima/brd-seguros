define( [ ], function()
{
    var CaseContentSupportRestService = function($resource, $stringUtils, $requestUtils, $dictionaryUtils)
    {
        var caseId = $dictionaryUtils._caseId;
        var paramDefaults = {};
        paramDefaults[caseId] = $stringUtils.format('@{0}',caseId);  

        var uri = $stringUtils.format('/api/cases/findcontentsupportbycase/:{0}', caseId);
        return $resource($requestUtils.contextPath() + uri, paramDefaults);      
    };

    return [
        "$resource",
        "$stringUtilsService",
        "$requestUtilsService",
        "$dictionaryUtilsService",
        CaseContentSupportRestService
    ];
});