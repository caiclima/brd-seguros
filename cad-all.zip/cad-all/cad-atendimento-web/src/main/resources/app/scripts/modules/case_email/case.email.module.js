/*
 * module definitions 
 */
define(['angular', 'CaseEmailController', 'CaseEmailContentController', 'CaseEmailReplyController', 'CaseEmailFowardController', 'CaseEmailPrettyFormatService', 'CaseEmailRestService', 'CaseEmailDirective', 'CaseEmailContentDirective', 'CaseEmailReplyDirective', 'CaseEmailFowardDirective'],
	function (angular, CaseEmailController, CaseEmailContentController, CaseEmailReplyController, CaseEmailFowardController, CaseEmailPrettyFormatService, CaseEmailRestService, CaseEmailDirective, CaseEmailContentDirective, CaseEmailReplyDirective, CaseEmailFowardDirective) {
		var _m = angular.module('CaseEmailModule', [
													   'ngResource'
													  ,'UtilsModule'
													  ,'pascalprecht.translate'
													  ,'ngCookies'
													  ,'UiModule']);

        _m.directive('caseEmail', CaseEmailDirective );
        _m.directive('emailContent', CaseEmailContentDirective );
        _m.directive('emailReply', CaseEmailReplyDirective);
        _m.directive('emailFoward', CaseEmailFowardDirective);

        _m.factory('$caseEmailPrettyFormatService', CaseEmailPrettyFormatService);
        _m.factory('$caseEmailRestService', CaseEmailRestService);

        _m.controller('CaseEmailController', CaseEmailController);
        _m.controller('CaseEmailContentController', CaseEmailContentController);
        _m.controller('CaseEmailReplyController', CaseEmailReplyController);
        _m.controller('CaseEmailFowardController', CaseEmailFowardController);

        
		return _m;
});