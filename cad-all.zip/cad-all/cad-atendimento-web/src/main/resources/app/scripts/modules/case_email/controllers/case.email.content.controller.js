    define([], function() {

        var CaseEmailContentController = function ($scope, $location, $routeParams, $caseEmailRestService, $caseAttachmentFormatService, $dic, $alert, $rootScope, $dictionaryUtils) {
            $scope.email = {};

            $scope.emailId = $routeParams.emailId;
            if(!$scope.emailId) {
                $location.path("/");
                return;
            }         
            $scope.hasPrivilegeReplyEmail = $rootScope.Namespace.Case.Current[$dictionaryUtils._hasPrivilegeReplyEmail];
            $scope.hasPrivilegeFowardEmail = $rootScope.Namespace.Case.Current[$dictionaryUtils._hasPrivilegeFowardEmail];
            $scope.getContent = function(){
                $scope.email = {};
                
                var urlParams = {};
                urlParams[$dic._emailId] = $scope.emailId;
              
                $caseEmailRestService.getContent().readEmail(urlParams, $scope.emailId,
                    function(content){
                        $scope.email = {
                            emailId: content[$dic._emailId],
                            subject: content[$dic._subject],
                            sentDate: content[$dic._sentDate],
                            from: content[$dic._from],
                            to: content[$dic._to],
                            carbonCopy: content[$dic._carbonCopy],
                            emailContent: content[$dic._emailContent],
                            attachments: $caseAttachmentFormatService.format(content[$dic._attachments])
                        };

                    }, function(msg){
                        $alert.error(msg.data ? msg.data.error : msg.error);     
                    });
            }();
        };

        return ["$scope", 
                "$location", 
                "$routeParams", 
                "$caseEmailRestService", 
                "$caseAttachmentFormatService", 
                "$dictionaryUtilsService",
                "$alertUiService",
                "$rootScope",
                "$dictionaryUtilsService",
                CaseEmailContentController];

    });