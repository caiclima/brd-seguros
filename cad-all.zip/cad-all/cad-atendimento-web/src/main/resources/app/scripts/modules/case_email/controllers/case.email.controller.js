define([], function() {

    var CaseEmailController = function($scope, $rootScope, $EmailFormatService, $caseEmailRestService, $dic, $alert) {
        $scope.prettyEmail = [];
        $scope.email = {};
        $scope.files = {};
        
        $scope.queryEmails = function(){
            $scope.prettyEmail = [];
            
            var urlParams = {};
            urlParams[$dic._caseId] = $rootScope.Namespace.Case.Current[$dic._caseId];                

            $caseEmailRestService.getAll().query(urlParams,
                function(emails) {
                    $scope.prettyEmail = $EmailFormatService.format(emails, $scope.files);                     
                }, 
                function(msg){
                    $alert.error(msg.data ? msg.data.error : msg.error);
                });
        }
        $scope.queryEmails();
    };

    return [
        "$scope"
      , "$rootScope"
      , "$caseEmailPrettyFormatService"
      , "$caseEmailRestService"
      , "$dictionaryUtilsService"
      , "$alertUiService"
      , CaseEmailController];

});