define([], function () {

    var CaseEmailFowardController = function ($rootScope, $scope, $routeParams, $location, $restService, $dataRestService, $alertUiService, $dictionaryUtils, $stringUtils, $caseAttachmentFormatService) {
        var caseId = $rootScope.Namespace.Case.Current[$dictionaryUtils._caseId];
        var userId = $rootScope.Namespace.User[$dictionaryUtils._userId];

        $scope.emailId = $routeParams.emailId;
        $scope.emailConfig = {};
        $scope.sending = undefined;
        $scope.hasAttachmentPrivilegeEmail = $rootScope.Namespace.Case.Current[$dictionaryUtils._hasAttachmentPrivilegeEmailReply];
        $scope.isActionDelete = true;
        $scope.listAttachment = {};

        if (!$scope.emailId) {
            $location.path("/");
            return;
        }

        void function getDataToResponse() {
            var urlParams = {};
            urlParams[$dictionaryUtils._emailId] = $scope.emailId;

            $restService.getContent().getDataToResponse(urlParams,
                function (content) {
                    $scope.emailConfig['content'] = content[$dictionaryUtils._emailContent];
                    $scope.emailConfig['subject'] = content[$dictionaryUtils._subject];
                    $scope.emailConfig['selectedRecipientsGroups'] = content[$dictionaryUtils._toEmailGroup];
                    $scope.emailConfig['recipients'] = content[$dictionaryUtils._from];
                    $scope.emailConfig['carbonCopyRecipients'] = content[$dictionaryUtils._carbonCopy];
                    $scope.emailConfig['attachments'] = $caseAttachmentFormatService.toEditAttachment(content[$dictionaryUtils._attachments]);
                    $scope.emailConfig['allowsGroup'] = content[$dictionaryUtils._allowsGroup];
                    $scope.emailConfig['isready'] = true;

                }, function (msg) {
                    $alertUiService.error(msg.data ? msg.data.error : msg.error);
                });
        }();

        void function fetchEmailGroups() {
            $dataRestService.fetchEmailGroups(
                caseId,
                function (groups) {
                    var prettyGrps = [];
                    for (var it = 0; it < groups.length; ++it) {
                        var group = groups[it];
                        prettyGrps.push({
                            id: group[$dictionaryUtils._emailGroupId],
                            text: group[$dictionaryUtils._description]
                        });
                    }
                    $scope.emailConfig.recipientsGroups = prettyGrps;
                },
                function (msg) {
                    $alertUiService.error(msg.data ? msg.data.error : msg.error);
                });
        }();

        $scope.findAttachment = function (attachmentId, callbackSucess, callbackError) {
            var urlParams = {};
            urlParams[$dictionaryUtils._attachmentId] = attachmentId;

            $restService.getBytesAttachment().get(urlParams,
                callbackSucess, callbackError);
        };

        $scope.fowardMail = function () {
            $scope.sending = true;

            var payload = {};
            payload[$dictionaryUtils._caseId] = caseId;
            payload[$dictionaryUtils._userId] = userId;

            payload[$dictionaryUtils._emailContent] = $scope.emailConfig.content;
            payload[$dictionaryUtils._subject] = $scope.emailConfig.subject;

            if ($scope.emailConfig.recipients !== undefined && $scope.emailConfig.recipients !== '')
                payload[$dictionaryUtils._to] = $scope.emailConfig.recipients;

            if ($scope.emailConfig.carbonCopyRecipients !== undefined && $scope.emailConfig.carbonCopyRecipients !== '')
                payload[$dictionaryUtils._carbonCopy] = $scope.emailConfig.carbonCopyRecipients;

            payload[$dictionaryUtils._toEmailGroup] = [];
            for (var it = 0; it < $scope.emailConfig.selectedRecipientsGroups.length; ++it) {
                var recipientsGroup = $scope.emailConfig.selectedRecipientsGroups[it];

                var emailGroup = {};
                emailGroup[$dictionaryUtils._emailGroupId] = parseInt(recipientsGroup);
                payload[$dictionaryUtils._toEmailGroup].push(emailGroup);
            }
            payload[$dictionaryUtils._toToView] = '';
            payload[$dictionaryUtils._fatherEmailId] = $scope.emailId;
            payload[$dictionaryUtils._attachmentList] = $scope.emailConfig.listNameArchives;

            $restService.fowardMail(
                payload
                , function (success) {
                    $location.path("/case-email");
                }, function (msg) {
                    $alertUiService.error(msg.data ? msg.data.error : msg.error);
                    $scope.sending = false;
                }
            );
        }

    };

    return ['$rootScope',
        '$scope',
        '$routeParams',
        '$location',
        '$caseEmailRestService',
        '$caseActionsDataRestService',
        '$alertUiService',
        '$dictionaryUtilsService',
        '$stringUtilsService',
        '$caseAttachmentFormatService',
        CaseEmailFowardController];
});