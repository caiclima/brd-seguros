define( [ ], function()
{            
    return ['$location', '$interval', '$stringUtilsService', function($location, $interval, $stringUtils){           
         return {
            restrict: 'A',
            templateUrl: 'app/scripts/modules/case_email/directives/templates/case.email.content.html',
            scope: {
                email: '=',
                hasPrivilegeReplyEmail: '=',
                hasPrivilegeFowardEmail:'='
            },
            link: function(scope,element, attrs) {
            	var unwatch = scope.$watch('email', function(newVal, oldVal){
                    if(newVal === oldVal){
                        return;
                    } 

                    var checker = $interval(function() {
                        if($('.html-content')) {
                            //We must check whether element is ready
                            if(newVal && newVal.emailContent){
                                $('.html-content').html(newVal.emailContent);
                            }    
                            $interval.cancel(checker);
							unwatch();
                        }
                    }, 250, 0, false);      
                });

                scope.back = function (){
                    $location.path('/case-email');
                };

                scope.reply = function (){
                    var uri = $stringUtils.format('/case-email-reply/{0}', scope.email.emailId);
                    $location.path(uri);
                };

                scope.foward = function () {
                    var uri = $stringUtils.format('/case-email-foward/{0}', scope.email.emailId);
                    $location.path(uri);
                };
            }
        };
    }];
});