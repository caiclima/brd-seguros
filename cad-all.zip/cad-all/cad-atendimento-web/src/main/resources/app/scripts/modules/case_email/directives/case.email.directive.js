define( [ ], function()
{            
    return ['$filter', function($filter){           
         return {
            restrict: 'A',
            templateUrl: 'app/scripts/modules/case_email/directives/templates/case.email.html',
            scope: {
                prettyEmail: '=',
                attachments: '=?'
            },
            link: function(scope,element, attrs) {
                scope.tableConfig = [{
                    type: 'icon-row'
                }, {
                    type: 'icon-row'
                },{
                    title: $filter('translate')('bundle.cad.EMAIL_ID'),
                    breakWord: false
                }, {
                    title: $filter('translate')('bundle.cad.EMAIL_SUBJECT'),
                    breakWord: false
                }, {
                    title: $filter('translate')('bundle.cad.DATE'),
                    type: 'icon-text',
                    icon: 'icon-calendar',
                    date: true,
                    breakWord: false
                }, {
                    title: $filter('translate')('bundle.cad.EMAIL_FROM'),
                    breakWord: false
                }, {
                    title: $filter('translate')('bundle.cad.EMAIL_TO'),
                    breakWord: false
                }, {
                    title: $filter('translateNamespace')('bundle.cad.usuario','OperacaoAtual'),
                    type: 'icon-text-default',
                    icon: 'icon-user',
                    default: "CAD"
                }, {
                    title: $filter('translate')('bundle.cad.ATTACHMENT'),
                    type: 'button-toogle',
                    icon: "icon-7-3"
                }, {
                    type: 'button',
                    icon: 'icon-search'
                }];
            }
        };
    }];
});