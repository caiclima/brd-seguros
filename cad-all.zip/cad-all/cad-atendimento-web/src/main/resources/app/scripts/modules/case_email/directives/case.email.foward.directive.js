define([], function () {
    return ['$filter', '$alertUiService', '$dictionaryUtilsService', '$interval', '$location', '$caseEmailRestService', function ($filter, $alertUiService, $dic, $interval, $location, $caseEmailRestService) {
        return {
            restrict: 'A',
            templateUrl: 'app/scripts/modules/case_email/directives/templates/case.email.foward.html',
            scope: {
                emailConfig: '=',
                sending: '=',
                sendEmail: '=',
                hasAttachmentPrivilegeEmail: '=',
                isActionDelete: '=?'
            },
            link: function (scope, element, attrs) {
                scope.tableConfig = [{
                    title: $filter('translate')('bundle.cad.ATTACHMENT'),
                    breakWord: false
                }, {
                    title: $filter('translate')('bundle.cad.DATE'),
                    type: 'icon-text',
                    icon: 'icon-calendar',
                    date: true,
                    breakWord: false
                }];

                var checker = $interval(function () {
                    if ($("#uploadp") && $('#upload-title') && $('#uploadf')) {
                        //We must check whether element is ready
                        $('#uploadp').addClass('form-group');
                        $('#upload-title').addClass('col-sm-2 control-label');
                        $('#uploadf').addClass('col-sm-10');
                        $interval.cancel(checker);
                    }
                }, 250);

                var unwatch = scope.$watch('emailConfig', function (newValue, oldValue) {
                    if (newValue === oldValue)
                        return;

                    var checker = $interval(function () {
                        if (newValue.isready && $("#emailComponent") && $('#emailRecipientsId') && $('#recipientsGroupsId')) {
                            //We must check whether element is ready
                            $('#emailComponent').htmlarea('html', newValue.content);

                            $interval.cancel(checker);
                            unwatch();
                        }
                    }, 250);

                }, true);

                scope.cancel = function () {
                    $location.path('/case-email');
                };

                scope.prepareAndSend = function () {
                    /*
                    *  Get Email content
                    */
                    scope.emailConfig.content = $('#emailComponent').htmlarea('html');
                    /*
                    *  Get Recipients Groups
                    */
                    var recipientsGroups = $('#recipientsGroupsId').select2("val");

                    if (recipientsGroups && recipientsGroups.length > 0) {
                        recipientsGroups = $.grep(recipientsGroups, function (value, index) {
                            return value !== 'undefined' && value !== '?' && value !== '';
                        });

                        scope.emailConfig.selectedRecipientsGroups = recipientsGroups;
                    } else {
                        scope.emailConfig.selectedRecipientsGroups = [];
                    }
                    /*
                    *  Get Recipients
                    */
                    scope.emailConfig.recipients = $('#emailRecipientsId').val();
                    /*
                     *  Get Recipients From Carbon Copies
                     */
                    scope.emailConfig.carbonCopyRecipients = $('#emailCarbonCopyRecipientsId').val();
                    try {
                        if (scope.emailConfig.carbonCopyRecipients && scope.emailConfig.carbonCopyRecipients.length > 4000) {
                            throw $filter('translate')('bundle.cad.CASE_EMAIL_CC_RECIPIENTS_ERROR');
                        }
                    } catch (e) {
                        $alertUiService.error(e);
                        return;
                    }

                    /*
                     *  Validate Formulary
                     */
                    try {
                        if (scope.emailConfig.selectedRecipientsGroups.length == 0
                            && scope.emailConfig.recipients == '') {
                            throw $filter('translate')('bundle.cad.CASE_EMAIL_RECIPIENTS_ERROR');
                        }
                        if (scope.emailConfig.content == '') {
                            throw $filter('translate')('bundle.cad.CASE_EMAIL_CONTENT_ERROR');
                        }
                    } catch (e) {
                        $alertUiService.error(e);
                        return;
                    }

                    /**
                     * Get id Table attachment
                     */
                    scope.emailConfig.listNameArchives = [];

                    $('#tableAttachment tr').each(function (index, value) {
                        var elemento = $(this).find("td").text().trim();

                        if (elemento !=='') {
                            scope.emailConfig.listNameArchives.push(elemento);
                        }
                        
                    });

                    /*
                    *  Send event upperwards
                    */
                    scope.sendEmail();
                };

                var unWatch1 = scope.$watch('sending', function (nV, oV) {
                    if (nV != undefined) {
                        scope.actionAttributes = {
                            disabled: nV,
                            disabledText: $filter('translate')('bundle.cad.SENDING')
                        };
                    }
                });

                $('#emailRecipientsId').tagsinput('refresh');
                $('#emailCarbonCopyRecipientsId').tagsinput('refresh');

                scope.$on('$destroy', function () {
                    unWatch1();
                });
            }
        };
    }];
});