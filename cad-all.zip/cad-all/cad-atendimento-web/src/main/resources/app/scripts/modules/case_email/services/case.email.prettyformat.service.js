define([], function() {
    return ['$location', '$dictionaryUtilsService', '$stringUtilsService', '$caseAttachmentFormatService', function($location, $dic, $stringUtils, $caseAttachmentFormatService) {
        return {
            format: function(objectList, files) {
                var prettyList = [];
                for(var it = 0; it < objectList.length; ++it) {
                    var emailEntry = objectList[it];
                    var prettyEntry = {
                        read: {
                            icon: emailEntry[$dic._isRead] ? 'icons icon-13-2' : 'icons icon-2-1'
                        },
                        sent: {
                            icon: emailEntry[$dic._isSent] ? 'icons icon-16-3' : undefined
                        },
                        emailId: emailEntry[$dic._emailId],
                        subject: emailEntry[$dic._subject],
                        sentDate: emailEntry[$dic._sentDate],
                        from: emailEntry[$dic._isSent] ? emailEntry[$dic._userName] : emailEntry[$dic._from],
                        to: emailEntry[$dic._to],
                        userId: emailEntry[$dic._userId],
                        download: {
                            _attachments: $caseAttachmentFormatService.format(emailEntry[$dic._attachments]),
                            show: (emailEntry[$dic._attachments] && emailEntry[$dic._attachments].length > 0),
                            action: function(){
                            	files.attachments = this._attachments;
                                $('#modalAttachment').modal({
                                    show: true
                                }); 
                            }
                        },
                        visualize: {
                            _uri: $stringUtils.format('/case-email-content/{0}', emailEntry[$dic._emailId]),
                            action: function(){
                                $location.path(this._uri);
                            }
                        }
                    };                                      
                    prettyList.push(prettyEntry);                           
                }                        
                return prettyList;
            }
        };
    }];
});