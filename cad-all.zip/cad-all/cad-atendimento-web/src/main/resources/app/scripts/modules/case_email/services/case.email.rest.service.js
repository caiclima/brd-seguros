define( [ ], function()
{
    var CaseEmailRestService = function($resource, $stringUtils, $requestUtils, $dictionaryUtils, $fileUploadService)
    {
        var send = function(uri, payload, _succesFn, _errorFn) {
            var path = $requestUtils.contextPath();
            var url = $stringUtils.concatenate(path, uri);

            $fileUploadService.upload(url, payload, function(response){
                 if(response == undefined || response.error == undefined){
                    _succesFn(response);
                 }else{
                    _errorFn(response);
                 }
            });
        }

        return {            
            getAll: function(){
                var caseId = $dictionaryUtils._caseId;

                var paramDefaults = {};
                paramDefaults[caseId] = $stringUtils.format('@{0}',caseId);  

                var uri = $stringUtils.format('/api/cases/emailsofcases/:{0}', caseId);
                return $resource($requestUtils.contextPath() + uri, paramDefaults);

            },
            getContent: function() {
                var emailId = $dictionaryUtils._emailId;

                var paramDefaults = {};
                paramDefaults[emailId] = $stringUtils.format('@{0}',emailId);  

                var uri = $stringUtils.format('/api/cases/email/:{0}', emailId);
                var url = $stringUtils.format('/api/cases/email/datatoresponse/:{0}', emailId);

                return $resource($requestUtils.contextPath() + uri, paramDefaults, {
                    'readEmail': { method:'PUT', params: paramDefaults },
                    'getDataToResponse': { url: $requestUtils.contextPath() + url, method:'GET', params: paramDefaults }
                });
            },            
            replyMail: function(payload, _succesFn, _errorFn) {
                var uri = '/api/cases/replymail';
                send(uri, payload, _succesFn, _errorFn);
            },
            fowardMail: function (payload, _succesFn, _errorFn) {
                var uri = '/api/cases/fowardmail';
                send(uri, payload, _succesFn, _errorFn);
            },
            getListAttachment: function (payload, _succesFn, _errorFn) {
                var uri = '/api/cases/email/anexo/:{0}';
                send(uri, payload, _succesFn, _errorFn);
            },
            getBytesAttachment: function () {

                var idAnexo = $dictionaryUtils._attachmentId;
                var paramDefaults = {};
                paramDefaults[idAnexo] = $stringUtils.format('@{0}', idAnexo);

                var uri = $stringUtils.format('/api/download/bytes/:{0}', idAnexo);
                return $resource($requestUtils.contextPath() + uri, paramDefaults);

            }
            
        }        
    };

    return [
        "$resource",
        "$stringUtilsService",
        "$requestUtilsService",
        "$dictionaryUtilsService",
        '$simpleFileUploadService',
        CaseEmailRestService
    ];
});