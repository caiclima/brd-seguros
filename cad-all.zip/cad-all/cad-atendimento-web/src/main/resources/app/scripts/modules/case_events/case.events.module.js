define([
    'angular',
    'CaseEventsTreeviewDirective',
    'CaseEventsComboMultiDirective',
    'CaseCallEventsComboMultiDirective',
    'CaseEventsTreeviewService',
    'CaseEventsComboMultiService',
    'CaseCallEventsComboMultiService'
    ], 
    function(angular, 
    		CaseEventsTreeviewDirective, 
    		CaseEventsComboMultiDirective, 
    		CaseCallEventsComboMultiDirective,
    		CaseEventsTreeviewService, 
    		CaseEventsComboMultiService, 
    		CaseCallEventsComboMultiService){
	
        var _m = angular.module('CaseEventsModule', [
                                                        'ngResource', 
                                                        'pascalprecht.translate',
                                                        'ngCookies', 
                                                        'UtilsModule',
                                                        'UiModule'
                                                    ]);

        _m.directive('caseEventsTreeview', CaseEventsTreeviewDirective);
        _m.directive('caseEventsComboMulti', CaseEventsComboMultiDirective);
        _m.directive('caseCallEventsComboMulti', CaseCallEventsComboMultiDirective);
        _m.factory('$caseEventsTreeviewService', CaseEventsTreeviewService);
        _m.factory('$caseEventsComboMultiService', CaseEventsComboMultiService);
        _m.factory('$caseCallEventsComboMultiService', CaseCallEventsComboMultiService);

        return _m;
    }
);