define([], function() {
    return ['$caseCallEventsComboMultiService','$alertUiService', '$dictionaryUtilsService', function($caseCallEventsComboMultiService, $alert, $dictionaryUtils) {
        return {
            restrict: 'A',
            scope: {
            	operationid: "=",
            	required: "=?",
                selectedEvent: '=?',
                remainSelection: "=?"
            },
            templateUrl: 'app/scripts/modules/case_events/directives/templates/case.events.combo.multi.html',
            link: function(scope, element, attrs) {
            	scope.onItemSelected = function(event){
                	//Get node data
                    var eventId = event.selectedID;
                    
                    if (eventId) {
                    	//Ask server for children nodes
                        $caseCallEventsComboMultiService.parentEvent(
                            eventId,
                            function(childEvents) {
                            	if (childEvents && childEvents.length > 0) {
                            		event.children = $caseCallEventsComboMultiService.createMultiData(
        								childEvents,
        								$dictionaryUtils._eventId,
        								$dictionaryUtils._eventName,
        								(event.level + 1),
        								undefined, 
        								''
        							);
                            		
                            	} else {
                            		event.children = undefined;
                            	}
                            	
                            	//Store eventId
                                scope.selectedEvent = eventId;
                                scope.remainSelection = remainSelection(scope.multidata); 
                            },
                            function(msg) {
                                $alert.error(msg.data ? msg.data.error : msg.error);
                            }
                        );
                        
                    } else {
                    	scope.selectedEvent = eventId;
                    	scope.remainSelection = remainSelection(scope.multidata); 
                    }
                };
                
                var remainSelection = function(multiData){
                	multiData = multiData || {};
                	
                	if(multiData.selectedID === NaN || multiData.selectedID === undefined || multiData.selectedID === null || multiData.selectedID === ''){
                		return true;
                	}
                	
                	if(multiData.children){
                		return remainSelection(multiData.children);
                	}
                	
                	return false;
                };
                
                var init = function(){
                	scope.multidata= {};
                	if(scope.operationid){
                		$caseCallEventsComboMultiService.eventByOperation(scope.operationid, function(events){
                			if(events){
                				if(events && events.length > 0){
                					scope.multidata = $caseCallEventsComboMultiService.createMultiData(
                            			events,
        								$dictionaryUtils._eventId,
        								$dictionaryUtils._eventName,
        								0,
        								undefined, 
        								''
        							);
                            	}
                			}
                		},
                        function(msg) {
                            $alert.error(msg.data ? msg.data.error : msg.error);
                        });
                	}
            	};
            	
            	var unwatch = scope.$watch('operationid', function(newVal,oldVal){
            		if(newVal){
            			init();
            			unwatch();
            		}
            	});
            }
        }
    }]
});