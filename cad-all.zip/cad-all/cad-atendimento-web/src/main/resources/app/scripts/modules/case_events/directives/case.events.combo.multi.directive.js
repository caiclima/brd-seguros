define([], function() {
    return ['$caseEventsComboMultiService','$alertUiService', '$dictionaryUtilsService', function($caseEventsComboMultiService, $alert, $dictionaryUtils) {
        return {
            restrict: 'A',
            scope: {
            	caseid: "=?",
            	operationid: "=?",
            	required: "=?",
            	disabled: "=?",
                selectedEvent: '=?',
                remainSelection: "=?"
            },
            templateUrl: 'app/scripts/modules/case_events/directives/templates/case.events.combo.multi.html',
            link: function(scope, element, attrs) {
            	scope.onItemSelected = function(event){
                	//Get node data
                    var eventId = event.selectedID;
                    
                    if (eventId) {
                    	//Ask server for children nodes
                        $caseEventsComboMultiService.parentEvent(
                            eventId,
                            function(childEvents) {
                            	if (childEvents && childEvents.length > 0) {
                            		event.children = $caseEventsComboMultiService.createMultiData(
        								childEvents,
        								$dictionaryUtils._eventId,
        								$dictionaryUtils._eventName,
        								(event.level + 1),
        								undefined, 
        								''
        							);
                            		
                            	} else {
                            		event.children = undefined;
                            	}
                            	
                            	//Store eventId
                                scope.selectedEvent = eventId;
                                scope.remainSelection = remainSelection(scope.multidata); 
                            },
                            function(msg) {
                                $alert.error(msg.data ? msg.data.error : msg.error);
                            }
                        );
                        
                    } else {
                    	scope.selectedEvent = eventId;
                    	scope.remainSelection = remainSelection(scope.multidata); 
                    }
                };
                
                var remainSelection = function(multiData){
                	multiData = multiData || {};
                	
                	if(multiData.selectedID === NaN || multiData.selectedID === undefined || multiData.selectedID === null || multiData.selectedID === ''){
                		return true;
                	}
                	
                	if(multiData.children){
                		return remainSelection(multiData.children);
                	}
                	
                	return false;
                };
                
                var init = function(){
                	scope.multidata= {};
                	// find by caseid (tree) or by operationid (first node)
                	if(scope.caseid){
                		$caseEventsComboMultiService.findTreeEvent(scope.caseid, function(event){
                    		if(event){
                    			scope.multidata = $caseEventsComboMultiService.createTreeViewMultiData(
                        			event,
        							$dictionaryUtils._eventId,
        							$dictionaryUtils._eventName,
        							''
        						);
                    			
                    			scope.remainSelection = remainSelection(scope.multidata); 
                    		}
                    	});
                	}else if(scope.operationid){
                		$caseEventsComboMultiService.eventByOperation(scope.operationid, function(events){
                			if(events){
                				if(events && events.length > 0){
                					scope.multidata = $caseEventsComboMultiService.createMultiData(
                            			events,
        								$dictionaryUtils._eventId,
        								$dictionaryUtils._eventName,
        								0,
        								undefined, 
        								''
        							);
                					
                					scope.multidata.selectedID = scope.selectedEvent;
                					scope.remainSelection = remainSelection(scope.multidata); 
                            	}
                			}
                		},
                        function(msg) {
                            $alert.error(msg.data ? msg.data.error : msg.error);
                        });
                	}
            	};
            	
            	var unbindrepaintlistener = scope.$on('repaintcombomulti', function(){
            		init();
            	});
            	
            	var unbindwatchoperation = scope.$watch('operationid', function(newVal,oldVal){
            		init();
            	});
            	
            	var unbindwatchcase = scope.$watch('caseid', function(newVal,oldVal){
            		init();
            	});
            	
            	scope.$on('$destroy', function(){
            		unbindrepaintlistener();
            		unbindwatchoperation();
            		unbindwatchcase();
            	});
            }
        }
    }]
});