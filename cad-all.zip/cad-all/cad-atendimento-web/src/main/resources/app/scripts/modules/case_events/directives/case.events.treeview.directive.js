define([], function() {
    return function() {
        return {
            restrict: 'A',
            scope: {
                events: '=',
                onEventSelected: '=',
                onEventTreeBuilded: '=?',
                selectedHasChildNodes: '=?'
            },
            templateUrl: 'app/scripts/modules/case_events/directives/templates/case.events.treeview.html',
            link: function(scope, element, attrs) {
                /*
                *  When an event is selected we first find it
                *  in the treeview, then we perform a clear operation
                *  on neighbour nodes and finally send it to
                *  controller
                */
                scope.onNodeEventSelected = function(eventNode) {
                    /*
                    *  Get node Path
                    */
                    var nodePath  = eventNode.nodePath;
                    /*
                    *  Clone object in order to trigger 'watch'
                    */
                    var eventsTree = scope.events.slice(0);
                    /*
                    *  Find triggered node in the models tree
                    *  And clear child nodes of neighbour nodes
                    */
                    var posOnFirstLevel = nodePath[0];
                    var currNode   = eventsTree[posOnFirstLevel];
                    //if selected node has only one level
                    if(nodePath.length == 1) {
                        clearNeighbourChildNodes(eventsTree, posOnFirstLevel);
                    } else {
                        for(var it = 1; it < nodePath.length; ++it) {
                            var pos   = nodePath[it];
                                                    
                            //on last iteration
                            if(it == nodePath.length - 1) {
                                clearNeighbourChildNodes(currNode.nodes, pos);
                            }

                            //Dive into further
                            currNode  = currNode.nodes[pos];
                        }
                    }
                    /*
                    *  Send the found event upperwards
                    */
                    scope.onEventSelected(currNode, eventsTree);
                    /*
                    * Store selected event
                    */
                    scope.selectedEventNode = currNode;

                    /*
                    *  This method clear neighbour childs nodes
                    */
                    function clearNeighbourChildNodes(neighbourHood, currPos) {
                        for(var j = 0; j < neighbourHood.length; ++j) {
                            if(j != currPos) {
                                var neighbourNode = neighbourHood[j];
                                neighbourNode.nodes = [];
                            }
                        }
                    }
                }

                scope.onEventTreeBuildedInterception = function(eventsTree) {

                    if(scope.selectedEventNode !== undefined && scope.selectedHasChildNodes !== undefined) {
                        scope.selectedHasChildNodes(scope.selectedEventNode.nodes.length > 0);
                    }

                    /*
                    *  Send the events tree upperwards
                    */
                    if(scope.onEventTreeBuilded !== undefined) {
                        scope.onEventTreeBuilded(eventsTree);
                    }
                }
            }
        }
    }
});