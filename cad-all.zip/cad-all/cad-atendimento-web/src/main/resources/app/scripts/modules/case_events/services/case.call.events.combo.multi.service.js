define([], function() {
    return ['$resource', 
            '$requestUtilsService', 
            '$stringUtilsService', 
            '$dictionaryUtilsService',
             function($resource, $requestUtils, $stringUtils, $dicUtils) {
    	
    	var format = function(objectList, id, text ) {
            var prettyList = [];
            if(objectList){
                for (var it = 0; it < objectList.length; ++it) {
                    var object = objectList[it];
                    var pretty = {};
                    pretty["id"] = object[id];
                    pretty["text"] = object[text];
                    prettyList.push(pretty);
                }
            }

            return prettyList;
        };
        
        return {

        	eventByOperation: function(operationId, successFn, errorFn){
        		 var path = $requestUtils.contextPath();
                 var uri = $stringUtils.format('/api/eventphonecall/operation/:{0}', $dicUtils._operationId);
                 var url = $stringUtils.concatenate(path, uri);

                 var paramDefaults = {};
                 paramDefaults[$dicUtils._operationId] = $stringUtils.format('@{0}',$dicUtils._operationId);

                 var params = {};
                 params[$dicUtils._operationId] = operationId;

                 $resource(url, paramDefaults).query(params, successFn, errorFn);
        	},
        
            parentEvent: function(eventId, successFn, errorFn) {
                var path = $requestUtils.contextPath();
                var uri = $stringUtils.format('/api/eventphonecall/perentevent/:{0}', $dicUtils._eventId);
                var url = $stringUtils.concatenate(path, uri);

                var paramDefaults = {};
                paramDefaults[$dicUtils._eventId] = $stringUtils.format('@{0}',$dicUtils._eventId);

                var params = {};
                params[$dicUtils._eventId] = eventId;

                $resource(url, paramDefaults).query(params, successFn, errorFn);
            },
            
            createMultiData: function(events, eventIdField, textField, level, selected, placeholder) {
				return {
					level : level,
					selectedID : selected,
					placeholder: placeholder,
					datasource : format(events, eventIdField, textField)
				};
            }
        }
    }];
});