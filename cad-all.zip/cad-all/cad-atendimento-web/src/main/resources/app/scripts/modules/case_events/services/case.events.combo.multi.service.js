define([], function() {
    return ['$resource', 
            '$requestUtilsService', 
            '$stringUtilsService', 
            '$dictionaryUtilsService',
             function($resource, $requestUtils, $stringUtils, $dicUtils) {
    	
    	var format = function(objectList, id, text ) {
            var prettyList = [];
            if(objectList){
                for (var it = 0; it < objectList.length; ++it) {
                    var object = objectList[it];
                    var pretty = {};
                    pretty["id"] = object[id];
                    pretty["text"] = object[text];
                    prettyList.push(pretty);
                }
            }

            return prettyList;
        };
        
        var _createMultiData = function(data, eventIdField, textField, placeholder) {
			var multidata = {
				level : data[$dicUtils._level],
				selectedID : data[$dicUtils._eventId],
				placeholder: placeholder,
				datasource : format(data[$dicUtils._events], eventIdField, textField)
			};
			
			if(data[$dicUtils._children]){
				multidata.children = _createMultiData(data[$dicUtils._children], eventIdField, textField, placeholder);
			}
			
			return multidata;
        };
        
        return {

        	eventByOperation: function(operationId, successFn, errorFn){
        		 var path = $requestUtils.contextPath();
                 var uri = $stringUtils.format('/api/event/operation/:{0}', $dicUtils._operationId);
                 var url = $stringUtils.concatenate(path, uri);

                 var paramDefaults = {};
                 paramDefaults[$dicUtils._operationId] = $stringUtils.format('@{0}',$dicUtils._operationId);

                 var params = {};
                 params[$dicUtils._operationId] = operationId;

                 $resource(url, paramDefaults).query(params, successFn, errorFn);
        	},
        
            parentEvent: function(eventId, successFn, errorFn) {
                var path = $requestUtils.contextPath();
                var uri = $stringUtils.format('/api/event/perentevent/:{0}', $dicUtils._eventId);
                var url = $stringUtils.concatenate(path, uri);

                var paramDefaults = {};
                paramDefaults[$dicUtils._eventId] = $stringUtils.format('@{0}',$dicUtils._eventId);

                var params = {};
                params[$dicUtils._eventId] = eventId;

                $resource(url, paramDefaults).query(params, successFn, errorFn);
            },
            
            findTreeEvent: function(caseId, successFn, errorFn) {
                var path = $requestUtils.contextPath();
                var uri = $stringUtils.format('/api/event/tree/case/:{0}', $dicUtils._caseId);
                var url = $stringUtils.concatenate(path, uri);

                var paramDefaults = {};
                paramDefaults[$dicUtils._caseId] = $stringUtils.format('@{0}',$dicUtils._caseId);

                var params = {};
                params[$dicUtils._caseId] = caseId;

                $resource(url, paramDefaults).get(params, successFn, errorFn);
            },
            
            createMultiData: function(events, eventIdField, textField, level, selected, placeholder) {
				return {
					level : level,
					selectedID : selected,
					placeholder: placeholder,
					datasource : format(events, eventIdField, textField)
				};
            },

            createTreeViewMultiData: function(event, eventIdField, textField, placeholder) {
            	return _createMultiData(event, eventIdField, textField, placeholder);
            }
        }
    }];
});