define([], function() {
    return ['$resource', 
            '$requestUtilsService', 
            '$stringUtilsService', 
            '$dictionaryUtilsService',
             function($resource, $requestUtils, $stringUtils, $dicUtils) {
        return {

            parentEvent: function(eventId, successFn, errorFn) {
                var path = $requestUtils.contextPath();
                //TODO: grammar error at endpoint
                var uri = $stringUtils.format('/api/event/perentevent/:{0}', $dicUtils._eventId);
                var url = $stringUtils.concatenate(path, uri);

                var paramDefaults = {};
                paramDefaults[$dicUtils._eventId] = $stringUtils.format('@{0}',$dicUtils._eventId);

                var params = {};
                params[$dicUtils._eventId] = eventId;

                $resource(url, paramDefaults).query(params, successFn, errorFn);
            },

            treeNode: function(events, path, textField, eventIdField) {
                var treeEvents = [];
                for(var it = 0; it < events.length; ++it) {
                    var eventNode = events[it];
                    /*
                    * create a path to each node 
                    * based on the parent's path
                    */
                    var nodePath = path.slice(0);
                    nodePath.push(it);
                    /*
                    * create the node
                    */
                    treeEvents.push( {
                        text: eventNode[textField],
                        eventId: eventNode[eventIdField],                        
                        nodePath: nodePath,
                        icon: 'none',
                        nodes: []
                    });
                }
                return treeEvents;
            }
        }
    }];
});