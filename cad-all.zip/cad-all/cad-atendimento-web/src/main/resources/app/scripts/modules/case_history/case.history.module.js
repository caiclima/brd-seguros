define(['angular', 'CaseHistoryController','CaseHistoryDirective','CaseHistoryRestService' ], 

	function(angular, CaseHistoryController, CaseHistoryDirective, CaseHistoryRestService){
		var _m = angular.module('CaseHistoryModule', ['UtilsModule','pascalprecht.translate','ngCookies','UiModule']);

		_m.directive('caseHistory',CaseHistoryDirective );
		_m.controller('CaseHistoryController', CaseHistoryController);
        _m.factory('$CaseHistoryRestService', CaseHistoryRestService);
		
		return _m;
});