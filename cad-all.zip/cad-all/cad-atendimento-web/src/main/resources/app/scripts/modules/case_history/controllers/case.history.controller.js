    define([], function() {

        var CaseHistoryController = function($scope, $rootScope, $caseAttachmentFormatService, $CaseHistoryRestService, $dictionaryUtils, $alertUiService) {
            $scope.prettyHistory = [];
            $scope.attachments = [];
            $scope.maxResults = 10;
            $scope.grandTotal = 0;
            /*
            *   Query user logs of current case
            */
            $scope.fetchUserLogs = function(){
                query($CaseHistoryRestService.getByUser);
            }
            $scope.appendUserLogs = function() {
                query($CaseHistoryRestService.getByUser, append = true);
            }
            /*
            *   Query general logs of current case
            */
            $scope.fetchGeneralLogs = function(){
                query($CaseHistoryRestService.getAll);
            }
            $scope.appendGeneralLogs = function() {
                query($CaseHistoryRestService.getAll, append = true);   
            }
            $scope.sortById = function (a, b){
                return ((a.download.logId < b.download.logId) ? -1 : ((a.download.logId > b.download.logId) ? 1 : 0));
            }

            /*
            *   Initial request
            */
            $scope.fetchGeneralLogs();

            /*
            *  Reset offset
            */
            $scope.switchedView = function() {                
                $scope.prettyHistory = [];
            };
            /*
            *  Common query method
            */
            function query(resourceService, append) {
                var urlParams = {};
                urlParams.caseId   = $rootScope.Namespace.Case.Current[$dictionaryUtils._caseId];
                urlParams.maxResults = $scope.maxResults;

				if ($scope.prettyHistory && $scope.prettyHistory.length) {
					var list = angular.copy($scope.prettyHistory);
					list.sort($scope.sortById);
					urlParams.lastId = list[0].download.logId;

				} else {
					urlParams.lastId = 0;
				}

                resourceService().get(
                    urlParams,
                    function(history) {
                        var caseHistoryList = [];
                        var list = history[$dictionaryUtils._currentLog];
                        $scope.grandTotal = history[$dictionaryUtils._grandTotalOfLog];

                        for (var i = 0; i < list.length; ++i) {                            
                            var caseEntry = list[i];

                            var prettyEntry = {
                                dataLog: caseEntry[$dictionaryUtils._dataLog],
                                description: caseEntry[$dictionaryUtils._description],
                                userName: caseEntry[$dictionaryUtils._userName],
                                slaInMinutes: {
                                    title: caseEntry[$dictionaryUtils._slaInMinutes],
                                    color: caseEntry[$dictionaryUtils._slaIcon]
                                },
                                spentTime: caseEntry[$dictionaryUtils._spentTime],
                                actionName: caseEntry[$dictionaryUtils._actionName],
                                eventName: caseEntry[$dictionaryUtils._eventName],
                                status: {
                                    title: caseEntry[$dictionaryUtils._statusName],
                                    color: caseEntry[$dictionaryUtils._statusColor]
                                },
                                download: {
                                    logId: caseEntry[$dictionaryUtils._logId],
                                    _attachments: caseEntry[$dictionaryUtils._attachments],
                                    show: (caseEntry[$dictionaryUtils._attachments] && caseEntry[$dictionaryUtils._attachments].length > 0),
                                    action: function(){
                                        $scope.attachments = $caseAttachmentFormatService.format(this._attachments);
                                        $('#modalAttachment').modal({
                                            show: true
                                        }); 
                                    }
                                }
                            };
                            caseHistoryList.push(prettyEntry);
                        }
                        if(append)
                            $.merge($scope.prettyHistory, caseHistoryList);
                        else 
                            $scope.prettyHistory = caseHistoryList;
                    }, 
                    function(msg){
                        $alertUiService.error(msg.data ? msg.data.error : msg.error);;
                    });
            }
        };

        return [
                "$scope"
              , "$rootScope"
              , "$caseAttachmentFormatService"
              , "$CaseHistoryRestService"
              , "$dictionaryUtilsService"
              , "$alertUiService"
              , CaseHistoryController];
    });