define( [ ], function()
{            
    return ['$filter', '$stringUtilsService', function($filter, $stringUtils){
    	 return {
            restrict: 'A',
            replace: true,
            scope: {
                switchedView: '=',
                fecthGeneralLogs: '=',
                fetchUserLogs: '=',
                appendGeneralLogs: '=',
                appendUserLogs: '=',
                datasource: '=',
                grandtotal: '=',
                attachments: '='
            },            
            templateUrl: 'app/scripts/modules/case_history/directives/templates/case.history.html',
            link: function(scope,element, attrs) {

                scope.$watchCollection('datasource', function(newValue, oldValue){     
                    if(newValue === oldValue)
                        return;               
                    
                    scope.info = $stringUtils.format('({0} {1} {2})', 
                                        scope.datasource.length || 0, $filter('translate')('bundle.cad.OF'), scope.grandtotal || 0); 
                }, true);                
        
                scope.userView = false;
                scope.switchView = function() {
                    scope.userView = !scope.userView;
                    scope.switchedView();
                    if(scope.userView) {
                        scope.fetchUserLogs();
                    } else {
                        scope.fecthGeneralLogs();
                    }
                }

                scope.tableConfig = [{
                    title: $filter('translate')('bundle.cad.DATE'),
                    type: 'icon-text',
                    icon: "icon-calendar",
                    date: true,
                    breakWord: false
                }, {
                    title: $filter('translate')('bundle.cad.DESCRIPTION'),
					width: '30%'
                }, {
                    title: $filter('translateNamespace')('bundle.cad.usuario','OperacaoAtual'),
                    type: 'icon-text-default',
                    icon: "icon-user",
                    default: $filter('translate')('bundle.cad.SYSTEM')
                }, {
                    title: $filter('translate')('bundle.cad.SLA'),
                    type: 'icon-color',
                    breakWord: false
                 }, {
                    title: $filter('translate')('bundle.cad.TIME'),
                    type: 'icon-text',
                    icon: "icon-time",
                    breakWord: false
                }, {
                    title: $filter('translate')('bundle.cad.ACTION')
                }, {
                    title: $filter('translate')('bundle.cad.EVENT')
                }, {
                    title: $filter('translateNamespace')('bundle.cad.status','OperacaoAtual'),                
                    type: "label",
                    breakWord: false
                }, {
                    title: $filter('translate')('bundle.cad.ATTACHMENT'),
                    type: 'button-toogle',
                    icon: "icon-7-3"
                }];
            }
        };
    }];
});