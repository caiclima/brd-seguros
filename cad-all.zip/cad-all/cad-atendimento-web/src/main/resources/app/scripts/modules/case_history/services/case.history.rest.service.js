define([], function() {
	var CaseHistoryRestService = function($resource, $stringUtils, $requestUtils) {
		
		var caseId = 'caseId';
		var lastId = 'lastId';
		var maxResults = 'maxResults';

		var paramDefaults = {};
		paramDefaults.caseId = $stringUtils.format('@{0}', caseId);
		paramDefaults.lastId = $stringUtils.format('@{0}', lastId);
		paramDefaults.maxResults = $stringUtils.format('@{0}', maxResults);

		return {
			getAll : function() {
				var uri = $stringUtils.format('/api/logs/cases/:{0}/:{1}/:{2} ', caseId, lastId, maxResults);
				return $resource($requestUtils.contextPath() + uri,	paramDefaults);

			},
			getByUser : function() {
				var uri = $stringUtils.format('/api/logs/cases/:{0}/useronly/true/:{1}/:{2} ', caseId, lastId, maxResults);

				return $resource($requestUtils.contextPath() + uri, paramDefaults);
			}
		}
	};

	return [ "$resource", "$stringUtilsService", "$requestUtilsService", CaseHistoryRestService ];
});