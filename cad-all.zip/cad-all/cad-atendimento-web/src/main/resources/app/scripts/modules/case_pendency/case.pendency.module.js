define(
    [
        'angular', 
        'CasePendencyViewController',
        'CasePendencyPreviewController',
        'CasePendencyViewDirective', 
        'CasePendencyPreviewDirective', 
        'CasePendencyRestService',
        'CasePendencyPrettyFormatService'
    ], 

	function(angular,
            CasePendencyViewController,
            CasePendencyPreviewController,
            CasePendencyViewDirective, 
            CasePendencyPreviewDirective,
            CasePendencyRestService,
            CasePendencyPrettyFormatService){
        
		var _m = angular.module('CasePendencyModule', [ 
                                                        'pascalprecht.translate',
                                                        'ngCookies',
                                                        'ngResource',
                                                        'UtilsModule',
                                                        'UiModule'
                                                      ]);

		_m.directive('casePendencyView',CasePendencyViewDirective );
		_m.directive('casePendencyPreview',CasePendencyPreviewDirective);
		_m.controller('CasePendencyViewController', CasePendencyViewController);
        _m.controller('CasePendencyPreviewController', CasePendencyPreviewController);
        _m.factory('$casePendencyRestService', CasePendencyRestService);
        _m.factory('$casePendencyPrettyFormatService', CasePendencyPrettyFormatService);

		
		return _m;
});