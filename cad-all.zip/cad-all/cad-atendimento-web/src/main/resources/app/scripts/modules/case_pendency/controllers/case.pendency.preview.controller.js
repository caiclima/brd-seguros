define([], function() {

    var filterCases = function (pendingCases) {
        return pendingCases.length > 5 ? pendingCases.slice(0,5) : pendingCases;
    }

    var CasePendencyPreviewController = function($rootScope, $scope, $location, $caseCheckerUtils, $eventNaming, $dictionaryUtils, $casePendencyFormat, $restService, $caseViewRestService, $alert) {
        /*
        *  Listen to PendingCasesChanged event
        *  in order to update 'preview table' if user 
        *  re-request pending cases in Pending Cases page.
        */
        $scope.$on($eventNaming.PendingCasesChanged, function(event, pendingCases) {
            setPendingCases(pendingCases);
        });
        
        /*
        * Filter and set pending cases
        */
        var setPendingCases = function(pendingCases) {
            $scope.preview = filterCases(pendingCases);
        }

        /*
        *  After system has completed its loading
        *  we shall start listening to NamespaceCaseChanged event
        *  in order to update hasCase flag and
        *  to re-request PendingCases 
        */
        $scope.$on($eventNaming.LoadingComplete, function(event) {

            /*
            *   Get Namespace object, but it might have been set yet
            */
            var namespace = $rootScope.Namespace;
            setPendingCases(namespace.Case.Pending.Cases);

           /*
            *  Listen to NamespaceCaseChanged event
            *  in order to update hasCase flag and
            *  to re-request PendingCases 
            */
            $scope.$on($eventNaming.NamespaceCaseChanged, function(event, Case) {
                /*
                *  Get UserId from Namespace object in order to
                *  request pending cases
                */
                var userId = namespace.User[$dictionaryUtils._userId];

                /*
                *  Request first entries
                */
                $restService.queryDefault(
                    userId,
                    function(pendingCases) {
                        pendingCases = $casePendencyFormat.format(pendingCases);
                        namespace.Case.Pending.ChangePendingCases(pendingCases);
                    },
                    function(msg) {
                        $alert.error(msg.data ? msg.data.error : msg.error);
                    }
                );
            });

            $scope.userRequestCase = function() {
                var userId = namespace.User[$dictionaryUtils._userId];
                $caseViewRestService.userRequestCase(
                    userId, function(newCase){
                        $rootScope.Namespace.Case.ChangeCase(newCase);
                        if($caseCheckerUtils.realCase(newCase)){
                            $location.path('/case-view');
                        }
                    }, function(msg){
                        $alert.error(msg.data ? msg.data.error : msg.error);
                    }
                );
            }
        });
 
    };

    return [
        '$rootScope',
        '$scope',
        '$location',
        '$caseCheckerUtilsService',
        '$eventNamingUtilsService',
        '$dictionaryUtilsService',
        '$casePendencyPrettyFormatService',
        '$casePendencyRestService',
        '$caseViewRestService',
        '$alertUiService',
        CasePendencyPreviewController
    ];
});