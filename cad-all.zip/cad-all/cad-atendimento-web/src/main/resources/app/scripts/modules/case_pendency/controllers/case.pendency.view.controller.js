define([], function() {

	var CasePendencyViewController = function($rootScope, $scope, $location, $restService, $dictionaryUtils, $caseViewRestService, $pendenciesFormatService, $genericUtils, $eventNaming, $caseCheckerUtils, $alert, $filter) {
        /*
        *  Lets JS eval our functions/properties
        */
        declareScopedFunctions();
        declareScopedVariables();
        /*
        *  Starts Listening to any change on Pending Cases List in Namespace
        */
       /*$scope.$on($eventNaming.PendingCasesChanged, function(event, pendingCases) {
            $scope.view = pendingCases;
       });*/

        /*
        *  If system is already loaded get necessary Data from Namespace
        *  Otherwise waits System Loading to complete
        */
        var namespace = $rootScope.Namespace;        
        if(namespace.Loaded) {
        	$scope.userId = namespace.User[$dictionaryUtils._userId];
            $scope.query($scope.userId, 1, 10000);
            $scope.hasCase = $caseCheckerUtils.realCase(namespace.Case.Current);

        } else {
            $scope.$on($eventNaming.LoadingComplete, function(event) {
            	$scope.userId = namespace.User[$dictionaryUtils._userId];
                $scope.query($scope.userId, 1, 10000);
                $scope.hasCase = $caseCheckerUtils.realCase(namespace.Case.Current);
            });

            $scope.$on($eventNaming.NamespaceCaseChanged, function(event, Case) {
                $scope.hasCase = $caseCheckerUtils.realCase(Case);
            });
        }

        function declareScopedFunctions() {
            var success = function(newCase){
                if($caseCheckerUtils.realCase(newCase)){
                    $location.path('/case-view');
                }
                $rootScope.Namespace.Case.ChangeCase(newCase);
                $scope.state.disabled = false;
            };

            var fail = function(msg){
                $alert.error(msg.data ? msg.data.error : msg.error);
                $scope.state.disabled = false;
            };

            $scope.query = function(userId, indexPage, maxResults) {
                $restService.query(userId, indexPage, maxResults,
                    function(pendingCases) {
                		if(!$scope.view){
                			$scope.view = [];
                		}
                        pendingCases = $pendenciesFormatService.format(pendingCases);
                        $scope.view.push.apply($scope.view, pendingCases);

                        if(indexPage <= 1) {
                            $scope.view = pendingCases;
                            $scope.$broadcast($eventNaming.RefreshTotalPendency);
                        }
                    },fail);
            }

            $scope.queryPendingCases = function() {
                var userId     = $scope.userId;
                var indexPage  = $scope.indexPage++;
                var maxResults = $scope.maxResults;

                $scope.query(userId, indexPage, maxResults);
            }

            $scope.userRequestCase = function() {
                $scope.state.disabled = true;

                var userId = namespace.User[$dictionaryUtils._userId];
                $caseViewRestService.userRequestCase(
                    userId, success, fail
                );
            }
        }

        function declareScopedVariables() {
            $scope.maxResults =  $restService.maxResults;
            $scope.indexPage  = $restService.indexPage;
            $scope.view = [];
            $scope.hasCase = true;
            $scope.state = {
                disabled: undefined,
                disabledText: $filter('translate')('bundle.cad.REQUESTING')
            };
        }
	};

	return [
        "$rootScope", 
        "$scope",
        "$location",
        "$casePendencyRestService", 
        "$dictionaryUtilsService",
        '$caseViewRestService',
        "$casePendencyPrettyFormatService",
        "$genericUtilsService",
        "$eventNamingUtilsService",
        '$caseCheckerUtilsService',
        '$alertUiService',
        '$filter',
        CasePendencyViewController];
});