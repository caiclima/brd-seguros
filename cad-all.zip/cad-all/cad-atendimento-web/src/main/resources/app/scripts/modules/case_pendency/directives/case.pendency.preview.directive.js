define( [ ], function()
{            
    return ['$translate','$compile', '$eventNamingUtilsService', '$caseCheckerUtilsService' ,function($translate,$compile,$eventNaming, $caseCheckerUtils){
    	 return {
            restrict: 'A',
            replace: true,
            scope: {},
            templateUrl: 'app/scripts/modules/case_pendency/directives/templates/case.pendency.preview.html',
            controller: 'CasePendencyPreviewController',
             link: function(scope, element, attrs) {

                $translate(['bundle.cad.ID',
                            'bundle.cad.EXTERNAL_ID',
                            'bundle.cad.DATE_SCHEDULING',
                            'bundle.cad.OPERATION',                             
                            'bundle.cad.QUEUE', 
                            'bundle.cad.CASE_TYPE',
                            'bundle.cad.EVENT',
                            'bundle.cad.CHANNEL',
                            'bundle.cad.STATUS',
                            'bundle.cad.SLA',
                            'bundle.cad.ACTION',
                            'bundle.cad.CASE_PENDENCY'])
                
                .then(function(labels) {

                    scope.config = [{
                        title: labels['bundle.cad.ID'],
                        breakWord: false
                    },{
                        title: labels['bundle.cad.EXTERNAL_ID'],
                        breakWord: false
                    },{
                        type: 'icon-text-toogle',
                        icon: 'icon-reopened-gray'
                    },{
                        title: labels['bundle.cad.DATE_SCHEDULING'],
                        type: 'icon-text',
                        icon: "icon-calendar",
                        date: true,
                        breakWord: false
                    },{
                        title: labels['bundle.cad.OPERATION'],
                        width: '10%'
                    }, {
                        title: labels['bundle.cad.QUEUE'],
                        type: 'labelQueue',
                        width: '12%'
                    }, {
                        title: labels['bundle.cad.CASE_TYPE'],
                        width: '10%'
                    }, {
                        title: labels['bundle.cad.EVENT'],
                        width: '10%'
                    }, {
                        title: labels['bundle.cad.CHANNEL'],
                        width: '10%'
                    }, {
                        title: labels['bundle.cad.STATUS'],
                        type: 'label',
                        breakWord: false
                    }, {
                        type: 'icon-text-toogle',
                        icon: 'icon-13-5'
                    }, {
                        title: labels['bundle.cad.SLA'],
                        type: 'icon-color',
                        breakWord: false
                    }, {
                        title: labels['bundle.cad.ACTION'],
                        type: 'button-toogle',
                        icon: 'icon-16-3',
                        width: '5%'
                    }];

                    scope.msg = labels['bundle.cad.CASE_PENDENCY'];

                    var tableEl = '<div table config="config" datasource="preview" context="{{msg}}"></div>';
                    $('div#casePendencyPreview').replaceWith($compile(tableEl)(scope));

                });
                
                scope.hasCase = true;
                scope.$on($eventNaming.NamespaceCaseChanged, function(event, Case) {
                    scope.hasCase = $caseCheckerUtils.realCase(Case);
                });
            }
        };
    }];
});