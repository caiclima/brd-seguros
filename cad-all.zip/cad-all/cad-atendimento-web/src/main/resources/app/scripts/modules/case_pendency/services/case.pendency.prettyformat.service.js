define([], function() {
	return [
		"$dictionaryUtilsService",
		"$filter",
		"$location",
		"$rootScope",
		"$caseCheckerUtilsService",
		"$caseViewRestService",
		"$alertUiService",
		function($Dic, $filter, $location, $rootScope, $caseCheckerUtils, $caseViewRestService, $alert) {
			return {
				_attendCase : function(newCase) {
					if ($caseCheckerUtils.realCase(newCase)) {
						$location.path('/case-view');
					}
					$rootScope.Namespace.Case.ChangeCase(newCase);
				},
				_showError : function(msg) {
					$alert.error(msg.data ? msg.data.error : msg.error);
				},
				format : function(objectList) {
					var prettyList = [];
					for (var it = 0; it < objectList.length; ++it) {
						var object = objectList[it];
						var pretty = {
							caseId : object[$Dic._caseId],
							externalId : object[$Dic._externalId],
							reopened : {
								show : object[$Dic._isReopened]
							},
							schedulingDate : object[$Dic._schedulingDate],
							operation : object[$Dic._nameOperation],
							queue : {
								title : object[$Dic._queueConfigName],
								color : object[$Dic._filaColor]
							},
							manifestationType : object[$Dic._caseTypeName],
							events : object[$Dic._eventName],
							channel : object[$Dic._channelName],
							status : {
								title : object[$Dic._statusName],
								color : object[$Dic._statusColor]
							},
							newEmail : {
								show : object[$Dic._hasNewEmail]
							},
							sla : {
								title : object[$Dic._slaInMinutes],
								color : object[$Dic._slaIcon]
							},
							attend : {
								_caseId : object[$Dic._caseId],
								_userId : object[$Dic._userId],
								_successFn: this._attendCase,
								_errorFn: this._showError,
								title : $filter('translate')('bundle.cad.ATTEND'),
								show : $caseCheckerUtils.fakeCase($rootScope.Namespace.Case.Current),
								action : function() {
									$caseViewRestService.requestCase(
										this._userId,
										this._caseId,
										this._successFn,
										this._errorFn)
								}
							}
						};
						prettyList.push(pretty);
					}
					return prettyList;
				}
			};
		} 
	];
});