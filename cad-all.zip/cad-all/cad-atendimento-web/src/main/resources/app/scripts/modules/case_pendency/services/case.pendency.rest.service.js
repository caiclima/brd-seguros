define([], function(){

    var CasePendencyRestService = function($resource, $requestUtils, $stringUtils, $dictionaryUtils) {

        var queryResource = function () {
            var userId = $dictionaryUtils._userId;
            var indexPage = $dictionaryUtils._indexPageEn;
            var maxResults = $dictionaryUtils._maxResultsEn;
            var uri = $stringUtils.format("/api/cases/users/:{0}/:{1}/:{2}", userId, indexPage, maxResults);

            var paramDefaults = {};
            paramDefaults[userId] = $stringUtils.format('@{0}', userId);
            paramDefaults[indexPage] = $stringUtils.format('@{0}', indexPage);
            paramDefaults[maxResults] = $stringUtils.format('@{0}', maxResults);
            
            return resource = $resource($requestUtils.contextPath() + uri, paramDefaults);
        }
        
        return {
            query: function( userId, indexPage, maxResults, successFn, errorFn) {
                var urlParams = {};
                urlParams[$dictionaryUtils._userId]       = userId;
                urlParams[$dictionaryUtils._indexPageEn]  = indexPage;
                urlParams[$dictionaryUtils._maxResultsEn] = maxResults;

                queryResource().query(urlParams, successFn, errorFn);
            },
            count: function(userId, successFn, errorFn){
            	var resource = function() {
                    var uri = $stringUtils.format("/api/cases/quantity/users/{0}", userId);
                    return $resource($stringUtils.concatenate($requestUtils.contextPath(), uri), {});
                }();

                resource.get({}, successFn, errorFn);
            },
            queryDefault: function(userId, successFn, errorFn) {
                this.query(userId, this.indexPage, this.maxResults, successFn, errorFn);
            },
            indexPage: 1,
            maxResults: 10
        };
    };

    return [
        "$resource",
        "$requestUtilsService",
        "$stringUtilsService",
        "$dictionaryUtilsService",
        CasePendencyRestService
    ];
});