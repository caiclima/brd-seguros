define(
    [
        'angular', 
        'CaseViewQuestionnaireController',
        'CaseViewQuestionnaireDirective', 
        'CaseViewResultQuestionnaireDirective', 
        'CaseViewQuestionnaireRestService',
        'CaseQuestionnairePrettyService'
    ], 

	function(angular,
			CaseViewQuestionnaireController,
			CaseViewQuestionnaireDirective,
			CaseViewResultQuestionnaireDirective, 
            CaseViewQuestionnaireRestService,
            CaseQuestionnairePrettyService){
        
		var _m = angular.module('CaseViewQuestionnaireModule', [ 
	        'pascalprecht.translate',
	        'ngCookies',
	        'ngResource',
	        'UtilsModule',
	        'UiModule'
	     ]);

		_m.directive('caseViewQuestionnaire', CaseViewQuestionnaireDirective);
		_m.directive('caseViewResultQuestionnaire',CaseViewResultQuestionnaireDirective);
		_m.controller('CaseViewQuestionnaireController', CaseViewQuestionnaireController);
        _m.factory('$caseViewQuestionnaireRestService', CaseViewQuestionnaireRestService);
        _m.factory('$caseQuestionnairePrettyService', CaseQuestionnairePrettyService);
		
		return _m;
});