define([], function() {

	var CaseViewQuestionnaireController = function(
			$scope, 
			$rootScope,
			$caseViewQuestionnaireRestService, 
			$caseQuestionnairePrettyService,
			$dictionaryUtils,
			$alertUiService) {
		
		$scope.queryQuestionnare = function(){
        	$scope.prettyQuestionnaire = [];
        	
        	$caseViewQuestionnaireRestService.queryQuestionnare(
				$rootScope.Namespace.Case.Current[$dictionaryUtils._caseId],
				$rootScope.Namespace.Case.Current[$dictionaryUtils._userId],
				function(questionnaires) {
					$scope.prettyQuestionnaire = $caseQuestionnairePrettyService.formatQuestionnare(questionnaires);
				},
				function(msg) {
					$alertUiService.error(msg.data ? msg.data.error	: msg.error);
				}
			);
        }();
        
    };

    return ["$scope"
          , "$rootScope"
          , "$caseViewQuestionnaireRestService"
          , "$caseQuestionnairePrettyService"
          , "$dictionaryUtilsService"
          , "$alertUiService"
          , CaseViewQuestionnaireController];
});