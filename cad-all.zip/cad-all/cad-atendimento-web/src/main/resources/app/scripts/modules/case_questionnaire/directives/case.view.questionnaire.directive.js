define( [ ], function()
{            
    return ['$filter', function($filter){
    	 return {
            restrict: 'A',
            replace: true,
            scope: {
                datasource: '='
            },            
            templateUrl: 'app/scripts/modules/case_questionnaire/directives/templates/case.view.questionnaire.html',
            link: function(scope,element, attrs) {
                scope.tableConfig = [{
                    title: $filter('translate')('bundle.cad.DATE'),
                    type: 'icon-text',
                    icon: "icon-calendar",
                    date: true,
                    breakWord: false
                }, {
                    title: $filter('translate')('bundle.cad.DESCRIPTION'),
					width: '30%'
                }, {
                    title: $filter('translateNamespace')('bundle.cad.usuario','OperacaoAtual'),
                    type: 'icon-text-default',
                    icon: "icon-user"
                }, {
                    title: $filter('translate')('bundle.cad.ACTION'),
                    width: '30%'
                }, {
                    title: $filter('translate')('bundle.cad.ANSWERS'),
                    type: 'button',
                    icon: "icon-24-7"
                }];
            }
        };
    }];
});