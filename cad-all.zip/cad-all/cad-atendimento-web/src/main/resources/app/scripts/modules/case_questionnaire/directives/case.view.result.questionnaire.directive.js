define( [ ], function()
{            
    return [function(){
    	 return {
            restrict: 'A',
            replace: true,
            templateUrl: 'app/scripts/modules/case_questionnaire/directives/templates/case.view.result.questionnaire.html',
            controller: ['$scope', '$rootScope', '$routeParams', '$caseViewQuestionnaireRestService', '$caseQuestionnairePrettyService', '$dictionaryUtilsService', '$alertUiService', 
                         function ($scope, $rootScope, $routeParams, $caseViewQuestionnaireRestService, $caseQuestionnairePrettyService, $dictionaryUtils, $alertUiService) {
    	        
            	var userId   = $rootScope.Namespace.User[$dictionaryUtils._userId];
    	        var questionnaireResultId = $routeParams.questionnaireResultId;
    	        
                function init() {
                	$scope.answers = [];
                	$caseViewQuestionnaireRestService.queryAnswers(
            			questionnaireResultId,
            			userId,
            			function(answers){
            				$scope.answers = $caseQuestionnairePrettyService.formatAnswers(answers);
            			},
            			function(msg) {
        					$alertUiService.error(msg.data ? msg.data.error	: msg.error);
        				}
                	);
                }
                
                init();
            }]
        };
    }];
});