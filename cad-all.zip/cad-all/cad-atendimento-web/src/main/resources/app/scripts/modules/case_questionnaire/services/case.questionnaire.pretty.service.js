define([], function() {

    var CaseQuestionnairePrettyService = function($dictionaryUtils, $genericUtils, $stringUtils, $location) {

        var fieldRelation = function() {
            var obj = {};
            obj[$dictionaryUtils._answerType_OneLine]        = "INPUT";
            obj[$dictionaryUtils._answerType_MultLine]       = "TEXTAREA";
            obj[$dictionaryUtils._answerType_SingleChoice]   = "COMBOBOX";
            obj[$dictionaryUtils._answerType_MultipleChoice] = "CHECKBOX";
            return obj;
        }();

        function getField(answerType) {
            return fieldRelation[answerType];
        }

        function goTo(questionnaireResultId) {
        	$location.path($stringUtils.format("/case-result-questionnaire/{0}", questionnaireResultId));
        }

        return {
        	formatQuestionnare: function(questionnaires) {
                var prettyList = [];
                
                if(questionnaires){
                	for (var i = 0; i < questionnaires.length; ++i) {
    					var questionnaire = questionnaires[i];

    					var entry = {
    						answerDate : questionnaire[$dictionaryUtils._answerDate],
    						questionnaireDescription : questionnaire[$dictionaryUtils._questionnaireDescription],
    						login : questionnaire[$dictionaryUtils._login],
    						actionName: questionnaire[$dictionaryUtils._actionName],
    						view : {
    							_questionnaireResultId : questionnaire[$dictionaryUtils._questionnaireResultId],
    							action : function() {
    								goTo(this._questionnaireResultId);
    							}
    						}
    					};
    					prettyList.push(entry);
    				}
                }
                
                return prettyList;
        	},
        	formatAnswers: function(answers) {
                var prettyList = [];

                if(answers){
                	for(var it=0; it<answers.length; ++it) {
                        var item = answers[it];

                        var prettyQuestion = {};
                        prettyQuestion.questionDescription = item[$dictionaryUtils._questionDescription];
                        prettyQuestion.answer = item[$dictionaryUtils._answer];

                        prettyQuestion.availableAnswers = function(item) {
                            var objAnswers = {};
                            if(!$genericUtils.isNull(item[$dictionaryUtils._availableAnswers_Ew])) {
                                var answers = item[$dictionaryUtils._availableAnswers_Ew].split(";");                        
                                for(var it = 0; it < answers.length; ++it) {
                                    var answerIt = answers[it];
                                    objAnswers[answerIt] = answerIt;
                                }    
                            }
                            return objAnswers;
                        }(item);

                        prettyQuestion.field = function(item) {
                            var answerType = item[$dictionaryUtils._answerType];                        
                            return getField(answerType);
                        }(item);

                        void function caseMultiAnswerQuestion(prettyQuestion) {
                            if(prettyQuestion.field === 'CHECKBOX') {
                                prettyQuestion.multiAnswer = {};
                                for(var answer in prettyQuestion.availableAnswers) {
                                    var checked = answer == prettyQuestion.answer;
                                    prettyQuestion.multiAnswer[answer] = checked;
                                }
                            }
                        }(prettyQuestion);

                        prettyList.push(prettyQuestion);
                    }
                }
                
                return prettyList;
            }
        };
    };

    return ['$dictionaryUtilsService', '$genericUtilsService', '$stringUtilsService', '$location', CaseQuestionnairePrettyService];
});