define([], function(){

    var CaseViewQuestionnareRestService = function($resource, $requestUtils, $stringUtils, $dictionaryUtils) {

        var customResource = function (uri, paramDefaults) {
            return $resource($requestUtils.contextPath() + uri, paramDefaults);
        }
        
        return {
        	queryQuestionnare: function(caseid, userid, successFn, errorFn) {
				var caseId = $dictionaryUtils._caseId;
				var userId = $dictionaryUtils._userId;
				var uri = $stringUtils.format("/api/questionnaire/list/case/:{0}/user/:{1}", caseId, userId);

				var paramDefaults = {};
				paramDefaults[caseId] = $stringUtils.format('@{0}', caseId);
				paramDefaults[userId] = $stringUtils.format('@{0}', userId);

				var resource = customResource(uri, paramDefaults);

				var urlParams = {};
				urlParams[caseId] = caseid;
				urlParams[userId] = userid;

				resource.query(urlParams, successFn, errorFn);
			},
            queryAnswers: function(resultid, userid, successFn, errorFn){
            	var resultId = $dictionaryUtils._questionnaireResultId;
				var userId = $dictionaryUtils._userId;
				var uri = $stringUtils.format("/api/questionnaire/result/:{0}/user/:{1}", resultId,	userId);

				var paramDefaults = {};
				paramDefaults[resultId] = $stringUtils.format('@{0}', resultId);
				paramDefaults[userId] = $stringUtils.format('@{0}', userId);

				var resource = customResource(uri, paramDefaults);

				var urlParams = {};
				urlParams[resultId] = resultid;
				urlParams[userId] = userid;

				resource.query(urlParams, successFn, errorFn);
            }
        };
    };

    return [
        "$resource",
        "$requestUtilsService",
        "$stringUtilsService",
        "$dictionaryUtilsService",
        CaseViewQuestionnareRestService
    ];
});