/*
 * module definitions 
 */

define(['angular', 'CaseRegisterController', 'CaseRegisterPrettyService', 'CaseRegisterRestService', 'CaseRegisterDirective', 'CaseRegisterFieldsDirective' ],
    function (angular, CaseRegisterController, CaseRegisterPrettyService, CaseRegisterRestService, CaseRegisterDirective, CaseRegisterFieldsDirective) {

        var _m = angular.module('CaseRegisterModule', [
            'ngResource',
            'UtilsModule',
            'pascalprecht.translate',
            'ngCookies',
            'UiModule',
            'CaseEventsModule',
            'DynamicFieldsModule',
            'SimpleFileUploadModule'
        ]);

        _m.directive('caseRegister', CaseRegisterDirective);
        _m.directive('caseRegisterFields', CaseRegisterFieldsDirective);
        _m.factory('$caseRegisterPrettyService', CaseRegisterPrettyService);
        _m.factory('$caseRegisterRestService', CaseRegisterRestService);
        _m.controller('CaseRegisterController', CaseRegisterController);

        return _m;
    });