define(
		[],
		function() {

			var CaseRegisterController = function($rootScope, $scope, $filter,
					$dictionaryUtils, $comboFormatterUtils, $genericUtils,
					$restService, $prettyService, $eventNaming, $route, $timeout, $alert,
					$dynamicFieldsService, $stringUtilsService) {

				$scope.validEvent = {
					remainingSelection : undefined
				};
				$scope.disabledComponent = {
					disableCaseType : true,
					disableChannel : true,
					disableEvent : true,
					disableOperation : false
				};
				$scope.showCaseID = false;
				$scope.showStatus = false;
				$scope.showOpeningDate = false;
				$scope.showCreatesID = false;
				$scope.showIdDad = false;
				$scope.idDadRequired = false;
				$scope.showDynamicsFields = false;
				$scope.showObservation = false;
				$scope.showChangeOperation = false;
				$scope.caseRegister = {};
				$scope.operations = [];
				$scope.caseTypesList = [];
				$scope.channel = [];
				$scope.datasource = {};
                $scope.state = {
                    disabled: undefined,
                    disabledText: $filter('translate')('bundle.cad.SAVING')
                };
                $scope.layoutPreview = [];
                $scope.showSelectionBox = false;
                $scope.hasAttachmentPrivilege = false;
                $scope.allowsAttachment = false;

				/*
				 * load page data
				 */
				var loadPageData = function() {
					$scope.userId = $rootScope.Namespace.User[$dictionaryUtils._userId];
                    $scope.layoutPreview = [];

                    $restService.layoutPreview(
                    	$scope.userId,
                        function (layouts) {
                            $scope.layoutPreview = $prettyService.prettyLayoutToBox(layouts, $scope.selectLayout);
                            $scope.showSelectionBox = $scope.layoutPreview != undefined && $scope.layoutPreview.length > 0;

                        }, function (msg) {
                            $alert.error(msg.data ? msg.data.error : msg.error);
                        }
                    );

                    // automaticaly load operations list
					var getOperationsList = function() {
						$restService.operationsList($scope.userId, function(
								operationsList) {
							$scope.operations = $comboFormatterUtils.format(
									operationsList,
									$dictionaryUtils._operationId,
									$dictionaryUtils._name);
						}, function(msg) {
							$alert.error(msg.data ? msg.data.error : msg.error);
						});
					}();
				}();

				$scope.operationSelected = function(val) {
					if (val != undefined) {
						$scope.disabledComponent.disableChannel = true;
						$scope.disabledComponent.disableEvent = true;
						$scope.showStatus = false;
						$scope.showObservation = false;
						$scope.showOpeningDate = false;
						$scope.showCreatesID = false;
						$scope.showIdDad = false;
						$scope.idDadRequired = false;
						$scope.showDynamicsFields = false;
						$rootScope.Namespace.OperacaoAtual = $scope.caseRegister.operationId;
						$scope.showChangeOperation = true;

						$scope.caseTypesList = [];
						$scope.channel = [];
						$scope.datasource = {};
						$scope.caseRegister.caseTypeId = undefined;
						$scope.caseRegister.channelId = undefined;
						
						$scope.hasAttachmentPrivilege = false;
		                $scope.allowsAttachment = false;

						/*
						 * Fetch case type list
						 */
						$restService.caseTypeList(
                                $scope.caseRegister.operationId,
                                function(caseTypesList) {
                                    $scope.caseTypesList = $comboFormatterUtils
                                            .format(
                                                    caseTypesList,
                                                    $dictionaryUtils._caseTypeId,
                                                    $dictionaryUtils._name);
                                    $scope.disabledComponent.disableCaseType = false;
                                }, function(msg) {
                                    $alert.error(msg.data ? msg.data.error : msg.error);
                                }
                        );
					}
				};

                $scope.toView = function(fields) {
                    if(fields){
                        $scope.showSelectionBox = false;
                        // el's visibility
                        $scope.disabledComponent.disableChannel = false;
                        $scope.disabledComponent.disableEvent = false;
                        $scope.showStatus = true;
                        $scope.showObservation = true;

                        // Update values
                        $scope.showOpeningDate = fields[$dictionaryUtils._showOpeningDate];
                        $scope.showCreatesID = !fields[$dictionaryUtils._showCreatesID];
                        $scope.showIdDad = fields[$dictionaryUtils._showIDDad];
                        $scope.idDadRequired = fields[$dictionaryUtils._idDadRequired];
                        $scope.labelStatus = {};
                        $scope.labelStatus[$dictionaryUtils._nameEn] = fields[$dictionaryUtils._statusName];
                        $scope.labelStatus[$dictionaryUtils._color] = fields[$dictionaryUtils._statusColor];
                        $scope.caseRegister.caseTypeId = fields[$dictionaryUtils._caseTypeId];
                        $scope.caseRegister.operationId = fields[$dictionaryUtils._operationId];
                        
                        $scope.hasAttachmentPrivilege = fields[$dictionaryUtils._hasAttachmentPrivilege];
                        $scope.allowsAttachment = fields[$dictionaryUtils._allowsAttachment];

                        // format dyn fields
                        $scope.datasource.fields = $dynamicFieldsService
                            .formatDynamicField(
                            fields[$dictionaryUtils._dynamicFields],
                            $rootScope.Namespace.Case.Current);

                        if ($scope.datasource.fields
                            && $scope.datasource.fields.length) {
                            $scope.showDynamicsFields = true;
                            $rootScope
                                .$broadcast(
                                $eventNaming.InternalContentChanged,
                                {});
                        }

                        // format channel
                        $scope.channel = $comboFormatterUtils
                            .format(
                            fields[$dictionaryUtils._channel],
                            $dictionaryUtils._channelId,
                            $dictionaryUtils._name);
                    }
                };

                $scope.selectLayout = function (layout) {
                    $scope.disabledComponent.disableChannel = true;
                    $scope.disabledComponent.disableEvent = true;
                    $scope.showStatus = false;
                    $scope.showObservation = false;
                    $scope.showOpeningDate = false;
                    $scope.showCreatesID = false;
                    $scope.showIdDad = false;
                    $scope.idDadRequired = false;
                    $scope.showDynamicsFields = false;
                    $rootScope.Namespace.OperacaoAtual = layout.operationId;
                    $scope.showChangeOperation = true;

                    $scope.caseTypesList = [];
                    $scope.channel = [];
                    $scope.datasource = {};
                    $scope.caseRegister.caseTypeId = undefined;
                    $scope.caseRegister.channelId = undefined;
                    
                    $scope.hasAttachmentPrivilege = false;
                    $scope.allowsAttachment = false;

                    if (layout != undefined) {
                        $restService.findLayout(
                            layout.layoutId,
                            $scope.userId,
                            function(fields){
                                /*
                                 * Fetch case type list
                                 */
                                $restService.caseTypeList(
                                    layout.operationId,
                                    function(caseTypesList) {
                                        $scope.caseTypesList = $comboFormatterUtils.format(
                                            caseTypesList,
                                            $dictionaryUtils._caseTypeId,
                                            $dictionaryUtils._name
                                        );
                                        $scope.disabledComponent.disableCaseType = false;

                                    }, function(msg) {
                                        $alert.error(msg.data ? msg.data.error : msg.error);
                                    }
                                );

                                $scope.toView(fields);
                            },
                            function(msg) {
                                $scope.disabledComponent.disableChannel = true;
                                $scope.disabledComponent.disableEvent = true;
                                $alert.error(msg.data ? msg.data.error : msg.error);
                            }
                        );
                    }
                };

				$scope.getFields = function(val) {
					$scope.channel = [];
					$scope.datasource = {};
					$scope.showStatus = false;
					$scope.showObservation = false;
					$scope.showOpeningDate = false;
					$scope.showCreatesID = false;
					$scope.showIdDad = false;
					$scope.idDadRequired = false;
					$scope.showDynamicsFields = false;
					$scope.caseRegister.channelId = undefined;
					$scope.caseRegister.externalCaseId = undefined;
					$scope.caseRegister.caseIdDad = undefined;
					$scope.caseRegister.eventId = undefined;
					$scope.caseRegister.observation = undefined;
					$scope.caseRegister.openingDate = undefined;
					$scope.hasAttachmentPrivilege = false;
                    $scope.allowsAttachment = false;
					$scope.$broadcast('repaintcombomulti');

					if (val != undefined) {
						$restService.flagsAndLists(
                            $scope.caseRegister.operationId,
                            $scope.caseRegister.caseTypeId,
                            $scope.userId,
                            $scope.toView,
                            function(msg) {
                                $scope.disabledComponent.disableChannel = true;
                                $scope.disabledComponent.disableEvent = true;
                                $alert.error(msg.data ? msg.data.error : msg.error);
                            }
                        );
					}
				};

				$scope.caseRegisterSave = function() {
                    $scope.state.disabled = true;

					var casePayload = {};
					casePayload[$dictionaryUtils._operationId] = $scope.caseRegister.operationId;
					casePayload[$dictionaryUtils._caseTypeId] = $scope.caseRegister.caseTypeId;
					casePayload[$dictionaryUtils._userId] = $scope.userId;
					casePayload[$dictionaryUtils._externalCaseId] = $scope.caseRegister.externalCaseId;
					casePayload[$dictionaryUtils._caseIdDad] = $scope.caseRegister.caseIdDad;
					casePayload[$dictionaryUtils._channelId] = $scope.caseRegister.channelId;
					casePayload[$dictionaryUtils._eventId] = $scope.caseRegister.eventId;
					casePayload[$dictionaryUtils._dynamicFields] = $dynamicFieldsService.formatFieldsToSend($scope.datasource.fields);
					casePayload[$dictionaryUtils._observation] = $scope.caseRegister.observation;

					if ($scope.caseRegister.openingDate && $scope.caseRegister.openingDate != "") {
						casePayload[$dictionaryUtils._openingDate] = $genericUtils.toServersDateFormat($scope.caseRegister.openingDate);
					}

					$restService.registerCase(casePayload, function(c) {
						var timer = $timeout(function() {
							$route.reload();
							$timeout.cancel(timer);
						}, 1000, false);

						var msg = $filter('translate')(
								'bundle.cad.CASE_MANUAL_SAVE');
						$alert.success($stringUtilsService.format(msg,
								c[$dictionaryUtils._externalId] || ''));

					}, function(msg) {
						$alert.error(msg.data ? msg.data.error : msg.error);
                        $scope.state.disabled = false;
					});
				}
			}
            return [ '$rootScope',
                '$scope',
                '$filter',
                '$dictionaryUtilsService',
                '$comboPrettyFormatUtilsService',
                '$genericUtilsService',
                '$caseRegisterRestService',
                '$caseRegisterPrettyService',
                '$eventNamingUtilsService',
                '$route',
                '$timeout',
                '$alertUiService',
                '$dynamicFieldsService',
                '$stringUtilsService',
                CaseRegisterController ];
		});