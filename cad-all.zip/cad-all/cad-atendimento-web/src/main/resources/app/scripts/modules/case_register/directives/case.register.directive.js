define( [ ], function()
{            
    return ['$interval', function($interval){          
       return {
            restrict: 'A',
            replace: true,
            ids:'ids',
            templateUrl: 'app/scripts/modules/case_register/directives/templates/case.register.html',
            scope: {
                inputRegister: '=',
                remainingSelection: "=?",
                operations: '=',
                operationSelected: '=',
                disableOperation: '=',
                caseTypesList: '=',
                getFields: '=',
                channel: '=',
                disableChannel: '=',
                disableEvent: '=',
                showStatus: '=',
                labelStatus: '=',
                showCreatesId: '=',
                showObservation: '=',
                showOpeningDate: '=',  
                showChangeOperation: '=',
                showIdDad: '=',
                idDadRequired: '=',
                showSelectionBox: '=',
                layoutPreview: '=',
                hasAttachmentPrivilege: '=',
                allowsAttachment: '='
            },
			link : function(scope, element, attrs) {
					var checker = $interval(function() {
						if ($("#uploadp") && $('#uploadf') && $('#upload-title')) {
							//We must check whether element is ready
							$('#uploadp').addClass('form-group');
							$('#upload-title').addClass('col-sm-2 control-label');
							$('#uploadf').addClass('col-sm-10');
							$interval.cancel(checker);
						}

					}, 250, 0, false);
				}
			};
    }];

});