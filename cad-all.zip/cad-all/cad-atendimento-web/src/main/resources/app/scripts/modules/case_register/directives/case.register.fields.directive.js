define( [ ], function()
{            
    return function(){
       return {
            restrict: 'A',
            replace: true,
            templateUrl: 'app/scripts/modules/case_register/directives/templates/case.register.fields.html',
            scope:{
                inputRegister: '=',
                dynamicFields: '=fields'
            }
        };
    };
});