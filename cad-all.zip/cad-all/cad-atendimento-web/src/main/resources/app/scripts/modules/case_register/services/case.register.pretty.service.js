/**
 * Created by swb_samuel on 09/07/2015.
 */
define([ ], function () {
    var CaseRegisterPrettyService = function ($dictionaryUtils) {
        return {
            prettyLayoutToBox: function (source, _action) {
                var prettyList = [];
                if (source) {
                    $.each(source, function (index, item) {
                        var entry = {
                            title: item[$dictionaryUtils._name],
                            description: item[$dictionaryUtils._description],
                            color: item[$dictionaryUtils._color],
                            action: function () {
                                _action({
                                    layoutId: item[$dictionaryUtils._layoutId],
                                    operationId: item[$dictionaryUtils._operationId]
                                });
                            }
                        };

                        prettyList.push(entry);
                    });
                }

                return prettyList;
            }
        }
    };
    return [
        "$dictionaryUtilsService",
        CaseRegisterPrettyService];
});