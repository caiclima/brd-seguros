define( [ ], function()
{
	
    var CaseRegisterRestService = function($resource, $stringUtils, $requestUtils, $dictionaryUtils,$fileUploadService)    
    {
    	 var send = function(uri, payload, _succesFn, _errorFn) {
 	        var path = $requestUtils.contextPath();
 	        var url = $stringUtils.concatenate(path, uri);

 	        $fileUploadService.upload(url, payload, function(response){
 	             if(response == undefined || response.error == undefined){
 	                _succesFn(response);
 	             }else{
 	                _errorFn(response);
 	             }
 	        });
 	    }
    	 
        return {
            operationsList: function(userId, successFn, errorFn) {
                var resource = function() {
                    var uri = '/api/operation/user/:{0}';
                    var userIdParam = $dictionaryUtils._userId;
                    var formattedUri = $stringUtils.format(uri, userIdParam);
                    var paramDefaults = {};
                    paramDefaults[userIdParam] = $stringUtils.format('@{0}',userIdParam);
                    return $resource($stringUtils.concatenate($requestUtils.contextPath(), formattedUri), paramDefaults);
                }();

                var urlParams = {};
                urlParams[$dictionaryUtils._userId] = userId;
                resource.query(urlParams, successFn, errorFn);

            },
            caseTypeList: function(operationId, successFn, errorFn) {
                var resource = function() {
                    var uri = '/api/casetype/operation/:{0}';
                    var operationIdParam = $dictionaryUtils._operationId;
                    var formattedUri = $stringUtils.format(uri, operationIdParam);
                    var paramDefaults = {};
                    paramDefaults[operationIdParam] = $stringUtils.format('@{0}',operationIdParam);
                    return $resource($stringUtils.concatenate($requestUtils.contextPath(), formattedUri), paramDefaults);
                }();

                var urlParams = {};
                urlParams[$dictionaryUtils._operationId] = operationId;
                resource.query(urlParams, successFn, errorFn);                
            },
            layoutPreview: function(userId, successFn, errorFn) {
                var resource = function() {
                    var uri = '/api/casemanual/layoutpreview/user/:{0}';
                    var userIdParam = $dictionaryUtils._userId;

                    var formattedUri = $stringUtils.format(uri, userIdParam);
                    
                    var paramDefaults = {};
                    paramDefaults[userIdParam] = $stringUtils.format('@{0}',userIdParam);
                    
                    return $resource($stringUtils.concatenate($requestUtils.contextPath(), formattedUri), paramDefaults);
                }();
                
                var urlParams = {};
                urlParams[$dictionaryUtils._userId] = userId;

                resource.query(urlParams, successFn, errorFn);
            },
            findLayout: function(layoutId, userId, successFn, errorFn) {
                var resource = function () {
                    var uri = '/api/casemanual/layout/:{0}/user/:{1}';
                    var layoutId = $dictionaryUtils._layoutId;
                    var userIdParam = $dictionaryUtils._userId;

                    var formattedUri = $stringUtils.format(uri, layoutId, userIdParam);

                    var paramDefaults = {};
                    paramDefaults[layoutId] = $stringUtils.format('@{0}', layoutId);
                    paramDefaults[userIdParam] = $stringUtils.format('@{0}',userIdParam);

                    return $resource($stringUtils.concatenate($requestUtils.contextPath(), formattedUri), paramDefaults);
                }();

                var urlParams = {};
                urlParams[$dictionaryUtils._layoutId] = layoutId;
                urlParams[$dictionaryUtils._userId] = userId;

                resource.get(urlParams, successFn, errorFn);
            },
            flagsAndLists: function(operationId, caseTypeId, userId, successFn, errorFn) {
                var resource = function() {
                    var uri = '/api/casemanual/operation/:{0}/typecase/:{1}/user/:{2}';
                    var operationIdParam = $dictionaryUtils._operationId;
                    var caseTypeParam = $dictionaryUtils._caseType;
                    var userIdParam = $dictionaryUtils._userId;
                    var formattedUri = $stringUtils.format(uri, operationIdParam, caseTypeParam, userIdParam);

                    var paramDefaults = {};
                    paramDefaults[operationIdParam] = $stringUtils.format('@{0}',operationIdParam);
                    paramDefaults[caseTypeParam] = $stringUtils.format('@{0}',caseTypeParam);
                    paramDefaults[userIdParam] = $stringUtils.format('@{0}',userIdParam);

                    return $resource($stringUtils.concatenate($requestUtils.contextPath(), formattedUri), paramDefaults);
                }();

                var urlParams = {};
                urlParams[$dictionaryUtils._operationId] = operationId;
                urlParams[$dictionaryUtils._caseType] = caseTypeId;
                urlParams[$dictionaryUtils._userId] = userId;

                resource.get(urlParams, successFn, errorFn);                  
            },
            registerCase: function(casePayload, successFn, errorFn) {
            	 var uri = '/api/casemanual/new';                 
                 send(uri, casePayload, successFn, errorFn);
            },
            systemParameter: function(operationId,key, successFn, errorFn) {
                var resource = function() {
                	
                	var uri = '/api/operation/:{0}/parameter/:{1}';
                    var operationId = $dictionaryUtils._operationId;
                    var key = $dictionaryUtils._key;
                    var formattedUri = $stringUtils.format(uri, operationId, key);

                    var paramDefaults = {};
                    paramDefaults[operationId] = $stringUtils.format('@{0}',operationId);
                    paramDefaults[key] = $stringUtils.format('@{0}',key);

                    return $resource($stringUtils.concatenate($requestUtils.contextPath(), formattedUri), paramDefaults);
                }();

                var urlParams = {};
                urlParams[$dictionaryUtils._operationId] = operationId;
                urlParams[$dictionaryUtils._key] = key;

                resource.get(urlParams, successFn, errorFn);                  

            },
        }
    };
    return [
        "$resource",
        "$stringUtilsService",
        "$requestUtilsService",
        "$dictionaryUtilsService",
        "$simpleFileUploadService",
        CaseRegisterRestService];
});