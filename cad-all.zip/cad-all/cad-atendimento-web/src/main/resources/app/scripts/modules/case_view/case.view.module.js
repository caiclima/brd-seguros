/*
 * module definitions 
 */

define(['angular', 'CaseViewController', 'CaseViewRestService','CaseViewPreviewDirective', 'CaseViewDirective', 'CaseViewFieldsDirective','CaseViewShowDirective' ],
	function(angular, CaseViewController,CaseViewRestService ,CaseViewPreviewDirective, CaseViewDirective, CaseViewFieldsDirective, CaseViewShowDirective){
		var _m = angular.module('CaseViewModule', ['ngResource','UtilsModule','pascalprecht.translate','ngCookies', 'UiModule']);

        _m.directive('caseViewPreview', CaseViewPreviewDirective );
        _m.directive('caseView', CaseViewDirective );
        _m.directive('caseViewFields', CaseViewFieldsDirective );
        _m.directive('caseViewShow', CaseViewShowDirective );
        
        _m.factory('$caseViewRestService', CaseViewRestService);
        _m.controller('CaseViewController', CaseViewController);

		return _m;
});