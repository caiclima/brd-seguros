define( [], function()
{
    var CaseViewController = function( $scope, $rootScope, $dictionaryUtils, $eventNaming )
        {   
            /*
            *  We may have arrived here from two ways:
            *
            *  1. User logged in and was redirected to /case-view, 
            *     if only if, there is a live case set to him/her;
            *
            *  2. User manually triggered /case-view route
            *     and then we show him his/her current case;
            */


            /*
            *   Get Namespace object, but it might have been set yet
            */
            var namespace = $rootScope.Namespace;
        
           $scope.$on($eventNaming.NamespaceCaseChanged, function(event, Case) {
        	   if(Case){
        		   namespace.OperacaoAtual = Case[$dictionaryUtils._operationId]; 
        	   }else{
        		   namespace.OperacaoAtual = namespace.User[$dictionaryUtils._mainOperation]; 
        	   }
           });

            /*
            *  It's mandatory to have user data in order to request a case.
            *  If we don't have it, we must wait Loading routine to complete.
            */
            if(namespace.Loaded) {
                processRequest();
            } else {                
                $scope.$on($eventNaming.LoadingComplete, function(event) {
                    processRequest();
                }); 
            }
            /*
            *  Process any kind of request to Case-View Controller
            */
            function processRequest() {
                /*
                *  just show current case.
                */
                $scope.currentCase = namespace.Case.Current;

                if($scope.currentCase){
                    namespace.OperacaoAtual = $scope.currentCase[$dictionaryUtils._operationId];
                }else{
                    namespace.OperacaoAtual = namespace.User[$dictionaryUtils._mainOperation];
                }
            }
        };
    return [ 
            "$scope",
            "$rootScope",
            "$dictionaryUtilsService",
            "$eventNamingUtilsService",
            CaseViewController 
        ];
});