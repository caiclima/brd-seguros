define( [ ], function()
{            
    return ['$interval','$caseCheckerUtilsService',
        function($interval, $caseCheckerUtils){
        	 return {
                restrict: 'A',
                replace: true,
                scope: {
                    currentCase: '='
                },
                templateUrl: 'app/scripts/modules/case_view/directives/templates/case.view.html',
                link: function(scope, element, attrs) {
                    
                    scope.$watch('currentCase', function(newVal, oldVal){
                        if(newVal !== undefined){
                            scope.hasCase = $caseCheckerUtils.realCase(newVal);
                            
                            if(scope.hasCase){
                            	scope.end = parseInt( newVal.listCampoDinamicoTO.length / 2);
                                
                                newVal.listCamposDin1 = newVal.listCampoDinamicoTO.slice(0, scope.end );
                                newVal.listCamposDin2 = newVal.listCampoDinamicoTO.slice( scope.end, newVal.listCampoDinamicoTO.length );
                                
                                var checker = $interval(function() {
                                    //We must check whether element is ready
                                    if($('#caseDescription').length > 0) {
                                        if (newVal.descricao) {
                                            $('#caseDescription').html(newVal.descricao);
                                        }
                                        $interval.cancel(checker);
                                    }
                                }, 250, 0, false);
                            }
                        }
                    }, true);
                }
            };
        }
    ];
});