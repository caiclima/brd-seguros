define([ ], function () {
    return ['$interval', '$caseCheckerUtilsService', '$dynamicFieldsService',
        function ($interval, $caseCheckerUtils, $dynamicFieldsService) {
            return {
                restrict: 'A',
                replace: true,
                scope: {
                    currentCase: '='
                },
                templateUrl: 'app/scripts/modules/case_view/directives/templates/case.view.fields.html',
                link: function (scope, element, attrs) {
                    scope.hasCase = false;

                    scope.$watch('currentCase', function (newVal, oldVal) {
                        if (newVal !== undefined) {
                            scope.hasCase = $caseCheckerUtils.realCase(newVal);

                            scope.formattedList = [];
                            var textAreaObjects = [];
                            
                            if(scope.hasCase){
                            	scope.formattedList = $dynamicFieldsService.formatDynamicField(newVal.listCampoDinamicoTO, newVal)
                            	 
                            	for (var it = 0; it < newVal.listCampoDinamicoTO.length; ++it) {
                                    var campo = newVal.listCampoDinamicoTO[it];
                                    if (campo && campo.tipoCampo == 'AREA_TEXTO' && campo.valor) {
                                        textAreaObjects.push({id: 'text' + campo.idCampoDinamico, value: campo.valor});
                                    }
                                }
                            }
                            
                            var checker = $interval(function () {
                                for (var it = 0; it < textAreaObjects.length; ++it) {
                                    var object = textAreaObjects[it];
                                    //We must check whether element is ready
                                    if ($('#' + object.id).length > 0) {
                                        if (object.value) {
                                            $('#' + object.id).html(object.value);
                                        }
                                        $interval.cancel(checker);
                                    }
                                }
                            }, 250, 0, false);

                        }
                    }, true);
                }
            };
        }
    ];
});