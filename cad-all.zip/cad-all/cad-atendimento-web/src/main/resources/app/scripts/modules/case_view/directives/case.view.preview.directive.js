define( [ ], function()
{            
    return ['$eventNamingUtilsService',
        function($eventNaming){
        	 return {
                restrict: 'A',
                replace: true,
                templateUrl: 'app/scripts/modules/case_view/directives/templates/case.view.preview.html',
                link: function(scope, element, attrs) {
                    scope.$on($eventNaming.NamespaceCaseChanged, function(event, Case) {
                        scope.currentCase = Case;
                    });
                }
            };
        }];
});