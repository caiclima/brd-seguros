define( [ ], function()
{            
    return [
        function(){
        	 return {
                restrict: 'A',
                replace: true,
                scope: {
                	field : '=',
                    currentCase: '='
                },
                templateUrl: 'app/scripts/modules/case_view/directives/templates/case.view.show.html',
                link: function(scope, element, attrs) {
                }
            };
        }
    ];
});