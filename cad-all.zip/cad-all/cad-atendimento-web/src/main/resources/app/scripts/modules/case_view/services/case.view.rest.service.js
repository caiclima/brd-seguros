define( [ ], function()
{
    var CaseViewRestService = function($resource, $stringUtils, $requestUtils, $dictionaryUtils)
    {
        function caseResource(uri, actionName, extraParams) {
            var userIdParam = $dictionaryUtils._userId;
            var formattedUri = $stringUtils.format(uri, userIdParam);

            var paramDefaults = {};
            paramDefaults[userIdParam] = $stringUtils.format('@{0}',userIdParam);
            for(var it = 0; extraParams !== undefined && it < extraParams.length; ++it) {
                var param = extraParams[it];
                paramDefaults[param] = $stringUtils.format('@{0}', param);
            }

            var actions = {};
            actions[actionName] = {};
            actions[actionName]['method'] = 'PUT';
            actions[actionName]['params'] = paramDefaults;

            return $resource($requestUtils.contextPath() + formattedUri, paramDefaults, actions);
        }

        return {
            //The common request for the Case Handling Cycle
            nextCase: function(userId, successFn, errorFn){
                var payload = {};
                payload[$dictionaryUtils._userId] = userId;
                return caseResource('/api/cases/nextCase/:{0}', 'nextCase')
                            .nextCase(payload, successFn, errorFn);
            },
            //Request a fresh new case. Which User have never seen before
            userRequestCase: function(userId, successFn, errorFn) {
                var payload = {};
                payload[$dictionaryUtils._userId] = userId;
                return caseResource('/api/cases/userRequestCase/:{0}', 'userRequestCase')
                            .userRequestCase(payload, successFn, errorFn);
            },
            //Switch current case to a pending one. User will have picked it in Pending Cases table.
            requestCase: function(userId, caseId, successFn, errorFn) {
                var payload = {};
                payload[$dictionaryUtils._userId] = userId;
                payload[$dictionaryUtils._caseId] = caseId;

                return caseResource('/api/cases/requestCase/:{0}', 'requestCase')
                            .requestCase(payload, successFn, errorFn);
            }
        };
    };
    return [
        "$resource",
        "$stringUtilsService",
        "$requestUtilsService",
        "$dictionaryUtilsService",
        CaseViewRestService];
});