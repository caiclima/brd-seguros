define(['angular','DaemonEvaluatorService', 'DaemonExecutorService'], 
    function(angular, DaemonEvaluatorService, DaemonExecutorService) {
        var _m = angular.module('DaemonModule', ['NotificationsModule']);

        _m.factory('$daemonEvaluatorService', DaemonEvaluatorService);
        _m.factory('$daemonExecutorService', DaemonExecutorService);

        return _m;
    }
);