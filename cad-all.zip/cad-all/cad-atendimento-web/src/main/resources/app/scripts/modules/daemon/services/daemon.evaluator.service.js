define([], function() {    

    var DaemonEvaluatorService = function() {
        return  {
            evalServices: function(services) {
                for(var it = 0; it < services.length; ++it) {
                    var service = services[it];
                    if(service.http ? !_evalHttpService(service.logic) : !_evalLocalService(service.logic)) {
                        throw "Invalid service: " + service;
                    }
                }
                return services;
            }
        };
    };

    function _evalHttpService (logic) {
        return logic.setup !== undefined && logic.doPoll  !== undefined && logic.doPush  !== undefined;
    }

    function _evalLocalService(logic) {
        return logic.setup !== undefined && logic.run !== undefined;
    }

    return DaemonEvaluatorService;
});