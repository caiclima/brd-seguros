define([], function() {
   return ['$daemonEvaluatorService','$interval',
    function($daemonEvaluatorService, $interval) {
        
        function _exec(service, ajaxModel) {
            if(service.http && ajaxModel === 'poll'){
                return $interval(service.logic.doPoll, service.delay, 0, false);
            } else if(service.http && ajaxModel === 'push') {
                service.logic.doPush();
                return null;
            } else {
                return $interval(service.logic.run, service.delay, 0, false);
            }
        };

        function _stop(service, checker) {
            var indexRemove = undefined;
            for(var it = 0; it < checker.length; ++it) {
                var _checker = checker[it];

                if(_checker && _checker.service === service){
                    $interval.cancel(_checker.interval);
                    indexRemove = it;
                };
            }

            if(indexRemove){
                checker.splice(indexRemove, 0);
            }
        };

        return {
            checker: [],
            services: [],
            setupObj: {},

            setup: function(setupObj, services) {
                this.setupObj = setupObj;
                this.services = $daemonEvaluatorService.evalServices(services);
                return this;
            },

            start: function() {
                var ajaxModel = this.setupObj.ajaxModel;
                for(var it = 0; it < this.services.length; ++it) {
                    var _service = this.services[it];
                    _service.logic.setup(this.setupObj);
                    var _checker = _exec(_service, ajaxModel);

                    this.checker.push({
                        service: _service,
                        interval: _checker
                    });
                }
            },

            stopAll: function(){
                for(var it = 0; it < this.services.length; ++it) {
                    var _service = this.services[it];
                    _stop(_service, this.checker);
                }
            },

            restart: function(setupObj, services) {
                this.setup(setupObj,services);
                this.stopAll();
                this.start();
            }
        };
   }];
});