define( [], function()
{            
    return function(){        	
    	 return {
            restrict: 'A',
            replace: false,
            templateUrl: 'app/scripts/modules/disconnection_handler/directives/templates/disconnection.html'
        };
    };
});