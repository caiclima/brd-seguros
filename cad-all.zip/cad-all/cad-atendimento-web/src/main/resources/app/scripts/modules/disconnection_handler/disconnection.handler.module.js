/*
 * module definitions 
 */
 
define(['angular', 'DisconnectionHandlerDirective', 'DisconnectionHandlerService'], function(angular, DisconnectionHandlerDirective, DisconnectionHandlerService){
	var _m = angular.module('DisconnectionHandlerModule', []);

	_m.factory('$disconnectionHandlerService', DisconnectionHandlerService);
	_m.directive('disconnectionView', DisconnectionHandlerDirective);
	
	return _m;
});