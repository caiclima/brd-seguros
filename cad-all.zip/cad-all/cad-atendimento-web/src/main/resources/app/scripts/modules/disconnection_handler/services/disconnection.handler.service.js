define([], function()
{
    return ['$q',
            '$rootScope',
            '$timeout',
            '$window',
            '$progressBarService',
            '$loadingPageService',
            '$ssoService',
            '$daemonExecutorService',
            '$injector', function($q,
                                  $rootScope,
                                  $timeout,
                                  $window,
                                  $progressBarService,
                                  $loadingPageService,
                                  $ssoService,
                                  $daemonExecutorService,
                                  $injector){

    	var _fn = {};
        var $http;

    	_fn.contextPath = function (){
            return '/' + window.location.pathname.split('/')[1];
        }
    	
    	_fn.active = false;
    	
    	_fn.setMaxAttempts = function(t){
    		_fn.maxAttempts = t;
    	}
    	
    	_fn.request = function(config) {
    		if(!$progressBarService.isStarted()){
    			if(!_fn.isXPollRequest(config)){
    				$loadingPageService.show();
    			}
    		}
    		return config;
    	};
    	
    	_fn.isXPollRequest = function(config){
    		return config.headers['X-Poll'] != undefined;
    	}
    	
    	_fn.response = function(response) {
            $http = $http || $injector.get('$http');

            if($http.pendingRequests.length < 1) {
                var timer = $timeout(function () {
                    $loadingPageService.hide();
                    $timeout.cancel(timer);
                }, 0, false);
            }

    		return response;
    	}
    	
    	_fn.responseError = function(rejection) {
    		if(_fn.verifyBrokenRequest(rejection)){
    			return;
    		}
    		$loadingPageService.hide();
    		
    		if(!$progressBarService.isStarted()){
                var timer = $timeout(function(){
	    			_fn.act();
                    $timeout.cancel(timer);
	    		}, 800, false);
    		}
    		
    		return $q.reject(rejection);
    	}
    	
    	_fn.verifyBrokenRequest = function(rejection){
    		if(typeof rejection.data != undefined && typeof rejection.data.error != undefined){
    			if(new RegExp(".*partial.*inc.*", "i").test(rejection.data.error)){
    				$ssoService.destroy();
    				return true;
    			}
    		}
    		return false;
    	}
    	
    	
    	_fn.getResURI = function(){
    		return _fn.contextPath() + '/api/srvp';
    	}
    	
    	_fn.isJbossConnectionError = function(d){
    		if(d.statusText == "error" || d.statusText == "timeout"){
				if(d.readyState == 0 && d.status == 0){
					return true;
				}
    		}
    		return false;
    	}
    	
    	_fn.isApacheModJK = function(d){
    		if(d.statusText == "Internal Server Error"){
				if(d.readyState == 4 && d.status == 500){
					return true;
				}
    		}
    		return false;
    	}
    	
    	_fn.act = function(){
    		try{
    			$.ajaxSetup({ timeout:_fn.connectionTimeout });
    			
    			var uri = _fn.getResURI();
    			var xhr = $.get(uri, function() {
					}).fail(function(error) {
						try{
							$loadingPageService.hide();
							if(_fn.isJbossConnectionError(error) || _fn.isApacheModJK(error)){
								if(!_fn.active){
					    			_fn.showTrying();
									_fn.showDisconnectModal();
						    		_fn.limit = 1;
						    		_fn.setLimit(_fn.limit);
						    		_fn.tryReconnection();
								}
							}
						}catch(e){
			    			_fn.active = false;
			    		}
					});
    		}catch(e){
    			_fn.active = false;
    		}
    	}
    	
    	_fn.tryReconnection = function(){
    		$timeout(function(){
    			$.ajaxSetup({ timeout:_fn.connectionTimeout });
    			
    			var uri = _fn.getResURI();
    			var xhr = $.get(uri, function() {
    				_fn.reconnected();
				}).fail(function(error) {
					if(_fn.limit < _fn.maxAttempts){
						_fn.limit++;
						_fn.setLimit(_fn.limit);
						_fn.tryReconnection();
					}else{
						_fn.failure();
					}
				});
    		}, 10000, false);
    	}
    	
    	_fn.setLimit = function(l){
    		_fn.find($("#attempts")).text(l);
    	}
    	
    	_fn.reconnected = function(){
    		_fn.active = false;
    		_fn.hide($(".trying"));
    		_fn.hide($(".failure"));
    		_fn.show($(".success"));
    	}
    	
    	_fn.showTrying = function(){
    		_fn.active = true;
    		_fn.show($(".trying"));
    		_fn.hide($(".failure"));
    		_fn.hide($(".success"));
    		_fn.find($("#total-attempts")).text(_fn.maxAttempts);
    	}
    	
    	_fn.failure = function(){
    		_fn.active = false;

    		_fn.hide($(".trying"));
    		_fn.hide($(".success"));
    		_fn.show($(".failure"));
    		
    		_fn.find($("#failureButton")).click(function(){
    			var namespace = $rootScope.Namespace;
    			namespace.Loaded = false;
    			$daemonExecutorService.stopAll();
    			$window.location.href = _fn.contextPath() + '/logout';
    		});
    	}
    	
    	_fn.show = function(el){
    		_fn.find(el).show();
    	}
    	
    	_fn.hide = function(el){
    		_fn.find(el).hide();
    	}

    	_fn.find = function(selector){
            return $(selector, $("#disconnectModal"));
        }
    	
    	_fn.showDisconnectModal = function(){
    		$("#disconnectModalButton").click();
    		$("#disconnectModalButton").parent().show();
    		$("#disconnectModalButton").hide();
    	}
    	
    	/*
    	 * default 10 attempts
    	 */
    	_fn.setMaxAttempts(10); 
    	
    	/*
    	 * connection timeout
    	 */
    	_fn.connectionTimeout = 2000;

    	return _fn;
    }];

});