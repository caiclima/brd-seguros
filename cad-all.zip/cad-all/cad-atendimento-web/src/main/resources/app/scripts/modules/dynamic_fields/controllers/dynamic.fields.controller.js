define([], function() {

	var DynamicFieldsController = function($rootScope, 
										   $scope, 
										   $routeParams, 
										   $dynamicFieldsService, 
										   $alert,
										   $dictionaryUtils) {

		if($scope.fetchLayout() === undefined || $scope.fetchLayout() == true) {
			var actionId = $routeParams.actionId;
			var currentCase = $rootScope.Namespace.Case.Current;
			var caseId = currentCase[$dictionaryUtils._caseId];

			$dynamicFieldsService.fetchLayout(actionId, caseId,
				function(fields) {
					$scope.datasource.fields = $dynamicFieldsService.formatDynamicField(fields, currentCase);
					$scope.onFieldsResponded(fields.length == 0);
				},
				function(msg) {
	                $alert.error(msg.data ? msg.data.error : msg.error);
				});
		}
		
	};

	return ['$rootScope', 
			'$scope', 
			'$routeParams', 
			'$dynamicFieldsService',
			'$alertUiService',
			'$dictionaryUtilsService',
			DynamicFieldsController];
});