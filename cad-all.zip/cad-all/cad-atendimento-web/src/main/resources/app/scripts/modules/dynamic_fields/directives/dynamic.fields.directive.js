define([], function () {
    return ['$comboPrettyFormatUtilsService', '$compile', '$interval', function ($comboFormatterUtils, $compile, $interval) {
        return {
            restrict: 'A',
            replace: true,
            templateUrl: 'app/scripts/modules/dynamic_fields/directives/templates/dynamic.fields.html',
            scope: {
                field: '='
            },
            link: function (scope, element, attrs) {
                scope.booleanSuggestion = $comboFormatterUtils.booleanOptions();

                scope.$watch('field', function (newVal, oldVal) {
                    if (newVal && newVal.typeField == 'TABELA') {
                        var tableEl = "<div dynamic-fields-table field='field' name='dynamic'></div>";
                        var elId = 'div#' + 'dynamicTable' + newVal.dynamicFieldId;

                        var checker = $interval(function() {
                            if($(elId) && $(elId).length) {
                                $(elId).replaceWith($compile(tableEl)(scope));
                                $interval.cancel(checker);
                            }

                        }, 250, 0, false);
                    }
                });
            }
        };
    }];
});