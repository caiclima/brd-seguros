define([], function() {
	return function() {
		return {
			restrict: 'A',
      replace: true,
      templateUrl: 'app/scripts/modules/dynamic_fields/directives/templates/dynamic.fields.list.html',
      scope: {
        datasource: '=',
        fetchLayout: '&'
      },
      controller: 'DynamicFieldsController',
      link: function(scope, element, attrs) {
        scope.onFieldsResponded = function(noFields) {
          if(noFields) {
            $(element).parent().hide();
          }
        }
      }
		};
	};
});