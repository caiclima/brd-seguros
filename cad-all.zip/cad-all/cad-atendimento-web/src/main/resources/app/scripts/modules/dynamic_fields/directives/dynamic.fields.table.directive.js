/**
 * Created by swb_samuel on 30/04/2015.
 */
define([], function () {
    return ['$dictionaryUtilsService', function ($dictionaryUtils) {
        return {
            restrict: 'A',
            replace: true,
            templateUrl: 'app/scripts/modules/dynamic_fields/directives/templates/dynamic.fields.table.html',
            scope: {
                field: '=?',
                readOnly: '=?'
            },
            link: function (scope, element, attrs) {
                if (scope.readOnly == undefined) {
                    scope.readOnly = false;
                }

                var fakeId = -1;

                var getModelEdit = function (id) {
                    return {
                        lineId: id,
                        show: true,
                        action: function (evt, item) {
                            scope.prepareEdit(this.lineId, item);
                        }
                    };
                };
                var getModelRemove = function (id) {
                    return {
                        lineId: id,
                        show: true,
                        action: function (evt, item) {
                            scope.remove(this.lineId, item);
                        }
                    };
                };
                var getColDefEdit = function () {
                    return {
                        type: 'button-toogle-2',
                        icon: 'icon-4-1',
                        width: '5%'
                    };
                };
                var getColDefRemove = function () {
                    return {
                        type: 'button-toogle-2',
                        icon: 'icon-21-8',
                        width: '5%'
                    };
                };
                var createEntry = function (id, fields) {
                    if(fields && fields.length){
                        var entry = {};

                        if (!scope.readOnly) {
                            entry.modelEdit = getModelEdit(id);
                            entry.modelRemove = getModelRemove(id);
                        }

                        $.each(fields, function (index, item) {
                            entry[index.toString()] = item.value;
                        });

                        return entry;
                    }

                    return undefined;
                };
                var reset = function () {
                    $.each(scope.form.dynamicFields, function (index, item) {
                        item.value = undefined
                    });
                    scope.form.dynamics.$setPristine();
                };

                scope.tableConfig = [];
                scope.datasource = [];
                scope.form = {
                    dynamicFields: undefined
                };

                scope.remove = function (lineId, item) {
                    scope.field.tableItens = $.grep(scope.field.tableItens, function (item, index) {
                        if (item.id == lineId) {
                            return false;
                        }
                        return true;
                    });

                    scope.datasource.splice(scope.datasource.indexOf(item), 1);
                };

                scope.prepareEdit = function (lineId, item) {
                    reset();
                    $('#modalAdd'+scope.field.dynamicFieldId).modal({
                        'backdrop': 'static',
                        keyboard: false
                    });

                    scope.indexTable = scope.datasource.indexOf(item);
                    scope.itemEdit = lineId;

                    scope.datasource.splice(scope.indexTable, 1);

                    $.each(scope.field.tableItens, function (index, item) {
                        if (item.id == lineId) {
                            $.each(item.columns, function (idx, it) {
                                $.each(scope.form.dynamicFields, function (id, field) {
                                    if (it.dynamicFieldId == field.dynamicFieldId) {
                                        field.value = it.value;
                                        return false;
                                    }
                                });
                            });
                            return false;
                        }
                    });
                };

                scope.addNewItem = function () {
                    reset();
                    $('#modalAdd'+scope.field.dynamicFieldId).modal({
                        'backdrop': 'static',
                        keyboard: false
                    });
                };

                scope.cancelEdit = function () {
                    $.each(scope.field.tableItens, function (index, item) {
                        if (item.id == scope.itemEdit) {
                            scope.datasource.splice(scope.indexTable, 0, createEntry(item.id, item.columns));
                            return false;
                        }
                    });

                    scope.itemEdit = undefined;
                    scope.indexTable = undefined;
                };

                scope.add = function () {
                    if (scope.field.tableItens == undefined) {
                        scope.field.tableItens = [];
                    }

                    if (scope.itemEdit) {
                        $.each(scope.field.tableItens, function (index, item) {
                            if (item.id == scope.itemEdit) {
                                $.each(item.columns, function (idx, it) {
                                    $.each(scope.form.dynamicFields, function (id, field) {
                                        if (it.dynamicFieldId == field.dynamicFieldId) {
                                            it.value = field.value;
                                            return false;
                                        }
                                    });
                                });
                                scope.datasource.splice(scope.indexTable, 0, createEntry(item.id, item.columns));
                                return false;
                            }
                        });

                        scope.itemEdit = undefined;
                        scope.indexTable = undefined;
                        return;
                    }

                    var newItem = {
                        id: --fakeId,
                        columns: angular.copy(scope.form.dynamicFields)
                    };
                    scope.field.tableItens.push(newItem);
                    scope.datasource.push(createEntry(newItem.id, newItem.columns));
                };

                var unWatch = scope.$watch('field', function (newVal, oldVal) {
                    if (newVal && newVal.tableFields) {
                        scope.form.dynamicFields = angular.copy(newVal.tableFields);

                        $.each(newVal.tableFields, function (index, item) {
                            var colDef = {
                                title: item.label,
                                breakWord: false
                            };
                            scope.tableConfig.push(colDef);
                        });

                        if (!scope.readOnly) {
                            scope.tableConfig.push(getColDefEdit());
                            scope.tableConfig.push(getColDefRemove());
                        }
                    }

                    if (newVal && newVal.tableItens) {
                        $.each(newVal.tableItens, function (index, item) {
                            if (item) {
                                var entry = createEntry(item.id, item.columns);
                                if(entry){
                                    scope.datasource.push(entry);
                                }
                            }
                        });
                    }

                    unWatch();
                });
            }
        }
    }]
});