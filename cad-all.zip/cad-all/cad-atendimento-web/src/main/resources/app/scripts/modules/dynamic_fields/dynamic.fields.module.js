/*
 * module definitions 
 */

define(['angular', 
	    'DynamicFieldsDirective',
	    'DynamicFieldsListDirective',
        'DynamicFieldsTableDirective',
	    'DynamicFieldsController',
	    'DynamicFieldsService' ], 

	function(angular, 
			 DynamicFieldsDirective, 
			 DynamicFieldsListDirective,
             DynamicFieldsTableDirective,
			 DynamicFieldsController, 
			 DynamicFieldsService){

		var _m = angular.module('DynamicFieldsModule', []);

		_m.directive('dynamicFields',DynamicFieldsDirective );
		_m.directive('dynamicFieldsList',DynamicFieldsListDirective );
        _m.directive('dynamicFieldsTable',DynamicFieldsTableDirective );
        _m.controller('DynamicFieldsController', DynamicFieldsController);
        _m.factory('$dynamicFieldsService', DynamicFieldsService);

		return _m;
});