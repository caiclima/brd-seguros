define([], function() {

	var DynamicFieldsService = function($resource, $stringUtils, $genericUtils, $requestUtils, $dictionaryUtils, $comboFormatterUtils) {
		return {
			fetchLayout: function(actionId, caseId, successFn, errorFn) {				
                var resource = function() {
                    var uri = '/api/dynamicfield/action/:{0}/case/:{1}';
                    var actionIdParam = $dictionaryUtils._actionId;
                    var caseIdParam = $dictionaryUtils._caseId;
                    var formattedUri = $stringUtils.format(uri, actionIdParam, caseIdParam);

                    var paramDefaults = {};
                    paramDefaults[actionIdParam] = $stringUtils.format('@{0}',actionIdParam);
                    paramDefaults[caseIdParam] = $stringUtils.format('@{0}',caseIdParam);

                    return $resource($stringUtils.concatenate($requestUtils.contextPath(), formattedUri), paramDefaults);
                }();

                var urlParams = {};
                urlParams[$dictionaryUtils._actionId] = actionId;
                urlParams[$dictionaryUtils._caseId] = caseId;
                resource.query(urlParams, successFn, errorFn);     
			},

            formatDynamicField: function(objectList, Case) {
                var list = [];
                if(objectList){
                    $.each(objectList, function(index, item){
                        var pretty = {
                            dynamicFieldId  : item[$dictionaryUtils._dynamicFieldId],
                            typeField       : item[$dictionaryUtils._typeField],
                            sizeField       : item[$dictionaryUtils._sizeEn],
                            label           : item[$dictionaryUtils._labelEn],
                            hasNotNull      : item[$dictionaryUtils._isNotNul],
                            hasDynamicField : item[$dictionaryUtils._isDynamicField],
                            mask            : item[$dictionaryUtils._mask],
                            regex			: item[$dictionaryUtils._regex],
                            hasTime			: item[$dictionaryUtils._hasTime],
                            upperLimit		: item[$dictionaryUtils._upperLimit],
                            lowerLimit		: item[$dictionaryUtils._lowerLimit],
                            value			: item[$dictionaryUtils._value]
                        };
                        
                        pretty.tableFields = [];
                        pretty.tableItens = [];
                        
                        if(item[$dictionaryUtils._tableFields]){
                        	$.each(item[$dictionaryUtils._tableFields], function(ix, it){
                        		var tableField = {
                    				dynamicFieldId  : it[$dictionaryUtils._dynamicFieldId],
                    				typeField       : it[$dictionaryUtils._typeField],
                    				sizeField       : it[$dictionaryUtils._sizeEn],
                    				label           : it[$dictionaryUtils._labelEn],
                    				hasNotNul       : it[$dictionaryUtils._isNotNul],
                    				mask            : it[$dictionaryUtils._mask],
                                    regex			: it[$dictionaryUtils._regex],
                    				hasTime			: it[$dictionaryUtils._hasTime],
                                    upperLimit		: it[$dictionaryUtils._upperLimit],
                                    lowerLimit		: it[$dictionaryUtils._lowerLimit],
                                    value			: it[$dictionaryUtils._value]
                        		};
                        		
                        		pretty.tableFields.push(tableField);
                        	});
                        }
                        
                        if(item[$dictionaryUtils._tableItens]){
                        	$.each(item[$dictionaryUtils._tableItens], function(ix, it){
                        		if(it && it[$dictionaryUtils._tableColumns]){
                        			var line = {};
                        			line.id = it.id;
                        			line.columns = [];
                        			
                        			$.each(it[$dictionaryUtils._tableColumns], function(idx, ite){
										if (ite) {
											var tableField = {
	                            				dynamicFieldId  : ite[$dictionaryUtils._dynamicFieldId],
	                            				typeField       : ite[$dictionaryUtils._typeField],
	                            				sizeField       : ite[$dictionaryUtils._sizeEn],
	                            				label           : ite[$dictionaryUtils._labelEn],
	                            				hasNotNul       : ite[$dictionaryUtils._isNotNul],
	                            				mask            : ite[$dictionaryUtils._mask],
	                                            regex			: ite[$dictionaryUtils._regex],
	                            				hasTime			: ite[$dictionaryUtils._hasTime],
                                                upperLimit		: ite[$dictionaryUtils._upperLimit],
                                                lowerLimit		: ite[$dictionaryUtils._lowerLimit],
                                                value			: ite[$dictionaryUtils._value]
	                                		};

											if (tableField.typeField == 'DATA' && tableField.value) {
												if (tableField.hasTime) {
													tableField.value = moment(tableField.value).format("DD/MM/YYYY hh:mm:ss");
												} else {
													tableField.value = moment(tableField.value).format("DD/MM/YYYY");
												}
											}

											if (tableField.typeField == 'NUMERO' && tableField.value) {
												tableField.value = Number(tableField.value);
											}
											
											line.columns.push(tableField);
										}
                                	});
                        			
                        			pretty.tableItens.push(line);
                        		}
                        	});
                        }
                        
                        switch(pretty.typeField) {
                            case 'DATA_ABERTURA':
                                if (Case[$dictionaryUtils._openingDate]) {
                                    pretty.value = $genericUtils.fromServersDateFormat(Case[$dictionaryUtils._openingDate]);
                                }
                                break;
                            case 'ID_JUNCAO':
                                pretty.value = Case[$dictionaryUtils._junctionId];
                                break;
                            case 'ID_OUTRA_AREA':
                                pretty.value = Case[$dictionaryUtils._externalAreaId];
                                break;
                            case 'ID_TIPO_CASO':
                                pretty.value = Case[$dictionaryUtils._caseTypeId];
                                break;
                            case 'ID_EVENTO':
                                pretty.value = Case[$dictionaryUtils._eventId];
                                break;
                            case 'ID_CAUSA':
                                pretty.value = Case[$dictionaryUtils._reasonId];
                                break;
                            case 'ID_CANAL':
                                pretty.value = Case[$dictionaryUtils._channelId];
                                break;
                            case 'ID_STATUS':
                                pretty.value = Case[$dictionaryUtils._statusId];
                                break;
                            case 'ID_CONFIGURACAO_FILA':
                                pretty.value = Case[$dictionaryUtils._queueConfigId];
                                break;
                            case 'ID_EXTERNO':
                                pretty.value = Case[$dictionaryUtils._externalId];
                                break;
                            case 'DESCRICAO':
                                pretty.value = Case[$dictionaryUtils._description];
                                break;
                            case 'DATA':
                                if (item[$dictionaryUtils._value]) {
                                    pretty.value = $genericUtils.fromServersDateFormat(item[$dictionaryUtils._value]);
                                }
                                break;
                            case 'NUMERO':
                                if (item[$dictionaryUtils._value]) {
                                    pretty.value = Number(item[$dictionaryUtils._value]);
                                }
                                break;
                            case 'LISTA_UNICA':
                                pretty.valueList = $comboFormatterUtils.format(
                                                        item[$dictionaryUtils._valueList], 
                                                        $dictionaryUtils._domainFieldId, 
                                                        $dictionaryUtils._domainFieldValue);
                                if (item[$dictionaryUtils._selectedValueList]) {
                                    pretty.selectedValueList = $comboFormatterUtils.format(
                                                            item[$dictionaryUtils._selectedValueList], 
                                                            $dictionaryUtils._domainFieldId, 
                                                            $dictionaryUtils._domainFieldValue);
                                    
                                    pretty.value = pretty.selectedValueList[0].id;
                                }
                                break;
                            case 'LISTA_MULTIPLA':
                                pretty.valueList = $comboFormatterUtils.format(
                                                        item[$dictionaryUtils._valueList], 
                                                        $dictionaryUtils._domainFieldId, 
                                                        $dictionaryUtils._domainFieldValue);
                                pretty.selectedValueList = $comboFormatterUtils.format(
                                                        item[$dictionaryUtils._selectedValueList], 
                                                        $dictionaryUtils._domainFieldId, 
                                                        $dictionaryUtils._domainFieldValue);
                                break;
                            default:
                                pretty.value = item[$dictionaryUtils._value];
                        }
                        list.push(pretty);
                    });
                }
                return list;
            },

            formatFieldsToSend: function(dynamicFields) {
                var dynamicFieldsList = [];

                $.each(dynamicFields, function(index, item){
                    var pretty = {};
                    pretty[$dictionaryUtils._dynamicFieldId] = item.dynamicFieldId;
                    pretty[$dictionaryUtils._isDynamicField] = item.hasDynamicField;
                    pretty[$dictionaryUtils._typeField] = item.typeField;
                    pretty[$dictionaryUtils._tableItens] = [];

                    if(item.tableItens){
                    	$.each(item.tableItens, function(ix, it){
                    		if(it){
                    			if(it && it.columns){
                        			var line = {};
                        			line.id = it.id;
                        			line[$dictionaryUtils._tableColumns] = [];
                        			
                        			$.each(it.columns, function(idx, ite){
										if (ite) {
											var tableField = {};
		                                    tableField[$dictionaryUtils._dynamicFieldId] = ite.dynamicFieldId;
		                                    tableField[$dictionaryUtils._typeField] = ite.typeField;
		                                    tableField[$dictionaryUtils._sizeEn] = ite.sizeField;
		                                    tableField[$dictionaryUtils._labelEn] = ite.label;
		                                    tableField[$dictionaryUtils._isNotNul] = ite.hasNotNul;
		                                    tableField[$dictionaryUtils._mask] = ite.mask;
		                                    tableField[$dictionaryUtils._regex] = ite.regex;
		                                    tableField[$dictionaryUtils._hasTime] = ite.hasTime;
		                                    tableField[$dictionaryUtils._value] = ite.value;
		                                    
			                                if (tableField[$dictionaryUtils._typeField] == 'DATA' && tableField[$dictionaryUtils._value]) {
			                                	tableField[$dictionaryUtils._value] = $genericUtils.toServersDateFormat(tableField[$dictionaryUtils._value]);
			                                }
	                                		
		                                    line[$dictionaryUtils._tableColumns].push(tableField);
										}
                                	});
                        			
                        			pretty[$dictionaryUtils._tableItens].push(line);
                        		}
                    		}
                    	});
                    }

                    var selectedValueList = undefined;
                    if (item.value && (item.typeField == 'DATA' || item.typeField == 'DATA_ABERTURA' || item.typeField == 'DATA_AGENDAMENTO')) {
                        pretty[$dictionaryUtils._value] = $genericUtils.toServersDateFormat(item.value);
                    } else if (item.typeField == 'LISTA_UNICA') {
                        for (var it = 0; it < item.valueList.length; ++it) {
                            if (item.value == item.valueList[it].id) {
                                selectedValueList = [];
                                selectedValueList.push(item.valueList[it]);
                                break;
                            }
                        }
                        pretty[$dictionaryUtils._selectedValueList] = $comboFormatterUtils.formatInverse(selectedValueList, $dictionaryUtils._domainFieldId, $dictionaryUtils._domainFieldValue);
                    } else if (item.typeField == 'LISTA_MULTIPLA') {
                        pretty[$dictionaryUtils._selectedValueList] = $comboFormatterUtils.formatInverse(item.selectedValueList, $dictionaryUtils._domainFieldId, $dictionaryUtils._domainFieldValue);
                    } else {
                        pretty[$dictionaryUtils._value] = item.value;
                    }

                    dynamicFieldsList.push(pretty);
                });

                return dynamicFieldsList;
            }
		};
	};

	return ['$resource', 
            '$stringUtilsService', 
            '$genericUtilsService', 
            '$requestUtilsService', 
            '$dictionaryUtilsService',
            '$comboPrettyFormatUtilsService',
            DynamicFieldsService];
});