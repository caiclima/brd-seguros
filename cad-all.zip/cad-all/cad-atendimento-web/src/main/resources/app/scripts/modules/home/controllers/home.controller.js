define( [ ], function()
{
    /*
    *   This controller will be called when user log in or when home page is clicked
    */
    var HomeController = function( $scope, $rootScope, $location, $caseCheckerUtils, $eventNaming ) {
        var _flowControl = function() {

            var namespace = $rootScope.Namespace;
            if(namespace.Loaded) {
                _handleFlow(namespace);
            } else {
                $scope.$on($eventNaming.LoadingComplete, function(e) { 
                    var namespace = $rootScope.Namespace;                   
                    _handleFlow(namespace);
                });
            }

            function _handleFlow(namespace) {
                if(!namespace.WorkingStatus.Paused && !namespace.WorkingStatus.RequestedPause) {
                    var currentCase = namespace.Case.Current;
                    if($caseCheckerUtils.realCase(currentCase)) {
                        $location.path("/case-view");
                    } else {
                        $location.path("/case-pendency");
                    }
                } else {
                    $location.path("/working-availability");
                }
            }
        }
        
        _flowControl();

    };
    return [ "$scope", "$rootScope", "$location", "$caseCheckerUtilsService", "$eventNamingUtilsService", HomeController ];
});