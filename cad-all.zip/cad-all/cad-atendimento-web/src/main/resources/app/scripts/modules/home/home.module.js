define(['angular', 'HomeController', 'HomeLoadingService', 'HomeGeneralService'],
    function(angular, HomeController, HomeLoadingService, HomeGeneralService){
        var _m = angular.module('HomeModule', 
            [
                'UtilsModule',
                'UserModule',
                'UiModule',
                'WorkingAvailabilityModule',
                'CaseViewModule', 
                'CasePendencyModule',
                'NotificationsModule',
                'ProgressBarModule',
                'pascalprecht.translate', 
                'ngCookies'
            ]);

        _m.controller('HomeController', HomeController);
        _m.factory('$homeLoadingService', HomeLoadingService);
        _m.factory('$homeGeneralService', HomeGeneralService);

        return _m;
});