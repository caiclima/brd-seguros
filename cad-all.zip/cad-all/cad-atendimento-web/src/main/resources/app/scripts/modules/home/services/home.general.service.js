define([], function() {
    return ['$rootScope', '$window', '$requestUtilsService', function($rootScope, $window, $requestUtils) {
        return {
            resetDom: function(nextRoute, currentRoute) {
                /*
                *  Reset Actions Combo
                */
                if(!this._hasRouteView(nextRoute)) {
                    _resetCombo();
                } else {
                    var routeView = this._getRouteView(nextRoute);
                    var reset = routeView.indexOf("case-end") < 0;
                    reset = reset && routeView.indexOf("case-note") < 0;
                    reset = reset && routeView.indexOf("case-external-pendency") < 0;
                    reset = reset && routeView.indexOf("case-classification") < 0;
                    reset = reset && routeView.indexOf("case-checklist") < 0;
                    reset = reset && routeView.indexOf("case-edit") < 0;
                    reset = reset && routeView.indexOf("case-send-email") < 0;
                    reset = reset && routeView.indexOf("case-questionnaire") < 0;

                    if(reset) {
                        _resetCombo();
                    }
                }                

                function _resetCombo() {
                    $('#select-funcoes').select2('val', 'All');
                }
            },

            /*
            *  Notice that event prevent default 
            *  will only work for
            *  $locationChangeStart rather $routeChangeStart
            */
            evalRoute: function(e, nextRoute) {
                if(!$rootScope.Namespace.Loaded && this._hasRouteView(nextRoute)) {
                    var routeView = this._getRouteView(nextRoute);

                    /*
                    *  In memory of Gandalf the Grey;
                    */
                    var youShallNotPass = routeView.indexOf("case-view") < 0;
                    youShallNotPass = youShallNotPass && routeView.indexOf("case-pendency") < 0;

                    if(youShallNotPass) {
                        e.preventDefault();
                        $window.location.href = $requestUtils.contextPath();
                    }
                }
            },

            _hasRouteView: function(route) {
                var routeView = this._getRouteView(route)
                return routeView !== undefined && routeView !== '' && routeView !== '/';
            },

            _getRouteView: function(route) {
                return route.split('#!')[1];
            }
        }         
    }];
});