/*
* I'll load system data.
* I promise you!
*/
define([], function() {

    return [
        '$q',
        '$window',
        '$requestUtilsService',
        '$progressBarService',
        '$timeout',
        '$rootScope',
        '$translate',
        '$userRestService',
        '$workingAvailabilityRestService',
        '$caseViewRestService',
        '$casePendencyRestService',
        '$casePendencyPrettyFormatService',
        '$notificationsRestService',
        '$dictionaryUtilsService',
        '$genericUtilsService',
        '$stringUtilsService',
        '$eventNamingUtilsService',
        '$modalUiService',
        '$caseCheckerUtilsService',
        '$alertUiService',
        '$location',
        '$daemonExecutorService',
        function($q, $window, $requestUtils, $progressBarService, $timeout, $rootScope, $translate, $userService, $workingAvailabilityRest, $caseViewRest, $casePendencyRest, $casePendencyFormat, $notificationsRestService, $dictionaryUtils, $genericUtils, $stringUtils, $eventNaming, $modalUiService, $caseCheckerUtils, $alert, $location, $daemonExecutorService) {
            /*
			 * Load User information
			 */
            function loadUser() {
                var userLoading = $q.defer();
                var namespace = $rootScope.Namespace;
                /*
				 * Request logged user information
				 */
                $userService.loggedUser(function(user){
                    /*
					 * Set progress bar value and request current progress bar
					 * message
					 */
                    var progress = $genericUtils.randomInRage(10,19);
                    $translate('bundle.cad.LOADING_USER').then(function(msg) {
                        $progressBarService.progress(progress, msg);
                        /*
						 * Resolve or reject promise after 1 sec delay
						 */
                        var timer = $timeout(function() {
                            namespace.User = user;
                            var userId = user[$dictionaryUtils._userId];
                            if(userId !== undefined) {
                                userLoading.resolve(userId);
                            } else {
                                $translate('bundle.cad.LOADING_USER_FAILURE').then(function(failure) {
                                    userLoading.reject({
                                        data: {
                                            error: failure
                                        }
                                    });
                                });
                            }
                            $timeout.cancel(timer);
                        }, 1000, false);
                    });
                }, function(error) {
                    userLoading.reject(error);
                });
                return userLoading.promise;
            }
            /*
			 * Load User Working Status
			 */
            function loadUserWorkingStatus(userId) {
            	if (userId != undefined) {
	                var workingStatusLoading = $q.defer();
	                var namespace = $rootScope.Namespace;
	
	                /*
					 * Request user working status
					 */
	                $workingAvailabilityRest.userWorkingStatus(
	                    userId,
	                    function(workingStatus) {
	                        var pausedFlag = workingStatus[$dictionaryUtils._pausedFlag];
	                        if(pausedFlag !== undefined) {
	                            namespace.WorkingStatus = workingStatus;
	                            if(typeof pausedFlag !== "boolean")
	                                namespace.WorkingStatus.Paused = $stringUtils.equalsIgnoreCase(pausedFlag, 'true');
	                            else
	                                namespace.WorkingStatus.Paused = pausedFlag;
	
	                            processWorkingStatusLoading(namespace.WorkingStatus.Paused, userId);
	                        } else {
	                            processWorkingStatusLoading(false, userId);
	                        }
	                    },
	                    function(msg){
	                        workingStatusLoading.reject(msg);
	                    });
	                
	
	                return workingStatusLoading.promise;
	                
            	}
            	
                /*
				 * Set progress bar value and request current progress bar
				 * message
				 */
                function processWorkingStatusLoading(pausedFlag, userId) {
                    var progress = $genericUtils.randomInRage(20,34);
                    $translate('bundle.cad.LOADING_WORKING_AVAILABILITY_STATUS').then(function(msg) {
                        $progressBarService.progress(progress, msg);
                        /*
						 * Resolve or reject promise after 1 sec delay
						 */
                        var timer = $timeout(function() {
                            workingStatusLoading.resolve(userId);
                            $timeout.cancel(timer);
                        }, 1000, false);
                    });
                }
            }
            /*
			 * Load Current Case
			 */
            function loadCase(userId) {
            	if (userId != undefined) {
	                var caseLoading = $q.defer();
	                var namespace = $rootScope.Namespace;
	                /*
					 * If user is in pause status, we cannot request a case
					 */
	                if(!namespace.WorkingStatus.Paused) {
	                    /*
						 * Request current case
						 */
	                    $caseViewRest.nextCase(
	                        userId,
	                        function(newCase) {                        
	                            processCaseLoading(newCase, userId);
	                        }, function(error){
	                            caseLoading.reject(error);
	                        }
	                    );  
	                } else {
	                    processCaseLoading({}, userId);
	                }                
	                return caseLoading.promise;
            	 }
               
            	/*
				 * Set progress bar value and request current progress bar
				 * message
				 */
                function processCaseLoading(newCase, userId) {
                    var progress = $genericUtils.randomInRage(35,60);
                    $translate('bundle.cad.LOADING_CASE').then(function(msg) {
                        $progressBarService.progress(progress, msg);
                        /*
						 * Resolve promise after 1 sec delay
						 */
                        var timer = $timeout(function() {
                            namespace.Case.ChangeCase(newCase);
                            caseLoading.resolve(userId);
                            $timeout.cancel(timer);
                        }, 1000, false);
                    });
                }
	        }
            
            /*
			 * Load Pending Cases
			 */
            function loadPendingCases(userId) {
            	if (userId != undefined) {
	                var pendingCasesLoading = $q.defer();
	                var namespace = $rootScope.Namespace; 
	                /*
					 * If user is in pause status, we cannot request pending cases
					 */
	                if(!namespace.WorkingStatus.Paused) {
	                    /*
						 * Request Pending Cases
						 */
	                    var indexPage  = $casePendencyRest.indexPage;
	                    var maxResults = $casePendencyRest.maxResults;
	                    $casePendencyRest.queryDefault(
	                        userId,
	                        function(pendingCases) {
	                            processpendingCasesLoading(pendingCases, userId);
	                        },
	                        function(error) {
	                            pendingCasesLoading.reject(error);
	                        }
	                    );
	                } else {
	                    processpendingCasesLoading([], userId);
	                }                
	                return pendingCasesLoading.promise;
            	}
             
            	/*
				 * Set progress bar value and request current progress bar
				 * message
				 */
                function processpendingCasesLoading(pendingCases, userId) {
                    var progress = $genericUtils.randomInRage(60,79);
                    $translate('bundle.cad.LOADING_PENDING_CASES').then(function(msg) {
                        $progressBarService.progress(progress, msg);
                        /*
						 * Resolve promise after 1 sec delay
						 */
                        var timer = $timeout(function() {
                            var hasCase = !$genericUtils.isRawJson(namespace.Case.Current) && !$genericUtils.isNull(namespace.Case.Current[$dictionaryUtils._caseId]);
                            pendingCases = $casePendencyFormat.format(pendingCases);
                            namespace.Case.Pending.ChangePendingCases(pendingCases);
                            pendingCasesLoading.resolve(userId);
                            $timeout.cancel(timer);
                        }, 1000, false);
                    });
                }
            }
            
            /*
			 * Load Notifications
			 */
            function loadNotifications(userId) {
            	if (userId != undefined) {
	                var notificationsLoading = $q.defer();
	
	                var payload = {};
	                payload[$dictionaryUtils._userId] = userId;
	                $notificationsRestService.update(
	                    payload, 
	                    function(response) {
	                        /*
							 * Set progress bar value and request current progress
							 * bar message
							 */
	                        var progress = $genericUtils.randomInRage(80,94);
	                        $translate('bundle.cad.LOADING_NOTIFICATIONS').then(function(msg) {
	                            $progressBarService.progress(progress, msg);
	                            /*
								 * Resolve promise after 1 sec delay
								 */
	                            var timer = $timeout(function() {
	                                $rootScope.$broadcast($eventNaming.NotificationsFetched, response);
	                                notificationsLoading.resolve();
	                                $timeout.cancel(timer);
	                            }, 1000, false);
	                        });
	                    },
	                    function(error) {
	                        notificationsLoading.reject(error);
	                    });
	                
	                return notificationsLoading.promise;
            	}
            }

            /*
			 * Finish Loading routine
			 */
            function finishLoad() {
                var progress = $genericUtils.randomInRage(95,100);
                $translate('bundle.cad.LOADING_FINISHING').then(function(msg){
                    $progressBarService.progress(progress, msg);
                    var timer = $timeout(function() {
                        /*
						 * Set the global System status to Loaded and notify the
						 * interested controllers
						 */
                        $rootScope.$broadcast($eventNaming.LoadingComplete);                        
                        var namespace = $rootScope.Namespace;
                        namespace.Loaded = true;
                        /*
						 * Release progress Bar
						 */
                        $progressBarService.finish($("#application"));
                        $timeout.cancel(timer);
                    }, 1000, false);
                });
            }

            return {
                loadBase: function() {
                    $progressBarService.start();

                    loadUser()
                        .then(loadUserWorkingStatus)
                            .catch(this._exceptionHandler)
                        .then(loadCase)
                            .catch(this._exceptionHandler)
                        .then(loadPendingCases)
                            .catch(this._exceptionHandler)
                        .then(loadNotifications)
                            .catch(this._exceptionHandler)
                        .then(finishLoad)
                            .catch(this._exceptionHandler);
                },

                _exceptionHandler: function(why) {

                    $translate(['bundle.cad.ERROR', 'bundle.cad.LOADING_ERROR']).then(function(msgs) {

                        var errorMsg = msgs['bundle.cad.LOADING_ERROR'];
                        var errors = msgs['bundle.cad.ERROR'];

                        if(why.data && why.data.error) {
                            var reason = why.data.error;
                            $progressBarService.finish($("#application"));
                            $modalUiService.showmodal(errors , errorMsg + reason, toLogout, lockedModal = true);
                        } else {
                            toLogout();
                        }
                        
                        function toLogout() {
                        	var namespace = $rootScope.Namespace;
                            namespace.Loaded = false;
                        	$daemonExecutorService.stopAll();
                            $window.location.href = $requestUtils.contextPath() + '/logout';
                        }
                    });

                    return $q.defer().promise;
                }
            }
        }
    ];
});