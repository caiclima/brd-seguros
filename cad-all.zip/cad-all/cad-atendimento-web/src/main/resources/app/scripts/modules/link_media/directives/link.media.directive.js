    define( [ ], function()
    {            
        return function(){        	
        	 return {
                restrict: 'A',
                replace: true,
                templateUrl: 'app/scripts/modules/link_media/directives/templates/link.media.html',
                link: function(scope, element, attrs) {
                   
                }
                
            };
        };

    });