/*
 * module definitions 
 */

define(['angular', 'LinkMediaDirective' ], 

	function(angular, LinkMediaDirective){
		var _m = angular.module('LinkMediaModule', []);

		_m.directive('linkMedia',LinkMediaDirective );

		return _m;
});