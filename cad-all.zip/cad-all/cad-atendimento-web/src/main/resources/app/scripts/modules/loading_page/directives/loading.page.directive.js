define( [], function()
{            
    return function(){        	
    	 return {
            restrict: 'A',
            replace: true,
            templateUrl: 'app/scripts/modules/loading_page/directives/templates/loading.page.html'
        };
    };
});