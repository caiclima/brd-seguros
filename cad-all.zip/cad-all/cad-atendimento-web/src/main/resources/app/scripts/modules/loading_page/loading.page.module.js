define([
    'angular',
    'LoadingPageDirective',
    'LoadingPageService'],

	function(angular, LoadingPageDirective, LoadingPageService){
		var _m = angular.module('LoadingPageModule', ['pascalprecht.translate','ngCookies']);

		_m.directive('loadingpage', LoadingPageDirective );
		_m.factory('$loadingPageService', LoadingPageService);
		
		return _m;
});