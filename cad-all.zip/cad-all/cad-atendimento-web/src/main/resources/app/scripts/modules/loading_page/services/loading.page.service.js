define( [ ], function()
{
    return function(){
        return {
	            show: function () {
	             	$(".loading-page").show();
	            },
	            hide: function () {
	                $(".loading-page").hide();    
	            }

            }
        };  
});    