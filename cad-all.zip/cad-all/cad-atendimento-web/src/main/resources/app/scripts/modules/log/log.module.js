/*
 * module definitions 
 */
 
define(['angular', 'LogService'], function(angular, LogService){
	var _m = angular.module('LogModule', []);

	_m.factory('$logService', LogService);

	return _m;
});