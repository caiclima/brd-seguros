    define( [ ], function()
    {
            
        return function(){
        	var _fn = {};

        	_fn.log = function(message){
        		alert(message);
        	};

        	return _fn;
        };

    });