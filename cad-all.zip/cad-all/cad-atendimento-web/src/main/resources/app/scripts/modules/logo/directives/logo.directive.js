define( [ ], function()
		{            
		    return [
		        '$logoRestService',
		        '$rootScope', 
		        '$eventNamingUtilsService', 
		        function($logoRestService,$rootScope,$eventNaming){
		         return {
		        	 restrict: 'A',
			         replace: true,
			         templateUrl: 'app/scripts/modules/logo/directives/templates/logo.html',   
			         link: function(scope, element, attrs) {
		            		
		            		scope.$on($eventNaming.NamespaceCaseChanged, function(event, Case) {
			                  	   if ($rootScope.Namespace.User.idOperacaoPrincipal != undefined) {
			                  		   $logoRestService.getLogo($rootScope.Namespace.User.idOperacaoPrincipal, function(data) {
			         	               			 if (data.value != undefined) {
			         	               				element[0].src = data.value;
		         								}else{
		         									element[0].style.display = "none";
		         								}
			         	               		}, function(msg) {});
			                  	   }
			                 });
		                   
		                }
		        };
		    }];
		});