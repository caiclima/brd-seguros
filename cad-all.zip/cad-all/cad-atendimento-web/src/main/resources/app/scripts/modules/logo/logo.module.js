define(['angular', 'LogoDirective' ,'LogoRestService'],

    function(angular, LogoDirective,LogoRestService){
        var _m = angular.module('LogoModule', ['UiModule', 'UtilsModule']);
        _m.directive('logo', LogoDirective );
        _m.factory('$logoRestService', LogoRestService);
        return _m;
});