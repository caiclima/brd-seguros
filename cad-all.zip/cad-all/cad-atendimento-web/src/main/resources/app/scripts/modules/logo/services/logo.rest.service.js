define( [ ], function()
{
	
    var LogoRestService = function($resource, $stringUtils, $requestUtils, $dictionaryUtils)    
    {
        return {         
            getLogo: function(operationId, successFn, errorFn) {
                var resource = function() {
                	
                	var uri = '/api/tenant/logo/:{0}';
                    var operationId = $dictionaryUtils._operationId;
                    var formattedUri = $stringUtils.format(uri, operationId);

                    var paramDefaults = {};
                    paramDefaults[operationId] = $stringUtils.format('@{0}',operationId);

                    return $resource($stringUtils.concatenate($requestUtils.contextPath(), formattedUri), paramDefaults);
                }();

                var urlParams = {};
                urlParams[$dictionaryUtils._operationId] = operationId;

                resource.get(urlParams, successFn, errorFn);                  

            },
        }
    };
    return [
        "$resource",
        "$stringUtilsService",
        "$requestUtilsService",
        "$dictionaryUtilsService",        
        LogoRestService];
});