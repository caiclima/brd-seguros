define( [ ], function()
{            
    return ['$translate', '$window', '$rootScope', '$location', '$eventNamingUtilsService', '$dictionaryUtilsService', '$genericUtilsService','$menuNotificationsService','$requestUtilsService', '$daemonExecutorService','$notificationsDaemonService', '$caseCheckerUtilsService', '$casePendencyRestService','$alertUiService','$versionRestService',
        function($translate, $window, $rootScope, $location, $eventNaming, $dictionaryUtils, $genericUtils, $menuNotificationsService, $requestUtils, $daemonExecutorService, $notificationsDaemonService, $caseCheckerUtils, $casePendencyRest, $alert, $versionRestService){

        var _restartDaemonNotificationService = function(delay){
            $daemonExecutorService.restart(
                {
                    ajaxModel: 'poll',
                    loggedUserId: $rootScope.Namespace.User[$dictionaryUtils._userId],
                    dispatcherFn: function(eventName, obj) {
                        $rootScope.$broadcast(eventName, obj);
                    }
                },
                [
                    {
                        logic: $notificationsDaemonService,
                        delay: delay,
                        http: true
                    }
                ]
            );
        };

    	 return {
            restrict: 'A',
            transclude: true,
            replace: true,
            scope: {},
            templateUrl: 'app/scripts/modules/menu/directives/templates/menu.html',
            link: function(scope, element, attrs) {

                scope.casesQty = 0;
                scope.hasCase = false;
                scope.notifications = [];
                scope.caseId = undefined;
                scope.systemVersion = undefined;
                scope.flagReopened = undefined;
                scope.statusRetPausaToolbar = false;
                
                $versionRestService.getSystemVersion(function (version) {
	                	if (version) {
	                    	scope.systemVersion = version.valor;
	                    }
                	},
                	function (msg) {
                		$alert.error(msg.data ? msg.data.error : msg.error);
                	}
                );

                scope.pathTo = function(path) {
                    $location.path( path );
                };
                scope.setLang = function(lang){
                    $translate.use(lang);
                    $location.path('/');
                };
                scope.clearNotifications = function() {
                    scope.notifications = [];
                };
                scope.stopDaemonServices = function() {
                	$daemonExecutorService.stopAll();
                };

                scope.showAboutModal = function() {
                	$('#modalAbout').modal({
                        show: true
                    });
                };
                
                scope.$on($eventNaming.LoadingComplete, function(event) {
                    scope.username = $rootScope.Namespace.User.login;
                });
                scope.$on($eventNaming.RefreshTotalPendency, function() {
                	$casePendencyRest.count($rootScope.Namespace.User[$dictionaryUtils._userId], function(total){
                		if(total && total[$dictionaryUtils._value]){
               				scope.casesQty = total[$dictionaryUtils._value];
                			
                		}else{
                			scope.casesQty = 0;
                		}
                		
                	}, function(msg){
                		$alert.error(msg.data ? msg.data.error : msg.error);
                	});
                });
                scope.$on($eventNaming.NotificationsFetched, function(event, notifications) {
                    var newCase = notifications[$dictionaryUtils._TODetailedCase];
                    var currentStatus = notifications[$dictionaryUtils._currentStatus];
                    var notificationsList = notifications[$dictionaryUtils._notificationsList];

                    scope.statusRetPausaToolbar = currentStatus[$dictionaryUtils._statusRetPausaToolbar];

                    if(!$genericUtils.isNull(currentStatus)) {
                        var pausedFlag = currentStatus[$dictionaryUtils._pausedFlag];

                        if($rootScope.Namespace.WorkingStatus.Paused && !pausedFlag){
                            _restartDaemonNotificationService(20000);

                            if($rootScope.Namespace.Loaded){
                                /*
                                 *  We force page reload in order to fetch case and pending cases
                                 *  without having to notify other controllers through broadcast
                                 */
                                $window.location.href = $requestUtils.contextPath();
                            }

                        }else if(!$rootScope.Namespace.WorkingStatus.Paused && pausedFlag) {
                            $rootScope.Namespace.WorkingStatus[$dictionaryUtils._statusName]  = currentStatus[$dictionaryUtils._statusName];
                            $rootScope.Namespace.WorkingStatus[$dictionaryUtils._statusColor] = currentStatus[$dictionaryUtils._statusColor];;
                            $rootScope.Namespace.WorkingStatus.Paused = true;
                            _restartDaemonNotificationService(5000);

                            if($rootScope.Namespace.Loaded){
                                /*
                                 *  We force page reload in order to fetch case and pending cases
                                 *  without having to notify other controllers through broadcast
                                 */
                                $location.path("/");
                            }
                        }
                    }

                    if(!$genericUtils.isNull(notificationsList) && notificationsList.length > 0) {
                        var formatted = $menuNotificationsService.format(notificationsList);

                        if($caseCheckerUtils.fakeCase(newCase)) {
                            formatted = $.grep(formatted, function(item) {
                                return item.key !== 'tempoexpirado';
                            });
                        }

                        if (scope.notifications && scope.notifications.length >= 5) {
                            var qtyToRemove = formatted.length;
                            scope.notifications.splice(0, qtyToRemove);
                        }
                        scope.notifications.push.apply(scope.notifications, formatted);
                        
                        $.each(formatted, function(index, value){
                        	$alert.success(value.message);
                        });
                    }

                    if($caseCheckerUtils.realCase(newCase)) {
                        $rootScope.Namespace.Case.ChangeCase(newCase);
                        $location.path('/case-view');
                    }
                });
                
                scope.$on($eventNaming.NamespaceCaseChanged, function(event, newCase) {
					if ($caseCheckerUtils.realCase(newCase)) {
						scope.caseId = newCase.idCaso;
						scope.flagReopened = newCase.flagReaberto;
					} else {
						scope.caseId = undefined;
						scope.flagReopened = undefined;
					}
                });

                $translate([
                    'bundle.cad.NOTIFICATIONS_EXPIRED_TIME',
                    'bundle.cad.NOTIFICATIONS_ALERT',
                    'bundle.cad.NOTIFICATIONS_ERROR',
                    'bundle.cad.NOTIFICATIONS_EMAIL',
                    'bundle.cad.NOTIFICATIONS_SYSTEM',
                    'bundle.cad.NOTIFICATIONS_SUPERVISOR'])
                .then(function(bundleMsgs) {
                    $menuNotificationsService.setTitleMessages(bundleMsgs);
                });                

                element.find(".nav li a").on('click', function(e){
     
                    // e.preventDefault(); // prevent link click if necessary?
             
                     var $thisLi = $(this).parent('li');
                     var $ul = $thisLi.parent('ul');
             
                     if (!$thisLi.hasClass('active'))
                     {
                         $ul.find('li.active').removeClass('active');
                             $thisLi.addClass('active');
                             return;
                     }
                 });
            }
        };
    }];

});