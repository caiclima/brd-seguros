/*
 * module definitions 
 */

define(['angular', 'MenuDirective', 'MenuNotificationsService' ], 

	function(angular, MenuDirective, MenuNotificationsService){
		var _m = angular.module('MenuModule', ['pascalprecht.translate','ngCookies', 'UtilsModule', 'UiModule']);

		_m.directive('menu',MenuDirective );
        _m.factory('$menuNotificationsService', MenuNotificationsService);

		return _m;
});