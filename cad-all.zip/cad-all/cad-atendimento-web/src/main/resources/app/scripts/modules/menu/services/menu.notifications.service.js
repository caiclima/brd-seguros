define([], function(){

    var MenuNotificationsService = function($dictionaryUtils, $genericUtils) {

        var titleMessages;

        var iconClasses = function() {
            var obj = {};
            obj[$dictionaryUtils._notificationType_Expired]   = "icons icon-6-4";
            obj[$dictionaryUtils._notificationType_Alert]     = "icons icon-warning-sign";
            obj[$dictionaryUtils._notificationType_Error]     = "icons icon-remove-sign";
            obj[$dictionaryUtils._notificationType_Email]     = "icons icon-envelope";
            obj[$dictionaryUtils._notificationType_System]    = "icons icon-cog";
            obj[$dictionaryUtils._notificationType_Supervisor] = "icons icon-comment";
            return obj;
        }();
        
        function _eventIconClass(eventType) {
            return iconClasses[eventType];
        }

        function _eventTitle(eventType) {
            return titleMessages[eventType];
        }

        return {
            format: function(notifications) {
                var prettyList = [];
                if(notifications){
                    for(var it = 0; it < notifications.length; ++it) {
                        var notification = notifications[it];
                        var prettyEntry = {
                            key: notification[$dictionaryUtils._notificationKey],
                            title: _eventTitle(notification[$dictionaryUtils._notificationKey]),
                            message: notification[$dictionaryUtils._notification],
                            date: $genericUtils.fromServersDateFormat(notification[$dictionaryUtils._creationDate]),
                            iconClass: _eventIconClass(notification[$dictionaryUtils._notificationKey])
                        };
                        prettyList.push(prettyEntry);
                    }
                }
                return prettyList;
            },

            setTitleMessages: function(bundleMsgs) {
                titleMessages = {};
                titleMessages[$dictionaryUtils._notificationType_Expired] = bundleMsgs['bundle.cad.NOTIFICATIONS_EXPIRED_TIME'];
                titleMessages[$dictionaryUtils._notificationType_Alert] = bundleMsgs['bundle.cad.NOTIFICATIONS_ALERT'];
                titleMessages[$dictionaryUtils._notificationType_Error] = bundleMsgs['bundle.cad.NOTIFICATIONS_ERROR'];
                titleMessages[$dictionaryUtils._notificationType_Email] = bundleMsgs['bundle.cad.NOTIFICATIONS_EMAIL'];
                titleMessages[$dictionaryUtils._notificationType_System] = bundleMsgs['bundle.cad.NOTIFICATIONS_SYSTEM'];
                titleMessages[$dictionaryUtils._notificationType_Supervisor] = bundleMsgs['bundle.cad.NOTIFICATIONS_SUPERVISOR'];
            }
        };
    };

    return ['$dictionaryUtilsService', '$genericUtilsService', MenuNotificationsService];
});