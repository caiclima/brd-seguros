define(['angular', 'MenuActionsDirective' ],

    function(angular, MenuActionsDirective){
        var _m = angular.module('MenuActionsModule', ['UiModule', 'UtilsModule']);
        _m.directive('menuActions', MenuActionsDirective );
        return _m;
});