define(['angular','NotificationsRestService', 'NotificationsDaemonService'], 
    function(angular, NotificationsRestService, NotificationsDaemonService) {
        var _m = angular.module('NotificationsModule', ['ngResource','UtilsModule','UiModule']);

        _m.factory('$notificationsRestService', NotificationsRestService);
        _m.factory('$notificationsDaemonService', NotificationsDaemonService);
        
        return _m;
    }
);