define([], function() {
    return ['$notificationsRestService','$dictionaryUtilsService', '$alertUiService', '$eventNamingUtilsService',
     function($notificationsRestService, $dictionaryUtils, $alertUiService, $eventNamingUtils) {
        var userId, notificationDispatcher;
        return{
            setup: function(setupObj) {
                userId = setupObj.loggedUserId;
                notificationDispatcher = setupObj.dispatcherFn;
            },

            doPoll: function() {
                var payload = {};
                payload[$dictionaryUtils._userId] = userId;
                
                $notificationsRestService.update(
                    payload, 
                    function(response) {
                        notificationDispatcher($eventNamingUtils.NotificationsFetched, response);
                    },
                    function(msg) {
                        $alertUiService.error(msg.data ? msg.data.error : msg.error);;
                    });
            },

            doPush: function() {
                //TODO: create event assignment
            }
        };
    }];
});