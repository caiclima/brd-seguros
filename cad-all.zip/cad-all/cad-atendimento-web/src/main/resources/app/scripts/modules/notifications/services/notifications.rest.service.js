define([], function() {

    var NotificationRestService = function($resource, $stringUtils, $requestUtils, $dictionaryUtils) {
        var userIdParam = $dictionaryUtils._userId;
        var paramDefaults = {};
        paramDefaults[userIdParam] = $stringUtils.format('@{0}',userIdParam);

        var actions = {
            update: {
                method: 'PUT',
                params: paramDefaults,
                headers: {
                    'X-Poll': ''
                }
            }
        };

        var uri = $stringUtils.format('/api/users/keepuserlogged/:{0}/processnotificactions', userIdParam);
        var url = $stringUtils.concatenate($requestUtils.contextPath(), uri);
        return $resource(url, paramDefaults, actions);
    }

   return [
        '$resource',
        '$stringUtilsService',
        '$requestUtilsService',
        '$dictionaryUtilsService', 
        NotificationRestService];
});