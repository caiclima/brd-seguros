    define([], function() {

        var OperatingTimeController = function($scope, $rootScope, $operatingTimeRestService, $dic, $alert) {
            $scope.prettyHistory = [];
            
            $scope.queryOperatingTime = function(){
                var urlParams = {};
                urlParams[$dic._userId]   = $rootScope.Namespace.User[$dic._userId];                

                $operatingTimeRestService.get(urlParams,
                    function(history) {
                      
                        $scope.totalTime = history[$dic._totalTime];
                        var operatingTime = history[$dic._operatingTime];

                        for (var i = 0; i < operatingTime.length; ++i) {
                            var item  = operatingTime[i];
                            var prettyEntry = {};                            
                            prettyEntry[$dic._status]       = {};
                            prettyEntry[$dic._status][$dic._title]       = item[$dic._statusName];
                            prettyEntry[$dic._status][$dic._colorEn]       = item[$dic._statusColor];
                            prettyEntry[$dic._elapsedTime]    = item[$dic._elapsedTime];
                           
                            $scope.prettyHistory.push(prettyEntry);
                        }
                    }, 
                    function(msg){
                        $alert.error(msg.data ? msg.data.error : msg.error);                       
                    });
            }
            $scope.queryOperatingTime();
        };

        return ["$scope", "$rootScope", "$operatingTimeRestService", "$dictionaryUtilsService","$alertUiService", OperatingTimeController];

    });