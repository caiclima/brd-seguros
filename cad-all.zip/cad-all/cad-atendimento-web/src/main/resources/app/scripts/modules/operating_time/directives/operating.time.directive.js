define( [ ], function()
{            
    return ['$filter', function($filter){           
         return {
            restrict: 'A',
            templateUrl: 'app/scripts/modules/operating_time/directives/templates/operating.time.html',
            link: function(scope,element, attrs) {
                scope.tableConfig = [{
                    title: $filter('translate')('bundle.cad.STATUS'),                
                    type: "label"
                },{
                    title: $filter('translate')('bundle.cad.TIME'),
                    type: 'icon-text',
                    icon: "icon-time"
                }];
            }
        };
    }];
});