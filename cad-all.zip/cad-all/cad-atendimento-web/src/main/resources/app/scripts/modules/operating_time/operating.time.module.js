/*
 * module definitions 
 */

define(['angular', 'OperatingTimeController', 'OperatingTimeRestService','OperatingTimeDirective' ],
	function(angular, OperatingTimeController,OperatingTimeRestService ,OperatingTimeDirective){
		var _m = angular.module('OperatingTimeModule', ['ngResource','UtilsModule','pascalprecht.translate','ngCookies', 'UiModule']);

        _m.directive('operatingTime', OperatingTimeDirective );
        _m.factory('$operatingTimeRestService', OperatingTimeRestService);
        _m.controller('OperatingTimeController', OperatingTimeController);

		return _m;
});