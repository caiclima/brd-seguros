define( [ ], function()
{
    var OperatingTimeRestService = function($resource, $stringUtils, $requestUtils, $dictionaryUtils)
    {
        var userID = $dictionaryUtils._userId;

        var uri = $stringUtils.format('/api/operationaltimes/users/:{0} ', userID);

        var paramDefaults = {};
        paramDefaults[userID] = $stringUtils.format('@{0}',userID);       

        return $resource($requestUtils.contextPath() + uri, paramDefaults);
    };

    return [
        "$resource",
        "$stringUtilsService",
        "$requestUtilsService",
        "$dictionaryUtilsService",
        OperatingTimeRestService
    ];
});