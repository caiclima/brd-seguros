/*
 * module definitions 
 */
 
define(['angular', 'PageScrollPaginationService'], function(angular, PageScrollPaginationService){
	var _m = angular.module('PageScrollPaginationModule', []);

	_m.factory('$pageScrollPaginationService', PageScrollPaginationService);

	return _m;
});