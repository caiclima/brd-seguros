define( [], function()
{
        
    return function(){
    	var _fn = {};    	
    	
    	_fn.setDefaults = function(){
    		_fn.totalContextElements = 100;
        	_fn.currentContextElements = 0;
        	_fn.maxPagesToScroll = 10;
    	}
    	
    	_fn.setCurrentContextElements = function(total){
    		_fn.currentContextElements = total;
    	}
    	
    	_fn.setTotalContextElements = function(total){
    		_fn.totalContextElements = total;
    	}
    	
    	_fn.windowHeight = function(){
    		return $(window).height();
    	};
    	
    	_fn.unbindWindowScroll = function(){
    		$(window).unbind('scroll');
    	}
    	
    	_fn.scroll = function(containerId, callback, maxPagesToScroll, loadingTemplate){
    		_fn.unbindWindowScroll();
    		_fn.setDefaults();
    		
    		if(typeof containerId === 'undefined'){
    			throw new Error('containerId must not be null!');
    		}
    		
    		if(typeof callback === 'undefined'){
    			throw new Error('callback must not be null!');
    		}
    		
    		if(typeof maxPagesToScroll === 'undefined'){
    			maxPagesToScroll = _fn.maxPagesToScroll;
    		}
    		
    		if(typeof loadingTemplate === 'undefined'){
    			loadingTemplate = '<div><b>Loading...</b></div>';
    		}
    		
            $(window).paged_scroll({
                handleScroll:function (page, container, doneCallback) {
                    setTimeout(function () {
                    	if(typeof page != 'undefined' && page == _fn.maxPagesToScroll){
                    		callback.finish(page, container);
                    		return;
                    	}
                    	
                    	if(_fn.currentContextElements == 0 || _fn.currentContextElements >= _fn.totalContextElements){
                    		callback.next(page, container);
                    	}else{
                    		if(typeof page != 'undefined' && page > 1){
                    			callback.finish(page, container);
                    		}
                    	}
                    }, 1000);

                    return true;
                },
                triggerFromBottom:'10px',
                loading: {
                	html: loadingTemplate
                },
                pagesToScroll: maxPagesToScroll,
                targetElement: $("#" + containerId),
                debug:false
            });
    	}

    	return _fn;
    };

});