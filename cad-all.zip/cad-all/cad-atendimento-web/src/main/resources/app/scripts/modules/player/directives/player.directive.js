    define( [ ], function()
    {            
        return function(){        	
        	 return {
                restrict: 'A',
                replace: true,
                scope: true,
                templateUrl: 'app/scripts/modules/player/directives/templates/player.html',
                link: function(scope, element, attrs) {
                    element.find("audio").mediaelementplayer({
                         alwaysShowControls: true,
                         features: ['playpause','progress'],
                         audioVolume: 'horizontal',
                         startVolume: 1            
                    });
                    
                  
                }
                //templateUrl: 'template.html',
                
            };
        };

    });