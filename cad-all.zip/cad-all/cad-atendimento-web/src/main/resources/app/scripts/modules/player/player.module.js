/*
 * module definitions 
 */

define(['angular', 'PlayerDirective' ], 

	function(angular, PlayerDirective){
		var _m = angular.module('PlayerModule', []);

		_m.directive('player',PlayerDirective );

		return _m;
});