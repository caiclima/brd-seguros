define( [], function()
{            
    return function(){        	
    	 return {
            restrict: 'A',
            replace: true,
            templateUrl: 'app/scripts/modules/progress_bar/directives/templates/progressbar.html',
            link: function(scope, element, attrs) {
            	$(".percent-text").css("top", ($(".loading-position").position().top + 45));
            	
            }


        };
    };
});