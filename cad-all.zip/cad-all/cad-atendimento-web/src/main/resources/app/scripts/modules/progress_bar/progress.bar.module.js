define([
    'angular',
    'ProgressBarDirective',
    'ProgressBarService'],

	function(angular, ProgressBarDirective, ProgressBarService){
		var _m = angular.module('ProgressBarModule', []);

		_m.directive('progressbar', ProgressBarDirective );
		_m.factory('$progressBarService', ProgressBarService);
		
		return _m;
});