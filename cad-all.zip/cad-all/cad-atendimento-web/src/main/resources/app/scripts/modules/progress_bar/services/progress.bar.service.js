define([], function()
{
        
    return function(){
    	var _fn = {};
    	
    	_fn.started = false;
    	
    	_fn.isStarted = function(){
    		return _fn.started;
    	}

    	_fn.find = function(selector){
            return $(selector, $(".loading-index")).first();
        }

    	_fn.setPercentLabel = function(t){
    		_fn.find($('.percent-text')).text(t);
        }

    	_fn.setLoadingPercent = function(t){
    		_fn.find($('.percent-header')).text(t);
        }

    	_fn.setLoadingPercentSize = function(size){
            var _current = size + '%';
            _fn.find($('.block-load')).css('width', _current);
            _fn.setLoadingPercent(_current);
        }

    	_fn.start = function(){
    		_fn.started = true;
    		_fn.progress(0, '');
        }
    	
    	_fn.finish = function(){
    		_fn.finish(null);
    	}

    	_fn.finish = function(mainApplication){
    		_fn.started = false;
    		
    		$(".loading-index").children().hide();
    		$(".loading-index").fadeOut('fast');
    		
    		if(typeof mainApplication != 'undefined'){
    			$(mainApplication).fadeIn(1000);
    		}
        }

    	_fn.progress = function(size, label){
    		_fn.setLoadingPercentSize(size);
    		_fn.setPercentLabel(label);
        }

    	return _fn;
    };

});