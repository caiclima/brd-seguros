define( [], function()
{            
    return function(){        	
    	return {
			priority: 100,
			scope: {
				uploadTitle : '@?',
				uploadAction : '@',
				uploadAddLabel: '@',
				uploadAddTitle: '@?',
				uploadRemoveLabel: '@',
				uploadRemoveTitle: '@?',
				uploadChooseFileLabel: '@'
			},
			templateUrl: 'app/scripts/modules/simple_file_upload/directives/templates/simple-upload-panel.html',
			replace: true,
			link: function($scope, iElm, iAttrs, controller) {

				function gsize(bytes) {
			        if (typeof bytes !== 'number') {
			            return '';
			        }

			        if (bytes >= 1000000000) {
			            return (bytes / 1000000000).toFixed(2) + ' GB';
			        }

			        if (bytes >= 1000000) {
			            return (bytes / 1000000).toFixed(2) + ' MB';
			        }

			        return (bytes / 1000).toFixed(2) + ' KB';
			    }

				var panel = $("#uploadp");
				var form = $("#uploadf");
				var ul = $("ul", form).first();

				/*
				 * add file action
				 */
				panel.find('#upload-add').click(function(){
					var fileSize = form.find('input').length;
					var fname = 'file' + (fileSize + 1);
					var flabel = $scope.uploadChooseFileLabel;
					var li = $("<li class='list-group-item' title='" + flabel + "'><div><span class='icons icon-20-1'></span> " + flabel + "</div><input style='display:none' type='file' name='" + fname + "' /></li>");
					var container = li.find('div');

					// verify timeout
					setTimeout(function(){
						if(!li.hasClass('verified')){
							li.fadeOut(1000);
							li.remove();
						}
					}, 1500000); // if not used in 15 seconds, remove it.

					// events
					container.click(function(){
						var tinput = li.find('input').first();

						$(tinput).bind('change', function(e){
							li.addClass('verified');
							var target = e.target ? e.target : e.srcElement;
							var fileName = '';
							var fileSize = '';

							if(target.files === undefined){
								fileName = target.value;
								fileSize = gsize(target.fileSize);
							}else{
								var currentFile = target.files.item(0);
								fileName = currentFile.name;
								fileSize = gsize(currentFile.size);
							}
							
							var fdescription = fileName + " - " + fileSize;
							var filetpl = $("<span class='upload-remove btn btn-xs btn-primary' title='" + $scope.uploadRemoveTitle + "'><span class='icons icon-21-8'></span>  " + $scope.uploadRemoveLabel + "</span><span class='upload-filename'><span class='icons icon-4-7'></span>  " + fdescription + "</span>");

							li.attr('title', fdescription);
							container.unbind('click');
							container.html(filetpl);
							container.find('.upload-remove').click(function(){
								li.remove();
							});
						});
						tinput.click();
					});

					/*
					 * add new file item
					 */
				 	ul.append(li);
				});

			}
		};
    };
});