define( [ ], function()
{
    var SimpleFileUploadService = function($timeout, $loadingPageService){
			var f = {
				container_ : function(){
					return $('#uploadp ul').first();
				},

				form_ : function(){
					return $('#uploadf', $('#uploadp')).first();
				},

				iframe_ : function(){
					return $('#uploadi', $('#uploadp')).first();
				},

				upload : function(uri, params, callback, responseAsJson){
                    $loadingPageService.show();

					// json response, by default
					if(responseAsJson === undefined){
						responseAsJson = true;
					}

					var $form = this.form_(); 
					var $iframe = this.iframe_();
					var $container = this.container_();

					// prepare data
					if(params != undefined){
						for(p in params){
                            if(angular.isArray(params[p])){
                                $.each(params[p], function(i, v){
                                	if(v){
                                		var in_ = $("<input style='display:none' type='text' />");
                                		in_.attr('name', p);
                                		in_.val(angular.toJson(v));
                                        
                                		$form.append(in_);
                                	}
                                });

                            }else{
                            	if(params[p]){
                            		var in_ = $("<input style='display:none' type='text' />");
                            		in_.attr('name', p);
                            		in_.val(params[p]);
                            		
                            		$form.append(in_);
                            	}
                            }
						}
					}

					$form.attr('action', uri);
					$form.submit();
					
					// iframe binding
					$iframe.unbind( 'load.ajaxsubmit' ).bind( 'load.ajaxsubmit', function(){
	                	var response = undefined;

	                	try{
							response = $.parseJSON($(this).contents().find('body').text());
	                	}catch(e){
	                		// ignore 
	                	}

                        $loadingPageService.hide();
	                	callback( response );
	                	
	                	$timeout(function(){
	                		$("input", $form).remove();
	                		$container.children().remove();
	                	}, 1000, false);
	            	});
				}
			};
			return f;
		};

    return [ "$timeout", "$loadingPageService", SimpleFileUploadService ];
});