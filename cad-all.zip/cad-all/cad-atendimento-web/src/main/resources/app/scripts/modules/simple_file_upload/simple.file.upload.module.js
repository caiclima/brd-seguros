define([
    'angular',
    'SimpleFileUploadDirective',
    'SimpleFileUploadService'],

	function(angular, SimpleFileUploadDirective, SimpleFileUploadService){
		var _m = angular.module('SimpleFileUploadModule', []);

		_m.directive('uploadPanel', SimpleFileUploadDirective );
		_m.factory('$simpleFileUploadService', SimpleFileUploadService);
		
		return _m;
});