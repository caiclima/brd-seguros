define([], function()
{
    return ['$timeout', '$cookieStore', '$alertUiService', '$filter', function($timeout, $cookieStore, $alertUiService, $filter){
    	var _fn = {};
    	
    	_fn.sendToRoot = function (){
            window.location.href = '/' + window.location.pathname.split('/')[1];
        };
    	
    	_fn.destroy = function(){
    		$alertUiService.error($filter('translate')('bundle.cad.MSG_FORCED_LOGOUT'));
    		var timer = $timeout(function(){
    			$cookieStore.remove('callink_sso_client');
    			_fn.sendToRoot();
    			$timeout.cancel(timer);
    		}, 3500, false);
    	};
    	
    	return _fn;
    }];

});