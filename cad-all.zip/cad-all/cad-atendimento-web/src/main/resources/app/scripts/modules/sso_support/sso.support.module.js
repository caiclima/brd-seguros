/*
 * module definitions 
 */
 
define(['angular', 'SSOService'], function(angular, SSOService){
	var _m = angular.module('SSOSupportModule', []);
	_m.factory('$ssoService', SSOService);
	return _m;
});