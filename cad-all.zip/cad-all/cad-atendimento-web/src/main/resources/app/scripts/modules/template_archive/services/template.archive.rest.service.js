define([], function () {

    var TemplateArchiveRestService = function ($resource, $stringUtils, $requestUtils, $dictionaryUtils) {
        var byOperation = function (uri) {
            var path = $requestUtils.contextPath();
            var url = $stringUtils.concatenate(path, uri);

            var paramDefaults = {};
            paramDefaults[$dictionaryUtils._operationId] = $stringUtils.format('@{0}', $dictionaryUtils._operationId);

            return $resource(url, paramDefaults);
        };

        return {
            getTemplateArchiveAtive: function (idOperaction, successFn, errorFn) {
                var uri = $stringUtils.format('/api/templateArchive/:{0}', $dictionaryUtils._operationId);

                var params = {};
                params[$dictionaryUtils._operationId] = idOperaction;

                byOperation(uri).query(params, successFn, errorFn);
            }
        };
    };
    return [
        "$resource",
        "$stringUtilsService",
        "$requestUtilsService",
        "$dictionaryUtilsService",
        TemplateArchiveRestService];
});