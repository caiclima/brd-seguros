/*
 * module definitions 
 */

define(['angular', 'TemplateArchiveRestService' ],
    function (angular, TemplateArchiveRestService) {

        var _m = angular.module('TemplateArchiveModule', [
            'ngResource',
            'UtilsModule',
            'pascalprecht.translate',
            'ngCookies',
            'UiModule',
            'CaseEventsModule'            
        ]);

        _m.factory('$templateArchiveRestService', TemplateArchiveRestService);
       

        return _m;
    });