/*
* module definitions
*/
define(['angular', 
    'TableUiDirective', 
    'TableUiFilter', 
    'BoxBorderUiDirective' , 
    'DatepickerUiDirective', 
    'AnchorsMenuUiDirective',
    'AnchorsScrollUiDirective', 
    'GroupedComboUiDirective',
    'DateTableUiFilter',
    'DateMomentUiFilter',
    'BooleanUiFilter',
    'MoneyUiFilter',
    'ComboUiDirective',
    'ComboChangeUiDirective',
    'TooltipUiDirective',
    'ModalUiDirective',
    'ModalUiService',
    'AlertUiService',
    'TreeViewUiDirective',
    'BoxUiDirective',
    'RichTextUiDirective',
    'MaskInputUiDirective',
    'SetColorUiDirective',
    'MultiSelectUiDirective',
    'ContentEditableUiDirective',
    'TimelyUiDirective',
    'DecorateElementUiDirective',
    'ComboMultiUiDirective'],

function(angular, 
         TableUiDirective,
         TableUiFilter,
         BoxBorderUiDirective,
         DatepickerUiDirective, 
         AnchorsMenuUiDirective, 
         AnchorsScrollUiDirective, 
         GroupedComboUiDirective,
         DateTableUiFilter,
         DateMomentUiFilter,
         BooleanUiFilter,
         MoneyUiFilter,
         ComboUiDirective,
         ComboChangeUiDirective,
         TooltipUiDirective,
         ModalUiDirective,
         ModalUiService,
         AlertUiService,
         TreeViewUiDirective,
         BoxUiDirective,
         RichTextUiDirective,
         MaskInputUiDirective,
         SetColorUiDirective,
         MultiSelectUiDirective,
         ContentEditableUiDirective,
         TimelyUiDirective,
         DecorateElementUiDirective,
         ComboMultiUiDirective) {

    var _m = angular.module('UiModule', ['UtilsModule','pascalprecht.translate','ngCookies']);
    _m.directive('contenteditable', ContentEditableUiDirective);
    _m.directive('table', TableUiDirective);
    _m.directive('boxBorder', BoxBorderUiDirective);
    _m.directive('datepicker', DatepickerUiDirective);
    _m.directive('anchorsMenu', AnchorsMenuUiDirective );
    _m.directive('anchorScroll', AnchorsScrollUiDirective );
    _m.directive('groupedCombo', GroupedComboUiDirective);
    _m.directive('tooltip', TooltipUiDirective);
    _m.directive('combo', ComboUiDirective);
    _m.directive('comboChange',ComboChangeUiDirective);
    _m.directive('uiModal', ModalUiDirective);
    _m.directive('treeview', TreeViewUiDirective);
    _m.directive('box', BoxUiDirective);
    _m.directive('richText', RichTextUiDirective);
    _m.directive('maskInput', MaskInputUiDirective);
    _m.directive('setColor',SetColorUiDirective);
    _m.directive('multiSelect', MultiSelectUiDirective);
    _m.directive('timely', TimelyUiDirective);
    _m.directive('decorateElement', DecorateElementUiDirective);
    _m.directive('multiCombo', ComboMultiUiDirective);

    _m.filter('validate', TableUiFilter);
    _m.filter('datetable', DateTableUiFilter);
    _m.filter('datemoment', DateMomentUiFilter);
    _m.filter('yesno', BooleanUiFilter);
    _m.filter('money', MoneyUiFilter);
    
    _m.factory('$modalUiService',ModalUiService);
    _m.factory('$alertUiService', AlertUiService);

    return _m;
});