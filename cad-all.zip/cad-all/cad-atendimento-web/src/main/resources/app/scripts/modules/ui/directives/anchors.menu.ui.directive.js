define( [ ], function()
{
	return ['$filter', '$eventNamingUtilsService', function($filter, $eventNaming){
        return {
            restrict: 'A',
            replace: true,
            scope: true,
            templateUrl: 'app/scripts/modules/ui/directives/templates/anchors.menu.ui.html',
            link: function(scope, element, attrs) {
                function toggleAnchorsMenu(hide) {
                    if(hide)
                        $('#anchors_menu').addClass('hide');
                    else 
                        $('#anchors_menu').removeClass('hide');
                }

                function constructAnchorsMenu() {
                     var anchorsList = [];
                    $('.anchors_selector', $('#contentView')).each(function(){
                    	var bundle = $(this).attr('anchor-bundle') || '';
                    	
                        anchorsList.push({
                            name: $filter('translate')(bundle),
                            link: '#' + $(this).attr('anchor-link')
                        });
                    });

                    var contextMenuHidden = anchorsList.length == 0;
                    if(!contextMenuHidden)
                        scope.anchorsList = anchorsList;
                    toggleAnchorsMenu(contextMenuHidden);
                }

                //listen to
                scope.$on($eventNaming.InternalContentChanged, function(event, args) {
                    constructAnchorsMenu();
                });
                
                scope.$on('$translationChangedEvent', function(event, args) {
                    constructAnchorsMenu();
                });
                
                //on bootstrap
                constructAnchorsMenu();
            }
        };
    }];
});