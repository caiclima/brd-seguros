    define( [ ], function()
    {            
        return function(){
          return {
            link: function(scope, element, attrs) {
                element.bind('click', function(event) {
                    var target = attrs.anchorScroll;
                    try{
                        $('html, body').animate(
                            {
                                scrollTop: ($(target).offset().top - 100) 
                            }, 500
                        );
                    } catch(e) {
                        //TODO
                    	throw new Error(e);
                    }
                });
            }
        };
    };
});