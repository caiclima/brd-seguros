    define( [ ], function()
    {            
        return function(){          
             return {
                restrict: 'A',
                replace: true,
                transclude: true,
                scope: {
                  anchorName: '@',
                  anchorLink: '@'
                },
                templateUrl: 'app/scripts/modules/ui/directives/templates/box.border.ui.html'               
            };
        };

    });