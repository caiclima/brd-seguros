define( [ ], function()
{            
    return function(){          
         return {
            restrict: 'A',
            replace: true,
            scope: {
              datasource: '=',
              showIcon: '@',
              showLegend: '@?',
              hintMessage: '@',
              classIcon: '@?'
            },
            templateUrl: 'app/scripts/modules/ui/directives/templates/box.ui.html'
        };
    };
});