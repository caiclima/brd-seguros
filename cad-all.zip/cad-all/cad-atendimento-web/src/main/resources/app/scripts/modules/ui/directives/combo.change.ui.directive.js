define([], function() {
    return ['$timeout', function($timeout) {
        return {
            restrict: 'A',
            require: "?ngModel",
            scope: {
                datasource: '=',
                require: '@',
                change: '=',
                disable: '='
            },
            templateUrl: 'app/scripts/modules/ui/directives/templates/combo.change.ui.html',
            compile: function(el, attrs) {
                $(el).attr('name', attrs.name);
                
                return function(scope, element, attr, ngModel) {
                	var combo = angular.element(element.find('select'));
                	
                	combo.select2({
                        allowClear: true
                    });
                	
                	if (ngModel) {
                		// Write data to the model
                        function read() {
                        	var val = combo.select2('val');
                            if (val == "_") {
                                val = undefined;
                            }

                            ngModel.$setViewValue(val);
                            scope.change(val);
                            scope.$digest();
                        };
                        
                        // Specify how UI should be updated
                        ngModel.$render = function () {
                        	if(!scope.datasource || !scope.datasource.length){
                        		var unwatch = scope.$watch('datasource', function(newVal, oldVal){
                        			if(newVal && newVal.length){
                        				var timer = $timeout(function() {
                        					combo.select2('val', ngModel.$viewValue);
                        					unwatch();
                        					$timeout.cancel(timer);
                        				}, 1, false);
                        			}
                        		});
                        	}else{
                        		var timer = $timeout(function() {
                        			combo.select2('val', ngModel.$viewValue);
                        			$timeout.cancel(timer);
                        		}, 0, false);
                        	}
                        };

                        // Listen for change events to enable binding
                        combo.on('change', function () {
                        	read();
                        });
                        
                	} else {
                		// Listen for change events to enable binding
                        combo.on('change', function () {
                        	var val = combo.select2('val');
                            if (val == "_") {
                                val = undefined;
                            }

                            scope.change(val);
                        });
                	}
                };

            }
        };
    }];
});