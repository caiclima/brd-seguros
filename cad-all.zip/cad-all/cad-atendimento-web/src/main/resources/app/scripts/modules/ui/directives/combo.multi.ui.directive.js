/**
 * Created by swb_samuel on 02/12/2014.
 */
define([], function() {
    return ['$compile', '$timeout', '$stringUtilsService', function($compile, $timeout, $stringUtils){
        return {
            restrict: 'A',
            replace: true,
            scope: {
            	required: '=?',
            	disabled: '=?',
            	multiData: '=',
            	onItemSelected: '='
            },
            template: '<div></div>',
            link: function (scope, element, attrs) {
        	    if(!scope.disabled){
                   scope.disabled = false;
                }
        	    if(!scope.required){
                    scope.required = false;
                }
            	  
				scope._template = {
					startContainer: '<div class="multi-combo" style="margin-bottom: 15px;">',
					startSelect : '<select name="selectEvent" ng-disabled="disabled" ng-model="{0}" ng-required="required">',
					emptyOption : '<optgroup label="" class="ng-scope empty-opt" style="display:none"><option value="{{null}}" class="ng-scope ng-binding"></option></optgroup>',
					options : '<option ng-repeat="item in {0}" value="{{item.id}}">{{item.text}}</option>',
					endSelect : '</select>',
					endContainer: '</div>'
				};
				
            	scope.$watch('multiData', function(newValue, oldValue) {
            		if (newValue) {
            			scope.buildMultiCombo(newValue, undefined);
            		}
            	}, true);
            	
            	scope.change = function(val, level) {
            		scope.selectedItem = scope.findItem(level);
            		scope.onItemSelected(scope.selectedItem);
            	};
            	
				scope.buildMultiCombo = function(multiData, lastLevel) {
					multiData = multiData || {};
					
					if (multiData.datasource && multiData.datasource.length > 0) {
						var prop = scope.getMultiDataProperty(multiData.level);
						scope.set(prop, multiData);
	
						var combo = element.find('select')[multiData.level];
	
						if (combo === undefined) {
							var options = $stringUtils.format(scope._template.options, (prop + '.datasource'));
							var startSelect = $stringUtils.format(scope._template.startSelect, (prop + '.selectedID'));
	
							var newEl = scope._template.startContainer
									  + startSelect
									  + scope._template.emptyOption
									  + options
									  + scope._template.endSelect
									  + scope._template.endContainer;
							
							var comp = angular.element(newEl);
							$compile(comp)(scope);
							element.append(comp);
							
							combo = comp.find('select');
							
							scope.buildSelect2(combo, multiData.placeholder);
							scope.registerListener(combo, multiData.level);
							
						} else {
							combo = angular.element(combo);
						}

						var timer = $timeout(function() {
							combo.select2('val', multiData.selectedID);
							$timeout.cancel(timer);
						}, 1, false);
						
						scope.buildMultiCombo(multiData.children, multiData.level);
						
					} else if (lastLevel != undefined) {
						var combos = element.find('div.multi-combo');
						if(combos){
							$.each(combos, function(i,v){
								if(i > lastLevel){
									$(v).remove();
								}
							});
						}
					}
				};
            	
            	scope.buildSelect2 = function (combo, comboPlaceholder, value){
            		combo.select2({
                        placeholder: comboPlaceholder || '',
                        allowClear: true
                    });
            	};
            	
            	scope.registerListener = function(combo, level){
                	combo.on('change', function(e) {
                		scope.change(e.val, level);
                    	scope.$digest();
                    });
                };

            	scope.findItem = function(level) {
					var prop = scope.getMultiDataProperty(level);
                    return scope.get(prop);
                };
                
                scope.get = function(p) {
					var obj = scope;
					p = p.split('.');
					for (var i = 0, len = p.length; i < len - 1; i++){
						obj = obj[p[i]];
					}
					return obj[p[len - 1]];
				};

				scope.set = function(p, value) {
					var obj = scope;
					p = p.split('.');
					for (var i = 0, len = p.length; i < len - 1; i++){
						obj = obj[p[i]];
					}
					obj[p[len - 1]] = value;
				};
				
				scope.getMultiDataProperty = function(level){
					var prop = 'multiData';

					if (level > 0) {
						for (var i = 1; i <= level; ++i) {
							prop += '.children';
						}
					}
					
					return prop;
				};
            }
        };
    }];
});