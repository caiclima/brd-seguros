define([ ], function () {
    return [function () {
        return {
            restrict: "A",
            require: "ngModel",
            scope: {
                numberOnly: '=?',
                maxLength: '=?'
            },
            link: function (scope, element, attrs, ngModel) {
                if (!ngModel) return; // do nothing if no ng-model

                if(scope.numberOnly === undefined){scope.numberOnly = false;}

                // Specify how UI should be updated
                ngModel.$render = function () {
					element.text(ngModel.$viewValue || '');
                };

                // Listen for change events to enable binding
                element.on('keyup', function () {
                	normalize();
                });
                
                element.on('blur change', function () {
                	read();
                });
                
                function normalize() {
                    var val = element.text().replace("\n", "");

                    // When we clear the content editable the browser leaves a <br> behind
                    // If strip-br attribute is provided then we strip this out
                    if (attrs.stripBr && val == '<br>')
                        val = '';

                    if (scope.numberOnly)
                        val = val.replace( /[a-zA-Z]+/, '');
                    if (scope.maxLength)
                        val = val.substring(0, scope.maxLength);

					element.text(val || '');
                    placeCaretAtEnd(element[0]);
                }

                // Write data to the model
                function read() {
                    ngModel.$setViewValue(element.text());
                    scope.$digest();
                };

                function isNumber(val) {
                    return !isNaN(val) && isFinite(val);
                };

                function placeCaretAtEnd(el) {
                    el.focus();
                    if (typeof window.getSelection != 'undefined'
                            && typeof document.createRange != 'undefined') {
                        var range = document.createRange();
                        range.selectNodeContents(el);
                        range.collapse(false);
                        var sel = window.getSelection();
                        sel.removeAllRanges();
                        sel.addRange(range);
                    } else if (typeof document.body.createTextRange != 'undefined') {
                        var textRange = document.body.createTextRange();
                        textRange.moveToElementText(el);
                        textRange.collapse(false);
                        textRange.select();
                    }
                };
            }
        };
    }];
});