define(
		[],
		function() {
			return function() {
				return {
					restrict : 'A',
					replace : true,
					scope : {
						idmodel : '=',
						require : '=',
						currentDate : '=',
						onValue : '=?',
						minView : '=?'
					},
					templateUrl : 'app/scripts/modules/ui/directives/templates/datepicker.ui.html',
					compile : function(el, attrs) {
						$('input', $(el)).first().attr('name', attrs.name);

						return function(scope, element, attr) {

							if (scope.currentDate === undefined) {
								scope.currentDate = true;
							}
							var formatData = "dd/mm/yyyy hh:ii";
							
							if (scope.minView===false) {
								scope.minView = 2;
								formatData = "dd/mm/yyyy";
							}else {
								scope.minView = 0;
							}
							
							if (scope.currentDate) {
								var now = moment().format('YYYY-MM-DD');
								element.datetimepicker({
									language : 'pt-BR',
									format : formatData,
									startDate : now,
									autoclose : true,
									minView : scope.minView,
									pickerPosition : "bottom-left"
								});
							} else {
								element.datetimepicker({
									language : 'pt-BR',
									format : formatData,
									autoclose : true,
									minView : scope.minView,
									pickerPosition : "bottom-left"
								});
							}

							if (scope.onValue !== undefined) {
								scope.$watch('idmodel',
										function(newVal, oldVal) {
											if (newVal === oldVal)
												return;
											scope.onValue();
										});
							}
						};
					}
				};
			};

		});