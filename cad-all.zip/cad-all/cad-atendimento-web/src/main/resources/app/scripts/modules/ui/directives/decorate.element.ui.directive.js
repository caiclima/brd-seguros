/**
 * Created by swb_samuel on 05/05/2015.
 */
define([ ], function () {
    return [function () {
        return {
            restrict: 'A',
            scope: {
                attributes: '=?'
            },
            link: function (scope, element, attrs) {
                var unwatch = scope.$watch('attributes', function (nV, oV) {
                    if (nV != undefined) {
                        element.attr(nV);

                        if (nV.disabledText != undefined) {
                            if (nV.disabled) {
                                scope._oldText = element.text();
                                element.text(nV.disabledText);
                            } else {
                                element.text(scope._oldText);
                                scope._oldText = undefined;
                            }
                        }
                    }
                }, true);

                scope.$on('$destroy', function () {
                    unwatch();
                });
            }
        };
    }];
});