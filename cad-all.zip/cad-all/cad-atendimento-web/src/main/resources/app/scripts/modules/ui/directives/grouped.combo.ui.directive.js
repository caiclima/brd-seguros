define( [ ], function()

		{            
    return ['$eventNamingUtilsService','$rootScope','$caseRegisterRestService', function($eventNaming,$rootScope,$caseRegisterRestService){
    	
        return {
            restrict: 'A',
            replace: true,
            scope: {},
            controller:['$scope', '$element', '$attrs', function($scope, $element, $attrs) {
            	
            
                this.fillCombo = function(comboContent) {
                    $scope.combo = comboContent;
                }
                this.toggleCombo = function(disabled) {
                    $scope.comboDisabled = disabled;
                }
                this.changeEvent = function(_event) {
                    $scope.changeEvent = _event;
                }
            }],
            templateUrl: 'app/scripts/modules/ui/directives/templates/grouped.combo.ui.html',
            link: function(scope, element, attrs) {
            	
            	
            	
            	scope.$on($eventNaming.NamespaceCaseChanged, function(event, Case) {
            		 scope.showComboAction = false;
                 	
               	   if ($rootScope.Namespace.User.idOperacaoPrincipal != undefined) {
      	               		 $caseRegisterRestService.systemParameter($rootScope.Namespace.User.idOperacaoPrincipal,'visualizacaoComboAcoes', function(data) {
      	               			 if (data.valor.toUpperCase() == 'TRUE') {
      	               				scope.showComboAction = true;
      								}else{
      									scope.showComboAction = false;
      								}
      	               		}, function(msg) {
      	  						$alert.error(msg.data ? msg.data.error : msg.error);
      	  						scope.showComboAction = false;
      	  					});
               	   }
                });
            	
            	
              
         	   
                var selectEL = element.find("#select-funcoes");
                selectEL.select2({
                    placeholder: "Select a State",
                    allowClear: true
                });

                selectEL.on("change", function(e) {
                	scope.changeEvent(e.val);
                	scope.$digest();
                });
            }
        };
    }];
});