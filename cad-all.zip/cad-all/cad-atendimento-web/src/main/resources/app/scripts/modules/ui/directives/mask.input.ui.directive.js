define([], function () {
    return ['$q', function ($q) {
        return {
            restrict: 'A',
            replace: false,
            require: '?ngModel',
            scope: {
                maskFormat: '@?',
                currency: '=?'
            },
            link: function (scope, element, attrs, ngModel) {
                if (ngModel) {
                    var validator = function (val) {
                        if (val != undefined && val.indexOf("?") > -1) {
                            ngModel.$setValidity('$invalidChar', false);
                        } else {
                            ngModel.$setValidity('$invalidChar', true);
                        }
                        return val;
                    };

                    ngModel.$formatters.push(validator);
                    ngModel.$parsers.unshift(validator);
                }

                if (scope.currency == undefined) {
                    scope.currency = false;
                }

                if (scope.currency) {
                    element.on('focus', function () {
                        element.maskMoney({
                            symbol: '',
                            symbolStay: false,
                            thousands: '.',
                            decimal: ',',
                            precision: 2,
                            defaultZero: true,
                            allowZero: false,
                            allowNegative: false
                        });
                        element.maskMoney('mask');
                    });

                    element.on('blur', function () {
                        element.maskMoney('destroy');
                    });

                } else if (scope.maskFormat) {
                    /*
                     * As definições são customizadas para que se adaptem ao
                     * conceito de máscaras do CAD, que podem ser aplicadas a
                     * campos do tipo texto, portanto deve aceitar o 'espaço'
                     * como caracter válido. O carácter '?' representa qualquer valor inválido
                     */
                    $.mask.definitions['a'] = "[A-Za-z? ]";
                    $.mask.definitions['*'] = "[A-Za-z0-9? ]";

                    element.on('focus', function () {
                        var settings = {
                            placeholder: ' '
                        };

                        element.mask(scope.maskFormat.toString(), settings);
                    });

                    element.on('blur', function () {
                        element.unmask();
                    });
                }

                var unwatch = scope.$watch(function () {
                    return ngModel.$modelValue;
                }, function (newValue) {
                    if (newValue != undefined) {
                        if (scope.currency) {
                            element.maskMoney({
                                symbol: '',
                                symbolStay: false,
                                thousands: '.',
                                decimal: ',',
                                precision: 2,
                                defaultZero: true,
                                allowZero: false,
                                allowNegative: false
                            });
                            element.maskMoney('mask');

                        } else if (scope.maskFormat) {
                            /*
                             * As definições são customizadas para que se adaptem ao
                             * conceito de máscaras do CAD, que podem ser aplicadas a
                             * campos do tipo texto, portanto deve aceitar o 'espaço'
                             * como caracter válido. O carácter '?' representa qualquer valor inválido
                             */
                            $.mask.definitions['a'] = "[A-Za-z? ]";
                            $.mask.definitions['*'] = "[A-Za-z0-9? ]";

                            var settings = {
                                placeholder: ' '
                            };

                            element.mask(scope.maskFormat.toString(), settings);
                        }
                        unwatch();
                    }
                });
            }
        };
    }];
});