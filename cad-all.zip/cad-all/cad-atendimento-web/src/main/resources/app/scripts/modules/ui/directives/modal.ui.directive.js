define([], function () {
    return function () {
        return {
            restrict: 'A',
            replace: false,
            transclude: true,
            templateUrl: 'app/scripts/modules/ui/directives/templates/modal.ui.html',
            scope: {
                modalId: '@',
                modalClass: '@?',
                small: '=?'
            },
            link: function (scope, element, attrs) {
                if (scope.small == undefined) {
                    scope.small = false;
                }

                var unwatch = scope.$watch('small', function (newVal, oldVal) {
                    newVal = newVal == undefined ? false : newVal;

                    if(newVal){
                        scope.labelledby = 'myModalLabel';
                        scope.contentClass = '';
                    }else{
                        scope.labelledby = 'myLargeModalLabel';
                        scope.contentClass = 'modal-lg';
                    }

                    unwatch();
                });
            }
        };
    };
});