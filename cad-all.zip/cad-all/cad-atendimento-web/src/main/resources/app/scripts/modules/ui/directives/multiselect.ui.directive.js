define( [ ], function()
{            
    return ['$timeout',function($timeout){
        return {
            restrict: 'A',
            replace: true,
            scope: {
                datasource: '=',
                searcheable: '=?',
                inputPlaceholder: '@?',
                selectedItems: '=',
                idmodel: '=?'
            },
            templateUrl: 'app/scripts/modules/ui/directives/templates/multiselect.ui.html',
            link: function (scope, element, attr) {

                if(!scope.searcheable){
                    scope.searcheable = false;
                }

                if (!scope.selectedItems) {
                    scope.selectedItems = [];
                }

                var searchAndInclude = function (value) {
                    var idsSelected = [];
                    for (var j = 0, jLen = scope.selectedItems.length; j < jLen; j++) {
                        idsSelected.push(scope.selectedItems[j].id);
                    }
                    for (var i = 0, iLen = scope.datasource.length; i < iLen; i++) {
                        if (scope.datasource[i].id.toString() == value
                                && idsSelected.indexOf(scope.datasource[i].id) < 0) {
                            scope.selectedItems.push(scope.datasource[i]);
                        }
                    }
                };
                var searchAndRemove = function (value) {
                    var indexRemove = undefined;
                    for (var i = 0, iLen = scope.selectedItems.length; i < iLen; i++) {
                        if (scope.selectedItems[i] && scope.selectedItems[i].id && scope.selectedItems[i].id.toString() == value) {
                            indexRemove = i;
                            break;
                        }
                    }
                    if (indexRemove != undefined && indexRemove > -1) {
                        scope.selectedItems.splice(indexRemove, 1);
                    }
                };

                if(scope.searcheable){
                    var inputPlaceholder = scope.inputPlaceholder !== undefined ? scope.inputPlaceholder : '';
                    var fieldName = attr.name !== undefined ? " name='" + attr.name + "'" : "";

                    element.find('select').multiSelect({
                      selectableHeader: "<input type='text' class='search-input form-control' autocomplete='off' placeholder='" + inputPlaceholder + "'" + fieldName + ">",
                      selectionHeader: "<input type='text' class='search-input form-control' autocomplete='off' placeholder='" + inputPlaceholder + "'" + fieldName + ">",
                      afterInit: function(ms){
                        var that = this,
                            $selectableSearch = that.$selectableUl.prev(),
                            $selectionSearch = that.$selectionUl.prev(),
                            selectableSearchString = '#'+that.$container.attr('id')+' .ms-elem-selectable:not(.ms-selected)',
                            selectionSearchString = '#'+that.$container.attr('id')+' .ms-elem-selection.ms-selected';

                        that.qs1 = $selectableSearch.quicksearch(selectableSearchString)
                        .on('keydown', function(e){
                          if (e.which === 40){
                            that.$selectableUl.focus();
                            return false;
                          }
                        });

                        that.qs2 = $selectionSearch.quicksearch(selectionSearchString)
                        .on('keydown', function(e){
                          if (e.which == 40){
                            that.$selectionUl.focus();
                            return false;
                          }
                        });
                      },
                      afterSelect: function(value){
                        this.qs1.cache();
                        this.qs2.cache();
                        searchAndInclude(value);
                      },
                      afterDeselect: function(value){
                        this.qs1.cache();
                        this.qs2.cache();
                        searchAndRemove(value);
                      }
                    });
                } else {
                    element.find('select').multiSelect({
                        afterSelect: function(value){
                            searchAndInclude(value);
                        },
                        afterDeselect: function(value){
                            searchAndRemove(value);
                        }
                    });
                }

                var unwatch = scope.$watchCollection('datasource', function(newVal, oldVal){
                    if (newVal !== undefined) {
                        var timer = $timeout(function() {
                            element.find('select').multiSelect('refresh');

                            if (scope.selectedItems.length > 0) {
                                var selected = [];
                                for (var it = 0; it < scope.selectedItems.length; ++it) {
                                    selected.push('' + scope.selectedItems[it].id + '');
                                }
                                element.find('select').multiSelect('select', selected);
                            }
                            $timeout.cancel(timer);
                        }, 0, false);
                        
                        unwatch();
                    }
                });
            }
        };
    }];
});