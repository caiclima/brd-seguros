define([], function() {
	return function() {
		return {
			restrict : 'A',
			template : "<div><textarea cols='80' rows='15' /></div>",
			scope : {
				content : '=?',
				showToolbar : '=?',
				readOnly : '=?'
			},
			replace : true,
			link : function(scope, element, attrs) {
				var ta = $(element).children().first();
				if (scope.showToolbar == undefined) {
					scope.showToolbar = true;
				}
				if (scope.readOnly == undefined) {
					scope.readOnly = false;
				}
				if (scope.showToolbar) {
					ta.htmlarea({
								toolbar : [
										[ "bold", "italic", "underline", "|",
												"increasefontsize",
												"decreasefontsize" ],
										[ "indent", "outdent", "|",
												"justifyleft", "justifycenter",
												"justifyright" ],
										[ "orderedList", "unorderedList" ],
										[ "link", "unlink" ] ]
							});
				} else {
					ta.htmlarea({
						toolbar : [],
						loaded : function() {
							$('.btn-default').focus();
						}
					});
				}

				scope.$watch('content', function(newValue, oldValue) {
					if (newValue != undefined) {
						ta.htmlarea('html', '<div id="target">' + newValue
								+ '</div>');
						if (scope.readOnly) {
							$('.IFrame').css('background-color', '#e7e7e7');
							$('.IFrame').contents().off().on("keydown",
									function(event) {
										event.preventDefault();
										return;
									});
						}
					}
				});
				ta.attr('readOnly', scope.readOnly);
				ta.attr('id', attrs.elId);
			}
		};
	};
});