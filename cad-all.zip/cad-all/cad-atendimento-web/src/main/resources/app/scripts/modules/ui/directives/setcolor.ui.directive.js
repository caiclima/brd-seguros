define( [ ], function()
{            
    return [function(){
        return {
            restrict: 'A',
            scope: {
                colorData: '@'
            },
            link: function(scope, element, attrs) {
            	var unwatch = scope.$watch('colorData', function(newValue, oldValue){     
            		if(newValue){
            			element.css("background-color", newValue);    
            			unwatch();                                       
            		}
                });
            }
        };
    }];
});