    define( [ ], function()
    {
        return function(){        	
              return {
                restrict: 'A',
                replace: true,
                templateUrl: 'app/scripts/modules/ui/directives/templates/table.ui.html',
                scope: {
                   config: '=',
                   searchable: '=?',
                   datasource: '=',
                   context: '@'
               },
               link: function(scope, element, attrs) {
                   scope.filter = '';

                   scope.$watch('filter', function(newVal, oldVal){
                       var rex = new RegExp(newVal, 'i');
                       $('tr.searchable').hide();
                       $('tr.searchable').filter(function () {
                           return rex.test($(this).text());
                       }).show();
                   });

                   scope.notSorted = function(obj){
                       if (!obj) {
                           return [];
                       }
                       var result = Object.keys(obj);
                       return result;
                   }
               }
        };
    };
});