/**
 * Created by swb_samuel on 05/11/2014.
 */
define([], function() {
    return [function(){
        return {
            restrict: 'A',
            templateUrl: 'app/scripts/modules/ui/directives/templates/timely.ui.html',
            controller: ['$scope', '$element', '$attrs', '$interval', '$stringUtilsService', '$eventNamingUtilsService', function ($scope, $element, $attrs, $interval, $stringUtils, $eventNaming) {
                $scope.autoStart = $attrs.autoStart || $attrs.autostart;
                $scope.show = undefined;
                $scope.checker = undefined;
                $scope.hours   = '00';
                $scope.minutes = '00';
                $scope.seconds = '00';
                $scope.hh = 0;
                $scope.mm = 0;
                $scope.ss = 0;

                $scope.$on($eventNaming.TimerRestart, function(){
                    $scope.show = true;
                    $scope.stop();
                    $scope.play();
                });

                $scope.$on($eventNaming.TimerStopHide, function(){
                    $scope.show = false;
                    $scope.stop();
                });

                $scope.$on($eventNaming.TimerPlayShow, function(){
                    $scope.show = true;
                    $scope.play();
                });

                $scope.play = function(){
                    $scope.show = true;
                    $scope.checker = $interval(function() {
                        if($scope.ss < 59){
                            $scope.ss += 1;
                        }else{
                            $scope.ss = 0;
                            if($scope.mm < 59){
                                $scope.mm += 1;
                            }else{
                                $scope.mm = 0;
                                $scope.hh += 1;
                            }
                        };
                        $scope.evalTime();

                    }, 1000, 0, false);
                };

                $scope.resume = function(){
                    $scope.cancelInterval();
                };

                $scope.stop = function(){
                    $scope.cancelInterval();
                    $scope.hours   = '00';
                    $scope.minutes = '00';
                    $scope.seconds = '00';
                    $scope.ss = 0;
                    $scope.mm = 0;
                    $scope.hh = 0;
                };

                $scope.cancelInterval = function(){
                    if($scope.checker){
                        $interval.cancel($scope.checker);
                    }
                };

                $scope.evalTime = function(){
                    $scope.hours   = $stringUtils.lpad($scope.hh, 2);
                    $scope.minutes = $stringUtils.lpad($scope.mm, 2);
                    $scope.seconds = $stringUtils.lpad($scope.ss, 2);
                };

                if($scope.autoStart === undefined || $scope.autoStart === true || $scope.autoStart === 'true') {
                    $scope.show = true;
                    $scope.play();
                }
            }]
        };
    }];
});