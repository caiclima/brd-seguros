    define( [ ], function()
    {            
        return function(){        	
        	 return {
                restrict: 'A',
                scope: {
                	tooltipTitle: '@',
                },
                link: function(scope, element, attrs) {  
             
                $(element).tooltip({
                    title: scope.tooltipTitle,
                });

               
            	}
            };
        };
    });