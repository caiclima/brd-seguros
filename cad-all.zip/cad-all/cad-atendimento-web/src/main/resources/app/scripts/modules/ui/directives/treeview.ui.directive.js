define([], function(){
    return ['$interval','$stringUtilsService', function($interval, $stringUtils){
         return {
            restrict: 'A',
            replace: true,
            scope: {
                nodes: '=',
                onNodeSelected: '=',
                onTreeBuilded: '=?',
                treeId: '@',
                levels: '@',
                highlightClass: '@',
                baseIconClass: '@',
                borderColor: '@',
                expandIcon: '@',
                collapseIcon: '@'
            },
            templateUrl: 'app/scripts/modules/ui/directives/templates/treeview.ui.html',
            link: function(scope, element, attrs) {
                /*
                *  Store the element id
                */
                scope.elId = $stringUtils.format('#{0}', scope.treeId);
                /*
                *  Sometimes, controller may have already
                *  assigned nodes attribute. So we must
                *  do a check before waiting on $watch
                */
                if(scope.nodes !== undefined && scope.nodes.length > 0) {
                    buildTreeView(scope.nodes);
                }
                /*
                *   Watch for any assign on scope.events attribute
                */
                scope.$watchCollection('nodes', function(newValue, oldValue) {
                    /*
                    *  When using $watch, it is important to
                    *  do this checking to prevent dummy
                    *  events on its initialization
                    */
                    if (newValue === oldValue)
                        return;
                    /*
                    *  We receive the reassigned events tree
                    */
                    scope.nodesTree = newValue;
                    /*
                    *  Destroy previous Treeview
                    */
                    var hasPrevious = destroyTreeview();
                    /*
                    *  Construct Treeview component
                    */
                    buildTreeView(scope.nodesTree, hasPrevious, onBuilded = function() {
                       /*
                        *  After the tree is builded
                        *  we remove default node icon
                        *  and alter toggle nodes functionality
                        */
                        replaceIcons();
                        /*
                        *  Based on selected Node
                        *  we can discover its Id and then
                        *  highlight ul>li
                        */
                        highlightNode();
                        /*
                        *  Trigger to model
                        */
                        if(scope.onTreeBuilded) {
                            scope.onTreeBuilded(scope.nodesTree);
                        } 
                    });                    
                });
                /*
                *  This method builds the treeview component
                */
                function buildTreeView(nodes, hasPrevious, successFn) {
                    if(hasPrevious) {
                        applyPlugin();
                        successFn();
                    } else {
                        var check = $interval(function() {
                            if($(scope.elId)) {
                                applyPlugin();
                                if(successFn)
                                    successFn();
                                $interval.cancel(check);
                            }
                        }, 250, 0, false);
                    }

                    function applyPlugin() {
                        $(scope.elId).treeview({
                            onNodeSelected: function(event, node) {
                                /*
                                * prevent multiple notifications
                                */
                                if(node.eventTriggered)
                                    return;
                                node.eventTriggered = true;
                                /*
                                * store selected node
                                */
                                scope.selectedNode  = node;
                                /*
                                * Trigger to model
                                */
                                scope.onNodeSelected(node);
                            },
                            //invert icon assignment
                            collapseIcon: $stringUtils.concatenate(scope.baseIconClass, ' ', scope.expandIcon),
                            levels: scope.levels,
                            borderColor: scope.borderColor,
                            data: nodes
                        });
                    }
                };
                /*
                *  This method destroys any previous tree view component
                *  with a particular id
                */
                function destroyTreeview() {
                    var previouslyCreated = $(scope.elId).children().length > 0;
                    if(previouslyCreated) {
                        $(scope.elId).treeview('remove');
                    }
                    return previouslyCreated;
                }
                /*
                *  This method has the cappability of highliting 
                *  the selected node in the treeview
                */
                function highlightNode() {
                    if(scope.selectedNode !== undefined) {
                        if(!scope.selectedNode.nodePath) {
                            
                            return;
                        }
                        /*
                        * Figure out data-nodeid value 
                        * using node's path
                        */
                        var nodeId = getRealisticNodeId(scope.selectedNode);

                        var nodeElSelector = $stringUtils.format('li[data-nodeid={0}]', nodeId);
                        var nodeEl = $(nodeElSelector);
                        nodeEl.addClass(scope.highlightClass);
                        nodeEl.addClass('node-selected');
                    }
                }
                /*
                *  Alter default icons
                */
                function replaceIcons() {
                    //remove node icon
                    $('.glyphicon.glyphicon-stop').removeClass('glyphicon-stop');

                    //remove toggle class
                    //hence bootstrap-treeview will always trigger nodeSelected Event
                    $('i','li').removeClass('click-collapse').removeClass('click-expand');

                    //Change selected node Icon
                    // '+' -> '-'
                    if(scope.selectedNode !== undefined) {                        
                        changeToggleIcon(scope.selectedNode);

                        // Change parents Toggle icon as well
                        var nodePath = scope.selectedNode.nodePath;
                        var posOnFirstLevel = nodePath[0];
                        var currNode   = scope.nodesTree[posOnFirstLevel];
                        for(var it = 1; it < nodePath.length; ++it) {
                            var pos   = nodePath[it];
                            changeToggleIcon(currNode);
                            //Dive into further
                            currNode  = currNode.nodes[pos];
                        }
                    }
                }
                /*
                * Figure out data-nodeid value 
                * using node's path
                */
                function getRealisticNodeId(node) {
                    var nodePath  = node.nodePath;
                    var levels = nodePath.length;
                    var position = undefined;
                    if(levels == 1) {
                        position = nodePath[0];
                    } else {
                        position = 0;
                        for(var it=0; it < nodePath.length; ++it) {
                            position = position + nodePath[it];
                            position = position + 1;
                        }
                        position = position - 1;
                    }
                    return realisticNodeId = position;
                }

                function changeToggleIcon(node) {
                    var nodeId = getRealisticNodeId(node);
                    var elScope = $stringUtils.format('li[data-nodeid={0}]', nodeId);
                    var iconSelector = $stringUtils.concatenate('.', scope.baseIconClass, '.', scope.expandIcon);
                    var nodeEl = $(iconSelector, elScope);
                    nodeEl.removeClass(scope.expandIcon).addClass(scope.collapseIcon);
                }
            }
        }
    }];
});