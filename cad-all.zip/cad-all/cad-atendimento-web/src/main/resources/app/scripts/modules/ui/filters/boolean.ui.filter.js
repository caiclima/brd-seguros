define([], function() {
  return ['$filter', function($filter) {
    return function(input) {
       if(input === 'true' || input === 'false'){
       	  return input === 'true' ? $filter('translate')('bundle.cad.YES') : $filter('translate')('bundle.cad.NO');
       }  

       return input;     
    };
  }];
});