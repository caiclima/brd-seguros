define([], function() {
  return function() {
    return function(input, param) {
      var out = input;
      
      if(input != null && input != undefined && input != ''){
         out =  moment(new Date(parseInt(out)));
        out = out.format('L') + ' ' + out.format('LT');
      }
      
      return out;
    };
  };
});