define([], function() {
  return ['$genericUtilsService', function($genericUtils) {
    return function(input, param) {
      var out = input;
      if(param){
        if(input != null && input != undefined && input != '-' && input != ''){
          //out =  moment(new Date(out));
          //out = out.format('L') + ' ' + out.format('LT');
          out = $genericUtils.fromServersDateFormat(out);
        }
      }
      return out;
    };
  }];
});