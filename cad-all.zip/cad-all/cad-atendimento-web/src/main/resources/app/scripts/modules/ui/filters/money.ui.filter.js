define([], function() {
	return [ '$filter', function($filter) {
		return function(input, symbol) {
			if (input && input.indexOf(",") >= 0) {
				input = input.replace(new RegExp('\\.'), '');
				input = input.replace(new RegExp('\\,'), '.');
			}

			return $filter('currency')(input, symbol);
		};
	} ];
});