define([], function() {
	return [ function() {
		return function(arr, start, end) {
			if (!end) {
				end = arr.length;
			}
			var ret = arr.slice(start, end);
			start = end + 1;
			end = end * 2
			
			return ret;
		}
	} ];
});