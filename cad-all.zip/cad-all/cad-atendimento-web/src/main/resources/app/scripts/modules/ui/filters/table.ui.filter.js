define([], function() {
  return function() {
    return function(input, param) {
      type = param.type;
      input = input || '';
      var out = "";
      out = input;
       
      if (type != undefined) {
        if (type == 'label') {     
          out = '';
        } 
        if (type == 'labelQueue' && ( input.color == null || input.color == '' ) ) {     
        	out = input.title;
        }
        if (type == 'labelQueue' && ( input.color != null && input.color != '' ) ) {     
        	out = '';
        } 
        if (type == 'icon-row') {     
          out = '';
        } 
        if (type == 'inplace-edit') {
          out = '';
        }
        if (type == 'check') {
              out = '';
        }
        if (type == 'link') {
          out = '';
        }
        if (type == 'link-toogle') {
          out = '';
        }
        if(type == 'download'){
          out = '';
        }
        if(type == 'button') {
          out = '';
        }
        if(type == 'button-toogle'){
          out = '';
        }
        if(type == 'button-toogle-2'){
            out = '';
        }
        if(type == 'button-danger'){
          out = '';
        }
        if(type == 'button-icon-primary'){
          out = '';
        }        
        if(type == 'button-primary'){
          out = '';
        }
        if(type == "icon-text-toogle"){
          out = '';
        }
        if(type == "icon-color"){
          out = input.title;
        }
        if(type == "icon-text"){
          out = input;
        }
        if(type == "icon-text-default"){
          out = input;
          if(out == '' || out == undefined || out == null){
            out = param.default;
          }
        }
      }
      if(
        (out == '' || out == undefined || out == null) && 
        type != 'label' && 
        type != 'labelQueue' && 
        type != 'link' &&
        type != 'link-toogle' &&
        type != 'download' && 
        type != 'button' &&
        type != 'icon-text-default' &&
        type != 'icon-text-toogle' &&
        type != 'icon-row' &&
        type != 'inplace-edit' &&
        type != 'check' && 
        type != 'button-toogle' &&
        type != 'button-toogle-2' &&
        type != 'button-danger' &&
        type != 'button-primary' &&
        type != 'button-icon-primary' 
        ){
        out = '-';
      }
     
      return out;
    };
  };
});