  define( [ ], function()
  {
    return function(){
      return {
        showmodal: function (title, msg, okCallBack, lockModal) {
          $("#globalModalHeader").find("h4").text('');
          $("#text-modal").html('');
          $("#globalModalHeader").show();
          $("#globalModalBody").show();
          $("#globalModalFooter").show();          
          $("#text-modal").html(msg);
          $("#globalModalHeader").find("h4").text(title);
        
          if(okCallBack) {
            $('#ok-modal').click(okCallBack);
          }

          if(lockModal === undefined) {
            $("#globalModal").modal('show');
          } else {
            $("#globalModal").modal({
              'backdrop': 'static'
            });
          }                           
        }
      }
    };  
  });    