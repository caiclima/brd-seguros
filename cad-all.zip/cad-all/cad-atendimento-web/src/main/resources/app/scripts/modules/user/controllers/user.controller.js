    define( [ ], function()
    {
            
        var UserController = function( $scope, $logService )
            {
                
            	$scope.user = '';
                $scope.suffix = " User";
                
                $scope.$watch('user', function(newValue, oldValue){
                	$logService.log('User Changed:' + newValue);	
            	});


            };

        return [ "$scope", "$logService", UserController ];

    });