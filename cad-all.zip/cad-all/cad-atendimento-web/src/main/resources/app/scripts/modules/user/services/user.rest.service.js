define([], function() {

    var UserRestService = function($resource, $requestUtils) {
        return {
            loggedUser: function(_successFn, _errorFn) {
                var uri = "/api/users/loggeduser";
                $resource($requestUtils.contextPath() + uri).get({}, _successFn, _errorFn);
            }
        };
    };

    return ["$resource", "$requestUtilsService", UserRestService];
});