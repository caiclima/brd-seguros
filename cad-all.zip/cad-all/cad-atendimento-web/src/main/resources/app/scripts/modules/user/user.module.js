/*
 * module definitions 
 */

define(
	['angular', 'UserController', 'UserRestService'], 

	function(angular, UserController, UserRestService){
		var _m = angular.module('UserModule', ['LogModule', 'UtilsModule']);

		_m.controller('UserController', UserController);
        _m.factory('$userRestService', UserRestService);

		return _m;
});