define([], function() {
  return function() {
    return function(input) {
      var out = input;
      if(input == null || input == undefined || input == ''){
          out = "-";     
      }
      return out;
    };
  };
});