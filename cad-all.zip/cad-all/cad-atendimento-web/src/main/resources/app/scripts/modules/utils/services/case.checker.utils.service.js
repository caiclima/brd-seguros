define([], function() {
    return ['$genericUtilsService', '$dictionaryUtilsService', function($genericUtils, $dictionaryUtils) {
        return {
            //This function only indicates that we hasnt requested any Case to server yet.
            caseNotLoadedYet: function(Case) {
                return $genericUtils.isRawJson(Case);
            },
            //It actually means no case at all.
            //Server rule is to send a fake case object, having all properties set to null values,
            //indicating that user has any case set.
            fakeCase: function(Case) {
                return Case === undefined || (!$genericUtils.isRawJson(Case) && $genericUtils.isNull(Case[$dictionaryUtils._caseId]));
            },
            //We consider a case, at its real concept, when the Case JSON object has the 'idCaso' property
            //set to a value different from null.
            realCase: function(Case) {
                return Case !== undefined && !$genericUtils.isRawJson(Case) && !$genericUtils.isNull(Case[$dictionaryUtils._caseId]);
            }
        }
    }];
});