define([], function() {
    return ['$filter', function($filter){ 
            return {
                format: function(objectList, id, text ) {

                    var prettyList = [];
                    if(objectList){
                        for (var it = 0; it < objectList.length; ++it) {
                            var object = objectList[it];
                            var pretty = {};
                            pretty["id"] = object[id];
                            pretty["text"] = object[text];
                            prettyList.push(pretty);
                        }
                    }

                    return prettyList;
                },
                formatInverse: function(prettyList, id, text ) {

                    var objectList = [];
                    if(prettyList){
                        for (var it = 0; it < prettyList.length; ++it) {
                            var pretty = prettyList[it];
                            var object = {};
                            object[id] = pretty["id"];
                            object[text] = pretty["text"];
                            objectList.push(object);
                        }
                    }

                    return objectList;
                },
                booleanOptions: function(){
                    var prettyList = [];
                    
                    prettyList.push({
                        id: true,
                        text: $filter('translate')('bundle.cad.YES')
                    });

                    prettyList.push({
                        id: false,
                        text: $filter('translate')('bundle.cad.NO')
                    });      
                    
                    return prettyList;
                }
            };
        }];
});