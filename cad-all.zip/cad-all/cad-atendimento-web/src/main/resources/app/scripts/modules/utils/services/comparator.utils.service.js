define([], function() {

    var ComparatorUtilsService = function($dictionaryUtils, $stringUtils) {

        function _checkMatching(matched, operator) {
            var isEqualOp = $stringUtils.equalsIgnoreCase(operator, $dictionaryUtils._equalOperator);
            var isDiffOp  = $stringUtils.equalsIgnoreCase(operator, $dictionaryUtils._differentOperator);

            if(isEqualOp && matched || isDiffOp && !matched) {
                return true;
            } else {
                return false;
            }
        }
        return {
            compare: function(actual, expected, operator) {
                var matched = $stringUtils.equalsIgnoreCase(actual, expected);
                return _checkMatching(matched, operator);
            },

            like: function(actual, expected, operator) {
                var matched;
                if(expected instanceof Array) {
                    matched = true;
                    for(var it=0; it < expected.length; ++it) {
                        var comparable = expected[it];
                        matched = matched && actual.indexOf(comparable) > -1;
                    }
                } else {
                    matched = actual.indexOf(expected) > -1;
                }
                
                return _checkMatching(matched, operator);
            }
        };
    };

    return ['$dictionaryUtilsService','$stringUtilsService', ComparatorUtilsService];
});