define([], function() {
    return function() {
        return {
            NamespaceCaseChanged: 'NamespaceCaseChanged',
            PendingCasesChanged: 'PendingCasesChanged',
            LoadingComplete: 'LoadingComplete',
            InternalContentChanged: 'InternalContentChanged',
            NotificationsFetched: 'NotificationsFetched',
            TimerStopHide: 'timer-stop-hide',
            TimerPlayShow: 'timer-play-show',
            TimerRestart: 'timer-restart',
            RefreshTotalPendency: 'refresh-total-pendency'
        };
    };
});