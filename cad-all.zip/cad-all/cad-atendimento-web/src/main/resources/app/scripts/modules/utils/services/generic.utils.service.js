define( [ ], function()
{
    return function(){
        return {
            isRawJson: function(obj) {
                if(obj !== undefined) {
                    for(var prop in obj) {
                        if(obj.hasOwnProperty(prop))
                            return false;
                    }    
                }
                return true;
            },

            randomInRage: function (min, max) {
                return Math.floor(Math.random() * (max - min + 1)) + min;
            },

            isNull: function(obj) {
                        return obj === undefined || obj === null;
            },

            toServersDateFormat: function(obj) {
                if(!obj){
                    return obj;
                }
                var m = moment(obj, "DD-MM-YYYY HH:mm");
                return m.valueOf();
            },

            fromServersDateFormat: function(obj) {
                var m =  moment(new Date(parseInt(obj)));
                return m.format('L') + ' ' + m.format('LT');
            }
        };
    };
});    