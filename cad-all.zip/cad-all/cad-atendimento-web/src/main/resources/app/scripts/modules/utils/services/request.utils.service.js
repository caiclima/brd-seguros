define( [ ], function()
{
    return ['$stringUtilsService', function($stringUtils){
        return {
            contextPath: function (){
               return '/' + window.location.pathname.split('/')[1];
            },

            absolutPath: function() {
                var protocol = window.location.protocol;
                var host = window.location.host;
                var domain = $stringUtils.concatenate(protocol, '//', host);
                var path = this.contextPath();
                return domain + path;
            }
        };
    }];
});    