define( [ ], function()
{
    return function(){
        return {
            format: function () {
                            var s = arguments[0];
                            for (var i = 0; i < arguments.length - 1; i++) {
                                var reg = new RegExp("\\{" + i + "\\}", "gm");
                                s = s.replace(reg, arguments[i + 1]);
                            }
                            return s;
                        },
            concatenate: function () {
                            var concatenated = '';
                            for( var i = 0; i < arguments.length; ++i) {
                                var arg = arguments[i];
                                concatenated = concatenated.concat(arg);
                            }
                            return concatenated;
            },
            equalsIgnoreCase: function() {
                return arguments[0].toUpperCase() === arguments[1].toUpperCase();
            },
            replaceAll: function(){
                var string = arguments[0];
                var token = arguments[1];
                var newtoken = arguments[2];
                while (string.indexOf(token) != -1) {
                    string = string.replace(token, newtoken);
                }
                return string;
            },
            lpad: function(i,l,s) {
                if(i === undefined || l === undefined) return i;
                var o = i.toString();
                if (!s) { s = '0'; }
                while (o.length < l) {
                    o = s + o;
                }
                return o;
            }
        }
    };
});    