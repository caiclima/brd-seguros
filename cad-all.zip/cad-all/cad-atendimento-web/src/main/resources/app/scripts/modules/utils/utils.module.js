define([
        'angular', 
        'StringUtilsService', 
        'RequestUtilsService', 
        'DictionaryUtilsService',
        'GenericUtilsService',
        'EmptyUtilsFilter',
        'ComboPrettyFormatUtilsService', 
        'CaseCheckerUtilsService',
        'EventNamingUtilsService',
        'ComparatorUtilsService'], 

    function(angular, StringUtilsService, RequestUtilsService, DictionaryUtilsService, GenericUtilsService, EmptyUtilsFilter,ComboPrettyFormatUtilsService, CaseCheckerUtilsService, EventNamingUtilsService, ComparatorUtilsService){
        var _m = angular.module('UtilsModule', []);
        _m.factory('$stringUtilsService', StringUtilsService);
        _m.factory('$requestUtilsService', RequestUtilsService);
        _m.factory('$dictionaryUtilsService', DictionaryUtilsService);
        _m.factory('$genericUtilsService', GenericUtilsService);
        _m.factory('$comboPrettyFormatUtilsService', ComboPrettyFormatUtilsService);
        _m.factory('$caseCheckerUtilsService', CaseCheckerUtilsService);        
        _m.factory('$eventNamingUtilsService', EventNamingUtilsService);
        _m.factory('$comparatorUtilsService', ComparatorUtilsService);
        _m.filter('emptyUtils', EmptyUtilsFilter);
        return _m;
});