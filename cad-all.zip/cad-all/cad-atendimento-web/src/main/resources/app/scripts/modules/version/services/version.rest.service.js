define( [ ], function()
{
    var VersionRestService = function($resource, $requestUtils)
    {
        return {
            getSystemVersion: function(_successFn, _errorFn) {
                var uri = '/api/version/systemversion';
                return $resource($requestUtils.contextPath() + uri).get({}, _successFn, _errorFn);
            }
        }
    };

    return [
        "$resource",
        "$requestUtilsService",
        VersionRestService
    ];
});