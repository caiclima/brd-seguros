/*
 * module definitions 
 */

define(['angular', 'VersionRestService' ], 

	function(angular, VersionRestService){
		var _m = angular.module('VersionModule', ['pascalprecht.translate','ngCookies', 'UtilsModule']);

        _m.factory('$versionRestService', VersionRestService);

		return _m;
});