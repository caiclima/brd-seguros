define([], function() {

    var WorkingAvailabilityStatusesController = function($rootScope, $scope, $window, $filter, $location, $restService, $dictionaryUtils, $alert, $requestUtils, $eventNaming) {

        var namespace = $rootScope.Namespace;
        var workingStatus = namespace.WorkingStatus;
        var userId = namespace.User[$dictionaryUtils._userId];

        $restService.fetchPauseStatuses(
            userId,
            function(unavailabilityStatuses) {
                var prettyList = [];
                for(var it = 0; it < unavailabilityStatuses.length; ++it) {
                    var unabailabilityStatus = unavailabilityStatuses[it];

                    var title        = unabailabilityStatus[$dictionaryUtils._userStatusName];
                    var color        = unabailabilityStatus[$dictionaryUtils._userStatusColor];
                    var userStatusId = unabailabilityStatus[$dictionaryUtils._userStatusId];
                    var prettyEntry = function(title, color, userStatusId) {
                        return {
                            title: title,
                            color: color,
                            action: function() {
                                _pauseWork(title, color, userStatusId);
                            }
                        };
                    }(title, color, userStatusId);

                    prettyList.push(prettyEntry);
                }
                $scope.unavailabilityStatuses = prettyList;
            },
            function(msg) {
                $alert.error(msg.data ? msg.data.error : msg.error);
            }
        );

        var _pauseWork = function(title, color, userStatusId) {
            $restService.pauseWork(
                userId, userStatusId,
                function() {
                    namespace.WorkingStatus.RequestedPause = true;

                    var currentStatus = {};
                    currentStatus[$dictionaryUtils._statusName]  = title;
                    currentStatus[$dictionaryUtils._statusColor] = color;
                    currentStatus[$dictionaryUtils._pausedFlag]  = true;

                    var notification = {};
                    notification[$dictionaryUtils._currentStatus] = currentStatus;

                    $rootScope.$broadcast($eventNaming.NotificationsFetched, notification);
                    $rootScope.$broadcast($eventNaming.TimerStopHide);

                    // $location.path('/');
                },
                function(msg) {
                    $alert.error(msg.data ? msg.data.error : msg.error);
                });
        };

        $scope.resumeWorkAction = function() {
            $restService.continueWork(
                userId,
                function() {
                    if($rootScope.Namespace.Loaded){
                        /*
                         *  We force page reload in order to fetch case and pending cases
                         *  without having to notify other controllers through broadcast
                         */
                        $window.location.href = $requestUtils.contextPath();
                    }
                },
                function(msg) {
                    $alert.error(msg.data ? msg.data.error : msg.error);
                });
        };

        $scope.unavailabilityStatuses = [];
        $scope.isPausedWork = workingStatus.Paused;
        $scope.pausedStatus = {
            title: workingStatus[$dictionaryUtils._statusName],
            color: workingStatus[$dictionaryUtils._statusColor],
            retPausaToolbar: workingStatus[$dictionaryUtils._statusRetPausaToolbar]
        };
    }

    return ['$rootScope',
            '$scope',
            '$window',
            '$filter',
            '$location',
            '$workingAvailabilityRestService',
            '$dictionaryUtilsService',
            '$alertUiService',
            '$requestUtilsService',
            '$eventNamingUtilsService',
            WorkingAvailabilityStatusesController];
});