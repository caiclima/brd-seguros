define([], function() {
    return ['$filter', '$interval', function($filter, $interval) {
        return {
            restrict: 'A',
            replace: true,
            scope: {
                statuses: '=',
                isPausedWork: '=',
                pausedStatus: '=',
                resumeWorkAction: '='
            },
            templateUrl: 'app/scripts/modules/working_availability/directives/templates/working.availability.html',
            link: function(scope, element, attrs) {
                /*
                *  Configure table header and columns fill
                */
                scope.config = [
                    {
                        title: $filter('translate')('bundle.cad.PAUSE_STATUS'),
                        type: "label"
                    },
                    {
                        title: $filter('translate')('bundle.cad.ACTION'),
                        type: 'button',
                        icon: 'icon-18-5'
                    }
                ];
                /*
                *  Show blocking static modal if user is paused
                *  for work
                */
                if(scope.isPausedWork) {
                    /*
                    *  We must check whether div element is ready
                    *  before calling modal function
                    */
                    var checker = $interval(function() {
                        if($("#pausedWorkModal")) {
                            $("#pausedWorkModal").modal({
                                'backdrop': 'static'
                            });
                            $interval.cancel(checker);
                        }
                    }, 250, 0, false);
                }
                /*
                *  Intercept action in order to hide modal
                *  before redirection
                */
                scope.resumeWorkActionInterceptor = function() {
                    $('#pausedWorkModal').on('hidden.bs.modal', function (e) {
                        //send event upperwards
                        scope.resumeWorkAction();
                    });
                    $('#pausedWorkModal').modal('hide');                    
                }
            }
        };
    }]
});