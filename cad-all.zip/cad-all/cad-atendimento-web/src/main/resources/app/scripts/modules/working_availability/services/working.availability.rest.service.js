define([], function() {

    var WorkingAvailabilityRestService = function($resource, $requestUtils, $stringUtils, $dictionaryUtils) {

        var _commonResource = function(uri, options) {
            var path = $requestUtils.contextPath();
            var url = $stringUtils.concatenate(path, $stringUtils.format(uri, $dictionaryUtils._userId));

            var paramDefaults = {};
            paramDefaults[$dictionaryUtils._userId] = $stringUtils.format('@{0}', $dictionaryUtils._userId);

            return $resource(url, paramDefaults, options);
        }

        var _putResource = function(uri) {
            return _commonResource(uri, {
                    update: {
                        method: 'PUT'
                    }
                });
        };

        var _getResource = function(uri) {
            return _commonResource(uri, {});
        };

        return {
            fetchPauseStatuses: function(userId, successFn, errorFn) {
                var urlParams = {};
                urlParams[$dictionaryUtils._userId] = userId;

                var resource = _getResource('/api/status/findstatususer/:{0}');
                resource.query(urlParams, successFn, errorFn);
            },

            pauseWork: function(userId, userIdStatus, successFn, errorFn) {
                var payload = {};
                payload[$dictionaryUtils._userId]       = userId;
                payload[$dictionaryUtils._userStatusId] = userIdStatus;

                var resource = _putResource('/api/status/updatestatuspauseuser/:{0}');
                resource.update(payload, successFn, errorFn);
            },

            continueWork: function(userId, successFn, errorFn) {
                var payload = {};
                payload[$dictionaryUtils._userId]       = userId;

                var resource = _putResource('/api/status/updatestatuscontinuouser/:{0}');
                resource.update(payload, successFn, errorFn);
            },

            userWorkingStatus: function(userId, successFn, errorFn) {
                var urlParams = {};
                urlParams[$dictionaryUtils._userId] = userId;

                var resource = _getResource('/api/operationaltimes/user/:{0}/currentstatus');
                resource.get(urlParams, successFn, errorFn);
            }
        };
    };

    return ['$resource',
            '$requestUtilsService',
            '$stringUtilsService',
            '$dictionaryUtilsService', 
            WorkingAvailabilityRestService];
});