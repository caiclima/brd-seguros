define([
    'angular',
    'WorkingAvailabilityRestService',
    'WorkingAvailabilityController',
    'WorkingAvailabilityDirective',
    ], function(angular, WorkingAvailabilityRestService,WorkingAvailabilityController, WorkingAvailabilityDirective) {
        var _m = angular.module('WorkingAvailabilityModule', ['UtilsModule',
                                                              'pascalprecht.translate',
                                                              'ngCookies',
                                                              'UiModule']);

        _m.controller('WorkingAvailabilityController', WorkingAvailabilityController);
        _m.directive('workingAvailability', WorkingAvailabilityDirective);
        _m.factory('$workingAvailabilityRestService', WorkingAvailabilityRestService);
        
        return _m;
});