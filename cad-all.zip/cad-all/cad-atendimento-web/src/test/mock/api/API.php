<?php
abstract class API
{
    /**
     * Property: method
     * The HTTP method this request was made in, either GET, POST, PUT or DELETE
     */
    protected $method = '';
    /**
     * Property: endpoint
     * The Model requested in the URI. eg: /files
     */
    protected $endpoint = '';
    /**
     * Property: verb
     * An optional additional descriptor about the endpoint, used for things that can
     * not be handled by the basic methods. eg: /files/process
     */
    protected $verb = '';
    /**
     * Property: args
     * Any additional URI components after the endpoint and verb have been removed, in our
     * case, an integer ID for the resource. eg: /<endpoint>/<verb>/<arg0>/<arg1>
     * or /<endpoint>/<arg0>
     */
    protected $args = Array();
    /**
     * Property: file
     * Stores the input of the PUT request
     */
     protected $file = Null;

    /**
     * Constructor: __construct
     * Allow for CORS, assemble and pre-process the data
     */
    public function __construct($request) {
        header("Access-Control-Allow-Orgin: *");
        header("Access-Control-Allow-Methods: *");

        $this->args = explode('/', rtrim($request, '/'));
        $this->endpoint = str_replace("/","_", rtrim($request, '/'));//array_shift($this->args);
        
        if (array_key_exists(0, $this->args) && !is_numeric($this->args[0])) {
            $this->verb = array_shift($this->args);
        }

        $this->method = $_SERVER['REQUEST_METHOD'];
        if ($this->method == 'POST' && array_key_exists('HTTP_X_HTTP_METHOD', $_SERVER)) {
            if ($_SERVER['HTTP_X_HTTP_METHOD'] == 'DELETE') {
                $this->method = 'DELETE';
            } else if ($_SERVER['HTTP_X_HTTP_METHOD'] == 'PUT') {
                $this->method = 'PUT';
            } else {
                throw new Exception("Unexpected Header");
            }
        }

        switch($this->method) {
        case 'DELETE':
        case 'POST':
            $this->request = $this->_cleanInputs($_POST);
            break;
        case 'GET':
            $this->request = $this->_cleanInputs($_GET);
            break;
        case 'PUT':
            $this->request = $this->_cleanInputs($_GET);
            $this->file = file_get_contents("php://input");
            break;
        default:
            $this->_response('Invalid Method', 405);
            break;
        }
    }

    public function processAPI() {
        if((strpos($this->endpoint, 'finishCases') !== false) 
            || (strpos($this->endpoint, 'noteActionCases') !== false)
            || (strpos($this->endpoint, 'pendingAnotherArea') !== false)
            || (strpos($this->endpoint, 'categorizecase') !== false)) {
            $this->action();
        } else if(strpos($this->endpoint,'logs_cases') !== false) {
            $this->logs_cases();
        } else if(strpos($this->endpoint,'users_keepuserlogged') !== false && strpos($this->endpoint,'processnotificactions') !== false) {
            $this->processnotificactions();
        }else if(strpos($this->endpoint, 'operationaltimes_users') !== false){
            $this->operationaltimes();
        }else if(strpos($this->endpoint, 'callslog') !== false){
            $this->callshistory();
        }else  if(strpos($this->endpoint,'cases_users') !== false) {
            $this->cases_users_22_1_20();
        } else if(strpos($this->endpoint, 'causes') !== false) {
            $this->ending_reasons();
        } else if(strpos($this->endpoint, 'otherArea') !== false) {
            $this->external_areas();
        } else if(strpos($this->endpoint, 'requestCase') !== false) {        
            $this->request_case();
        } else if(strpos($this->endpoint, 'operation_user') !== false) {
            $this->operation_list();
        } else if(strpos($this->endpoint, 'casetype_operation') !== false) {
            $this->case_types_list();
        } else if(strpos($this->endpoint, 'casemanual_operation') !== false) {
            $this->case_register_fields();
        } else if(strpos($this->endpoint, 'dataforclassification') !== false) {
            $this->data_classification();
        } else if(strpos($this->endpoint, 'status_findstatususer') !== false) {
            $this->status_findstatususer();
        } else if(strpos($this->endpoint, 'updatestatuspauseuser') !== false) {    
            $this->updatestatuspauseuser();
        } else if(strpos($this->endpoint, 'operationaltimes_user') !== false) {
            $this->status_user();
        } else if(strpos($this->endpoint, 'updatestatuscontinuouser') !== false) {
            $this->updatestatuscontinuouser();            
        } else if(strpos($this->endpoint, 'event_perentevent') !== false) {
            $this->parent_event();
		}else if(strpos($this->endpoint, 'emailsofcases') !== false) {
            $this->emailsofcases();
		}else if(strpos($this->endpoint, 'cases_email') !== false) {
            $this->email();
		}else if(strpos($this->endpoint, 'datatoresponse') !== false) {
            $this->datatoresponse();		
		}else if(strpos($this->endpoint, 'replymail') !== false) {
            $this->replymail();					
        }else if(strpos($this->endpoint, 'clientgroupedcases') !== false) {
            $this->historyClient();
		}else if(strpos($this->endpoint, 'requirespasswordmaster') !== false) {
            $this->requirespasswordmaster();
		}else if(strpos($this->endpoint, 'delegatecase') !== false) {
            $this->delegatecase();
		}else if(strpos($this->endpoint, 'findcontentsupportbycase') !== false) {
            $this->conteudoapoio();
		}else if(strpos($this->endpoint, 'edit_fields') !== false) {
            $this->editFieldsCaso();	
		}else if(strpos($this->endpoint, 'case_edit') !== false) {
            $this->editCaso();				
        }else if(strpos($this->endpoint, 'cases_findemailgroupforoperationcase') !== false) {
            $this->email_groups();
		}else if(strpos($this->endpoint, 'download') !== false) {
            $this->download();
        }else if(strpos($this->endpoint, 'checklist_action') !== false) {
            $this->checklist();
        }else if(strpos($this->endpoint, 'action_sendemail') !== false) {
            $this->sendEmail();
        }else if(strpos($this->endpoint, 'checklist_savechecklist') !== false) {    
            $this->savechecklist();
        }else if(strpos($this->endpoint, 'questionnaire_case') !== false) {
            $this->questionnaire();
        }else if(strpos($this->endpoint, 'questionnaire_saveissue') !== false) {    
            $this->questionnaireSaveissue();
		}else if(strpos($this->endpoint, 'dynamiclist_user') !== false) {
            $this->dynamic_list();
        } else if ((int)method_exists($this, $this->endpoint) > 0) {
            $this->_response($this->{$this->endpoint}($this->args));
        } else {
            $this->downCheck();
        }
        
    }

    protected function _response($data, $status = 200) {
        header("HTTP/1.1 " . $status . " " . $this->_requestStatus($status));
        return json_encode($data);
    }

    private function _cleanInputs($data) {
        $clean_input = Array();
        if (is_array($data)) {
            foreach ($data as $k => $v) {
                $clean_input[$k] = $this->_cleanInputs($v);
            }
        } else {
            $clean_input = trim(strip_tags($data));
        }
        return $clean_input;
    }

    private function _requestStatus($code) {
        $status = array(  
            200 => 'OK',
            404 => 'Not Found',   
            405 => 'Method Not Allowed',
            500 => 'Internal Server Error',
        ); 
        return ($status[$code])?$status[$code]:$status[500]; 
    }
}


?>