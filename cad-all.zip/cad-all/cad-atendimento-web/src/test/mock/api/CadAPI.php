<?php
require_once 'API.php';
class CadAPI extends API
{
    protected function downCheck() {
        echo $this->_response("No Endpoint: " . $endpoint, 404);
        exit;
    }

    protected function logs_cases() {
        header('Content-Type: application/json');
        $jsonData = file_get_contents('history_194163_1_20.json');
        $jsonData = str_replace(array("\n", "\t", "\r"), '', $jsonData);
        echo $jsonData;
        exit;
    }

    protected function cases_userRequestCase() {
        $this->cases_userRequestCase_22();
    }

    protected function cases_userRequestCase_22() {
        header('Content-Type: application/json');
        $jsonData = file_get_contents('case_22.json');
        $jsonData = str_replace(array("\n", "\t", "\r"), '', $jsonData);
        echo $jsonData;
        exit;
        //return $jsonData;       
        //if ($this->method == 'GET' )
    }

    protected function cases_users_22_1_20() {
        header('Content-Type: application/json');
        $jsonData = file_get_contents('pending_cases.json');
        $jsonData = str_replace(array("\n", "\t", "\r"), '', $jsonData);
        echo $jsonData;
        exit;
    }

    protected function cases_nextCase() {
        $this->cases_nextCase_22();
    }

    protected function cases_nextCase_22() {
        $this->cases_userRequestCase_22();
    }

    protected function request_case() {
        $this->cases_userRequestCase_22();
    }

    protected function users_loggeduser() {
        header('Content-Type: application/json');
        $jsonData = file_get_contents('login.json');
        $jsonData = str_replace(array("\n", "\t", "\r"), '', $jsonData);
        echo $jsonData;
        exit;
    }

    protected function ending_reasons() {
        header('Content-Type: application/json');
        $jsonData = file_get_contents('action_reasons.json');
        $jsonData = str_replace(array("\n", "\t", "\r"), '', $jsonData);
        echo $jsonData;
        exit;
    }

    protected function external_areas() {
        header('Content-Type: application/json');
        $jsonData = file_get_contents('external_areas.json');
        $jsonData = str_replace(array("\n", "\t", "\r"), '', $jsonData);
        echo $jsonData;
        exit;
    }

    protected function action() {
        header("HTTP/1.1 200 OK");
        exit;
    }

    protected function operation_list() {
        header('Content-Type: application/json');
        $jsonData = file_get_contents('operation_list.json');
        $jsonData = str_replace(array("\n", "\t", "\r"), '', $jsonData);
        echo $jsonData;
        exit;
    }

    protected function case_types_list() {
        header('Content-Type: application/json');
        $jsonData = file_get_contents('case_types_list.json');
        $jsonData = str_replace(array("\n", "\t", "\r"), '', $jsonData);
        echo $jsonData;
        exit;
    }
	
	protected function dynamic_list() {
        header('Content-Type: application/json');
        $jsonData = file_get_contents('dynamic_list.json');
        $jsonData = str_replace(array("\n", "\t", "\r"), '', $jsonData);
        echo $jsonData;
        exit;
    }

    protected function operationaltimes(){
        header('Content-Type: application/json');
        $jsonData = file_get_contents('operationaltimes.json');
        $jsonData = str_replace(array("\n", "\t", "\r"), '', $jsonData);
        echo $jsonData;
        exit;
    }

    protected function callshistory(){
        header('Content-Type: application/json');
        $jsonData = file_get_contents('callshistory.json');
        $jsonData = str_replace(array("\n", "\t", "\r"), '', $jsonData);
        echo $jsonData;
        exit;
    }

    protected function case_register_fields() {
        header('Content-Type: application/json');
        $jsonData = file_get_contents('case_register_fields.json');
        $jsonData = str_replace(array("\n", "\t", "\r"), '', $jsonData);
        echo $jsonData;
        exit;
    }

    protected function casemanual_new() {
        header("HTTP/1.1 200 OK");
        exit;
    }

    protected function data_classification() {
        header('Content-Type: application/json');
        $jsonData = file_get_contents('data_classification.json');
        $jsonData = str_replace(array("\n", "\t", "\r"), '', $jsonData);
        echo $jsonData;
        exit;
    }

    protected function parent_event() {
        header('Content-Type: application/json');
        $jsonData = file_get_contents('parent_event.json');
        $jsonData = str_replace(array("\n", "\t", "\r"), '', $jsonData);
        echo $jsonData;
        exit;
    }

    protected function status_findstatususer() {
        header('Content-Type: application/json');
        $jsonData = file_get_contents('pause_statuses.json');
        $jsonData = str_replace(array("\n", "\t", "\r"), '', $jsonData);
        echo $jsonData;
        exit;
    }

    protected function updatestatuspauseuser() {
        header("HTTP/1.1 200 OK");
        exit;
    }

    protected function status_user() {
        header('Content-Type: application/json');
        $jsonData = file_get_contents('working_status.json');
        $jsonData = str_replace(array("\n", "\t", "\r"), '', $jsonData);
        echo $jsonData;
        exit;
    }

    protected function updatestatuscontinuouser() {
        header("HTTP/1.1 200 OK");
        exit;        
    }
	
	protected function emailsofcases() {
       header('Content-Type: application/json');
       $jsonData = file_get_contents('email.json');
       $jsonData = str_replace(array("\n", "\t", "\r"), '', $jsonData);
       echo $jsonData;
       exit;      
    }
	
	protected function email() {
       header('Content-Type: application/json');
       $jsonData = file_get_contents('email_detalhe.json');
       $jsonData = str_replace(array("\n", "\t", "\r"), '', $jsonData);
       echo $jsonData;
       exit;      
    }

    protected function historyClient() {
       header('Content-Type: application/json');
       $jsonData = file_get_contents('history_client.json');
       $jsonData = str_replace(array("\n", "\t", "\r"), '', $jsonData);
       echo $jsonData;
       exit;      
    }

    protected function processnotificactions() {        
        header('Content-Type: application/json');
        $jsonData = file_get_contents('processnotificactions.json');
        
        $objBundle = json_decode($jsonData);    
        $list = $objBundle->{'notificacaoList'};
        $notification = $list[array_rand($list)];
        $objBundle->{'notificacaoList'} = array($notification);
        $jsonData = json_encode($objBundle);

        $jsonData = str_replace(array("\n", "\t", "\r"), '', $jsonData);
        echo $jsonData;
        exit;
    }
   
   protected function requirespasswordmaster() {        
        header('Content-Type: application/json');
        $jsonData = file_get_contents('booleanto.json');
        $jsonData = str_replace(array("\n", "\t", "\r"), '', $jsonData);
        echo $jsonData;
        exit;
    }
	
	protected function delegatecase() {        
        header('Content-Type: application/json');
        exit;
    }
	
	protected function conteudoapoio() {        
        header('Content-Type: application/json');
        $jsonData = file_get_contents('conteudoapoio.json');
        $jsonData = str_replace(array("\n", "\t", "\r"), '', $jsonData);
        echo $jsonData;
        exit;
	}

    protected function email_groups() {
        header('Content-Type: application/json');
        $jsonData = file_get_contents('email_groups.json');
        $jsonData = str_replace(array("\n", "\t", "\r"), '', $jsonData);
        echo $jsonData;
        exit;
    }
	
    protected function download() {
        header('Content-Type: application/json');
        exit;
    }

    protected function checklist() {
        header('Content-Type: application/json');
        $jsonData = file_get_contents('checklist.json');
        $jsonData = str_replace(array("\n", "\t", "\r"), '', $jsonData);
        echo $jsonData;
        exit;
    }

    protected function sendEmail() {
        header('Content-Type: application/json');
        exit;
    }

    protected function savechecklist() {
        header('Content-Type: application/json');
        exit;
    }

    protected function questionnaire() {
        header('Content-Type: application/json');
        $jsonData = file_get_contents('questionnaire.json');
        $jsonData = str_replace(array("\n", "\t", "\r"), '', $jsonData);
        echo $jsonData;
        exit;
    }
	
	protected function editFieldsCaso() {
        header('Content-Type: application/json');
        $jsonData = file_get_contents('campos_editar_caso.json');
        $jsonData = str_replace(array("\n", "\t", "\r"), '', $jsonData);
        echo $jsonData;
        exit;
    }	
	
	protected function editCaso() {
        header("HTTP/1.1 200 OK");
        exit;
    }	
	
    protected function questionnaireSaveissue()	{        
        header("HTTP/1.1 200 OK");
        exit;
    }
	
	protected function datatoresponse()	{        
       header('Content-Type: application/json');
        $jsonData = file_get_contents('datatoresponse.json');
        $jsonData = str_replace(array("\n", "\t", "\r"), '', $jsonData);
        echo $jsonData;
        exit;
    }
	
	protected function replymail()	{        
        header("HTTP/1.1 200 OK");
        exit;
    }
}
?>