<?php 
header('Content-Type: application/json');

$lang = $_REQUEST[lang];
$cadBundle = file_get_contents('../cad_' . $lang . '.json');
$bundle = sprintf('{ "bundle": {%s}}',$cadBundle);

if(file_exists('../sgm_' . $lang . '.json')) {
    $sgmBundle = file_get_contents('../sgm_' . $lang . '.json');
    $sgmBundle = str_replace('"sgm": ', '', $sgmBundle);

    $objBundle = json_decode($bundle);    
    $objBundle->{'bundle'}->sgm = json_decode($sgmBundle);
    $bundle = json_encode($objBundle);
}

$bundle = str_replace(array("\n", "\t", "\r"), '', $bundle);
echo $bundle

?>