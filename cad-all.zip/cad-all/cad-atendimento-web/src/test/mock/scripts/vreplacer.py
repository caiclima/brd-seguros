
import sys

def main(argv):
    infile = open(argv[0])
    outfile = open(argv[1], 'w')

    for line in infile:
        line = line.replace(argv[2], argv[3])
        outfile.write(line)

    infile.close()
    outfile.close()

if __name__ == "__main__":
    main(sys.argv[1:])

