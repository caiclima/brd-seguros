package br.com.callink.cad.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import br.com.callink.cad.to.AssociaOperacaoJobTO;
import br.com.callink.cad.to.EmailModeloTO;
import br.com.callink.cad.to.JobTO;

public class AssociaOperacaoJobDAO extends GenericDAO {

	private Logger logger = Logger.getLogger(AssociaOperacaoJobDAO.class.getName());
	
	public List<AssociaOperacaoJobTO> findByOperacao(Integer idOperacao) throws Exception {
		try {
			List<AssociaOperacaoJobTO> list = new ArrayList<AssociaOperacaoJobTO>();
			
			StringBuilder sql = new StringBuilder().append(SELECT)
	        	.append(AssociaOperacaoJobTO.getSqlCamposAssociaOperacaoJob())
	        	.append(" , ").append(JobTO.getSqlColuns())
	        	.append(FROM)
	            .append(AssociaOperacaoJobTO.getSqlFromAssociaOperacaoJob())
	            .append(INNER_JOIN).append(" TB_JOB Job WITH (NOLOCK) ")
	            .append(" ON Job.id_job = AssociaOperacaoJob.id_job ")
	            .append(WHERE)
	            .append(" AssociaOperacaoJob.id_operacao = ? ");

			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ps.setInt(1, idOperacao);

			ResultSet rs = ps.executeQuery();

			if (rs != null) {
				while (rs.next()) {
					AssociaOperacaoJobTO associaOperacaoJobTO = AssociaOperacaoJobTO.getAssociaOperacaoJobByResultSet(rs);
					JobTO jobTO = JobTO.getJobTOByResultSet(rs);
					associaOperacaoJobTO.setJobTO(jobTO);
					list.add(associaOperacaoJobTO);
				}
			}
			return list;
		} catch (Exception e) {
			logger.severe("Erro ao buscar jobs associadas para a operação: " + idOperacao + ". " + e.getMessage());
			throw e;
		} finally {
			super.closeConnection();
		}
	}
	
}
