package br.com.callink.cad.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import br.com.callink.cad.to.BufferFilaTO;
import br.com.callink.cad.to.CasoTO;
import br.com.callink.cad.to.ConfiguracaoFilaTO;

public class AtualizaBufferFilaDAO extends GenericDAO {

	private Logger logger = Logger.getLogger(AtualizaBufferFilaDAO.class.getName());
	
	public List<CasoTO> buscaCasosOrdernadosPorFilaSemUsuario(String sqlOrder, ConfiguracaoFilaTO confFila, Integer quantidadeCasos) throws Exception {
		StringBuilder sql = new StringBuilder();
		try {
			final int ROWS = quantidadeCasos == null || quantidadeCasos.equals(0) ? 3 : quantidadeCasos;

			List<CasoTO> toReturn = new ArrayList<CasoTO>();
			
			sql.append(" select TOP  ");
			sql.append(ROWS);
			
			sql.append(CasoTO.getSqlColuns());
			
			sql.append(" from tb_caso Caso with(nolock) INNER JOIN tb_fila_classificacao_caso f with(nolock) on f.id_caso = Caso.id_caso ");
			sql.append(" LEFT OUTER JOIN tb_caso_detalhe casodetalhe with(nolock) on Caso.id_caso = casodetalhe.id_caso ");
			sql.append(" where f.id_configuracao_fila = ? ");
			sql.append(" and Caso.id_configuracao_fila = f.id_configuracao_fila ");
			sql.append(" and (Caso.FLAG_RECLASSIFICA_REABERTURA = 0 or Caso.FLAG_RECLASSIFICA_REABERTURA is null) ");
			sql.append(" and Caso.id_usuario is null and Caso.flag_finalizado = 0");
			sql.append(" and Caso.id_usuario_sugerido is null");
			sql.append(" and Caso.id_caso not in (SELECT ag.id_caso FROM tb_agendamento ag with(nolock) where ag.flag_ativo = 1 ) ");
			sql.append(" and Caso.id_caso not in ( Select fa.id_caso from tb_caso_fila_atendimento fa with(nolock) ) ");
			sql.append(" order by ");

			if (sqlOrder != null && !sqlOrder.isEmpty()) {
				sql.append(sqlOrder);
			} else {
				sql.append(" caso.data_abertura asc ");
			}

			PreparedStatement ps = super.getPreparedStatement(sql.toString(), ROWS);
			ps.setInt(1, confFila.getIdConfiguracaoFila());
			ResultSet resultSet = ps.executeQuery();

			if (resultSet != null) {
				while (resultSet.next()) {
					toReturn.add(CasoTO.getCasoTOByResultSet(resultSet));
				}
			}
			return toReturn;
		} catch (Exception e) {
			StringBuilder str = new StringBuilder();
			
			str.append("Erro ao buscar casos ordenados pela fila. SQL: ").append(sql.toString());
			
			logger.log(Level.SEVERE, str.toString());
			
			throw e;
		} finally {
			super.closeConnection();
		}
	}

	public List<ConfiguracaoFilaTO> buscaFilaAtivaPorPrioridadeEOperacao(Integer idOperacao) throws Exception {
		StringBuilder sql = new StringBuilder();
		try {
			List<ConfiguracaoFilaTO> toReturn = new ArrayList<ConfiguracaoFilaTO>();
			
			sql.append("SELECT conF.nome as 'conF.nome', ");
			sql.append("conF.sql_order as 'conF.sql_order', ");
			sql.append("conF.id_configuracao_fila as 'conF.id_configuracao_fila' ");
			sql.append("FROM tb_configuracao_fila conF with(nolock) ");
			sql.append("WHERE conF.flag_ativo = 1 ");
			sql.append(" AND conF.id_operacao =").append(idOperacao);
			sql.append(" AND conF.prioridade is not null ");
			sql.append(" ORDER BY conF.id_operacao, conF.prioridade ");

			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ResultSet resultSet = ps.executeQuery();

			if (resultSet != null) {
				while (resultSet.next()) {
					ConfiguracaoFilaTO to = new ConfiguracaoFilaTO();
					to.setIdConfiguracaoFila((Integer) resultSet.getObject("conF.id_configuracao_fila"));
					to.setNome(resultSet.getString("conF.nome"));
					to.setSqlOrder(resultSet.getString("conF.sql_order"));
					toReturn.add(to);
				}
			}
			return toReturn;
		} catch (Exception e) {
			StringBuilder str = new StringBuilder();
			
			str.append("Erro ao buscar filas ativas por prioridade. SQL: ").append(sql.toString())
			.append(" - Operacao: ").append(idOperacao);
			
			logger.log(Level.SEVERE, str.toString());
			
			throw e;
		} finally {
			super.closeConnection();
		}
	}

	public List<BufferFilaTO> buscaFilasNoBuffer(Integer idOperacao) throws Exception {
		StringBuilder sql = new StringBuilder();
		try {
			List<BufferFilaTO> toReturn = new ArrayList<BufferFilaTO>();
			sql.append("SELECT conF.id_fila as 'conF.idFila', count(*) as 'conF.quantidade'");
			sql.append(" FROM tb_caso_fila_atendimento conF with(nolock) ");
			sql.append(" WHERE conF.id_operacao =").append(idOperacao);
			sql.append(" group by conF.id_fila ");

			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ResultSet resultSet = ps.executeQuery();

			if (resultSet != null) {
				while (resultSet.next()) {
					BufferFilaTO to = new BufferFilaTO();
					to.setIdFila((Integer) resultSet.getObject("conF.idFila"));
					to.setQuantidade((Integer) resultSet.getObject("conF.quantidade"));
					toReturn.add(to);
				}
			}
			return toReturn;
		} catch (Exception e) {
			StringBuilder str = new StringBuilder();
			
			str.append("Erro ao buscar filas no buffer. SQL: ").append(sql.toString())
			.append(" - Operacao: ").append(idOperacao);
			
			logger.log(Level.SEVERE, str.toString());
			
			throw e;
		} finally {
			super.closeConnection();
		}
	}

	public void insereCasoBuffer(List<CasoTO> inserts) throws Exception {
		try {
			for (CasoTO insert : inserts) {
				try {
					DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					StringBuilder sql = new StringBuilder().append("INSERT INTO tb_caso_fila_atendimento ")
							.append(" ( id_caso, id_fila, flag_entregue, id_operacao , percentual_sla, data_cadastro ) ").append(" VALUES (?, ?, ?, ?, ?, '")
							.append(df.format(getDataBanco())).append("') ");
	
					PreparedStatement stmt = super.getPreparedStatement(sql.toString());
					stmt.setInt(1, insert.getIdCaso());
					stmt.setInt(2, insert.getIdConfiguracaoFila());
					stmt.setBoolean(3, Boolean.FALSE);
					stmt.setInt(4, insert.getIdOperacao());
					stmt.setDouble(5, insert.getPorcentagemSla());
					stmt.executeUpdate();
				} catch (Exception e) {
					StringBuilder str = new StringBuilder();
					
					str.append("Erro ao inserir caso no buffer. Caso: ").append(insert.getIdCaso())
					.append(" - Configuracao fila: ").append(insert.getIdConfiguracaoFila())
					.append(" - Operacao: ").append(insert.getIdOperacao());
					
					logger.log(Level.SEVERE, str.toString());
					
					throw e;
				}
			}
		} finally {
			super.closeConnection();
		}
	}

	public void removeCasosEntregues(Integer idOperacao) throws Exception {
		Calendar data = new GregorianCalendar();
		data.setTime(getDataBanco());
		data.add(Calendar.SECOND, -10);

		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		try {
			StringBuilder sql = new StringBuilder().append("delete from tb_caso_fila_atendimento where id_operacao = ? and data_entregue < ? ");

			PreparedStatement stmt = super.getPreparedStatement(sql.toString());
			stmt.setInt(1, idOperacao);
			stmt.setString(2, df.format(data.getTime()));

			stmt.executeUpdate();

		} catch (Exception e) {
			StringBuilder str = new StringBuilder();
			str.append("Erro ao remover casos entregues. Operacao: ").
			append(idOperacao).append(" - Data Entregue menor que: ").
			append(df.format(data.getTime()));
			
			logger.log(Level.SEVERE, str.toString());
			
			throw e;
		} finally {
			super.closeConnection();
		}
	}

	public void removeCasosNaoExistentes() throws Exception {
		StringBuilder sql = new StringBuilder();
		try {
			
			sql.append("delete ");
			sql.append("from tb_caso_fila_atendimento ");
			sql.append("where id_caso_fila_atendimento in ( ");
			sql.append("select id_caso_fila_atendimento ");
			sql.append("from tb_caso_fila_atendimento buffer ");
			sql.append("left join tb_caso caso on buffer.id_caso = caso.id_caso ");
			sql.append("where caso.id_caso is null ");
			sql.append(") ");
			
			PreparedStatement stmt = super.getPreparedStatement(sql.toString());
			stmt.executeUpdate();
		} catch (Exception e) {
			StringBuilder str = new StringBuilder();
			str.append("Erro ao remover casos não existentes. SQL: ").
			append(sql.toString());
			
			logger.log(Level.SEVERE, str.toString());
			
			throw e;
		} finally {
			super.closeConnection();
		}
	}
}