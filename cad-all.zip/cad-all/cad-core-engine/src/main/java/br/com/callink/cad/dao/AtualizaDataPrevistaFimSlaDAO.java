package br.com.callink.cad.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import br.com.callink.cad.to.CasoTO;
import br.com.callink.cad.to.ConfiguracaoFilaTO;
import br.com.callink.cad.to.SlaFilaTO;
import br.com.callink.cad.util.HintNumberRows;

public class AtualizaDataPrevistaFimSlaDAO extends GenericDAO {

	private Logger logger = Logger.getLogger(AtualizaDataPrevistaFimSlaDAO.class.getName());
	
	public List<CasoTO> buscaCasosEnfileirados(Integer idOperacao) throws Exception {
		StringBuilder sql = new StringBuilder();
		try {
			sql.append(SELECT);
			sql.append(CasoTO.getSqlColuns());
			sql.append(CasoTO.getSqlFrom());
			sql.append(WHERE);
			sql.append("Caso.id_operacao = ? ");
			sql.append("AND Caso.id_configuracao_fila is not null and Caso.id_sla_fila is not null ");
			sql.append("AND Caso.data_prevista_fim_sla is null ");

			PreparedStatement stmt = super.getPreparedStatement(sql.toString(), HintNumberRows.ROWS_CASO.getRows());
			stmt.setInt(1, idOperacao);
			ResultSet resultSet = stmt.executeQuery();
			List<CasoTO> listRows = new ArrayList<CasoTO>();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					listRows.add(CasoTO.getCasoTOByResultSet(resultSet));
				}
			}

			return listRows;
		} catch (Exception e) {
			StringBuilder str = new StringBuilder();
			
			str.append("Erro ao buscar casos enfileirados. SQL: ").append(sql.toString()).append(" - Operacao: ").append(idOperacao);
			
			logger.log(Level.SEVERE, str.toString());
			
			throw e;
		} finally {
			super.closeConnection();
		}
	}

	public void atualizaDataPrevistaFimSlaEDataAbertura(CasoTO casoTO) throws Exception {
		try {
			PreparedStatement ps = super.getPreparedStatement("update tb_caso set data_abertura = ?, data_prevista_fim_sla = ? WHERE id_caso = ? ");

			ps.setTimestamp(1, new Timestamp(casoTO.getDataAbertura().getTime()));
			
			if (casoTO.getDataPrevistaFimSla() != null) {
				ps.setTimestamp(2, new Timestamp(casoTO.getDataPrevistaFimSla().getTime()));
			} else {
				ps.setNull(2, Types.NULL);
			}
			
			ps.setInt(3, casoTO.getIdCaso());
			ps.executeUpdate();
		} catch (Exception e) {
			StringBuilder str = new StringBuilder();
			
			str.append("Erro ao atualizar data prevista fim sla. Data: ").append(casoTO.getDataAbertura()).append(" - Caso: ").append(casoTO.getIdCaso());
			if (casoTO.getDataPrevistaFimSla() != null) {
				str.append(" - Data Fim SLA: ").append(casoTO.getDataPrevistaFimSla());
			} else {
				str.append(" - Data Fim SLA null ");
			}
			
			logger.log(Level.SEVERE, str.toString());
			
			throw e;
		} finally {
			super.closeConnection();
		}		
	}

	public SlaFilaTO findSlaFilaByConfFilaAndDataFimNull(Integer idConfiguracaoFila) throws Exception {
		StringBuilder sql = new StringBuilder();
		try {
			SlaFilaTO to = null;
					sql.append(SELECT)
					.append(SlaFilaTO.getSqlCamposSlaFilaTO())
					.append(FROM)
					.append(ConfiguracaoFilaTO.getSqlFromConfiguracaoFila())
					.append(INNER_JOIN).append(SlaFilaTO.getSqlFromSlaFilaTO())
					.append(" ON SlaFilaTO.ID_SLA_FILA = ConfiguracaoFila.ID_SLA_FILA ")
					.append(WHERE)
					.append("SlaFilaTO.DATA_FIM IS NULL ")
					.append(" AND ConfiguracaoFila.ID_CONFIGURACAO_FILA = ? ");

			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ps.setInt(1, idConfiguracaoFila);
			ResultSet rs = ps.executeQuery();

			if (rs != null && rs.next()) {
				to = SlaFilaTO.getSlaFilaTOByResultSet(rs);
			}

			return to;
		} catch (Exception e) {
			StringBuilder str = new StringBuilder();
			
			str.append("Erro ao buscar sla fila. SQL: ").append(sql.toString()).append(" - Id Configuracao FIla: ").append(idConfiguracaoFila);
			
			logger.log(Level.SEVERE, str.toString());
			
			throw e;
		} finally {
			super.closeConnection();
		}
	}
}
