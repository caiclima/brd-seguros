package br.com.callink.cad.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import br.com.callink.cad.to.CabMetaFullTO;
import br.com.callink.cad.to.CabUphTO;
import br.com.callink.cad.to.ConfiguracaoFilaTO;
import br.com.callink.cad.to.GoalFinalTO;
import br.com.callink.cad.to.MetaUphTO;
import br.com.callink.cad.to.StatusUsuarioTO;
import br.com.callink.cad.to.UsuarioTO;
import br.com.callink.cad.util.DateUtils;
import br.com.callink.cad.util.StringUtils;

public class CalculaMetasDAO extends GenericDAO {

	public List<GoalFinalTO> buscaGoalsAtivos(Integer idOperacao) throws Exception {
		try {
			List<GoalFinalTO> toReturn = new ArrayList<GoalFinalTO>();
			StringBuilder sql = new StringBuilder().append(SELECT)
					.append(" goal.id_goal_final as 'goal.id_goal_final', ")
					.append(" goal.goal_inicial as 'goal.goal_inicial', ")
					.append(" goal.goal_final as 'goal.goal_final', ")
					.append(" goal.nome_imagem as 'goal.nome_imagem' ")
					.append(FROM)
					.append(" tb_goal_final goal with(nolock) ")
					.append(WHERE)
					.append(" goal.data_final is null ")
					.append(" and goal.id_operacao = ? ")
					.append(" and goal.flag_ativo = 1 ")
					.append(" ORDER BY goal.goal_inicial ");
		
			PreparedStatement stmt = super.getPreparedStatement(sql.toString());
			stmt.setInt(1, idOperacao);
			ResultSet resultSet = stmt.executeQuery();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					GoalFinalTO to = new GoalFinalTO();
					to.setIdGoalFinal(resultSet.getInt("goal.id_goal_final"));
					to.setGoalInicial(resultSet.getDouble("goal.goal_inicial"));
					to.setGoalFinal(resultSet.getDouble("goal.goal_final"));
					to.setNomeImagem(resultSet.getString("goal.nome_imagem"));
					toReturn.add(to);
				}
			}
			return toReturn;
		} finally {
			super.closeConnection();
		}
	}

	public List<Integer> findEquipeAtivos(Integer idOperacao) throws Exception {
		try {
			List<Integer> toReturn = new ArrayList<Integer>();
			StringBuilder sql = new StringBuilder()
					.append(SELECT)
					.append(" equipe.id_equipe as 'equipe.id_equipe' ")
					.append(FROM)
					.append(" tb_equipe equipe with(nolock) ")
					.append(WHERE)
					.append(" equipe.flag_ativo = 1 ")
					.append(" AND EXISTS (select 1 from tb_associa_operacao_equipe aoe with(nolock) where aoe.id_equipe = equipe.id_equipe and aoe.id_operacao = ? )");
			
			PreparedStatement stmt = super.getPreparedStatement(sql.toString());
			stmt.setInt(1, idOperacao);
			ResultSet resultSet = stmt.executeQuery();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					toReturn.add((Integer) resultSet.getObject("equipe.id_equipe"));
				}
			}
			return toReturn;
		} finally {
			super.closeConnection();
		}
	}

	public List<UsuarioTO> buscaUsuariosPorEquipe(Integer idEquipe, Integer idOperacao) throws Exception {
		try {
			List<UsuarioTO> toReturn = new ArrayList<UsuarioTO>();
			StringBuilder sql = new StringBuilder()
					.append(SELECT)
					.append(" usuario.id_usuario as 'usuario.id_usuario', ")
					.append(" usuario.login as 'usuario.login' ")
					.append(FROM)
					.append(" tb_usuario usuario with(nolock) ")
					.append(WHERE)
					.append(" usuario.id_equipe = ? ")
					.append(" and exists (select 1 from tb_operacao_usuario ou with(nolock) where usuario.id_usuario = ou.id_usuario and ou.flag_operacao_principal = 1 and ou.id_operacao = ?) ");
		
			PreparedStatement stmt = super.getPreparedStatement(sql.toString());
			stmt.setInt(1, idEquipe);
			stmt.setInt(2, idOperacao);
			ResultSet resultSet = stmt.executeQuery();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					UsuarioTO to = new UsuarioTO();
					to.setIdUsuario((Integer) resultSet.getObject("usuario.id_usuario"));
					to.setLogin(resultSet.getString("usuario.login"));
					toReturn.add(to);
				}
			}
			return toReturn;
		} finally {
			super.closeConnection();
		}
	}

	public List<Integer> findFilasByEquipeAndOperacao(Integer idEquipe, Integer idOperacao) throws Exception {
		try {
			List<Integer> toReturn = new ArrayList<Integer>();
			StringBuilder sql = new StringBuilder()
					.append(SELECT)
					.append(" eqf.id_configuracao_fila as 'eqf.id_configuracao_fila' ")
					.append(FROM)
					.append(" tb_equipe_fila eqf with(nolock) ")
					.append(INNER_JOIN)
					.append(" tb_equipe equipe with(nolock) ")
					.append(" ON eqf.id_equipe = equipe.id_equipe ")
					.append(INNER_JOIN)
					.append(" tb_configuracao_fila conF with(nolock) ")
					.append(" ON eqf.id_configuracao_fila = conF.id_configuracao_fila  ")
					.append(WHERE)
					.append(" eqf.id_equipe = ? ")
					.append(" AND conF.id_operacao = ? and equipe.flag_ativo = 1 and conF.flag_ativo = 1 ");
			
			PreparedStatement stmt = super.getPreparedStatement(sql.toString());
			stmt.setInt(1, idEquipe);
			stmt.setInt(2, idOperacao);
			ResultSet resultSet = stmt.executeQuery();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					toReturn.add((Integer) resultSet.getObject("eqf.id_configuracao_fila"));
				}
			}
			return toReturn;
		} finally {
			super.closeConnection();
		}
	}

	public List<StatusUsuarioTO> buscaStatusUsuarioByUserEquipe(Integer idConfigFilaEquipeFila, Integer idEquipe, UsuarioTO usuario, Date dataInicial,
			Date dataFinal) throws Exception {
		try {
			List<StatusUsuarioTO> toReturn = new ArrayList<StatusUsuarioTO>();
			int index = 0;

			StringBuilder sql = new StringBuilder(SELECT)
					.append(" stus.data_inicio as 'stus.data_inicio', ")
					.append(" stus.data_fim as 'stus.data_fim' ")
					.append(FROM)
					.append(" tb_status_usuario stus with(nolock) ")
					.append(WHERE)
					.append(" stus.data_inicio BETWEEN ? AND ? ");

			if (idConfigFilaEquipeFila != null) {
				sql.append(" AND stus.id_configuracao_fila = ? ");
			}
			if (idEquipe != null) {
				sql.append(" AND stus.id_equipe = ? ");
			}
			if (usuario != null && usuario.getIdUsuario() != null) {
				sql.append(" AND stus.id_usuario = ? ");
			}

			PreparedStatement stmt = super.getPreparedStatement(sql.toString());
			stmt.setString(++index, DateUtils.convertDateStringWithHour(dataInicial));
			stmt.setString(++index, DateUtils.convertDateStringWithHour(dataFinal));

			if (idConfigFilaEquipeFila != null) {
				stmt.setInt(++index, idConfigFilaEquipeFila);
			}
			if (idEquipe != null) {
				stmt.setInt(++index, idEquipe);
			}
			if (usuario != null && usuario.getIdUsuario() != null) {
				stmt.setInt(++index, usuario.getIdUsuario());
			}
			ResultSet resultSet = stmt.executeQuery();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					StatusUsuarioTO to = new StatusUsuarioTO();
					to.setDataInicio(resultSet.getTimestamp("stus.data_inicio") != null ? new Date(resultSet.getTimestamp("stus.data_inicio").getTime()) : null);
					to.setDataFim(resultSet.getTimestamp("stus.data_fim") != null ? new Date(resultSet.getTimestamp("stus.data_fim").getTime()) : null);
					toReturn.add(to);
				}
			}
			return toReturn;
		} finally {
			super.closeConnection();
		}
	}

	public Integer quantidadeCasosFechados(Integer idUsuario, Integer idConfigFilaEquipeFila, Date dataInicial, Date dataFinal) throws Exception {
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		Integer casos = 0;
		int index = 0;
		
		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" select count(*) casosFechados from tb_caso with(nolock) where flag_finalizado = 1 ");

			if (idUsuario != null && idUsuario != 0) {
				sql.append(" and id_usuario = ? ");
			}
			if (idConfigFilaEquipeFila != null && idConfigFilaEquipeFila != 0) {
				sql.append(" and id_configuracao_fila = ? ");
			}
			if (dataInicial != null && dataFinal != null) {
				sql.append(" and data_encerramento > ? and data_encerramento < ? ");
			}

			stmt = getPreparedStatement(sql.toString());

			if (idUsuario != null && idUsuario != 0) {
				stmt.setInt(++index, idUsuario);
			}
			if (idConfigFilaEquipeFila != null && idConfigFilaEquipeFila != 0) {
				stmt.setInt(++index, idConfigFilaEquipeFila);
			}
			if (dataInicial != null && dataFinal != null) {
				stmt.setTimestamp(++index, new java.sql.Timestamp(dataInicial.getTime()));
				stmt.setTimestamp(++index, new java.sql.Timestamp(dataFinal.getTime()));
			}

			stmt.execute();
			resultSet = stmt.getResultSet();

			if (resultSet != null) {
				while (resultSet.next()) {
					casos = resultSet.getInt("casosFechados");
				}
			}
			return casos;
		} finally {
			super.closeConnection();
		}
	}

	public CabUphTO findUltimaMetaConfigura(Integer idConfigFilaEquipeFila) throws Exception {
		try {
			CabUphTO toReturn = null;

			StringBuilder sql = new StringBuilder()
					.append(SELECT).append(" cabuph.id_cab_uph as 'cabuph.id_cab_uph', ")
					.append(" cabuph.meta as 'cabuph.meta' ")
					.append(FROM)
					.append(" tb_cab_uph cabuph with(nolock) ")
					.append(" WHERE cabuph.ID_CONFIGURACAO_FILA = ? ")
					.append(" AND cabuph.DATA_FINAL is null ")
					.append(" ORDER BY CabUph.DATA_INICIAL DESC ");
			
			PreparedStatement stmt = getPreparedStatement(sql.toString());
			stmt.setInt(1, idConfigFilaEquipeFila);
			ResultSet resultSet = stmt.executeQuery();
			
			if (resultSet != null && resultSet.next()) {
				toReturn = new CabUphTO();
				toReturn.setIdCabUph((Integer) resultSet.getObject("cabuph.id_cab_uph"));
				toReturn.setMeta(resultSet.getDouble("cabuph.meta"));
			}

			return toReturn;
			
		} finally {
			super.closeConnection();
		}
	}

	public ConfiguracaoFilaTO findConfigFilaByPk(Integer idConfigFilaEquipeFila) throws Exception {
		try {
			ConfiguracaoFilaTO toReturn = null;
			
			StringBuilder sql = new StringBuilder()
					.append(SELECT)
					.append(" conF.id_configuracao_fila as 'conF.id_configuracao_fila',")
					.append(" conF.id_operacao as 'conF.id_operacao', ")
					.append(" conF.nome as 'conF.nome' ")
					.append(FROM)
					.append(" tb_configuracao_fila conF with(nolock) ")
					.append(" WHERE conF.id_configuracao_fila = ? ");
			
			PreparedStatement stmt = getPreparedStatement(sql.toString());
			stmt.setInt(1, idConfigFilaEquipeFila);
			ResultSet resultSet = stmt.executeQuery();
			
			if (resultSet != null && resultSet.next()) {
				toReturn = new ConfiguracaoFilaTO();
				toReturn.setIdConfiguracaoFila((Integer) resultSet.getObject("conF.id_configuracao_fila"));
				toReturn.setIdOperacao((Integer) resultSet.getObject("conF.id_operacao"));
				toReturn.setNome(resultSet.getString("conF.nome"));
			}
			return toReturn;
			
		} finally {
			super.closeConnection();
		}
	}

	public List<MetaUphTO> findMetaByCabUph(CabUphTO cab) throws Exception {
		try {
			List<MetaUphTO> toReturn = new ArrayList<MetaUphTO>();
			
			StringBuilder sql = new StringBuilder(SELECT)
					.append(" metauph.id_meta_uph as 'metauph.id_meta_uph', ")
					.append(" metauph.id_cab_uph as 'metauph.id_cab_uph', ")
					.append(" metauph.meta as 'metauph.meta', ")
					.append(" metauph.descricao as 'metauph.descricao', ")
					.append(" metauph.nome_imagem as 'metauph.nome_imagem', ")
					.append(" metauph.goal as 'metauph.goal' ")
					.append(FROM)
					.append(" tb_meta_uph metauph with(nolock) ")
					.append(WHERE)
					.append(" metauph.id_cab_uph = ? ")
					.append(" ORDER BY metauph.descricao ");
			
			PreparedStatement stmt = getPreparedStatement(sql.toString());
			stmt.setInt(1, cab.getIdCabUph());
			ResultSet resultSet = stmt.executeQuery();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					MetaUphTO to = new MetaUphTO();
					to.setIdMetaUph((Integer) resultSet.getObject("metauph.id_meta_uph"));
					to.setIdCabUph((Integer) resultSet.getObject("metauph.id_cab_uph"));
					to.setMeta(resultSet.getDouble("metauph.meta"));
					to.setDescricao(resultSet.getString("metauph.descricao"));
					to.setNomeImagem(resultSet.getString("metauph.nome_imagem"));
					to.setGoal((Integer) resultSet.getObject("metauph.goal"));
					toReturn.add(to);
				}
			}
			return toReturn;
			
		} finally {
			super.closeConnection();
		}
	}

	public void insereCabMeta(List<CabMetaFullTO> inserts) throws Exception {
		try {
			for (CabMetaFullTO insert : inserts) {
				StringBuilder sql = new StringBuilder()
						.append("INSERT INTO tb_cab_meta ")
						.append("(media_ponderada_final, id_usuario, image_g_final, id_configuracao_fila, tempo_total_equipe, ")
						.append("casos_fechados, uph_equipe, nome_configuracao_fila, goal_final, imagem_goal_final, indice_goal, ")
						.append("login, meta, uph, flag_totalizador, id_operacao) ")
						.append("VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ");
				
				PreparedStatement stmt = super.getPreparedStatement(sql.toString());
				stmt.setDouble(1, insert.getMediaPonderadaFinal());
				stmt.setInt(2, insert.getIdUsuario());
				
				if (insert.getImageGFinal() != null) {
					stmt.setString(3, insert.getImageGFinal());
				} else {
					stmt.setNull(3, Types.NULL);
				}
				stmt.setInt(4, insert.getIdConfiguracaoFila());
				stmt.setDouble(5, insert.getTempoTotalEquipe());
				stmt.setInt(6, insert.getCasosFechados());
				stmt.setDouble(7, insert.getUphEquipe());
				if (insert.getNomeConfiguracaoFila() != null) {
					stmt.setString(8, insert.getNomeConfiguracaoFila());
				} else {
					stmt.setNull(8, Types.NULL);
				}
				stmt.setDouble(9, insert.getGoalFinal());
				if (insert.getImagemGoalFinal() != null) {
					stmt.setString(10, insert.getImagemGoalFinal());
				} else {
					stmt.setNull(10, Types.NULL);
				}
				stmt.setDouble(11, insert.getIndiceGoal());
				if (insert.getLogin() != null) {
					stmt.setString(12, insert.getLogin());
				} else {
					stmt.setNull(12, Types.NULL);
				}
				stmt.setDouble(13, insert.getMeta());
				stmt.setDouble(14, insert.getUph());
				stmt.setInt(15, insert.getFlagTotalizador() == true ? 1 : 0);
				stmt.setInt(16, insert.getIdOperacao());
				stmt.executeUpdate();
			}
		} finally {
			super.closeConnection();
		}
	}

	public void deleteCabMetaPorOperacao(Integer idOperacao) throws Exception {
		try {
			StringBuilder sql = new StringBuilder().append("delete from tb_cab_meta where id_operacao = ?");
			PreparedStatement stmt = super.getPreparedStatement(sql.toString());
			stmt.setInt(1, idOperacao);
			stmt.executeUpdate();
			
		} finally {
			super.closeConnection();
		}
	}

	public List<CabMetaFullTO> buscaPorUsuarios(List<Integer> listaUsuariosId) throws Exception {
		try {
			List<CabMetaFullTO> toReturn = null;
			if (listaUsuariosId != null && listaUsuariosId.size() > 0) {
				toReturn = new ArrayList<CabMetaFullTO>();
				StringBuilder sql = new StringBuilder()
						.append(SELECT)
						.append(" cabmeta.media_ponderada_final as 'cabmeta.media_ponderada_final', ")
						.append(" cabmeta.id_usuario as 'cabmeta.id_usuario', ")
						.append(" cabmeta.image_g_final as 'cabmeta.image_g_final', ")
						.append(" cabmeta.id_configuracao_fila as 'cabmeta.id_configuracao_fila', ")
						.append(" cabmeta.tempo_total_equipe as 'cabmeta.tempo_total_equipe', ")
						.append(" cabmeta.casos_fechados as 'cabmeta.casos_fechados', ")
						.append(" cabmeta.uph_equipe as 'cabmeta.uph_equipe', ")
						.append(" cabmeta.nome_configuracao_fila as 'cabmeta.nome_configuracao_fila', ")
						.append(" cabmeta.goal_final as 'cabmeta.goal_final', ")
						.append(" cabmeta.imagem_goal_final as 'cabmeta.imagem_goal_final', ")
						.append(" cabmeta.indice_goal as 'cabmeta.indice_goal', ")
						.append(" cabmeta.login as 'cabmeta.login', ")
						.append(" cabmeta.meta as 'cabmeta.meta', ")
						.append(" cabmeta.uph as 'cabmeta.uph', ")
						.append(" cabmeta.flag_totalizador as 'cabmeta.flag_totalizador', ")
						.append(" cabmeta.id_operacao as 'cabmeta.id_operacao' ")
						.append(FROM)
						.append(" tb_cab_meta cabmeta with(nolock) ").append(WHERE)
						.append(MessageFormat.format(" cabmeta.id_usuario IN ({0}) ", StringUtils.join(listaUsuariosId.iterator(), ",", false)));
			
				PreparedStatement stmt = super.getPreparedStatement(sql.toString());
				ResultSet resultSet = stmt.executeQuery();

				if (resultSet != null) {
					while (resultSet.next()) {
						CabMetaFullTO to = new CabMetaFullTO();
						to.setMediaPonderadaFinal(resultSet.getDouble("cabmeta.media_ponderada_final"));
						to.setIdUsuario((Integer) resultSet.getObject("cabmeta.id_usuario"));
						to.setImageGFinal(resultSet.getString("cabmeta.image_g_final"));
						to.setIdConfiguracaoFila((Integer) resultSet.getObject("cabmeta.id_configuracao_fila"));
						to.setTempoTotalEquipe(resultSet.getDouble("cabmeta.tempo_total_equipe"));
						to.setCasosFechados((Integer) resultSet.getObject("cabmeta.casos_fechados"));
						to.setUphEquipe(resultSet.getDouble("cabmeta.uph_equipe"));
						to.setNomeConfiguracaoFila(resultSet.getString("cabmeta.nome_configuracao_fila"));
						to.setGoalFinal(resultSet.getDouble("cabmeta.goal_final"));
						to.setImagemGoalFinal(resultSet.getString("cabmeta.imagem_goal_final"));
						to.setIndiceGoal(resultSet.getDouble("cabmeta.indice_goal"));
						to.setLogin(resultSet.getString("cabmeta.login"));
						to.setMeta(resultSet.getDouble("cabmeta.meta"));
						to.setUph(resultSet.getDouble("cabmeta.uph"));
						to.setFlagTotalizador(resultSet.getBoolean("cabmeta.flag_totalizador"));
						to.setIdOperacao((Integer) resultSet.getObject("cabmeta.id_operacao"));
						toReturn.add(to);
					}
				}
			}
			return toReturn;
			
		} finally {
			super.closeConnection();
		}
	}

	public void atualizaStatusLogado(Map<String, List<Integer>> iconPerUser) throws Exception {
		try {
			for (String icon : iconPerUser.keySet()) {
				PreparedStatement stmt = super.getPreparedStatement(MessageFormat.format(
						"UPDATE tb_usuario_logado set goal = ''{0}'' where id_usuario IN ({1}) and flag_logado = 1 ", icon,
						StringUtils.join(iconPerUser.get(icon).iterator(), ",", false)));
				stmt.executeUpdate();
			}
		} finally {
			super.closeConnection();
		}
	}
}