package br.com.callink.cad.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang3.SerializationUtils;

import br.com.callink.cad.to.CampoDinamicoTO;
import br.com.callink.cad.to.LinhaCampoDinamicoTabelaTO;
import br.com.callink.cad.to.TipoCampoDinamico;
import br.com.callink.cad.util.CollectionUtils;

public class CampoDinamicoDAO extends GenericDAO {

	private Logger logger = Logger.getLogger(CampoDinamicoDAO.class.getName());
	
	public boolean exibirCampoCriptografado(String nome, String tipoCampo, Integer idOperacao) throws Exception {

		StringBuilder sq = new StringBuilder();
		sq.append(" select count(*) as numero   from tb_campo_dinamico c, tb_operacao_campo_dinamico oc ");
		sq.append(" where c.id_campo_dinamico = oc.id_campo_dinamico and oc.id_operacao = ? and c.tipo_campo = ? and c.nome_coluna = ? ");

		try {
			PreparedStatement p = getPreparedStatement(sq.toString());

			p.setInt(1, idOperacao);
			p.setString(2, tipoCampo);
			p.setString(3, nome);

			ResultSet resultSet = p.executeQuery(sq.toString());

			if (resultSet != null) {
				while (resultSet.next()) {
					Integer num = resultSet.getInt("numero");

					if (num > 0) {
						return true;
					}
				}
			}
			return false;
		} catch (Exception e) {
			StringBuilder str = new StringBuilder();
			
			str.append("Erro ao buscar campo criptografado. Nome: ").append(nome)
			.append(" - Tipo Campo: ").append(tipoCampo).append(" - Operacao: ").append(idOperacao);
			
			logger.log(Level.SEVERE, str.toString());
			
			throw e;
		} finally {
			super.closeConnection();
		}
	}
	
	public List<CampoDinamicoTO> findDynamicFieldsByType (List<TipoCampoDinamico> tipos, Integer idTenant) throws Exception {
		try {
			List<CampoDinamicoTO> campos = new ArrayList<CampoDinamicoTO>();
			
			StringBuilder sq = new StringBuilder();
			sq.append("SELECT * FROM tb_campo_dinamico with(nolock) where tipo_campo in (");
			
			for(TipoCampoDinamico t:tipos) {
				sq.append( "'" + t.name()+ "'" + ",");
			}
	
			sq.deleteCharAt(sq.length()-1) ;
			sq.append(")");
			
			sq.append(String.format(" and id_tenant = %d",idTenant));
			
			PreparedStatement p = getPreparedStatement(sq.toString());
			ResultSet res = p.executeQuery();
			
			while(res.next()) {
				campos.add(CampoDinamicoTO.getCampoTOByResultSet(res));
			}
			
			return campos;
		} catch (Exception e) {
			StringBuilder str = new StringBuilder();
			
			str.append("Erro ao buscar campo dinamico por tipos. Tipos: ");
			for(TipoCampoDinamico t:tipos) {
				str.append(t.name()).append(", ");
			}
			
			logger.log(Level.SEVERE, str.toString());
			
			throw e;
		} finally {
			super.closeConnection();
		}
	}

	public List<CampoDinamicoTO> getFieldsCriptografados(Integer idOperacao) throws Exception {
		try {
			List<CampoDinamicoTO> campos = new ArrayList<CampoDinamicoTO>();
			
			StringBuilder sq = new StringBuilder();
			sq.append("SELECT * FROM tb_campo_dinamico cd with(nolock), tb_operacao_campo_dinamico oc with(nolock) where cd.id_campo_dinamico = oc.id_campo_dinamico and cd.tipo_campo = ('")
					.append(TipoCampoDinamico.CRIPTOGRAFADO.name()).append("') and cd.flag_ativo = 1 and oc.id_operacao = ").append(idOperacao.toString());
			
			PreparedStatement p = getPreparedStatement(sq.toString());
			ResultSet res = p.executeQuery();
			
			while(res.next()) {
				campos.add(CampoDinamicoTO.getCampoTOByResultSet(res));
			}
			
			return campos;
		} catch (Exception e) {
			StringBuilder str = new StringBuilder();
			str.append("Erro ao buscar campo dinamico do tipo criptogrado ");
			
			logger.log(Level.SEVERE, str.toString());
			
			throw e;
		} finally {
			super.closeConnection();
		}
	}
	
	public List<CampoDinamicoTO> buscaAtivosPorOperacaoComRange(Integer idOperacao) throws Exception {
		List<CampoDinamicoTO> campos = new ArrayList<CampoDinamicoTO>();
		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT ocd.limite_inferior as limite_inferior ");
			sql.append(" 	   ,ocd.limite_superior as limite_superior ");
			sql.append(" 	   ,CASE WHEN LTRIM(RTRIM(ocd.label)) IS NOT NULL THEN ocd.label ");
			sql.append(" 	         ELSE campoDinamico.nome ");
			sql.append(" 	    END AS label ");
			sql.append(" 	   ,campoDinamico.id_campo_dinamico as id_campo_dinamico ");
			sql.append(" 	   ,campoDinamico.flag_exportar_valor_real as flag_exportar_valor_real ");
			sql.append(" 	   ,campoDinamico.flag_date_time as flag_date_time ");
			sql.append(" 	   ,campoDinamico.flag_mascara_todos_caracteres as flag_mascara_todos_caracteres ");
			sql.append(" 	   ,campoDinamico.nome as nome ");
			sql.append(" 	   ,campoDinamico.mascara as mascara ");
			sql.append(" 	   ,campoDinamico.nome_coluna as nome_coluna ");
			sql.append(" 	   ,campoDinamico.separador_campo as separador_campo ");
			sql.append(" 	   ,campoDinamico.separador_valor as separador_valor ");
			sql.append(" 	   ,campoDinamico.size_campo as size_campo ");
			sql.append(" 	   ,campoDinamico.tipo_campo as tipo_campo ");
			sql.append(" FROM TB_CAMPO_DINAMICO campoDinamico  ");
			sql.append(" LEFT JOIN TB_OPERACAO_CAMPO_DINAMICO ocd ON campoDinamico.ID_CAMPO_DINAMICO = ocd.ID_CAMPO_DINAMICO  ");
			sql.append(" WHERE ocd.ID_OPERACAO = ? ");
			
			PreparedStatement p = getPreparedStatement(sql.toString());
			p.setInt(1, idOperacao);
			
			ResultSet rs = p.executeQuery();
			
			if (rs != null) {
				while (rs.next()) {
					CampoDinamicoTO campo = new CampoDinamicoTO();
					campo.setLabel(rs.getString("label"));
					campo.setIdCampoDinamico((Integer) rs.getObject("id_campo_dinamico"));
					campo.setFlagExportarValorReal((Boolean) rs.getObject("flag_exportar_valor_real"));
					campo.setFlagDateTime((Boolean) rs.getObject("flag_date_time"));
					campo.setFlagMascaraTodosCaracteres((Boolean) rs.getObject("flag_mascara_todos_caracteres"));
					campo.setNome(rs.getString("nome"));
					campo.setMascara(rs.getString("mascara"));
					campo.setNomeColuna(rs.getString("nome_coluna"));
					campo.setSeparadorCampo(rs.getString("separador_campo"));
					campo.setSeparadorValor(rs.getString("separador_valor"));
					campo.setSizeCampo((Integer) rs.getObject("size_campo"));
					campo.setTipoCampo(TipoCampoDinamico.getInstance(rs.getString("tipo_campo")));
					
					campos.add(campo);
				}
			}
			return campos;
		} catch (Exception e) {
			StringBuilder str = new StringBuilder();
			str.append("Erro ao buscar campos dinamicos");
			logger.log(Level.SEVERE, str.toString());
			throw e;
		} finally {
			super.closeConnection();
		}
	}
	
	public List<CampoDinamicoTO> buscaCamposPorTabela(Integer idCampoDinamico) throws Exception {
		try {
			List<CampoDinamicoTO> campos = new ArrayList<CampoDinamicoTO>();
			
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT campos.id_configuracao_campo_tabela AS 'idCampoDinamico' ");
			sql.append(" 	,campos.tipo_campo AS 'tipoCampo' ");
			sql.append(" 	,campos.size_campo AS 'size' ");
			sql.append(" 	,ass.label AS 'label' ");
			sql.append(" 	,campos.flag_date_time AS 'flagHasTime' ");
			sql.append(" 	,campos.nome_coluna AS 'nomeColuna' ");
			sql.append(" 	,campos.mascara as 'mascara' ");
			sql.append(" from TB_ASSOCIA_CAMPO_TABELA ass ");
			sql.append(" INNER JOIN TB_CONFIGURACAO_CAMPO_TABELA campos on ass.ID_CONFIGURACAO_CAMPO_TABELA = campos.ID_CONFIGURACAO_CAMPO_TABELA ");
			sql.append(" WHERE ass.ID_CAMPO_TABELA = ? ");
			
			PreparedStatement p = getPreparedStatement(sql.toString());
			p.setInt(1, idCampoDinamico);
			
			ResultSet rs = p.executeQuery();
			
			if (rs != null) {
				while(rs.next()) {
					CampoDinamicoTO campo = new CampoDinamicoTO();
					campo.setIdCampoDinamico((Integer) rs.getObject("idCampoDinamico"));
					campo.setTipoCampo(TipoCampoDinamico.valueOf(rs.getString("tipoCampo")));
					campo.setSizeCampo((Integer) rs.getObject("size"));
					campo.setLabel(rs.getString("label"));
					campo.setFlagDateTime((Boolean) rs.getObject("flagHasTime"));
					campo.setNomeColuna(rs.getString("nomeColuna"));
					campo.setMascara(rs.getString("mascara"));
					
					campos.add(campo);
				}
			}
			
			return campos;
		} catch (Exception e) {
			StringBuilder str = new StringBuilder();
			str.append("Erro ao buscar campo dinamico do tipo tabela ");
			
			logger.log(Level.SEVERE, str.toString());
			
			throw e;
		} finally {
			super.closeConnection();
		}
	}
	
	public List<LinhaCampoDinamicoTabelaTO> buscaValores(Integer idCampoTabela, List<CampoDinamicoTO> camposTabela, Integer idCaso) throws Exception {
		try {
			if (CollectionUtils.isEmpty(camposTabela)) {
				return null;
			}
			List<Object[]> list = new ArrayList<Object[]>();
			StringBuilder sql = new StringBuilder();
			sql.append(" select ");

			for (CampoDinamicoTO campoDinamicoTO : camposTabela) {
				sql.append(campoDinamicoTO.getNomeColuna());

				if (camposTabela.indexOf(campoDinamicoTO) < (camposTabela.size()-1)) {
					sql.append(", ");
				}
			}

			sql.append(", id_valor_campo_tabela ");
			sql.append(" from tb_valor_campo_tabela ");
			sql.append(" where id_caso = ?");
			sql.append(" and id_campo_tabela = ?");

			PreparedStatement p = getPreparedStatement(sql.toString());
			p.setInt(1, idCaso);
			p.setInt(2, idCampoTabela);
			
			ResultSet rs = p.executeQuery();
			if (rs != null) {
				while (rs.next()) {
					Object[] campo = new Object[camposTabela.size()];
					for (int x = 0; x < camposTabela.size(); x++) {
						campo[x] = rs.getObject(camposTabela.get(x).getNomeColuna());
					}
					list.add(campo);
				}
			}
			
			if (CollectionUtils.hasValue(list)) {
				List<LinhaCampoDinamicoTabelaTO> retorno = new ArrayList<LinhaCampoDinamicoTabelaTO>();

				for (Object[] arr : list) {
					LinhaCampoDinamicoTabelaTO line = new LinhaCampoDinamicoTabelaTO();
					line.setColunas(new CampoDinamicoTO[camposTabela.size()]);

					for (CampoDinamicoTO campo : camposTabela) {
						CampoDinamicoTO campoClone = (CampoDinamicoTO) SerializationUtils.clone(campo);
						
						if(arr[camposTabela.indexOf(campo)] != null){
							campoClone.setValor(arr[camposTabela.indexOf(campo)].toString());
						}
						line.getColunas()[camposTabela.indexOf(campo)] = campoClone;
					}
					line.setId((Integer) arr[arr.length-1]);

					retorno.add(line);
				}
				return retorno;
			}
			return null;
		} catch (Exception e) {
			StringBuilder str = new StringBuilder();
			str.append("Erro ao buscar valores de campo dinamico do tipo tabela ");
			
			logger.log(Level.SEVERE, str.toString());
			
			throw e;
		} finally {
			super.closeConnection();
		}
	}
	
}
