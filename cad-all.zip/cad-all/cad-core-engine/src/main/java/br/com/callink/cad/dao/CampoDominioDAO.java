package br.com.callink.cad.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import br.com.callink.cad.to.CampoDominioSelecionadoTO;
import br.com.callink.cad.to.CampoDominioTO;
import br.com.callink.cad.to.DadosDinamicos;
import br.com.callink.cad.to.GrupoCampoDominioTO;
import br.com.callink.cad.to.TipoCampoDinamico;
import br.com.callink.cad.util.CollectionUtils;

public class CampoDominioDAO extends GenericDAO {

	private Logger logger = Logger.getLogger(CampoDominioDAO.class.getName());
	
	public List<CampoDominioSelecionadoTO> findCampoDominioSelecionadoByGrupo(Integer idGrupoCampoDominio) throws Exception {
		try {
			List<CampoDominioSelecionadoTO> campos = new ArrayList<CampoDominioSelecionadoTO>();
			
			StringBuilder sql = new StringBuilder();
			sql.append(" select cds.id_campo_dominio_selecionado as id_campo_dominio_selecionado ");
			sql.append(" 	  , cds.id_campo_dominio as id_campo_dominio ");
			sql.append(" 	  , cds.id_grupo_campo_dominio as id_grupo_campo_dominio ");
			sql.append(" 	  , cd.id_campo_dinamico as id_campo_dinamico ");
			sql.append(" 	  , cd.valor as valor ");
			sql.append(" from tb_campo_dominio_selecionado cds ");
			sql.append("  inner join tb_campo_dominio cd ");
			sql.append("   on cd.id_campo_dominio = cds.id_campo_dominio ");
			sql.append(" where cds.id_grupo_campo_dominio = ? ");
			
			PreparedStatement p = getPreparedStatement(sql.toString());
			p.setInt(1, idGrupoCampoDominio);
			
			ResultSet rs = p.executeQuery();
			
			if (rs != null) {
				while (rs.next()) {
					CampoDominioSelecionadoTO campoSelecionado = new CampoDominioSelecionadoTO();
					campoSelecionado.setIdCampoDominioSelecionado((Integer) rs.getObject("id_campo_dominio_selecionado"));
					
					CampoDominioTO campo = new CampoDominioTO();
					campo.setIdCampoDominio((Integer) rs.getObject("id_campo_dominio"));
					campo.setValor(rs.getString("valor"));
					campoSelecionado.setCampoDominio(campo);
					
					GrupoCampoDominioTO grupo = new GrupoCampoDominioTO();
					grupo.setIdGrupoCampoDominio((Integer) rs.getObject("id_grupo_campo_dominio"));
					campoSelecionado.setGrupoCampoDominio(grupo);
					
					campos.add(campoSelecionado);
				}
			}
			return campos;
		} catch (Exception e) {
			StringBuilder str = new StringBuilder();
			str.append("Erro ao buscar campos dominio selecionados");
			
			logger.log(Level.SEVERE, str.toString());
			
			throw e;
		} finally {
			super.closeConnection();
		}
	}
	
	public void buscaValoresCamposDinamicosListaCaso(DadosDinamicos[] dadosDinamicos, Integer idCaso) throws Exception {
		try {
			if (CollectionUtils.hasValue(dadosDinamicos)) {
				PreparedStatement stmt = null;
				ResultSet resultSet = null;

				for (DadosDinamicos dado : dadosDinamicos) {
					if ((TipoCampoDinamico.LISTA_UNICA.equals(dado.getDadosColuna().getTipoCampo()) || TipoCampoDinamico.LISTA_MULTIPLA.equals(dado.getDadosColuna().getTipoCampo())) 
							&& dado.getValor() != null) {

						StringBuilder sql = new StringBuilder();
						sql.append(" select cd.valor as valor, cd.id_externo as id");
						sql.append(" from tb_caso_detalhe caso with(nolock) ");
						sql.append(" , tb_grupo_campo_dominio gcd with(nolock) ");
						sql.append(" , tb_campo_dominio_selecionado cds with(nolock) ");
						sql.append(" , tb_campo_dominio cd with(nolock) ");
						sql.append(MessageFormat.format(" where caso.{0} = gcd.id_grupo_campo_dominio ", dado.getDadosColuna().getNomeColuna()));
						sql.append(" and gcd.id_grupo_campo_dominio = cds.id_grupo_campo_dominio ");
						sql.append(" and cds.id_campo_dominio = cd.id_campo_dominio ");
						sql.append(" and caso.id_caso = ? ");

						stmt = getPreparedStatement(sql.toString());
						stmt.setInt(1, idCaso);
						stmt.execute();
						resultSet = stmt.getResultSet();

						if (resultSet != null) {
							StringBuilder valor = new StringBuilder();

							while (resultSet.next()) {
								valor.append(resultSet.getString("valor"));
								if (resultSet.getString("id") != null) {
									valor.append(dado.getDadosColuna().getSeparadorValor());
									valor.append(resultSet.getString("id"));
								}
								valor.append(dado.getDadosColuna().getSeparadorCampo());
							}
							if (valor != null && valor.lastIndexOf(dado.getDadosColuna().getSeparadorCampo()) > 0) {
								valor = valor.deleteCharAt(valor.lastIndexOf(dado.getDadosColuna().getSeparadorCampo()));
							}
							dado.getDadosColuna().setValor(valor.toString().isEmpty() ? null : valor.toString());
							dado.setValor(valor.toString().isEmpty() ? null : valor.toString());
						}
					}
				}
			}
		} catch (Exception e) {
			throw new Exception("Erro ao buscar valores dos campos dinamicos lista.", e);
		} finally {
			super.closeConnection();
		}
	}
	
}
