package br.com.callink.cad.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import br.com.callink.cad.to.CampoLayoutAlteracaoTO;

public class CampoLayoutAlteracaoDAO extends GenericDAO {

	private Logger logger = Logger.getLogger(CampoLayoutAlteracaoDAO.class.getName());
	
	public List<CampoLayoutAlteracaoTO> buscaCamposLayout(Integer idLayoutAlteracao) throws Exception {

		List<CampoLayoutAlteracaoTO> campos = new ArrayList<CampoLayoutAlteracaoTO>();
		
		StringBuilder sq = new StringBuilder();
		sq.append(" select * from tb_campo_layout_alteracao ");
		sq.append(" where id_layout_alteracao = ? ");
		
		try {
			PreparedStatement p = getPreparedStatement(sq.toString());
			p.setInt(1, idLayoutAlteracao);
			ResultSet resultSet = p.executeQuery();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					CampoLayoutAlteracaoTO campo = CampoLayoutAlteracaoTO.getCamposLayoutTOByResultSet(resultSet);
					campos.add(campo);
				}
			}

			return campos;
		} catch (Exception e) {
			StringBuilder str = new StringBuilder();
			
			str.append("Erro ao buscar os campos do layoyt de alteracao: ").append(idLayoutAlteracao);
			
			logger.log(Level.SEVERE, str.toString());
			
			throw e;
		} finally {
			super.closeConnection();
		}
	}
}
