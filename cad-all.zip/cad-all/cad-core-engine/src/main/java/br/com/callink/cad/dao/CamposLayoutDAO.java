package br.com.callink.cad.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import br.com.callink.cad.to.CamposLayoutTO;

public class CamposLayoutDAO extends GenericDAO {

	private Logger logger = Logger.getLogger(CamposLayoutDAO.class.getName());
	
	public List<CamposLayoutTO> buscaCamposByLayout(Integer idLayout) throws Exception {
		try {
			StringBuilder sql = new StringBuilder();
			sql.append(SELECT);
			sql.append("campo.campo_caso as campoCaso ");
			sql.append(",campo.campo_nome AS campoNome ");
			sql.append(",campo.campo_import_caso AS campoImportCaso ");
			sql.append(",campo.flag_identificador AS flagIdentificador ");
			sql.append(",CASE ");
			sql.append("WHEN din.size_campo IS NULL ");
			sql.append("THEN ( ");
			sql.append("SELECT colunas.length ");
			sql.append("FROM SYSOBJECTS tabelas, SYSCOLUMNS colunas ");
			sql.append("WHERE tabelas.id = colunas.id ");
			sql.append("AND tabelas.NAME = 'tb_caso' ");
			sql.append("AND colunas.NAME = campo.campo_caso ");
			sql.append(") ");
			sql.append("ELSE din.size_campo ");
			sql.append("END AS size ");
			sql.append(",campo.flag_not_null AS notNull ");
			sql.append(",campo.flag_campo_dinamico AS flagCampoDinamico ");
			sql.append(FROM);
			sql.append("tb_campo_layout campo with(nolock) ");
			sql.append("left join tb_campo_dinamico din with(nolock) on campo.campo_caso = din.nome_coluna ");
			sql.append(WHERE);
			sql.append("campo.id_layout = ? ");

			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ps.setInt(1, idLayout);
			ResultSet resultSet = ps.executeQuery();

			List<CamposLayoutTO> ret = new ArrayList<CamposLayoutTO>();
			if (resultSet != null) {
				while (resultSet.next()) {
					CamposLayoutTO campo = CamposLayoutTO.getCamposLayoutTOByResultSet(resultSet);
					ret.add(campo);
				}
			}
			return ret;
		} catch (Exception e) {
			StringBuilder str = new StringBuilder();
			
			str.append("Erro ao buscar campos do layout: ").append(idLayout);
			
			logger.log(Level.SEVERE, str.toString());
			
			throw e;
		} finally {
			super.closeConnection();
		}
	}
	
	
	public List<CamposLayoutTO> buscaCamposByJob(Integer idJob) throws Exception {
		try {
			StringBuilder sql = new StringBuilder();
			sql.append(SELECT);
			sql.append("campo.campo_caso as campoCaso ");
			sql.append(",campo.campo_nome AS campoNome ");
			sql.append(",campo.campo_import_caso AS campoImportCaso ");
			sql.append(",campo.flag_identificador AS flagIdentificador ");
			sql.append(",CASE ");
			sql.append("WHEN din.size_campo IS NULL ");
			sql.append("THEN ( ");
			sql.append("SELECT colunas.length ");
			sql.append("FROM SYSOBJECTS tabelas, SYSCOLUMNS colunas ");
			sql.append("WHERE tabelas.id = colunas.id ");
			sql.append("AND tabelas.NAME = 'tb_caso' ");
			sql.append("AND colunas.NAME = campo.campo_caso ");
			sql.append(") ");
			sql.append("ELSE din.size_campo ");
			sql.append("END AS size ");
			sql.append(",campo.flag_not_null AS notNull ");
			sql.append(",campo.flag_campo_dinamico AS flagCampoDinamico ");
			sql.append(FROM);
			sql.append("tb_campo_layout campo with(nolock) ");
			sql.append(" inner join tb_layout_importacao layout with(nolock) on campo.id_layout = layout.id_layout ");
			sql.append(" left join tb_campo_dinamico din with(nolock) on campo.campo_caso = din.nome_coluna ");
			sql.append(WHERE);
			sql.append(" layout.id_job = ? ");

			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ps.setInt(1, idJob);
			ResultSet resultSet = ps.executeQuery();

			List<CamposLayoutTO> ret = new ArrayList<CamposLayoutTO>();
			if (resultSet != null) {
				while (resultSet.next()) {
					CamposLayoutTO campo = CamposLayoutTO.getCamposLayoutTOByResultSet(resultSet);
					ret.add(campo);
				}
			}
			return ret;
		} catch (Exception e) {
			StringBuilder str = new StringBuilder();
			
			str.append("Erro ao buscar campos da job: ").append(idJob);
			
			logger.log(Level.SEVERE, str.toString());
			
			throw e;
		} finally {
			super.closeConnection();
		}
	}
}
