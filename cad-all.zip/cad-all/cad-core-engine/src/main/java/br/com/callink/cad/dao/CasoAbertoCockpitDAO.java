package br.com.callink.cad.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import br.com.callink.cad.to.CasoAbertoCockpitDetalheTO;
import br.com.callink.cad.to.CasoAbertoCockpitTO;
import br.com.callink.cad.to.CasoTO;
import br.com.callink.cad.to.SlaFilaTO;
import br.com.callink.cad.util.Constantes;
import br.com.callink.cad.util.HintNumberRows;

public class CasoAbertoCockpitDAO extends GenericDAO {

	private Logger logger = Logger.getLogger(CasoAbertoCockpitDAO.class.getName());

	public List<CasoTO> buscaCasoAbertoSemPendencia(Integer idOperacao) throws Exception {
		try {
			List<CasoTO> casos = new ArrayList<>();

			StringBuilder sql = new StringBuilder();
			sql.append(SELECT);
			sql.append(CasoTO.getSqlColuns());
			sql.append(", ConfiguracaoFila.NOME AS 'ConfiguracaoFila.NOME', TipoCaso.ID_TIPO_CASO AS 'TipoCaso.ID_TIPO_CASO' ");
			sql.append(", TipoCaso.NOME AS 'TipoCaso.NOME', TipoCaso.ID_OPERACAO AS 'TipoCaso.ID_OPERACAO', Caso.ID_SLA_FILA AS 'Caso.ID_SLA_FILA' ");
			sql.append(CasoTO.getSqlFrom());
			sql.append(", TB_TIPO_CASO TipoCaso with(nolock), TB_CONFIGURACAO_FILA ConfiguracaoFila with(nolock), tb_status status with(nolock) ");
			sql.append(WHERE);
			sql.append("Caso.ID_TIPO_CASO = TipoCaso.ID_TIPO_CASO   ");
			sql.append("AND Caso.id_configuracao_fila = ConfiguracaoFila.id_configuracao_fila ");
			sql.append("AND Caso.ID_OPERACAO = ? ");
			sql.append("AND Caso.FLAG_FINALIZADO = 0 ");
			sql.append("AND Caso.DATA_FIM_SLA is null ");
			sql.append("AND Caso.ID_STATUS = status.ID_STATUS  ");
			sql.append("AND status.FLAG_CONTA_SLA = 1  ");
			sql.append("ORDER BY Caso.DATA_ABERTURA ");

			PreparedStatement ps = super.getPreparedStatement(sql.toString(), HintNumberRows.ROWS_CASO.getRows());
			ps.setInt(1, idOperacao);
			ResultSet resultSet = ps.executeQuery();

			if (resultSet != null) {
				while (resultSet.next()) {
					CasoTO to = new CasoTO();
					to.setIdCaso((Integer) resultSet.getObject("Caso.ID_CASO"));
					to.setIdUsuario((Integer) resultSet.getObject("Caso.ID_USUARIO"));
					to.setFlagReclassificaReabertura(resultSet.getBoolean("Caso.flag_reclassifica_reabertura"));
					to.setFlagClassifica(resultSet.getBoolean("Caso.flag_classifica"));
					to.setIdConfiguracaoFila((Integer) resultSet.getObject("Caso.id_configuracao_fila"));
					to.setDataAbertura(resultSet.getTimestamp("Caso.data_abertura"));
					to.setDataFimSla(resultSet.getTimestamp("Caso.data_fim_sla"));
					to.setNomeConfiguracaoFila(resultSet.getString("ConfiguracaoFila.NOME"));
					to.setIdTipoCaso((Integer) resultSet.getObject("TipoCaso.ID_TIPO_CASO"));
					to.setNomeTipoCaso(resultSet.getString("TipoCaso.NOME"));
					to.setIdOperacao((Integer) resultSet.getObject("TipoCaso.ID_OPERACAO"));
					to.setSlaFilaTO(resultSet.getObject("Caso.ID_SLA_FILA") != null ? new SlaFilaTO((Integer) resultSet.getObject("Caso.ID_SLA_FILA")) : null);
					to.setIdExterno(resultSet.getString("Caso.id_externo"));

					casos.add(to);
				}
			}

			return casos;
		} catch (Exception e) {
			StringBuilder str = new StringBuilder();

			str.append("Erro ao buscar caso aberto sem pendencia. Operacao: ").append(idOperacao);

			logger.log(Level.SEVERE, str.toString());

			throw e;
		} finally {
			super.closeConnection();
		}
	}

	public void insert(List<CasoAbertoCockpitTO> casoAbertoCockpitList, Integer idOperacao) throws Exception {
		Connection connection = null;
		try {
			Date dataBanco = getDataBanco();
			delete(dataBanco, idOperacao);

			CasoAbertoCockpitTO casoAbertoCockpitTO = null;

			try {

				connection = getConnection();
				connection.setAutoCommit(false);
				String query = "INSERT INTO tb_caso_aberto_cockpit (nome_fila_atendimento,tipo_manifestacao,data_processamento,flag_fila,qtd_primeiro_dia,percentual_primeiro_dia,qtd_segundo_dia,percentual_segundo_dia,qtd_terceiro_dia,percentual_terceiro_dia,qtd_quarto_dia,percentual_quarto_dia,qtd_quinto_dia,percentual_quinto_dia,qtd_sexto_dia,percentual_sexto_dia,qtd_restante_dia,percentual_restante_dia,qtd_total,percentual_total,id_operacao)  values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

				PreparedStatement ps = connection.prepareStatement(query);
				ps.setFetchSize(casoAbertoCockpitList.size());

				int count = 0;
				for (int i = 0; i < casoAbertoCockpitList.size(); i++) {

					casoAbertoCockpitTO = casoAbertoCockpitList.get(i);
					casoAbertoCockpitTO.setDataProcessamento(dataBanco);

					if (casoAbertoCockpitTO.getNomeFilaAtendimento() == null || casoAbertoCockpitTO.getNomeFilaAtendimento().isEmpty()) {
						ps.setNull(1, Types.NULL);
					} else {
						ps.setString(1, casoAbertoCockpitTO.getNomeFilaAtendimento());
					}
					if (casoAbertoCockpitTO.getTipoCaso() == null || casoAbertoCockpitTO.getTipoCaso().isEmpty()) {
						ps.setNull(2, Types.NULL);
					} else {
						ps.setString(2, casoAbertoCockpitTO.getTipoCaso());
					}
					ps.setString(3, new SimpleDateFormat("yyyy-MM-dd").format(casoAbertoCockpitTO.getDataProcessamento()));
					ps.setBoolean(4, casoAbertoCockpitTO.getFlagFila() ? Boolean.TRUE : Boolean.FALSE);
					ps.setInt(5, casoAbertoCockpitTO.getQtdPrimeiroDia());
					ps.setString(6, casoAbertoCockpitTO.getPercentualPrimeiroDia());
					ps.setInt(7, casoAbertoCockpitTO.getQtdSegundoDia());
					ps.setString(8, casoAbertoCockpitTO.getPercentualSegundoDia());
					ps.setInt(9, casoAbertoCockpitTO.getQtdTerceiroDia());
					ps.setString(10, casoAbertoCockpitTO.getPercentualTerceiroDia());
					ps.setInt(11, casoAbertoCockpitTO.getQtdQuartoDia());
					ps.setString(12, casoAbertoCockpitTO.getPercentualQuartoDia());
					ps.setInt(13, casoAbertoCockpitTO.getQtdQuintoDia());
					ps.setString(14, casoAbertoCockpitTO.getPercentualQuintoDia());
					ps.setInt(15, casoAbertoCockpitTO.getQtdSextoDia());
					ps.setString(16, casoAbertoCockpitTO.getPercentualSextoDia());
					ps.setInt(17, casoAbertoCockpitTO.getQtdRestanteDia());
					ps.setString(18, casoAbertoCockpitTO.getPercentualRestanteDia());
					ps.setInt(19, casoAbertoCockpitTO.getQtdTotal());
					ps.setString(20, casoAbertoCockpitTO.getPercentualTotal());
					ps.setInt(21, casoAbertoCockpitTO.getIdOperacao());

					ps.addBatch();

					if (++count % Constantes.BATCH_SIZE == 0) {
						ps.executeBatch();
						connection.commit();
					}
				}

				ps.executeBatch();
				connection.commit();

			} catch (Exception e) {
				StringBuilder str = new StringBuilder();

				str.append("Erro ao inserir caso aberto cockpit. ");
				if (casoAbertoCockpitTO.getNomeFilaAtendimento() != null && !casoAbertoCockpitTO.getNomeFilaAtendimento().isEmpty()) {
					str.append(" - Fila: ").append(casoAbertoCockpitTO.getNomeFilaAtendimento());
				}
				if (casoAbertoCockpitTO.getTipoCaso() != null && !casoAbertoCockpitTO.getTipoCaso().isEmpty()) {
					str.append(" - Tipo Caso: ").append(casoAbertoCockpitTO.getTipoCaso());
				}

				logger.log(Level.SEVERE, str.toString());

				throw e;
			}

		} finally {

			if (connection != null) {
				connection.close();
			}
		}
	}

	public void delete(Date dataBanco, Integer idOperacao) throws Exception {
		try {
			PreparedStatement ps = super.getPreparedStatement(" delete from tb_caso_aberto_cockpit where data_processamento = CAST(? AS DATE) and id_operacao = ? ");
			ps.setDate(1, new java.sql.Date(dataBanco.getTime()));
			ps.setInt(2, idOperacao);
			ps.execute();
		} catch (Exception e) {
			StringBuilder str = new StringBuilder();

			str.append("Erro ao delegar. Data: ").append(dataBanco).append(" - Operacao: ").append(idOperacao);

			logger.log(Level.SEVERE, str.toString());

			throw e;
		} finally {
			super.closeConnection();
		}
	}

	public Integer findIdStatusPendenteChecagem(String mnemonico) throws Exception {
		try {
			StringBuilder sql = new StringBuilder();
			sql.append(SELECT);
			sql.append(" ID_STATUS AS 'ID_STATUS' ");
			sql.append(FROM);
			sql.append(" TB_STATUS with(nolock) ");
			sql.append(WHERE);
			sql.append(" NOME =  '" + mnemonico + "'");

			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ResultSet resultSet = ps.executeQuery();

			if (resultSet != null && resultSet.next()) {
				return (Integer) resultSet.getObject("ID_STATUS");
			}

			return null;
		} catch (Exception e) {
			StringBuilder str = new StringBuilder();

			str.append("Erro ao buscar status pendente de checagem. MNM: ").append(mnemonico);

			logger.log(Level.SEVERE, str.toString());

			throw e;
		} finally {
			super.closeConnection();
		}
	}

	public void deleteDetalhe(Date dataBanco, Integer idOperacao) throws Exception {
		try {
			PreparedStatement ps = super.getPreparedStatement(" delete from tb_caso_aberto_cockpit_detalhe where data_processamento = CAST(? AS DATE) and id_operacao = ? ");
			ps.setDate(1, new java.sql.Date(dataBanco.getTime()));
			ps.setInt(2, idOperacao);
			ps.execute();
		} catch (Exception e) {
			StringBuilder str = new StringBuilder();

			str.append("Erro ao deletar detalhe. Data: ").append(dataBanco).append(" - Operacao: ").append(idOperacao);

			logger.log(Level.SEVERE, str.toString());

			throw e;
		} finally {
			super.closeConnection();
		}
	}

	public void insertDetalhe(List<CasoAbertoCockpitDetalheTO> casoAbertoCockpitDetalheList, Integer idOperacao) throws Exception {
		Connection connection = null;
		try {
			Date dataBanco = getDataBanco();
			CasoAbertoCockpitDetalheTO casoTO = null;

			try {

				connection = getConnection();
				connection.setAutoCommit(false);
				StringBuilder sql = new StringBuilder().append("INSERT INTO tb_caso_aberto_cockpit_detalhe ").append("(id_caso_aberto_cockpit, ").append("id_caso, ").append("id_externo, ").append("id_tipo_caso, ").append("tipo_caso, ").append("id_configuracao_fila, ").append("configuracao_fila, ").append("percentual, ").append("id_operacao, ").append("data_processamento) ")
						.append("VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ");

				PreparedStatement stmt = super.getPreparedStatement(sql.toString());
				stmt.setFetchSize(casoAbertoCockpitDetalheList.size());
				int count = 0;
				for (int i = 0; i < casoAbertoCockpitDetalheList.size(); i++) {
					casoTO = casoAbertoCockpitDetalheList.get(i);
					casoTO.setDataProcessamento(dataBanco);

					if (casoTO.getIdCasoAbertoCockpit() != null) {
						stmt.setInt(1, casoTO.getIdCasoAbertoCockpit());

						stmt.setInt(2, casoTO.getIdCaso());
						stmt.setString(3, casoTO.getIdExterno());
						if (casoTO.getIdTipoCaso() != null) {
							stmt.setInt(4, casoTO.getIdTipoCaso());
						} else {
							stmt.setNull(4, Types.NULL);
						}
						if (casoTO.getTipoCaso() != null) {
							stmt.setString(5, casoTO.getTipoCaso());
						} else {
							stmt.setNull(5, Types.NULL);
						}
						if (casoTO.getIdConfiguracaoFila() != null) {
							stmt.setInt(6, casoTO.getIdConfiguracaoFila());
						} else {
							stmt.setNull(6, Types.NULL);
						}
						if (casoTO.getConfiguracaoFila() != null) {
							stmt.setString(7, casoTO.getConfiguracaoFila());
						} else {
							stmt.setNull(7, Types.NULL);
						}
						stmt.setDouble(8, casoTO.getPercentual());
						stmt.setInt(9, casoTO.getIdOperacao());
						stmt.setString(10, new SimpleDateFormat("yyyy-MM-dd").format(casoTO.getDataProcessamento()));
						stmt.addBatch();

						if (++count % Constantes.BATCH_SIZE == 0) {
							stmt.executeBatch();
							connection.commit();
						}

					}

				}

				stmt.executeBatch();
				connection.commit();

			} catch (Exception e) {
				StringBuilder str = new StringBuilder();

				str.append("Erro ao inserir detalhe. Caso: ").append(casoTO.getIdCaso()).append(" - Id Externo: ").append(casoTO.getIdExterno()).append(" - Operacao: ").append(casoTO.getIdOperacao());

				logger.log(Level.SEVERE, str.toString());

				throw e;
			}

		} finally {
			if (connection != null) {
				connection.close();
			}
		}
	}

	public List<CasoAbertoCockpitTO> getListCasoAberto(Date dataBanco) throws Exception {

		String query = "Select id_caso_aberto_cockpit,nome_fila_atendimento,tipo_manifestacao,data_processamento,flag_fila,qtd_primeiro_dia,percentual_primeiro_dia,qtd_segundo_dia,percentual_segundo_dia,qtd_terceiro_dia,percentual_terceiro_dia,qtd_quarto_dia,percentual_quarto_dia,qtd_quinto_dia,percentual_quinto_dia,qtd_sexto_dia,percentual_sexto_dia,qtd_restante_dia,percentual_restante_dia,qtd_total,percentual_total,id_operacao from tb_caso_aberto_cockpit where data_processamento=?";

		List<CasoAbertoCockpitTO> list = null;

		try {

			PreparedStatement ps = super.getPreparedStatement(query);
			ps.setFetchSize(100);

			ps.setDate(1, new java.sql.Date(dataBanco.getTime()));

			ResultSet rs = ps.executeQuery();

			if (rs != null) {
				list = new ArrayList<CasoAbertoCockpitTO>();
				while (rs.next()) {
					CasoAbertoCockpitTO casoAbertoCockpitTO = new CasoAbertoCockpitTO();
					casoAbertoCockpitTO.setIdCasoAbertoCockpit(rs.getInt("id_caso_aberto_cockpit"));
					casoAbertoCockpitTO.setNomeFilaAtendimento(rs.getString("nome_fila_atendimento"));
					casoAbertoCockpitTO.setTipoCaso(rs.getString("tipo_manifestacao"));
					casoAbertoCockpitTO.setDataProcessamento(rs.getDate("data_processamento"));
					casoAbertoCockpitTO.setFlagFila(rs.getBoolean("flag_fila"));
					casoAbertoCockpitTO.setQtdPrimeiroDia(rs.getInt("qtd_primeiro_dia"));
					casoAbertoCockpitTO.setPercentualPrimeiroDia(rs.getString("percentual_primeiro_dia"));
					casoAbertoCockpitTO.setQtdSegundoDia(rs.getInt("qtd_segundo_dia"));
					casoAbertoCockpitTO.setPercentualSegundoDia(rs.getString("percentual_segundo_dia"));
					casoAbertoCockpitTO.setQtdTerceiroDia(rs.getInt("qtd_terceiro_dia"));
					casoAbertoCockpitTO.setPercentualTerceiroDia(rs.getString("percentual_terceiro_dia"));
					casoAbertoCockpitTO.setQtdQuartoDia(rs.getInt("qtd_quarto_dia"));
					casoAbertoCockpitTO.setPercentualQuartoDia(rs.getString("percentual_quarto_dia"));
					casoAbertoCockpitTO.setQtdQuintoDia(rs.getInt("qtd_quinto_dia"));
					casoAbertoCockpitTO.setPercentualQuintoDia(rs.getString("percentual_quinto_dia"));
					casoAbertoCockpitTO.setQtdSextoDia(rs.getInt("qtd_sexto_dia"));
					casoAbertoCockpitTO.setPercentualSextoDia(rs.getString("percentual_sexto_dia"));
					casoAbertoCockpitTO.setQtdRestanteDia(rs.getInt("qtd_restante_dia"));
					casoAbertoCockpitTO.setPercentualRestanteDia(rs.getString("percentual_restante_dia"));
					casoAbertoCockpitTO.setQtdTotal(rs.getInt("qtd_total"));
					casoAbertoCockpitTO.setPercentualTotal(rs.getString("percentual_total"));
					casoAbertoCockpitTO.setIdOperacao(rs.getInt("id_operacao"));
					list.add(casoAbertoCockpitTO);
				}
			}

			return list;

		} catch (Exception e) {
			StringBuilder str = new StringBuilder();
			str.append("Erro getListCasoAberto: ");
			logger.log(Level.SEVERE, str.toString());

			throw e;
		} finally {
			super.closeConnection();
		}
	}

}
