package br.com.callink.cad.dao;

import java.io.File;
import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import br.com.callink.cad.to.CampoDinamicoTO;
import br.com.callink.cad.to.CamposFiltroCasoEnum;
import br.com.callink.cad.to.CasoFindTO;
import br.com.callink.cad.to.CasoTO;
import br.com.callink.cad.to.ConfiguracaoAcaoAutomaticaTO;
import br.com.callink.cad.to.DadosDinamicos;
import br.com.callink.cad.to.ExportaCasoSchedulerDataTO;
import br.com.callink.cad.to.FiltroCasoCampoTO;
import br.com.callink.cad.to.FiltroDadosDinamicosTO;
import br.com.callink.cad.to.SchedulerDateType;
import br.com.callink.cad.to.SlaFilaTO;
import br.com.callink.cad.to.TipoCampoDinamico;
import br.com.callink.cad.util.DateUtils;
import br.com.callink.cad.util.QueryExpurgoDadosEnum;
import br.com.callink.cad.util.StringUtils;

public class CasoDAO extends GenericDAO {

	private static final String RESULT_SET_KEY = "NOME_ANEXO";
	private static final String QUERY_ANEXO = "select anexo.nome_fake as 'NOME_ANEXO' from tb_email email inner join tb_log logg with(nolock)on logg.id_email = email.id_email inner join tb_grupo_anexo grupoAnexo with(nolock) on grupoAnexo.id_grupo_anexo = email.id_grupo_anexo inner join tb_anexo anexo with(nolock)on anexo.id_grupo_anexo =grupoAnexo.id_grupo_anexo where id_caso IN(?)";
	private static final String ID_CASO = "ID_CASO";
	private static final String DB_CAD_REPORT = "DB_CAD_REPORT";
	private Logger logger = Logger.getLogger(CasoDAO.class.getName());
	private static final String QUERY_RETURN_CASE_CLOSED = "SELECT ID_CASO FROM TB_CASO WHERE DATA_ENCERRAMENTO <= ? AND ID_OPERACAO = ?";
	private static final String COL_FIELD_DYNAMICS = "(COL";
	private static final String LIMITE_BUSCA_CASOS = "10000";

	public CasoTO findById(Integer idCaso) throws Exception {
		try {
			CasoTO caso = null;

			StringBuilder sql = new StringBuilder();
			sql.append(SELECT);
			sql.append(CasoTO.getSqlColuns());
			sql.append(CasoTO.getSqlFrom());
			sql.append(WHERE);
			sql.append(" Caso.ID_CASO = ? ");

			PreparedStatement ps = super.getPreparedStatement(sql.toString());

			ps.setInt(1, idCaso);
			ResultSet rs = ps.executeQuery();

			if (rs != null) {
				while (rs.next()) {
					caso = CasoTO.getCasoTOByResultSet(rs);
				}
			}
			return caso;
		} catch (Exception e) {
			StringBuilder str = new StringBuilder();
			
			str.append("Erro ao buscar caso pelo ID: ").append(idCaso);
			
			logger.log(Level.SEVERE, str.toString());
			
			throw e;
		} finally {
			super.closeConnection();
		}
	}

	public List<Integer> findByDateFinally(Integer quantidadeDias, Integer idOperacao) throws Exception {
		try {
			String sql = QUERY_RETURN_CASE_CLOSED;
			List<Integer> ids = new ArrayList<Integer>();
			PreparedStatement ps = super.getPreparedStatement(sql);
	
			ps.setDate(1, new java.sql.Date(DateUtils.returnDateForDays(quantidadeDias).getTime()));
			ps.setInt(2, idOperacao);
	
			ResultSet rs = ps.executeQuery();
	
			if (rs != null) {
				while (rs.next()) {
					Integer id = rs.getInt(ID_CASO);
					ids.add(id);
				}
			}
			return ids;
		} catch (Exception e) {
			StringBuilder str = new StringBuilder();
			
			str.append("Erro ao buscar casos finalizados. Dias: ").append(quantidadeDias);
			
			logger.log(Level.SEVERE, str.toString());
			
			throw e;
		} finally {
			super.closeConnection();
		}
	}

	
	public boolean existeCasoDetalhe(Integer idCaso) throws Exception {
		try {
			
			StringBuilder sq = new StringBuilder();
			sq.append(" select top 1 * from tb_caso_detalhe where id_caso = ? ");
			
			PreparedStatement p = getPreparedStatement(sq.toString());
			p.setInt(1, idCaso);
			ResultSet res = p.executeQuery();

			while (res.next()) {
				return true;
			}
		} catch (Exception e) {
			StringBuilder str = new StringBuilder();
			
			str.append("Erro ao verificar se existe caso. Caso: ").append(idCaso);
			
			logger.log(Level.SEVERE, str.toString());
			
			throw e;
		} finally {
			super.closeConnection();
		}
		return false;
	}
	
	
	
	public void realizaExpurgo(List<Integer> cases, String schemaDB, Integer quantidadeDias, Integer idOperacao) throws Exception {
		try {
			if (cases != null) {

				for (Integer id : cases) {
					for (QueryExpurgoDadosEnum item : QueryExpurgoDadosEnum.values()) {
						PreparedStatement ps = null;
						logger.info("=> Realizando expurgo dados: " + item.toString());
						if (item.getQuery().contains(DB_CAD_REPORT)) {
							logger.info("=> Alterando esquema do banco de dados");
							ps = super.getPreparedStatement(item.getQuery().replace(DB_CAD_REPORT, schemaDB));

						} else {
							ps = super.getPreparedStatement(item.getQuery());
						}
						if (item.getIsPeriodo()) {
							logger.info("=> Expurgo por periodo");
							ps.setDate(1, new java.sql.Date(DateUtils.returnDateForDays(quantidadeDias).getTime()));
							ps.setInt(2, idOperacao);
							ps.execute();
						} else {
							ps.setInt(1, id);
							ps.execute();
							
						}
					}
				}
			} else {
				for (QueryExpurgoDadosEnum item : QueryExpurgoDadosEnum.values()) {
					if (item.getIsPeriodo()) {
						logger.info("=> Expurgo por periodo");
						PreparedStatement ps = null;
						if (item.getQuery().contains(DB_CAD_REPORT)) {
							logger.info("=> Alterando esquema do banco de dados");
							ps = super.getPreparedStatement(item.getQuery().replace(DB_CAD_REPORT, schemaDB));
						} else {
							ps = super.getPreparedStatement(item.getQuery());
						}
						ps.setDate(1, new java.sql.Date(DateUtils.returnDateForDays(quantidadeDias).getTime()));
						ps.setInt(2, idOperacao);
						ps.execute();
					}
				}
			}
		} catch (Exception e) {
			StringBuilder str = new StringBuilder();
			
			str.append("Erro ao realizar expurgo: ")
			.append(" - Schema: ").append(schemaDB)
			.append(" - Quantidade de dias: ").append(quantidadeDias);
			
			logger.log(Level.SEVERE, str.toString());
			
			throw e;
		} finally {
			super.closeConnection();
		}
	}
	
	
	public void deleteArchivesByCase(List<Integer> casos,String diretorioAnexo) throws Exception{
		
			String sql = QUERY_ANEXO;
			
			List<String> archives = new ArrayList<String>();
			PreparedStatement ps = super.getPreparedStatement(sql);
	
			ps.setString(1, configureParam(casos.toString()));
	
			ResultSet rs = ps.executeQuery();
	
			if (rs != null) {
				while (rs.next()) {
					String name = rs.getString(RESULT_SET_KEY);
					archives.add(name);
				}
			}
			for (String item : archives) {
				new File(diretorioAnexo +"\\"+ item).delete();
			}
	}
	
	
	private String configureParam(String item) {
		return item.replace(",", "','").replace("]", "'").replace("[", "'");
	}
	
	public void insertLogExecution(Integer idCaso,Integer parametro) throws Exception {
		try {
			StringBuilder sql = new StringBuilder();
			sql.append(INSERT);
			sql.append("TB_EXPURGO_DADOS");
			sql.append(" VALUES ");
			sql.append(" (?,GETDATE(),?) ");

			PreparedStatement ps = super.getPreparedStatement(sql.toString());

			ps.setInt(1, idCaso);
			ps.setInt(2, parametro);
			ps.execute();
		} catch (Exception e) {
			StringBuilder str = new StringBuilder();
			
			str.append("Erro ao inserir log. Caso: ").append(idCaso)
			.append(" - Parametro: ").append(parametro);
			
			logger.log(Level.SEVERE, str.toString());
			
			throw e;
		} finally {
			super.closeConnection();
		}
	}
	
	public Integer reabreCaso(Integer idCaso, Integer idStatus, Date dataAlteracao) throws Exception {
		try {
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			
			StringBuilder sql = new StringBuilder();
			sql.append("UPDATE tb_caso ");
			sql.append("SET data_encerramento = null ");
			sql.append("  , data_fim_sla = null ");
			sql.append("  , id_causa = null ");
			sql.append("  , flag_em_atendimento = 0 ");
			sql.append("  , flag_finalizado = 0 ");
			sql.append("  , flag_reaberto = 1 ");
			sql.append("  , flag_classifica = 1 ");
			sql.append("  , flag_reclassifica_reabertura = 1 ");
			sql.append("  , sla_minutos = null ");
			sql.append("  , sla_total = null ");
			sql.append("  , percentual_sla = null ");
			sql.append("  , id_status = ? ");
			sql.append("  , data_alteracao = ? ");
			sql.append("WHERE id_caso = ? ");
			sql.append("AND data_encerramento IS NOT NULL ");
			sql.append("AND data_fim_sla IS NOT NULL ");
			sql.append("AND flag_finalizado = 1 ");
			
			PreparedStatement ps = super.getPreparedStatement(sql.toString());

			ps.setInt(1, idStatus);
			ps.setString(2, df.format(dataAlteracao));
			ps.setInt(3, idCaso);
			
			return ps.executeUpdate();
		} catch (Exception e) {
			StringBuilder str = new StringBuilder();
			
			str.append("Erro ao reabrir caso. Caso: ").append(idCaso)
			.append(" - Data: ").append(dataAlteracao)
			.append(" - Status: ").append(idStatus);
			
			logger.log(Level.SEVERE, str.toString());
			
			throw e;
		} finally {
			super.closeConnection();
		}
	}
	
	public Integer finalizaCaso(Integer idCaso, Integer idStatus, Date dataAlteracao) throws Exception {
		try {
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			
			StringBuilder sql = new StringBuilder();
			sql.append("UPDATE tb_caso ");
			sql.append("SET id_status = ? ");
			sql.append("  , id_causa = (SELECT min(id_causa)  ");
			sql.append("  				FROM tb_evento_causa with(nolock)  ");
			sql.append("  				WHERE finaliza_caso = 1  ");
			sql.append("  				AND id_evento = (SELECT tc.id_evento  ");
			sql.append("  				    		  	 FROM tb_tipo_caso tc with(nolock)  ");
			sql.append("  				    		  	 WHERE tc.id_tipo_caso = (select id_tipo_caso from tb_caso with(nolock) where id_caso = ?) ) ) ");
			sql.append("  , flag_finalizado = 1 ");
			sql.append("  , flag_em_atendimento = 0 ");
			sql.append("  , id_usuario = NULL ");
			sql.append("  , data_fim_sla = ? ");
			sql.append("  , data_encerramento = ? ");
			sql.append("  , data_alteracao = ? ");
			sql.append("WHERE id_caso = ? ");
			sql.append("AND data_encerramento IS NULL ");
			sql.append("AND data_fim_sla IS NULL ");
			sql.append("AND (flag_finalizado IS NULL OR flag_finalizado = 0) ");
			
			PreparedStatement ps = super.getPreparedStatement(sql.toString());

			ps.setInt(1, idStatus);
			ps.setInt(2, idCaso);
			ps.setString(3, df.format(dataAlteracao));
			ps.setString(4, df.format(dataAlteracao));
			ps.setString(5, df.format(dataAlteracao));
			ps.setInt(6, idCaso);
			
			return ps.executeUpdate();
		} catch (Exception e) {
			StringBuilder str = new StringBuilder();
			
			str.append("Erro ao finalizar caso. Caso: ").append(idCaso)
			.append(" - Data: ").append(dataAlteracao)
			.append(" - Status: ").append(idStatus);
			
			logger.log(Level.SEVERE, str.toString());
			
			throw e;
		} finally {
			super.closeConnection();
		}
	}
	
	public Integer reclassificaCaso(Integer idCaso, Date dataAlteracao) throws Exception {
		try {
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			
			StringBuilder sql = new StringBuilder();
			sql.append("UPDATE tb_caso ");
			sql.append("SET id_configuracao_fila = null ");
			sql.append("  , flag_classifica = 1 ");
			sql.append("  , id_usuario = null ");
			sql.append("  , data_alteracao = ? ");
			sql.append("WHERE id_caso = ? ");
			sql.append("AND data_encerramento IS NULL ");
			sql.append("AND (flag_finalizado IS NULL OR flag_finalizado = 0) ");
			
			PreparedStatement ps = super.getPreparedStatement(sql.toString());

			ps.setString(1, df.format(dataAlteracao));
			ps.setInt(2, idCaso);

			return ps.executeUpdate();
		} catch (Exception e) {
			StringBuilder str = new StringBuilder();
			
			str.append("Erro ao reclassificar caso. Caso: ").append(idCaso)
			.append(" - Data: ").append(dataAlteracao);
			
			logger.log(Level.SEVERE, str.toString());
			
			throw e;
		} finally {
			super.closeConnection();
		}
	}
	
	public Integer retornaCasoPraFila(Integer idCaso, Date dataAlteracao) throws Exception {
		try {
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			
			StringBuilder sql = new StringBuilder();
			sql.append("UPDATE tb_caso ");
			sql.append("SET id_usuario = null ");
			sql.append("  , data_alteracao = ? ");
			sql.append("WHERE id_caso = ? ");
			sql.append("AND data_encerramento IS NULL ");
			sql.append("AND (flag_finalizado IS NULL OR flag_finalizado = 0) ");
			
			PreparedStatement ps = super.getPreparedStatement(sql.toString());

			ps.setString(1, df.format(dataAlteracao));
			ps.setInt(2, idCaso);
			
			return ps.executeUpdate();
		} catch (Exception e) {
			StringBuilder str = new StringBuilder();
			
			str.append("Erro ao retornar casos para fila. Caso: ").append(idCaso)
			.append(" - Data: ").append(dataAlteracao);
			
			logger.log(Level.SEVERE, str.toString());
			
			throw e;
		} finally {
			super.closeConnection();
		}
	}
	
	public List<Integer> buscaIdsEventosAscendentes(Integer idEvento) throws Exception {
		try {
			List<Integer> idsEventos = new ArrayList<Integer>();
			
			StringBuilder sql = new StringBuilder();
			sql.append(" WITH arvore (idEvento,idEventoPai,nivel) ");
			sql.append(" AS ( ");
			sql.append(" 	SELECT e.id_evento, e.id_evento_pai, 0 AS nivel ");
			sql.append(" 	FROM tb_evento e ");
			sql.append(" 	WHERE e.id_evento = ? ");
			sql.append(" 	UNION ALL ");
			sql.append(" 	SELECT e.id_evento, e.id_evento_pai, cte.nivel + 1 ");
			sql.append(" 	FROM arvore cte, tb_evento e ");
			sql.append(" 	WHERE e.id_evento = cte.idEventoPai ");
			sql.append(" ) ");
			sql.append(" SELECT idEvento as ID_EVENTO FROM arvore ");
			sql.append(" order by idEvento asc ");
			
			PreparedStatement ps = super.getPreparedStatement(sql.toString());

			ps.setInt(1, idEvento);
			
			ResultSet rs = ps.executeQuery();

			if (rs != null) {
				while (rs.next()) {
					Integer idEvt = (Integer) rs.getObject("ID_EVENTO");
					idsEventos.add(idEvt);
				}
			}
			return idsEventos;
		} catch (Exception e) {
			StringBuilder str = new StringBuilder();
			
			str.append("Erro ao buscar buscaIdsEventosAscendentes: ").append(idEvento);
			
			logger.log(Level.SEVERE, str.toString());
			
			throw e;
		} finally {
			super.closeConnection();
		}
	}
	
	public Integer alteraValoresCaso(String query) throws Exception {
		try {
			PreparedStatement p = getPreparedStatement(query);
			return p.executeUpdate();
		} catch (Exception e) {
			StringBuilder str = new StringBuilder();
			
			str.append("Erro ao alterar os valores do caso: ").append(query);
			
			logger.log(Level.SEVERE, str.toString());
			
			throw e;			
		} finally {
			super.closeConnection();
		}
	}

	public Integer consultaIdExistente(String query) throws Exception {
		
		Integer codigoTabela = 0;
		try {
			PreparedStatement p = getPreparedStatement(query);
			ResultSet res = p.executeQuery(query);

			while (res.next()) {
				codigoTabela = res.getInt("id_tabela");
				return codigoTabela;
			}
		} catch (Exception e) {
			StringBuilder str = new StringBuilder();
			
			str.append("Erro ao consultar id Existente com a query: ").append(query);
			
			logger.log(Level.SEVERE, str.toString());
			
			throw e;
		} finally {
			super.closeConnection();
		}
		return codigoTabela;
	}
	
	
	public Integer updateIdExterno(Integer idCaso) throws Exception {
	
		try {
			StringBuilder sq = new StringBuilder();
			sq.append(" update tb_caso set id_externo = ? ");
			sq.append(" where id_caso = ? ");
			
			PreparedStatement p = getPreparedStatement(sq.toString());
			p.setString(1, String.valueOf(idCaso));
			p.setInt(2, idCaso);
			p.executeUpdate();
		} catch (Exception e) {
			StringBuilder str = new StringBuilder();
			
			str.append("Erro ao executar update no caso: ").append(idCaso);
			
			logger.log(Level.SEVERE, str.toString());
			
			throw e;
		} finally {
			super.closeConnection();
		}
		return 0;
	}
	
	public Integer insereCaso(CasoTO caso) throws Exception {
		try {
		
		    StringBuilder sq = new StringBuilder();
		    
		    sq.append( " insert into TB_CASO (ID_CANAL, ID_CASO_PAI, ID_CAUSA, CLASSIFICACAO_COUNT, ID_CONFIGURACAO_FILA, " );
		    sq.append( " DATA_ABERTURA, DATA_CADASTRO, DATA_ENCERRAMENTO, DATA_FIM_SLA, DATA_PREVISTA_FIM_SLA, " ); 
		    sq.append( " DESCRICAO, EDICAO_TELEFONE_COUNT, ID_EVENTO, FLAG_CLASSIFICA, FLAG_CRIADO_MANUAL, FLAG_EM_ATENDIMENTO, " ); 
		    sq.append( " FLAG_FINALIZADO, FLAG_REABERTO, FLAG_RECLASSIFICA_REABERTURA, FLAG_TELEFONE_EDITADO, ID_EXTERNO, ID_JUNCAO, " ); 
		    sq.append( " MOTIVO_1, MOTIVO_1_NOME, MOTIVO_2, MOTIVO_2_NOME, MOTIVO_3, MOTIVO_3_NOME, MOTIVO_4, MOTIVO_4_NOME, MOTIVO_5, " ); 
		    sq.append( " MOTIVO_5_NOME, MOTIVO_6, MOTIVO_6_NOME, ID_OPERACAO, ID_OUTRA_AREA, ID_SLA_FILA, ID_STATUS, ID_TIPO_CASO, ID_USUARIO, " ); 
		    sq.append( " DISCRIMINATOR) " );
		    sq.append( " values (?, ?, ?, ?, ?, ?, ?, "); 
		    sq.append( " ?, ?, ?, ?, ?, ?, ?, ?, "); 
		    sq.append( " ?, ?, ?, ?, ?, ?, ?, ?, ");
		    sq.append( " ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ");
		    sq.append( " ?, ?, ?, ?, ?, ?, 'C') ");
	
		    PreparedStatement p = getPreparedStatementId(sq.toString());
		    
		    if(caso.getIdCanal() != null ){
		    	p.setInt(1,caso.getIdCanal() );
		    } else {
		    	p.setNull(1, Types.NULL );
		    }
		    
		    if(caso.getIdCasoPai() != null) {
		    	p.setInt(2,caso.getIdCasoPai());
		    } else {
		    	p.setNull(2,Types.NULL);
		    }
		    
		    if(caso.getIdCausa() != null) {
		    	p.setInt(3, caso.getIdCausa());
		    } else {
		    	p.setNull(3, Types.NULL);
		    }
		    p.setInt(4, caso.getClassificacaoCount() != null ? caso.getClassificacaoCount() : Types.NULL);
		    
		    if(caso.getIdConfiguracaoFila() != null ) {
		    	p.setInt(5, caso.getIdConfiguracaoFila());
		    } else {
		    	p.setNull(5, Types.NULL);
		    }

		    if(caso.getDataAbertura() != null) {
		    	p.setTimestamp(6,new Timestamp(caso.getDataAbertura().getTime()));
		    } else {
		    	p.setNull(6, Types.NULL);
		    }
		    
		    if(caso.getDataCadastro() != null) {
		    	p.setTimestamp(7,new Timestamp(caso.getDataCadastro().getTime()));
		    } else {
		    	p.setNull(7, Types.NULL);
		    }
		    
		    if(caso.getDataEncerramento() != null) {
		    	p.setTimestamp(8,new Timestamp(caso.getDataEncerramento().getTime()));
		    } else {
		    	p.setNull(8, Types.NULL);
		    }
		    
		    if(caso.getDataFimSla() != null) {
		    	p.setTimestamp(9,new Timestamp(caso.getDataFimSla().getTime()));
		    } else {
		    	p.setNull(9, Types.NULL);
		    }
		    
		    if(caso.getDataPrevistaFimSla() != null) {
		    	p.setTimestamp(10,new Timestamp(caso.getDataPrevistaFimSla().getTime()));
		    } else {
		    	p.setNull(10, Types.NULL);
		    }
		    
		    if( caso.getDescricao() != null ) {
		    	p.setString(11,caso.getDescricao() );
		    } else {
		    	p.setNull(11, Types.NULL);
		    }
		    
		    p.setInt(12, caso.getEdicaoTelefoneCount() !=  null ? caso.getEdicaoTelefoneCount() : 0 );
		    
		    if(caso.getIdEvento() != null) {
		    	p.setInt(13, caso.getIdEvento() );
		    } else {
		    	p.setNull(13, Types.NULL);
		    }
		    p.setBoolean(14, caso.isFlagClassifica());
		    p.setBoolean(15, caso.getFlagCriadoManual() != null ? caso.getFlagCriadoManual() : Boolean.FALSE);
		    p.setBoolean(16, caso.getFlagEmAtendimento() != null ? caso.getFlagEmAtendimento() : Boolean.FALSE);
		    p.setBoolean(17, caso.isFlagFinalizado());
		    p.setBoolean(18, caso.getFlagReaberto() != null ? caso.getFlagReaberto() : Boolean.FALSE);
		    p.setBoolean(19, caso.isFlagReclassificaReabertura());
		    p.setBoolean(20, caso.getFlagTelefoneEditado() != null ? caso.getFlagTelefoneEditado() : Boolean.FALSE);
	        
		    if(caso.getIdExterno() != null) {
		    	p.setString(21, caso.getIdExterno());
		    } else  {
		    	p.setNull(21, Types.NULL);
		    }
	        
	        if(caso.getIdJuncao() != null) {
	        	p.setInt(22,  caso.getIdJuncao() );
	        } else {
	        	p.setNull(22,  Types.NULL );
	        }
	        p.setInt(23,caso.getMotivo1() != null ? caso.getMotivo1() : Types.NULL);
	        p.setString(24,caso.getMotivo1Nome());
	        p.setInt(25,caso.getMotivo2() != null ? caso.getMotivo2() : Types.NULL);
	        p.setString(26,caso.getMotivo2Nome());
	        p.setInt(27,caso.getMotivo3() != null ? caso.getMotivo3() : Types.NULL);
	        p.setString(28,caso.getMotivo3Nome());
	        p.setInt(29, caso.getMotivo4() != null ? caso.getMotivo4() : Types.NULL);
	        p.setString(30,caso.getMotivo4Nome());
	        p.setInt(31,caso.getMotivo5() != null ? caso.getMotivo5() : Types.NULL);
	        p.setString(32,caso.getMotivo5Nome());
	        p.setInt(33,caso.getMotivo6() != null ? caso.getMotivo6() : Types.NULL);
	        p.setString(34,caso.getMotivo6Nome());
	       
	        
	        p.setInt(35, caso.getIdOperacao() != null ? caso.getIdOperacao() : Types.NULL);
	        
	        if(caso.getIdOutraArea() != null) {
	        	p.setInt(36, caso.getIdOutraArea());	
	        } else {
	         	p.setNull(36, Types.NULL);
	        }
	        
	        if(caso.getIdSlaFila() != null) {
	        	p.setInt(37, caso.getIdSlaFila() );
	        } else {
	        	p.setNull(37, Types.NULL );
	        }
	        
	        if(caso.getIdStatus() != null) {
	        	p.setInt(38, caso.getIdStatus());
	        } else {
	        	p.setNull(38, Types.NULL);
	        }
	        
	        if(caso.getIdTipoCaso() != null) {
	        	p.setInt(39, caso.getIdTipoCaso());
	        } else {
	        	p.setNull(39,Types.NULL );
	        }
	        
	        if(caso.getIdUsuario() != null) {
	        	p.setInt(40, caso.getIdUsuario());
	        } else {
	        	p.setNull(40, Types.NULL);
	        }
	        
	        int res = p.executeUpdate();
	        
            
	        if(res ==1) {
	        	ResultSet rs = p.getGeneratedKeys();
	            if (rs != null && rs.next()) {
	                caso.setIdCaso(rs.getInt(1));
	            }
	        }
			return res;
			
		} finally {
			super.closeConnection();
		}
	}
	
	public List<CasoTO> findCasosByFiltrosConfiguracaoTempo(ConfiguracaoAcaoAutomaticaTO configuracao, StringBuilder filtroData)
				throws Exception {
		List<CasoTO> casosTO = new ArrayList<CasoTO>();
		try {
			StringBuilder sql = new StringBuilder();
			sql.append(SELECT);
			sql.append(CasoTO.getSqlColuns());
			sql.append(CasoTO.getSqlFrom());
			sql.append(" LEFT JOIN TB_CASO_DETALHE AS CasoDetalhe with(nolock) ");
			sql.append("  ON CasoDetalhe.ID_CASO = Caso.ID_CASO ");
			sql.append(WHERE);
			sql.append(" Caso.ID_OPERACAO = ? ");
			
			if (configuracao.getIdTipoCasoFiltro() != null) {
				sql.append(" AND Caso.ID_TIPO_CASO = ").append(configuracao.getIdTipoCasoFiltro());
			}
			if (configuracao.getIdStatusFiltro() != null) {
				sql.append(" AND Caso.ID_STATUS = ").append(configuracao.getIdStatusFiltro());
			}
			
			if (configuracao.getIdEventoFiltro() != null) {
				sql.append(" AND (Caso.MOTIVO_1 = ").append(configuracao.getIdEventoFiltro());
				sql.append("   OR Caso.MOTIVO_2 = ").append(configuracao.getIdEventoFiltro());
				sql.append("   OR Caso.MOTIVO_3 = ").append(configuracao.getIdEventoFiltro());
				sql.append("   OR Caso.MOTIVO_4 = ").append(configuracao.getIdEventoFiltro());
				sql.append("   OR Caso.MOTIVO_5 = ").append(configuracao.getIdEventoFiltro());
				sql.append("   OR Caso.MOTIVO_6 = ").append(configuracao.getIdEventoFiltro()).append(")");
			}
			
			sql.append(" AND ").append(filtroData);
			
			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			
			ps.setInt(1, configuracao.getIdOperacao());
	
			ResultSet rs = ps.executeQuery();
	
			if (rs != null) {
				while (rs.next()) {
					CasoTO casoTO = CasoTO.getCasoTOByResultSet(rs);
					casosTO.add(casoTO);
				}
			}
		} catch (Exception e) {
			
			StringBuilder str = new StringBuilder();
			str.append("Erro ao buscar os casos para a configuração automatica: ");
			if (configuracao != null) {
				str.append("ID Fila: ").append(configuracao.getIdConfiguracaoAcaoAutomatica()).append(" - Tipo Caso: ")
				.append(configuracao.getIdTipoCasoFiltro()).append(" - Status: ").append(configuracao.getIdStatusFiltro())
				.append(" - Motivo: ").append(configuracao.getIdEventoFiltro());
			}
			if (filtroData != null) {
				str.append(" com o filtro de data: ").append(filtroData.toString());
			}
			logger.log(Level.SEVERE, str.toString());
			
			throw e;
			
		} finally {
			super.closeConnection();
		}
		return casosTO;
	}
	
	public List<CasoTO> buscaPorFiltroSQL(CasoFindTO casoFind) throws Exception {
		List<CasoTO> casos = new ArrayList<CasoTO>();
		try {
			StringBuilder select = new StringBuilder();
			select.append(" SELECT distinct TOP ").append(LIMITE_BUSCA_CASOS);
			select.append(" caso.id_caso AS 'id_caso', ");
			select.append(" 	caso.id_externo AS 'id_externo', ");
			select.append(" 	caso.data_abertura AS 'data_abertura', ");
			select.append(" 	caso.data_encerramento AS 'data_encerramento', ");
			select.append(" 	caso.data_fim_sla AS 'data_fim_sla', ");
			select.append(" 	caso.data_prevista_fim_sla AS 'data_prevista_fim_sla', ");
			select.append(" 	caso.data_cadastro AS 'data_cadastro', ");
			select.append(" 	caso.flag_reaberto AS 'flag_reaberto', ");
			select.append(" 	caso.flag_finalizado AS 'flag_finalizado', ");
			select.append(" 	caso.flag_classifica AS 'flag_classifica', ");
			select.append("   	caso.flag_em_atendimento AS 'flag_em_atendimento', ");
			select.append(" 	caso.motivo_1 AS 'motivo_1', ");
			select.append(" 	caso.motivo_1_nome AS 'motivo_1_nome', ");
			select.append(" 	caso.motivo_2 AS 'motivo_2', ");
			select.append(" 	caso.motivo_2_nome AS 'motivo_2_nome', ");
			select.append(" 	caso.motivo_3 AS 'motivo_3', ");
			select.append(" 	caso.motivo_3_nome AS 'motivo_3_nome', ");
			select.append(" 	caso.motivo_4 AS 'motivo_4', ");
			select.append(" 	caso.motivo_4_nome AS 'motivo_4_nome', ");
			select.append(" 	caso.motivo_5 AS 'motivo_5', ");
			select.append(" 	caso.motivo_5_nome AS 'motivo_5_nome', ");
			select.append(" 	caso.motivo_6 AS 'motivo_6', ");
			select.append(" 	caso.motivo_6_nome AS 'motivo_6_nome', ");
			select.append(" 	caso.descricao AS 'descricao', ");
			select.append(" 	caso.classificacao_count AS 'classificacao_count', ");
			select.append(" 	caso.edicao_telefone_count AS 'edicao_telefone_count', ");
			select.append(" 	caso.percentual_sla AS 'percentual_sla', ");
			select.append(" 	caso.sla_minutos AS 'sla_minutos', ");
			select.append(" 	caso.sla_total AS 'sla_total', ");
			select.append(" 	caso.id_caso_pai AS 'id_caso_pai', ");
			select.append(" 	caso.id_usuario_sugerido AS 'id_usuario_sugerido', ");
			select.append(" 	caso.data_alteracao AS 'data_alteracao', ");
			select.append(" 	caso.flag_criado_manual AS 'flag_criado_manual', ");
			select.append(" 	caso.flag_reclassifica_reabertura AS 'flag_reclassifica_reabertura', ");
			select.append(" 	caso.flag_telefone_editado AS 'flag_telefone_editado', ");
			select.append(" 	juncao.id_juncao AS 'id_juncao', ");
			select.append(" 	juncao.nome AS 'juncao', ");
			select.append(" 	operacao.id_operacao AS 'id_operacao', ");
			select.append(" 	operacao.nome AS 'operacao', ");
			select.append(" 	slaFila.id_sla_fila AS 'id_sla_fila', ");
			select.append(" 	canal.id_canal AS 'id_canal', ");
			select.append(" 	canal.nome AS 'canal', ");
			select.append(" 	tipoCaso.id_tipo_caso AS 'id_tipo_caso', ");
			select.append(" 	tipoCaso.nome AS 'tipo_caso', ");
			select.append(" 	usuario.id_usuario AS 'id_usuario', ");
			select.append(" 	usuario.login AS 'login', ");
			select.append(" 	status.id_status AS 'id_status', ");
			select.append(" 	status.nome AS 'status', ");
			select.append(" 	status.cor AS 'cor', ");
			select.append(" 	evento.id_evento AS 'id_evento', ");
			select.append(" 	evento.nome AS 'evento', ");
			select.append(" 	causa.id_causa AS 'id_causa', ");
			select.append(" 	causa.nome AS 'causa', ");
			select.append(" 	outraArea.id_outra_area AS 'id_outra_area', ");
			select.append(" 	outraArea.nome AS 'outra_area', ");
			select.append(" 	fila.id_configuracao_fila AS 'id_configuracao_fila', ");
			select.append(" 	fila.nome AS 'configuracao_fila', ");
			select.append(" 	loteCaso.id_lote_caso AS 'id_lote_caso', ");
			select.append(" 	loteCaso.nome_arquivo AS 'nome_arquivo' ");
			select.append(" FROM TB_CASO_DETALHE casodetalhe ");
			select.append(" RIGHT OUTER JOIN TB_CASO caso  ON caso.id_caso = casodetalhe.id_caso ");
			select.append(" INNER JOIN TB_STATUS status  ON caso.id_status = status.id_status ");
			select.append(" INNER JOIN TB_OPERACAO operacao  ON caso.id_operacao = operacao.id_operacao ");
			select.append(" LEFT OUTER JOIN TB_USUARIO usuario  ON caso.id_usuario = usuario.id_usuario ");
			select.append(" LEFT OUTER JOIN TB_TIPO_CASO tipoCaso  ON caso.id_tipo_caso = tipoCaso.id_tipo_caso ");
			select.append(" LEFT OUTER JOIN TB_CANAL canal  ON caso.id_canal = canal.id_canal ");
			select.append(" LEFT OUTER JOIN TB_CAUSA causa  ON caso.id_causa = causa.id_causa ");
			select.append(" LEFT OUTER JOIN TB_SLA_FILA slaFila  ON caso.id_sla_fila = slaFila.id_sla_fila ");
			select.append(" LEFT OUTER JOIN TB_EVENTO evento  ON caso.id_evento = evento.id_evento ");
			select.append(" LEFT OUTER JOIN TB_OUTRA_AREA outraArea  ON caso.id_outra_area = outraArea.id_outra_area ");
			select.append(" LEFT OUTER JOIN TB_CONFIGURACAO_FILA fila  ON caso.id_configuracao_fila = fila.id_configuracao_fila ");
			select.append(" LEFT OUTER JOIN TB_LOTE_CASO loteCaso ON caso.id_lote_caso = loteCaso.id_lote_caso ");
			select.append(" LEFT OUTER JOIN TB_JUNCAO juncao  ON caso.id_juncao = juncao.id_juncao ");

			if (casoFind.getFiltroDadosDinamicos() != null && casoFind.getFiltroDadosDinamicos().length > 0) {
				final String cols = extrairColunasFiltro(casoFind.getFiltroDadosDinamicos());
				final int start = select.lastIndexOf("FROM") - 1;
				select.insert(start, cols);
			}

			getFiltrosCaso(select, casoFind);
			
			select.append(" ORDER BY caso.id_caso ASC ");
			
			PreparedStatement ps = super.getPreparedStatement(select.toString());
			ResultSet rs = ps.executeQuery();
			
			if (rs != null) {
				while (rs.next()) {
					CasoTO caso = getCasoTOByResultSet(rs);
					
					CampoDinamicoTO[] campos = obterCamposDinamicos(casoFind.getFiltroDadosDinamicos());
					DadosDinamicos[] dados = new DadosDinamicos[campos.length];
					for (int i = 0; i < campos.length; i++) {
						CampoDinamicoTO campo = campos[i];
						DadosDinamicos dado = new DadosDinamicos();
						dado.setDadosColuna(campo);
						dado.setValor(rs.getString(campo.getNomeColuna()));
						dados[i] = dado;
					}
					caso.setDadosDinamicos(dados);
					
					casos.add(caso);
				}
			}
			
			return casos;
		} catch (Exception e) {
			StringBuilder str = new StringBuilder();
			str.append("Erro ao buscar casos por filtro");
			logger.log(Level.SEVERE, str.toString());
			throw e;
		} finally {
			super.closeConnection();
		}
	}
	
	private CasoTO getCasoTOByResultSet(ResultSet rs) throws Exception {
		CasoTO caso = new CasoTO();
		caso.setIdCaso((Integer) rs.getObject("id_caso"));
		caso.setIdExterno(rs.getString("id_externo"));
		caso.setDataAbertura(rs.getTimestamp("data_abertura"));
		caso.setDataEncerramento(rs.getTimestamp("data_encerramento"));
		caso.setDataFimSla(rs.getTimestamp("data_fim_sla"));
		caso.setDataPrevistaFimSla(rs.getTimestamp("data_prevista_fim_sla"));
		caso.setDataCadastro(rs.getTimestamp("data_cadastro"));
		caso.setFlagReaberto(rs.getBoolean("flag_reaberto"));
		caso.setFlagFinalizado(rs.getBoolean("flag_finalizado"));
		caso.setFlagClassifica(rs.getBoolean("flag_classifica"));
		caso.setFlagEmAtendimento(rs.getBoolean("flag_em_atendimento"));
		caso.setMotivo1((Integer) rs.getObject("motivo_1"));
		caso.setMotivo1Nome(rs.getString("motivo_1_nome"));
		caso.setMotivo2((Integer) rs.getObject("motivo_2"));
		caso.setMotivo2Nome(rs.getString("motivo_2_nome"));
		caso.setMotivo3((Integer) rs.getObject("motivo_3"));
		caso.setMotivo3Nome(rs.getString("motivo_3_nome"));
		caso.setMotivo4((Integer) rs.getObject("motivo_4"));
		caso.setMotivo4Nome(rs.getString("motivo_4_nome"));
		caso.setMotivo5((Integer) rs.getObject("motivo_5"));
		caso.setMotivo5Nome(rs.getString("motivo_5_nome"));
		caso.setMotivo6((Integer) rs.getObject("motivo_6"));
		caso.setMotivo6Nome(rs.getString("motivo_6_nome"));
		caso.setDescricao(rs.getString("descricao"));
		caso.setClassificacaoCount((Integer) rs.getObject("classificacao_count"));
		caso.setEdicaoTelefoneCount((Integer) rs.getObject("edicao_telefone_count"));
		BigDecimal percentual = (BigDecimal) rs.getObject("percentual_sla");
		caso.setPorcentagemSla(percentual != null ? percentual.doubleValue() : null);
		caso.setSlaEmMinutos(rs.getString("sla_minutos"));
		caso.setSlaTotalMinutos(rs.getString("sla_total"));
		caso.setIdCasoPai((Integer) rs.getObject("id_caso_pai"));
		caso.setIdUsuarioSugerido((Integer) rs.getObject("id_usuario_sugerido"));
		caso.setDataAlteracao(rs.getTimestamp("data_alteracao"));
		caso.setFlagCriadoManual(rs.getBoolean("flag_criado_manual"));
		caso.setFlagReclassificaReabertura(rs.getBoolean("flag_reclassifica_reabertura"));
		caso.setFlagTelefoneEditado(rs.getBoolean("flag_telefone_editado"));
		caso.setIdJuncao((Integer) rs.getObject("id_juncao"));
		caso.setNomeJuncao(rs.getString("juncao"));
		caso.setIdOperacao((Integer) rs.getObject("id_operacao"));
		caso.setNomeOperacao(rs.getString("operacao"));
		caso.setIdSlaFila((Integer) rs.getObject("id_sla_fila"));
		caso.setSlaFilaTO(new SlaFilaTO((Integer) rs.getObject("id_sla_fila")));
		caso.setIdCanal((Integer) rs.getObject("id_canal"));
		caso.setNomeCanal(rs.getString("canal"));
		caso.setIdTipoCaso((Integer) rs.getObject("id_tipo_caso"));
		caso.setNomeTipoCaso(rs.getString("tipo_caso"));
		caso.setIdUsuario((Integer) rs.getObject("id_usuario"));
		caso.setLoginUsuario(rs.getString("login"));
		caso.setIdStatus((Integer) rs.getObject("id_status"));
		caso.setNomeStatus(rs.getString("status"));
		caso.setCorStatus(rs.getString("cor"));
		caso.setIdEvento((Integer) rs.getObject("id_evento"));
		caso.setNomeEvento(rs.getString("evento"));
		caso.setIdCausa((Integer) rs.getObject("id_causa"));
		caso.setNomeCausa(rs.getString("causa"));
		caso.setIdOutraArea((Integer) rs.getObject("id_outra_area"));
		caso.setNomeOutraArea(rs.getString("outra_area"));
		caso.setIdConfiguracaoFila((Integer) rs.getObject("id_configuracao_fila"));
		caso.setNomeConfiguracaoFila(rs.getString("configuracao_fila"));
		caso.setIdLoteCaso((Integer) rs.getObject("id_lote_caso"));
		caso.setNomeArquivo(rs.getString("nome_arquivo"));
		return caso;
	}
	
	public CampoDinamicoTO[] obterCamposDinamicos(FiltroDadosDinamicosTO[] filtroDadosDinamicos) {
		if (filtroDadosDinamicos != null) {
			CampoDinamicoTO[] campos = new CampoDinamicoTO[filtroDadosDinamicos.length];
			for (int i = 0; i < filtroDadosDinamicos.length; i++) {
				if (filtroDadosDinamicos[i] != null) {
					campos[i] = filtroDadosDinamicos[i].CAMPO_DINAMICO;
				}
			}
			return campos;
		}
		return null;
	}
	
	public String extrairColunasFiltro(FiltroDadosDinamicosTO[] filters) {
		StringBuilder sbr = new StringBuilder();
		for (FiltroDadosDinamicosTO col : filters) {
			if (col != null) {
				sbr.append(",").append("casodetalhe.").append(col.CAMPO_DINAMICO.getNomeColuna()).append(" as '").append(col.CAMPO_DINAMICO.getNomeColuna()).append("'\n");
			}
		}
		sbr.append(" ");
		return sbr.toString();
	}
	
	public void getFiltrosCaso(StringBuilder select, CasoFindTO casoFind) throws ParseException {
		for (FiltroCasoCampoTO campo : casoFind.getListFiltroCasoCampos()) {

			if (campo.getCampoNome().toUpperCase().contains(COL_FIELD_DYNAMICS)) {
				if (campo.getCampoTipo().equals("LISTA_UNICA") || campo.getCampoTipo().equals("LISTA_MULTIPLA")) {
					String coluna = campo.getCampoNome().substring(campo.getCampoNome().indexOf("(") + 1, campo.getCampoNome().indexOf(")"));
					select.append(String.format(" inner join tb_grupo_campo_dominio %s with(nolock) on casodetalhe.%s = %s.id_grupo_campo_dominio", coluna, coluna, coluna));
					select.append(String.format(" inner join tb_campo_dominio_selecionado selecionado%s with(nolock) on 1=1  and  %s.id_grupo_campo_dominio = selecionado%s.id_grupo_campo_dominio", coluna, coluna, coluna));
				}
			}
		}
		for (FiltroCasoCampoTO campo : casoFind.getListFiltroCasoCampos()) {
			CamposFiltroCasoEnum campoEnum = CamposFiltroCasoEnum.getEnumByNomeCampo(campo.getCampoNome());
			if (campoEnum != null && campoEnum.getType().equals(TipoCampoDinamico.BOOLEAN.toString()) && campoEnum.toString().equalsIgnoreCase(CamposFiltroCasoEnum.FLAG_LIDO.toString())) {
				select.append(" inner join tb_log loge with(nolock) on caso.id_caso = loge.id_caso inner join tb_email email with(nolock) on loge.id_email = email.id_email ");
			}
		}

		select.append(" where 1=1 ");

		if (casoFind.getIdOperacao() != null) {
			select.append(" AND caso.id_operacao = ").append(casoFind.getIdOperacao()).append(" ");
		}

		for (FiltroCasoCampoTO campo : casoFind.getListFiltroCasoCampos()) {

			if (!campo.getCampoNome().toUpperCase().contains(COL_FIELD_DYNAMICS)) {

				CamposFiltroCasoEnum campoEnum = CamposFiltroCasoEnum.getEnumByNomeCampo(campo.getCampoNome());

				if (campoEnum.getVariavelQuery().equalsIgnoreCase("sla_maior") || campoEnum.getVariavelQuery().equalsIgnoreCase("sla_menor")) {
					continue;
				} else if (campoEnum.getClazz() == null) {

					select.append(" AND ");
					select.append(" " + campoEnum.getVariavelQuery() + " ");

					if (campoEnum.getType().equals(TipoCampoDinamico.DATA.toString())) {
						configuraFiltroDatas(casoFind, select, campo, false);
					} else if (campoEnum.getType().equals(TipoCampoDinamico.BOOLEAN.toString()) && campoEnum.toString().equalsIgnoreCase(CamposFiltroCasoEnum.CASO_SEM_FILA.toString())) {
						select.append(campo.getCampoValor().equalsIgnoreCase("TRUE") ? " IS NULL " : " IS NOT NULL ");
					} else if (campoEnum.getType().equals(TipoCampoDinamico.BOOLEAN.toString()) && campoEnum.toString().equalsIgnoreCase(CamposFiltroCasoEnum.FLAG_LIDO.toString())) {
						select.append(" = ").append(new Boolean(campo.getCampoValor()) ? "1" : "0");
					} else if (campoEnum.getType().equals(TipoCampoDinamico.BOOLEAN.toString())) {
						select.append(" = ").append(new Boolean(campo.getCampoValor()) ? "1" : "0");
					} else if (campoEnum.getNomeCampo().equals("Id do Caso")) {
						select.append(" in ( ").append(campo.getCampoValor()).append(" ) ");
					} else if (campoEnum.getNomeCampo().equals("Id Externo")) {
						select.append(" in ( ");
						
						String valor = campo.getCampoValor().replace(" ", "");
						if (!valor.contains(",")) {
							select.append("'").append(valor).append("'");
						} else {
							String[] valores = valor.split(",");
							for (int x = 0; x < valores.length; x++) {
								select.append("'").append(valores[x]).append("' ");
								if (x <= valores.length - 1) {
									select.append(",");
								}
							}
							
						}
						select.append(" ) ");
					} else {
						select.append(" in (").append(campo.getCampoValor()).append(") ");
					}
				} else {

					select.append(" AND ");
					select.append(" " + campoEnum.getVariavelQuery() + " ");
					select.append(" in (").append(getIndentificadorDominio(campo.getCampoValor())).append(") ");
				}

			} else {
				String nomeCampo = campo.getCampoNome();
				String coluna = nomeCampo.substring(nomeCampo.indexOf("(") + 1, nomeCampo.indexOf(")"));

				if (campo.getCampoTipo().equals("DATA")) {
					configuraFiltroDatas(casoFind, select, campo, true);
				} else if (campo.getCampoTipo().equals("LISTA_UNICA") || campo.getCampoTipo().equals("LISTA_MULTIPLA")) {
					select.append(String.format(" and selecionado%s.id_grupo_campo_dominio = casodetalhe.%s ", coluna, coluna));
					select.append(String.format(" and selecionado%s.id_campo_dominio in(%s) ", coluna, getIndentificadorDominio(campo.getCampoValor())));
				} else if (campo.getCampoTipo().equals("BOOLEAN")) {
					select.append(" AND casodetalhe." + coluna);
					select.append(" = ").append(new Boolean(campo.getCampoValor()) ? "1" : "0");
				} else {
					select.append(" AND casodetalhe." + coluna + " ");
					select.append(" like '%" + campo.getCampoValor() + "%' ");
				}
			}
		}
	}
	
	private void configuraFiltroDatas(CasoFindTO casoFind, StringBuilder select, FiltroCasoCampoTO campo, Boolean dataDinamica) throws ParseException {
		SimpleDateFormat formatBra = new SimpleDateFormat("dd/MM/yyyy HH:mm");
		
		String nomeCampo = dataDinamica ? campo.getCampoNome() : null;
		String coluna = dataDinamica ? nomeCampo.substring(nomeCampo.indexOf("(") + 1, nomeCampo.indexOf(")")) : null;
		
		// Se for campo do tipo data, é necessário buscar como será feito o filtro da data
		if (casoFind.getDatasExportaCasoScheduler() != null && !casoFind.getDatasExportaCasoScheduler().isEmpty()) {
			for (ExportaCasoSchedulerDataTO dataTO : casoFind.getDatasExportaCasoScheduler()) {
				if (dataTO.getIdFiltroCasoCampo().compareTo(campo.getIdFiltroCasoCampo()) == 0) {
					// Se estiver configurado como data filtro utiliza da forma como o filtro foi criado
					if (dataTO.getSchedulerDateTypeInicial().equals(SchedulerDateType.DATA_FILTRO)
							&& dataTO.getSchedulerDateTypeFinal().equals(SchedulerDateType.DATA_FILTRO)) {
						Date d1 = formatBra.parse(campo.getCampoValor());
						Date d2 = formatBra.parse(campo.getCampoValor2());
						
						if (!dataDinamica) {
							select.append(" between '").append(DateUtils.convertDateStringWithHour(d1)).append("' ")
							  	  .append(" and '").append(DateUtils.convertDateStringWithHour(d2)).append("' ");
						} else {
							select.append(" AND casodetalhe.").append(coluna).append(" ")
								  .append(" BETWEEN '").append(DateUtils.convertDateStringWithHour(d1))
								  .append("' AND '").append(DateUtils.convertDateStringWithHour(d2)).append("'");
						}
						
						break;
					}
					
					// Verifica qual o tipo de data inicial
					if (dataTO.getSchedulerDateTypeInicial().equals(SchedulerDateType.INTERVALO_DIAS) && dataTO.getQuantidadeDiasInicial() != null) {
						if (!dataDinamica) {
							select.append(" between GETDATE() - ").append(dataTO.getQuantidadeDiasInicial());
						} else {
							select.append(" AND casodetalhe.").append(coluna).append(" ")
							  	  .append(" BETWEEN GETDATE() - ").append(dataTO.getQuantidadeDiasInicial());
						}
					} else if (dataTO.getSchedulerDateTypeInicial().equals(SchedulerDateType.DATA_ATUAL)) {
						if (!dataDinamica) {
							select.append(" between GETDATE() ");
						} else {
							select.append(" AND casodetalhe.").append(coluna).append(" ")
						  	  	  .append(" BETWEEN GETDATE() ");
						}
					} else if (dataTO.getSchedulerDateTypeInicial().equals(SchedulerDateType.DATA_FILTRO)) {
						Date d1 = formatBra.parse(campo.getCampoValor());
						if (!dataDinamica) {
							select.append(" between '").append(DateUtils.convertDateStringWithHour(d1)).append("' ");
						} else {
							select.append(" AND casodetalhe.").append(coluna).append(" ")
							  	  .append(" BETWEEN '").append(DateUtils.convertDateStringWithHour(d1)).append("' ");
						}
					}
					
					// Verifica qual o tipo de data final
					if (dataTO.getSchedulerDateTypeFinal().equals(SchedulerDateType.INTERVALO_DIAS) && dataTO.getQuantidadeDiasFinal() != null) {
						select.append(" and GETDATE() - ").append(dataTO.getQuantidadeDiasFinal());
					} else if (dataTO.getSchedulerDateTypeFinal().equals(SchedulerDateType.DATA_ATUAL)) {
						select.append(" and GETDATE() ");
					} else if (dataTO.getSchedulerDateTypeFinal().equals(SchedulerDateType.DATA_FILTRO)) {
						Date d2 = formatBra.parse(campo.getCampoValor2());
						select.append(" and '").append(DateUtils.convertDateStringWithHour(d2)).append("' ");
					}
					
					break;
				}
			}
		} else {
			Date d1 = formatBra.parse(campo.getCampoValor());
			Date d2 = formatBra.parse(campo.getCampoValor2());
			
			if (!dataDinamica) {
				select.append(" between '").append(DateUtils.convertDateStringWithHour(d1)).append("' ")
				  	  .append(" and '").append(DateUtils.convertDateStringWithHour(d2)).append("' ");
			} else {
				select.append(" AND casodetalhe.").append(coluna).append(" ")
					  .append(" BETWEEN '").append(DateUtils.convertDateStringWithHour(d1))
					  .append("' AND '").append(DateUtils.convertDateStringWithHour(d2)).append("'");
			}
		}
	}
	
	private String getIndentificadorDominio(String campoValor) {
		List<Integer> ids = new ArrayList<Integer>();
		if (!StringUtils.isEmpty(campoValor)) {
			if (campoValor.contains(",")) {
				for (String item : campoValor.split(",")) {
					if (item.contains("[") && item.contains("]")) {
						String valor = item.substring(item.indexOf("[") + 1, item.lastIndexOf("]"));
						if (StringUtils.isNumeric(valor)) {
							ids.add(Integer.parseInt(valor));
						}
					} else {
						if (StringUtils.isNumeric(item)) {
							ids.add(Integer.parseInt(item));
						}
					}
				}
			} else if (campoValor.contains("[") && campoValor.contains("]")) {
				String valor = campoValor.substring(campoValor.indexOf("[") + 1, campoValor.lastIndexOf("]"));
				if (StringUtils.isNumeric(valor)) {
					ids.add(Integer.parseInt(valor));
				}
			} else {
				if (StringUtils.isNumeric(campoValor)) {
					ids.add(Integer.parseInt(campoValor));
				} else {
					return campoValor;
				}
			}
		}

		StringBuilder sql = new StringBuilder();
		for (Integer id : ids) {
			sql.append(id.intValue() + ", ");
		}

		return sql.substring(0, sql.lastIndexOf(","));
	}
	
}
