package br.com.callink.cad.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import br.com.callink.cad.to.CasoClassificadoCockpitDetalheTO;
import br.com.callink.cad.to.CasoClassificadoCockpitTO;
import br.com.callink.cad.to.CasoTO;
import br.com.callink.cad.to.SlaFilaTO;
import br.com.callink.cad.util.Constantes;
import br.com.callink.cad.util.HintNumberRows;

public class CasosClassificadosDAO extends GenericDAO {

	private Logger logger = Logger.getLogger(CasosClassificadosDAO.class.getName());
	
	public List<CasoTO> buscaCasosAbertos(Integer idOperacao) throws Exception {
		List<CasoTO> casos = new ArrayList<CasoTO>();
		try {
			StringBuilder sql = new StringBuilder().append("SELECT caso.id_caso as 'caso.id_caso'").append(", caso.id_tipo_caso as 'caso.id_tipo_caso'").append(", caso.data_abertura as 'caso.data_abertura'").append(", caso.data_cadastro as 'caso.data_cadastro'").append(", caso.data_prevista_fim_sla as 'caso.data_prevista_fim_sla'")
					.append(", caso.data_fim_sla as 'caso.data_fim_sla'").append(", caso.id_sla_fila as 'caso.id_sla_fila'").append(", caso.motivo_1 as 'caso.motivo_1'").append(", caso.motivo_1_nome as 'caso.motivo_1_nome'").append(", tipo_caso.nome as 'tipo_caso.nome'").append(", caso.id_operacao as 'caso.id_operacao' ").append(", caso.id_externo as 'caso.id_externo' ")
					.append("FROM tb_caso caso with(nolock) ").append("INNER JOIN tb_tipo_caso tipo_caso with(nolock) ").append("ON caso.id_tipo_caso = tipo_caso.id_tipo_caso ").append("WHERE caso.flag_finalizado = 0 ").append("AND caso.id_operacao = ? ");

			PreparedStatement stmt = super.getPreparedStatement(sql.toString(), HintNumberRows.ROWS_CASO.getRows());
			stmt.setInt(1, idOperacao);
			ResultSet resultSet = stmt.executeQuery();

			if (resultSet != null) {
				while (resultSet.next()) {
					CasoTO to = new CasoTO();
					to.setIdCaso((Integer) resultSet.getObject("caso.id_caso"));
					to.setIdTipoCaso((Integer) resultSet.getObject("caso.id_tipo_caso"));
					to.setNomeTipoCaso(resultSet.getString("tipo_caso.nome"));
					to.setDataAbertura(resultSet.getTimestamp("caso.data_abertura"));
					to.setDataFimSla(resultSet.getTimestamp("caso.data_fim_sla"));
					to.setDataPrevistaFimSla(resultSet.getTimestamp("caso.data_prevista_fim_sla"));
					to.setDataCadastro(resultSet.getTimestamp("caso.data_cadastro"));
					to.setSlaFilaTO(resultSet.getObject("caso.id_sla_fila") != null ? new SlaFilaTO((Integer) resultSet.getObject("caso.id_sla_fila")) : null);
					to.setMotivo1((Integer)resultSet.getObject("caso.motivo_1"));
					to.setMotivo1Nome(resultSet.getString("caso.motivo_1_nome"));
					to.setIdOperacao((Integer) resultSet.getObject("caso.id_operacao"));
					to.setIdExterno(resultSet.getString("caso.id_externo"));
					casos.add(to);
				}
			} 
			return casos;
		} catch (Exception e) {
			StringBuilder str = new StringBuilder();
			
			str.append("Erro ao buscar casos abertos. Operacao: ").append(idOperacao);
			
			logger.log(Level.SEVERE, str.toString());
			
			throw e;
		} finally {
			super.closeConnection();
		}
	}
	
	public void saveCasoClassificado(List<CasoClassificadoCockpitTO> casoClassificados) throws Exception {

		Connection connection = null;
		CasoClassificadoCockpitTO casoClassificado = null;
		try {

			connection = getConnection();
			connection.setAutoCommit(false);

			StringBuilder sql = new StringBuilder().append("INSERT INTO tb_caso_classificado_cockpit ").append("(tipo_manifestacao, ").append("nome_div, ").append("caso_top, ").append("evento_pai, ").append("volume_total, ").append("volume_dentro_prazo, ").append("percentual_dentro_prazo, ").append("volume_fora_prazo, ").append("percentual_fora_prazo, ")
					.append("total_dentro_prazo, ").append("total_fora_prazo, ").append("percentual_total_dentro_prazo, ").append("percentual_total_fora_prazo, ").append("flag_totalizador, ").append("id_operacao) ").append("VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ");

			PreparedStatement stmt = connection.prepareStatement(sql.toString());
			stmt.setFetchSize(casoClassificados.size());

			int count = 0;
			for (int i = 0; i < casoClassificados.size(); i++) {
				try {

					casoClassificado = casoClassificados.get(i);

					if (casoClassificado.getTipoCaso() != null) {
						stmt.setString(1, casoClassificado.getTipoCaso());
					} else {
						stmt.setNull(1, Types.NULL);
					}
					if(casoClassificado.getTipoCaso() != null) { 
						stmt.setString(2, casoClassificado.getNomeDiv());
					} else {
						stmt.setNull(2, Types.NULL);
					}
					stmt.setInt(3, casoClassificado.getTop());
					if(casoClassificado.getEventoPai() != null) { 
						stmt.setString(4, casoClassificado.getEventoPai());
					} else {
						stmt.setNull(4, Types.NULL);
					}
					stmt.setInt(5, casoClassificado.getVolumeTotal());
					stmt.setInt(6, casoClassificado.getVolumeDentroPrazo());
					stmt.setDouble(7, casoClassificado.getPercentualDentroPrazo());
					stmt.setInt(8, casoClassificado.getVolumeForaPrazo());
					stmt.setDouble(9, casoClassificado.getPercentualForaPrazo());
					stmt.setInt(10, casoClassificado.getTotalDentroPrazo());
					stmt.setInt(11, casoClassificado.getTotalForaPrazo());
					stmt.setDouble(12, casoClassificado.getPercentualTotalDentroPrazo());
					stmt.setDouble(13, casoClassificado.getPercentualTotalForaPrazo());
					stmt.setInt(14, casoClassificado.getFlagTotalizador() == true ? 1 : 0);
					stmt.setInt(15, casoClassificado.getIdOperacao());
					stmt.executeUpdate();

					stmt.addBatch();

					if (++count % Constantes.BATCH_SIZE == 0) {
						stmt.executeBatch();
						connection.commit();
					}

				} catch (Exception e) {
					StringBuilder str = new StringBuilder();
					
					str.append("Erro ao salvar caso classificado. Tipo Caso: ").append(casoClassificado.getTipoCaso());
					str.append(" - Evento: ");
					if(casoClassificado.getEventoPai() != null) { 
						str.append(casoClassificado.getEventoPai());
					} else {
						str.append(" Sem evento");
					}
					logger.log(Level.SEVERE, str.toString());
					
					throw e;
				}
			}

			stmt.executeBatch();
			connection.commit();
		} finally {
			super.closeConnection();
		}
	}
	
	public void expurgaCasoClassificadoPorOperacao(Integer idOperacao) throws Exception {
		try {
			StringBuilder sql = new StringBuilder().append("delete from tb_caso_classificado_cockpit where id_operacao = ? ");
			PreparedStatement stmt = super.getPreparedStatement(sql.toString());
			stmt.setInt(1, idOperacao);
			stmt.executeUpdate();
		} catch (Exception e) {
			StringBuilder str = new StringBuilder();
			
			str.append("Erro ao expurgar dados. Operacao: ").append(idOperacao);
			
			logger.log(Level.SEVERE, str.toString());
			
			throw e;
		} finally {
			super.closeConnection();
		}
	}
	
	public void expurgaCasoClassificadoDetalhePorOperacao(Integer idOperacao) throws Exception {
		try {
			StringBuilder sql = new StringBuilder().append("delete from tb_caso_classificado_cockpit_detalhe where id_operacao = ? ");
			PreparedStatement stmt = super.getPreparedStatement(sql.toString());
			stmt.setInt(1, idOperacao);
			stmt.executeUpdate();
		} catch (Exception e) {
			StringBuilder str = new StringBuilder();
			
			str.append("Erro ao expurgar casos classificados. Operacao: ").append(idOperacao);
			
			logger.log(Level.SEVERE, str.toString());
			
			throw e;
		} finally {
			super.closeConnection();
		}
	}
	
	public void saveCasoClassificadoDetalhe(List<CasoClassificadoCockpitDetalheTO> casosDetalhe) throws Exception {

		Connection connection = null;
		CasoClassificadoCockpitDetalheTO item = null;
		try {

			connection = getConnection();
			connection.setAutoCommit(false);
			StringBuilder sql = new StringBuilder().append("INSERT INTO tb_caso_classificado_cockpit_detalhe ").append("(id_caso_classificado_cockpit, ").append("id_caso, ").append("id_externo, ").append("id_tipo_caso, ").append("tipo_caso, ").append("id_evento_pai, ").append("evento_pai, ").append("flag_dentro_prazo, ").append("id_operacao) ")
					.append("VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?) ");

			PreparedStatement stmt = connection.prepareStatement(sql.toString());
			stmt.setFetchSize(casosDetalhe.size());

			int count = 0;
			for (int i = 0; i < casosDetalhe.size(); i++) {
				try {
					item = casosDetalhe.get(i);

					if (item.getIdCasoClassificado() != null) {

						stmt.setInt(1, item.getIdCasoClassificado());
						stmt.setInt(2, item.getIdCaso());
						if (item.getIdExterno() != null) {
							stmt.setString(3, item.getIdExterno());
						} else {
							stmt.setNull(3, Types.NULL);
						}
						if (item.getIdTipoCaso() != null) {
							stmt.setInt(4, item.getIdTipoCaso());
						} else {
							stmt.setNull(4, Types.NULL);
						}
						if (item.getTipoCaso() != null) {
							stmt.setString(5, item.getTipoCaso());
						} else {
							stmt.setNull(5, Types.NULL);
						}
						if (item.getIdEventoPai() != null) {
							stmt.setInt(6, item.getIdEventoPai());
						} else {
							stmt.setNull(6, Types.NULL);
						}
						if (item.getEventoPai() != null) {
							stmt.setString(7, item.getEventoPai());
						} else {
							stmt.setNull(7, Types.NULL);
						}
						stmt.setInt(8, item.getFlagDentroPrazo() == true ? 1 : 0);
						stmt.setInt(9, item.getIdOperacao());

						stmt.addBatch();

						if (++count % Constantes.BATCH_SIZE == 0) {
							stmt.executeBatch();
							connection.commit();
						}
					}
				
				} catch (Exception e) {
					StringBuilder str = new StringBuilder();

					str.append("Erro ao inserir detalhe. ID Caso: ").append(item.getIdCaso());

					logger.log(Level.SEVERE, str.toString());
					
					throw e;
				}
			}

			stmt.executeBatch();
			connection.commit();
		} finally {
			super.closeConnection();
		}
	}

	public List<CasoClassificadoCockpitTO> buscaCasosInserido(Integer idOperacao) throws Exception {

		List<CasoClassificadoCockpitTO> list = new ArrayList<CasoClassificadoCockpitTO>();
		String query = "select id_caso_classificado_cockpit,tipo_manifestacao,nome_div,caso_top, evento_pai,volume_total,volume_dentro_prazo,percentual_dentro_prazo,volume_fora_prazo, percentual_fora_prazo,total_dentro_prazo,total_fora_prazo,percentual_total_dentro_prazo,percentual_total_fora_prazo,flag_totalizador,id_operacao from tb_caso_classificado_cockpit where id_operacao = ?";
		try {
			PreparedStatement ps = super.getPreparedStatement(query);
			ps.setInt(1, idOperacao);
			ResultSet rs = ps.executeQuery();

			if (rs != null) {
				while (rs.next()) {

					CasoClassificadoCockpitTO casoClassificado = new CasoClassificadoCockpitTO();
					casoClassificado.setIdCasoClassificado(rs.getInt("id_caso_classificado_cockpit"));
					casoClassificado.setTipoCaso(rs.getString("tipo_manifestacao"));
					casoClassificado.setNomeDiv(rs.getString("nome_div"));
					casoClassificado.setTop(rs.getInt("caso_top"));
					casoClassificado.setEventoPai(rs.getString("evento_pai"));
					casoClassificado.setVolumeTotal(rs.getInt("volume_total"));
					casoClassificado.setVolumeDentroPrazo(rs.getInt("volume_dentro_prazo"));
					casoClassificado.setPercentualDentroPrazo(rs.getDouble("percentual_dentro_prazo"));
					casoClassificado.setVolumeForaPrazo(rs.getInt("volume_fora_prazo"));
					casoClassificado.setPercentualForaPrazo(rs.getDouble("percentual_fora_prazo"));
					casoClassificado.setTotalDentroPrazo(rs.getInt("total_dentro_prazo"));
					casoClassificado.setTotalForaPrazo(rs.getInt("total_fora_prazo"));
					casoClassificado.setPercentualTotalDentroPrazo(rs.getDouble("percentual_total_dentro_prazo"));
					casoClassificado.setPercentualTotalForaPrazo(rs.getDouble("percentual_total_fora_prazo"));
					casoClassificado.setFlagTotalizador(rs.getBoolean("flag_totalizador"));
					casoClassificado.setIdOperacao(rs.getInt("id_operacao"));
					list.add(casoClassificado);
				}
			}

		} catch (Exception e) {
			logger.log(Level.SEVERE, e.getMessage());

			throw e;
		} finally {
			super.closeConnection();
		}

		return list;
	}
	
}
