package br.com.callink.cad.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.logging.Logger;

import br.com.callink.cad.to.CockpitCasosFechadosTO;
import br.com.callink.cad.util.HintNumberRows;

public class CockpitCasosFechadosDAO extends GenericDAO {

	private Logger logger = Logger.getLogger(CockpitCasosFechadosDAO.class.getName());
	private final int BATCH_SIZE = 1000;

	public void save(List<CockpitCasosFechadosTO> dataSource, Date dataAtual) throws Exception {
		Connection connection = null;

		try {
			logger.info("Salvando dados do cockipt de casos fechados. ");

			StringBuilder sql = new StringBuilder();
			sql.append("INSERT INTO tb_relatorio_casos_fechados ");
			sql.append(" ( ");
			sql.append("usuario ");
			sql.append(",data_fim ");
			sql.append(",equipe_nome ");
			sql.append(",fila_nome ");
			sql.append(",id_usuario ");
			sql.append(",id_caso ");
			sql.append(",id_equipe ");
			sql.append(",id_externo ");
			sql.append(",id_fila ");
			sql.append(",id_operacao ");
			sql.append(",data_cadastro ");
			sql.append(",sla ");
			sql.append(",flag_dentro_prazo ");
			sql.append(",usuario_nome ");

			sql.append(" ) ");

			sql.append("VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ");

			connection = getConnection();
			connection.setAutoCommit(false);

			PreparedStatement ps = connection.prepareStatement(sql.toString());
			ps.setFetchSize(dataSource.size());

			int count = 0;
			for (CockpitCasosFechadosTO to : dataSource) {
				ps.setString(1, to.getLoginUsuario());
				ps.setTimestamp(2, new Timestamp(to.getDataFim().getTime()));
				ps.setString(3, to.getNomeEquipe());
				ps.setString(4, to.getNomeFila());
				ps.setInt(5, to.getIdUsuario());
				ps.setInt(6, to.getIdCaso());
				ps.setInt(7, to.getIdEquipe());
				ps.setString(8, to.getIdExterno());
				ps.setInt(9, to.getIdConfiguracaoFila());
				ps.setInt(10, to.getIdOperacao());
				ps.setTimestamp(11, new Timestamp(dataAtual.getTime()));
				ps.setInt(12, to.getSla());
				ps.setInt(13, to.isFlagSlaDentroPrazo() ? 1 : 0);
				ps.setString(14, to.getNomeUsuario());

				ps.addBatch();

				if (++count % BATCH_SIZE == 0) {
					ps.executeBatch();
					connection.commit();
				}
			}

			ps.executeBatch(); // insert remaining records
			connection.commit();

		} catch (Exception e) {
			if (connection != null && !connection.isClosed()) {
				connection.rollback();
			}
			throw e;

		} finally {
			super.closeConnection();
		}
	}

	public List<CockpitCasosFechadosTO> retornaCasoFimSLADiario(Date data, Integer idOperacao) throws Exception {
		try {
			logger.info("Buscando dados do cockipt de casos fechados. ");

			Calendar dataConsulta = new GregorianCalendar();
			dataConsulta.setTime(data);

			Calendar dataInicio = new GregorianCalendar(dataConsulta.get(Calendar.YEAR), dataConsulta.get(Calendar.MONTH), dataConsulta.get(Calendar.DAY_OF_MONTH), Integer.valueOf(0), Integer.valueOf(0));
			Calendar dataFinal = new GregorianCalendar(dataConsulta.get(Calendar.YEAR), dataConsulta.get(Calendar.MONTH), dataConsulta.get(Calendar.DAY_OF_MONTH), Integer.valueOf(23), Integer.valueOf(59));

			StringBuilder sql = new StringBuilder()
				.append("SELECT ")
				.append(CockpitCasosFechadosTO.getSqlColuns())
				.append(CockpitCasosFechadosTO.getSqlFrom())
				.append("WHERE ")
				.append("Caso.FLAG_FINALIZADO = 1 ")
				.append("AND Caso.DATA_ENCERRAMENTO between ? and ? ")
				.append("AND Caso.id_operacao = ? ");

			PreparedStatement stmt = super.getPreparedStatement(sql.toString(), HintNumberRows.ROWS_CASO.getRows());

			stmt.setTimestamp(1, new Timestamp(dataInicio.getTimeInMillis()));
			stmt.setTimestamp(2, new Timestamp(dataFinal.getTimeInMillis()));
			stmt.setInt(3, idOperacao);
			ResultSet resultSet = stmt.executeQuery();
			List<CockpitCasosFechadosTO> listRows = new ArrayList<>();

			if (resultSet != null) {
				while (resultSet.next()) {
					CockpitCasosFechadosTO to = new CockpitCasosFechadosTO();
					to.setIdCaso((Integer) resultSet.getObject("Caso.ID_CASO"));
					to.setDataFim(resultSet.getTimestamp("Caso.DATA_FIM_SLA"));
					to.setIdConfiguracaoFila((Integer) resultSet.getObject("ConfiguracaoFila.ID_CONFIGURACAO_FILA"));
					to.setIdExterno(resultSet.getString("Caso.ID_EXTERNO"));
					to.setNomeFila(resultSet.getString("ConfiguracaoFila.NOME"));
					to.setIdUsuario((Integer) resultSet.getObject("Usuario.ID_USUARIO"));
					to.setLoginUsuario(resultSet.getString("Usuario.LOGIN"));
					to.setIdEquipe((Integer) resultSet.getObject("Equipe.ID_EQUIPE"));
					to.setNomeEquipe(resultSet.getString("Equipe.NOME"));
					to.setIdOperacao((Integer) resultSet.getObject("Caso.ID_OPERACAO"));
					to.setSla((Integer) resultSet.getObject("Caso.SLA_MINUTOS"));
					to.setFlagSlaDentroPrazo(resultSet.getBoolean("Caso.PERCENTUAL_SLA"));
					to.setNomeUsuario(resultSet.getString("Usuario.NOME"));

					listRows.add(to);
				}
			}

			return listRows;

		} finally {
			super.closeConnection();
		}
	}

	public void expurgaCockpitCasosFechadosPorOperacao(Integer idOperacao, Date dataAtual) throws Exception {
		try {
			Calendar dataConsulta = new GregorianCalendar();
			dataConsulta.setTime(dataAtual);

			Calendar dataInicio = new GregorianCalendar(dataConsulta.get(Calendar.YEAR), dataConsulta.get(Calendar.MONTH), dataConsulta.get(Calendar.DAY_OF_MONTH), Integer.valueOf(0), Integer.valueOf(0));
			Calendar dataFinal = new GregorianCalendar(dataConsulta.get(Calendar.YEAR), dataConsulta.get(Calendar.MONTH), dataConsulta.get(Calendar.DAY_OF_MONTH), Integer.valueOf(23), Integer.valueOf(59));

			StringBuilder sql = new StringBuilder("delete from tb_relatorio_casos_fechados where id_operacao = ? and data_cadastro between ? and ? ");

			final PreparedStatement stmt = super.getPreparedStatement(sql.toString());
			stmt.setInt(1, idOperacao);
			stmt.setTimestamp(2, new java.sql.Timestamp(dataInicio.getTime().getTime()));
			stmt.setTimestamp(3, new java.sql.Timestamp(dataFinal.getTime().getTime()));
			stmt.execute();

		} finally {
			super.closeConnection();
		}
	}
}
