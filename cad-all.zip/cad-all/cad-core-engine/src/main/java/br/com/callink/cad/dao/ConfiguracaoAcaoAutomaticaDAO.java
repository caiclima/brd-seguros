package br.com.callink.cad.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import br.com.callink.cad.to.ConfiguracaoAcaoAutomaticaTO;
import br.com.callink.cad.to.LogTO;

public class ConfiguracaoAcaoAutomaticaDAO extends GenericDAO {
	
	private Logger logger = Logger.getLogger(ConfiguracaoAcaoAutomaticaDAO.class.getName());

	public List<ConfiguracaoAcaoAutomaticaTO> findByTipoConfiguracaoFiltrosAndOperacao(String tipoConfiguracao, Integer idOperacao,
				Integer idTipoCasoFiltro, Integer idStatusFiltro, List<Integer> idsEventosFiltro) throws Exception {
		try {
			List<ConfiguracaoAcaoAutomaticaTO> configuracoesTO = new ArrayList<ConfiguracaoAcaoAutomaticaTO>();

			StringBuilder sql = new StringBuilder();
			sql.append(SELECT);
			sql.append(ConfiguracaoAcaoAutomaticaTO.getSqlCamposConfiguracaoAcaoAutomatica());
			sql.append(FROM);
			sql.append(ConfiguracaoAcaoAutomaticaTO.getSqlFromConfiguracaoAcaoAutomatica());
			sql.append(WHERE);
			sql.append(" ConfiguracaoAcaoAutomatica.TIPO_CONFIGURACAO = ? ");
			sql.append(" AND ConfiguracaoAcaoAutomatica.ID_OPERACAO = ? ");
			sql.append(" AND (ConfiguracaoAcaoAutomatica.ID_TIPO_CASO_FILTRO = ? OR ConfiguracaoAcaoAutomatica.ID_TIPO_CASO_FILTRO IS NULL) ");
			sql.append(" AND (ConfiguracaoAcaoAutomatica.ID_STATUS_FILTRO = ? OR ConfiguracaoAcaoAutomatica.ID_STATUS_FILTRO IS NULL) ");
			sql.append(" AND (ConfiguracaoAcaoAutomatica.ID_EVENTO_FILTRO IN ( ");
			if (idsEventosFiltro != null && idsEventosFiltro.size() > 0) {
				for (int x = 0; x < idsEventosFiltro.size(); x++) {
					if (x > 0) {
						sql.append(",");
					}
					sql.append(idsEventosFiltro.get(x));
				}
			} else {
				sql.append("NULL");
			}
			sql.append(") OR ConfiguracaoAcaoAutomatica.ID_EVENTO_FILTRO IS NULL) ");
			sql.append(" ORDER BY ConfiguracaoAcaoAutomatica.ID_CONFIGURACAO_ACAO_AUTOMATICA ");
			
			PreparedStatement ps = super.getPreparedStatement(sql.toString());

			ps.setString(1, tipoConfiguracao);
			ps.setInt(2, idOperacao);
			if (idTipoCasoFiltro != null) {
				ps.setInt(3, idTipoCasoFiltro);
			} else {
				ps.setNull(3, Types.NULL);
			}
			if (idStatusFiltro != null) {
				ps.setInt(4, idStatusFiltro);
			} else {
				ps.setNull(4, Types.NULL);
			}

			ResultSet rs = ps.executeQuery();

			if (rs != null) {
				while (rs.next()) {
					ConfiguracaoAcaoAutomaticaTO configuracaoTO = ConfiguracaoAcaoAutomaticaTO.getConfiguracaoAcaoAutomaticaByResultSet(rs);
					configuracoesTO.add(configuracaoTO);
				}
			}
			return configuracoesTO;
		} finally {
			super.closeConnection();
		}
	}
	
	public List<ConfiguracaoAcaoAutomaticaTO> findByTipoConfiguracaoAndOperacao(String tipoConfiguracao, Integer idOperacao) throws Exception {
		try {
			List<ConfiguracaoAcaoAutomaticaTO> configuracoesTO = new ArrayList<ConfiguracaoAcaoAutomaticaTO>();
	
			StringBuilder sql = new StringBuilder();
			sql.append(SELECT);
			sql.append(ConfiguracaoAcaoAutomaticaTO.getSqlCamposConfiguracaoAcaoAutomatica());
			sql.append(FROM);
			sql.append(ConfiguracaoAcaoAutomaticaTO.getSqlFromConfiguracaoAcaoAutomatica());
			sql.append(WHERE);
			sql.append(" ConfiguracaoAcaoAutomatica.TIPO_CONFIGURACAO = ? ");
			sql.append(" AND ConfiguracaoAcaoAutomatica.ID_OPERACAO = ? ");
			sql.append(" ORDER BY ConfiguracaoAcaoAutomatica.ID_CONFIGURACAO_ACAO_AUTOMATICA ");
	
			PreparedStatement ps = super.getPreparedStatement(sql.toString());
	
			ps.setString(1, tipoConfiguracao);
			ps.setInt(2, idOperacao);
	
			ResultSet rs = ps.executeQuery();
	
			if (rs != null) {
				while (rs.next()) {
					ConfiguracaoAcaoAutomaticaTO configuracaoTO = ConfiguracaoAcaoAutomaticaTO.getConfiguracaoAcaoAutomaticaByResultSet(rs);
					configuracoesTO.add(configuracaoTO);
				}
			}
			return configuracoesTO;
		} finally {
			super.closeConnection();
		}
	}
	
	public void insereLogExecucaoAutomatica(LogTO log) throws Exception {
		try {
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			
			StringBuilder sql = new StringBuilder();
			sql.append("INSERT INTO tb_log (id_caso, descricao, id_status, data_log, data_abertura, id_configuracao_fila, id_sla_fila, id_evento) ");
			sql.append(" VALUES (?, ?, ?, ?, ?, ?, ?, ?) ");
			
			PreparedStatement ps = super.getPreparedStatement(sql.toString());

			ps.setInt(1, log.getIdCaso());
			ps.setString(2, log.getDescricao());
			ps.setInt(3, log.getIdStatus());
			ps.setString(4, df.format(log.getDataLog()));
			ps.setString(5, df.format(log.getDataAbertura()));
			if (log.getIdConfiguracaoFila() != null) {
				ps.setInt(6, log.getIdConfiguracaoFila());
			} else {
				ps.setNull(6, Types.NULL);
			}
			if (log.getIdSlaFila() != null) {
				ps.setInt(7, log.getIdSlaFila());
			} else {
				ps.setNull(7, Types.NULL);
			}
			if (log.getIdEvento() != null) {
				ps.setInt(8, log.getIdEvento());
			} else {
				ps.setNull(8, Types.NULL);
			}
			
			ps.execute();
		} finally {
			super.closeConnection();
		}
	}
	
}
