package br.com.callink.cad.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import br.com.callink.cad.to.ConfiguracaoCaixaEmailTO;

public class ConfiguracaoCaixaEmailDAO extends GenericDAO {

	public ConfiguracaoCaixaEmailTO findById(Integer id) throws Exception {
		try {
			StringBuilder sql = new StringBuilder();
			sql.append(SELECT);
			sql.append(ConfiguracaoCaixaEmailTO.getSqlCamposConfiguracaoCaixaEmail());
			sql.append(FROM);
			sql.append(ConfiguracaoCaixaEmailTO.getSqlFromConfiguracaoCaixaEmail());
			sql.append(" WHERE configuracaoCaixaEmail.id_configuracao_caixa_email = ? ");

			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				return ConfiguracaoCaixaEmailTO.getConfiguracaoCaixaEmailByResultSet(rs);
			}

			return null;
		} finally {
			super.closeConnection();
		}
	}
	
	public void updateGetDateDataProcessando(Integer idConfiguracaoCaixaEmail) throws Exception {
		try {
			StringBuilder sql = new StringBuilder();
			sql.append(UPDATE);
			sql.append(" TB_CONFIGURACAO_CAIXA_EMAIL ");
			sql.append(SET);
			sql.append(" data_processando = getdate() ");
			sql.append(" WHERE id_configuracao_caixa_email = ? and flag_ativo = 1");

			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ps.setInt(1, idConfiguracaoCaixaEmail);
			ps.executeUpdate();
		} finally {
			super.closeConnection();
		}
	}
	
	public ConfiguracaoCaixaEmailTO findAtivosDataProcessandoPorOperacao(Integer idOperacao) throws Exception {
		try {
			List<ConfiguracaoCaixaEmailTO> ret = new ArrayList<>();

			StringBuilder sql = new StringBuilder();
			sql.append(SELECT);
			sql.append(" TOP 1 ");
			sql.append(ConfiguracaoCaixaEmailTO.getSqlCamposConfiguracaoCaixaEmail());
			sql.append(FROM);
			sql.append(ConfiguracaoCaixaEmailTO.getSqlFromConfiguracaoCaixaEmail());
			sql.append(" where configuracaoCaixaEmail.id_operacao = ? and configuracaoCaixaEmail.flag_ativo = ? ");
			sql.append(" order by data_processando asc ");

			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			
			ps.setInt(1, idOperacao);
			ps.setBoolean(2, Boolean.TRUE);
			
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				ret.add(ConfiguracaoCaixaEmailTO.getConfiguracaoCaixaEmailByResultSet(rs));
			}

			if(ret != null && !ret.isEmpty()) {
				return ret.get(0);
			}
			
			return null;
		} finally {
			super.closeConnection();
		}
	}
	
	public ConfiguracaoCaixaEmailTO findAtivosPrincipalPorOperacao(Integer idOperacao, boolean isPrincipal) throws Exception {
		try {
			List<ConfiguracaoCaixaEmailTO> ret = new ArrayList<>();

			StringBuilder sql = new StringBuilder();
			sql.append(SELECT);
			sql.append(ConfiguracaoCaixaEmailTO.getSqlCamposConfiguracaoCaixaEmail());
			sql.append(FROM);
			sql.append(ConfiguracaoCaixaEmailTO.getSqlFromConfiguracaoCaixaEmail())
			.append(" where configuracaoCaixaEmail.id_operacao = ? and configuracaoCaixaEmail.flag_principal = ? and configuracaoCaixaEmail.flag_ativo = ? ");

			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			
			ps.setInt(1, idOperacao);
			ps.setBoolean(2, isPrincipal);
			ps.setBoolean(3, Boolean.TRUE);
			
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				ret.add(ConfiguracaoCaixaEmailTO.getConfiguracaoCaixaEmailByResultSet(rs));
			}

			if(ret != null && !ret.isEmpty()) {
				return ret.get(0);
			}
			
			return null;
		} finally {
			super.closeConnection();
		}
	}
	
	public List<ConfiguracaoCaixaEmailTO> findPorOperacao(Integer idOperacao) throws Exception {
		try {
			List<ConfiguracaoCaixaEmailTO> ret = new ArrayList<>();

			StringBuilder sql = new StringBuilder();
			sql.append(SELECT);
			sql.append(ConfiguracaoCaixaEmailTO.getSqlCamposConfiguracaoCaixaEmail());
			sql.append(FROM);
			sql.append(ConfiguracaoCaixaEmailTO.getSqlFromConfiguracaoCaixaEmail())
			.append(" where configuracaoCaixaEmail.id_operacao = ? ");

			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			
			ps.setInt(1, idOperacao);
			
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				ret.add(ConfiguracaoCaixaEmailTO.getConfiguracaoCaixaEmailByResultSet(rs));
			}

			return ret;
		} finally {
			super.closeConnection();
		}
	}
	
}
