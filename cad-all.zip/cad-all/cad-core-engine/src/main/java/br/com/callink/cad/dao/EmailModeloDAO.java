package br.com.callink.cad.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import br.com.callink.cad.to.EmailModeloTO;

public class EmailModeloDAO  extends GenericDAO{

	private static Logger logger = Logger.getLogger(EmailModeloDAO.class.getName());

	public EmailModeloTO buscaEmailModelo(Integer idEmailModelo, Integer idOperacao) throws Exception {
		try {
			StringBuilder sql = new StringBuilder().append(SELECT)
        	.append(EmailModeloTO.getSqlCamposEmail())
        	.append(FROM)
            .append(EmailModeloTO.getSqlFromEmail())
            .append(WHERE)
            .append(" EmailModelo.id_email_modelo = ? ")
            .append(" AND EmailModelo.id_operacao = ? ");

			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ps.setInt(1, idEmailModelo);
			ps.setInt(2, idOperacao);

			ResultSet rs = ps.executeQuery();
			List<EmailModeloTO> listRows = new ArrayList<EmailModeloTO>();

			if (rs != null) {
				while (rs.next()) {
					EmailModeloTO emailTO = EmailModeloTO.getEmailByResultSet(rs);
					listRows.add(emailTO);
				}
			}

			return (listRows!= null && listRows.size() > 0) ? listRows.get(0) : null;
		} catch (Exception e) {
			logger.severe("Operacao " + idOperacao + "EmailModelo : " + idEmailModelo + " /n" + e.getMessage());
			throw e;
		} finally {
			super.closeConnection();
		}
	}
}
