package br.com.callink.cad.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

import br.com.callink.cad.to.CasoTO;
import br.com.callink.cad.to.ConfiguracaoFilaTO;
import br.com.callink.cad.to.LogSlaCasoTO;
import br.com.callink.cad.to.MotivoCasoTO;
import br.com.callink.cad.to.SlaFilaTO;
import br.com.callink.cad.util.HintNumberRows;

public class EnfileiraCasoDAO extends GenericDAO {

	private final int FALSE = 0;
	private final int BATCH_SIZE_LOG = 1000;
	private final int QTD_REGISTROS_TOP = 2000;
	private Logger logger = Logger.getLogger(EnfileiraCasoDAO.class.getName());

	public List<ConfiguracaoFilaTO> buscaFilaAtivaPorPrioridadeEOperacao(Integer idOperacao) throws Exception {
		try {
			StringBuilder sql = new StringBuilder()
				.append(SELECT)
				.append(ConfiguracaoFilaTO.getSqlCamposConfiguracaoFila())
				.append(FROM)
				.append(ConfiguracaoFilaTO.getSqlFromConfiguracaoFila())
				.append(WHERE)
				.append(" ConfiguracaoFila.FLAG_ATIVO = 1 ")
				.append(" and ConfiguracaoFila.id_operacao = ? ")
				.append(" AND ConfiguracaoFila.PRIORIDADE is not null ")
				.append(" ORDER BY ConfiguracaoFila.ID_OPERACAO, ConfiguracaoFila.PRIORIDADE ");

			PreparedStatement stmt = super.getPreparedStatement(sql.toString());
			stmt.setInt(1, idOperacao);
			ResultSet rs = stmt.executeQuery();
			List<ConfiguracaoFilaTO> listRows = new ArrayList<ConfiguracaoFilaTO>();

			if (rs != null) {
				while (rs.next()) {
					ConfiguracaoFilaTO to = new ConfiguracaoFilaTO();

					to.setIdConfiguracaoFila((Integer) rs.getObject("ConfiguracaoFila.ID_CONFIGURACAO_FILA"));
					to.setIdOperacao(rs.getInt("ConfiguracaoFila.ID_OPERACAO"));
					to.setFlagBuild(rs.getBoolean("ConfiguracaoFila.FLAG_BUILD"));
					to.setNome(rs.getString("ConfiguracaoFila.NOME"));
					to.setSqlFrom(rs.getString("ConfiguracaoFila.SQL_FROM"));
					to.setSqlWhere(rs.getString("ConfiguracaoFila.SQL_WHERE"));
					to.setSqlOrder(rs.getString("ConfiguracaoFila.SQL_ORDER"));
					to.setFlagSqlAvancado(rs.getBoolean("ConfiguracaoFila.FLAG_SQL_AVANCADO"));

					listRows.add(to);
				}
			}

			logger.info("buscaFilaAtivaPorPrioridadeEOperacao. ");
			return listRows;

		} finally {
			super.closeConnection();
		}
	}

	public void removeFilaCasosBuild(Integer idOperacao) throws Exception {
		try {
			StringBuilder sql = new StringBuilder()
					.append(" update tb_caso  ")
					.append(" set id_configuracao_fila = null, flag_classifica = 1 ")
					.append(WHERE)
					.append(" id_usuario is null and flag_finalizado = 0 and id_configuracao_fila in ( ")
					.append(" SELECT config.id_configuracao_fila from tb_configuracao_fila as config with(nolock) where config.FLAG_BUILD = 1 AND config.FLAG_ATIVO = 1 and config.id_operacao = ? ")
					.append(" ) ");

			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ps.setInt(1, idOperacao);
			ps.execute();
			
			logger.info("removeFilaCasosBuild. ");

		} finally {
			super.closeConnection();
		}
	}

	public void removeFilaClassificacaoCasoBuild(Integer idOperacao) throws Exception {
		try {
			StringBuilder sql = new StringBuilder()
					.append(" delete ")
					.append(FROM)
					.append(" tb_fila_classificacao_caso ")
					.append(WHERE)
					.append(" id_configuracao_fila in ( ")
					.append(" SELECT config.id_configuracao_fila from tb_configuracao_fila as config with(nolock) where config.FLAG_BUILD = 1 AND config.FLAG_ATIVO = 1 and config.id_operacao = ? ")
					.append(" ) ");

			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ps.setInt(1, idOperacao);
			ps.execute();
			
			logger.info("removeFilaClassificacaoCasoBuild. ");

		} finally {
			super.closeConnection();
		}
	}

	public List<CasoTO> buscaCasosFiltroPorFilaSemUsuario(String fromCaso, String sqlWhere, Integer idOperacao) throws Exception {
		try {
			StringBuilder sql = new StringBuilder();
			sql.append(SELECT);
			sql.append(CasoTO.getSqlColuns());
			sql.append(FROM);
			sql.append(fromCaso);

			if (!fromCaso.contains("(nolock")) {
				sql.append(" with(nolock) ");
			}

			sql.append(" ");

			if (sqlWhere != null && !sqlWhere.isEmpty()) {
				sql.append(WHERE);
				sql.append(sqlWhere);
			}

			sql.append(" and caso.id_operacao = ? ");
			sql.append(" and caso.id_sla_fila is not null ");

			PreparedStatement stmt = super.getPreparedStatement(sql.toString(), HintNumberRows.ROWS_CASO.getRows());
			stmt.setInt(1, idOperacao);
			ResultSet resultSet = stmt.executeQuery();

			List<CasoTO> listRows = new ArrayList<CasoTO>();
			if (resultSet != null) {
				while (resultSet.next()) {
					listRows.add(CasoTO.getCasoTOByResultSet(resultSet));
				}
			}
			
			logger.info("buscaCasosFiltroPorFilaSemUsuario. ");

			return listRows;

		} finally {
			super.closeConnection();
		}
	}
	
	public List<Integer> buscaCasosParaEnfileirar(String fromCaso, String sqlWhere, Integer idOperacao, Date dataJob) throws Exception {
		try {
			StringBuilder sql = new StringBuilder();
			sql.append(SELECT);
			sql.append(" TOP ").append(QTD_REGISTROS_TOP);
			sql.append(" caso.id_caso ");
			sql.append(FROM);
			sql.append(fromCaso);

			if (!fromCaso.contains("(nolock")) {
				sql.append(" with(nolock) ");
			}

			sql.append(" ");

			if (sqlWhere != null && !sqlWhere.isEmpty()) {
				sql.append(WHERE);
				sql.append(sqlWhere);
			}

			sql.append(" and caso.id_operacao = ? ");
			sql.append(" and caso.data_cadastro < ? ");
			sql.append(" and (caso.data_alteracao < ? OR caso.data_alteracao is null) ");
			sql.append(" ORDER BY caso.id_caso asc ");

			PreparedStatement stmt = super.getPreparedStatement(sql.toString());
			stmt.setInt(1, idOperacao);
			stmt.setTimestamp(2, new java.sql.Timestamp(dataJob.getTime()));
			stmt.setTimestamp(3, new java.sql.Timestamp(dataJob.getTime()));
			final ResultSet rs = stmt.executeQuery();
			
			List<Integer> list = new ArrayList<Integer>();
			if (rs != null) {
				while (rs.next()) {
					list.add(rs.getInt(1));
				}
			}
			
			logger.info("buscaCasosParaEnfileirar. ");
			
			return list;
			
		} catch (Exception e) {
			throw new Exception("Erro ao buscar os casos para a seren classificados. SQL_WHERE: "+ sqlWhere, e);
		} finally {
			super.closeConnection();
		}
	}
	
	public void enfileiraCasos(Integer idConfiguracaoFila, Integer idSlaFila, List<Integer> idscasos) throws Exception {
		try {
			StringBuilder sql = new StringBuilder();
			sql.append(UPDATE);
			sql.append("TB_CASO ");
			sql.append(SET);
			sql.append("id_configuracao_fila = ?, id_sla_fila = ?, data_prevista_fim_sla = ?, flag_classifica = ? ");
			sql.append(WHERE);
			sql.append("id_caso IN (");

			for (Integer pk : idscasos) {
				sql.append(pk.toString());

				if (idscasos.indexOf(pk) == (idscasos.size() - 1)) {
					sql.append(") ");
				} else {
					sql.append(", ");
				}
			}

			PreparedStatement stmt = super.getPreparedStatement(sql.toString());
			stmt.setInt(1, idConfiguracaoFila);
			stmt.setInt(2, idSlaFila);
			stmt.setNull(3, Types.NULL);
			stmt.setInt(4, FALSE);
			stmt.executeUpdate();
			
			logger.info("enfileiraCasos. ");

		} catch (Exception e) {
			throw new Exception("Erro ao classificar os casos para a fila: " + idConfiguracaoFila, e);
		} finally {
			super.closeConnection();
		}
	}
	
	public void reiniciarSlaDeCasosQueMudaramDeFila(Date newDate, String fromCaso, String sqlWhere, Integer idOperacao) throws Exception {
		try {
			StringBuilder sql = new StringBuilder();
			sql.append(UPDATE);
			sql.append("tmp ");
			sql.append(SET);
			sql.append("tmp.data_abertura = ? ");
			sql.append(FROM);
			sql.append("( ");
			sql.append(SELECT);
			sql.append(" caso.data_abertura ");
			sql.append(FROM);
			sql.append(fromCaso);

			if (!fromCaso.contains("(nolock")) {
				sql.append(" with(nolock) ");
			}

			sql.append(" ");

			if (sqlWhere != null && !sqlWhere.isEmpty()) {
				sql.append(WHERE);
				sql.append(sqlWhere);
			}

			sql.append(" and caso.id_operacao = ? ");
			sql.append(" and caso.id_sla_fila is not null ");
			sql.append(") tmp ");

			PreparedStatement stmt = super.getPreparedStatement(sql.toString());
			stmt.setTimestamp(1, new Timestamp(newDate.getTime()));
			stmt.setInt(2, idOperacao);
			stmt.executeUpdate();
			
			logger.info("reiniciarSlaDeCasosQueMudaramDeFila. ");

		} finally {
			super.closeConnection();
		}
	}
	
	public void insereLogDeClassificacao(List<Integer> idscasos, Date data) throws Exception {
		StringBuilder sql = new StringBuilder();
		try {

			sql.append(" INSERT INTO tb_log ");
			sql.append(" (id_status, id_caso, data_log, descricao, id_configuracao_fila, id_usuario, data_abertura, id_sla_fila, id_evento) ");
			sql.append(SELECT);
			sql.append(" Caso.id_status, Caso.id_caso, ?, 'Caso classificado com sucesso para a fila: ' + ConfiguracaoFila.nome, Caso.id_configuracao_fila, Caso.id_usuario, Caso.data_abertura, Caso.id_sla_fila, Caso.id_evento ");
			sql.append(CasoTO.getSqlFrom());
			sql.append(", ");
			sql.append(ConfiguracaoFilaTO.getSqlFromConfiguracaoFila());
			sql.append(WHERE);
			sql.append(" ConfiguracaoFila.id_configuracao_fila = Caso.id_configuracao_fila  ");
			sql.append(" and Caso.id_caso in (");

			for (Integer pk : idscasos) {
				sql.append(pk.toString());

				if (idscasos.indexOf(pk) == (idscasos.size() - 1)) {
					sql.append(") ");
				} else {
					sql.append(", ");
				}
			}

			sql.append(" ORDER BY caso.id_caso asc ");

			PreparedStatement stmt = super.getPreparedStatement(sql.toString());
			stmt.setTimestamp(1, new Timestamp(data.getTime()));
			stmt.executeUpdate();
			
			logger.info("insereLogDeClassificacao. ");

		} catch (Exception e) {
			logger.severe(" Erro ao inserir log: " + sql.toString());
			throw new Exception(" Erro ao inserir log: " + sql.toString(), e);

		} finally {
			super.closeConnection();
		}
	}

	public void insereLogSlaCaso(List<LogSlaCasoTO> logs) throws Exception {
		Connection connection = null;
		
		try {
			StringBuilder sql = new StringBuilder()
					.append(" INSERT INTO tb_log_sla_caso  ")
					.append(" (id_caso,data_abertura,data_alteracao,id_sla_fila,id_configuracao_fila,tempo_sla,percentual_gasto)  ")
					.append(" VALUES ")
					.append(" (?, ?, getdate(), ?, ?, ?, ?) ");

			connection = getConnection();
			connection.setAutoCommit(false);

			PreparedStatement ps = connection.prepareStatement(sql.toString());
			ps.setFetchSize(logs.size());
			
			int count = 0;
			
			for (LogSlaCasoTO logSlaCasoTO : logs) {
				if (logSlaCasoTO.getIdCaso() != null) {
					ps.setInt(1, logSlaCasoTO.getIdCaso());
				} else {
					ps.setNull(1, Types.NULL);
				}

				if (logSlaCasoTO.getDataAbertura() != null) {
					ps.setTimestamp(2, new Timestamp(logSlaCasoTO.getDataAbertura().getTime()));
				} else {
					ps.setNull(2, Types.NULL);
				}

				if (logSlaCasoTO.getIdSlaFila() != null) {
					ps.setInt(3, logSlaCasoTO.getIdSlaFila());
				} else {
					ps.setNull(3, Types.NULL);
				}

				if (logSlaCasoTO.getIdConfiguracaoFila() != null) {
					ps.setInt(4, logSlaCasoTO.getIdConfiguracaoFila());
				} else {
					ps.setNull(4, Types.NULL);
				}

				if (logSlaCasoTO.getTempoSla() != null) {
					ps.setInt(5, logSlaCasoTO.getTempoSla());
				} else {
					ps.setNull(5, Types.NULL);
				}

				if (logSlaCasoTO.getPercentualGasto() != null) {
					ps.setDouble(6, logSlaCasoTO.getPercentualGasto());
				} else {
					ps.setNull(6, Types.NULL);
				}

				ps.addBatch();

				if (++count % BATCH_SIZE_LOG == 0) {
					ps.executeBatch();
					connection.commit();
				}
			}
			
			ps.executeBatch(); // insert remaining records
			connection.commit();
			
			logger.info("insereLogSlaCaso. ");
			
		} catch (Exception e) {
			if (connection != null && !connection.isClosed()) {
				connection.rollback();
			}
			throw new Exception("Erro ao salvar log dos slas dos casos.", e);
			
		} finally {
			super.closeConnection();
		}
	}

	public void removeFilaClassificaoCaso(List<Integer> idscasos) throws Exception {
		StringBuilder sql = new StringBuilder();
		try {
			sql.append(" delete filaClass ");
			sql.append(FROM);
			sql.append(" tb_fila_classificacao_caso filaClass with(nolock) ");
			sql.append(WHERE);
			sql.append(" filaClass.id_caso IN (");

			for (Integer pk : idscasos) {
				sql.append(pk.toString());

				if (idscasos.indexOf(pk) == (idscasos.size() - 1)) {
					sql.append(") ");
				} else {
					sql.append(", ");
				}
			}

			PreparedStatement stmt = super.getPreparedStatement(sql.toString());
			stmt.executeUpdate();
			
			logger.info("removeFilaClassificaoCaso. ");

		} catch (Exception e) {
			throw new Exception("Erro ao remover linhas Classificação: " + sql.toString(), e);

		} finally {
			super.closeConnection();
		}
	}
	
	public void insereCasoFila(Integer idConfiguracaoFila, List<Integer> idscasos) throws Exception {
		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" insert into tb_fila_classificacao_caso (id_configuracao_fila,id_caso) ");
			sql.append(SELECT);
			sql.append(MessageFormat.format(" {0}, Caso.id_caso", idConfiguracaoFila.toString()));
			sql.append(CasoTO.getSqlFrom());
			sql.append(WHERE);
			sql.append(" Caso.id_caso IN (");

			for (Integer pk : idscasos) {
				sql.append(pk.toString());

				if (idscasos.indexOf(pk) == (idscasos.size() - 1)) {
					sql.append(") ");
				} else {
					sql.append(", ");
				}
			}

			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ps.executeUpdate();
			
			logger.info("insereCasoFila. ");

		} catch (Exception e) {
			throw new Exception("Erro ao salvar os casos na tb_classificacao.", e);

		} finally {
			super.closeConnection();
		}
	}
	
	public void classificaMotivos() throws Exception {
		try {
			CallableStatement cs = prepareCall(" exec PROC_ATUALIZA_MOTIVOS_CASO ");
			cs.execute();
			
			logger.info("classificaMotivos. ");

		} finally {
			super.closeConnection();
		}
	}
	
	public SlaFilaTO findSlaFilaByConfFilaAndDataFimNull(Integer idConfiguracao) throws Exception {
		try {
			StringBuilder sql = new StringBuilder()
				.append(SELECT)
				.append(SlaFilaTO.getSqlCamposSlaFilaTO())
				.append(FROM)
				.append(ConfiguracaoFilaTO.getSqlFromConfiguracaoFila())
				.append(INNER_JOIN).append(SlaFilaTO.getSqlFromSlaFilaTO())
				.append(" ON ConfiguracaoFila.ID_SLA_FILA = SlaFilaTO.ID_SLA_FILA ")
				.append(WHERE)
				.append("SlaFilaTO.DATA_FIM IS NULL ")
				.append(" AND ConfiguracaoFila.ID_CONFIGURACAO_FILA = ? ");

			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ps.setInt(1, idConfiguracao);
			ResultSet rs = ps.executeQuery();

			SlaFilaTO slaFila = new SlaFilaTO();
			if (rs != null && rs.next()) {
				slaFila = SlaFilaTO.getSlaFilaTOByResultSet(rs);
			}
			
			logger.info("findSlaFilaByConfFilaAndDataFimNull. ");
			
			return slaFila;
		} finally {
			super.closeConnection();
		}
	}

	public void updateConfiguracaoFilaBuild(Integer idOperacao) throws Exception {
		try {
			if (idOperacao != null) {
				StringBuilder sql = new StringBuilder()
					.append(" update tb_configuracao_fila ")
					.append(" set FLAG_BUILD = 0 ")
					.append(WHERE)
					.append(" FLAG_BUILD = 1 ")
					.append(" and id_operacao = ").append(idOperacao)
					.append(" AND FLAG_ATIVO = 1 ");
	
				super.getPreparedStatement(sql.toString()).execute();
				
				logger.info("updateConfiguracaoFilaBuild. ");
			}
		} finally {
			super.closeConnection();
		}
	}

	public MotivoCasoTO montaArvoreEvento(Integer idEvento) throws Exception {
		try {
			PreparedStatement stmt = super.getPreparedStatement(" SELECT id_evento, nome, nivel from FCN_MONTA_ARVORE_EVENTOS(?) ");
			stmt.setInt(1, idEvento);
			ResultSet result = stmt.executeQuery();

			MotivoCasoTO mtvo = new MotivoCasoTO();

			if (result != null) {
				while (result.next()) {
					if (result.getInt("nivel") == 1) {
						mtvo.setMotivo1(result.getInt("id_evento"));
						mtvo.setMotivo1Nome(result.getString("nome"));
					}
					if (result.getInt("nivel") == 2) {
						mtvo.setMotivo2(result.getInt("id_evento"));
						mtvo.setMotivo2Nome(result.getString("nome"));
					}
					if (result.getInt("nivel") == 3) {
						mtvo.setMotivo3(result.getInt("id_evento"));
						mtvo.setMotivo3Nome(result.getString("nome"));
					}
					if (result.getInt("nivel") == 4) {
						mtvo.setMotivo4(result.getInt("id_evento"));
						mtvo.setMotivo4Nome(result.getString("nome"));
					}
					if (result.getInt("nivel") == 5) {
						mtvo.setMotivo5(result.getInt("id_evento"));
						mtvo.setMotivo5Nome(result.getString("nome"));
					}
					if (result.getInt("nivel") == 6) {
						mtvo.setMotivo6(result.getInt("id_evento"));
						mtvo.setMotivo6Nome(result.getString("nome"));
					}
				}
			}
			
			logger.info("montaArvoreEvento. ");

			return mtvo;

		} finally {
			super.closeConnection();
		}
	}

	public void updateCasosNaoClassificadosParaClassificar(Integer idOperacao) throws SQLException, Exception {
		try {
			if (idOperacao != null) {
				StringBuilder sql = new StringBuilder()
					.append(" update caso ")
					.append(" set caso.flag_classifica = 1 ")
					.append(FROM)
					.append("tb_caso caso with(nolock), tb_lote_caso lote with(nolock) ")
					.append(WHERE)
					.append(" caso.id_lote_caso = lote.id_lote_caso ")
					.append(" and ( lote.status_execucao = '").append("FINALIZADO").append("'")
					.append(" or lote.status_execucao = '").append("FINALIZADO COM PENDENCIA").append("' )")
					.append(" and caso.id_configuracao_fila is null ")
					.append(" and caso.flag_finalizado = 0  ")
					.append(" and caso.flag_classifica = 0  ")
					.append(" and caso.flag_reclassifica_reabertura = 0 ")
					.append(" and caso.id_operacao = ").append(idOperacao);
	
				super.getPreparedStatement(sql.toString()).execute();
				
				logger.info("updateCasosNaoClassificadosParaClassificar. ");
			}
		} finally {
			super.closeConnection();
		}
		
	}

	public void retiraCasosJaFinalizadosBuffer(Integer idOperacao) throws SQLException, Exception  {
		try {
			if (idOperacao != null) {
				StringBuilder sql = new StringBuilder()
					.append(" delete from tb_caso_fila_atendimento ")
					.append(WHERE)
					.append(" id_caso in (select ca.id_caso from tb_caso ca with(nolock), tb_caso_fila_atendimento cf with(nolock)") 
					.append(" where ca.id_caso = cf.id_caso and ca.flag_finalizado = 1 and ca.id_operacao = ")
					.append(idOperacao)
					.append(" ) and id_operacao = ")
					.append(idOperacao);
	
				super.getPreparedStatement(sql.toString()).execute();
				
				logger.info("retiraCasosJaFinalizadosBuffer. ");
			}
		} finally {
			super.closeConnection();
		}
	}
}