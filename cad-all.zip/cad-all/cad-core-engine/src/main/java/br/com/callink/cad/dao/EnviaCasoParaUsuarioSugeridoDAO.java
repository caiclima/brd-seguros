package br.com.callink.cad.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import br.com.callink.cad.to.CasoTO;
import br.com.callink.cad.to.LogTO;

public class EnviaCasoParaUsuarioSugeridoDAO extends GenericDAO {

	private final int BATCH_SIZE = 1000;

	public boolean existeUsuario(int idUsuarioSugerido) throws Exception {
		try {
			StringBuilder sql = new StringBuilder().append(" select 1 from tb_usuario with(nolock) ").append(WHERE).append(" id_usuario = ? ");

			PreparedStatement stmt = super.getPreparedStatement(sql.toString());
			stmt.setInt(1, idUsuarioSugerido);
			ResultSet result = stmt.executeQuery();
			return result != null && result.next();

		} finally {
			super.closeConnection();
		}
	}

	public boolean possuiEquipe(int idUsuarioSugerido) throws Exception {
		try {
			StringBuilder sql = new StringBuilder().append("select 1 from tb_equipe with(nolock) where id_equipe = (select id_equipe from tb_usuario with(nolock) ").append(WHERE)
					.append(" id_usuario = ?) ");

			PreparedStatement stmt = super.getPreparedStatement(sql.toString());
			stmt.setInt(1, idUsuarioSugerido);
			ResultSet result = stmt.executeQuery();
			return result != null && result.next();

		} finally {
			super.closeConnection();
		}
	}

	public boolean possuiOperacao(int idUsuarioSugerido) throws Exception {
		try {
			StringBuilder sql = new StringBuilder().append("select 1 from tb_operacao_usuario with(nolock) ").append(WHERE).append(" id_usuario = ? ");

			PreparedStatement stmt = super.getPreparedStatement(sql.toString());
			stmt.setInt(1, idUsuarioSugerido);
			ResultSet result = stmt.executeQuery();
			return result != null && result.next();

		} finally {
			super.closeConnection();
		}
	}

	public boolean atendeFila(int idUsuarioSugerido, int idConfiguracaoFila) throws Exception {
		try {
			StringBuilder sql = new StringBuilder().append("select 1 from tb_equipe_fila with(nolock) ").append(WHERE).append(" id_configuracao_fila = ? ")
					.append("and id_equipe = (select id_equipe from tb_usuario with(nolock) where id_usuario = ?)");

			PreparedStatement stmt = super.getPreparedStatement(sql.toString());
			stmt.setInt(1, idConfiguracaoFila);
			stmt.setInt(2, idUsuarioSugerido);
			ResultSet result = stmt.executeQuery();
			return result != null && result.next();

		} finally {
			super.closeConnection();
		}
	}

	public List<CasoTO> buscaCasosAbertosComUsuarioSugerido(Integer idOperacao) throws Exception {
		try {
			StringBuilder sql = new StringBuilder();
			sql.append(SELECT);
			sql.append(CasoTO.getSqlColuns());
			sql.append(CasoTO.getSqlFrom());
			sql.append(WHERE);
			sql.append("Caso.id_operacao = ? ");
			sql.append("AND Caso.id_configuracao_fila is not null ");
			sql.append("AND Caso.id_usuario is null ");
			sql.append("AND Caso.id_usuario_sugerido is not null ");
			sql.append("AND Caso.flag_finalizado = 0 and data_encerramento is null ");

			PreparedStatement stmt = super.getPreparedStatement(sql.toString());
			stmt.setInt(1, idOperacao);
			ResultSet resultSet = stmt.executeQuery();
			List<CasoTO> listRows = new ArrayList<CasoTO>();

			if (resultSet != null) {
				while (resultSet.next()) {
					listRows.add(CasoTO.getCasoTOByResultSet(resultSet));
				}
			}

			return listRows;

		} finally {
			super.closeConnection();
		}
	}

	public void atualizaUsuarioCaso(List<CasoTO> casos) throws Exception {
		Connection connection = null;

		try {
			connection = getConnection();
			connection.setAutoCommit(false);

			PreparedStatement ps = connection.prepareStatement("update tb_caso set id_usuario_sugerido = ?, id_usuario = ? WHERE id_caso = ? ");
			ps.setFetchSize(casos.size());

			int count = 0;

			for (CasoTO casoTO : casos) {
				if (casoTO.getIdUsuarioSugerido() != null) {
					ps.setInt(1, casoTO.getIdUsuarioSugerido());
				} else {
					ps.setNull(1, Types.NULL);
				}

				if (casoTO.getIdUsuario() != null) {
					ps.setInt(2, casoTO.getIdUsuario());
				} else {
					ps.setNull(2, Types.NULL);
				}

				ps.setInt(3, casoTO.getIdCaso());

				ps.addBatch();

				if (++count % BATCH_SIZE == 0) {
					ps.executeBatch();
					connection.commit();
				}
			}

			ps.executeBatch(); // insert remaining records
			connection.commit();

		} catch (Exception e) {
			if (connection != null && !connection.isClosed()) {
				connection.rollback();
			}
			throw e;

		} finally {
			super.closeConnection();
		}
	}

	public void insereLog(List<LogTO> logs) throws Exception {
		Connection connection = null;

		try {
			StringBuilder sql = new StringBuilder().append(" INSERT INTO tb_log   ")
					.append(" (id_status,id_caso,data_log,descricao,id_grupo_anexo,id_acao,id_email,id_configuracao_fila,detalhe,id_usuario,data_abertura,id_evento)  ").append(" VALUES ")
					.append(" (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ");

			connection = getConnection();
			connection.setAutoCommit(false);

			PreparedStatement ps = connection.prepareStatement(sql.toString());
			ps.setFetchSize(logs.size());

			int count = 0;

			for (LogTO logTO : logs) {
				if (logTO.getIdStatus() != null) {
					ps.setInt(1, logTO.getIdStatus());
				} else {
					ps.setNull(1, Types.NULL);
				}

				if (logTO.getIdCaso() != null) {
					ps.setInt(2, logTO.getIdCaso());
				} else {
					ps.setNull(2, Types.NULL);
				}

				if (logTO.getDataLog() != null) {
					ps.setTimestamp(3, new Timestamp(logTO.getDataLog().getTime()));
				} else {
					ps.setNull(3, Types.NULL);
				}

				if (logTO.getDescricao() != null) {
					ps.setString(4, logTO.getDescricao());
				} else {
					ps.setNull(4, Types.NULL);
				}

				if (logTO.getIdGrupoAnexo() != null) {
					ps.setInt(5, logTO.getIdGrupoAnexo());
				} else {
					ps.setNull(5, Types.NULL);
				}

				if (logTO.getIdAcao() != null) {
					ps.setInt(6, logTO.getIdAcao());
				} else {
					ps.setNull(6, Types.NULL);
				}

				if (logTO.getIdEmail() != null) {
					ps.setInt(7, logTO.getIdEmail());
				} else {
					ps.setNull(7, Types.NULL);
				}

				if (logTO.getIdConfiguracaoFila() != null) {
					ps.setInt(8, logTO.getIdConfiguracaoFila());
				} else {
					ps.setNull(8, Types.NULL);
				}

				if (logTO.getDetalhe() != null) {
					ps.setString(9, logTO.getDetalhe());
				} else {
					ps.setNull(9, Types.NULL);
				}

				if (logTO.getIdUsuario() != null) {
					ps.setInt(10, logTO.getIdUsuario());
				} else {
					ps.setNull(10, Types.NULL);
				}

				if (logTO.getDataAbertura() != null) {
					ps.setTimestamp(11, new Timestamp(logTO.getDataAbertura().getTime()));
				} else {
					ps.setNull(11, Types.NULL);
				}

				if (logTO.getIdEvento() != null) {
					ps.setInt(12, logTO.getIdEvento());
				} else {
					ps.setNull(12, Types.NULL);
				}

				if (++count % BATCH_SIZE == 0) {
					ps.executeBatch();
					connection.commit();
				}
			}

			ps.executeBatch(); // insert remaining records
			connection.commit();

		} catch (Exception e) {
			if (connection != null && !connection.isClosed()) {
				connection.rollback();
			}
			throw e;

		} finally {
			super.closeConnection();
		}
	}
}
