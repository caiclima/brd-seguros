package br.com.callink.cad.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import br.com.callink.cad.to.AnexoTO;
import br.com.callink.cad.to.EmailTO;


public class EnviaEmailDAO extends GenericDAO {
	
	private Logger logger = Logger.getLogger(EnviaEmailDAO.class.getName());

	public List<EmailTO> findEmailsEnvioPendente(boolean flagEnvioPendente, boolean flagEnvio, boolean flagErroEnvio, Integer idOperacao) throws Exception {
		try {
			StringBuilder sql = new StringBuilder().append(SELECT)
        	.append(EmailTO.getSqlCamposEmail())
        	.append(FROM)
            .append(EmailTO.getSqlFromEmail())
            .append(WHERE)
            .append(" Email.FLAG_ENVIO_PENDENTE = ? ")
            .append(" AND Email.FLAG_ERRO_ENVIO =  ? ")
            .append(" AND Email.FLAG_ENVIO = ? ")
            .append(" AND Email.id_operacao = ? ");

			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ps.setBoolean(1, flagEnvioPendente);
			ps.setBoolean(2, flagErroEnvio);
			ps.setBoolean(3, flagEnvio);
			ps.setInt(4, idOperacao);

			ResultSet rs = ps.executeQuery();
			List<EmailTO> listRows = new ArrayList<EmailTO>();

			if (rs != null) {
				while (rs.next()) {
					EmailTO emailTO = EmailTO.getEmailByResultSet(rs);
					listRows.add(emailTO);
				}
			}

			logger.info("findEmailsEnvioPendente. ");
			return listRows;
			
		} finally {
			super.closeConnection();
		}
	}
	
	public void updateFlagErroEnvio(Map<Integer, Boolean> map) throws Exception {
		try {
			for(Map.Entry<Integer, Boolean> entry : map.entrySet()){
				StringBuilder sql = new StringBuilder()
				.append(UPDATE)
				.append(" tb_email SET ")
	        	.append(" FLAG_ERRO_ENVIO = ? ")
	            .append(WHERE)
	            .append(" ID_EMAIL = ? ");
	
				PreparedStatement ps = super.getPreparedStatement(sql.toString());
				ps.setBoolean(1, entry.getValue());
				ps.setInt(2, entry.getKey());
	
				ps.executeUpdate();
	
			}
			logger.info("updateFlagFlagErroEnvio. ");
		} finally {
			super.closeConnection();
		}
	}
	
	public void updateEmail(List<EmailTO> listEmails) throws Exception {
		try {
			for(EmailTO update : listEmails){
				StringBuilder sql = new StringBuilder()
				.append(UPDATE)
				.append(" TB_Email SET ")
	        	.append(" FLAG_ERRO_ENVIO = ?, FLAG_ENVIO_PENDENTE = ? ")
	            .append(WHERE)
	            .append(" ID_EMAIL = ? ");
	
				PreparedStatement ps = super.getPreparedStatement(sql.toString());
				ps.setBoolean(1, update.getFlagErroEnvio());
				ps.setBoolean(2, update.getFlagEnvioPendente());
				ps.setInt(3, update.getIdEmail());
	
				ps.executeUpdate();
			}

			logger.info("updateEmail. ");
		} finally {
			super.closeConnection();
		}
	}
	
	public List<AnexoTO> buscaPorGrupoAnexo(Integer idGrupoAnexo) throws Exception {
		List<AnexoTO> list = new ArrayList<AnexoTO>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(AnexoTO.getSqlCamposAnexo())
				.append(FROM)
				.append(AnexoTO.getSqlFromAnexo())
				.append(" WHERE Anexo.ID_GRUPO_ANEXO = ? ");

			stmt = getPreparedStatement(select.toString());
			stmt.setInt(1, idGrupoAnexo);

			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					AnexoTO anexo = AnexoTO.getAnexoByResultSet(resultSet);
					list.add(anexo);
				}
			}
		} finally {
			super.closeConnection();
		}
		return list;
    }
}