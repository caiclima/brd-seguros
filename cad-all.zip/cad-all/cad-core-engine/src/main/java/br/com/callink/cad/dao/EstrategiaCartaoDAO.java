package br.com.callink.cad.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import br.com.callink.cad.to.EstrategiaCartaoTO;

public class EstrategiaCartaoDAO extends GenericDAO {

	private Logger logger = Logger.getLogger(EstrategiaCartaoDAO.class.getName());
	
	public List<EstrategiaCartaoTO> buscarEstrategiasPorOperacao(Integer idOperacao) throws Exception {
		try {
			List<EstrategiaCartaoTO> list = new ArrayList<EstrategiaCartaoTO>();

			StringBuilder sql = new StringBuilder();
			sql.append(SELECT);
			sql.append(EstrategiaCartaoTO.getSqlColuns());
			sql.append(EstrategiaCartaoTO.getSqlFrom());
			sql.append(WHERE);
			sql.append(" estrategia.ID_OPERACAO = ? ");

			PreparedStatement ps = super.getPreparedStatement(sql.toString());

			ps.setInt(1, idOperacao);
			ResultSet rs = ps.executeQuery();

			if (rs != null) {
				while (rs.next()) {
					list.add(EstrategiaCartaoTO.getEstrategiaTOByResultSet(rs));
				}
			}
			return list;
		} catch (Exception e) {
			StringBuilder str = new StringBuilder();
			
			str.append("Erro ao buscar estrategias de cartao pela operação: ").append(idOperacao);
			
			logger.log(Level.SEVERE, str.toString());
			
			throw e;
		} finally {
			super.closeConnection();
		}
	}
}
