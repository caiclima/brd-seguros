package br.com.callink.cad.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

import br.com.callink.cad.to.CasoTO;
import br.com.callink.cad.to.EvolucaoAtendimentoDetalheTO;
import br.com.callink.cad.to.EvolucaoAtendimentoTO;
import br.com.callink.cad.to.GenericTO;
import br.com.callink.cad.to.SlaFilaTO;
import br.com.callink.cad.util.Constantes;
import br.com.callink.cad.util.HintNumberRows;

public class EvolucaoAtendimentoCasoDAO extends GenericDAO {

	public List<CasoTO> buscaCasoEntranteDia(Integer idOperacao) throws Exception {
		List<CasoTO> casos = new ArrayList<CasoTO>();
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			StringBuilder sql = new StringBuilder()
						.append("SELECT caso.id_caso as 'caso.id_caso'")
						.append(", caso.id_externo as 'caso.id_externo'")
						.append(", caso.id_tipo_caso as 'caso.id_tipo_caso'")
						.append(", caso.id_configuracao_fila as 'caso.id_configuracao_fila'")
						.append(", caso.data_abertura as 'caso.data_abertura'")
						.append(", caso.data_fim_sla as 'caso.data_fim_sla'")
						.append(", caso.id_operacao as 'caso.id_operacao'")
						.append(", caso.id_sla_fila as 'caso.id_sla_fila'")
						.append(", tipoCaso.nome as 'caso.nome_tipo_caso'")
						.append(", configFila.nome as 'caso.nome_configuracao_fila'")
					.append("FROM tb_caso caso with(nolock) ")
					.append(" LEFT JOIN tb_tipo_caso tipoCaso with(nolock) ")
					.append("  ON tipoCaso.id_tipo_caso = caso.id_tipo_caso ")
					.append(" LEFT JOIN tb_configuracao_fila configFila with(nolock) ")
					.append("  ON configFila.id_configuracao_fila = caso.id_configuracao_fila ")
					.append("WHERE caso.data_cadastro BETWEEN ? AND ? ")
					.append("AND caso.id_operacao = ? ");

			Calendar dataInicio = new GregorianCalendar(Calendar.getInstance().get(Calendar.YEAR), Calendar.getInstance().get(Calendar.MONTH), Calendar.getInstance().get(Calendar.DAY_OF_MONTH), Integer.valueOf(0), Integer.valueOf(0));
			Calendar dataFim = new GregorianCalendar(Calendar.getInstance().get(Calendar.YEAR), Calendar.getInstance().get(Calendar.MONTH), Calendar.getInstance().get(Calendar.DAY_OF_MONTH), Integer.valueOf(23), Integer.valueOf(59));

			PreparedStatement stmt = super.getPreparedStatement(sql.toString(), HintNumberRows.ROWS_CASO.getRows());
			stmt.setString(1, df.format(dataInicio.getTime()));
			stmt.setString(2, df.format(dataFim.getTime()));
			stmt.setInt(3, idOperacao);
			ResultSet resultSet = stmt.executeQuery();

			if (resultSet != null) {
				while (resultSet.next()) {
					CasoTO to = new CasoTO();
					to.setIdCaso((Integer) resultSet.getObject("caso.id_caso"));
					to.setIdExterno((String) resultSet.getObject("caso.id_externo"));
					to.setIdTipoCaso((Integer) resultSet.getObject("caso.id_tipo_caso"));
					to.setIdConfiguracaoFila((Integer) resultSet.getObject("caso.id_configuracao_fila"));
					to.setDataAbertura(resultSet.getTimestamp("caso.data_abertura"));
					to.setDataFimSla(resultSet.getTimestamp("caso.data_fim_sla"));
					to.setIdOperacao(resultSet.getInt("caso.id_operacao"));
					to.setSlaFilaTO(resultSet.getObject("caso.id_sla_fila") != null ? new SlaFilaTO((Integer) resultSet.getObject("caso.id_sla_fila")) : null);
					to.setNomeTipoCaso((String) resultSet.getObject("caso.nome_tipo_caso"));
					to.setNomeConfiguracaoFila((String) resultSet.getObject("caso.nome_configuracao_fila"));
					
					casos.add(to);
				}
			}
			return casos;

		} finally {
			super.closeConnection();
		}
	}

	public List<CasoTO> buscaCasoReabertoDia(Integer idOperacao) throws Exception {
		List<CasoTO> casos = new ArrayList<CasoTO>();
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			StringBuilder sql = new StringBuilder()
					.append("SELECT caso.id_caso as 'caso.id_caso'")
					.append(", caso.id_externo as 'caso.id_externo'")
					.append(", caso.id_tipo_caso as 'caso.id_tipo_caso'")
					.append(", caso.id_configuracao_fila as 'caso.id_configuracao_fila'")
					.append(", caso.data_abertura as 'caso.data_abertura'")
					.append(", caso.data_prevista_fim_sla as 'caso.data_prevista_fim_sla'")
					.append(", caso.data_fim_sla as 'caso.data_fim_sla'")
					.append(", caso.id_operacao as 'caso.id_operacao'")
					.append(", caso.id_sla_fila as 'caso.id_sla_fila'")
					.append(", tipoCaso.nome as 'caso.nome_tipo_caso'")
					.append(", configFila.nome as 'caso.nome_configuracao_fila'")
				.append("FROM tb_caso caso with(nolock) ")
				.append(" INNER JOIN tb_reabertura_caso reab with(nolock) ")
				.append("  ON caso.id_caso = reab.id_caso ")
				.append(" LEFT JOIN tb_tipo_caso tipoCaso with(nolock) ")
				.append("  ON tipoCaso.id_tipo_caso = caso.id_tipo_caso ")
				.append(" LEFT JOIN tb_configuracao_fila configFila with(nolock) ")
				.append("  ON configFila.id_configuracao_fila = caso.id_configuracao_fila ")
				.append("WHERE reab.data_reabertura BETWEEN ? AND ? ")
				.append("AND caso.id_operacao = ? ");

			Calendar dataInicio = new GregorianCalendar(Calendar.getInstance().get(Calendar.YEAR), Calendar.getInstance().get(Calendar.MONTH), Calendar.getInstance().get(Calendar.DAY_OF_MONTH), Integer.valueOf(0), Integer.valueOf(0));
			Calendar dataFim = new GregorianCalendar(Calendar.getInstance().get(Calendar.YEAR), Calendar.getInstance().get(Calendar.MONTH), Calendar.getInstance().get(Calendar.DAY_OF_MONTH), Integer.valueOf(23), Integer.valueOf(59));

			PreparedStatement stmt = super.getPreparedStatement(sql.toString(), HintNumberRows.ROWS_CASO.getRows());
			stmt.setString(1, df.format(dataInicio.getTime()));
			stmt.setString(2, df.format(dataFim.getTime()));
			stmt.setInt(3, idOperacao);
			ResultSet resultSet = stmt.executeQuery();

			if (resultSet != null) {
				while (resultSet.next()) {
					CasoTO to = new CasoTO();
					to.setIdCaso((Integer) resultSet.getObject("caso.id_caso"));
					to.setIdExterno((String) resultSet.getObject("caso.id_externo"));
					to.setIdTipoCaso((Integer) resultSet.getObject("caso.id_tipo_caso"));
					to.setIdConfiguracaoFila((Integer) resultSet.getObject("caso.id_configuracao_fila"));
					to.setDataAbertura(resultSet.getTimestamp("caso.data_abertura"));
					to.setDataFimSla(resultSet.getTimestamp("caso.data_fim_sla"));
					to.setDataPrevistaFimSla(resultSet.getTimestamp("caso.data_prevista_fim_sla"));
					to.setIdOperacao(resultSet.getInt("caso.id_operacao"));
					to.setSlaFilaTO(resultSet.getObject("caso.id_sla_fila") != null ? new SlaFilaTO((Integer) resultSet.getObject("caso.id_sla_fila")) : null);
					to.setNomeTipoCaso((String) resultSet.getObject("caso.nome_tipo_caso"));
					to.setNomeConfiguracaoFila((String) resultSet.getObject("caso.nome_configuracao_fila"));
					casos.add(to);
				}
			}
			return casos;

		} finally {
			super.closeConnection();
		}
	}

	public List<CasoTO> buscaCasoAbertoSemPendencia(Integer idOperacao) throws Exception {
		List<CasoTO> casos = new ArrayList<CasoTO>();
		try {
			StringBuilder sql = new StringBuilder()
						.append("SELECT caso.id_caso as 'caso.id_caso'")
						.append(", caso.id_externo as 'caso.id_externo'")
						.append(", caso.id_tipo_caso as 'caso.id_tipo_caso'")
						.append(", caso.id_configuracao_fila as 'caso.id_configuracao_fila'")
						.append(", caso.data_abertura as 'caso.data_abertura'")
						.append(", caso.data_cadastro as 'caso.data_cadastro'")
						.append(", caso.data_prevista_fim_sla as 'caso.data_prevista_fim_sla'")
						.append(", caso.data_fim_sla as 'caso.data_fim_sla'")
						.append(", caso.id_operacao as 'caso.id_operacao'")
						.append(", caso.id_sla_fila as 'caso.id_sla_fila'")
						.append(", tipoCaso.nome as 'caso.nome_tipo_caso'")
						.append(", configFila.nome as 'caso.nome_configuracao_fila'")
					.append("FROM tb_caso caso with(nolock) ")
					.append(" INNER JOIN tb_status status with(nolock) ")
					.append("  ON caso.id_status = status.id_status ")
					.append(" LEFT JOIN tb_tipo_caso tipoCaso with(nolock) ")
					.append("  ON tipoCaso.id_tipo_caso = caso.id_tipo_caso ")
					.append(" LEFT JOIN tb_configuracao_fila configFila with(nolock) ")
					.append("  ON configFila.id_configuracao_fila = caso.id_configuracao_fila ")
					.append("WHERE caso.flag_finalizado = 0 ")
					.append("AND caso.data_fim_sla IS NULL ")
					.append("AND caso.id_operacao = ? ")
					.append("AND status.flag_conta_sla = 1 ");

			PreparedStatement stmt = super.getPreparedStatement(sql.toString(), HintNumberRows.ROWS_CASO.getRows());
			stmt.setInt(1, idOperacao);
			ResultSet resultSet = stmt.executeQuery();

			if (resultSet != null) {
				while (resultSet.next()) {
					CasoTO to = new CasoTO();
					to.setIdCaso((Integer) resultSet.getObject("caso.id_caso"));
					to.setIdExterno((String) resultSet.getObject("caso.id_externo"));
					to.setIdTipoCaso((Integer) resultSet.getObject("caso.id_tipo_caso"));
					to.setIdConfiguracaoFila((Integer) resultSet.getObject("caso.id_configuracao_fila"));
					to.setDataAbertura(resultSet.getTimestamp("caso.data_abertura"));
					to.setDataFimSla(resultSet.getTimestamp("caso.data_fim_sla"));
					to.setIdOperacao(resultSet.getInt("caso.id_operacao"));
					to.setDataPrevistaFimSla(resultSet.getTimestamp("caso.data_prevista_fim_sla"));
					to.setSlaFilaTO(resultSet.getObject("caso.id_sla_fila") != null ? new SlaFilaTO((Integer) resultSet.getObject("caso.id_sla_fila")) : null);
					to.setNomeTipoCaso((String) resultSet.getObject("caso.nome_tipo_caso"));
					to.setNomeConfiguracaoFila((String) resultSet.getObject("caso.nome_configuracao_fila"));
					casos.add(to);
				}
			}
			return casos;

		} finally {
			super.closeConnection();
		}
	}

	public List<CasoTO> buscaCasosFechadosNoDia(Integer idOperacao) throws Exception {
		List<CasoTO> casos = new ArrayList<CasoTO>();
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			StringBuilder sql = new StringBuilder()
					.append("SELECT caso.id_caso as 'caso.id_caso'")
					.append(", caso.id_externo as 'caso.id_externo'")
					.append(", caso.id_tipo_caso as 'caso.id_tipo_caso'")
					.append(", caso.id_configuracao_fila as 'caso.id_configuracao_fila'")
					.append(", caso.data_abertura as 'caso.data_abertura'")
					.append(", caso.data_fim_sla as 'caso.data_fim_sla'")
					.append(", caso.id_sla_fila as 'caso.id_sla_fila'")
					.append(", caso.id_operacao as 'caso.id_operacao'")
					.append(", tipoCaso.nome as 'caso.nome_tipo_caso'")
					.append(", configFila.nome as 'caso.nome_configuracao_fila'")
				.append("FROM tb_caso caso with(nolock) ")
				.append(" LEFT JOIN tb_tipo_caso tipoCaso with(nolock) ")
				.append("  ON tipoCaso.id_tipo_caso = caso.id_tipo_caso ")
				.append(" LEFT JOIN tb_configuracao_fila configFila with(nolock) ")
				.append("  ON configFila.id_configuracao_fila = caso.id_configuracao_fila ")
				.append("WHERE caso.flag_finalizado = 1 ")
				.append("AND caso.data_encerramento BETWEEN ? AND ? ")
				.append("AND caso.id_operacao = ? ");

			Calendar dataInicio = new GregorianCalendar(Calendar.getInstance().get(Calendar.YEAR), Calendar.getInstance().get(Calendar.MONTH), Calendar.getInstance().get(Calendar.DAY_OF_MONTH), Integer.valueOf(0), Integer.valueOf(0));
			Calendar dataFim = new GregorianCalendar(Calendar.getInstance().get(Calendar.YEAR), Calendar.getInstance().get(Calendar.MONTH), Calendar.getInstance().get(Calendar.DAY_OF_MONTH), Integer.valueOf(23), Integer.valueOf(59));

			PreparedStatement stmt = super.getPreparedStatement(sql.toString(), HintNumberRows.ROWS_CASO.getRows());
			stmt.setString(1, df.format(dataInicio.getTime()));
			stmt.setString(2, df.format(dataFim.getTime()));
			stmt.setInt(3, idOperacao);
			ResultSet resultSet = stmt.executeQuery();

			if (resultSet != null) {
				while (resultSet.next()) {
					CasoTO to = new CasoTO();
					to.setIdCaso((Integer) resultSet.getObject("caso.id_caso"));
					to.setIdExterno((String) resultSet.getObject("caso.id_externo"));
					to.setIdTipoCaso((Integer) resultSet.getObject("caso.id_tipo_caso"));
					to.setIdConfiguracaoFila((Integer) resultSet.getObject("caso.id_configuracao_fila"));
					to.setDataAbertura(resultSet.getTimestamp("caso.data_abertura"));
					to.setDataFimSla(resultSet.getTimestamp("caso.data_fim_sla"));
					to.setIdOperacao(resultSet.getInt("caso.id_operacao"));
					to.setSlaFilaTO(resultSet.getObject("caso.id_sla_fila") != null ? new SlaFilaTO((Integer) resultSet.getObject("caso.id_sla_fila")) : null);
					to.setNomeTipoCaso((String) resultSet.getObject("caso.nome_tipo_caso"));
					to.setNomeConfiguracaoFila((String) resultSet.getObject("caso.nome_configuracao_fila"));
					casos.add(to);
				}
			}
			return casos;

		} finally {
			super.closeConnection();
		}
	}

	public List<CasoTO> buscaCasosPendenteChecagem(Integer idOperacao) throws Exception {
		List<CasoTO> casos = new ArrayList<CasoTO>();
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		
		try {
			String pendente = "PENDENTE DE CHECAGEM";
			StringBuilder sql = new StringBuilder()
					.append("SELECT caso.id_caso as 'caso.id_caso'")
					.append(", caso.id_externo as 'caso.id_externo'")
					.append(", caso.id_tipo_caso as 'caso.id_tipo_caso'")
					.append(", caso.id_configuracao_fila as 'caso.id_configuracao_fila'")
					.append(", caso.data_abertura as 'caso.data_abertura'")
					.append(", caso.data_fim_sla as 'caso.data_fim_sla'")
					.append(", caso.id_sla_fila as 'caso.id_sla_fila'")
					.append(", caso.id_operacao as 'caso.id_operacao'")
					.append(", tipoCaso.nome as 'caso.nome_tipo_caso'")
					.append(", configFila.nome as 'caso.nome_configuracao_fila'")
				.append("FROM tb_caso caso with(nolock) ")
				.append(" LEFT JOIN tb_tipo_caso tipoCaso with(nolock) ")
				.append("  ON tipoCaso.id_tipo_caso = caso.id_tipo_caso ")
				.append(" LEFT JOIN tb_configuracao_fila configFila with(nolock) ")
				.append("  ON configFila.id_configuracao_fila = caso.id_configuracao_fila ")
				.append("WHERE caso.flag_finalizado = 0 ")
				.append("AND caso.id_operacao = ? ")
				.append("AND caso.data_fim_sla IS NULL ")
				.append("AND caso.data_encerramento BETWEEN ? AND ? ")
				.append("AND caso.id_status = ( SELECT TOP 1 status.id_status ")
					.append("FROM tb_status status with(nolock) ")
					.append("WHERE status.nome LIKE ?) ");

			Calendar dataInicio = new GregorianCalendar(Calendar.getInstance().get(Calendar.YEAR), Calendar.getInstance().get(Calendar.MONTH), Calendar.getInstance().get(Calendar.DAY_OF_MONTH), Integer.valueOf(0), Integer.valueOf(0));
			Calendar dataFim = new GregorianCalendar(Calendar.getInstance().get(Calendar.YEAR), Calendar.getInstance().get(Calendar.MONTH), Calendar.getInstance().get(Calendar.DAY_OF_MONTH), Integer.valueOf(23), Integer.valueOf(59));

			PreparedStatement stmt = super.getPreparedStatement(sql.toString(), HintNumberRows.ROWS_CASO.getRows());
			stmt.setInt(1, idOperacao);
			stmt.setString(2, df.format(dataInicio.getTime()));
			stmt.setString(3, df.format(dataFim.getTime()));
			stmt.setString(4, pendente);
			ResultSet resultSet = stmt.executeQuery();

			if (resultSet != null) {
				while (resultSet.next()) {
					CasoTO to = new CasoTO();
					to.setIdCaso((Integer) resultSet.getObject("caso.id_caso"));
					to.setIdExterno((String) resultSet.getObject("caso.id_externo"));
					to.setIdTipoCaso((Integer) resultSet.getObject("caso.id_tipo_caso"));
					to.setIdOperacao(resultSet.getInt("caso.id_operacao"));
					to.setIdConfiguracaoFila((Integer) resultSet.getObject("caso.id_configuracao_fila"));
					to.setDataAbertura(resultSet.getTimestamp("caso.data_abertura"));
					to.setDataFimSla(resultSet.getTimestamp("caso.data_fim_sla"));
					to.setSlaFilaTO(resultSet.getObject("caso.id_sla_fila") != null ? new SlaFilaTO((Integer) resultSet.getObject("caso.id_sla_fila")) : null);
					to.setNomeTipoCaso((String) resultSet.getObject("caso.nome_tipo_caso"));
					to.setNomeConfiguracaoFila((String) resultSet.getObject("caso.nome_configuracao_fila"));
					casos.add(to);
				}
			}
			return casos;

		} finally {
			super.closeConnection();
		}
	}

	public List<GenericTO> findIdsTipoCasoAtivos(Integer idOperacao) throws Exception {
		List<GenericTO> tipoManifestacoes = new ArrayList<GenericTO>();
		try {
			StringBuilder sql = new StringBuilder().append("SELECT tpc.id_tipo_caso as 'tpc.id_tipo_caso'").append(", tpc.nome as 'tpc.nome'").append(", tpc.id_operacao as 'tpc.id_operacao'").append("FROM tb_tipo_caso tpc with(nolock) ").append("WHERE tpc.flag_ativo = 1 ").append("AND tpc.id_operacao = ? ");

			PreparedStatement stmt = super.getPreparedStatement(sql.toString());
			stmt.setInt(1, idOperacao);
			ResultSet resultSet = stmt.executeQuery();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					GenericTO to = new GenericTO();
					to.setId((Integer) resultSet.getObject("tpc.id_tipo_caso"));
					to.setNome(resultSet.getString("tpc.nome"));
					to.setIdOperacao((Integer) resultSet.getObject("tpc.id_operacao"));
					tipoManifestacoes.add(to);
				}
			}
			return tipoManifestacoes;

		} finally {
			super.closeConnection();
		}
	}

	public List<GenericTO> findIdsConfiguracaoFilaoAtivos(Integer idOperacao) throws Exception {
		List<GenericTO> confFilas = new ArrayList<GenericTO>();
		try {
			StringBuilder sql = new StringBuilder().append("SELECT cff.id_configuracao_fila as 'cff.id_configuracao_fila', ").append("cff.nome as 'cff.nome', ").append("cff.id_operacao as 'cff.id_operacao'").append("FROM tb_configuracao_fila cff with(nolock) ").append("WHERE cff.flag_ativo = 1 ").append("AND cff.id_operacao = ? ");

			PreparedStatement stmt = super.getPreparedStatement(sql.toString());
			stmt.setInt(1, idOperacao);
			ResultSet resultSet = stmt.executeQuery();
			if (resultSet != null) {
				while (resultSet.next()) {
					GenericTO to = new GenericTO();
					to.setId((Integer) resultSet.getObject("cff.id_configuracao_fila"));
					to.setNome(resultSet.getString("cff.nome"));
					to.setIdOperacao((Integer) resultSet.getObject("cff.id_operacao"));
					confFilas.add(to);
				}
			}
			return confFilas;

		} finally {
			super.closeConnection();
		}
	}

	public void removeEvolucaoAtendimento(Integer idOperacao) throws Exception {
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			StringBuilder sql = new StringBuilder().append("delete from tb_evolucao_atendimento where id_operacao = ? and data_relatorio between ? and ?  ");

			Calendar dataInicio = new GregorianCalendar(Calendar.getInstance().get(Calendar.YEAR), Calendar.getInstance().get(Calendar.MONTH), Calendar.getInstance().get(Calendar.DAY_OF_MONTH), Integer.valueOf(0), Integer.valueOf(0));
			Calendar dataFim = new GregorianCalendar(Calendar.getInstance().get(Calendar.YEAR), Calendar.getInstance().get(Calendar.MONTH), Calendar.getInstance().get(Calendar.DAY_OF_MONTH), Integer.valueOf(23), Integer.valueOf(59));

			PreparedStatement stmt = super.getPreparedStatement(sql.toString());
			stmt.setInt(1, idOperacao);
			stmt.setString(2, df.format(dataInicio.getTime()));
			stmt.setString(3, df.format(dataFim.getTime()));
			stmt.executeUpdate();
			
		} finally {
			super.closeConnection();
		}
	}

	public void saveEvolucaoAtendimento(List<EvolucaoAtendimentoTO> evolAtendimentos) throws Exception {

		Connection connection = null;
		EvolucaoAtendimentoTO evolAtendimento = null;

		try {

			connection = getConnection();
			connection.setAutoCommit(false);

			StringBuilder sql = new StringBuilder().append("INSERT INTO tb_evolucao_atendimento ").append("(data_relatorio, ").append("tipo_maifestacao, ").append("total_entrantes, ").append("pendente_dentro_prazo, ").append("pendente_fora_prazo, ").append("pendente_total, ").append("fechado_dentro_prazo, ").append("fechado_fora_prazo, ").append("saldo_percentual, ")
					.append("saldo_quantidade, ").append("pendente_fora_prazo_percentual, ").append("fechado_total, ").append("total_reabertos, ").append("total_reabertos_entrantes, ").append("fechado_fora_prazo_percentual, ").append("id_operacao, ").append("configuracao_fila, ").append("flag_filtro_fila) ")
					.append("VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ");

			PreparedStatement stmt = connection.prepareStatement(sql.toString());
			stmt.setFetchSize(evolAtendimentos.size());

			int count = 0;
			for (int i = 0; i < evolAtendimentos.size(); i++) {

				evolAtendimento = evolAtendimentos.get(i);

				stmt.setTimestamp(1, new Timestamp(evolAtendimento.getDataRelatorio().getTime()));
				if(evolAtendimento.getTipoCaso() != null) { 
					stmt.setString(2, evolAtendimento.getTipoCaso());
				} else {
					stmt.setNull(2, Types.NULL);
				}
				stmt.setInt(3, evolAtendimento.getTotalEntrantes());
				stmt.setInt(4, evolAtendimento.getPendenteDentroPrazo());
				stmt.setInt(5, evolAtendimento.getPendenteForaPrazo());
				stmt.setInt(6, evolAtendimento.getPendenteTotal());
				stmt.setInt(7, evolAtendimento.getFechadoDentroPrazo());
				stmt.setInt(8, evolAtendimento.getFechadoForaPrazo());
				stmt.setDouble(9, evolAtendimento.getSaldoPercentual());
				stmt.setInt(10, evolAtendimento.getSaldoQuantidade());
				stmt.setDouble(11, evolAtendimento.getPendenteForaPrazoPercentual());
				stmt.setInt(12, evolAtendimento.getFechadoTotal());
				stmt.setInt(13, evolAtendimento.getTotalReabertos());
				stmt.setInt(14, evolAtendimento.getTotalReabertosEntrantes());
				stmt.setDouble(15, evolAtendimento.getFechadoForaPrazoPercentual());
				stmt.setInt(16, evolAtendimento.getOperacao());
				if(evolAtendimento.getConfiguracaoFila() != null) { 
					stmt.setString(17, evolAtendimento.getConfiguracaoFila());
				} else {
					stmt.setNull(17, Types.NULL);
				}
				stmt.setInt(18, evolAtendimento.getFlagFiltroFila() == true ? 1 : 0);

				stmt.addBatch();

				if (++count % Constantes.BATCH_SIZE == 0) {
					stmt.executeBatch();
					connection.commit();
				}

			}
			stmt.executeBatch();
			connection.commit();
			
		} catch (Exception e) {
			if(connection != null && !connection.isClosed()){
				connection.rollback();
			}
			throw e;

		} finally {
			super.closeConnection();
		}
	}
	
	public void removeEvolucaoAtendimentoDetalhe(Integer idOperacao) throws Exception {
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			StringBuilder sql = new StringBuilder().append("delete from tb_evolucao_atendimento_detalhe where id_operacao = ? and data_relatorio between ? and ?  ");

			Calendar dataInicio = new GregorianCalendar(Calendar.getInstance().get(Calendar.YEAR), Calendar.getInstance().get(Calendar.MONTH), Calendar.getInstance().get(Calendar.DAY_OF_MONTH), Integer.valueOf(0), Integer.valueOf(0));
			Calendar dataFim = new GregorianCalendar(Calendar.getInstance().get(Calendar.YEAR), Calendar.getInstance().get(Calendar.MONTH), Calendar.getInstance().get(Calendar.DAY_OF_MONTH), Integer.valueOf(23), Integer.valueOf(59));

			PreparedStatement stmt = super.getPreparedStatement(sql.toString());
			stmt.setInt(1, idOperacao);
			stmt.setString(2, df.format(dataInicio.getTime()));
			stmt.setString(3, df.format(dataFim.getTime()));
			stmt.executeUpdate();
		} finally {
			super.closeConnection();
		}
	}
	
	public void saveEvolucaoAtendimentoDetalhe(List<EvolucaoAtendimentoDetalheTO> evolAtendimentosDetalhe) throws Exception {

		Connection connection = null;
		EvolucaoAtendimentoDetalheTO evolAtendimentoDetalhe = null;
		try {

			connection = getConnection();
			connection.setAutoCommit(false);

			StringBuilder sql = new StringBuilder().append("INSERT INTO tb_evolucao_atendimento_detalhe ").append("(id_evolucao_atendimento, ").append("id_caso, ").append("id_externo, ").append("id_tipo_caso, ").append("tipo_caso, ").append("id_configuracao_fila, ").append("configuracao_fila, ").append("mnemonico, ").append("flag_dentro_prazo, ").append("id_operacao, ")
					.append("data_relatorio) ").append("VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ");

			PreparedStatement stmt = connection.prepareStatement(sql.toString());
			stmt.setFetchSize(evolAtendimentosDetalhe.size());

			int count = 0;
			for (int i = 0; i < evolAtendimentosDetalhe.size(); i++) {

				evolAtendimentoDetalhe = evolAtendimentosDetalhe.get(i);

				if (evolAtendimentoDetalhe.getIdEvolucaoAtendimento() != null) {

					stmt.setInt(1, evolAtendimentoDetalhe.getIdEvolucaoAtendimento());
					stmt.setInt(2, evolAtendimentoDetalhe.getIdCaso());
					stmt.setString(3, evolAtendimentoDetalhe.getIdExterno());
					if (evolAtendimentoDetalhe.getIdTipoCaso() != null) {
						stmt.setInt(4, evolAtendimentoDetalhe.getIdTipoCaso());
					} else {
						stmt.setNull(4, Types.NULL);
					}
					if (evolAtendimentoDetalhe.getTipoCaso() != null) {
						stmt.setString(5, evolAtendimentoDetalhe.getTipoCaso());
					} else {
						stmt.setNull(5, Types.NULL);
					}
					if (evolAtendimentoDetalhe.getIdConfiguracaoFila() != null) {
						stmt.setInt(6, evolAtendimentoDetalhe.getIdConfiguracaoFila());
					} else {
						stmt.setNull(6, Types.NULL);
					}
					if (evolAtendimentoDetalhe.getConfiguracaoFila() != null) {
						stmt.setString(7, evolAtendimentoDetalhe.getConfiguracaoFila());
					} else {
						stmt.setNull(7, Types.NULL);
					}
					stmt.setString(8, evolAtendimentoDetalhe.getMnemonico());
					stmt.setInt(9, evolAtendimentoDetalhe.getFlagDentroPrazo() == true ? 1 : 0);
					stmt.setInt(10, evolAtendimentoDetalhe.getIdOperacao());
					stmt.setTimestamp(11, new Timestamp(evolAtendimentoDetalhe.getDataRelatorio().getTime()));

					stmt.addBatch();

					if (++count % Constantes.BATCH_SIZE == 0) {
						stmt.executeBatch();
						connection.commit();
					}
				}
			}

			stmt.executeBatch();
			connection.commit();
		} finally {
			super.closeConnection();
		}
	}

	public List<EvolucaoAtendimentoTO> getEvolucaoAtendimentoInseridos(Integer idOperacao) throws Exception {

		List<EvolucaoAtendimentoTO> lista = null;
		try {
			String sql = "SELECT id_evolucao_atendimento,data_relatorio, tipo_maifestacao, total_entrantes, pendente_dentro_prazo, pendente_fora_prazo, pendente_total, fechado_dentro_prazo, fechado_fora_prazo, saldo_percentual, saldo_quantidade, pendente_fora_prazo_percentual, fechado_total, total_reabertos, total_reabertos_entrantes, fechado_fora_prazo_percentual, id_operacao, configuracao_fila, flag_filtro_fila FROM tb_evolucao_atendimento WHERE ID_OPERACAO = ?";
			PreparedStatement stmt = super.getPreparedStatement(sql);
			stmt.setInt(1, idOperacao);

			ResultSet rs = stmt.executeQuery();

			if (rs != null) {
				lista = new ArrayList<EvolucaoAtendimentoTO>();
				while (rs.next()) {

					EvolucaoAtendimentoTO to = new EvolucaoAtendimentoTO();
					to.setIdEvolucaoAtendimento(rs.getInt("id_evolucao_atendimento"));
					to.setDataRelatorio(rs.getDate("data_relatorio"));
					to.setTipoCaso(rs.getString("tipo_maifestacao"));
					to.setTotalEntrantes(rs.getInt("total_entrantes"));
					to.setPendenteDentroPrazo(rs.getInt("pendente_dentro_prazo"));
					to.setPendenteForaPrazo(rs.getInt("pendente_fora_prazo"));
					to.setPendenteTotal(rs.getInt("pendente_total"));
					to.setFechadoDentroPrazo(rs.getInt("fechado_dentro_prazo"));
					to.setFechadoForaPrazo(rs.getInt("fechado_fora_prazo"));
					to.setSaldoPercentual(rs.getDouble("saldo_percentual"));
					to.setSaldoQuantidade(rs.getInt("saldo_quantidade"));
					to.setPendenteForaPrazoPercentual(rs.getDouble("pendente_fora_prazo_percentual"));
					to.setFechadoTotal(rs.getInt("fechado_total"));
					to.setTotalReabertos(rs.getInt("total_reabertos"));
					to.setTotalReabertosEntrantes(rs.getInt("total_reabertos_entrantes"));
					to.setFechadoForaPrazoPercentual(rs.getDouble("fechado_fora_prazo_percentual"));
					to.setOperacao(rs.getInt("id_operacao"));
					to.setConfiguracaoFila(rs.getString("configuracao_fila"));
					to.setFlagFiltroFila(rs.getBoolean("flag_filtro_fila"));
					lista.add(to);

				}
			}

		} catch (Exception e) {
			throw e;
		} finally {
			super.closeConnection();
		}

		return lista;
	}

}
