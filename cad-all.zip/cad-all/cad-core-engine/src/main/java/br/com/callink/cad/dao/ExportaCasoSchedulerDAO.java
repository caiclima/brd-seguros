package br.com.callink.cad.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.com.callink.cad.to.ExportaCasoSchedulerDataTO;
import br.com.callink.cad.to.ExportaCasoSchedulerTO;

public class ExportaCasoSchedulerDAO extends GenericDAO {

	public ExportaCasoSchedulerTO findExportaCasoSchedulerByJob(Integer idJob) throws Exception {
		try {
			ExportaCasoSchedulerTO exportaCasoSchedulerTO = null;
	
			StringBuilder sql = new StringBuilder();
			sql.append(SELECT);
			sql.append(ExportaCasoSchedulerTO.getSqlCamposExportaCasoScheduler());
			sql.append(FROM);
			sql.append(ExportaCasoSchedulerTO.getSqlFromExportaCasoScheduler());
			sql.append(WHERE);
			sql.append(" ExportaCasoScheduler.ID_JOB = ? ");
			sql.append(" AND ExportaCasoScheduler.FLAG_ATIVO = 1 ");
	
			PreparedStatement ps = super.getPreparedStatement(sql.toString());
	
			ps.setInt(1, idJob);
	
			ResultSet rs = ps.executeQuery();
	
			if (rs != null && rs.next()) {
				exportaCasoSchedulerTO = ExportaCasoSchedulerTO.getExportaCasoSchedulerByResultSet(rs);
			}
			return exportaCasoSchedulerTO;
		} finally {
			super.closeConnection();
		}
	}
	
	public List<ExportaCasoSchedulerDataTO> findExportaCasoSchedulerDataByExporta(Integer idExportaCasoScheduler) throws Exception {
		try {
			List<ExportaCasoSchedulerDataTO> list = new ArrayList<ExportaCasoSchedulerDataTO>();
	
			StringBuilder sql = new StringBuilder();
			sql.append(SELECT);
			sql.append(ExportaCasoSchedulerDataTO.getSqlCamposExportaCasoSchedulerData());
			sql.append(FROM);
			sql.append(ExportaCasoSchedulerDataTO.getSqlFromExportaCasoSchedulerData());
			sql.append(WHERE);
			sql.append(" ExportaCasoSchedulerData.ID_EXPORTA_CASO_SCHEDULER = ? ");
	
			PreparedStatement ps = super.getPreparedStatement(sql.toString());
	
			ps.setInt(1, idExportaCasoScheduler);
	
			ResultSet rs = ps.executeQuery();
	
			if (rs != null && rs.next()) {
				list.add(ExportaCasoSchedulerDataTO.getExportaCasoSchedulerDataByResultSet(rs));
			}
			return list;
		} finally {
			super.closeConnection();
		}
	}

}