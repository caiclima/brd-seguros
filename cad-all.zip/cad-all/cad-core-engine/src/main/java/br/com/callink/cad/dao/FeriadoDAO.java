package br.com.callink.cad.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.com.callink.cad.to.FeriadoTO;


public class FeriadoDAO extends GenericDAO {

	public List<FeriadoTO> findAll() throws Exception {
		try {
			List<FeriadoTO> slas = new ArrayList<>();
			
			StringBuilder sql = new StringBuilder();
			sql.append(SELECT);
			sql.append(FeriadoTO.getSqlCamposFeriado());
			sql.append(FROM);
			sql.append(FeriadoTO.getSqlFromFeriado());
			
			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ResultSet rs = ps.executeQuery();
			
			if(rs != null){
				while(rs.next()){
					FeriadoTO sla = FeriadoTO.getFeriadoByResultSet(rs);
					slas.add(sla);
				}
			}
			
			return slas;
			
		} finally {
			super.closeConnection();
		}
	}
	
	public List<FeriadoTO> findFeriadosOperacao(Integer idOperacao)  throws Exception {
		try {
			List<FeriadoTO> feriados = new ArrayList<>();
			
			StringBuilder sql = new StringBuilder();
			sql.append(SELECT);
			sql.append(FeriadoTO.getSqlCamposFeriado());
			sql.append(FROM);
			sql.append(FeriadoTO.getSqlFromFeriado())
			.append(" where id_operacao = ? ");
			
			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			
			ps.setInt(1, idOperacao);
			
			ResultSet rs = ps.executeQuery();
			
			if(rs != null){
				while(rs.next()){
					FeriadoTO feriado = FeriadoTO.getFeriadoByResultSet(rs);
					feriados.add(feriado);
				}
			}
			
			return feriados;
			
		} finally {
			super.closeConnection();
		}		
	}
	
}