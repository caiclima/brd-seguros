package br.com.callink.cad.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.com.callink.cad.to.FiltroCasoCampoTO;

public class FiltroCasoDAO extends GenericDAO {

	public List<FiltroCasoCampoTO> findCamposFiltroCaso(Integer idFiltroCaso) throws Exception {
		try {
			List<FiltroCasoCampoTO> camposFiltro = new ArrayList<FiltroCasoCampoTO>();
	
			StringBuilder sql = new StringBuilder();
			sql.append(SELECT);
			sql.append(FiltroCasoCampoTO.getSqlCamposFiltroCasoCampo());
			sql.append(FROM);
			sql.append(FiltroCasoCampoTO.getSqlFromFiltroCasoCampo());
			sql.append(WHERE);
			sql.append(" FiltroCasoCampo.ID_FILTRO_CASO = ? ");
			
			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			
			ps.setInt(1, idFiltroCaso);
			
			ResultSet rs = ps.executeQuery();
	
			if (rs != null) {
				while (rs.next()) {
					camposFiltro.add(FiltroCasoCampoTO.getFiltroCasoCampoByResultSet(rs));
				}
				
			}
			return camposFiltro;
		} finally {
			super.closeConnection();
		}
	}

}