package br.com.callink.cad.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.com.callink.cad.to.FiltroExportarDadosCampoTO;

public class FiltroExportarCasoDAO extends GenericDAO {

	public List<FiltroExportarDadosCampoTO> findCamposFiltroExportarCaso(Integer idFiltroExportarDados) throws Exception {
		try {
			List<FiltroExportarDadosCampoTO> camposFiltroExportar = new ArrayList<FiltroExportarDadosCampoTO>();
	
			StringBuilder sql = new StringBuilder();
			sql.append(SELECT);
			sql.append(FiltroExportarDadosCampoTO.getSqlCamposFiltroExportarDadosCampo());
			sql.append(FROM);
			sql.append(FiltroExportarDadosCampoTO.getSqlFromFiltroExportarDadosCampo());
			sql.append(WHERE);
			sql.append(" FiltroExportarDadosCampo.ID_FILTRO_EXPORTAR_DADOS = ? ");
			
			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			
			ps.setInt(1, idFiltroExportarDados);
			
			ResultSet rs = ps.executeQuery();
	
			if (rs != null) {
				while (rs.next()) {
					FiltroExportarDadosCampoTO filtroExportarDadosCampoTO = FiltroExportarDadosCampoTO.getFiltroExportarDadosCampoByResultSet(rs);
					camposFiltroExportar.add(filtroExportarDadosCampoTO);
				}
				
			}
			return camposFiltroExportar;
		} finally {
			super.closeConnection();
		}
	}
	
}
