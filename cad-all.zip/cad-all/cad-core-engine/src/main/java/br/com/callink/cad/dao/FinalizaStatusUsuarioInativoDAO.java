package br.com.callink.cad.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import br.com.callink.cad.util.StringUtils;

public class FinalizaStatusUsuarioInativoDAO extends GenericDAO {

	public void atualizaFlagLogado(List<Integer> listaUsuario) throws Exception {
		try {
			if (listaUsuario != null && listaUsuario.size() > 0) {
				StringBuilder sql = new StringBuilder();
				sql.append(" update tb_usuario_logado set flag_logado = 0, flag_solicita_alteracao_status = 0, flag_em_atendimento = 0 ");
				sql.append(MessageFormat.format(" where id_usuario IN ({0}) ", StringUtils.join(listaUsuario.iterator(), ",", false)));

				PreparedStatement ps = super.getPreparedStatement(sql.toString());
				ps.executeUpdate();
			}

		} finally {
			super.closeConnection();
		}
	}

	public void atualizaFlagEmAtendimentoParaFalse(List<Integer> listaUsuario) throws Exception {
		try {
			if (listaUsuario != null && listaUsuario.size() > 0) {
				StringBuilder str = new StringBuilder();
				str.append(" update tb_caso set flag_em_atendimento = 0 where flag_em_atendimento = 1 and id_usuario in ( ")
					.append(StringUtils.join(listaUsuario.iterator(), ",", false)).append(") ");
				
				PreparedStatement ps = super.getPreparedStatement(str.toString());
				ps.executeUpdate();
			}

		} finally {
			super.closeConnection();
		}
	}

	public void finalizaStatusUsuarioSemDataFim() throws Exception {
		try {
			PreparedStatement ps = super
					.getPreparedStatement(" update tb_status_usuario set data_fim = data_inicio where data_fim is null and data_inicio < dateadd(hh, -9, getdate()) ");
			ps.executeUpdate();

		} finally {
			super.closeConnection();
		}
	}

	public List<Integer> validaFinalizaStatusUsuario(Integer idOperacao, Integer minutosFinalizaSessao) throws Exception {
		try {
			StringBuilder sql = new StringBuilder();
			sql.append("SELECT ul.id_usuario as idUser ");
			sql.append("FROM tb_usuario_logado ul with(nolock) ");
			sql.append("WHERE EXISTS ( ");
			sql.append("	SELECT 1 ");
			sql.append("	FROM tb_operacao_usuario opUsr with(nolock) ");
			sql.append("	WHERE opUsr.id_usuario = ul.id_usuario ");
			sql.append("	  AND opUsr.id_operacao = ? ").append(" AND flag_operacao_principal = 1 ");
			sql.append("	) ");
			sql.append("  AND datediff(mi, ul.data_ping, getdate()) > ? and flag_logado = 1 ");

			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ps.setInt(1, idOperacao);
			ps.setInt(2, minutosFinalizaSessao);
			ResultSet resultSet = ps.executeQuery();

			List<Integer> usuarioRemoveList = new ArrayList<Integer>();
			if (resultSet != null) {
				while (resultSet.next()) {
					usuarioRemoveList.add(resultSet.getInt("idUser"));
				}
			}

			return usuarioRemoveList;
			
		} finally {
			super.closeConnection();
		}
	}
}
