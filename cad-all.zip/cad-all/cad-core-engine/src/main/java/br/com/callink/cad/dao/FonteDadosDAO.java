package br.com.callink.cad.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.com.callink.cad.to.FonteDadosTO;
import br.com.callink.cad.to.LayoutImportacaoTO;

public class FonteDadosDAO extends GenericDAO {

	public FonteDadosTO buscaFonteDadosById(Integer idFonteDados) throws Exception {
		try {
			StringBuilder sql = new StringBuilder();
			sql.append(SELECT);
			sql.append(FonteDadosTO.getSqlColuns());
			sql.append(FROM);
			sql.append(FonteDadosTO.getSqlFrom());
			sql.append(WHERE);
			sql.append(" fonteDados.id_fonte_dados = ? ");

			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ps.setInt(1, idFonteDados);
			ResultSet resultSet = ps.executeQuery();

			if (resultSet != null) {
				while (resultSet.next()) {
					FonteDadosTO fonteDadosTO = FonteDadosTO.getFonteDadosTOByResultSet(resultSet);
					return fonteDadosTO;
				}
			}
			return null;
		} finally {
			super.closeConnection();
		}
	}
	
	public List<LayoutImportacaoTO> buscaLayoutImportacaoByJob(Integer idJob) throws Exception {
		try {
			StringBuilder sql = new StringBuilder();
			sql.append(SELECT);
			sql.append(LayoutImportacaoTO.getSqlColuns());
			sql.append(FROM);
			sql.append(LayoutImportacaoTO.getSqlFrom());
			sql.append(WHERE);
			sql.append(" layout.id_job = 1 ");

			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ps.setInt(1, idJob);
			ResultSet resultSet = ps.executeQuery();

			List<LayoutImportacaoTO> ret = new ArrayList<LayoutImportacaoTO>();
			if (resultSet != null) {
				while (resultSet.next()) {
					LayoutImportacaoTO layout = LayoutImportacaoTO.getLayoutImportacaoTOByResultSet(resultSet);
					ret.add(layout);
				}
			}
			return ret;
		} finally {
			super.closeConnection();
		}
	}
}
