package br.com.callink.cad.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Calendar;
import java.util.Date;
import javax.annotation.Resource;
import javax.sql.DataSource;

public class GenericDAO {

	@Resource(mappedName = "java:jboss/datasources/CAD_DS")
	private DataSource ds;

	private Connection connection;
	private PreparedStatement stmt;
	private CallableStatement cs;

	protected final static String INSERT = " INSERT INTO ";
	protected final static String UPDATE = " UPDATE ";
	protected final static String SELECT = " SELECT ";
	protected final static String SET = " SET ";
	protected final static String FROM = " FROM ";
	protected final static String WHERE = " WHERE ";
	protected final static String INNER_JOIN = " INNER JOIN ";
	protected final static String LEFT_JOIN = " LEFT JOIN ";

	private void setUp() throws Exception {
		if (ds == null) {
			ds = (DataSource) new javax.naming.InitialContext().lookup("java:jboss/datasources/CAD_DS");
		}

		if (ds != null && connection == null) {
			connection = ds.getConnection();
		}
	}

	protected Connection getConnection() throws Exception {
		setUp();

		if (connection == null || connection.isClosed()) {
			connection = ds.getConnection();
		}
		return connection;
	}

	public Date getDataBanco() throws Exception {
		try {
			getPreparedStatement("select getdate() as data ");
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				Calendar cal = Calendar.getInstance();
				rs.getTimestamp("data", cal);

				return cal.getTime();
			}
			return null;

		} finally {
			closeConnection();
		}
	}

	protected void closeConnection() throws Exception {
		/*
		 * NAO ESQUECER DE FECHAR A CONEXAO, PARA DEVOLVE-LA PARA O POOL DO JBOSS
		 */
		if (connection != null) {
			connection.close();
		}
		if (stmt != null) {
			stmt.close();
		}
		if (cs != null) {
			cs.close();
		}
	}

	protected PreparedStatement getPreparedStatementId(String sql) throws Exception {
		stmt = getConnection().prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
		return stmt;
	}
	
	protected PreparedStatement getPreparedStatement(String sql) throws Exception {
		stmt = getConnection().prepareStatement(sql);
		return stmt;
	}
	
	protected PreparedStatement getPreparedStatement(String sql, int rows) throws Exception {
		stmt = getConnection().prepareStatement(sql);
		stmt.setFetchSize(rows);
		return stmt;
	}
	
	protected CallableStatement prepareCall(String command) throws Exception {
		cs = getConnection().prepareCall(command);
		return cs;
	}
}
