package br.com.callink.cad.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Types;
import java.util.List;

import br.com.callink.cad.to.ImportCasoTO;
import br.com.callink.cad.util.StringUtils;

public class ImportCasoDAO extends GenericDAO {
	
	private final int BATCH_SIZE = 1000;
	
	public void inserImportCasoNative(List<ImportCasoTO> listImportCasos) throws Exception {
		StringBuilder sql = new StringBuilder();
		StringBuilder values = new StringBuilder();
		
		sql.append(" INSERT INTO tb_import_caso ");
		sql.append(" (");
		sql.append(" id_lote_caso ");
		sql.append(" , id_layout ");
		sql.append(" , flag_import_rejeitado ");
		sql.append(" , id_externo ");
		
		values.append(" VALUES ");
		values.append("( ?, ?, ?, ?");
		
		final ImportCasoTO firstLine = listImportCasos.get(0);
		for (String campo : firstLine.getMapDados().keySet()) {
			sql.append(", ").append(campo);
			values.append(", ?");
		}
		
		sql.append(" ) ");
		values.append(" ) ");
		sql.append(values);
		
		Connection connection = getConnection();
		connection.setAutoCommit(false);

		PreparedStatement stmt = connection.prepareStatement(sql.toString());
		stmt.setFetchSize(listImportCasos.size());
		
		try {
			int countCommit = 0;
			int index = 1;
			boolean insereIdExterno = false;
			boolean flagImportRejeitado = false;
			
			for (ImportCasoTO importCaso : listImportCasos) {
				insereIdExterno = !StringUtils.isEmpty(importCaso.getIdExterno());
				flagImportRejeitado = importCaso.getFlagImportRejeitado() != null && importCaso.getFlagImportRejeitado();
				
				stmt.setString(index++, importCaso.getIdLoteCaso().toString());
				stmt.setString(index++, importCaso.getIdLayout().toString());
				stmt.setString(index++, flagImportRejeitado ? "1" : "0");
				
				if(insereIdExterno) {
					stmt.setString(index++, importCaso.getIdExterno().toString());
				}else{
					stmt.setNull(index++, Types.NULL);
				}
				
				for (String campo : importCaso.getMapDados().keySet()) {
					String aux = (String) importCaso.getMapDados().get(campo);
					
					if (StringUtils.isNotEmpty(aux)) {
						if (Character.getType(aux.toCharArray()[0]) == 16) {
							aux = aux.substring(1);
						}
						stmt.setString(index++, aux);
					} else {
						stmt.setNull(index++, Types.NULL);
					}
				}
				
				index = 1;
				stmt.addBatch();
				
				if (++countCommit % BATCH_SIZE == 0) {
					stmt.executeBatch();
					connection.commit();
				}
			}
			
			stmt.executeBatch(); // insert remaining records
			connection.commit();
			
		} catch (Exception e) {
			if (connection != null && !connection.isClosed()) {
				connection.rollback();
			}
			throw e;
			
		} finally {
			super.closeConnection();
		}
	}
}
