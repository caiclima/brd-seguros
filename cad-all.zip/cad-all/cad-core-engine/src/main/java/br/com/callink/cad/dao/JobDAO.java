package br.com.callink.cad.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

import br.com.callink.cad.to.JobTO;
import br.com.callink.cad.to.NotificacaoAdminTO;
import br.com.callink.cad.to.OperacaoTO;
import br.com.callink.cad.util.HintNumberRows;

public class JobDAO extends GenericDAO {
	
	private final Logger logger = Logger.getLogger(getClass().getName());
	private final int BATCH_SIZE = 1000;

	/**
	 * @return
	 * @throws Exception
	 */
	public List<JobTO> findJobs() throws Exception {
		try {
			StringBuilder sql = new StringBuilder();
			sql.append("select ");
			sql.append(JobTO.getSqlColuns());
			sql.append(JobTO.getSqlFrom());

			PreparedStatement ps = super.getPreparedStatement(sql.toString(), HintNumberRows.ROWS_JOBS.getRows());
			ResultSet rs = ps.executeQuery();

			List<JobTO> list = new ArrayList<>();
			while (rs.next()) {
				list.add(JobTO.getJobTOByResultSet(rs));
			}

			return list;
		} finally {
			super.closeConnection();
		}
	}

	/**
	 * @param jobName
	 * @return
	 * @throws Exception
	 */
	public JobTO buscaOperacaoAtualPorJob(Integer idJob) throws Exception {
		try {
			JobTO jobTO = new JobTO();
			jobTO.setOperacao(new OperacaoTO());
			
			StringBuilder sb = new StringBuilder();
			sb.append("select top 1 jb.id_job, jb.class, jb.nome, jb.descricao, jb.cron, jb.quantidade_job, ass.id_operacao, ass.flag_notifica_falha, operacao.email_admin, operacao.id_tenant ");
			sb.append("from tb_associa_operacao_job ass with(nolock) , tb_job jb with(nolock), tb_operacao operacao with(nolock) ");
			sb.append("where ass.id_job = jb.id_job  ");
			sb.append("and ass.id_operacao = operacao.id_operacao ");
			sb.append("and jb.id_job = ? and jb.flag_ativo = 1 and ass.flag_ativo = 1 and ass.flag_executando = 0 ");
			sb.append("order by data_start_exec asc");

			PreparedStatement stmt = getPreparedStatement(sb.toString(), 1);
			stmt.setInt(1, idJob);
			ResultSet rs = stmt.executeQuery();
			
			if (rs.next()) {
				 jobTO.setId(rs.getInt(1));
				 jobTO.setClazz(rs.getString(2));
				 jobTO.setNome(rs.getString(3));
				 jobTO.setDescricao(rs.getString(4));
				 jobTO.setCronExpression(rs.getString(5));
				 jobTO.setQuantidadeJob(rs.getInt(6));
				 jobTO.getOperacao().setIdOperacao(rs.getInt(7));;
				 jobTO.setFlagNotificaFalha(rs.getBoolean(8));
				 jobTO.getOperacao().setEmailsAdm(rs.getString(9));
				 jobTO.getOperacao().setIdTenant(rs.getInt(10));
				 
				 return jobTO;
			}
			return null;

		} finally {
			closeConnection();
		}
	}

	/**
	 * @param idJob
	 * @param idOperacao
	 * @param dataBase
	 * @param processando
	 * @throws Exception
	 */
	public void atualizaFlagExecucaoPorJobEOperacao(int idJob, int idOperacao, Date dataBase, boolean processando, String sarID) throws Exception {
		try {
			StringBuilder sb = new StringBuilder();
			sb.append("update ass ");

			DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			if (processando) {
				sb.append("set ass.flag_executando = 1 ");
				sb.append(MessageFormat.format(", ass.data_start_exec = ''{0}'' ", df.format(dataBase)));
			} else {
				sb.append("set ass.flag_executando = 0 ");
				sb.append(MessageFormat.format(", ass.data_fim_exec = ''{0}'' ", df.format(dataBase)));
			}
			sb.append(" , ass.sar_id = '").append(sarID).append("' ");
			sb.append("from tb_associa_operacao_job ass with(nolock) , tb_job jb with(nolock) ");
			sb.append("where ass.id_job = jb.id_job  ");
			sb.append("and jb.id_job = ? and ass.id_operacao = ? and ass.flag_ativo = 1 and jb.flag_ativo = 1 ");

			PreparedStatement st = getPreparedStatement(sb.toString());
			st.setInt(1, idJob);
			st.setInt(2, idOperacao);
			st.execute();

		} finally {
			closeConnection();
		}
	}

	public void atualizaFlagExpirada(Integer intervalo) throws Exception {
		
		StringBuilder sq = new StringBuilder();
		sq.append( "update tb_associa_operacao_job set flag_executando = 0 " );
		sq.append( " where DATEDIFF(minute,data_start_exec , getDate()) > ? and data_fim_exec is null " );
		
		try {
			PreparedStatement ps = getPreparedStatement(sq.toString());
			
			ps.setInt(1, intervalo);
			ps.execute();
			
		} finally {
			closeConnection();
		}
	}
	
	/**
	 * Somente atualizar jobs que a data de execução seja menor que a data atual.
	 * @param tempoMinutos
	 * @param dataAtual
	 * @throws Exception
	 */
	public void updateJobsComErro(Integer tempoMinutos) throws Exception {
		StringBuilder sq = new StringBuilder();
		sq.append( " update ass set ass.flag_executando = 0 ")
		.append(" from tb_associa_operacao_job ass with(nolock) ")
		.append(" inner join tb_execucao_job exjob with(nolock) on ass.id_job = exjob.id_job and ass.id_operacao = exjob.id_operacao ")
		.append(" where DATEDIFF(SECOND, exjob.data_controle_sar, getDate()) > ").append(tempoMinutos)
		.append(" and ass.flag_executando = 1 and ass.sar_id = exjob.sar_id ");
		
		try {
			PreparedStatement ps = getPreparedStatement(sq.toString());
			ps.execute();
		} finally {
			closeConnection();
		}
	}
	
	/**
	 * Coloca o flag executando igual a 0 quando a job está sem o registro de controle
	 * @param tempoMinutos
	 * @param dataAtual
	 * @throws Exception
	 */
	public void updateJobsComErroSemControle(Integer tempoMinutos) throws Exception {
		StringBuilder sq = new StringBuilder();
		sq.append(" update ass set ass.flag_executando = 0 ")
		.append(" from tb_associa_operacao_job ass with(nolock), tb_job job with(nolock) ")
		.append(" where ass.sar_id not in (select distinct ex.sar_id from tb_execucao_job ex with(nolock), tb_job jb  with(nolock) where ex.id_job = jb.id_job and jb.flag_ativo = 1) ")
		.append(" and ass.flag_executando = 1 and ass.id_job = job.id_job and job.flag_ativo = 1 and DATEDIFF(SECOND, ass.data_start_exec, getDate()) > ").append(tempoMinutos);
				
		try {
			PreparedStatement ps = getPreparedStatement(sq.toString());
			ps.execute();
		} finally {
			closeConnection();
		}
	}
	
	/**
	 * Insere um novo controle para a job e a operacao
	 * @param idOperacao
	 * @param idJob
	 * @throws Exception
	 */
	public void insereControleJob(Integer idOperacao, Integer idJob, String sarID) throws Exception {
		
		StringBuilder sq = new StringBuilder();
		sq.append( "insert into tb_execucao_job(id_Job,id_Operacao,sar_id,data_controle_sar) " );
		sq.append( " values (?,?,?,getDate()) ");
		
		try {
			PreparedStatement ps = getPreparedStatement(sq.toString());
			ps.setInt(1, idJob);
			ps.setInt(2, idOperacao);
			ps.setString(3, sarID);
			
			ps.executeUpdate();
		} finally {
			closeConnection();
		}
	}
	
	
	public Integer updateDataExecucao(Integer idOperacao, Integer idJob, String sarID) throws Exception {
		StringBuilder sq = new StringBuilder();
		sq.append( "update tb_execucao_job set data_controle_sar = getDate() " );
		sq.append( " where id_Job = ? and id_Operacao = ? and sar_id = ? ");
		
		try {
			PreparedStatement ps = getPreparedStatement(sq.toString());
			ps.setInt(1, idJob);
			ps.setInt(2, idOperacao);
			ps.setString(3, sarID);
			
			ps.executeUpdate();
			
			return ps.getUpdateCount();
		} finally {
			closeConnection();
		}
	}
	
	/**
	 * Deleta o controle da job se existir
	 * @param idOperacao
	 * @param idJob
	 * @throws Exception
	 */
	public void deleteExecucaoJobInativa(Integer idOperacao, Integer idJob) throws Exception {
		
		StringBuilder sq = new StringBuilder();
		sq.append( "delete from tb_execucao_job " );
		sq.append( " where id_operacao = ? and id_job = ? ");
		
		try {
			PreparedStatement ps = getPreparedStatement(sq.toString());
			ps.setInt(1, idOperacao);
			ps.setInt(2, idJob);
			
			ps.execute();
			
		} finally {
			closeConnection();
		}
	}
	
	/**
	 * Altera o controle da job se existir
	 * @param idOperacao
	 * @param idJob
	 * @throws Exception
	 */
	public void updateControleJob(String idsJob, String sarID) throws Exception {
		
		StringBuilder sq = new StringBuilder();
		sq.append( " update tb_execucao_job set data_controle_sar = getDate() ")
		.append(" where sar_id = ? and ( "+idsJob+" ) ");
		
		try {
			PreparedStatement ps = getPreparedStatement(sq.toString());
			ps.setString(1, sarID);
			ps.execute();
			
		} finally {
			closeConnection();
		}
	}
	
	public String getSchemaDbReport(Integer idTenant) throws Exception {
		try {
			PreparedStatement stmt = getPreparedStatement(
			        "select nome_db_report from tb_tenant with(nolock) where id_tenant = ?", 1);
			stmt.setInt(1, idTenant);
			ResultSet rs = stmt.executeQuery();
			
			if (rs != null && rs.next()) {
				return rs.getString(1);
			}
			
			return null;
			
		} finally {
			closeConnection();
		}
	}
	
	public void salvaNotificacaoAdmin(List<NotificacaoAdminTO> source) throws Exception {
		StringBuilder sq = new StringBuilder();
		sq.append("INSERT INTO [dbo].[tb_notificacao_admin] (");
		sq.append("	[chave_notificacao]");
		sq.append("	,[usuario]");
		sq.append("	,[flag_processado]");
		sq.append("	,[data_criacao]");
		sq.append("	,[notificacao] )");
		sq.append(" VALUES (?,?,?,?,?)");

		Connection connection = null;
		try {
			connection = getConnection();
			connection.setAutoCommit(false);
			
			PreparedStatement ps = connection.prepareStatement(sq.toString());
			ps.setFetchSize(source.size());
			
			int count = 0;
			for (NotificacaoAdminTO notificacao : source) {
				ps.setString(1, notificacao.getChaveNotificacao());
				ps.setInt(2, notificacao.getIdUsuario());
				ps.setInt(3, 0);
				ps.setTimestamp(4, new Timestamp(notificacao.getDataCriacao().getTime()));
				ps.setString(5, notificacao.getNotificacao());
				
				ps.addBatch();

				if (++count % BATCH_SIZE == 0) {
					ps.executeBatch();
					connection.commit();
				}
			}
			
			ps.executeBatch(); // insert remaining records
			connection.commit();
			
			logger.info("Notificações salvas com sucesso");
			
		} catch (Exception e) {
			if (connection != null && !connection.isClosed()) {
				connection.rollback();
			}
			throw e;

		} finally {
			closeConnection();
		}
	}

	/**
	 * @param idOperacao
	 * @return
	 * @throws Exception 
	 */
	public List<Integer> buscaObservadorPorOperacao(Integer idOperacao) throws Exception {
		try {
			PreparedStatement stmt = getPreparedStatement("select id_usuario from tb_operacao_usuario with(nolock) where flag_recebe_notificacao = 1 and id_operacao = ? ", 1);
			stmt.setInt(1, idOperacao);
			ResultSet rs = stmt.executeQuery();

			List<Integer> ret = new ArrayList<Integer>();
			if (rs != null) {
				while (rs.next()) {
					ret.add(rs.getInt(1));
				}
			}

			return ret;

		} finally {
			closeConnection();
		}
	}
}
