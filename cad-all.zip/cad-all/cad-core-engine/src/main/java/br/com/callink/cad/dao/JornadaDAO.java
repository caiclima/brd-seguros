package br.com.callink.cad.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import br.com.callink.cad.to.JornadaTO;

public class JornadaDAO extends GenericDAO {

	public JornadaTO buscarPorId(Integer id) throws Exception {
		try {
			StringBuilder sql = new StringBuilder();
			sql.append(SELECT);
			sql.append(JornadaTO.getSqlCamposJornada());
			sql.append(FROM);
			sql.append(JornadaTO.getSqlFromJornada());
			sql.append(" WHERE id_jornada = ? ");

			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				return JornadaTO.getJornadaByResultSet(rs);
			}

			return null;
		} finally {
			super.closeConnection();
		}
	}

	public List<JornadaTO> findAtivos() throws Exception {
		try {
			List<JornadaTO> ret = new ArrayList<>();

			StringBuilder sql = new StringBuilder();
			sql.append(SELECT);
			sql.append(JornadaTO.getSqlCamposJornada());
			sql.append(FROM);
			sql.append(JornadaTO.getSqlFromJornada());
			sql.append(" WHERE FLAG_ATIVO = 1 ");

			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				ret.add(JornadaTO.getJornadaByResultSet(rs));
			}

			return ret;
		} finally {
			super.closeConnection();
		}
	}
	
	public List<JornadaTO> findPorOperacao(Integer idOperacao) throws Exception {
		try {
			List<JornadaTO> ret = new ArrayList<>();

			StringBuilder sql = new StringBuilder();
			sql.append(SELECT);
			sql.append(JornadaTO.getSqlCamposJornada());
			sql.append(FROM);
			sql.append(JornadaTO.getSqlFromJornada())
			.append(" where id_operacao = ? ");

			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			
			ps.setInt(1, idOperacao);
			
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				ret.add(JornadaTO.getJornadaByResultSet(rs));
			}

			return ret;
		} finally {
			super.closeConnection();
		}
	}
	
}
