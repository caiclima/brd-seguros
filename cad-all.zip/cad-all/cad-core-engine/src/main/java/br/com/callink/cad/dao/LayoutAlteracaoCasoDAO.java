package br.com.callink.cad.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import br.com.callink.cad.to.LayoutAlteracaoCasoTO;

public class LayoutAlteracaoCasoDAO extends GenericDAO {

	
	public LayoutAlteracaoCasoTO buscaLayoutAlteracao(Integer idLayout) throws Exception {
		
		LayoutAlteracaoCasoTO layout = new LayoutAlteracaoCasoTO();
		
		StringBuilder sq= new StringBuilder();
		sq.append("select * from tb_layout_alteracao where id_layout_alteracao = ?");
		
		PreparedStatement p;
		try {
			p = getPreparedStatement(sq.toString());
			p.setInt(1, idLayout);
			
			ResultSet resultSet = p.executeQuery();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					layout = LayoutAlteracaoCasoTO.getCamposLayoutTOByResultSet(resultSet);
				}
				return layout;
			}

		} finally {
			super.closeConnection();
		}
		
		return null;
	}
	
	
	
}
