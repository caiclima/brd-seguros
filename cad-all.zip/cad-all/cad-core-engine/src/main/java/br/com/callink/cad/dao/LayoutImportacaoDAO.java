package br.com.callink.cad.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.com.callink.cad.to.LayoutImportacaoTO;

public class LayoutImportacaoDAO extends GenericDAO {

	public LayoutImportacaoTO buscaLayoutImportacaoEmailPorCaixaEmail(Integer idCaixaEmail) throws Exception {
		try {
			StringBuilder sql = new StringBuilder();
			sql.append(SELECT);
			sql.append("layout.id_layout as idLayout ");
			sql.append(",layout.IGNORAR_EMAIL as emailIgnorado ");
			sql.append(",layout.EMAIL_UNICO as emailUnico ");
			sql.append(FROM);
			sql.append("tb_layout_importacao layout with(nolock), ");
			sql.append("tb_configuracao_caixa_email caixa with(nolock) ");
			sql.append(WHERE);
			sql.append("layout.id_layout = caixa.id_layout_importacao ");
			sql.append("AND caixa.id_configuracao_caixa_email = ? ");
			sql.append("AND layout.flag_ativo = 1 ");
			sql.append("AND caixa.flag_ativo = 1 ");

			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ps.setInt(1, idCaixaEmail);
			ResultSet resultSet = ps.executeQuery();

			if (resultSet != null) {
				while (resultSet.next()) {
					LayoutImportacaoTO layout = LayoutImportacaoTO.getLayoutImportacaoTOByResultSet(resultSet);
					return layout;
				}
			}
			return null;
		} finally {
			super.closeConnection();
		}
	}
	
	public List<LayoutImportacaoTO> buscaLayoutImportacaoByJob(Integer idJob) throws Exception {
		try {
			StringBuilder sql = new StringBuilder();
			sql.append(SELECT);
			sql.append(LayoutImportacaoTO.getSqlColuns());
			sql.append(FROM);
			sql.append(LayoutImportacaoTO.getSqlFrom());
			sql.append(WHERE);
			sql.append(" layout.id_job = ? ");

			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ps.setInt(1, idJob);
			ResultSet resultSet = ps.executeQuery();

			List<LayoutImportacaoTO> ret = new ArrayList<LayoutImportacaoTO>();
			if (resultSet != null) {
				while (resultSet.next()) {
					LayoutImportacaoTO layout = LayoutImportacaoTO.getLayoutImportacaoTOByResultSet(resultSet);
					ret.add(layout);
				}
			}
			return ret;
		} finally {
			super.closeConnection();
		}
	}
}
