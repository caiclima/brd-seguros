package br.com.callink.cad.dao;

import java.sql.PreparedStatement;
import java.sql.Timestamp;

import br.com.callink.cad.to.LogTO;

public class LogDAO extends GenericDAO {
	
	public Integer insereLogJob(LogTO logTO) throws Exception {
		try {
			int ret = 0;
	
			StringBuilder sql = new StringBuilder();
			
			sql.append(" insert into tb_log (id_caso, data_log, descricao, id_status ) values ");
			sql.append(" (?, ?, ?, ? )");
			
			PreparedStatement p = getPreparedStatement(sql.toString());
			
			p.setInt(1, logTO.getIdCaso());
			p.setTimestamp(2 , new Timestamp(logTO.getDataLog().getTime()));
			p.setString(3, logTO.getDescricao());
			p.setInt(4, logTO.getIdStatus());
			
			ret = p.executeUpdate();
			
			return ret;
		} finally {
			super.closeConnection();
		}
	}
}
