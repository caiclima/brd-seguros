package br.com.callink.cad.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import br.com.callink.cad.to.LogJobTO;
import br.com.callink.cad.util.StringUtils;

public class LogJobDAO extends GenericDAO {

	public List<LogJobTO> findLogsOperacao(Integer idOperacao) throws Exception {
		try {
			StringBuilder sql = new StringBuilder();
			sql.append("select ");
			sql.append(LogJobTO.getSqlColuns());
			sql.append(LogJobTO.getSqlFrom());
			sql.append(" where id_operacao = ?");

			PreparedStatement ps = getPreparedStatement(sql.toString());
			ps.setInt(1, idOperacao);
			ResultSet rs = ps.executeQuery();

			List<LogJobTO> list = new ArrayList<>();
			while (rs.next()) {
				list.add(LogJobTO.getJobTOByResultSet(rs));
			}

			return list;
		} finally {
			super.closeConnection();
		}
	}

	public Integer insereLogJob(LogJobTO logTO) throws Exception {

		int ret = 0;

		StringBuilder sql = new StringBuilder().append(" insert into tb_log_job (nome_job, descricao, id_operacao, stack_trace, data_inicio, data_fim, flag_sucesso, clazz ) values ").append(" (?, ?, ?, ?, ?, ?, ? ,? )");

		try {

			PreparedStatement ps = getPreparedStatement(sql.toString());

			ps.setString(1, StringUtils.isEmpty(logTO.getNomeJob()) ? "" : logTO.getNomeJob());
			ps.setString(2, StringUtils.isEmpty(logTO.getDescricao()) ? "" : logTO.getDescricao());
			ps.setInt(3, logTO.getIdOperacao() != null ? logTO.getIdOperacao() : Types.NULL);
			ps.setString(4, StringUtils.isEmpty(logTO.getStackTrace()) ? "" : logTO.getStackTrace());
			ps.setTimestamp(5, logTO.getDataInicio() == null ? null : new java.sql.Timestamp(logTO.getDataInicio().getTime()));
			ps.setTimestamp(6, logTO.getDataFim() == null ? null : new java.sql.Timestamp(logTO.getDataFim().getTime()));
			ps.setInt(7, logTO.getFlagSucesso() == true ? 1 : 0);
			ps.setString(8, StringUtils.isEmpty(logTO.getClazz()) ? "" : logTO.getClazz());

			ret = ps.executeUpdate();

		} finally {
			super.closeConnection();
		}

		return ret;
	}

}
