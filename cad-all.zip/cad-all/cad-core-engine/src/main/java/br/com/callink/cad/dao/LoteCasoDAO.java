package br.com.callink.cad.dao;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.logging.Logger;
import br.com.callink.cad.to.LoteCasoTO;

public class LoteCasoDAO extends GenericDAO {
	
	private Logger logger = Logger.getLogger(LoteCasoDAO.class.getName());

	public LoteCasoTO buscaLoteCasoPendente(Integer idOperacao) throws Exception {
		try {
			StringBuilder sql = new StringBuilder()
					.append(SELECT)
					.append(" TOP 1 ")
					.append(LoteCasoTO.getSqlCamposLoteCaso())
					.append(FROM)
					.append(LoteCasoTO.getSqlFromLoteCaso())
					.append(WHERE)
					.append(" LoteCaso.flag_ativo = 1 ")
					.append(" AND LoteCaso.id_operacao = ? ")
					.append(" AND LoteCaso.tipo_execucao = 'AGENDADO' ")
					.append(" AND LoteCaso.status_execucao = 'PENDENTE' ")
					.append(" AND LoteCaso.horario_agendamento <= getdate() ")
					.append(" ORDER BY LoteCaso.horario_agendamento asc ");

			PreparedStatement stmt = super.getPreparedStatement(sql.toString(), 1);
			stmt.setInt(1, idOperacao);
			ResultSet rs = stmt.executeQuery();
			if (rs != null) {
				while (rs.next()) {
					return new LoteCasoTO((Integer) rs.getObject("LoteCaso.ID_LOTE_CASO"));
				}
			}

			return null;
			
		} finally {
			super.closeConnection();
		}
	}
	
	public void execProcedureImportacao(Integer idLoteCaso) throws Exception {
		CallableStatement cs = null;
		try {
			
	    	StringBuilder sql = new StringBuilder();
			sql.append(" exec ").append("PROC_IMPORT_CASO").append(" @vIdLoteCaso = ").append(idLoteCaso);

			cs = super.getConnection().prepareCall(sql.toString());
			cs.execute();
			
		} finally {
			if (cs != null) {
				cs.close();
			}
			super.closeConnection();
		}
	}
	
	public LoteCasoTO savarLoteCaso(LoteCasoTO loteCaso) throws Exception {
		try {
			StringBuilder sql = new StringBuilder();
			sql.append(INSERT);
			sql.append(" tb_lote_caso (id_layout, id_operacao, tipo_processo, tipo_execucao, status_execucao, flag_ativo, horario_agendamento, nome_arquivo)  ");
			sql.append(" values ");
			sql.append(" (?,?,?,?,?,?,?,?) ");

			PreparedStatement ps = getPreparedStatementId(sql.toString());
			ps.setInt(1, loteCaso.getIdLayout());
			ps.setInt(2, loteCaso.getIdOperacao());
			ps.setString(3, loteCaso.getTipoProcesso());
			ps.setString(4, loteCaso.getTipoExecucao());
			ps.setString(5, loteCaso.getStatusExecucao());
			ps.setBoolean(6, loteCaso.getFlagAtivo());
			ps.setTimestamp(7, new Timestamp(loteCaso.getHorarioAgendamento().getTime()));
			ps.setString(8, loteCaso.getNomeArquivo());
			ps.executeUpdate();

			ResultSet generatedKeys = ps.getGeneratedKeys();
			if (generatedKeys.next()) {
				loteCaso.setIdLoteCaso((int) generatedKeys.getLong(1));
			}

			logger.info("insertLoteCaso. ");
			return loteCaso;
			

		} finally {
			super.closeConnection();
		}
	}

	public void atualizaStatusExecucaoLoteCaso(Integer idLoteCaso, String statusExecucaoPendente) throws Exception {
		try {
			StringBuilder sql = new StringBuilder();
			sql.append(UPDATE);
			sql.append(" tb_lote_caso ");
			sql.append(" set status_execucao = ? ");
			sql.append(WHERE);
			sql.append(" id_lote_caso = ? ");

			PreparedStatement ps = getPreparedStatement(sql.toString());
			ps.setString(1, statusExecucaoPendente);
			ps.setInt(2, idLoteCaso);
			ps.executeUpdate();
			
			logger.info("atualizaStatusExecucaoLoteCaso. ");

		} finally {
			super.closeConnection();
		}
	}
	
	public void atualizaLoteStatusQuantidade(Integer idLoteCaso, Integer qtdArquivo, Integer qtdImportado, Integer qtdReaberto,
			Integer qtdRejeitado, String motivo, String status) throws Exception {
		try {
			StringBuilder sql = new StringBuilder();
			sql.append(UPDATE);
			sql.append(" tb_lote_caso ");
			sql.append(" set status_execucao = ? ");
			sql.append("   , qtd_arquivo = ? ");
			sql.append("   , qtd_importado = ? ");
			sql.append("   , qtd_reaberto = ? ");
			sql.append("   , qtd_rejeitado = ? ");
			sql.append("   , motivo = ? ");
			sql.append(WHERE);
			sql.append(" id_lote_caso = ? ");

			PreparedStatement ps = getPreparedStatement(sql.toString());
			ps.setString(1, status);
			if (qtdArquivo != null) {
				ps.setInt(2, qtdArquivo);
			} else {
				ps.setNull(2, Types.NULL);
			}
			if (qtdImportado != null) {
				ps.setInt(3, qtdImportado);
			} else {
				ps.setNull(3, Types.NULL);
			}
			if (qtdReaberto != null) {
				ps.setInt(4, qtdReaberto);
			} else {
				ps.setNull(4, Types.NULL);
			}
			if (qtdRejeitado != null) {
				ps.setInt(5, qtdRejeitado);
			} else {
				ps.setNull(5, Types.NULL);
			}
			if (motivo != null && !motivo.isEmpty()) {
				ps.setString(6, motivo);
			} else {
				ps.setNull(6, Types.NULL);
			}
			ps.setInt(7, idLoteCaso);
			ps.executeUpdate();
			
			logger.info("atualizaStatusExecucaoLoteCaso. ");

		} finally {
			super.closeConnection();
		}
	}
}
