package br.com.callink.cad.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import br.com.callink.cad.to.CasoTO;
import br.com.callink.cad.to.OperacaoTO;
import br.com.callink.cad.util.HintNumberRows;

public class NotificaCasoNaoClassificadoDAO extends GenericDAO {

	private Logger logger = Logger.getLogger(NotificaCasoNaoClassificadoDAO.class.getName());

	public List<CasoTO> buscaCasosSemFila(Integer idOperacao) throws Exception {
		try {
			StringBuilder sql = new StringBuilder()
				.append(SELECT)
				.append(" caso.id_caso as 'caso.id_caso', " + " caso.id_externo as 'caso.id_externo', ")
				.append(" caso.id_operacao as 'caso.id_operacao', ")
				.append(" caso.data_abertura as 'caso.data_abertura', ")
				.append(" log.data_log as 'log.data_log' ")
				.append(FROM)
				.append(" tb_caso caso with(nolock) ")
				.append(LEFT_JOIN)
				.append(" tb_log log with(nolock) ")
				.append(" ON caso.id_caso = log.id_caso ")
				.append(" AND log.id_log = (SELECT TOP 1 tb_log.id_log ")
				.append( " FROM tb_log with(nolock) ")
				.append(" WHERE tb_log.id_caso = caso.id_caso ")
				.append(" ORDER BY tb_log.data_log DESC) ")
				.append(WHERE)
				.append(" caso.id_configuracao_fila IS NULL ")
				.append(" AND caso.id_operacao = ? ");

			PreparedStatement stmt = super.getPreparedStatement(sql.toString(), HintNumberRows.ROWS_CASO.getRows());
			stmt.setInt(1, idOperacao);

			ResultSet rs = stmt.executeQuery();
			List<CasoTO> toReturn = new ArrayList<CasoTO>();

			if (rs != null) {
				while (rs.next()) {
					CasoTO to = new CasoTO();
					to.setIdCaso((Integer) rs.getObject("caso.id_caso"));
					to.setIdExterno(rs.getString("caso.id_externo"));
					to.setIdOperacao((Integer) rs.getObject("caso.id_operacao"));
					to.setDataAbertura(rs.getTimestamp("caso.data_abertura"));
					to.setDataUltimoLog(rs.getTimestamp("log.data_log"));

					toReturn.add(to);
				}
			}

			logger.info("buscaCasosSemFila. ");
			return toReturn;
			
		} finally {
			super.closeConnection();
		}
	}

	public List<OperacaoTO> buscaOperacoes() throws Exception {
		try {
			StringBuilder sql = new StringBuilder()
				.append(SELECT)
				.append(" op.id_operacao as 'op.id_operacao',")
				.append(" op.nome as 'op.nome',")
				.append(" op.email_admin as 'op.email_admin' ")
				.append(FROM)
				.append(" tb_operacao op with(nolock) ")
				.append(WHERE)
				.append(" op.flag_ativo = 1 ");

			PreparedStatement stmt = super.getPreparedStatement(sql.toString());
			ResultSet rs = stmt.executeQuery();
			
			List<OperacaoTO> toReturn = new ArrayList<OperacaoTO>();

			if (rs != null) {
				while (rs.next()) {
					OperacaoTO to = new OperacaoTO();
					to.setIdOperacao((Integer) rs.getObject("op.id_operacao"));
					to.setEmailsAdm(rs.getString("op.email_admin"));
					to.setNomeOperacao(rs.getString("op.nome"));

					toReturn.add(to);
				}
			}

			logger.info("buscaCasosSemFila. ");
			return toReturn;
			
		} finally {
			super.closeConnection();
		}
	}
	
	public OperacaoTO buscaDadosOperacao(Integer idOperacao) throws Exception {
		try {
			OperacaoTO toReturn = null;
			
			StringBuilder sql = new StringBuilder()
				.append(SELECT)
				.append(" op.id_operacao as 'op.id_operacao',")
				.append(" op.nome as 'op.nome',")
				.append(" op.email_admin as 'op.email_admin' ")
				.append(FROM)
				.append(" tb_operacao op with(nolock) ")
				.append(WHERE)
				.append(" op.flag_ativo = 1 ")
				.append(" and op.id_operacao = ? ");

			PreparedStatement stmt = super.getPreparedStatement(sql.toString());
			stmt.setInt(1, idOperacao);
			ResultSet rs = stmt.executeQuery();

			if (rs != null && rs.next()) {
				toReturn = new OperacaoTO();
				toReturn.setIdOperacao((Integer) rs.getObject("op.id_operacao"));
				toReturn.setEmailsAdm(rs.getString("op.email_admin"));
				toReturn.setNomeOperacao(rs.getString("op.nome"));
			}

			logger.info("buscaDadosOperacao. ");
			return toReturn;
			
		} finally {
			super.closeConnection();
		}
	}
}