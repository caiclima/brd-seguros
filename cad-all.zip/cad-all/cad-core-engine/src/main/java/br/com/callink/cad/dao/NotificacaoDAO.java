package br.com.callink.cad.dao;

import java.sql.PreparedStatement;

public class NotificacaoDAO extends GenericDAO {

	public void insereNotificacaoUsuario(String chave, Integer usuario) throws Exception {
		try {
			StringBuilder sql = 
					new StringBuilder();
			sql.append("insert into tb_notificacao (chave_notificacao, usuario, flag_processado, data_criacao, notificacao) ").
					append(" values (? , ? , 0 , getDate(), 'Caso enviado para o atendente.') ");
			
			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ps.setString(1, chave);
			ps.setInt(2, usuario);
			
			ps.executeUpdate();
		} finally {
			super.closeConnection();
		}
	}
}
