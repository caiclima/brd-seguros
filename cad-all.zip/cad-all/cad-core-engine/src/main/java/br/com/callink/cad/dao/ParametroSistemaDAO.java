package br.com.callink.cad.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.MessageFormat;

public class ParametroSistemaDAO extends GenericDAO {

	public String findValorParametroSistema(String mnemonico) throws Exception {
		try {
			PreparedStatement ps =
					super.getPreparedStatement("select valor as valorParametro from tb_parametro_sistema with(nolock) where nome = ? ");
			ps.setString(1, mnemonico);
			ResultSet rs = ps.executeQuery();
			
			if (rs.next()) {
				return rs.getString("valorParametro");
			}

			throw new Exception(MessageFormat.format("Parametro {0} não encontrado", mnemonico));
		} finally {
			super.closeConnection();
		}
	}

	public String findValorParametroSistemaOperacao(String mnemonico, Integer idOperacao) throws Exception {
		try {
			StringBuilder sql = new StringBuilder();
			sql.append("select valor as valorParametro ")
				.append("from tb_parametro_sistema_operacao with(nolock) ")
				.append("where nome = ? ")
				.append("and id_operacao = ? ");
			
			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ps.setString(1, mnemonico);
			ps.setInt(2, idOperacao);
			ResultSet rs = ps.executeQuery();
			
			if (rs.next()) {
				return rs.getString("valorParametro");
			}

			throw new Exception(MessageFormat.format("Parametro de sistema {0} nao configurado para operacao {1} !", mnemonico, idOperacao));
		
		} finally {
			super.closeConnection();
		}
	}
	
	public void atualizaValorParametroSistemaOperacao(String mnemonico, Integer idOperacao, String valor) throws Exception {
		try {
			StringBuilder sql = new StringBuilder();
			sql.append("update tb_parametro_sistema_operacao ")
				.append("set valor = ?, data_alteracao = getDate() ")
				.append("where nome = ? ")
				.append("and id_operacao = ? ");
			
			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ps.setString(1, valor);
			ps.setString(2, mnemonico);
			ps.setInt(3, idOperacao);
			final int rowCount = ps.executeUpdate();

			if (rowCount == 0) {
				throw new Exception(MessageFormat.format("Parâmetro {0} não configurado para a operação {1}", mnemonico, idOperacao.toString()));
			}
			
		} finally {
			super.closeConnection();
		}
	}
}