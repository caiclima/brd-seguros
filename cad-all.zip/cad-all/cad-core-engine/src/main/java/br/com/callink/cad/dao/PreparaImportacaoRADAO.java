package br.com.callink.cad.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.MessageFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import br.com.callink.cad.to.ControleAcessoReclameAquiTO;
import br.com.callink.cad.to.ParceiroReclameAquiTO;
import br.com.callink.cad.util.CollectionUtils;
import br.com.callink.cad.util.StringUtils;
import br.com.callink.ra.to.ComentarioTO;
import br.com.callink.ra.to.ConsideracaoConsumidorTO;
import br.com.callink.ra.to.ConsideracaoEmpresaTO;
import br.com.callink.ra.to.ReclamacaoTO;
import br.com.callink.ra.to.ReplicaTO;
import br.com.callink.ra.to.RespostaTO;

/**
 * @author swb_samuel
 *
 */
public class PreparaImportacaoRADAO extends GenericDAO {

	private final int BATCH_SIZE = 1000;

	public ParceiroReclameAquiTO buscaParceiroPorLayout(Integer idLayout) throws Exception {
		try {
			StringBuilder sql = new StringBuilder();
			sql.append(SELECT);
			sql.append("parceiro.id_parceiro as idParceiro ");
			sql.append(",parceiro.id_empresa as idEmpresa ");
			sql.append(",parceiro.usuario as usuario ");
			sql.append(",parceiro.senha as senha ");
			sql.append(",parceiro.target_endpoint as targetEndpoint ");
			sql.append(FROM);
			sql.append("tb_parceiro_reclame_aqui parceiro with(nolock), ");
			sql.append("tb_layout_importacao layout with(nolock) ");
			sql.append(WHERE);
			sql.append("parceiro.id_parceiro = layout.id_parceiro ");
			sql.append("AND parceiro.flag_ativo = 1 ");
			sql.append("AND layout.flag_ativo = 1 ");
			sql.append("AND layout.id_layout = ? ");

			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ps.setInt(1, idLayout);
			ResultSet resultSet = ps.executeQuery();

			if (resultSet != null) {
				while (resultSet.next()) {
					ParceiroReclameAquiTO parceiro = ParceiroReclameAquiTO.getParceiroReclameAquiTOByResultSet(resultSet);
					return parceiro;
				}
			}
			return null;

		} finally {
			super.closeConnection();
		}
	}

	public ControleAcessoReclameAquiTO buscaControleAcesso(int idParceiro) throws Exception {
		try {
			StringBuilder sql = new StringBuilder();
			sql.append(SELECT);
			sql.append("ctrl.id_controle_acesso as idControleAcesso ");
			sql.append(",ctrl.id_parceiro as idParceiro ");
			sql.append(",ctrl.ultima_chave_acesso as ultimaChaveAcesso ");
			sql.append(",ctrl.data_autenticacao as dataAutenticacao ");
			sql.append(",ctrl.id_ultima_reclamacao_importada as idUltimaReclamacaoImportada ");
			sql.append(",ctrl.id_ultima_replica_importada as idUltimaReplicaImportada ");
			sql.append(FROM);
			sql.append("tb_controle_acesso_reclame_aqui ctrl with(nolock) ");
			sql.append(WHERE);
			sql.append("ctrl.id_parceiro = ? ");

			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ps.setInt(1, idParceiro);
			ResultSet resultSet = ps.executeQuery();

			if (resultSet != null) {
				while (resultSet.next()) {
					ControleAcessoReclameAquiTO ctrl = ControleAcessoReclameAquiTO.getControleAcessoReclameAquiTOByResultSet(resultSet);
					return ctrl;
				}
			}
			return null;

		} finally {
			super.closeConnection();
		}
	}

	public ControleAcessoReclameAquiTO salvaControleAcesso(int idParceiro, String token, Date data) throws Exception {
		try {
			ControleAcessoReclameAquiTO ctrl = new ControleAcessoReclameAquiTO();
			ctrl.setIdParceiro(idParceiro);
			ctrl.setUltimaChaveAcesso(token);
			ctrl.setDataUltimaAutenticacao(data);

			StringBuilder sql = new StringBuilder();
			sql.append(INSERT);
			sql.append(" tb_controle_acesso_reclame_aqui (id_parceiro, ultima_chave_acesso, data_autenticacao, id_ultima_reclamacao_importada) ");
			sql.append(" values (?,?,?,?) ");

			PreparedStatement ps = getPreparedStatementId(sql.toString());
			ps.setInt(1, ctrl.getIdParceiro());
			ps.setString(2, ctrl.getUltimaChaveAcesso());
			ps.setTimestamp(3, new Timestamp(ctrl.getDataUltimaAutenticacao().getTime()));
			ps.setNull(4, Types.NULL);

			ps.executeUpdate();

			ResultSet generatedKeys = ps.getGeneratedKeys();
			if (generatedKeys.next()) {
				ctrl.setIdControleAcesso((int) generatedKeys.getLong(1));
			}

			return ctrl;

		} finally {
			super.closeConnection();
		}
	}

	public ControleAcessoReclameAquiTO atualizaControleAcesso(int idControleAcesso, int idParceiro, int idUltimaRecImportada, String chaveAcesso)
			throws Exception {
		try {
			ControleAcessoReclameAquiTO ctrl = new ControleAcessoReclameAquiTO();
			ctrl.setIdControleAcesso(idControleAcesso);
			ctrl.setIdParceiro(idParceiro);
			ctrl.setUltimaChaveAcesso(chaveAcesso);
			ctrl.setDataUltimaAutenticacao(getDataBanco());
			ctrl.setIdUltimaRecImportada(idUltimaRecImportada);

			StringBuilder sql = new StringBuilder();
			sql.append(UPDATE);
			sql.append(" tb_controle_acesso_reclame_aqui ");
			sql.append(" set ultima_chave_acesso = ?, data_autenticacao = ? ");
			sql.append(" where id_controle_acesso = ? ");

			PreparedStatement ps = getPreparedStatement(sql.toString());
			ps.setString(1, ctrl.getUltimaChaveAcesso());
			ps.setTimestamp(2, new Timestamp(ctrl.getDataUltimaAutenticacao().getTime()));
			ps.setInt(3, ctrl.getIdControleAcesso());
			ps.executeUpdate();

			return ctrl;

		} finally {
			super.closeConnection();
		}
	}

	public void atualizaControleAcesso(final int idControleAcesso, final int idLayout, String columnCaso) throws Exception {
		try {
			final String DESCRICAO_LOG_REPLICA = "Réplica%";
			final String STATUS_EXECUCAO_IMPORTACAO = "FINALIZADO";

			StringBuilder sql = new StringBuilder();
			sql.append("UPDATE tb_controle_acesso_reclame_aqui ");
			sql.append("SET id_ultima_replica_importada = ( ");
			sql.append("		SELECT TOP 1 CONVERT(INT, log.detalhe) ");
			sql.append("		FROM tb_log log with(nolock) ");
			sql.append("		INNER JOIN tb_caso caso with(nolock) ON log.id_caso = caso.id_caso ");
			sql.append("		INNER JOIN tb_lote_caso lote with(nolock) ON caso.id_lote_caso = lote.id_lote_caso ");
			sql.append("		WHERE log.descricao LIKE ? ");
			sql.append("		  AND lote.id_layout = ? ");
			sql.append("		ORDER BY CONVERT(INT, log.detalhe) DESC ");
			sql.append("	 ) ");
			sql.append(", id_ultima_reclamacao_importada = ( ");
			sql.append("		SELECT TOP 1 CONVERT(INT, ").append(columnCaso).append(")");
			sql.append("		FROM tb_caso caso with(nolock) ");
			sql.append("		INNER JOIN tb_lote_caso lote with(nolock) ON caso.id_lote_caso = lote.id_lote_caso ");
			sql.append("		WHERE lote.status_execucao = ? ");
			sql.append("		  AND lote.id_layout = ?	");
			sql.append("		ORDER BY caso.id_caso DESC ");
			sql.append("	) ");
			sql.append(" where id_controle_acesso = ? ");

			PreparedStatement ps = getPreparedStatement(sql.toString());

			ps.setString(1, DESCRICAO_LOG_REPLICA);
			ps.setInt(2, idLayout);
			ps.setString(3, STATUS_EXECUCAO_IMPORTACAO);
			ps.setInt(4, idLayout);
			ps.setInt(5, idControleAcesso);
			
			ps.executeUpdate();

		} finally {
			super.closeConnection();
		}
	}
	
	public List<ConsideracaoConsumidorTO> retiraConsideracoesProcessadas(List<ConsideracaoConsumidorTO> consideracoes) throws Exception {
		try {
			StringBuilder sql = new StringBuilder();
			sql.append("select log.detalhe ");
			sql.append("from tb_log log with(nolock) ");
			sql.append(" where log.detalhe IN ( ");

			for (ConsideracaoConsumidorTO consideracao : consideracoes) {
				sql.append("'" + consideracao.getCodigo() + "'");

				if (consideracoes.indexOf(consideracao) == consideracoes.size() - 1) {
					sql.append(")");
				} else {
					sql.append(",");
				}
			}

			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ResultSet resultSet = ps.executeQuery();

			// retira os itens que ja foram importados para o CAD
			if (resultSet != null) {
				ConsideracaoConsumidorTO item;

				while (resultSet.next()) {
					final Iterator<ConsideracaoConsumidorTO> iterator = consideracoes.iterator();
					
					while (iterator.hasNext()) {
						item = iterator.next();
						if (item.getCodigo().equals(resultSet.getString(1))) {
							iterator.remove();
						}
					}
				}
			}

			return consideracoes;
			
		} finally {
			super.closeConnection();
		}
	}
	
	public List<ReplicaTO> retiraReplicasProcessadas(List<ReplicaTO> replicas) throws Exception {
		try {
			StringBuilder sql = new StringBuilder();
			sql.append("select log.detalhe ");
			sql.append("from tb_log log with(nolock) ");
			sql.append(" where log.detalhe IN ( ");

			for (ReplicaTO replica : replicas) {
				sql.append("'" + replica.getId().toString() + "'");

				if (replicas.indexOf(replica) == replicas.size() - 1) {
					sql.append(")");
				} else {
					sql.append(",");
				}
			}

			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ResultSet resultSet = ps.executeQuery();

			// retira os itens que ja foram importados para o CAD
			if (resultSet != null) {
				ReplicaTO item;

				while (resultSet.next()) {
					final Iterator<ReplicaTO> iterator = replicas.iterator();
					
					while (iterator.hasNext()) {
						item = iterator.next();
						if (item.getId().toString().equals(resultSet.getString(1))) {
							iterator.remove();
						}
					}
				}
			}

			return replicas;
			
		} finally {
			super.closeConnection();
		}
	}
	
	public List<ComentarioTO> retiraComentariosProcessados(List<ComentarioTO> comentarios) throws Exception{
		try {
			StringBuilder sql = new StringBuilder();
			sql.append("select log.detalhe ");
			sql.append("from tb_log log with(nolock) ");
			sql.append(" where log.detalhe IN ( ");

			for (ComentarioTO coment : comentarios) {
				sql.append("'" + coment.getId().toString() + "'");

				if (comentarios.indexOf(coment) == comentarios.size() - 1) {
					sql.append(")");
				} else {
					sql.append(",");
				}
			}

			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ResultSet resultSet = ps.executeQuery();

			// retira os itens que ja foram importados para o CAD
			if (resultSet != null) {
				ComentarioTO item;

				while (resultSet.next()) {
					final Iterator<ComentarioTO> iterator = comentarios.iterator();
					
					while (iterator.hasNext()) {
						item = iterator.next();
						if (item.getId().toString().equals(resultSet.getString(1))) {
							iterator.remove();
						}
					}
				}
			}

			return comentarios;
			
		} finally {
			super.closeConnection();
		}
	}
	
	public List<RespostaTO> retiraRespostasProcessadas(List<RespostaTO> respostas) throws Exception {
		try {
			StringBuilder sql = new StringBuilder();
			sql.append("select log.detalhe ");
			sql.append("from tb_log log with(nolock) ");
			sql.append(" where log.detalhe IN ( ");

			for (RespostaTO resp : respostas) {
				sql.append("'" + resp.getCodigo() + "'");

				if (respostas.indexOf(resp) == respostas.size() - 1) {
					sql.append(")");
				} else {
					sql.append(",");
				}
			}

			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ResultSet resultSet = ps.executeQuery();

			// retira os itens que ja foram importados para o CAD
			if (resultSet != null) {
				RespostaTO item;

				while (resultSet.next()) {
					final Iterator<RespostaTO> iterator = respostas.iterator();

					while (iterator.hasNext()) {
						item = iterator.next();
						if (item.getCodigo().equals(resultSet.getString(1))) {
							iterator.remove();
						}
					}
				}
			}

			return respostas;

		} finally {
			super.closeConnection();
		}
	}
	
	public List<ReclamacaoTO> retiraReclamacoesProcessadas(List<ReclamacaoTO> reclamacoes, String columnImport) throws Exception {
		try {
			StringBuilder sql = new StringBuilder();
			sql.append("select ");
			sql.append(columnImport);
			sql.append(" from tb_import_caso with(nolock) ");
			sql.append(" where ");
			sql.append(columnImport);
			sql.append(" IN ( ");
			
			for (ReclamacaoTO rec : reclamacoes) {
				sql.append("'" + rec.getId().toString() + "'");

				if (reclamacoes.indexOf(rec) == reclamacoes.size() - 1) {
					sql.append(")");
				} else {
					sql.append(",");
				}
			}

			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ResultSet resultSet = ps.executeQuery();

			// retira os itens que ja foram importados para o CAD
			if (resultSet != null) {
				ReclamacaoTO item;

				while (resultSet.next()) {
					final Iterator<ReclamacaoTO> iterator = reclamacoes.iterator();

					while (iterator.hasNext()) {
						item = iterator.next();
						if (item.getId().toString().equals(resultSet.getString(1))) {
							iterator.remove();
						}
					}
				}
			}

			return reclamacoes;

		} finally {
			super.closeConnection();
		}
	}
	
	public void reabrirCasos(Integer idStatus, Date dataAbertura, String columnName, List<Long> reclamacoes) throws Exception {
		try {
			if (CollectionUtils.isEmpty(reclamacoes)) {
				return;
			}
			
			retiraCasoFinalizadoBuffer(columnName, reclamacoes);
			
			StringBuilder sql = new StringBuilder();
			sql.append(UPDATE);
			sql.append("tmp ");
			sql.append(SET);
			sql.append(" tmp.data_encerramento = NULL, tmp.data_fim_sla = NULL, tmp.id_causa = NULL, tmp.id_status = ?, ");
			sql.append("tmp.flag_em_atendimento = 0, tmp.flag_finalizado = 0, tmp.flag_reaberto = 1, tmp.flag_classifica = 1, tmp.flag_reclassifica_reabertura = 1, ");
			sql.append("tmp.data_abertura = ?, tmp.data_alteracao = ?, tmp.sla_minutos = NULL, tmp.sla_total = NULL, tmp.percentual_sla = NULL ");
			sql.append(FROM);
			sql.append("( ");
			sql.append(SELECT);
			sql.append(" data_encerramento, data_fim_sla, id_causa, id_status, ");
			sql.append("flag_em_atendimento, flag_finalizado, flag_reaberto, flag_classifica, flag_reclassifica_reabertura, ");
			sql.append("data_abertura, data_alteracao, sla_minutos, sla_total, percentual_sla ");
			sql.append(FROM);
			sql.append(" tb_caso with(nolock), tb_caso_detalhe with(nolock) ");
			sql.append(WHERE);
			sql.append(" tb_caso.id_caso = tb_caso_detalhe.id_caso and ");
			sql.append(columnName).append(MessageFormat.format(" IN ( {0} ) ", StringUtils.join(reclamacoes.iterator(), ",", columnName.equalsIgnoreCase("id_externo"))));
			sql.append(" AND data_encerramento IS NOT NULL");
			sql.append(" AND data_fim_sla IS NOT NULL");
			sql.append(" AND flag_finalizado = 1");
			sql.append(") tmp");

			PreparedStatement ps = getPreparedStatement(sql.toString());
			ps.setInt(1, idStatus);
			ps.setTimestamp(2, new Timestamp(dataAbertura.getTime()));
			ps.setTimestamp(3, new Timestamp(dataAbertura.getTime()));
		
			ps.executeUpdate();

		} finally {
			super.closeConnection();
		}
	}
	
	public void retiraCasoFinalizadoBuffer(String columnName, List<Long> reclamacoes) throws SQLException, Exception  {
		try {
			StringBuilder sql = new StringBuilder()
			.append(" delete from tb_caso_fila_atendimento ")
			.append(WHERE)
			.append(" id_caso in ( select tb_caso.id_caso from tb_caso with(nolock), tb_caso_detalhe with(nolock) ") 
			.append(" WHERE tb_caso.id_caso = tb_caso_detalhe.id_caso AND ")
			.append(columnName).append(MessageFormat.format(" IN ( {0} ) ", StringUtils.join(reclamacoes.iterator(), ",", columnName.equalsIgnoreCase("id_externo"))))
			.append(" AND data_encerramento IS NOT NULL")
			.append(" AND data_fim_sla IS NOT NULL")
			.append(" AND flag_finalizado = 1 ) ");

			super.getPreparedStatement(sql.toString()).execute();
			
		} finally {
			super.closeConnection();
		}
	}

	public void finalizarCasos(Integer idStatus, Date dataEncerramento, String columnName, List<Long> reclamacoes) throws Exception {
		try {
			if (CollectionUtils.isEmpty(reclamacoes)) {
				return;
			}
			
			StringBuilder sql = new StringBuilder();
			sql.append(UPDATE);
			sql.append("tmp ");
			sql.append(SET);
			sql.append(" tmp.id_causa = (SELECT MIN(ec.id_causa) ");
			sql.append(" 	FROM tb_evento_causa ec ");
			sql.append(" 	WHERE ec.finaliza_caso = 1 ");
			sql.append(" 	AND ec.id_evento = (SELECT id_evento FROM tb_tipo_caso WHERE id_tipo_caso = tmp.id_tipo_caso) ) ");
			sql.append(", tmp.id_status = ?,  tmp.id_usuario = NULL, tmp.data_encerramento = ?, tmp.data_fim_sla = ? ");
			sql.append(", tmp.data_alteracao = ?, tmp.flag_em_atendimento = 0, tmp.flag_finalizado = 1 ");
			sql.append(FROM);
			sql.append("( ");
			sql.append(SELECT);
			sql.append(" id_causa, id_status, id_usuario, id_tipo_caso, data_encerramento, data_fim_sla, data_alteracao, flag_em_atendimento, flag_finalizado ");
			sql.append(FROM);
			sql.append(" tb_caso with(nolock), tb_caso_detalhe with(nolock) ");
			sql.append(WHERE);
			sql.append(" tb_caso.id_caso = tb_caso_detalhe.id_caso and ");
			sql.append(columnName).append(MessageFormat.format(" IN ( {0} ) ", StringUtils.join(reclamacoes.iterator(), ",", columnName.equalsIgnoreCase("id_externo"))));
			sql.append(" AND data_encerramento IS NULL");
			sql.append(" AND data_fim_sla IS NULL");
			sql.append(" AND (flag_finalizado IS NULL OR flag_finalizado = 0)");
			sql.append(") tmp");

			PreparedStatement ps = getPreparedStatement(sql.toString());
			ps.setInt(1, idStatus);
			ps.setTimestamp(2, new Timestamp(dataEncerramento.getTime()));
			ps.setTimestamp(3, new Timestamp(dataEncerramento.getTime()));
			ps.setTimestamp(4, new Timestamp(dataEncerramento.getTime()));
			
			ps.executeUpdate();

		} finally {
			super.closeConnection();
		}
	}

	public void salvarLogResposta(String columnName, List<RespostaTO> respostas) throws Exception {
		Connection connection = null;
		
		try {
			if (CollectionUtils.isEmpty(respostas)) {
				return;
			}

			final StringBuilder sql = new StringBuilder();
			sql.append(" INSERT INTO tb_log ");
			sql.append(" (id_status, id_caso, data_log, descricao, detalhe, id_configuracao_fila, id_usuario, data_abertura, id_sla_fila) ");
			sql.append(SELECT);
			sql.append(" distinct tb_caso.id_status, tb_caso.id_caso, getdate(), ?, ?, tb_caso.id_configuracao_fila, tb_caso.id_usuario, tb_caso.data_abertura, tb_caso.id_sla_fila ");
			sql.append(FROM);
			sql.append("tb_caso with(nolock), tb_caso_detalhe with(nolock) ");
			sql.append(WHERE);
			sql.append("tb_caso.id_caso = tb_caso_detalhe.id_caso and ");
			sql.append(columnName).append(" = ?");
			sql.append(" and not exists (select log.id_log from tb_log log where log.detalhe = ?) ");

			connection = getConnection();
			connection.setAutoCommit(false);
			
			PreparedStatement ps = connection.prepareStatement(sql.toString());
			ps.setFetchSize(respostas.size());

			int count = 0;

			for (RespostaTO resposta : respostas) {
				ps.setString(1, "Resposta: " + resposta.getTexto());
				ps.setString(2, resposta.getCodigo().toString());

				if (columnName.equalsIgnoreCase("id_externo")) {
					ps.setString(3, resposta.getReclamacao().toString());

				} else {
					ps.setLong(3, resposta.getReclamacao());
				}

				ps.setString(4, resposta.getCodigo().toString());
				ps.addBatch();

				if (++count % BATCH_SIZE == 0) {
					ps.executeBatch();
					connection.commit();
				}
			}

			ps.executeBatch(); // insert remaining records
			connection.commit();
			
		} catch (Exception e) {
			if (connection != null && !connection.isClosed()) {
				connection.rollback();
			}
			throw e;
			
		} finally {
			super.closeConnection();
		}
	}

	public void salvarLogComentario(String columnName, List<ComentarioTO> comentarios) throws Exception {
		Connection connection = null;
		try {
			
			if (CollectionUtils.isEmpty(comentarios)) {
				return;
			}

			final StringBuilder sql = new StringBuilder();
			sql.append(" INSERT INTO tb_log ");
			sql.append(" (id_status, id_caso, data_log, descricao, detalhe, id_configuracao_fila, id_usuario, data_abertura, id_sla_fila) ");
			sql.append(SELECT);
			sql.append(" distinct tb_caso.id_status, tb_caso.id_caso, getdate(), ?, ?, tb_caso.id_configuracao_fila, tb_caso.id_usuario, tb_caso.data_abertura, tb_caso.id_sla_fila ");
			sql.append(FROM);
			sql.append("tb_caso with(nolock), tb_caso_detalhe with(nolock) ");
			sql.append(WHERE);
			sql.append("tb_caso.id_caso = tb_caso_detalhe.id_caso and ");
			sql.append(columnName).append(" = ?");
			sql.append(" and not exists (select log.id_log from tb_log log where log.detalhe = ?) ");

			connection = getConnection();
			connection.setAutoCommit(false);
			
			PreparedStatement ps = connection.prepareStatement(sql.toString());
			ps.setFetchSize(comentarios.size());

			int count = 0;

			for (ComentarioTO comentario : comentarios) {
				ps.setString(1, "Comentário (" + comentario.getCadastro() + "): " + comentario.getTexto());
				ps.setString(2, comentario.getId().toString());

				if (columnName.equalsIgnoreCase("id_externo")) {
					ps.setString(3, comentario.getReclamacao().toString());

				} else {
					ps.setLong(3, comentario.getReclamacao());
				}

				ps.setString(4, comentario.getId().toString());
				ps.addBatch();

				if (++count % BATCH_SIZE == 0) {
					ps.executeBatch();
					connection.commit();
				}
			}

			ps.executeBatch(); // insert remaining records
			connection.commit();
			
		} catch (Exception e) {
			if (connection != null && !connection.isClosed()) {
				connection.rollback();
			}
			throw e;
			
		} finally {
			super.closeConnection();
		}
	}

	public void salvarLogReplica(String columnName, List<ReplicaTO> replicas) throws Exception {
		Connection connection = null;
		try {
			if (CollectionUtils.isEmpty(replicas)) {
				return;
			}

			final StringBuilder sql = new StringBuilder();
			sql.append(" INSERT INTO tb_log ");
			sql.append(" (id_status, id_caso, data_log, descricao, detalhe, id_configuracao_fila, id_usuario, data_abertura, id_sla_fila) ");
			sql.append(SELECT);
			sql.append(" distinct tb_caso.id_status, tb_caso.id_caso, getdate(), ?, ?, tb_caso.id_configuracao_fila, tb_caso.id_usuario, tb_caso.data_abertura, tb_caso.id_sla_fila ");
			sql.append(FROM);
			sql.append("tb_caso with(nolock), tb_caso_detalhe with(nolock) ");
			sql.append(WHERE);
			sql.append("tb_caso.id_caso = tb_caso_detalhe.id_caso and ");
			sql.append(columnName).append(" = ?");
			sql.append(" and not exists (select log.id_log from tb_log log where log.detalhe = ?) ");

			connection = getConnection();
			connection.setAutoCommit(false);
			
			PreparedStatement ps = connection.prepareStatement(sql.toString());
			ps.setFetchSize(replicas.size());

			int count = 0;

			for (ReplicaTO replicaTO : replicas) {
				ps.setString(1, "Réplica (" + replicaTO.getOrigem() + "): " + replicaTO.getTexto());
				ps.setString(2, replicaTO.getId().toString());

				if (columnName.equalsIgnoreCase("id_externo")) {
					ps.setString(3, replicaTO.getReclamacao().toString());

				} else {
					ps.setLong(3, replicaTO.getReclamacao());
				}

				ps.setString(4, replicaTO.getId().toString());
				ps.addBatch();

				if (++count % BATCH_SIZE == 0) {
					ps.executeBatch();
					connection.commit();
				}
			}

			ps.executeBatch(); // insert remaining records
			connection.commit();
			
		} catch (Exception e) {
			if (connection != null && !connection.isClosed()) {
				connection.rollback();
			}
			throw e;

		} finally {
			super.closeConnection();
		}
	}

	public void salvarLogConsideracaoEmpresa(String columnName, List<ConsideracaoEmpresaTO> consideracoes) throws Exception {
		Connection connection = null;
		try {
			if (CollectionUtils.isEmpty(consideracoes)) {
				return;
			}

			final StringBuilder sql = new StringBuilder();
			sql.append(" INSERT INTO tb_log ");
			sql.append(" (id_status, id_caso, data_log, descricao, detalhe, id_configuracao_fila, id_usuario, data_abertura, id_sla_fila) ");
			sql.append(SELECT);
			sql.append(" distinct tb_caso.id_status, tb_caso.id_caso, getdate(), ?, ?, tb_caso.id_configuracao_fila, tb_caso.id_usuario, tb_caso.data_abertura, tb_caso.id_sla_fila ");
			sql.append(FROM);
			sql.append("tb_caso with(nolock) , tb_caso_detalhe with(nolock) ");
			sql.append(WHERE);
			sql.append("tb_caso.id_caso = tb_caso_detalhe.id_caso and ");
			sql.append(columnName).append(" = ?");
			sql.append(" and not exists (select log.id_log from tb_log log where log.detalhe = ?) ");

			connection = getConnection();
			connection.setAutoCommit(false);
			
			PreparedStatement ps = connection.prepareStatement(sql.toString());
			ps.setFetchSize(consideracoes.size());

			int count = 0;

			for (ConsideracaoEmpresaTO consideracaoEmpresaTO : consideracoes) {
				ps.setString(1, "Consideração empresa: " + consideracaoEmpresaTO.getTexto());
				ps.setString(2, consideracaoEmpresaTO.getCodigo().toString());

				if (columnName.equalsIgnoreCase("id_externo")) {
					ps.setString(3, consideracaoEmpresaTO.getReclamacao().toString());

				} else {
					ps.setLong(3, consideracaoEmpresaTO.getReclamacao());
				}

				ps.setString(4, consideracaoEmpresaTO.getCodigo().toString());
				ps.addBatch();

				if (++count % BATCH_SIZE == 0) {
					ps.executeBatch();
					connection.commit();
				}
			}

			ps.executeBatch(); // insert remaining records
			connection.commit();
			
		} catch (Exception e) {
			if (connection != null && !connection.isClosed()) {
				connection.rollback();
			}
			throw e;

		} finally {
			super.closeConnection();
		}
	}

	public void salvarLogConsideracaoConsumidor(String columnName, List<ConsideracaoConsumidorTO> consideracoes) throws Exception {
		Connection connection = null;
		try {
			if (CollectionUtils.isEmpty(consideracoes)) {
				return;
			}

			StringBuilder sql = new StringBuilder();
			sql.append(" INSERT INTO tb_log ");
			sql.append(" (id_status, id_caso, data_log, descricao, detalhe, id_configuracao_fila, id_usuario, data_abertura, id_sla_fila) ");
			sql.append(SELECT);
			sql.append(" distinct tb_caso.id_status, tb_caso.id_caso, getdate(), ?, ?, tb_caso.id_configuracao_fila, tb_caso.id_usuario, tb_caso.data_abertura, tb_caso.id_sla_fila ");
			sql.append(FROM);
			sql.append("tb_caso with(nolock), tb_caso_detalhe with(nolock) ");
			sql.append(WHERE);
			sql.append("tb_caso.id_caso = tb_caso_detalhe.id_caso and ");
			sql.append(columnName).append(" = ?");
			sql.append(" and not exists (select log.id_log from tb_log log where log.detalhe = ?) ");

			connection = getConnection();
			connection.setAutoCommit(false);
			
			PreparedStatement ps = connection.prepareStatement(sql.toString());
			ps.setFetchSize(consideracoes.size());

			int count = 0;
			StringBuilder tmp = new StringBuilder();

			for (ConsideracaoConsumidorTO consideracaoConsumidorTO : consideracoes) {
				tmp.append("Consideração consumidor: ");
				tmp.append(consideracaoConsumidorTO.getTexto());
				tmp.append(" - Nota: ");
				tmp.append(consideracaoConsumidorTO.getNota());
				tmp.append(" - Status: ");
				tmp.append(consideracaoConsumidorTO.getStatus());
				tmp.append(" - Voltaria: ");
				tmp.append(consideracaoConsumidorTO.getVoltaria().getLabel());

				ps.setString(1, tmp.toString());

				/* clean string builder */
				tmp.delete(0, tmp.length());

				ps.setString(2, consideracaoConsumidorTO.getCodigo().toString());

				if (columnName.equalsIgnoreCase("id_externo")) {
					ps.setString(3, consideracaoConsumidorTO.getReclamacao().toString());

				} else {
					ps.setLong(3, consideracaoConsumidorTO.getReclamacao());
				}

				ps.setString(4, consideracaoConsumidorTO.getCodigo().toString());
				ps.addBatch();

				if (++count % BATCH_SIZE == 0) {
					ps.executeBatch();
					connection.commit();
				}
			}

			ps.executeBatch(); // insert remaining records
			connection.commit();
			
		} catch (Exception e) {
			if (connection != null && !connection.isClosed()) {
				connection.rollback();
			}
			throw e;

		} finally {
			super.closeConnection();
		}
	}
}