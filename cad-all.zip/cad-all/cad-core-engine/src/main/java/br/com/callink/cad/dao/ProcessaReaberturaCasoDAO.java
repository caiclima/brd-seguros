package br.com.callink.cad.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import br.com.callink.cad.to.CasoTO;
import br.com.callink.cad.to.EquipeTO;
import br.com.callink.cad.to.UsuarioTO;
import br.com.callink.cad.util.HintNumberRows;

public class ProcessaReaberturaCasoDAO extends GenericDAO {

	private Logger logger = Logger.getLogger(ProcessaReaberturaCasoDAO.class.getName());

	public List<CasoTO> buscaCasoReclassificaReabertura(Integer idOperacao) throws Exception {
		try {
			StringBuilder sql = new StringBuilder()
					.append(SELECT)
					.append(CasoTO.getSqlColuns())
					.append(CasoTO.getSqlFrom())
					.append(WHERE)
					.append(" Caso.FLAG_FINALIZADO = 0 ")
					.append(" AND Caso.FLAG_RECLASSIFICA_REABERTURA = 1 ")
					.append(" AND Caso.ID_OPERACAO = ? ");

			PreparedStatement stmt = super.getPreparedStatement(sql.toString(), HintNumberRows.ROWS_CASO.getRows());
			stmt.setInt(1, idOperacao);
			ResultSet resultSet = stmt.executeQuery();
			
			List<CasoTO> listRows = new ArrayList<CasoTO>();

			if (resultSet != null) {
				while (resultSet.next()) {
					CasoTO to = new CasoTO();
					to.setIdCaso((Integer) resultSet.getObject("Caso.ID_CASO"));
					to.setIdUsuario((Integer) resultSet.getObject("Caso.ID_USUARIO"));
					to.setFlagReclassificaReabertura(resultSet.getBoolean("Caso.flag_reclassifica_reabertura"));
					to.setFlagClassifica(resultSet.getBoolean("Caso.flag_classifica"));
					to.setIdConfiguracaoFila((Integer) resultSet.getObject("Caso.id_configuracao_fila"));
					listRows.add(to);
				}
			}

			logger.info("buscaCasoReclassificaReabertura. ");
			return listRows;
			
		} finally {
			super.closeConnection();
		}
	}

	public UsuarioTO findUsuarioByPk(Integer idUsuario) throws Exception {
		try {
			PreparedStatement ps = super
					.getPreparedStatement("select id_usuario as usuario, flag_ativo as ativo, id_equipe as equipe from tb_usuario with(nolock) where id_usuario = ? ");
			ps.setInt(1, idUsuario);
			ResultSet rs = ps.executeQuery();

			UsuarioTO usuario = null;
			if (rs != null && rs.next()) {
				usuario = new UsuarioTO();
				usuario.setIdUsuario((Integer) rs.getObject("usuario"));
				usuario.setFlagAtivo(rs.getBoolean("ativo"));
				usuario.setIdEquipe((Integer) rs.getObject("equipe"));
			}

			return usuario;
			
		} finally {
			super.closeConnection();
		}
	}

	public EquipeTO findEquipeByPk(Integer idEquipe) throws Exception {
		try {
			PreparedStatement ps = super
					.getPreparedStatement("select id_equipe as equipe, flag_ativo as ativo from tb_equipe with(nolock) where id_equipe = ? ");
			ps.setInt(1, idEquipe);
			ResultSet rs = ps.executeQuery();

			if (rs != null && rs.next()) {
				EquipeTO equipe = new EquipeTO();
				equipe.setIdEquipe((Integer) rs.getObject("equipe"));
				equipe.setFlagAtivo(rs.getBoolean("ativo"));
				return equipe;
			}
			return null;

		} finally {
			super.closeConnection();
		}
	}

	public void updateCaso(List<CasoTO> casoTOs) throws Exception {
		try {
			logger.info("Salvando dados do caso. ");
			
			for (CasoTO casoTO : casoTOs) {
				StringBuilder sql = new StringBuilder();
				sql.append("UPDATE tb_caso SET ")
					.append(" id_usuario = ? ")
					.append(", ")
					.append(" flag_reclassifica_reabertura = ? ")
					.append(", ")
					.append(" flag_classifica = ? ")
					.append(", ")
					.append(" id_configuracao_fila = ? ")
					.append(WHERE)
					.append(" id_caso = ? ");

				PreparedStatement ps = super.getPreparedStatement(sql.toString());

				if (casoTO.getIdUsuario() != null) {
					ps.setInt(1, casoTO.getIdUsuario());
				} else {
					ps.setNull(1, Types.NULL);
				}

				ps.setBoolean(2, casoTO.isFlagReclassificaReabertura());
				ps.setBoolean(3, casoTO.isFlagClassifica());

				if (casoTO.getIdConfiguracaoFila() != null) {
					ps.setInt(4, casoTO.getIdConfiguracaoFila());
				} else {
					ps.setNull(4, Types.NULL);
				}

				ps.setInt(5, casoTO.getIdCaso());

				ps.execute();
			}

		} finally {
			super.closeConnection();
		}

		logger.info("Operação concluída. ");
	}

	public List<Integer> buscaUsuariosLogados(Integer idOperacao) throws Exception {
		try {
			StringBuilder sql = new StringBuilder();
			sql.append("SELECT ul.id_usuario as idUser ");
			sql.append("FROM tb_usuario_logado ul with(nolock) ");
			sql.append("WHERE EXISTS ( ");
			sql.append("	SELECT 1 ");
			sql.append("	FROM tb_operacao_usuario opUsr with(nolock) ");
			sql.append("	WHERE opUsr.id_usuario = ul.id_usuario ");
			sql.append("	  AND opUsr.id_operacao = ? ");
			sql.append("	) ");
			sql.append("  AND ul.flag_logado = 1 ");

			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ps.setInt(1, idOperacao);
			ResultSet resultSet = ps.executeQuery();

			List<Integer> usuariosLogados = new ArrayList<Integer>();
			if (resultSet != null) {
				while (resultSet.next()) {
					usuariosLogados.add(resultSet.getInt("idUser"));
				}
			}

			return usuariosLogados;
			
		} finally {
			super.closeConnection();
		}
	}
}