package br.com.callink.cad.dao;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;
import java.util.List;

public class ProcessaTempoGeralDAO extends GenericDAO {

	public Date findUltimaHoraRelatorioTempoGeral(Integer idOperacao) throws Exception {
		ResultSet resultSet = null;
		PreparedStatement stmt = null;

		try {
			StringBuilder SQL = new StringBuilder()
					.append("SELECT ")
					.append("max(RelatorioTempoGeral.data) as maxDate ")
					.append("FROM ")
					.append("tb_relatorio_tempo_geral  AS RelatorioTempoGeral with(nolock) ")
					.append("where RelatorioTempoGeral.id_equipe IN (SELECT id_equipe FROM tb_associa_operacao_equipe WITH (NOLOCK) WHERE id_operacao = ?) ");

			stmt = super.getPreparedStatement(SQL.toString());
			stmt.setInt(1, idOperacao);
			stmt.execute();

			resultSet = stmt.getResultSet();

			if (resultSet.next()) {
				return resultSet.getTimestamp("maxDate");
			}
			return null;

		} finally {
			super.closeConnection();
		}
	}

	public void geraRelatorioTempoGeral(List<Date> datasIniciais, Integer idOperacao) throws Exception {
		try {
			for (Date dataInicial : datasIniciais) {
				if (dataInicial == null) {
					throw new Exception("Obrigatorio informar a data inicial");
				}

				CallableStatement cs = super.getConnection().prepareCall(" exec PROC_RELATORIO_TEMPO_GERAL @Pdata_execucao = ?, @id_operacao = ?");
				cs.setTimestamp(1, new java.sql.Timestamp(dataInicial.getTime()));
				cs.setInt(2, idOperacao);
				cs.execute();
				cs.close();
			}
		} finally {
			super.closeConnection();
		}
	}

	public Date findUltimaHoraRelatorioTempoGeralOperador(Integer idOperacao) throws Exception {
		ResultSet resultSet = null;
		PreparedStatement stmt = null;

		try {
			StringBuilder sql = new StringBuilder()
					.append("SELECT ")
					.append(" max(convert(datetime, RelatorioTempoGeralOperadorStatus.data, 103)) as maxDate ")
					.append("FROM ")
					.append(" tb_relatorio_tempo_geral_operador_status  AS RelatorioTempoGeralOperadorStatus with(nolock) ")
					.append(" WHERE RelatorioTempoGeralOperadorStatus.id_usuario IN (SELECT id_usuario FROM tb_operacao_usuario WITH (NOLOCK) WHERE id_operacao = ?)");

			stmt = getPreparedStatement(sql.toString());
			stmt.setInt(1, idOperacao);
			stmt.execute();

			resultSet = stmt.getResultSet();

			if (resultSet.next()) {
				return resultSet.getTimestamp("maxDate");
			}
			return null;

		} finally {
			super.closeConnection();
		}
	}

	public void geraRelatorioTempoGeralOperador(List<Date> datasInciais, Integer idOperacao) throws Exception {
		try {
			for (Date dataInicial : datasInciais) {
				if (dataInicial == null) {
					throw new Exception("Obrigatorio informar a data inicial");
				}

				CallableStatement cs = getConnection().prepareCall("exec PROC_RELATORIO_GERAL_OPERADOR  @Pdata_execucao = ?, @id_operacao = ? ");
				cs.setTimestamp(1, new java.sql.Timestamp(dataInicial.getTime()));
				cs.setInt(2, idOperacao);
				cs.execute();
				cs.close();
			}
		} finally {
			super.closeConnection();
		}
	}
}
