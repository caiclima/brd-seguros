package br.com.callink.cad.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import br.com.callink.cad.to.AnexoTO;
import br.com.callink.cad.to.CamposLayoutTO;
import br.com.callink.cad.to.CasoTO;
import br.com.callink.cad.to.EmailTO;
import br.com.callink.cad.to.GrupoAnexoTO;
import br.com.callink.cad.to.ImportCasoTO;
import br.com.callink.cad.to.LayoutImportacaoTO;
import br.com.callink.cad.to.LogTO;
import br.com.callink.cad.to.LoteCasoTO;
import br.com.callink.cad.util.StringUtils;

public class RecebeEmailDAO extends GenericDAO {

	private Logger logger = Logger.getLogger(RecebeEmailDAO.class.getName());

	public void updateGrupoAnexo(GrupoAnexoTO to) throws Exception {
		try {
			StringBuilder sql = new StringBuilder().append(UPDATE).append(" tb_grupo_anexo with(nolock) ").append(" NOME = ?, DESCRICAO = ? ").append(WHERE)
					.append(" ID_GRUPO_ANEXO = ? ");

			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ps.setString(1, to.getNome());
			ps.setString(2, to.getDescricao());

			if (to.getIdGrupoAnexo() == null) {
				ps.setNull(3, java.sql.Types.INTEGER);
			} else {
				ps.setInt(3, to.getIdGrupoAnexo());
			}

			ps.executeUpdate();

			logger.info("updateGrupoAnexo. ");

		} finally {
			super.closeConnection();
		}
	}

	public void saveGrupoAnexo(GrupoAnexoTO to) throws Exception {
		try {
			StringBuilder sql = new StringBuilder().append(INSERT).append(" tb_grupo_anexo ").append(" ( NOME , DESCRICAO ) VALUES ").append(" (?, ?) ");

			PreparedStatement ps = getPreparedStatementId(sql.toString());
			ps.setString(1, to.getNome());
			ps.setString(2, to.getDescricao());

			ps.executeUpdate();

			ResultSet rs = ps.getGeneratedKeys();
			if (rs != null && rs.next()) {
				to.setIdGrupoAnexo(rs.getInt(1));
			}

			logger.info("insertGrupoAnexo. ");
		} finally {
			super.closeConnection();
		}
	}

	public void saveAnexo(AnexoTO anexoTO) throws Exception {
		try {
			anexoTO.setNomeFake(br.com.callink.cad.util.StringUtils.removeCaracteresInvalidosParaNomeDeArquivoWindows(anexoTO.getNomeFake()));
			anexoTO.setNomeReal(br.com.callink.cad.util.StringUtils.removeCaracteresInvalidosParaNomeDeArquivoWindows(anexoTO.getNomeReal()));
			
			StringBuilder sql = new StringBuilder().append(INSERT).append(" tb_anexo ")
					.append(" ( NOME_REAL, NOME_FAKE, DIRETORIO, DATA_CRIACAO, ID_GRUPO_ANEXO ) VALUES ").append(" (?, ?, ?, ?, ?) ");

			PreparedStatement ps = getPreparedStatementId(sql.toString());
			ps.setString(1, anexoTO.getNomeReal());
			ps.setString(2, anexoTO.getNomeFake());
			ps.setString(3, anexoTO.getDiretorio());
			ps.setTimestamp(4, new java.sql.Timestamp(anexoTO.getDataCriacao().getTime()));

			if (anexoTO.getGrupoAnexo() == null || anexoTO.getGrupoAnexo().getIdGrupoAnexo() == null) {
				ps.setNull(5, java.sql.Types.INTEGER);
			} else {
				ps.setInt(5, anexoTO.getGrupoAnexo().getIdGrupoAnexo());
			}

			ps.executeUpdate();

			ResultSet rs = ps.getGeneratedKeys();
			if (rs != null && rs.next()) {
				anexoTO.setIdAnexo(rs.getInt(1));
			}

			logger.info("insertAnexo. ");
		} finally {
			super.closeConnection();
		}
	}

	public void saveEmail(EmailTO emailTO) throws Exception {
		try {
			StringBuilder sql = new StringBuilder().append(INSERT).append(" tb_email ")
					.append(" (assunto,remetente,destinatario,conteudo,data_envio,id_grupo_email,flag_lido,")
					.append("flag_erro_envio,flag_possui_caso,id_grupo_anexo,flag_envio,flag_envio_pendente,id_pai,")
					.append("destinatario_para_exibicao,flag_desativado,id_operacao,id_configuracao_caixa_email, destinatario_copia) ")
					.append(" VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ");

			PreparedStatement ps = getPreparedStatementId(sql.toString());
			ps.setString(1, emailTO.getAssunto());
			ps.setString(2, emailTO.getRemetente());
			ps.setString(3, emailTO.getDestinatario());
			ps.setString(4, emailTO.getConteudo());

			if (emailTO.getDataEnvio() != null) {
				ps.setTimestamp(5, new java.sql.Timestamp(emailTO.getDataEnvio().getTime()));
			} else {
				if (emailTO.getDataRecebimento() != null) {
					ps.setTimestamp(5, new java.sql.Timestamp(emailTO.getDataRecebimento().getTime()));
				}else{
					ps.setNull(5, Types.NULL);
				}
			}

			if (emailTO.getGrupoEmail() == null || emailTO.getGrupoEmail().getIdGrupoEmail() == null) {
				ps.setNull(6, java.sql.Types.INTEGER);
			} else {
				ps.setInt(6, emailTO.getGrupoEmail().getIdGrupoEmail());
			}

			ps.setBoolean(7, emailTO.getFlagLido());
			ps.setBoolean(8, emailTO.getFlagErroEnvio());
			ps.setBoolean(9, emailTO.getFlagPossuiCaso());

			if (emailTO.getGrupoAnexo() == null || emailTO.getGrupoAnexo().getIdGrupoAnexo() == null) {
				ps.setNull(10, java.sql.Types.INTEGER);
			} else {
				ps.setInt(10, emailTO.getGrupoAnexo().getIdGrupoAnexo());
			}

			ps.setBoolean(11, emailTO.getFlagEnvio());
			ps.setBoolean(12, emailTO.getFlagEnvioPendente());

			if (emailTO.getPai() == null || emailTO.getPai().getIdEmail() == null) {
				ps.setNull(13, java.sql.Types.INTEGER);
			} else {
				ps.setInt(13, emailTO.getPai().getIdEmail());
			}

			ps.setString(14, emailTO.getDestinatarioParaExibicao());
			ps.setBoolean(15, emailTO.getFlagDesativado());
			ps.setInt(16, emailTO.getIdOperacao());
			ps.setInt(17, emailTO.getIdConfiguracaoCaixaEmail());
			if (emailTO.getDestinatarioCopia() != null) {
				ps.setString(18, emailTO.getDestinatarioCopia());
			} else {
				ps.setNull(18, Types.NULL);
			}

			ps.executeUpdate();

			ResultSet rs = ps.getGeneratedKeys();
			if (rs != null && rs.next()) {
				emailTO.setIdEmail(rs.getInt(1));
			}

			logger.info("insertEmail. ");
		} finally {
			super.closeConnection();
		}
	}

	public List<CasoTO> buscaPorIdExterno(String idExterno) throws Exception {
		List<CasoTO> casoList = new ArrayList<CasoTO>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder sql = new StringBuilder().append(SELECT).append(CasoTO.getSqlColuns()).append(CasoTO.getSqlFrom());

			if (idExterno != null) {
				sql.append(WHERE).append(" Caso.id_externo = ? ");
			}

			stmt = getPreparedStatement(sql.toString());

			if (idExterno != null) {
				stmt.setString(1, idExterno);
			}

			stmt.execute();
			resultSet = stmt.getResultSet();

			if (resultSet != null) {
				while (resultSet.next()) {
					CasoTO caso = CasoTO.getCasoTOByResultSet(resultSet);
					casoList.add(caso);
				}
			}
			return casoList;

		} finally {
			super.closeConnection();
		}
	}

	public CasoTO loadCasoTO(Integer idCaso) throws Exception {
		try {
			StringBuilder sql = new StringBuilder();
			sql.append(SELECT);
			sql.append(CasoTO.getSqlColuns());
			sql.append(", ").append("\nstatus.nome AS 'Caso.status_nome' ");
			sql.append(", ").append("\ntipoCaso.nome AS 'Caso.tipo_caso_nome' ");
			sql.append(", ").append("\nconfigFila.nome AS 'Caso.configuracao_fila_nome' ");
			sql.append(", ").append("\njuncao.nome AS 'Caso.juncao_nome' ");
			sql.append(", ").append("\noutraArea.nome AS 'Caso.outra_area_nome' ");
			sql.append(", ").append("\nslaFila.descricao AS 'Caso.sla_fila_nome' ");
			sql.append(", ").append("\ncanal.nome AS 'Caso.canal_nome' ");
			sql.append(", ").append("\ncausa.nome AS 'Caso.causa_nome' ");
			
			sql.append(CasoTO.getSqlFrom());

			sql.append(" LEFT JOIN TB_CASO_DETALHE AS CasoDetalhe with(nolock) ");
			sql.append("  ON CasoDetalhe.ID_CASO = Caso.ID_CASO ");
			sql.append(" INNER JOIN tb_status status with(nolock) ");
			sql.append("  ON caso.id_status = status.id_status ");
			sql.append(" LEFT JOIN tb_tipo_caso tipoCaso with(nolock) ");
			sql.append("  ON tipoCaso.id_tipo_caso = caso.id_tipo_caso ");
			sql.append(" LEFT JOIN tb_configuracao_fila configFila with(nolock) ");
			sql.append("  ON configFila.id_configuracao_fila = caso.id_configuracao_fila ");
			sql.append(" LEFT JOIN tb_juncao juncao with(nolock) ");
			sql.append("  ON juncao.id_juncao = caso.id_juncao ");
			sql.append(" LEFT JOIN tb_outra_area outraArea with(nolock) ");
			sql.append("  ON outraArea.id_outra_area = caso.id_outra_area ");
			sql.append(" LEFT JOIN tb_sla_fila slaFila with(nolock) ");
			sql.append("  ON slaFila.id_sla_fila = caso.id_sla_fila ");
			sql.append(" LEFT JOIN tb_canal canal with(nolock) ");
			sql.append("  ON canal.id_canal = caso.id_canal ");
			sql.append(" LEFT JOIN tb_causa causa with(nolock) ");
			sql.append("  ON causa.id_causa = caso.id_causa ");
			
			sql.append(WHERE);
			sql.append("Caso.ID_CASO = ?   ");

			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ps.setInt(1, idCaso);
			ResultSet resultSet = ps.executeQuery();

			if (resultSet != null) {
				while (resultSet.next()) {
					CasoTO casoTO = CasoTO.getCasoTOByResultSetFull(resultSet);

					return casoTO;
				}
			}
			return null;
		} finally {
			super.closeConnection();
		}
	}

	public void saveLog(LogTO logTO) throws Exception {
		try {
			StringBuilder sql = new StringBuilder()
					.append(INSERT)
					.append(" tb_log ")
					.append(" ( ID_STATUS, ID_CASO, DATA_LOG, DESCRICAO, ID_GRUPO_ANEXO, ID_ACAO, ID_EMAIL, ID_CONFIGURACAO_FILA, DETALHE, ID_USUARIO, ID_SLA_FILA, ID_EVENTO) ")
					.append(" VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ");

			PreparedStatement ps = super.getPreparedStatement(sql.toString());

			if (logTO.getIdStatus() == null) {
				ps.setNull(1, Types.NULL);
			} else {
				ps.setInt(1, logTO.getIdStatus());
			}

			if (logTO.getIdCaso() == null) {
				ps.setNull(2, Types.NULL);
			} else {
				ps.setInt(2, logTO.getIdCaso());
			}

			ps.setTimestamp(3, new java.sql.Timestamp(logTO.getDataLog().getTime()));
			ps.setString(4, logTO.getDescricao());

			if (logTO.getIdGrupoAnexo() == null) {
				ps.setNull(5, Types.NULL);
			} else {
				ps.setInt(5, logTO.getIdGrupoAnexo());
			}

			if (logTO.getIdAcao() == null) {
				ps.setNull(6, Types.NULL);
			} else {
				ps.setInt(6, logTO.getIdAcao());
			}

			if (logTO.getIdEmail() == null) {
				ps.setNull(7, Types.NULL);
			} else {
				ps.setInt(7, logTO.getIdEmail());
			}

			if (logTO.getIdConfiguracaoFila() == null) {
				ps.setNull(8, Types.NULL);
			} else {
				ps.setInt(8, logTO.getIdConfiguracaoFila());
			}

			ps.setString(9, logTO.getDetalhe());

			if (logTO.getIdUsuario() == null) {
				ps.setNull(10, Types.NULL);
			} else {
				ps.setInt(10, logTO.getIdUsuario());
			}
			
			if (logTO.getIdSlaFila() == null) {
				ps.setNull(11, Types.NULL);
			} else {
				ps.setInt(11, logTO.getIdSlaFila());
			}
			
			if (logTO.getIdEvento() == null) {
				ps.setNull(12, Types.NULL);
			} else {
				ps.setInt(12, logTO.getIdEvento());
			}

			ps.executeUpdate();

			logger.info("insertLog. ");

		} finally {
			super.closeConnection();
		}
	}

	public LayoutImportacaoTO buscaLayoutImportacaoEmailPorCaixaEmail(Integer idCaixaEmail) throws Exception {
		try {
			StringBuilder sql = new StringBuilder();
			sql.append(SELECT);
			sql.append("layout.id_layout as idLayout ");
			sql.append(",layout.IGNORAR_EMAIL as emailIgnorado ");
			sql.append(",layout.EMAIL_UNICO as emailUnico ");
			sql.append(",layout.id_job as idJob ");
			sql.append(",layout.nome as nome ");
			sql.append(",layout.id_fonte_dados as idFonteDados ");
			sql.append(",layout.cron as cron ");
			sql.append(",layout.sqlText as sqlText ");
			sql.append(",layout.id_operacao as idOperacao ");
			sql.append(",layout.id_status_inicial as idStatusInicial ");
			sql.append(",layout.id_status_finaliza as idStatusFinaliza ");
			sql.append(FROM);
			sql.append("tb_layout_importacao layout with(nolock), ");
			sql.append("tb_configuracao_caixa_email caixa with(nolock) ");
			sql.append(WHERE);
			sql.append("layout.id_layout = caixa.id_layout_importacao ");
			sql.append("AND caixa.id_configuracao_caixa_email = ? ");
			sql.append("AND layout.flag_ativo = 1 ");
			sql.append("AND caixa.flag_ativo = 1 ");

			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ps.setInt(1, idCaixaEmail);
			ResultSet resultSet = ps.executeQuery();

			if (resultSet != null) {
				while (resultSet.next()) {
					LayoutImportacaoTO layout = LayoutImportacaoTO.getLayoutImportacaoTOByResultSet(resultSet);
					return layout;
				}
			}
			return null;
		} finally {
			super.closeConnection();
		}
	}

	public List<CamposLayoutTO> buscaCamposByLayout(Integer idLayout) throws Exception {
		try {
			StringBuilder sql = new StringBuilder();
			sql.append(SELECT);
			sql.append("campo.campo_caso as campoCaso ");
			sql.append(",campo.campo_nome AS campoNome ");
			sql.append(",campo.campo_import_caso AS campoImportCaso ");
			sql.append(",CASE ");
			sql.append("WHEN din.size_campo IS NULL ");
			sql.append("THEN ( ");
			sql.append("SELECT colunas.length ");
			sql.append("FROM SYSOBJECTS tabelas, SYSCOLUMNS colunas ");
			sql.append("WHERE tabelas.id = colunas.id ");
			sql.append("AND tabelas.NAME = 'tb_caso' ");
			sql.append("AND colunas.NAME = campo.campo_caso ");
			sql.append(") ");
			sql.append("ELSE din.size_campo ");
			sql.append("END AS size ");
			sql.append(",campo.flag_not_null AS notNull ");
			sql.append(",campo.flag_campo_dinamico AS flagCampoDinamico ");
			sql.append(",campo.flag_identificador AS flagIdentificador ");
			sql.append(FROM);
			sql.append("tb_campo_layout campo with(nolock) ");
			sql.append("left join tb_campo_dinamico din with(nolock) on campo.campo_caso = din.nome_coluna ");
			sql.append(WHERE);
			sql.append("campo.id_layout = ? ");

			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ps.setInt(1, idLayout);
			ResultSet resultSet = ps.executeQuery();

			List<CamposLayoutTO> ret = new ArrayList<CamposLayoutTO>();
			if (resultSet != null) {
				while (resultSet.next()) {
					CamposLayoutTO campo = CamposLayoutTO.getCamposLayoutTOByResultSet(resultSet);
					ret.add(campo);
				}
			}
			return ret;

		} finally {
			super.closeConnection();
		}
	}

	public void inserImportCasoNative(List<ImportCasoTO> listImportCasos) throws Exception {
		try {
			for (ImportCasoTO importCaso : listImportCasos) {
				insertImportCasoNative(importCaso);
			}

		} finally {
			super.closeConnection();
		}
	}

	public void insertImportCasoNative(ImportCasoTO importCaso) throws Exception {
		boolean insereIdExterno = !StringUtils.isEmpty(importCaso.getIdExterno());
		boolean flagImportRejeitado = importCaso.getFlagImportRejeitado() != null && importCaso.getFlagImportRejeitado();
		
		StringBuilder sql = new StringBuilder();
		sql.append(" INSERT INTO tb_import_caso ");
		sql.append(" ( ");
		sql.append(" id_lote_caso ");
		sql.append(" , id_layout ");
		sql.append(" , id_email ");
		sql.append(" , flag_import_rejeitado ");
		
		if(insereIdExterno){
			sql.append(" , id_externo ");
		}

		for (String campo : importCaso.getMapDados().keySet()) {
			sql.append(", ").append(campo);
		}

		sql.append(" ) ");

		sql.append(" VALUES ");

		sql.append(" ( ");
		sql.append(MessageFormat.format("{0} ", importCaso.getIdLoteCaso().toString()));
		sql.append(MessageFormat.format(", {0} ", importCaso.getIdLayout().toString()));
		sql.append(MessageFormat.format(", {0} ", importCaso.getIdEmail().toString()));
		sql.append(MessageFormat.format(", {0} ", flagImportRejeitado ? "1" : "0"));
		
		if(insereIdExterno){
			sql.append(MessageFormat.format(", ''{0}'' ", importCaso.getIdExterno().toString()));
		}

		for (String campo : importCaso.getMapDados().keySet()) {
			String aux = (String) importCaso.getMapDados().get(campo);
			if (Character.getType(aux.toCharArray()[0]) == 16) {
				aux = aux.substring(1);
			}
			sql.append(MessageFormat.format(", ''{0}'' ", aux));
		}

		sql.append(" ) ");

		PreparedStatement ps = super.getPreparedStatement(sql.toString());
		ps.executeUpdate();
		
		logger.info("insertImportCaso. ");
	}

	public LoteCasoTO savarLoteCaso(LoteCasoTO loteCaso) throws Exception {
		try {
			StringBuilder sql = new StringBuilder();
			sql.append(INSERT);
			sql.append(" tb_lote_caso (id_layout, id_operacao, tipo_processo, tipo_execucao, status_execucao, flag_ativo, horario_agendamento)  ");
			sql.append(" values ");
			sql.append(" (?,?,?,?,?,?,?) ");

			PreparedStatement ps = getPreparedStatementId(sql.toString());
			ps.setInt(1, loteCaso.getIdLayout());
			ps.setInt(2, loteCaso.getIdOperacao());
			ps.setString(3, loteCaso.getTipoProcesso());
			ps.setString(4, loteCaso.getTipoExecucao());
			ps.setString(5, loteCaso.getStatusExecucao());
			ps.setBoolean(6, loteCaso.getFlagAtivo());
			ps.setTimestamp(7, new Timestamp(loteCaso.getHorarioAgendamento().getTime()));
			ps.executeUpdate();

			ResultSet generatedKeys = ps.getGeneratedKeys();
			if (generatedKeys.next()) {
				loteCaso.setIdLoteCaso((int) generatedKeys.getLong(1));
			}

			logger.info("insertLoteCaso. ");
			return loteCaso;
			

		} finally {
			super.closeConnection();
		}
	}

	public void atualizaStatusExecucaoLoteCaso(Integer idLoteCaso, String statusExecucaoPendente) throws Exception {
		try {
			StringBuilder sql = new StringBuilder();
			sql.append(UPDATE);
			sql.append(" tb_lote_caso ");
			sql.append(" set status_execucao = ? ");
			sql.append(WHERE);
			sql.append(" id_lote_caso = ? ");

			PreparedStatement ps = getPreparedStatement(sql.toString());
			ps.setString(1, statusExecucaoPendente);
			ps.setInt(2, idLoteCaso);
			ps.executeUpdate();
			
			logger.info("atualizaStatusExecucaoLoteCaso. ");

		} finally {
			super.closeConnection();
		}
	}
}