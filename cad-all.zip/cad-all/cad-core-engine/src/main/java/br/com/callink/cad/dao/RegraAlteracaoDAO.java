package br.com.callink.cad.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.com.callink.cad.to.RegraAlteracaoTO;

public class RegraAlteracaoDAO extends GenericDAO {

	public List<RegraAlteracaoTO> buscaRegrasLayout(Integer idLayoutAlteracao) throws Exception {

		List<RegraAlteracaoTO> regras = new ArrayList<RegraAlteracaoTO>();
		
		StringBuilder sq = new StringBuilder();
		sq.append(" select * from tb_regra_alteracao ");
		sq.append(" where id_layout_alteracao = ? ");
		
		try {
			PreparedStatement p = getPreparedStatement(sq.toString());
			p.setInt(1, idLayoutAlteracao);
			ResultSet resultSet = p.executeQuery();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					RegraAlteracaoTO regra = RegraAlteracaoTO.getRetraTOByResultSet(resultSet);
					regras.add(regra);
				}
			}

			return regras;
		} finally {
			super.closeConnection();
		}
	}
	
}
