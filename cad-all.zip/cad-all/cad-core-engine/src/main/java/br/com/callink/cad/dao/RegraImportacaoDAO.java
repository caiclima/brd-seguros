/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import br.com.callink.cad.to.RegraImportacaoTO;

public class RegraImportacaoDAO extends GenericDAO {

	private Logger logger = Logger.getLogger(RegraImportacaoDAO.class.getName());
	
	public List<RegraImportacaoTO> buscaRegrasExecucaoBancoByLayout(Integer idLayout, String tempoExecucao) throws Exception {
		try {
			final int ATIVO = 1;

			StringBuilder sql = new StringBuilder();
			sql.append(SELECT);
			sql.append("regra.id_regra_importacao as idRegraImportacao ");
			sql.append(",regra.nome AS nome ");
			sql.append(",regra.sql AS sql ");
			sql.append(FROM);
			sql.append("tb_regra_importacao regra with(nolock) ");
			sql.append(WHERE);
			sql.append("regra.id_layout = ? ");
			sql.append("and regra.flag_ativo = ? ");
			sql.append("and regra.tempo_execucao = ? ");
			sql.append("ORDER BY regra.ordem ASC ");

			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ps.setInt(1, idLayout);
			ps.setInt(2, ATIVO);
			ps.setString(3, tempoExecucao);
			ResultSet resultSet = ps.executeQuery();

			List<RegraImportacaoTO> ret = new ArrayList<RegraImportacaoTO>();
			if (resultSet != null) {
				while (resultSet.next()) {
					RegraImportacaoTO regra = RegraImportacaoTO.getRegrasImportacaoTOByResultSet(resultSet);
					ret.add(regra);
				}
			}
			return ret;
		} catch (Exception e) {
			StringBuilder str = new StringBuilder();
			
			str.append("Erro ao buscar regras do layout: ").append(idLayout);
			
			logger.log(Level.SEVERE, str.toString());
			
			throw e;
		} finally {
			super.closeConnection();
		}
	}
	
}
