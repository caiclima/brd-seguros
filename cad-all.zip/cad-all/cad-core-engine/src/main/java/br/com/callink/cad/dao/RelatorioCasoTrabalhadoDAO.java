package br.com.callink.cad.dao;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import br.com.callink.cad.to.RelatorioCasoTrabalhado;
import br.com.callink.cad.util.CollectionUtils;
import br.com.callink.cad.util.HintNumberRows;

public class RelatorioCasoTrabalhadoDAO extends GenericDAO {
	
	private final int BATCH_SIZE = 1000;

	public List<RelatorioCasoTrabalhado> buscaCasos(Integer idOperacao) throws Exception {
		final StringBuilder sql_portion = new StringBuilder();
		sql_portion.append("SELECT caso.id_caso ");
		sql_portion.append(",caso.id_externo ");
		sql_portion.append(",caso.id_operacao ");
		sql_portion.append(",caso.id_lote_caso ");
		sql_portion.append(",caso.id_caso_pai ");
		sql_portion.append(",caso.data_abertura ");
		sql_portion.append(",caso.data_cadastro ");
		sql_portion.append(",caso.data_encerramento ");
		sql_portion.append(",caso.data_prevista_fim_sla ");
		sql_portion.append(",caso.data_fim_sla ");
		sql_portion.append(",caso.flag_reaberto ");
		sql_portion.append(",caso.flag_criado_manual ");
		sql_portion.append(",caso.flag_finalizado ");
		sql_portion.append(",caso.flag_telefone_editado ");
		sql_portion.append(",caso.classificacao_count ");
		sql_portion.append(",caso.sla_minutos ");
		sql_portion.append(",caso.sla_total ");
		sql_portion.append(",caso.percentual_sla ");
		sql_portion.append(",caso.motivo_1 ");
		sql_portion.append(",caso.motivo_2 ");
		sql_portion.append(",caso.motivo_3 ");
		sql_portion.append(",caso.motivo_4 ");
		sql_portion.append(",caso.motivo_5 ");
		sql_portion.append(",caso.motivo_6 ");
		sql_portion.append(",caso.motivo_1_nome ");
		sql_portion.append(",caso.motivo_2_nome ");
		sql_portion.append(",caso.motivo_3_nome ");
		sql_portion.append(",caso.motivo_4_nome ");
		sql_portion.append(",caso.motivo_5_nome ");
		sql_portion.append(",caso.motivo_6_nome ");
		sql_portion.append(",tipoCaso.id_tipo_caso ");
		sql_portion.append(",tipoCaso.nome as nomeTipo ");
		sql_portion.append(",canal.id_canal ");
		sql_portion.append(",canal.nome as nomeCanal ");
		sql_portion.append(",usuario.id_usuario ");
		sql_portion.append(",usuario.login ");
		sql_portion.append(",fila.id_configuracao_fila ");
		sql_portion.append(",fila.nome as nomeFila ");
		sql_portion.append(",status.id_status ");
		sql_portion.append(",status.nome as nomeStatus ");
		sql_portion.append(",slaFila.id_sla_fila ");
		sql_portion.append(",slaFila.tipo_calculo ");
		sql_portion.append(",slaFila.sla ");
		sql_portion.append(",slaFila.descontar_dias ");
		sql_portion.append(",causa.id_causa ");
		sql_portion.append(",causa.nome as nomeCausa ");
		sql_portion.append(",ususup.id_usuario as idUsuarioSupervisor ");
		sql_portion.append(",ususup.nome as nomeUsuarioSupervisor ");
		sql_portion.append("FROM tb_caso caso WITH (NOLOCK) ");
		sql_portion.append("INNER JOIN TB_STATUS status WITH (NOLOCK) ON caso.id_status = status.id_status ");
		sql_portion.append("LEFT OUTER JOIN TB_USUARIO usuario WITH (NOLOCK) ON caso.id_usuario = usuario.id_usuario ");
		sql_portion.append("LEFT OUTER JOIN TB_TIPO_CASO tipoCaso WITH (NOLOCK) ON caso.id_tipo_caso = tipoCaso.id_tipo_caso ");
		sql_portion.append("LEFT OUTER JOIN TB_CANAL canal WITH (NOLOCK) ON caso.id_canal = canal.id_canal ");
		sql_portion.append("LEFT OUTER JOIN TB_CAUSA causa WITH (NOLOCK) ON caso.id_causa = causa.id_causa ");
		sql_portion.append("LEFT OUTER JOIN TB_SLA_FILA slaFila WITH (NOLOCK) ON caso.id_sla_fila = slaFila.id_sla_fila ");
		sql_portion.append("LEFT OUTER JOIN TB_OUTRA_AREA outraArea WITH (NOLOCK) ON caso.id_outra_area = outraArea.id_outra_area ");
		sql_portion.append("LEFT OUTER JOIN TB_CONFIGURACAO_FILA fila WITH (NOLOCK) ON caso.id_configuracao_fila = fila.id_configuracao_fila ");
		sql_portion.append("LEFT OUTER JOIN TB_USUARIO ususup WITH (NOLOCK) ON ususup.id_usuario = usuario.id_usuario_supervisor ");

		final StringBuilder sql = new StringBuilder();
		sql.append(sql_portion);
		sql.append("WHERE caso.flag_finalizado = 0 ");
		sql.append("AND caso.data_encerramento IS NULL ");
		sql.append("AND caso.id_operacao = ? ");
		sql.append("UNION ALL ");
		sql.append(sql_portion);
		sql.append("WHERE caso.flag_finalizado = 1 ");
		sql.append("AND caso.data_encerramento IS NOT NULL ");
		sql.append("AND caso.id_operacao = ? ");
		sql.append("AND CONVERT(VARCHAR(10), caso.data_encerramento, 103) = CONVERT(VARCHAR(10), GETDATE(), 103) ");

		try {
			PreparedStatement stmt = super.getPreparedStatement(sql.toString(), HintNumberRows.ROWS_CASO.getRows());
			stmt.setInt(1, idOperacao);
			stmt.setInt(2, idOperacao);

			ResultSet resultSet = stmt.executeQuery();
			List<RelatorioCasoTrabalhado> result = processaResultSet(resultSet);
			return result;

		} finally {
			super.closeConnection();
		}
	}

	private List<RelatorioCasoTrabalhado> processaResultSet(ResultSet resultSet) throws Exception {
		List<RelatorioCasoTrabalhado> ret = new ArrayList<RelatorioCasoTrabalhado>();
		if (resultSet != null) {
			while (resultSet.next()) {
				RelatorioCasoTrabalhado casoTrabalhado = new RelatorioCasoTrabalhado();
				casoTrabalhado.setIdCaso((Integer) (Integer) resultSet.getObject("id_caso"));
				casoTrabalhado.setIdExterno((String) resultSet.getObject("id_externo"));
				casoTrabalhado.setIdOperacao((Integer) (Integer) resultSet.getObject("id_operacao"));
				casoTrabalhado.setIdLoteCaso((Integer) resultSet.getObject("id_lote_caso"));
				casoTrabalhado.setIdCasoPai((Integer) resultSet.getObject("id_caso_pai"));
				casoTrabalhado.setDataAbertura((Date) resultSet.getObject("data_abertura"));
				casoTrabalhado.setDataCadastro((Date) resultSet.getObject("data_cadastro"));
				casoTrabalhado.setDataEncerramento((Date) resultSet.getObject("data_encerramento"));
				casoTrabalhado.setDataPrevistaFimSla((Date) resultSet.getObject("data_prevista_fim_sla"));
				casoTrabalhado.setDataFimSla((Date) resultSet.getObject("data_fim_sla"));
				casoTrabalhado.setFlagReaberto((Boolean) resultSet.getObject("flag_reaberto"));
				casoTrabalhado.setFlagCriadoManual((Boolean) resultSet.getObject("flag_criado_manual"));
				casoTrabalhado.setFlagFinalizado((Boolean) resultSet.getObject("flag_finalizado"));
				casoTrabalhado.setFlagTelefoneEditado((Boolean) resultSet.getObject("flag_telefone_editado"));
				casoTrabalhado.setClassificacaoCount((Integer) resultSet.getObject("classificacao_count"));
				casoTrabalhado.setSlaEmMinutosCaso((String) resultSet.getObject("sla_minutos"));
				casoTrabalhado.setSlaTotalMinutos((String) resultSet.getObject("sla_total"));
				casoTrabalhado.setPorcentagemSla(((BigDecimal) resultSet.getObject("percentual_sla")));
				casoTrabalhado.setMotivo1((Integer) resultSet.getObject("motivo_1"));
				casoTrabalhado.setMotivo2((Integer) resultSet.getObject("motivo_2"));
				casoTrabalhado.setMotivo3((Integer) resultSet.getObject("motivo_3"));
				casoTrabalhado.setMotivo4((Integer) resultSet.getObject("motivo_4"));
				casoTrabalhado.setMotivo5((Integer) resultSet.getObject("motivo_5"));
				casoTrabalhado.setMotivo6((Integer) resultSet.getObject("motivo_6"));
				casoTrabalhado.setMotivo1Nome((String) resultSet.getObject("motivo_1_nome"));
				casoTrabalhado.setMotivo2Nome((String) resultSet.getObject("motivo_2_nome"));
				casoTrabalhado.setMotivo3Nome((String) resultSet.getObject("motivo_3_nome"));
				casoTrabalhado.setMotivo4Nome((String) resultSet.getObject("motivo_4_nome"));
				casoTrabalhado.setMotivo5Nome((String) resultSet.getObject("motivo_5_nome"));
				casoTrabalhado.setMotivo6Nome((String) resultSet.getObject("motivo_6_nome"));
				casoTrabalhado.setIdTipoCaso((Integer) resultSet.getObject("id_tipo_caso"));
				casoTrabalhado.setNomeTipoCaso((String) resultSet.getObject("nomeTipo"));
				casoTrabalhado.setIdCanal((Integer) resultSet.getObject("id_canal"));
				casoTrabalhado.setNomeCanal((String) resultSet.getObject("nomeCanal"));
				casoTrabalhado.setIdCausa((Integer) resultSet.getObject("id_causa"));
				casoTrabalhado.setNomeCausa((String) resultSet.getObject("nomeCausa"));
				casoTrabalhado.setIdUsuario((Integer) resultSet.getObject("id_usuario"));
				casoTrabalhado.setLogin((String) resultSet.getObject("login"));
				casoTrabalhado.setIdConfiguracaoFila((Integer) resultSet.getObject("id_configuracao_fila"));
				casoTrabalhado.setNomeConfiguracaoFila((String) resultSet.getObject("nomeFila"));
				casoTrabalhado.setIdStatus((Integer) resultSet.getObject("id_status"));
				casoTrabalhado.setNomeStatus((String) resultSet.getObject("nomeStatus"));
				casoTrabalhado.setIdSlaFila((Integer) resultSet.getObject("id_sla_fila"));
				casoTrabalhado.setTipoCalculo((String) resultSet.getObject("tipo_calculo"));
				casoTrabalhado.setSlaMinutos((Integer) resultSet.getObject("sla"));
				casoTrabalhado.setDescontarDias((Integer) resultSet.getObject("descontar_dias"));
				casoTrabalhado.setIdUsuarioSupervisor((Integer) resultSet.getObject("idUsuarioSupervisor"));
				casoTrabalhado.setNomeUsuarioSupervisor((String) resultSet.getObject("nomeUsuarioSupervisor"));

				ret.add(casoTrabalhado);
			}
		}
		return ret;
	}

	public void deletaReletorioPorDia(String schemaDb, Integer idOperacao, Integer qtdRegistrosExpurgoPorVez) throws Exception {
		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" delete top (").append(qtdRegistrosExpurgoPorVez).append(") ")
			   .append(" from  ")
			   .append(schemaDb)
			   .append("..tb_relatorio_caso_trabalhado")
			   .append(" where CONVERT(VARCHAR(10), data_geracao, 103) = CONVERT(VARCHAR(10), getdate(), 103) ")
			   .append("   and id_operacao = ? ");

			PreparedStatement stmt = super.getPreparedStatement(sql.toString());
			stmt.setInt(1, idOperacao);
			
			int countDelete = stmt.executeUpdate();
			
			while (countDelete > 0) {
				countDelete = stmt.executeUpdate();
			}
		} finally {
			super.closeConnection();
		}
	}
	
	public void salvaRelatorio(String schemaDb, List<RelatorioCasoTrabalhado> dados) throws Exception {
		if (CollectionUtils.hasValue(dados)) {
			Connection connection = null;
			
			try {
				StringBuilder sql = new StringBuilder();
				sql.append("insert into ");
				sql.append(schemaDb);
				sql.append("..tb_relatorio_caso_trabalhado ");
				sql.append("( id_caso,id_externo,id_tipo_caso,nome_tipo_caso,motivo_1,motivo_2,motivo_3,motivo_4,motivo_5,motibo_6 ");
				sql.append(",id_motivo_1,id_motivo_2,id_motivo_3,id_motivo_4,id_motivo_5,id_motivo_6,id_canal,nome_canal,id_usuario ");
				sql.append(",login_usuario,id_configuracao_fila,nome_fila,id_status,nome_status,data_abertura,data_cadastro,data_encerramento ");
				sql.append(",data_fim_sla,flag_finalizado,classificacao_count,flag_reaberto,id_sla_fila,tipo_calculo,sla_minutos,descontar_dias ");
				sql.append(",id_lote_caso,flag_telefone_editado,id_causa,nome_causa,flag_criado_manual,id_operacao,data_prevista_fim_sla,id_caso_pai ");
				sql.append(",sla_minutos_caso,sla_total,percentual_sla,id_usuario_supervisor,nome_usuario_supervisor,data_geracao ) ");
				sql.append(" VALUES ");
				sql.append("( ?,?,?,?,?,?,?,?,?,? ");
				sql.append(" ,?,?,?,?,?,?,?,?,?,? ");
				sql.append(" ,?,?,?,?,?,?,?,?,?,? ");
				sql.append(" ,?,?,?,?,?,?,?,?,?,? ");
				sql.append(" ,?,?,?,?,?,?,?,?,? ) ");

				connection = getConnection();
				connection.setAutoCommit(false);

				PreparedStatement ps = connection.prepareStatement(sql.toString());
				ps.setFetchSize(dados.size());
				
				int count = 0;
				DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				
				for (RelatorioCasoTrabalhado relatorio : dados) {
					setParametersToInsert(ps, relatorio, df);
					ps.addBatch();

					if (++count % BATCH_SIZE == 0) {
						ps.executeBatch();
						connection.commit();
					}
				}
				
				ps.executeBatch(); // insert remaining records
				connection.commit();
				
			} catch (Exception e) {
				if (connection != null && !connection.isClosed()) {
					connection.rollback();
				}
				throw e;
				
			} finally {
				super.closeConnection();
			}
		}
	}

	private void setParametersToInsert(PreparedStatement ps, RelatorioCasoTrabalhado relatorio, DateFormat df) throws Exception, SQLException {
		if (relatorio.getIdCaso() != null) {
			ps.setInt(1, relatorio.getIdCaso());
		} else {
			ps.setNull(1, Types.NULL);
		}
		if (relatorio.getIdExterno() != null) {
			ps.setString(2, relatorio.getIdExterno());
		} else {
			ps.setNull(2, Types.NULL);
		}
		if (relatorio.getIdTipoCaso() != null) {
			ps.setInt(3, relatorio.getIdTipoCaso());
		} else {
			ps.setNull(3, Types.NULL);
		}
		if (relatorio.getNomeTipoCaso() != null) {
			ps.setString(4, relatorio.getNomeTipoCaso());
		} else {
			ps.setNull(4, Types.NULL);
		}
		if (relatorio.getMotivo1Nome() != null) {
			ps.setString(5, relatorio.getMotivo1Nome());
		} else {
			ps.setNull(5, Types.NULL);
		}
		if (relatorio.getMotivo2Nome() != null) {
			ps.setString(6, relatorio.getMotivo2Nome());
		} else {
			ps.setNull(6, Types.NULL);
		}
		if (relatorio.getMotivo3Nome() != null) {
			ps.setString(7, relatorio.getMotivo3Nome());
		} else {
			ps.setNull(7, Types.NULL);
		}
		if (relatorio.getMotivo4Nome() != null) {
			ps.setString(8, relatorio.getMotivo4Nome());
		} else {
			ps.setNull(8, Types.NULL);
		}
		if (relatorio.getMotivo5Nome() != null) {
			ps.setString(9, relatorio.getMotivo5Nome());
		} else {
			ps.setNull(9, Types.NULL);
		}
		if (relatorio.getMotivo6Nome() != null) {
			ps.setString(10, relatorio.getMotivo6Nome());
		} else {
			ps.setNull(10, Types.NULL);
		}
		if (relatorio.getMotivo1() != null) {
			ps.setInt(11, relatorio.getMotivo1());
		} else {
			ps.setNull(11, Types.NULL);
		}
		if (relatorio.getMotivo2() != null) {
			ps.setInt(12, relatorio.getMotivo2());
		} else {
			ps.setNull(12, Types.NULL);
		}
		if (relatorio.getMotivo3() != null) {
			ps.setInt(13, relatorio.getMotivo3());
		} else {
			ps.setNull(13, Types.NULL);
		}
		if (relatorio.getMotivo4() != null) {
			ps.setInt(14, relatorio.getMotivo4());
		} else {
			ps.setNull(14, Types.NULL);
		}
		if (relatorio.getMotivo5() != null) {
			ps.setInt(15, relatorio.getMotivo5());
		} else {
			ps.setNull(15, Types.NULL);
		}
		if (relatorio.getMotivo6() != null) {
			ps.setInt(16, relatorio.getMotivo6());
		} else {
			ps.setNull(16, Types.NULL);
		}
		if (relatorio.getIdCanal() != null) {
			ps.setInt(17, relatorio.getIdCanal());
		} else {
			ps.setNull(17, Types.NULL);
		}
		if (relatorio.getNomeCanal() != null) {
			ps.setString(18, relatorio.getNomeCanal());
		} else {
			ps.setNull(18, Types.NULL);
		}
		if (relatorio.getIdUsuario() != null) {
			ps.setInt(19, relatorio.getIdUsuario());
		} else {
			ps.setNull(19, Types.NULL);
		}
		if (relatorio.getLogin() != null) {
			ps.setString(20, relatorio.getLogin());
		} else {
			ps.setNull(20, Types.NULL);
		}
		if (relatorio.getIdConfiguracaoFila() != null) {
			ps.setInt(21, relatorio.getIdConfiguracaoFila());
		} else {
			ps.setNull(21, Types.NULL);
		}
		if (relatorio.getNomeConfiguracaoFila() != null) {
			ps.setString(22, relatorio.getNomeConfiguracaoFila());
		} else {
			ps.setNull(22, Types.NULL);
		}
		if (relatorio.getIdStatus() != null) {
			ps.setInt(23, relatorio.getIdStatus());
		} else {
			ps.setNull(23, Types.NULL);
		}
		if (relatorio.getNomeStatus() != null) {
			ps.setString(24, relatorio.getNomeStatus());
		} else {
			ps.setNull(24, Types.NULL);
		}
		if (relatorio.getDataAbertura() != null) {
			ps.setTimestamp(25, new Timestamp(relatorio.getDataAbertura().getTime()));
		} else {
			ps.setNull(25, Types.NULL);
		}
		if (relatorio.getDataCadastro() != null) {
			ps.setTimestamp(26, new Timestamp(relatorio.getDataCadastro().getTime()));
		} else {
			ps.setNull(26, Types.NULL);
		}
		if (relatorio.getDataEncerramento() != null) {
			ps.setTimestamp(27, new Timestamp(relatorio.getDataEncerramento().getTime()));
		} else {
			ps.setNull(27, Types.NULL);
		}
		if (relatorio.getDataFimSla() != null) {
			ps.setTimestamp(28, new Timestamp(relatorio.getDataFimSla().getTime()));
		} else {
			ps.setNull(28, Types.NULL);
		}
		if (relatorio.isFlagFinalizado() != null && relatorio.isFlagFinalizado()) {
			ps.setBoolean(29, relatorio.isFlagFinalizado());
		} else {
			ps.setNull(29, Types.NULL);
		}
		if (relatorio.getClassificacaoCount() != null) {
			ps.setInt(30, relatorio.getClassificacaoCount());
		} else {
			ps.setNull(30, Types.NULL);
		}
		if (relatorio.isFlagReaberto() != null && relatorio.isFlagReaberto()) {
			ps.setBoolean(31, relatorio.isFlagReaberto());
		} else {
			ps.setNull(31, Types.NULL);
		}
		if (relatorio.getIdSlaFila() != null) {
			ps.setInt(32, relatorio.getIdSlaFila());
		} else {
			ps.setNull(32, Types.NULL);
		}
		if (relatorio.getTipoCalculo() != null) {
			ps.setString(33, relatorio.getTipoCalculo());
		} else {
			ps.setNull(33, Types.NULL);
		}
		if (relatorio.getSlaMinutos() != null) {
			ps.setInt(34, relatorio.getSlaMinutos());
		} else {
			ps.setNull(34, Types.NULL);
		}
		if (relatorio.getDescontarDias() != null) {
			ps.setInt(35, relatorio.getDescontarDias());
		} else {
			ps.setNull(35, Types.NULL);
		}
		if (relatorio.getIdLoteCaso() != null) {
			ps.setInt(36, relatorio.getIdLoteCaso());
		} else {
			ps.setNull(36, Types.NULL);
		}
		if (relatorio.isFlagTelefoneEditado() != null && relatorio.isFlagTelefoneEditado()) {
			ps.setBoolean(37, relatorio.isFlagTelefoneEditado());
		} else {
			ps.setNull(37, Types.NULL);
		}
		if (relatorio.getIdCausa() != null) {
			ps.setInt(38, relatorio.getIdCausa());
		} else {
			ps.setNull(38, Types.NULL);
		}
		if (relatorio.getNomeCausa() != null) {
			ps.setString(39, relatorio.getNomeCausa());
		} else {
			ps.setNull(39, Types.NULL);
		}
		if (relatorio.isFlagCriadoManual() != null && relatorio.isFlagCriadoManual()) {
			ps.setBoolean(40, relatorio.isFlagCriadoManual());
		} else {
			ps.setNull(40, Types.NULL);
		}
		if (relatorio.getIdOperacao() != null) {
			ps.setInt(41, relatorio.getIdOperacao());
		} else {
			ps.setNull(41, Types.NULL);
		}
		if (relatorio.getDataPrevistaFimSla() != null) {
			ps.setTimestamp(42, new Timestamp(relatorio.getDataPrevistaFimSla().getTime()));
		} else {
			ps.setNull(42, Types.NULL);
		}
		if (relatorio.getIdCasoPai() != null) {
			ps.setInt(43, relatorio.getIdCasoPai());
		} else {
			ps.setNull(43, Types.NULL);
		}
		if (relatorio.getSlaEmMinutosCaso() != null) {
			ps.setString(44, relatorio.getSlaEmMinutosCaso());
		} else {
			ps.setNull(44, Types.NULL);
		}
		if (relatorio.getSlaTotalMinutos() != null) {
			ps.setString(45, relatorio.getSlaTotalMinutos());
		} else {
			ps.setNull(45, Types.NULL);
		}
		if (relatorio.getPorcentagemSla() != null) {
			ps.setBigDecimal(46, relatorio.getPorcentagemSla());
		} else {
			ps.setNull(46, Types.NULL);
		}
		if (relatorio.getIdUsuarioSupervisor() != null && relatorio.getIdUsuarioSupervisor() > 0) {
			ps.setInt(47, relatorio.getIdUsuarioSupervisor());
		} else {
			ps.setNull(47, Types.NULL);
		}
		if (relatorio.getNomeUsuarioSupervisor() != null) {
			ps.setString(48, relatorio.getNomeUsuarioSupervisor());
		} else {
			ps.setNull(48, Types.NULL);
		}
		if (relatorio.getDataGeracao() != null) {
			ps.setString(49, df.format(relatorio.getDataGeracao()));
		} else {
			ps.setNull(49, Types.NULL);
		}
	}

	public void executaExpurgoDados(String schemaDb, Integer idOperacao, Integer qtdDiasExpurgo, Date dataAtual) throws Exception {
		try {
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			StringBuilder sql = new StringBuilder();
			sql.append("delete from ")
			.append(schemaDb)
			.append("..tb_relatorio_caso_trabalhado ")
			.append("where id_operacao = ? ").append("  and data_geracao < DATEADD(dd, - ?, ?) ");

			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ps.setInt(1, idOperacao);
			ps.setInt(2, qtdDiasExpurgo);
			ps.setString(3, df.format(dataAtual));
			ps.executeUpdate();
		} finally {
			super.closeConnection();
		}
	}
}
