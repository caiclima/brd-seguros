package br.com.callink.cad.dao;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.DateFormat;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import br.com.callink.cad.to.CampoDinamicoTO;
import br.com.callink.cad.to.RelatorioHistoricoCasoTO;
import br.com.callink.cad.to.TipoCampoDinamico;
import br.com.callink.cad.util.CollectionUtils;
import br.com.callink.cad.util.DateUtils;
import br.com.callink.cad.util.StringUtils;

public class RelatorioHistoricoCasoDAO extends GenericDAO {

	private static final String QUERY_CAMPO_TABELA_ASSOCIACAO = "INSERT INTO DB_CAD_REPORT..TB_ASSOCIA_CAMPO_TABELA SELECT ASS.ID_ASSOCIA_CAMPO_TABELA ,ASS.ID_CAMPO_TABELA,ASS.ID_CONFIGURACAO_CAMPO_TABELA ,ASS.LABEL ,CONF.NOME_COLUNA ,CONF.MASCARA ,CONF.TIPO_CAMPO ,CONF.SIZE_CAMPO FROM TB_ASSOCIA_CAMPO_TABELA ASS WITH (NOLOCK) INNER JOIN TB_CONFIGURACAO_CAMPO_TABELA CONF WITH (NOLOCK) ON CONF.ID_CONFIGURACAO_CAMPO_TABELA = ASS.ID_CONFIGURACAO_CAMPO_TABELA WHERE ASS.ID_CAMPO_TABELA = ? and ASS.ID_CAMPO_TABELA NOT IN (SELECT EXCESSAO.ID_CAMPO_TABELA FROM DB_CAD_REPORT..TB_ASSOCIA_CAMPO_TABELA EXCESSAO WHERE EXCESSAO.ID_CAMPO_TABELA = ? AND EXCESSAO.nome_coluna = CONF.NOME_COLUNA)";

	private static final String QUERY_CAMPO_TABELA = "DECLARE @MINUTE AS INTEGER DECLARE @SECOND AS INTEGER DECLARE @ID_CASO AS INTEGER DECLARE @ID_CAMPO_TABELA AS INTEGER DECLARE @HOUR AS INTEGER DECLARE @DAY AS INTEGER DECLARE @MONTH AS INTEGER DECLARE @YEAR AS INTEGER DECLARE @REGISTRO AS INTEGER DECLARE @DATA1 AS DATETIME DECLARE @DATA2 AS DATETIME SET @ID_CASO = ? SET @ID_CAMPO_TABELA = ? SET @DATA1 = (SELECT TOP 1 DATA_ALTERACAO FROM TB_VALOR_CAMPO_TABELA WITH (NOLOCK) WHERE ID_CASO = @ID_CASO AND ID_CAMPO_TABELA = @ID_CAMPO_TABELA) SET @DATA2 = (SELECT TOP 1 DATA_ALTERACAO FROM DB_CAD_REPORT..TB_VALOR_CAMPO_TABELA WITH (NOLOCK) WHERE ID_CASO = @ID_CASO AND ID_CAMPO_TABELA = @ID_CAMPO_TABELA ORDER BY 1 DESC) IF @DATA2 IS NULL BEGIN SET @DATA2 = GETDATE()-1000 END SET @SECOND = (SELECT DATEDIFF(SECOND, @DATA1,@DATA2)) SET @MINUTE = (SELECT DATEDIFF(MINUTE, @DATA1,@DATA2))	SET @HOUR = (SELECT DATEDIFF(HOUR, @DATA1,@DATA2))	SET @DAY = (SELECT DATEDIFF(DAY, @DATA1,@DATA2)) SET @MONTH = (SELECT DATEDIFF(MONTH, @DATA1,@DATA2)) SET @YEAR =  (SELECT DATEDIFF(YEAR, @DATA1,@DATA2)) SET @REGISTRO = (SELECT TOP 1 id_caso FROM DB_CAD_REPORT..TB_VALOR_CAMPO_TABELA WITH (NOLOCK) WHERE ID_CASO = @ID_CASO AND ID_CAMPO_TABELA = @ID_CAMPO_TABELA) IF	@REGISTRO IS NULL OR ((@SECOND < 0 ) OR (@MINUTE < 0 )OR (@HOUR < 0 )OR (@DAY < 0)OR (@MONTH < 0)OR (@YEAR < 0)) BEGIN INSERT INTO DB_CAD_REPORT..TB_VALOR_CAMPO_TABELA SELECT * FROM TB_VALOR_CAMPO_TABELA WITH (NOLOCK) WHERE ID_CASO = @ID_CASO AND ID_CAMPO_TABELA = @ID_CAMPO_TABELA END ";

	private Logger logger = Logger.getLogger(RelatorioHistoricoCasoDAO.class.getName());

	private final int BATCH_SIZE = 1000;
	private final int QTD_REGISTROS_TOP = 2500;
	private final double DOIS_SEGUNDOS = 0.00002;

	public void executaExpurgoDados(String schemaDb, Integer idOperacao, Integer qtdDiasExpurgo, Date dataAtual, Integer qtdRegistrosExpurgoPorVez) throws Exception {
		try {
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			StringBuilder sql = new StringBuilder();
			
			sql.append(" delete top (").append(qtdRegistrosExpurgoPorVez).append(")")
			   .append(" from ")
			   .append(schemaDb)
			   .append("..tb_historico_caso ")
			   .append(" where id_operacao = ? ")
			   .append("   and data_insercao < DATEADD(dd, - ?, ?) ");

			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ps.setInt(1, idOperacao);
			ps.setInt(2, qtdDiasExpurgo);
			ps.setString(3, df.format(dataAtual));
			
			int countDelete = ps.executeUpdate();
			
			while (countDelete > 0) {
				countDelete = ps.executeUpdate();
			}
		} finally {
			super.closeConnection();
		}
	}

	public List<RelatorioHistoricoCasoTO> geraNuvemHistoricoCasoPeriodoFechados(Integer idOperacao, Date dataInicio, Date dataFim, Boolean diaAtual, 
			List<CampoDinamicoTO> camposDinamicos, Integer ultimoIdLog,String schemaDB) throws Exception {
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		List<RelatorioHistoricoCasoTO> result = new ArrayList<RelatorioHistoricoCasoTO>();
		PreparedStatement stmtFechados = null;
		ResultSet resultSetFechados = null;

		StringBuilder sqlSelect = montaSQLHistorico(camposDinamicos);

		try {
			StringBuilder sql = new StringBuilder();

			// Busca casos fechados no dia
			// Faz a busca para o dia inteiro, para garantir que os logs sejam encontrados
			sql.append(sqlSelect);
			sql.append(" where ca.id_operacao = ? ");
			sql.append("   and ca.flag_finalizado = 1 ");
			sql.append("   and ca.data_encerramento IS NOT NULL ");
			sql.append("   and ca.data_encerramento >= '").append(df.format(DateUtils.addFirstTimeInDate(dataInicio))).append("' ");
			sql.append("   and ca.data_encerramento <= '").append(df.format(DateUtils.addLastTimeInDate(dataInicio))).append("' ");
			sql.append("   and not exists (select top 1 1 from ").append(schemaDB).append("..tb_historico_caso with(nolock) where id_log = lo.id_log ) ");
			
			if (ultimoIdLog != null && ultimoIdLog > 0) {
				sql.append("   and lo.id_log > ? ");
			}

			sql.append(" order by lo.id_log asc ");

			stmtFechados = getPreparedStatement(sql.toString());
			stmtFechados.setInt(1, idOperacao);
			if (ultimoIdLog != null && ultimoIdLog > 0) {
				stmtFechados.setInt(2, ultimoIdLog);
			}

			stmtFechados.execute();
			resultSetFechados = stmtFechados.getResultSet();
			List<RelatorioHistoricoCasoTO> casosFechadosDia = processaResultSet(resultSetFechados, camposDinamicos);

			result.addAll(casosFechadosDia);
		} catch (Exception e) {
			throw new Exception("Erro ao buscar historico dos casos Fechados. Operacao: "+idOperacao+" - Ultimo Log: "+ultimoIdLog+" - Dia Atual: "+diaAtual, e);
		} finally {
			super.closeConnection();
		}
		return result;
	}
	
	public List<RelatorioHistoricoCasoTO> geraNuvemHistoricoCasoPeriodoAbertos(Integer idOperacao, Date dataInicio, Date dataFim, Boolean diaAtual, 
			List<CampoDinamicoTO> camposDinamicos, Integer ultimoIdLog,String schemaDB) throws Exception {
		List<RelatorioHistoricoCasoTO> result = new ArrayList<RelatorioHistoricoCasoTO>();
		PreparedStatement stmtAbertos = null;
		ResultSet resultSetAbertos = null;

		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		StringBuilder sqlSelect = montaSQLHistorico(camposDinamicos);

		try {
			StringBuilder sql = new StringBuilder();

			sql.append(sqlSelect);
			sql.append(" where ca.flag_finalizado = 0 ");
			sql.append("   and ca.id_operacao = ? ");
			sql.append("   and lo.data_log >= '").append(df.format(dataInicio)).append("' ");
			sql.append("   and lo.data_log <= '").append(df.format(dataFim)).append("' ");
			sql.append("   and not exists (select top 1 1 from ").append(schemaDB).append("..tb_historico_caso with(nolock) where id_log = lo.id_log ) ");

			if (ultimoIdLog != null && ultimoIdLog > 0) {
				sql.append("   and lo.id_log > ? ");
			}

			sql.append(" order by lo.id_log asc ");

			stmtAbertos = getPreparedStatement(sql.toString());
			stmtAbertos.setInt(1, idOperacao);
			if (ultimoIdLog != null && ultimoIdLog > 0) {
				stmtAbertos.setInt(2, ultimoIdLog);
			}

			stmtAbertos.execute();
			resultSetAbertos = stmtAbertos.getResultSet();
			List<RelatorioHistoricoCasoTO> casosAbertos = processaResultSet(resultSetAbertos, camposDinamicos);

			result.addAll(casosAbertos);
		} catch (Exception e) {
			throw new Exception("Erro ao buscar historico dos casos Abertos. Operacao: "+idOperacao+" - Ultimo Log: "+ultimoIdLog+" - Dia Atual: "+diaAtual, e);
		} finally {
			super.closeConnection();
		}
		return result;
	}

	private StringBuilder montaSQLHistorico(List<CampoDinamicoTO> camposDinamicos) {
		StringBuilder sqlSelect = new StringBuilder();
		sqlSelect.append(" select ").append(" TOP ").append(QTD_REGISTROS_TOP);
		sqlSelect.append(" 	lo.id_log as ID_LOG, ");
		sqlSelect.append(" 	ca.id_caso as ID_CASO, ");
		sqlSelect.append(" 	cade.id_caso_detalhe as ID_CASO_DETALHE, ");
		sqlSelect.append(" 	st.id_status as ID_STATUS, ");
		sqlSelect.append(" 	st.nome as NOME_STATUS, ");
		sqlSelect.append(" 	lo.data_log as DATA_LOG, ");
		sqlSelect.append(" 	lo.descricao as DESCRICAO_LOG, ");
		sqlSelect.append(" 	ga.id_grupo_anexo as ID_GRUPO_ANEXO, ");
		sqlSelect.append(" 	ga.nome as NOME_GRUPO_ANEXO, ");
		sqlSelect.append(" 	ac.id_acao as ID_ACAO, ");
		sqlSelect.append(" 	ac.nome as NOME_ACAO, ");
		sqlSelect.append(" 	cf.id_configuracao_fila as ID_CONFIGURACAO_FILA, ");
		sqlSelect.append(" 	cf.nome as NOME_CONFIGURACAO_FILA, ");
		sqlSelect.append(" 	lo.detalhe as DETALHE_LOG, ");
		sqlSelect.append(" 	us.id_usuario as ID_USUARIO, ");
		sqlSelect.append(" 	us.login as LOGIN_USUARIO, ");
		sqlSelect.append(" 	us.nome as NOME_USUARIO, ");
		sqlSelect.append(" 	eq.id_equipe as ID_EQUIPE, ");
		sqlSelect.append(" 	eq.nome as NOME_EQUIPE, ");
		sqlSelect.append(" 	sl.id_sla_fila as ID_SLA_FILA, ");
		sqlSelect.append(" 	sl.sla as SLA, ");
		sqlSelect.append(" 	lo.data_abertura as DATA_ABERTURA, ");
		sqlSelect.append(" 	ca.data_encerramento as DATA_ENCERRAMENTO, ");
		sqlSelect.append(" 	ca.data_cadastro as DATA_CADASTRO, ");
		sqlSelect.append(" 	ca.flag_classifica as FLAG_CLASSIFICA, ");
		sqlSelect.append(" 	ca.flag_finalizado as FLAG_FINALIZADO, ");
		sqlSelect.append(" 	ca.id_externo as ID_EXTERNO, ");
		sqlSelect.append(" 	ca.data_fim_sla as DATA_FIM_SLA, ");
		sqlSelect.append(" 	ca.flag_em_atendimento as FLAG_EM_ATENDIMENTO, ");
		sqlSelect.append(" 	ca.classificacao_count as CLASSIFICACAO_COUNT, ");
		sqlSelect.append(" 	ca.flag_reaberto as FLAG_REABERTO, ");
		sqlSelect.append(" 	ca.flag_reclassifica_reabertura as FLAG_RECLASSIFICA_REABERTURA, ");
		sqlSelect.append(" 	ca.id_lote_caso as ID_LOTE_CASO, ");
		sqlSelect.append(" 	ca.flag_telefone_editado as FLAG_TELEFONE_EDITADO, ");
		sqlSelect.append(" 	ca.edicao_telefone_count as EDICAO_TELEFONE_COUNT, ");
		sqlSelect.append(" 	cau.id_causa as ID_CAUSA, ");
		sqlSelect.append(" 	cau.nome as NOME_CAUSA, ");
		sqlSelect.append(" 	lo.id_evento as ID_EVENTO, ");
		sqlSelect.append(" 	ev.nome as NOME_EVENTO, ");
		sqlSelect.append(" 	tc.id_tipo_caso as ID_TIPO_CASO, ");
		sqlSelect.append(" 	tc.nome as NOME_TIPO_CASO, ");
		sqlSelect.append(" 	can.id_canal as ID_CANAL, ");
		sqlSelect.append(" 	can.nome as NOME_CANAL, ");
		sqlSelect.append(" 	oa.id_outra_area as ID_OUTRA_AREA, ");
		sqlSelect.append(" 	oa.nome as NOME_OUTRA_AREA, ");
		sqlSelect.append(" 	ju.id_juncao as ID_JUNCAO, ");
		sqlSelect.append(" 	ju.nome as NOME_JUNCAO, ");
		sqlSelect.append(" 	ca.motivo_1 as MOTIVO_1, ");
		sqlSelect.append(" 	ca.motivo_1_nome as MOTIVO_1_NOME, ");
		sqlSelect.append(" 	ca.motivo_2 as MOTIVO_2, ");
		sqlSelect.append(" 	ca.motivo_2_nome as MOTIVO_2_NOME, ");
		sqlSelect.append(" 	ca.motivo_3 as MOTIVO_3, ");
		sqlSelect.append(" 	ca.motivo_3_nome as MOTIVO_3_NOME, ");
		sqlSelect.append(" 	ca.motivo_4 as MOTIVO_4, ");
		sqlSelect.append(" 	ca.motivo_4_nome as MOTIVO_4_NOME, ");
		sqlSelect.append(" 	ca.motivo_5 as MOTIVO_5, ");
		sqlSelect.append(" 	ca.motivo_5_nome as MOTIVO_5_NOME, ");
		sqlSelect.append(" 	ca.motivo_6 as MOTIVO_6, ");
		sqlSelect.append(" 	ca.motivo_6_nome as MOTIVO_6_NOME, ");
		sqlSelect.append(" 	ca.flag_criado_manual as FLAG_CRIADO_MANUAL, ");
		sqlSelect.append(" 	op.id_operacao as ID_OPERACAO, ");
		sqlSelect.append(" 	op.nome as NOME_OPERACAO, ");
		sqlSelect.append(" 	ca.data_prevista_fim_sla as DATA_PREVISTA_FIM_SLA, ");
		sqlSelect.append(" 	ca.id_caso_pai as ID_CASO_PAI, ");
		sqlSelect.append(" 	ca.descricao as DESCRICAO_CASO, ");
		sqlSelect.append(" 	ca.data_alteracao as DATA_ALTERACAO, ");
		sqlSelect.append(" 	ca.id_import_caso as ID_IMPORT_CASO, ");
		sqlSelect.append("  case when lo.data_abertura is not null then lo.data_abertura ");
		sqlSelect.append("   else ( ");
		sqlSelect.append(" 	    SELECT TOP 1 log_sla.data_abertura ");
		sqlSelect.append(" 	    FROM tb_log_sla_caso log_sla with(nolock) ");
		sqlSelect.append(" 	    WHERE ca.id_caso = log_sla.id_caso ");
		sqlSelect.append(" 	    AND log_sla.data_alteracao >= lo.data_log ");
		sqlSelect.append(" 	    ORDER BY log_sla.data_alteracao asc ");
		sqlSelect.append(" 	 ) end AS DATA_ABERTURA_LOG_SLA, ");
		sqlSelect.append("  case when lo.id_sla_fila is not null then lo.id_sla_fila ");
		sqlSelect.append("   else ( ");
		sqlSelect.append(" 	    SELECT TOP 1 log_sla.id_sla_fila ");
		sqlSelect.append(" 	    FROM tb_log_sla_caso log_sla with(nolock) ");
		sqlSelect.append(" 	    WHERE ca.id_caso = log_sla.id_caso ");
		sqlSelect.append(" 	    AND log_sla.data_alteracao >= lo.data_log ");
		sqlSelect.append(" 	    ORDER BY log_sla.data_alteracao asc ");
		sqlSelect.append(" 	 ) end AS ID_SLA_FILA_LOG_SLA, ");
		sqlSelect.append(" 	ca.data_abertura as DATA_ABERTURA_CASO, ");
		sqlSelect.append("	slacaso.id_sla_fila AS ID_SLA_CASO, ");
		sqlSelect.append("	slacaso.sla AS SLA_CASO, ");
		sqlSelect.append("	atc.data_inicio AS DATA_INICIO_ACAO, ");
		sqlSelect.append("	atc.data_fim AS DATA_FIM_ACAO, ");
		sqlSelect.append("	ususup.id_usuario AS ID_USUARIO_SUPERVISOR, ");
		sqlSelect.append("	ususup.nome AS NOME_USUARIO_SUPERVISOR ");

		for (int x = 0; x < camposDinamicos.size(); x++) {
			sqlSelect.append(", ").append(camposDinamicos.get(x).getNomeColuna()).append(" as ").append(camposDinamicos.get(x).getNomeColuna());
		}

		sqlSelect.append(" from tb_log lo with(nolock) ");
		sqlSelect.append("  inner join tb_caso ca with(nolock) ");
		sqlSelect.append("   on ca.id_caso = lo.id_caso ");
		sqlSelect.append("  inner join tb_status st with(nolock) ");
		sqlSelect.append("   on st.id_status = lo.id_status ");
		sqlSelect.append("  inner join tb_caso_detalhe cade with(nolock) ");
		sqlSelect.append("   on cade.id_caso = ca.id_caso ");
		sqlSelect.append("  left join tb_grupo_anexo ga with(nolock) ");
		sqlSelect.append("   on ga.id_grupo_anexo = lo.id_grupo_anexo ");
		sqlSelect.append("  left join tb_acao ac with(nolock) ");
		sqlSelect.append("   on ac.id_acao = lo.id_acao ");
		sqlSelect.append("  left join tb_configuracao_fila cf with(nolock) ");
		sqlSelect.append("   on cf.id_configuracao_fila = lo.id_configuracao_fila ");
		sqlSelect.append("  left join tb_evento ev with(nolock) ");
		sqlSelect.append("   on ev.id_evento = lo.id_evento ");
		sqlSelect.append("  left join tb_usuario us with(nolock) ");
		sqlSelect.append("   on us.id_usuario = lo.id_usuario ");
		sqlSelect.append("  left join tb_equipe eq with(nolock) ");
		sqlSelect.append("   on eq.id_equipe = lo.id_equipe ");
		sqlSelect.append("  left join tb_sla_fila sl with(nolock) ");
		sqlSelect.append("   on sl.id_sla_fila = lo.id_sla_fila ");
		sqlSelect.append("  left join tb_causa cau with(nolock) ");
		sqlSelect.append("   on cau.id_causa = ca.ID_CAUSA ");
		sqlSelect.append("  inner join tb_tipo_caso tc with(nolock) ");
		sqlSelect.append("   on tc.id_tipo_caso = ca.id_tipo_caso ");
		sqlSelect.append("  left join tb_canal can with(nolock) ");
		sqlSelect.append("   on can.id_canal = ca.id_canal ");
		sqlSelect.append("  left join tb_outra_area oa with(nolock) ");
		sqlSelect.append("   on oa.id_outra_area = ca.id_outra_area ");
		sqlSelect.append("  left join tb_juncao ju with(nolock) ");
		sqlSelect.append("   on ju.id_juncao = ca.id_juncao ");
		sqlSelect.append("  inner join tb_operacao op with(nolock) ");
		sqlSelect.append("   on op.id_operacao = ca.id_operacao ");
		sqlSelect.append("  left join tb_sla_fila slacaso with(nolock) ");
		sqlSelect.append("   on slacaso.id_sla_fila = ca.id_sla_fila ");
		sqlSelect.append("  left join tb_tempo_atendimento_caso atc with(nolock)");
		sqlSelect.append("	 on ( atc.data_fim BETWEEN (lo.data_log - ").append(DOIS_SEGUNDOS).append(")");
		sqlSelect.append("   and ( lo.data_log + ").append(DOIS_SEGUNDOS).append(")");
		sqlSelect.append("	 and atc.id_caso = ca.id_caso AND atc.id_acao = lo.id_acao )");
		sqlSelect.append("  left join tb_usuario ususup with(nolock) ");
		sqlSelect.append("   on ususup.id_usuario = us.id_usuario_supervisor ");
		return sqlSelect;
	}

	private List<RelatorioHistoricoCasoTO> processaResultSet(ResultSet resultSet, List<CampoDinamicoTO> camposDinamicos) throws Exception {
		List<RelatorioHistoricoCasoTO> ret = new ArrayList<RelatorioHistoricoCasoTO>();
		if (resultSet != null) {
			while (resultSet.next()) {
				RelatorioHistoricoCasoTO historicoCaso = new RelatorioHistoricoCasoTO();
				historicoCaso.setIdLog((Integer) resultSet.getObject("ID_LOG"));
				historicoCaso.setIdCaso((Integer) resultSet.getObject("ID_CASO"));
				historicoCaso.setIdCasoDetalhe((Integer) resultSet.getObject("ID_CASO_DETALHE"));
				historicoCaso.setIdStatus((Integer) resultSet.getObject("ID_STATUS"));
				historicoCaso.setNomeStatus(resultSet.getString("NOME_STATUS"));
				historicoCaso.setDataLog(resultSet.getTimestamp("DATA_LOG"));
				historicoCaso.setDescricaoLog(resultSet.getString("DESCRICAO_LOG"));
				historicoCaso.setIdGrupoAnexo((Integer) resultSet.getObject("ID_GRUPO_ANEXO"));
				historicoCaso.setNomeGrupoAnexo(resultSet.getString("NOME_GRUPO_ANEXO"));
				historicoCaso.setIdAcao((Integer) resultSet.getObject("ID_ACAO"));
				historicoCaso.setNomeAcao(resultSet.getString("NOME_ACAO"));
				historicoCaso.setIdConfiguracaoFila((Integer) resultSet.getObject("ID_CONFIGURACAO_FILA"));
				historicoCaso.setNomeConfiguracaoFila(resultSet.getString("NOME_CONFIGURACAO_FILA"));
				historicoCaso.setDetalheLog(resultSet.getString("DETALHE_LOG"));
				historicoCaso.setIdUsuario((Integer) resultSet.getObject("ID_USUARIO"));
				historicoCaso.setLoginUsuario(resultSet.getString("LOGIN_USUARIO"));
				historicoCaso.setNomeUsuario(resultSet.getString("NOME_USUARIO"));
				historicoCaso.setIdEquipe((Integer) resultSet.getObject("ID_EQUIPE"));
				historicoCaso.setNomeEquipe(resultSet.getString("NOME_EQUIPE"));
				historicoCaso.setIdSlaFila((Integer) resultSet.getObject("ID_SLA_FILA"));
				historicoCaso.setSla((Integer) resultSet.getObject("SLA"));
				historicoCaso.setDataAbertura(resultSet.getTimestamp("DATA_ABERTURA"));
				historicoCaso.setDataEncerramento(resultSet.getTimestamp("DATA_ENCERRAMENTO"));
				historicoCaso.setDataCadastro(resultSet.getTimestamp("DATA_CADASTRO"));
				historicoCaso.setFlagClassifica(resultSet.getBoolean("FLAG_CLASSIFICA"));
				historicoCaso.setFlagFinalizado(resultSet.getBoolean("FLAG_FINALIZADO"));
				historicoCaso.setIdExterno(resultSet.getString("ID_EXTERNO"));
				historicoCaso.setDataFimSla(resultSet.getTimestamp("DATA_FIM_SLA"));
				historicoCaso.setFlagEmAtendimento(resultSet.getBoolean("FLAG_EM_ATENDIMENTO"));
				historicoCaso.setClassificacaoCount((Integer) resultSet.getObject("CLASSIFICACAO_COUNT"));
				historicoCaso.setFlagReaberto(resultSet.getBoolean("FLAG_REABERTO"));
				historicoCaso.setFlagReclassificaReabertura(resultSet.getBoolean("FLAG_RECLASSIFICA_REABERTURA"));
				historicoCaso.setIdLoteCaso((Integer) resultSet.getObject("ID_LOTE_CASO"));
				historicoCaso.setFlagTelefoneEditado(resultSet.getBoolean("FLAG_TELEFONE_EDITADO"));
				historicoCaso.setEdicaoTelefoneCount((Integer) resultSet.getObject("EDICAO_TELEFONE_COUNT"));
				historicoCaso.setIdCausa((Integer) resultSet.getObject("ID_CAUSA"));
				historicoCaso.setNomeCausa(resultSet.getString("NOME_CAUSA"));
				historicoCaso.setIdEvento((Integer) resultSet.getObject("ID_EVENTO"));
				historicoCaso.setNomeEvento(resultSet.getString("NOME_EVENTO"));
				historicoCaso.setIdTipoCaso((Integer) resultSet.getObject("ID_TIPO_CASO"));
				historicoCaso.setNomeTipoCaso(resultSet.getString("NOME_TIPO_CASO"));
				historicoCaso.setIdCanal((Integer) resultSet.getObject("ID_CANAL"));
				historicoCaso.setNomeCanal(resultSet.getString("NOME_CANAL"));
				historicoCaso.setIdOutraArea((Integer) resultSet.getObject("ID_OUTRA_AREA"));
				historicoCaso.setNomeOutraArea(resultSet.getString("NOME_OUTRA_AREA"));
				historicoCaso.setIdJuncao((Integer) resultSet.getObject("ID_JUNCAO"));
				historicoCaso.setNomeJuncao(resultSet.getString("NOME_JUNCAO"));
				historicoCaso.setMotivo1((Integer) resultSet.getObject("MOTIVO_1"));
				historicoCaso.setMotivo1Nome(resultSet.getString("MOTIVO_1_NOME"));
				historicoCaso.setMotivo2((Integer) resultSet.getObject("MOTIVO_2"));
				historicoCaso.setMotivo2Nome(resultSet.getString("MOTIVO_2_NOME"));
				historicoCaso.setMotivo3((Integer) resultSet.getObject("MOTIVO_3"));
				historicoCaso.setMotivo3Nome(resultSet.getString("MOTIVO_3_NOME"));
				historicoCaso.setMotivo4((Integer) resultSet.getObject("MOTIVO_4"));
				historicoCaso.setMotivo4Nome(resultSet.getString("MOTIVO_4_NOME"));
				historicoCaso.setMotivo5((Integer) resultSet.getObject("MOTIVO_5"));
				historicoCaso.setMotivo5Nome(resultSet.getString("MOTIVO_5_NOME"));
				historicoCaso.setMotivo6((Integer) resultSet.getObject("MOTIVO_6"));
				historicoCaso.setMotivo6Nome(resultSet.getString("MOTIVO_6_NOME"));
				historicoCaso.setFlagCriadoManual(resultSet.getBoolean("FLAG_CRIADO_MANUAL"));
				historicoCaso.setIdOperacao((Integer) resultSet.getObject("ID_OPERACAO"));
				historicoCaso.setNomeOperacao(resultSet.getString("NOME_OPERACAO"));
				historicoCaso.setDataPrevistaFimSla(resultSet.getTimestamp("DATA_PREVISTA_FIM_SLA"));
				historicoCaso.setIdCasoPai((Integer) resultSet.getObject("ID_CASO_PAI"));
				historicoCaso.setDescricaoCaso(resultSet.getString("DESCRICAO_CASO"));
				historicoCaso.setDataAlteracao(resultSet.getTimestamp("DATA_ALTERACAO"));
				historicoCaso.setIdImportCaso((Integer) resultSet.getObject("ID_IMPORT_CASO"));
				historicoCaso.setDataAberturaCaso(resultSet.getTimestamp("DATA_ABERTURA_CASO"));
				historicoCaso.setDataAberturaLogSla(resultSet.getTimestamp("DATA_ABERTURA_LOG_SLA"));
				historicoCaso.setIdSlaFilaLogSla((Integer) resultSet.getObject("ID_SLA_FILA_LOG_SLA"));
				historicoCaso.setIdSlaCaso((Integer) resultSet.getObject("ID_SLA_CASO"));
				historicoCaso.setSlaCaso((Integer) resultSet.getObject("SLA_CASO"));
				historicoCaso.setDataInicioAcao((Date) resultSet.getObject("DATA_INICIO_ACAO"));
				historicoCaso.setDataFimAcao((Date) resultSet.getObject("DATA_FIM_ACAO"));
				historicoCaso.setIdUsuarioSupervisor((Integer) resultSet.getInt("ID_USUARIO_SUPERVISOR"));
				historicoCaso.setNomeUsuarioSupervisor(resultSet.getString("NOME_USUARIO_SUPERVISOR"));

				if (historicoCaso.getDataInicioAcao() == null) {
					historicoCaso.setDataInicioAcao(historicoCaso.getDataLog());
				}

				if (StringUtils.isBlank(historicoCaso.getLoginUsuario())) {
					historicoCaso.setDataFimAcao(historicoCaso.getDataInicioAcao());

				} else if (historicoCaso.getDataFimAcao() == null) {
					historicoCaso.setDataFimAcao(historicoCaso.getDataLog());
				}

				if (camposDinamicos != null && !camposDinamicos.isEmpty()) {

					List<CampoDinamicoTO> listCampoDinamicoTOs = new ArrayList<CampoDinamicoTO>();
					Object valor = null;
					for (int x = 0; x < camposDinamicos.size(); x++) {
						CampoDinamicoTO campoDinamicoTO = new CampoDinamicoTO(camposDinamicos.get(x));

						valor = populaValorCampoDinamicoPorTipo(camposDinamicos.get(x), resultSet);
						campoDinamicoTO.setValor(valor);
						listCampoDinamicoTOs.add(campoDinamicoTO);
					}
					historicoCaso.setCamposDinamicos(listCampoDinamicoTOs);
				} else {

					historicoCaso.setCamposDinamicos(camposDinamicos);
				}

				ret.add(historicoCaso);
			}
		}
		return ret;
	}

	public List<CampoDinamicoTO> buscaCamposDinamicos(Integer idOperacao) throws Exception {
		List<CampoDinamicoTO> result = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;

		StringBuilder sql = new StringBuilder();
		sql.append(" select ");
		sql.append(" 	cd.id_campo_dinamico as ID_CAMPO_DINAMICO, ");
		sql.append(" 	cd.data_criacao as DATA_CRIACAO, ");
		sql.append(" 	cd.tipo_campo as TIPO_CAMPO, ");
		sql.append(" 	cd.size_campo as SIZE_CAMPO, ");
		sql.append(" 	CASE WHEN LTRIM(RTRIM(ocd.label)) IS NOT NULL THEN ocd.label ");
		sql.append(" 	     ELSE cd.nome ");
		sql.append(" 	END AS LABEL, ");
		sql.append(" 	cd.nome_coluna as NOME_COLUNA, ");
		sql.append(" 	cd.chave as CHAVE, ");
		sql.append(" 	cd.flag_ativo as FLAG_ATIVO, ");
		sql.append(" 	cd.flag_exportar_valor_real as FLAG_EXPORTAR_VALOR_REAL, ");
		sql.append(" 	cd.separador_valor as SEPERADOR_VALOR, ");
		sql.append(" 	cd.separador_campo as SEPARADOR_CAMPO, ");
		sql.append(" 	cd.mascara as mascara, ");
		sql.append(" 	cd.flag_mascara_todos_caracteres as flagMascaraTodosChar ");
		sql.append(" from tb_campo_dinamico cd with(nolock) ");
		sql.append(" inner join tb_operacao_campo_dinamico ocd with(nolock) on cd.id_campo_dinamico = ocd.id_campo_dinamico ");
		sql.append(" where ocd.id_operacao = ? ");

		try {
			stmt = getPreparedStatement(sql.toString());

			stmt.setInt(1, idOperacao);
			stmt.execute();
			resultSet = stmt.getResultSet();
			result = processaResultSetCamposDinamicos(resultSet);
		} catch (Exception e) {
			throw new Exception("Erro ao buscar campos dinamicos.", e);
		} finally {
			super.closeConnection();
		}
		return result;
	}

	private List<CampoDinamicoTO> processaResultSetCamposDinamicos(ResultSet resultSet) throws Exception {
		List<CampoDinamicoTO> campos = new ArrayList<CampoDinamicoTO>();
		if (resultSet != null) {
			while (resultSet.next()) {
				CampoDinamicoTO campo = new CampoDinamicoTO();
				campo.setIdCampoDinamico((Integer) resultSet.getObject("ID_CAMPO_DINAMICO"));
				campo.setDataCriacao(resultSet.getTimestamp("DATA_CRIACAO"));
				campo.setTipoCampo(TipoCampoDinamico.valueOf(resultSet.getString("TIPO_CAMPO")));
				campo.setSizeCampo((Integer) resultSet.getObject("SIZE_CAMPO"));
				campo.setLabel(resultSet.getString("LABEL"));
				campo.setNomeColuna(resultSet.getString("NOME_COLUNA"));
				campo.setChave(resultSet.getString("CHAVE"));
				campo.setFlagAtivo(resultSet.getBoolean("FLAG_ATIVO"));
				campo.setFlagExportarValorReal(resultSet.getBoolean("FLAG_EXPORTAR_VALOR_REAL"));
				campo.setSeparadorCampo(resultSet.getString("SEPARADOR_CAMPO"));
				campo.setSeparadorValor(resultSet.getString("SEPERADOR_VALOR"));
				campo.setMascara(resultSet.getString("mascara"));
				campo.setFlagMascaraTodosCaracteres(resultSet.getBoolean("flagMascaraTodosChar"));
				campos.add(campo);
			}
		}
		return campos;
	}

	public void buscaValoresCamposDinamicosListaCaso(RelatorioHistoricoCasoTO historicoCaso) throws Exception {
		try {
			if (CollectionUtils.hasValue(historicoCaso.getCamposDinamicos())) {
				PreparedStatement stmt = null;
				ResultSet resultSet = null;

				for (CampoDinamicoTO campo : historicoCaso.getCamposDinamicos()) {
					if ((TipoCampoDinamico.LISTA_UNICA.equals(campo.getTipoCampo()) || TipoCampoDinamico.LISTA_MULTIPLA.equals(campo.getTipoCampo())) && campo.getValor() != null) {

						StringBuilder sql = new StringBuilder();
						sql.append(" select cd.valor as valor, cd.id_externo as id");
						sql.append(" from tb_caso_detalhe caso with(nolock) ");
						sql.append(" , tb_grupo_campo_dominio gcd with(nolock) ");
						sql.append(" , tb_campo_dominio_selecionado cds with(nolock) ");
						sql.append(" , tb_campo_dominio cd with(nolock) ");
						sql.append(MessageFormat.format(" where caso.{0} = gcd.id_grupo_campo_dominio ", campo.getNomeColuna()));
						sql.append(" and gcd.id_grupo_campo_dominio = cds.id_grupo_campo_dominio ");
						sql.append(" and cds.id_campo_dominio = cd.id_campo_dominio ");
						sql.append(" and caso.id_caso = ? ");

						stmt = getPreparedStatement(sql.toString());
						stmt.setInt(1, historicoCaso.getIdCaso());
						stmt.execute();
						resultSet = stmt.getResultSet();

						if (resultSet != null) {
							StringBuilder valor = new StringBuilder();

							while (resultSet.next()) {
								valor.append(resultSet.getString("valor"));
								if (resultSet.getString("id") != null) {
									valor.append(campo.getSeparadorValor());
									valor.append(resultSet.getString("id"));
								}
								valor.append(campo.getSeparadorCampo());
							}
							if (valor != null && valor.lastIndexOf(campo.getSeparadorCampo()) > 0) {
								valor = valor.deleteCharAt(valor.lastIndexOf(campo.getSeparadorCampo()));
							}
							campo.setValor(valor.toString().isEmpty() ? null : valor.toString());
						}
					}
				}
			}
		} catch (Exception e) {
			throw new Exception("Erro ao buscar valores dos campos dinamicos lista.", e);
		} finally {
			super.closeConnection();
		}
	}

	private Object populaValorCampoDinamicoPorTipo(CampoDinamicoTO campo, ResultSet rs) throws Exception {
		switch (campo.getTipoCampo()) {
		case NUMERO:
			return (Integer) rs.getObject(campo.getNomeColuna());
		case MOEDA:
			return rs.getBigDecimal(campo.getNomeColuna());
		case BOOLEAN:
			return rs.getBoolean(campo.getNomeColuna());
		case DATA:
			return rs.getTimestamp(campo.getNomeColuna());
		default:
			return rs.getString(campo.getNomeColuna());
		}
	}

	public void persisteDadosNuvemHistoricoCaso(String schemaDb, List<RelatorioHistoricoCasoTO> dados) throws Exception {
		if (CollectionUtils.hasValue(dados)) {
			StringBuilder sql = new StringBuilder();
			RelatorioHistoricoCasoTO historicoCaso = null;
			Connection connection = null;
					
			try {
				sql.append(" insert into  ")
				        .append(schemaDb)
				        .append("..tb_historico_caso")
				        .append(" (id_log, id_caso, id_status, nome_status, data_log, descricao_log, id_grupo_anexo, nome_grupo_anexo, ")
						.append("  id_acao, nome_acao, id_configuracao_fila, nome_configuracao_fila, detalhe_log, id_usuario, ")
						.append("  login_usuario, nome_usuario, id_equipe, nome_equipe, id_sla_fila, sla, data_abertura, ")
						.append("  data_encerramento, data_cadastro, flag_classifica, flag_finalizado, id_externo, dafa_fim_sla, ")
						.append("  flag_em_atendimento, classificacao_count, flag_reaberto, flag_reclassifica_reabertura, ")
						.append("  id_lote_caso, flag_telefone_editado, edicao_telefone_count, id_causa, nome_causa, id_evento, ")
						.append("  nome_evento, id_tipo_caso, nome_tipo_caso, id_canal, nome_canal, id_outra_area, nome_outra_area, ")
						.append("  id_juncao, nome_juncao, motivo_1, motivo_1_nome, motivo_2, motivo_2_nome, motivo_3, motivo_3_nome, ")
						.append("  motivo_4, motivo_4_nome, motivo_5, motivo_5_nome, motivo_6, motivo_6_nome, flag_criado_manual, ")
						.append("  id_operacao, nome_operacao, data_prevista_fim_sla, id_caso_pai, descricao_caso, data_alteracao, ")
						.append("  id_import_caso, sla_minutos, sla_total, percentual_sla, data_insercao, data_inicio_acao, data_fim_acao, ")
						.append("  id_caso_detalhe, id_usuario_supervisor, nome_usuario_supervisor ");

				historicoCaso = dados.get(0);
				
				for (int x = 0; x < historicoCaso.getCamposDinamicos().size(); x++) {
					sql.append(", ").append(historicoCaso.getCamposDinamicos().get(x).getNomeColuna());
				}
				sql.append(") ");

				// 75 campos
				sql.append(" select ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ")
				   .append("  ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ")
				   .append("  ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?");

				for (int x = 1; x <= historicoCaso.getCamposDinamicos().size(); x++) {
					sql.append(", ?");
				}
				//sql.append(" where not exists (select 1 from tb_historico_caso where id_log = ? )");

				connection = getConnection();
				connection.setAutoCommit(false);
				
				PreparedStatement ps = connection.prepareStatement(sql.toString());
				ps.setFetchSize(dados.size());
				
				int count = 0;
				DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				
				for (int i = 0; i < dados.size(); i++) {
					historicoCaso = dados.get(i);
					
					setParametersToInsert(historicoCaso, df, ps);
					ps.addBatch();

					if (++count % BATCH_SIZE == 0) {
						ps.executeBatch();
						connection.commit();
					}
				}

				ps.executeBatch(); // insert remaining records
				connection.commit();

			} catch (Exception e) {
				if (connection != null && !connection.isClosed()) {
					connection.rollback();
				}
				throw new Exception("Erro ao inserir historico caso: SQL: "+sql.toString()+" - ID Historico: "+historicoCaso.getIdLog(),e);
			} finally {
				super.closeConnection();
			}
		}
	}

	private void setParametersToInsert(RelatorioHistoricoCasoTO historicoCaso, DateFormat df, PreparedStatement ps) throws SQLException, Exception {
		ps.setInt(1, historicoCaso.getIdLog());
		ps.setInt(2, historicoCaso.getIdCaso());
		ps.setInt(3, historicoCaso.getIdStatus());
		ps.setString(4, historicoCaso.getNomeStatus());
		ps.setString(5, df.format(historicoCaso.getDataLog()));
		if (historicoCaso.getDescricaoLog() != null) {
			ps.setString(6, historicoCaso.getDescricaoLog());
		} else {
			ps.setNull(6, Types.NULL);
		}
		if (historicoCaso.getIdGrupoAnexo() != null && historicoCaso.getIdGrupoAnexo() > 0) {
			ps.setInt(7, historicoCaso.getIdGrupoAnexo());
		} else {
			ps.setNull(7, Types.NULL);
		}
		if (historicoCaso.getNomeGrupoAnexo() != null) {
			ps.setString(8, historicoCaso.getNomeGrupoAnexo());
		} else {
			ps.setNull(8, Types.NULL);
		}
		if (historicoCaso.getIdAcao() != null && historicoCaso.getIdAcao() > 0) {
			ps.setInt(9, historicoCaso.getIdAcao());
		} else {
			ps.setNull(9, Types.NULL);
		}
		if (historicoCaso.getNomeAcao() != null) {
			ps.setString(10, historicoCaso.getNomeAcao());
		} else {
			ps.setNull(10, Types.NULL);
		}
		if (historicoCaso.getIdConfiguracaoFila() != null && historicoCaso.getIdConfiguracaoFila() > 0) {
			ps.setInt(11, historicoCaso.getIdConfiguracaoFila());
		} else {
			ps.setNull(11, Types.NULL);
		}
		if (historicoCaso.getNomeConfiguracaoFila() != null) {
			ps.setString(12, historicoCaso.getNomeConfiguracaoFila());
		} else {
			ps.setNull(12, Types.NULL);
		}
		if (historicoCaso.getDetalheLog() != null) {
			ps.setString(13, historicoCaso.getDetalheLog());
		} else {
			ps.setNull(13, Types.NULL);
		}
		if (historicoCaso.getIdUsuario() != null && historicoCaso.getIdUsuario() > 0) {
			ps.setInt(14, historicoCaso.getIdUsuario());
		} else {
			ps.setNull(14, Types.NULL);
		}
		if (historicoCaso.getLoginUsuario() != null) {
			ps.setString(15, historicoCaso.getLoginUsuario());
		} else {
			ps.setNull(15, Types.NULL);
		}
		if (historicoCaso.getNomeUsuario() != null) {
			ps.setString(16, historicoCaso.getNomeUsuario());
		} else {
			ps.setNull(16, Types.NULL);
		}
		if (historicoCaso.getIdEquipe() != null && historicoCaso.getIdEquipe() > 0) {
			ps.setInt(17, historicoCaso.getIdEquipe());
		} else {
			ps.setNull(17, Types.NULL);
		}
		if (historicoCaso.getNomeEquipe() != null) {
			ps.setString(18, historicoCaso.getNomeEquipe());
		} else {
			ps.setNull(18, Types.NULL);
		}
		if (historicoCaso.getIdSlaFila() != null && historicoCaso.getIdSlaFila() > 0) {
			ps.setInt(19, historicoCaso.getIdSlaFila());
		} else {
			ps.setNull(19, Types.NULL);
		}
		if (historicoCaso.getSla() != null) {
			ps.setInt(20, historicoCaso.getSla());
		} else {
			ps.setNull(20, Types.NULL);
		}
		if (historicoCaso.getDataAbertura() != null) {
			ps.setString(21, df.format(historicoCaso.getDataAbertura()));
		} else {
			ps.setNull(21, Types.NULL);
		}
		if (historicoCaso.getDataEncerramento() != null) {
			ps.setString(22, df.format(historicoCaso.getDataEncerramento()));
		} else {
			ps.setNull(22, Types.NULL);
		}
		if (historicoCaso.getDataCadastro() != null) {
			ps.setString(23, df.format(historicoCaso.getDataCadastro()));
		} else {
			ps.setNull(23, Types.NULL);
		}
		if (historicoCaso.getFlagClassifica() != null) {
			ps.setBoolean(24, historicoCaso.getFlagClassifica());
		} else {
			ps.setNull(24, Types.NULL);
		}
		if (historicoCaso.getFlagFinalizado() != null) {
			ps.setBoolean(25, historicoCaso.getFlagFinalizado());
		} else {
			ps.setNull(25, Types.NULL);
		}
		if (historicoCaso.getIdExterno() != null) {
			ps.setString(26, historicoCaso.getIdExterno());
		} else {
			ps.setNull(26, Types.NULL);
		}
		if (historicoCaso.getDataFimSla() != null) {
			ps.setString(27, df.format(historicoCaso.getDataFimSla()));
		} else {
			ps.setNull(27, Types.NULL);
		}
		if (historicoCaso.getFlagEmAtendimento() != null) {
			ps.setBoolean(28, historicoCaso.getFlagEmAtendimento());
		} else {
			ps.setNull(28, Types.NULL);
		}
		if (historicoCaso.getClassificacaoCount() != null) {
			ps.setInt(29, historicoCaso.getClassificacaoCount());
		} else {
			ps.setNull(29, Types.NULL);
		}
		if (historicoCaso.getFlagReaberto() != null) {
			ps.setBoolean(30, historicoCaso.getFlagReaberto());
		} else {
			ps.setNull(30, Types.NULL);
		}
		if (historicoCaso.getFlagReclassificaReabertura() != null) {
			ps.setBoolean(31, historicoCaso.getFlagReclassificaReabertura());
		} else {
			ps.setNull(31, Types.NULL);
		}
		if (historicoCaso.getIdLoteCaso() != null && historicoCaso.getIdLoteCaso() > 0) {
			ps.setInt(32, historicoCaso.getIdLoteCaso());
		} else {
			ps.setNull(32, Types.NULL);
		}
		if (historicoCaso.getFlagTelefoneEditado() != null) {
			ps.setBoolean(33, historicoCaso.getFlagTelefoneEditado());
		} else {
			ps.setNull(33, Types.NULL);
		}
		if (historicoCaso.getEdicaoTelefoneCount() != null) {
			ps.setInt(34, historicoCaso.getEdicaoTelefoneCount());
		} else {
			ps.setNull(34, Types.NULL);
		}
		if (historicoCaso.getIdCausa() != null && historicoCaso.getIdCausa() > 0) {
			ps.setInt(35, historicoCaso.getIdCausa());
		} else {
			ps.setNull(35, Types.NULL);
		}
		if (historicoCaso.getNomeCausa() != null) {
			ps.setString(36, historicoCaso.getNomeCausa());
		} else {
			ps.setNull(36, Types.NULL);
		}
		if (historicoCaso.getIdEvento() != null && historicoCaso.getIdEvento() > 0) {
			ps.setInt(37, historicoCaso.getIdEvento());
		} else {
			ps.setNull(37, Types.NULL);
		}
		if (historicoCaso.getNomeEvento() != null) {
			ps.setString(38, historicoCaso.getNomeEvento());
		} else {
			ps.setNull(38, Types.NULL);
		}
		if (historicoCaso.getIdTipoCaso() != null && historicoCaso.getIdTipoCaso() > 0) {
			ps.setInt(39, historicoCaso.getIdTipoCaso());
		} else {
			ps.setNull(39, Types.NULL);
		}
		if (historicoCaso.getNomeTipoCaso() != null) {
			ps.setString(40, historicoCaso.getNomeTipoCaso());
		} else {
			ps.setNull(40, Types.NULL);
		}
		if (historicoCaso.getIdCanal() != null && historicoCaso.getIdCanal() > 0) {
			ps.setInt(41, historicoCaso.getIdCanal());
		} else {
			ps.setNull(41, Types.NULL);
		}
		if (historicoCaso.getNomeCanal() != null) {
			ps.setString(42, historicoCaso.getNomeCanal());
		} else {
			ps.setNull(42, Types.NULL);
		}
		if (historicoCaso.getIdOutraArea() != null && historicoCaso.getIdOutraArea() > 0) {
			ps.setInt(43, historicoCaso.getIdOutraArea());
		} else {
			ps.setNull(43, Types.NULL);
		}
		if (historicoCaso.getNomeOutraArea() != null) {
			ps.setString(44, historicoCaso.getNomeOutraArea());
		} else {
			ps.setNull(44, Types.NULL);
		}
		if (historicoCaso.getIdJuncao() != null && historicoCaso.getIdJuncao() > 0) {
			ps.setInt(45, historicoCaso.getIdJuncao());
		} else {
			ps.setNull(45, Types.NULL);
		}
		if (historicoCaso.getNomeJuncao() != null) {
			ps.setString(46, historicoCaso.getNomeJuncao());
		} else {
			ps.setNull(46, Types.NULL);
		}
		if (historicoCaso.getMotivo1() != null && historicoCaso.getMotivo1() > 0) {
			ps.setInt(47, historicoCaso.getMotivo1());
		} else {
			ps.setNull(47, Types.NULL);
		}
		if (historicoCaso.getMotivo1Nome() != null) {
			ps.setString(48, historicoCaso.getMotivo1Nome());
		} else {
			ps.setNull(48, Types.NULL);
		}
		if (historicoCaso.getMotivo2() != null && historicoCaso.getMotivo2() > 0) {
			ps.setInt(49, historicoCaso.getMotivo2());
		} else {
			ps.setNull(49, Types.NULL);
		}
		if (historicoCaso.getMotivo2Nome() != null) {
			ps.setString(50, historicoCaso.getMotivo2Nome());
		} else {
			ps.setNull(50, Types.NULL);
		}
		if (historicoCaso.getMotivo3() != null && historicoCaso.getMotivo3() > 0) {
			ps.setInt(51, historicoCaso.getMotivo3());
		} else {
			ps.setNull(51, Types.NULL);
		}
		if (historicoCaso.getMotivo3Nome() != null) {
			ps.setString(52, historicoCaso.getMotivo3Nome());
		} else {
			ps.setNull(52, Types.NULL);
		}
		if (historicoCaso.getMotivo4() != null && historicoCaso.getMotivo4() > 0) {
			ps.setInt(53, historicoCaso.getMotivo4());
		} else {
			ps.setNull(53, Types.NULL);
		}
		if (historicoCaso.getMotivo4Nome() != null) {
			ps.setString(54, historicoCaso.getMotivo4Nome());
		} else {
			ps.setNull(54, Types.NULL);
		}
		if (historicoCaso.getMotivo5() != null && historicoCaso.getMotivo5() > 0) {
			ps.setInt(55, historicoCaso.getMotivo5());
		} else {
			ps.setNull(55, Types.NULL);
		}
		if (historicoCaso.getMotivo5Nome() != null) {
			ps.setString(56, historicoCaso.getMotivo5Nome());
		} else {
			ps.setNull(56, Types.NULL);
		}
		if (historicoCaso.getMotivo6() != null && historicoCaso.getMotivo6() > 0) {
			ps.setInt(57, historicoCaso.getMotivo6());
		} else {
			ps.setNull(57, Types.NULL);
		}
		if (historicoCaso.getMotivo6Nome() != null) {
			ps.setString(58, historicoCaso.getMotivo6Nome());
		} else {
			ps.setNull(58, Types.NULL);
		}
		if (historicoCaso.getFlagCriadoManual() != null) {
			ps.setBoolean(59, historicoCaso.getFlagCriadoManual());
		} else {
			ps.setNull(59, Types.NULL);
		}
		ps.setInt(60, historicoCaso.getIdOperacao());
		ps.setString(61, historicoCaso.getNomeOperacao());
		if (historicoCaso.getDataPrevistaFimSla() != null) {
			ps.setString(62, df.format(historicoCaso.getDataPrevistaFimSla()));
		} else {
			ps.setNull(62, Types.NULL);
		}
		if (historicoCaso.getIdCasoPai() != null && historicoCaso.getIdCasoPai() > 0) {
			ps.setInt(63, historicoCaso.getIdCasoPai());
		} else {
			ps.setNull(63, Types.NULL);
		}
		if (historicoCaso.getDescricaoCaso() != null) {
			ps.setString(64, historicoCaso.getDescricaoCaso());
		} else {
			ps.setNull(64, Types.NULL);
		}
		if (historicoCaso.getDataAlteracao() != null) {
			ps.setString(65, df.format(historicoCaso.getDataAlteracao()));
		} else {
			ps.setNull(65, Types.NULL);
		}
		if (historicoCaso.getIdImportCaso() != null && historicoCaso.getIdImportCaso() > 0) {
			ps.setInt(66, historicoCaso.getIdImportCaso());
		} else {
			ps.setNull(66, Types.NULL);
		}
		if (historicoCaso.getSlaMinutos() != null) {
			ps.setString(67, historicoCaso.getSlaMinutos());
		} else {
			ps.setNull(67, Types.NULL);
		}
		if (historicoCaso.getSlaTotal() != null) {
			ps.setString(68, historicoCaso.getSlaTotal());
		} else {
			ps.setNull(68, Types.NULL);
		}
		if (historicoCaso.getPercentualSla() != null) {
			ps.setDouble(69, historicoCaso.getPercentualSla());
		} else {
			ps.setNull(69, Types.NULL);
		}
		ps.setString(70, df.format(historicoCaso.getDataInsercao()));

		if (historicoCaso.getDataInicioAcao() != null) {
			ps.setString(71, df.format(historicoCaso.getDataInicioAcao()));
		} else {
			ps.setNull(71, Types.NULL);
		}
		if (historicoCaso.getDataFimAcao() != null) {
			ps.setString(72, df.format(historicoCaso.getDataFimAcao()));
		} else {
			ps.setNull(72, Types.NULL);
		}

		if (historicoCaso.getIdCasoDetalhe() != null && historicoCaso.getIdCasoDetalhe() > 0) {
			ps.setInt(73, historicoCaso.getIdCasoDetalhe());
		} else {
			ps.setNull(73, Types.NULL);
		}
		if (historicoCaso.getIdUsuarioSupervisor() != null && historicoCaso.getIdUsuarioSupervisor() > 0) {
			ps.setInt(74, historicoCaso.getIdUsuarioSupervisor());
		} else {
			ps.setNull(74, Types.NULL);
		}
		if (historicoCaso.getNomeUsuarioSupervisor() != null) {
			ps.setString(75, historicoCaso.getNomeUsuarioSupervisor());
		} else {
			ps.setNull(75, Types.NULL);
		}

		int index = 76;

		for (int x = 0; x < historicoCaso.getCamposDinamicos().size(); x++) {
			CampoDinamicoTO campo = historicoCaso.getCamposDinamicos().get(x);

			if (campo.getValor() != null) {
				switch (campo.getTipoCampo()) {
				case NUMERO:
					ps.setInt(index, Integer.valueOf(campo.getValor().toString()));
					break;
				case MOEDA:
					ps.setBigDecimal(index, BigDecimal.valueOf(Double.valueOf(campo.getValor().toString())));
					break;
				case BOOLEAN:
					ps.setBoolean(index, Boolean.valueOf(campo.getValor().toString()));
					break;
				case DATA:
					try {
						ps.setString(index, campo.getValor().toString());
					} catch (Exception e) {
						try {
							ps.setNull(index, Types.NULL);

							logger.log(Level.SEVERE, "Mess " + e.getMessage());

							logger.log(Level.SEVERE, "id Caso " + historicoCaso.getIdCaso());
							logger.log(Level.SEVERE, "valor " + campo.getValor());
							logger.log(Level.SEVERE, "id campo " + campo.getIdCampoDinamico());

							try {
								logger.log(Level.SEVERE, "timestamp " + ((Timestamp) campo.getValor()).toString());
							} catch (Exception ex) {
								logger.log(Level.SEVERE, "Mess 1 " + ex.getMessage());
							}
						} catch (Exception ex) {
							logger.log(Level.SEVERE, "Mess 2 " + ex.getMessage());
						}

						throw e;
					}
					break;
				default:
					ps.setString(index, (String) campo.getValor());
					break;
				}
			} else {
				ps.setNull(index, Types.NULL);
			}
			index++;
		}
		
		//ps.setInt(index, historicoCaso.getIdLog());
	}

	public void persisteCampoTabela(RelatorioHistoricoCasoTO historico, String schemaDB) throws Exception {
		try {

			if (historico != null && !historico.getCamposDinamicos().isEmpty()) {

				for (CampoDinamicoTO to : historico.getCamposDinamicos()) {

					if (to.getTipoCampo().equals(TipoCampoDinamico.TABELA)) {

						PreparedStatement ps = super.getPreparedStatement(QUERY_CAMPO_TABELA.replace("DB_CAD_REPORT", schemaDB));

						ps.setInt(1, historico.getIdCaso());
						ps.setInt(2, to.getIdCampoDinamico());
						int rows = ps.executeUpdate();

						if (rows > 0) {
							
							PreparedStatement psAssociacao = super.getPreparedStatement(QUERY_CAMPO_TABELA_ASSOCIACAO.replace("DB_CAD_REPORT", schemaDB));
							
							psAssociacao.setInt(1, to.getIdCampoDinamico());
							psAssociacao.setInt(2, to.getIdCampoDinamico());
							psAssociacao.execute();
						}
					}

				}

			}

		} catch (Exception e) {
			logger.severe("=> DAO - Erro gerar nuvem de dados campo tabela" + e.getMessage());
			throw new Exception(e);
		} finally {
			super.closeConnection();
		}
		
	}
	public String buscaParametroOperacao(String mnemonico) throws Exception {
		try {
			PreparedStatement ps =
					super.getPreparedStatement("select valor as valorParametro from tb_parametro_sistema with(nolock) where nome = ? ");
			ps.setString(1, mnemonico);
			ResultSet rs = ps.executeQuery();
			
			if (rs.next()) {
				return rs.getString("valorParametro");
			}

			throw new Exception(MessageFormat.format("Parametro {0} não encontrado", mnemonico));
		} finally {
			super.closeConnection();
		}
	}
	
	public void insereCasosDeletados(Integer idOperacao, String schemaDB, Date dataExecucao) throws Exception {
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			StringBuilder str = new StringBuilder();
			str.append(" insert into DB_CAD_REPORT..tb_caso_deletado ")
			.append(" select cd.id_caso_deletado, cd.id_caso, cd.id_externo, cd.data_cadastro, cd.id_lote_caso, cd.data_exclusao, cd.id_usuario_exclusao, cd.id_operacao ")
			.append(" from tb_caso_deletado cd with(nolock) ")
			.append(" where cd.data_exclusao >= '").append(df.format(dataExecucao)).append("' ")
			.append(" and not exists (select 1 from DB_CAD_REPORT..tb_caso_deletado cd1 with(nolock) where cd.id_caso = cd1.id_caso and cd1.id_operacao = ").append(idOperacao).append(") ")
			.append(" and cd.id_operacao = ").append(idOperacao);
			
			PreparedStatement ps = super.getPreparedStatement(str.toString().replace("DB_CAD_REPORT", schemaDB));
			ps.execute();
			
		} catch (Exception e) {
			throw new Exception("Erro ao inserir casos deletados. Operacao: "+idOperacao+" - SchemaDB: "+schemaDB+" - Data: "+df.format(dataExecucao),e);
		} finally {
			super.closeConnection();
		}
	}
	
	/**
	 * Insere a estrutura de campos dinamicos no sistema CAD
	 * @param idOperacao
	 * @param schemaDB
	 * @throws Exception
	 */
	public void insereEstruturaCampoDinamico(Integer idOperacao, String schemaDB) throws Exception {
		try {
			
			// insere campos que não existem na base report
			StringBuilder str = new StringBuilder();
			str.append("INSERT INTO DB_CAD_REPORT..TB_CAMPO_DINAMICO ")
			.append(" SELECT CASE WHEN LTRIM(RTRIM(cmop.label)) IS NOT NULL THEN cmop.label ")
			.append(" 	 ELSE campo.nome ")
			.append(" END, ")
			.append(" campo.nome_coluna, getDate(), cmop.id_operacao  ")
			.append(" FROM tb_campo_dinamico campo with(nolock), tb_operacao_campo_dinamico cmop with(nolock) ")
			.append(" where campo.id_campo_dinamico = cmop.id_campo_dinamico ")
			.append(" and cmop.id_operacao = ?")
			.append(" and CAST(cmop.id_operacao as varchar(100)) + campo.nome_coluna not in  ")
			.append(" (select CAST(tcd.id_operacao as varchar(100)) + tcd.nome_coluna from DB_CAD_REPORT..TB_CAMPO_DINAMICO tcd with(nolock) ) ")
			.append(" order by cmop.id_operacao");
			
			PreparedStatement ps = super.getPreparedStatement(str.toString().replace("DB_CAD_REPORT", schemaDB));
			ps.setInt(1, idOperacao);
			ps.execute();
			
			// atualiza labels que existem na base report
			str = new StringBuilder();
			str.append("UPDATE rptCampo ")
			.append(" SET rptCampo.label = (SELECT CASE WHEN LTRIM(RTRIM(cmop.label)) IS NOT NULL THEN cmop.label ")
			.append(" 	 ELSE campo.nome ")
			.append(" END ")
			.append(" FROM tb_campo_dinamico campo with(nolock) ")
			.append(" LEFT JOIN tb_operacao_campo_dinamico cmop with(nolock) ON campo.id_campo_dinamico = cmop.id_campo_dinamico ")
			.append(" where CAST(cmop.id_operacao as varchar(100)) + campo.nome_coluna = CAST(rptCampo.id_operacao  as varchar(100)) + rptCampo.nome_coluna )  ")
			.append("FROM DB_CAD_REPORT..TB_CAMPO_DINAMICO rptCampo with(nolock) ")
			.append("WHERE rptCampo.id_operacao = ? ");
			
			ps = super.getPreparedStatement(str.toString().replace("DB_CAD_REPORT", schemaDB));
			ps.setInt(1, idOperacao);
			ps.execute();
			
		} catch (Exception e) {
			throw new Exception("Erro ao inserir estrutura dos campos dinamicos. Operacao: "+idOperacao+" - SchemaDB: "+schemaDB,e);
		} finally {
			super.closeConnection();
		}
	}
	
}
