package br.com.callink.cad.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import br.com.callink.cad.to.RelatorioRespostaEnqueteTO;
import br.com.callink.cad.util.HintNumberRows;

public class RelatorioRespostaCheckListDAO extends GenericDAO {

	/**
	 * Retirar duplicidade caso seja executado no mesmo dia
	 * 
	 * @param idOperacao
	 * @param qtdDiasExpurgo
	 * @param dataAtual
	 * @throws Exception
	 */
	public void executaExpurgoDados(String schemaDb, Integer idOperacao, Integer qtdDiasExpurgo, Date dataAtual, Integer qtdRegistrosExpurgoPorVez) throws Exception {
		try {
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			StringBuilder sql = new StringBuilder();
			
			sql.append(" delete top (").append(qtdRegistrosExpurgoPorVez).append(") ")
			   .append(" from  ")
			   .append(schemaDb)
			   .append("..tb_resposta_checklist")
			   .append(" where id_operacao = ? ")
			   .append("   and data_insercao < DATEADD(dd, - ?, ?) ");

			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ps.setInt(1, idOperacao);
			ps.setInt(2, qtdDiasExpurgo);
			ps.setString(3, df.format(dataAtual));
			
			int countDelete = ps.executeUpdate();
			
			while (countDelete > 0) {
				countDelete = ps.executeUpdate();
			}
		} finally {
			super.closeConnection();
		}
	}

	/**
	 * Captura dados para gerar inserções
	 * 
	 * @param idOperacao
	 * @param dataInicio
	 * @param dataFim
	 * @return
	 * @throws Exception
	 */
	public List<RelatorioRespostaEnqueteTO> geraNuvemCheckListPeriodo(Integer idOperacao, Date dataInicio, Date dataFim) throws Exception {
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		List<RelatorioRespostaEnqueteTO> result = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;

		StringBuilder sbr = new StringBuilder();
		sbr.append("  select  ");
		sbr.append("    ca.id_externo as MANIFESTACAO,  ");
		sbr.append("    tc.id_tipo_caso as ID_TIPO_MANIFESTACAO,  ");
		sbr.append("    tc.nome AS NOME_MANIFESTACAO,  ");
		sbr.append("    tcf.id_configuracao_fila AS ID_FILA,  ");
		sbr.append("    tcf.descricao AS DESCRICAO_FILA,  ");
		sbr.append("    trq.data_resposta AS DATA_RESPOSTA,  ");
		sbr.append("    trq.login AS USUARIO,  ");
		sbr.append("    tqs.id_checklist AS ID_CHECKLIST,  ");
		sbr.append("    tqs.descricao AS DESCRICAO_CHECKLIST,  ");
		sbr.append("    qq.id_check AS ID_CHECK,  ");
		sbr.append("    qq.descricao AS DESCRICAO_CHECK,  ");
		sbr.append("    tr.id_resposta_checklist AS ID_RESPOSTA,  ");
		sbr.append("    tr.resposta AS RESPOSTA,  ");
		sbr.append("    tu.nome AS NOME  ");
		sbr.append(" from tb_caso ca with(nolock),  ");
		sbr.append("    tb_resultado_checklist trq with(nolock),  ");
		sbr.append("    tb_resposta_checklist tr with(nolock),  ");
		sbr.append("    tb_tipo_caso tc with(nolock),  ");
		sbr.append("    tb_check qq with(nolock),  ");
		sbr.append("    tb_checklist tqs with(nolock),  ");
		sbr.append("    tb_configuracao_fila tcf with(nolock),  ");
		sbr.append("    tb_usuario tu with(nolock)  ");
		sbr.append(" where ca.id_caso = trq.id_externo  ");
		sbr.append("   and ca.id_configuracao_fila =  tcf.id_configuracao_fila  ");
		sbr.append("   and ca.id_tipo_caso = tc.id_tipo_caso  ");
		sbr.append("   and tr.id_resultado_checklist = trq.id_resultado_checklist  ");
		sbr.append("   and trq.login = tu.login  ");
		sbr.append("   and tr.id_check = qq.id_check  ");
		sbr.append("   and qq.id_checklist = tqs.id_checklist  ");
		sbr.append("   and ca.id_operacao = ? ");
		sbr.append("   and trq.data_resposta BETWEEN '").append(df.format(dataInicio)).append("' AND '").append(df.format(dataFim)).append("'");

		try {
			stmt = getPreparedStatement(sbr.toString(), HintNumberRows.ROWS_CASO.getRows());

			stmt.setInt(1, idOperacao);

			stmt.execute();
			resultSet = stmt.getResultSet();
			result = processaResultSet(resultSet);
		} finally {
			super.closeConnection();
		}
		return result;
	}

	/**
	 * Parse para objeto TO
	 * 
	 * @param resultSet
	 * @return
	 * @throws Exception
	 */
	private List<RelatorioRespostaEnqueteTO> processaResultSet(ResultSet resultSet) throws Exception {
		List<RelatorioRespostaEnqueteTO> ret = new ArrayList<RelatorioRespostaEnqueteTO>();
		if (resultSet != null) {
			while (resultSet.next()) {
				RelatorioRespostaEnqueteTO enquete = new RelatorioRespostaEnqueteTO();
				enquete.setDataRegistroEnquete(resultSet.getTimestamp("DATA_RESPOSTA"));
				enquete.setDescricaoEnquete(resultSet.getString("DESCRICAO_CHECKLIST"));
				enquete.setDescricaoQuestao(resultSet.getString("DESCRICAO_CHECK"));
				enquete.setIdResposta(resultSet.getInt("ID_RESPOSTA"));
				enquete.setDescricaoResposta(resultSet.getString("RESPOSTA"));
				enquete.setFilaTratamento(resultSet.getString("DESCRICAO_FILA"));
				enquete.setIdEnquete(resultSet.getInt("ID_CHECKLIST"));
				enquete.setIdFilaTratamento(resultSet.getInt("ID_FILA"));
				enquete.setIdQuestao(resultSet.getInt("ID_CHECK"));
				enquete.setIdTipoManifestacao(resultSet.getInt("ID_TIPO_MANIFESTACAO"));
				enquete.setLoginUsuario(resultSet.getString("USUARIO"));
				enquete.setManifestacao(resultSet.getString("MANIFESTACAO"));
				enquete.setTipoManifestacao(resultSet.getString("NOME_MANIFESTACAO"));
				enquete.setNomeUsuario(resultSet.getString("NOME"));
				ret.add(enquete);
			}
		}
		return ret;
	}

	/**
	 * Insere dados do checklist
	 * 
	 * @param enqueteTO
	 * @throws Exception
	 */
	public void persisteDadosNuvemCheckList(String schemaDb, RelatorioRespostaEnqueteTO enqueteTO) throws Exception {
		try {
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			StringBuilder sql = new StringBuilder();
			sql.append(" insert into  ")
			        .append(schemaDb)
			        .append("..tb_resposta_checklist")
			        .append(" (manifestacao, id_tipo_manifestacao, tipo_manifestacao, id_fila_tratamento, fila_tratamento, data_registro_checklist, ")
			        .append("  login_usuario, id_checklist, descricao_checklist, id_check, descricao_check, descricao_resposta, ")
			        .append("  id_resposta, nome_usuario, id_operacao, data_insercao) ")
			        .append(" values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ");

			PreparedStatement ps = super.getPreparedStatement(sql.toString());

			ps.setString(1, enqueteTO.getManifestacao());
			ps.setInt(2, enqueteTO.getIdTipoManifestacao());
			ps.setString(3, enqueteTO.getTipoManifestacao());
			ps.setInt(4, enqueteTO.getIdFilaTratamento());
			ps.setString(5, enqueteTO.getFilaTratamento());
			ps.setString(6, df.format(enqueteTO.getDataRegistroEnquete()));
			ps.setString(7, enqueteTO.getLoginUsuario());
			ps.setInt(8, enqueteTO.getIdEnquete());
			ps.setString(9, enqueteTO.getDescricaoEnquete());
			ps.setInt(10, enqueteTO.getIdQuestao());
			ps.setString(11, enqueteTO.getDescricaoQuestao());
			ps.setString(12, enqueteTO.getDescricaoResposta());
			ps.setInt(13, enqueteTO.getIdResposta());
			ps.setString(14, enqueteTO.getNomeUsuario());
			ps.setInt(15, enqueteTO.getIdOperacao());
			ps.setString(16, df.format(enqueteTO.getDataInsercao()));

			ps.executeUpdate();

		} finally {
			super.closeConnection();
		}
	}

}
