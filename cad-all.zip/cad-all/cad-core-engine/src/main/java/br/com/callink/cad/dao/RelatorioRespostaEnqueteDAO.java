package br.com.callink.cad.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import br.com.callink.cad.to.RelatorioRespostaEnqueteTO;
import br.com.callink.cad.util.HintNumberRows;

public class RelatorioRespostaEnqueteDAO extends GenericDAO {

	public void executaExpurgoDados(String schemaDb, Integer idOperacao, Integer qtdDiasExpurgo, Date dataAtual, Integer qtdRegistrosExpurgoPorVez) throws Exception {
		try {
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			StringBuilder sql = new StringBuilder();
			
			sql.append(" delete top (").append(qtdRegistrosExpurgoPorVez).append(") ")
			   .append(" from ")
			   .append(schemaDb)
			   .append("..tb_resposta_enquete")
			   .append(" where id_operacao = ? ")
			   .append("   and data_insercao < DATEADD(dd, - ?, ?) ");
			
			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ps.setInt(1, idOperacao);
			ps.setInt(2, qtdDiasExpurgo);
			ps.setString(3, df.format(dataAtual));

			int countDelete = ps.executeUpdate();
			
			while (countDelete > 0) {
				countDelete = ps.executeUpdate();
			}
		} finally {
			super.closeConnection();
		}
	}
	
	public List<RelatorioRespostaEnqueteTO> geraNuvemEnquetesPeriodo(Integer idOperacao, Date dataInicio, Date dataFim) throws Exception {
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		List<RelatorioRespostaEnqueteTO> result = null;
    	PreparedStatement stmt = null;
    	ResultSet resultSet = null;
    	
    	StringBuilder sbr = new StringBuilder();
        sbr.append(" select ");
        sbr.append("	ca.id_externo as MANIFESTACAO, ");
        sbr.append("	tc.id_tipo_caso as ID_TIPO_MANIFESTACAO, ");
        sbr.append("	tc.nome AS NOME_MANIFESTACAO, ");
        sbr.append("	tcf.id_configuracao_fila AS ID_FILA, ");
        sbr.append("	tcf.descricao AS DESCRICAO_FILA, ");
        sbr.append("	trq.data_resposta AS DATA_RESPOSTA, ");
        sbr.append("	trq.login AS USUARIO, ");
        sbr.append("	tqs.id_questionario AS ID_QUESTIONARIO, ");
        sbr.append("	tqs.descricao AS DESCRICAO_QUESTIONARIO, ");
        sbr.append("	qq.id_questao AS ID_QUESTAO, ");
        sbr.append("	qq.descricao AS DESCRICAO_QUESTAO, ");
        sbr.append("	tr.id_resposta AS ID_RESPOSTA, ");
        sbr.append("	tr.resposta AS RESPOSTA, ");
        sbr.append("	tu.nome AS NOME ");
        sbr.append(" from tb_caso ca with(nolock), ");
        sbr.append(" 	  tb_resultado_questionario trq with(nolock), ");
        sbr.append(" 	  tb_resposta tr with(nolock), ");
        sbr.append(" 	  tb_tipo_caso tc with(nolock), ");
        sbr.append("	  tb_questao qq with(nolock), ");
        sbr.append("	  tb_questionario tqs with(nolock), ");
        sbr.append("	  tb_configuracao_fila tcf with(nolock), ");
        sbr.append("	  tb_usuario tu with(nolock) ");
        sbr.append(" where ca.id_caso = trq.id_externo ");
        sbr.append("   and ca.id_configuracao_fila =  tcf.id_configuracao_fila ");
        sbr.append("   and ca.id_tipo_caso = tc.id_tipo_caso ");
        sbr.append("   and tr.id_resultado_questionario = trq.id_resultado_questionario ");
        sbr.append("   and trq.login = tu.login ");
        sbr.append("   and tr.id_questao = qq.id_questao ");
        sbr.append("   and qq.id_questionario = tqs.id_questionario ");
        sbr.append("   and ca.id_operacao = ? ");
        sbr.append("   and trq.data_resposta BETWEEN '").append(df.format(dataInicio)).append("' AND '").append(df.format(dataFim)).append("'");
        
        try {
        	stmt = getPreparedStatement(sbr.toString(), HintNumberRows.ROWS_CASO.getRows());
			
        	stmt.setInt(1, idOperacao);
        	
			stmt.execute();
			resultSet = stmt.getResultSet();
            result = processaResultSet(resultSet);
        } finally {
        	super.closeConnection();
		}
        return result;
    }
	
	private List<RelatorioRespostaEnqueteTO> processaResultSet(ResultSet resultSet) throws Exception {
        List<RelatorioRespostaEnqueteTO> ret = new ArrayList<RelatorioRespostaEnqueteTO>();
        if (resultSet != null) {
            while (resultSet.next()) {
                RelatorioRespostaEnqueteTO enquete = new RelatorioRespostaEnqueteTO();
                enquete.setDataRegistroEnquete(resultSet.getTimestamp("DATA_RESPOSTA"));
                enquete.setDescricaoEnquete(resultSet.getString("DESCRICAO_QUESTIONARIO"));
                enquete.setDescricaoQuestao(resultSet.getString("DESCRICAO_QUESTAO"));
                enquete.setIdResposta(resultSet.getInt("ID_RESPOSTA"));
                enquete.setDescricaoResposta(resultSet.getString("RESPOSTA"));
                enquete.setFilaTratamento(resultSet.getString("DESCRICAO_FILA"));
                enquete.setIdEnquete(resultSet.getInt("ID_QUESTIONARIO"));
                enquete.setIdFilaTratamento(resultSet.getInt("ID_FILA"));
                enquete.setIdQuestao(resultSet.getInt("ID_QUESTAO"));
                enquete.setIdTipoManifestacao(resultSet.getInt("ID_TIPO_MANIFESTACAO"));
                enquete.setLoginUsuario(resultSet.getString("USUARIO"));
                enquete.setManifestacao(resultSet.getString("MANIFESTACAO"));
                enquete.setTipoManifestacao(resultSet.getString("NOME_MANIFESTACAO"));
                enquete.setNomeUsuario(resultSet.getString("NOME"));
                ret.add(enquete);
            }
        }
        return ret;
    }
	
	public void persisteDadosNuvemEnquete(String schemaDb, RelatorioRespostaEnqueteTO enqueteTO) throws Exception {
		try {
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			StringBuilder sql = new StringBuilder();
			sql.append(" insert into ")
			   .append(schemaDb)
			   .append("..tb_resposta_enquete")
			   .append(" (manifestacao, id_tipo_manifestacao, tipo_manifestacao, id_fila_tratamento, fila_tratamento, data_registro_enquete, ")
			   .append("  login_usuario, id_enquete, descricao_enquete, id_questao, descricao_questao, descricao_resposta, ")
			   .append("  id_resposta, nome_usuario, id_operacao, data_insercao) ")
			   .append(" values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ");
			
			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			
			ps.setString(1, enqueteTO.getManifestacao());
			ps.setInt(2, enqueteTO.getIdTipoManifestacao());
			ps.setString(3, enqueteTO.getTipoManifestacao());
			ps.setInt(4, enqueteTO.getIdFilaTratamento());
			ps.setString(5, enqueteTO.getFilaTratamento());
			ps.setString(6, df.format(enqueteTO.getDataRegistroEnquete()));
			ps.setString(7, enqueteTO.getLoginUsuario());
			ps.setInt(8, enqueteTO.getIdEnquete());
			ps.setString(9, enqueteTO.getDescricaoEnquete());
			ps.setInt(10, enqueteTO.getIdQuestao());
			ps.setString(11, enqueteTO.getDescricaoQuestao());
			ps.setString(12, enqueteTO.getDescricaoResposta());
			ps.setInt(13, enqueteTO.getIdResposta());
			ps.setString(14, enqueteTO.getNomeUsuario());
			ps.setInt(15, enqueteTO.getIdOperacao());
			ps.setString(16, df.format(enqueteTO.getDataInsercao()));
			
			ps.executeUpdate();
			
		} finally {
			super.closeConnection();
		}
	}
	
}
