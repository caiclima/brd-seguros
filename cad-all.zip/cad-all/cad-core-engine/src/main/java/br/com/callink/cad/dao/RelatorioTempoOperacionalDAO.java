package br.com.callink.cad.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import br.com.callink.cad.to.RelatorioTempoOperacionalTO;

public class RelatorioTempoOperacionalDAO extends GenericDAO {

	public void executaExpurgoDados(String schemaDb, Integer idOperacao, Integer qtdDiasExpurgo, Date dataAtual, Integer qtdRegistrosExpurgoPorVez) throws Exception {
		try {
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			StringBuilder sql = new StringBuilder();
			
			sql.append("delete top (").append(qtdRegistrosExpurgoPorVez).append(") ")
			   .append(" from  ")
			   .append(schemaDb)
			   .append("..tb_tempos_operacionais")
			   .append(" where id_operacao = ? ")
			   .append("   and data_insercao < DATEADD(dd, - ?, ?) ");
			
			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ps.setInt(1, idOperacao);
			ps.setInt(2, qtdDiasExpurgo);
			ps.setString(3, df.format(dataAtual));
			
			int countDelete = ps.executeUpdate();
			
			while (countDelete > 0) {
				countDelete = ps.executeUpdate();
			}
		} finally {
			super.closeConnection();
		}
	}
	
	public List<RelatorioTempoOperacionalTO> geraNuvemTemposOperacionaisPeriodo(Integer idOperacao, Date dataInicio, Date dataFim) throws Exception {
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		List<RelatorioTempoOperacionalTO> result = null;
    	PreparedStatement stmt = null;
    	ResultSet resultSet = null;
    	
    	StringBuilder sbr = new StringBuilder();
        sbr.append(" select ");
        sbr.append("	u.login as LOGIN, ");
        sbr.append("	su.data_inicio as DATA_INICIO, ");
        sbr.append("	su.data_fim as DATA_FIM, ");
        sbr.append("	us.nome_status as STATUS_USUARIO, ");
        sbr.append("	u.nome as NOME_USUARIO ");
        sbr.append(" from tb_status_usuario su with(nolock) ");
        sbr.append("  inner join tb_usuario u with(nolock) ");
        sbr.append("   on u.id_usuario = su.id_usuario ");
        sbr.append("  inner join tb_usuario_status us with(nolock) ");
        sbr.append("   on us.id_usuario_status = su.id_usuario_status ");
        sbr.append("  inner join tb_operacao_usuario ou with(nolock) ");
        sbr.append("   on ou.id_usuario = su.id_usuario ");
        sbr.append("   and ou.flag_operacao_principal = 1 ");
        sbr.append("   and ou.id_operacao = ? ");
        sbr.append(" where su.data_fim BETWEEN '").append(df.format(dataInicio)).append("' AND '").append(df.format(dataFim)).append("'");
        
        try {
        	stmt = getPreparedStatement(sbr.toString());
			
        	stmt.setInt(1, idOperacao);
        	
			stmt.execute();
			resultSet = stmt.getResultSet();
            result = processaResultSet(resultSet);
        } finally {
        	super.closeConnection();
		}
        return result;
    }
	
	private List<RelatorioTempoOperacionalTO> processaResultSet(ResultSet resultSet) throws Exception {
        List<RelatorioTempoOperacionalTO> ret = new ArrayList<RelatorioTempoOperacionalTO>();
        if (resultSet != null) {
            while (resultSet.next()) {
            	RelatorioTempoOperacionalTO tempoOperacional = new RelatorioTempoOperacionalTO();
            	tempoOperacional.setLogin(resultSet.getString("LOGIN"));
            	tempoOperacional.setDataInicio(resultSet.getTimestamp("DATA_INICIO"));
            	tempoOperacional.setDataFim(resultSet.getTimestamp("DATA_FIM"));
            	tempoOperacional.setStatusUsuario(resultSet.getString("STATUS_USUARIO"));
            	tempoOperacional.setNomeUsuario(resultSet.getString("NOME_USUARIO"));
                ret.add(tempoOperacional);
            }
        }
        return ret;
    }
	
	public void persisteDadosNuvemTempoOperacional(String schemaDb, RelatorioTempoOperacionalTO tempoOperacionalTO) throws Exception {
		try {
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			StringBuilder sql = new StringBuilder();
			sql.append(" insert into  ")
				.append(schemaDb)
				.append("..tb_tempos_operacionais")
			   .append(" (login, data_inicio, data_fim, status_usuario, nome_usuario, id_operacao, data_insercao) ")
			   .append(" values (?, ?, ?, ?, ?, ?, ?) ");
			
			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			
			ps.setString(1, tempoOperacionalTO.getLogin());
			if (tempoOperacionalTO.getDataInicio() != null) {
				ps.setString(2, df.format(tempoOperacionalTO.getDataInicio()));
			} else {
				ps.setNull(2, Types.NULL);
			}
			if (tempoOperacionalTO.getDataFim() != null) {
				ps.setString(3, df.format(tempoOperacionalTO.getDataFim()));
			} else {
				ps.setNull(3, Types.NULL);
			}
			ps.setString(4, tempoOperacionalTO.getStatusUsuario());
			ps.setString(5, tempoOperacionalTO.getNomeUsuario());
			ps.setInt(6, tempoOperacionalTO.getIdOperacao());
			ps.setString(7, df.format(tempoOperacionalTO.getDataInsercao()));
			
			ps.executeUpdate();
			
		} finally {
			super.closeConnection();
		}
	}
	
}
