package br.com.callink.cad.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import br.com.callink.cad.to.AnexoTO;
import br.com.callink.cad.to.AtendimentoCasoTO;
import br.com.callink.cad.to.CasoTO;
import br.com.callink.cad.to.ConfiguracaoFilaTO;
import br.com.callink.cad.to.LogSlaCasoTO;
import br.com.callink.cad.to.LogTO;


public class RetiraCasoUsuarioDao extends GenericDAO {
	
	private Logger logger = Logger.getLogger(RetiraCasoUsuarioDao.class.getName());

	public void retiraCasoUsuariosInativos() throws Exception {
		try {
			StringBuilder sql = new StringBuilder().append(SELECT)
        	.append(ConfiguracaoFilaTO.getSqlCamposConfiguracaoFila())
        	.append(FROM)
            .append(ConfiguracaoFilaTO.getSqlFromConfiguracaoFila())
            .append(WHERE)
            .append(" ConfiguracaoFila.FLAG_BUILD = 1 ")
            .append(" AND ConfiguracaoFila.FLAG_ATIVO = 1 ")
            .append(" ORDER BY ConfiguracaoFila.ID_OPERACAO, ConfiguracaoFila.PRIORIDADE ");

			PreparedStatement stmt = super.getPreparedStatement(sql.toString());

			ResultSet rs = stmt.executeQuery();
			List<ConfiguracaoFilaTO> listRows = new ArrayList<ConfiguracaoFilaTO>();

			if (rs != null) {
				while (rs.next()) {
					ConfiguracaoFilaTO to = new ConfiguracaoFilaTO();
					
					to.setIdConfiguracaoFila((Integer)rs.getObject("ConfiguracaoFila.ID_CONFIGURACAO_FILA"));
					to.setFlagBuild(rs.getBoolean("ConfiguracaoFila.FLAG_BUILD"));
					to.setNome(rs.getString("ConfiguracaoFila.NOME"));

					listRows.add(to);
				}
			}

			logger.info("buscaCasoReclassificaReabertura. ");
		} finally {
			super.closeConnection();
		}
	}
	
	public List<CasoTO> buscaCasoEmAtendimento(Integer idOperacao) throws Exception {
		List<CasoTO> casoTOList = new ArrayList<CasoTO>();
		try {
			
			StringBuilder sql = new StringBuilder();
			sql.append(SELECT).append(" TOP 1000 ");
			sql.append(CasoTO.getSqlColuns());
			sql.append(CasoTO.getSqlFrom());
			sql.append(WHERE)
			.append(" Caso.FLAG_FINALIZADO = 0 AND Caso.flag_em_atendimento = 0 ")
			.append(" AND Caso.ID_USUARIO is not null AND ID_OPERACAO = ")
			.append(idOperacao)
			.append(" AND (Caso.FLAG_RECLASSIFICA_REABERTURA = 0 ")
			.append(" OR Caso.FLAG_RECLASSIFICA_REABERTURA is null)  ");

			PreparedStatement stmt = super.getPreparedStatement(sql.toString(), 1000);

			ResultSet resultSet = stmt.executeQuery();
			if (resultSet != null) {
				while (resultSet.next()) {
					casoTOList.add(CasoTO.getCasoTOByResultSet(resultSet));
				}
			}
			return casoTOList;
		} finally {
			super.closeConnection();
		}
	}
	
	public List<LogTO> buscaHistorioByCaso(Integer idCaso) throws Exception {
		List<LogTO> logTOList = new ArrayList<LogTO>();
		try {
			
			StringBuilder sql = new StringBuilder();
			sql.append(SELECT);
			sql.append(LogTO.getSqlCamposLog());
			sql.append(FROM);
			sql.append(LogTO.getSqlFromLog());
			sql.append(WHERE)
			.append(" Log.ID_CASO = ? order by Log.ID_LOG asc ");

			PreparedStatement stmt = super.getPreparedStatement(sql.toString());
			stmt.setInt(1, idCaso);

			ResultSet resultSet = stmt.executeQuery();
			if (resultSet != null) {
				while (resultSet.next()) {
					logTOList.add(LogTO.getLogByResultSet(resultSet));
				}
			}
			return logTOList;
		} finally {
			super.closeConnection();
		}
	}
	
	public List<LogSlaCasoTO> findLogSlaByCaso(Integer idCaso) throws Exception {
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		List<LogSlaCasoTO> list = null;
		try {
			StringBuilder sql = new StringBuilder(SELECT)
					.append(LogSlaCasoTO.getSqlCamposLogSlaCaso())
					.append(FROM)
					.append(LogSlaCasoTO.getSqlFromLogSlaCaso())
					.append(WHERE)
					.append(" LogSlaCaso.ID_CASO = ? ")
					.append(" ORDER BY LogSlaCaso.DATA_ABERTURA DESC ");
			
			stmt = getPreparedStatement(sql.toString());
			stmt.setInt(1, idCaso);
			stmt.execute();
			resultSet = stmt.getResultSet();
			list = new ArrayList<LogSlaCasoTO>();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					LogSlaCasoTO logSlaCaso = LogSlaCasoTO.getLogSlaCasoTOByResultSet(resultSet);
					list.add(logSlaCaso);
				}
			}
			return list;
			
		} finally {
			super.closeConnection();
		}
	}
	
	public void removeFilaClassificaoCaso(List<Integer> idCasos) throws Exception {
		
		try {
			for(Integer idCaso : idCasos){
				StringBuilder sql = 
						new StringBuilder("delete from tb_fila_classificacao_caso where id_caso = ?");
				
				PreparedStatement ps = super.getPreparedStatement(sql.toString());
				ps.setInt(1, idCaso);
				
				ps.executeUpdate();
			}
		} finally {
			super.closeConnection();
		}
	}
	
	public void insereLog(List<LogTO> logTOs) throws Exception {
		
		try {
			for(LogTO logTO : logTOs){
		        StringBuilder sql = new StringBuilder()
				.append(" INSERT INTO tb_log   ")
				.append(" (id_status,id_caso,data_log,descricao,id_grupo_anexo,id_acao,id_email,id_configuracao_fila,detalhe,id_usuario,data_abertura,id_sla_fila,id_evento)  ")
				.append(" VALUES ")
				.append(" (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) "); 
		        
		        PreparedStatement ps = super.getPreparedStatement(sql.toString());
		        
		        if(logTO.getIdStatus() != null) {
		        	ps.setInt(1, logTO.getIdStatus());
		        } else {
		        	ps.setNull(1, Types.NULL);
		        }
		        
		        if(logTO.getIdCaso() != null) {
		        	ps.setInt(2, logTO.getIdCaso());
		        } else {
		        	ps.setNull(2, Types.NULL);
		        }
		        
		        if(logTO.getDataLog() != null) {
		        	ps.setTimestamp(3, new Timestamp(logTO.getDataLog().getTime()));
		        } else {
		        	ps.setNull(3, Types.NULL);
		        }
		        
		        if(logTO.getDescricao() != null ) {
		        	ps.setString(4, logTO.getDescricao()); 
		        } else {
		        	ps.setNull(4, Types.NULL);
		        }
				
				if(logTO.getIdGrupoAnexo() != null) {
					ps.setInt(5, logTO.getIdGrupoAnexo());
				} else {
					ps.setNull(5, Types.NULL);
				}
				
				if(logTO.getIdAcao() != null) {
					ps.setInt(6, logTO.getIdAcao());
				} else {
					ps.setNull(6, Types.NULL);
				}
				
				if(logTO.getIdEmail() != null) {
					ps.setInt(7, logTO.getIdEmail());
				} else {
					ps.setNull(7, Types.NULL);
				}
				
				if(logTO.getIdConfiguracaoFila() != null) {
					ps.setInt(8, logTO.getIdConfiguracaoFila());
				} else {
					ps.setNull(8, Types.NULL);
				}
				
				if(logTO.getDetalhe() != null) {
					ps.setString(9, logTO.getDetalhe());
				} else {
					ps.setNull(9, Types.NULL);
				}
				
				if(logTO.getIdUsuario() != null) {
					ps.setInt(10, logTO.getIdUsuario());
				} else {
					ps.setNull(10, Types.NULL);
				}
				
		        if(logTO.getDataAbertura() != null) {
		        	ps.setTimestamp(11, new Timestamp(logTO.getDataAbertura().getTime()));
		        } else {
		        	ps.setNull(11, Types.NULL);
		        }
				
		        if(logTO.getIdSlaFila() != null) {
		        	ps.setInt(12, logTO.getIdSlaFila());
		        } else {
		        	ps.setNull(12, Types.NULL);
		        }
		        
		        if(logTO.getIdEvento() != null) {
		        	ps.setInt(13, logTO.getIdEvento());
		        } else {
		        	ps.setNull(13, Types.NULL);
		        }
		        
				ps.executeUpdate();
			}
		} finally {
			super.closeConnection();
		}
	}
	
	public void updateCaso(List<CasoTO> casoTOs) throws Exception {
		try {
			for(CasoTO casoTO : casoTOs){
				StringBuilder sql = new StringBuilder()
				.append(" update tb_caso ")
				.append(" set id_configuracao_fila = ?, flag_classifica = ?, id_usuario = ? ")
				.append(WHERE)
				.append(" id_caso = ? "); 
				
				PreparedStatement ps = super.getPreparedStatement(sql.toString());
				
				if(casoTO.getIdConfiguracaoFila() != null) {
					ps.setInt(1, casoTO.getIdConfiguracaoFila());
				} else {
					ps.setNull(1, Types.NULL);
				}
				
				ps.setBoolean(2, casoTO.isFlagClassifica());
				
				if(casoTO.getIdUsuario() != null) {
					ps.setInt(3, casoTO.getIdUsuario());
				} else {
					ps.setNull(3, Types.NULL);
				}
				
				ps.setInt(4, casoTO.getIdCaso());
				
				ps.executeUpdate();
			}
		} finally {
			super.closeConnection();
		}
	}
	
	
	public void insereAtendimentoCaso(List<AtendimentoCasoTO> atendimentoCasos) throws Exception {
		
		try {
			for(AtendimentoCasoTO atendimentoCaso : atendimentoCasos){
		        StringBuilder sql = new StringBuilder()
				.append(" insert into ")
				.append(" tb_atendimento_caso ")
				.append(" ( ")
				.append(" id_caso ")
				.append(", ")
				.append(" id_usuario ")
				.append(", ")
				.append(" id_status ")
				.append(", ")
				.append(" id_configuracao_fila ")
				.append(", ")
				.append(" flag_inicio ")
				.append(" ) ")
				.append(" values ")
				.append(" ( ?, ?, ?, ?, ? ) "); 
		        
		        PreparedStatement ps = super.getPreparedStatement(sql.toString());
		        if(atendimentoCaso.getIdCaso() != null) {
		        	ps.setInt(1, atendimentoCaso.getIdCaso());
		        } else {
		        	ps.setNull(1, Types.NULL);
		        }
		        
		        if(atendimentoCaso.getIdUsuario() != null) {
		        	ps.setInt(2, atendimentoCaso.getIdUsuario());
		        } else {
		        	ps.setNull(2, Types.NULL);
		        }
				
		        if(atendimentoCaso.getIdStatus() != null) {
		        	ps.setInt(3, atendimentoCaso.getIdStatus());
		        } else {
		        	ps.setNull(3, Types.NULL);
		        }
				
		        if(atendimentoCaso.getIdConfiguracaoFila() != null) {
		        	ps.setInt(4, atendimentoCaso.getIdConfiguracaoFila());
		        } else {
		        	ps.setNull(4, Types.NULL);
		        }
				
				ps.setBoolean(5, atendimentoCaso.getFlgInicio());
				
				ps.executeUpdate();
			}
		} finally {
			super.closeConnection();
		}
	}
	
	public List<AnexoTO> buscaPorGrupoAnexo(Integer idGrupoAnexo) throws Exception {
		List<AnexoTO> list = new ArrayList<AnexoTO>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(AnexoTO.getSqlCamposAnexo())
				.append(FROM)
				.append(AnexoTO.getSqlFromAnexo())
				.append(" WHERE Anexo.ID_GRUPO_ANEXO = ? ");

			stmt = getPreparedStatement(select.toString());

			stmt.setInt(1, idGrupoAnexo);

			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					AnexoTO anexo = AnexoTO.getAnexoByResultSet(resultSet);
					list.add(anexo);
				}
			}
		} finally {
			super.closeConnection();
		}
		return list;
    }
}