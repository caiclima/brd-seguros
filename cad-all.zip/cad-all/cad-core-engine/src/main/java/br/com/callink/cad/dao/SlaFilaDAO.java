package br.com.callink.cad.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import br.com.callink.cad.to.SlaFilaTO;


public class SlaFilaDAO extends GenericDAO {

	public List<SlaFilaTO> findAll() throws Exception {
		try {
			List<SlaFilaTO> slas = new ArrayList<>();
			
			StringBuilder sql = new StringBuilder();
			sql.append(SELECT);
			sql.append(SlaFilaTO.getSqlCamposSlaFilaTO());
			sql.append(FROM);
			sql.append(SlaFilaTO.getSqlFromSlaFilaTO());
			
			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ResultSet rs = ps.executeQuery();
			
			if(rs != null){
				while(rs.next()){
					SlaFilaTO sla = SlaFilaTO.getSlaFilaTOByResultSet(rs);
					slas.add(sla);
				}
			}
			
			return slas;
			
		} finally {
			super.closeConnection();
		}
	}

	public SlaFilaTO buscarPorId(Integer id) throws Exception {
		try {
			StringBuilder sql = new StringBuilder();
			sql.append(SELECT);
			sql.append(SlaFilaTO.getSqlCamposSlaFilaTO());
			sql.append(FROM);
			sql.append(SlaFilaTO.getSqlFromSlaFilaTO());
			sql.append(" WHERE id_sla_fila = ? ");

			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				return SlaFilaTO.getSlaFilaTOByResultSet(rs);
			}

			return null;
		} finally {
			super.closeConnection();
		}
	}

	public List<SlaFilaTO> buscaSlaFilaPorOperacao(Integer idOperacao) throws Exception {
		try {
			List<SlaFilaTO> slas = new ArrayList<>();
			
			StringBuilder sql = new StringBuilder();
			sql.append(SELECT);
			sql.append(SlaFilaTO.getSqlCamposSlaFilaTO());
			sql.append(FROM);
			sql.append(SlaFilaTO.getSqlFromSlaFilaTO())
			.append(" where SlaFilaTO.id_operacao = ? ")
			.append("   and SlaFilaTO.data_fim is null ");
			
			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			
			ps.setInt(1, idOperacao);
			
			ResultSet rs = ps.executeQuery();
			
			if(rs != null){
				while(rs.next()){
					SlaFilaTO sla = SlaFilaTO.getSlaFilaTOByResultSet(rs);
					slas.add(sla);
				}
			}
			
			return slas;
			
		} finally {
			super.closeConnection();
		}
	}

}
