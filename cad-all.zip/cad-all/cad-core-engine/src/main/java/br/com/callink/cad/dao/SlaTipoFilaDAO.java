package br.com.callink.cad.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import br.com.callink.cad.to.SlaFilaTO;


public class SlaTipoFilaDAO extends GenericDAO {

	public SlaFilaTO findSlaTipoFilaByPk(Integer idSlaFilaTO) throws Exception {
		try {
			
			StringBuilder sql = new StringBuilder();
			sql.append(SELECT);
			sql.append(SlaFilaTO.getSqlCamposSlaFilaTO());
			sql.append(FROM);
			sql.append(SlaFilaTO.getSqlFromSlaFilaTO());
			sql.append(WHERE)
			.append(" SlaFilaTO.ID_SLA_FILA = ? ");
			
			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ps.setInt(1, idSlaFilaTO);
			ResultSet rs = ps.executeQuery();
			
			if(rs != null){
				while(rs.next()){
					return SlaFilaTO.getSlaFilaTOByResultSet(rs);
				}
			}
			return null;
			
		} finally {
			super.closeConnection();
		}
	}
}