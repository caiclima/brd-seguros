package br.com.callink.cad.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.com.callink.cad.to.UsuarioLogadoTO;

public class UsuarioLogadoDAO extends GenericDAO {

	public List<UsuarioLogadoTO> validaTempoDisponivel(Integer idOperacao, Integer minutosFinalizaSessao, Integer idStatus) throws Exception {
		try {
			StringBuilder sql = new StringBuilder();
			sql.append("SELECT ul.id_usuario as idUser , ul.id_status as idStatus , ul.data_status as dataStatus ");
			sql.append("FROM tb_usuario_logado ul with(nolock) ");
			sql.append("WHERE EXISTS ( ");
			sql.append("	SELECT 1 ");
			sql.append("	FROM tb_operacao_usuario opUsr with(nolock) ");
			sql.append("	WHERE opUsr.id_usuario = ul.id_usuario ");
			sql.append("	  AND opUsr.id_operacao = ? ").append(" AND flag_operacao_principal = 1 ");
			sql.append("	) ");
			sql.append(" AND datediff(ss, ul.data_status, getdate()) > ? and flag_logado = 1 and id_status = ?");

			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ps.setInt(1, idOperacao);
			ps.setInt(2, minutosFinalizaSessao);
			ps.setInt(3, idStatus);
			ResultSet resultSet = ps.executeQuery();

			List<UsuarioLogadoTO> usuarioList = new ArrayList<UsuarioLogadoTO>();
			if (resultSet != null) {
				while (resultSet.next()) {
					UsuarioLogadoTO usuarioLogadoTO = new UsuarioLogadoTO();
					usuarioLogadoTO.setIdUsuario(resultSet.getInt("idUser"));
					usuarioLogadoTO.setIdStatus(resultSet.getInt("idStatus"));
					usuarioLogadoTO.setDataStatus(resultSet.getTimestamp("dataStatus"));
					
					usuarioList.add(usuarioLogadoTO);
				}
			}

			return usuarioList;
			
		} finally {
			super.closeConnection();
		}
	}
	
	public Integer quantidadeMensagemUsuario(Integer idUsuario, String chave) throws Exception {
		try {
			StringBuilder sql = new StringBuilder();
			sql.append("SELECT count(*) as contador from tb_notificacao with(nolock) where chave_notificacao = ? AND usuario = ? and (flag_processado = 0 OR flag_processado is null) ");

			PreparedStatement ps = super.getPreparedStatement(sql.toString());
			ps.setString(1, chave);
			ps.setInt(2, idUsuario);
			ResultSet resultSet = ps.executeQuery();

			if (resultSet != null) {
				resultSet.next();
				
				return resultSet.getInt("contador");
			}
			
			return 0;
		} finally {
			super.closeConnection();
		}
	}
	
}
