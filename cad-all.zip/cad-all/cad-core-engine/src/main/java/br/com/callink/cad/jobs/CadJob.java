package br.com.callink.cad.jobs;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.JobKey;
import org.quartz.xml.ValidationException;

import br.com.callink.cad.dao.ConfiguracaoCaixaEmailDAO;
import br.com.callink.cad.dao.FeriadoDAO;
import br.com.callink.cad.dao.JobDAO;
import br.com.callink.cad.dao.JornadaDAO;
import br.com.callink.cad.dao.LogJobDAO;
import br.com.callink.cad.dao.ParametroSistemaDAO;
import br.com.callink.cad.dao.RecebeEmailDAO;
import br.com.callink.cad.dao.SlaFilaDAO;
import br.com.callink.cad.enumeration.NotificacaoEnum;
import br.com.callink.cad.to.ConfiguracaoCaixaEmailTO;
import br.com.callink.cad.to.EmailTO;
import br.com.callink.cad.to.FeriadoTO;
import br.com.callink.cad.to.JobTO;
import br.com.callink.cad.to.JornadaTO;
import br.com.callink.cad.to.LogJobTO;
import br.com.callink.cad.to.NotificacaoAdminTO;
import br.com.callink.cad.to.SlaFilaTO;
import br.com.callink.cad.util.CollectionUtils;
import br.com.callink.cad.util.ConstantesParametro;
import br.com.callink.cad.util.DateUtils;

public abstract class CadJob implements Job {

	private final Logger logger = Logger.getLogger(getClass().getName());
	private final int TRIGGER_ERROR_CODE = 50000;

	private JobDAO dao;
	private LogJobDAO logDao;
	private RecebeEmailDAO emailDAO;
	private ParametroSistemaDAO parametroSistemaDAO;
	private ConfiguracaoCaixaEmailDAO configuracaoCaixaEmailDAO;
	private Date dataIni = null;
	private JobTO jobTO = null;

	@Override
	public final void execute(JobExecutionContext context) throws JobExecutionException {
		logger.info("Início execução JOB.");
		
		final JobKey key = context.getJobDetail().getKey();
		final Integer idJob = Integer.valueOf(key.getGroup());
		
		String sarID = context.getJobDetail().getDescription();
		
		try {
			dataIni = startUp();
			buscaOperacaoEIniciaExecucaoJob(dataIni, idJob, sarID, context);
			
			if (jobTO != null && jobTO.getOperacao() != null) {
				logger.info(MessageFormat.format("Operação a ser processada: {0} ", jobTO.getOperacao().getIdOperacao()));
				
				//Insere controle de execução da JOB
				Integer row = dao.updateDataExecucao(jobTO.getOperacao().getIdOperacao(), idJob, sarID);
				if (row == null || row == 0 || row == -1) {
					dao.insereControleJob(jobTO.getOperacao().getIdOperacao(), idJob, sarID);
				}
				
				process(jobTO.getOperacao().getIdTenant(), jobTO.getOperacao().getIdOperacao(), jobTO.getNome());
				
				logger.log(Level.INFO, "CADJOB - Controle de execução removido apos execucao. Operacao: "+jobTO.getOperacao().getIdOperacao()+" - Job: "+ idJob);
				Date dataFim = startUp();
				logDao.insereLogJob(LogJobTO.buildLogJob(jobTO.getNome(), dataIni, dataFim, "Realizado com sucesso", true, null, jobTO.getOperacao().getIdOperacao(), jobTO.getClazz()));
				
			} else {
				logger.info("Nenhuma operação a ser processada!");
				if (jobTO != null) {
					logDao.insereLogJob(LogJobTO.buildLogJob(jobTO.getNome(), dataIni, null, "Nenhuma operação a ser processada", true, null, jobTO.getOperacao().getIdOperacao(), jobTO.getClazz()));
				}
			}
			context.put("executando", 0);
		} catch (Exception e) {
			StringBuilder errors = new StringBuilder("[Operação: ");
			errors.append(jobTO.getOperacao().getIdOperacao());
			errors.append(", JOB: ");
			errors.append(idJob);
			errors.append("] ");
			errors.append(e.getMessage());
			logger.log(Level.SEVERE, errors.toString(), e);
			context.put("executando", 0);
			try {
				Date dataFim = startUp();
				logDao.insereLogJob(LogJobTO.buildLogJob(jobTO.getNome(), dataIni, dataFim, "Falha no processamento", false, getStackTrace(e), jobTO.getOperacao().getIdOperacao(), jobTO.getClazz()));
				
				StringBuilder stack = new StringBuilder(e.getMessage());
				stack.append("  <br /> <br />");
				for (StackTraceElement element : e.getStackTrace()) {
					stack.append(element);
					stack.append(" <br />");
				}
				
				String conteudo = parametroSistemaDAO.findValorParametroSistema(ConstantesParametro.CORPO_EMAIL_NOTIF_FALHA_JOB.getMnemonico());
				conteudo = conteudo.replace("#{JOB}", jobTO.getNome()).replace("#{STACKTRACE}", stack)
						.replace("#{DATAEXECUCAO}", DateUtils.formatDateTime(dataIni));

				enviaNotificacaoAdmin(conteudo, NotificacaoEnum.ERRO);
				
				if (jobTO != null && jobTO.getFlagNotificaFalha()) {
					final ConfiguracaoCaixaEmailTO configuracaoCaixaEmailTO = configuracaoCaixaEmailDAO.findAtivosPrincipalPorOperacao(jobTO.getOperacao()
							.getIdOperacao(), Boolean.TRUE);

					if (configuracaoCaixaEmailTO != null && configuracaoCaixaEmailTO.getIdConfiguracaoCaixaEmail() != null) {
						String assunto = parametroSistemaDAO.findValorParametroSistema(ConstantesParametro.ASSUNTO_EMAIL_NOTIF_FALHA_JOB.getMnemonico());
						assunto = assunto.replace("#{JOB}", jobTO.getNome());
						
						final Date dataBanco = dao.getDataBanco();
					
						emailDAO.saveEmail(EmailTO.buildMailToSend(assunto, conteudo, configuracaoCaixaEmailTO.getEmail(), jobTO.getOperacao().getEmailsAdm(),
								null, dataBanco, jobTO.getOperacao().getIdOperacao(), configuracaoCaixaEmailTO.getIdConfiguracaoCaixaEmail(),
								Boolean.TRUE, Boolean.FALSE, null));
					}
				}

			} catch (Exception e1) {
				errors = new StringBuilder("[Operação: ");
				errors.append(jobTO.getOperacao().getIdOperacao());
				errors.append(", JOB: ");
				errors.append(idJob);
				errors.append("] ");
				errors.append(e.getMessage());
				logger.log(Level.SEVERE, errors.toString(), e);
				
			}
		} finally {
			try {
				if (jobTO != null) {
					finalizaExecucaoJob(jobTO.getOperacao().getIdOperacao(), idJob, sarID);
				}
				logger.info("Fim execução JOB.");
				context.put("executando", 0);
			} catch (Exception e) {
				StringBuilder errors = new StringBuilder("[Operação: ");
				errors.append(jobTO.getOperacao().getIdOperacao());
				errors.append(", JOB: ");
				errors.append(idJob);
				errors.append("] ");
				errors.append(e.getMessage());
				logger.log(Level.SEVERE, errors.toString(), e);
			}
		}
	}
	
	protected String getStackTrace(Throwable aThrowable) {
	    Writer result = new StringWriter();
	    PrintWriter printWriter = new PrintWriter(result);
	    aThrowable.printStackTrace(printWriter);
	    return result.toString();
	  }


	/**
	 * @param idOperacao
	 * @throws Exception
	 */
	protected abstract void process(Integer idTenant, Integer idOperacao, String nome) throws Exception;

	/**
	 * @param dataIni
	 * @return
	 * @throws Exception
	 */
	protected final void buscaOperacaoEIniciaExecucaoJob(Date dataIni, Integer idJob, String sarID, JobExecutionContext context) throws Exception {
		
		try {
			jobTO = dao.buscaOperacaoAtualPorJob(idJob);
			
			if (jobTO != null && jobTO.getOperacao() != null) {
				context.put("operacaoExecucao", jobTO.getOperacao().getIdOperacao());
				context.put("executando", 1);
				dao.atualizaFlagExecucaoPorJobEOperacao(idJob, jobTO.getOperacao().getIdOperacao(), dataIni, true, sarID);

				logger.info(jobTO.getNome() + " [Operação: " + jobTO.getOperacao().getIdOperacao() + "] " + "[flag_executando = true]");
			}

		} catch (SQLException e) {
			if (e.getErrorCode() == TRIGGER_ERROR_CODE) {
				logger.log(Level.SEVERE, e.getMessage());
				buscaOperacaoEIniciaExecucaoJob(dao.getDataBanco(), idJob, sarID, context);
			}
			logger.log(Level.SEVERE, e.getMessage());
		}
	}

	/**
	 * @param idOperacao
	 * @throws Exception
	 */
	protected void finalizaExecucaoJob(Integer idOperacao, Integer idJob, String sarID) throws Exception {
		if (idOperacao != null) {
			dao.atualizaFlagExecucaoPorJobEOperacao(idJob, idOperacao, dao.getDataBanco(), false, sarID);
		}
	}

	/**
	 * @return
	 * @throws Exception
	 */
	private Date startUp() throws Exception {
		if (dao == null) {
			dao = new JobDAO();
			logDao = new LogJobDAO();
			emailDAO = new RecebeEmailDAO();
			parametroSistemaDAO = new ParametroSistemaDAO();
			configuracaoCaixaEmailDAO = new ConfiguracaoCaixaEmailDAO();
		}
		return dao.getDataBanco();
	}
	
	protected LogJobDAO getLogDao() {
		return logDao;
	}
	
	protected Date getDataInitJob() {
		return dataIni;
	}
	
	protected JobTO getJobTO() {
		return jobTO;
	}

	public Map<String, br.com.callink.cad.to.FeriadoTO> getFeriadosOperacao(Integer idOperacao) throws Exception {
		
		if (idOperacao == null || idOperacao.equals(Integer.valueOf(0))) {
			throw new ValidationException("O idOperacao não pode ser nulo.");
		}
		
		FeriadoDAO feriadoDAO = new FeriadoDAO();
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		
		Map<String, br.com.callink.cad.to.FeriadoTO> feriadoMap = new HashMap<String, br.com.callink.cad.to.FeriadoTO>();
		
		for (FeriadoTO dta : feriadoDAO.findFeriadosOperacao(idOperacao)) {

			if (dta.getFlagNacional() != null && dta.getFlagNacional()) {

				Calendar calAtual = Calendar.getInstance();
				calAtual.setTime(dta.getDataFeriado());
				calAtual.set(Calendar.YEAR, Calendar.getInstance().get(Calendar.YEAR));

				feriadoMap.put(df.format(calAtual.getTime()), dta);
			} else {

				feriadoMap.put(df.format(dta.getDataFeriado()), dta);
			}

		}
		
		return feriadoMap;
	}
	
	public Map<Integer, br.com.callink.cad.to.JornadaTO> getJornadaOperacao(Integer idOperacao) throws Exception {
		if (idOperacao == null || idOperacao.equals(Integer.valueOf(0))) {
			throw new ValidationException("O idOperacao não pode ser nulo.");
		}
		JornadaDAO jornadaDAO = new JornadaDAO();
		
		Map<Integer, br.com.callink.cad.to.JornadaTO> jornadaMap = new HashMap<Integer, br.com.callink.cad.to.JornadaTO>();
		List<JornadaTO> jornadasAtivas = jornadaDAO.findPorOperacao(idOperacao);
		if (jornadasAtivas != null && jornadasAtivas.size() > 0) {
			for (JornadaTO jornada : jornadasAtivas) {
				jornadaMap.put(jornada.getIdJornada(), jornada);
			}
		}
		
		return jornadaMap;
	}
	
	public Map<Integer, br.com.callink.cad.to.SlaFilaTO> getSlaFilaOperacao(Integer idOperacao) throws Exception {
		if (idOperacao == null || idOperacao.equals(Integer.valueOf(0))) {
			throw new ValidationException("O idOperacao não pode ser nulo.");
		}
		SlaFilaDAO slaFilaDAO = new SlaFilaDAO();
		
		Map<Integer, br.com.callink.cad.to.SlaFilaTO> slaFilaMap = new HashMap<Integer, br.com.callink.cad.to.SlaFilaTO>();
		
		List<SlaFilaTO> listSlaFila = slaFilaDAO.buscaSlaFilaPorOperacao(idOperacao);

		// Verifica se não foi encontrado nenhum dado na tabela tb_sla_fila
		if (listSlaFila != null && !listSlaFila.isEmpty()) {
			for (SlaFilaTO slaFila : listSlaFila) {
				slaFilaMap.put(slaFila.getIdSlaFila(), slaFila);
			}
		}
		return slaFilaMap;
	}
	
	public String getSchemaDbReport(Integer idTenant) throws Exception {
		return dao.getSchemaDbReport(idTenant);
	}
	
	public void enviaNotificacaoAdmin(String mensagem, NotificacaoEnum chave) throws Exception {
		logger.info("Enviando notificações... ");
		final List<Integer> listIDs = dao.buscaObservadorPorOperacao(jobTO.getOperacao().getIdOperacao());

		if (CollectionUtils.hasValue(listIDs)) {
			logger.info("Observadores de notificações admin para operação: " + jobTO.getOperacao().getIdOperacao());
			
			Date dataCriacao = dao.getDataBanco();
			List<NotificacaoAdminTO> source = new ArrayList<NotificacaoAdminTO>();

			for (Integer idusuario : listIDs) {
				logger.info(idusuario.toString());
				
				NotificacaoAdminTO notificacao = new NotificacaoAdminTO();
				notificacao.setChaveNotificacao(chave.toString());
				notificacao.setIdUsuario(idusuario);
				notificacao.setDataCriacao(dataCriacao);
				notificacao.setNotificacao(mensagem);

				source.add(notificacao);
			}
			dao.salvaNotificacaoAdmin(source);
		}
	}
}
