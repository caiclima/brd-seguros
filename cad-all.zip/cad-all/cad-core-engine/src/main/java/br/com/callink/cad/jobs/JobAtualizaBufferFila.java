package br.com.callink.cad.jobs;

import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.quartz.JobExecutionException;

import br.com.callink.cad.dao.AtualizaBufferFilaDAO;
import br.com.callink.cad.dao.ParametroSistemaDAO;
import br.com.callink.cad.to.BufferFilaTO;
import br.com.callink.cad.to.CasoTO;
import br.com.callink.cad.to.ConfiguracaoFilaTO;
import br.com.callink.cad.util.CalculoSlaHelper;
import br.com.callink.cad.util.ConstantesParametro;

/**
 * @author Bruno Martins
 * 
 */
public class JobAtualizaBufferFila extends CadJob {

	private Logger logger = Logger.getLogger(JobAtualizaBufferFila.class.getName());
	private AtualizaBufferFilaDAO atualizaBufferFilaDAO;
	private ParametroSistemaDAO parametroSistemaDAO;
	private CalculoSlaHelper calculoSlaUtil;
	
	private void setUp(Integer idOperacao) throws Exception {
		if (atualizaBufferFilaDAO == null) {
			atualizaBufferFilaDAO = new AtualizaBufferFilaDAO();
		}
		if (parametroSistemaDAO == null) {
			parametroSistemaDAO = new ParametroSistemaDAO();
		}
		
		calculoSlaUtil = new CalculoSlaHelper(getFeriadosOperacao(idOperacao),
				getJornadaOperacao(idOperacao),
				getSlaFilaOperacao(idOperacao));
	}

	@Override
	protected void process(Integer idTenant, Integer idOperacao, String nome) throws Exception {
		if (idOperacao == null) {
			return;
		}
		
		setUp(idOperacao);
		iniciaBufferFila(idOperacao);
	}

	private void iniciaBufferFila(Integer idOperacao) throws JobExecutionException {
		try {
			/*
			 * Remove do buffer os casos que não existem mais na tb_caso
			 */
			atualizaBufferFilaDAO.removeCasosNaoExistentes();
			
			Integer bufferCasoParametro;
			try {
				bufferCasoParametro = Integer.valueOf(parametroSistemaDAO.
						findValorParametroSistemaOperacao(ConstantesParametro.BUFFER_ATENDIMENTO.getMnemonico(), idOperacao));
			} catch (Exception e1) {
				bufferCasoParametro = 3;
				
				StringBuilder errors = new StringBuilder("[Operação: ");
				errors.append(idOperacao);
				errors.append("] ");
				errors.append(" Erro ao buscar o parametro: ").append(ConstantesParametro.BUFFER_ATENDIMENTO.getMnemonico());
				errors.append(e1.getMessage());
				logger.log(Level.SEVERE, errors.toString(), e1);
				throw e1;
			}
			
			//Esta tratado no DAO o log do erro
			atualizaBufferFilaDAO.removeCasosEntregues(idOperacao);
			
			List<ConfiguracaoFilaTO> configuracaoFilaList = null;
			configuracaoFilaList = atualizaBufferFilaDAO.buscaFilaAtivaPorPrioridadeEOperacao(idOperacao);
			
			List<BufferFilaTO> bufferList = atualizaBufferFilaDAO.buscaFilasNoBuffer(idOperacao);
			
			if (configuracaoFilaList != null) {
				for (ConfiguracaoFilaTO configuracaoFila : configuracaoFilaList) {
					iniciaBufferFila(configuracaoFila, bufferCasoParametro, idOperacao, bufferList);
				}
			}
		} catch (Exception e) {
			StringBuilder errors = new StringBuilder("[Operação: ");
			errors.append(idOperacao);
			errors.append("] ");
			errors.append(" Erro na JobAtualizaBufferFila: ");
			errors.append(e.getMessage());
			logger.log(Level.SEVERE, errors.toString(), e);
		
			throw new JobExecutionException(e);
		}
	}

	private void iniciaBufferFila(ConfiguracaoFilaTO configuracaoFila, Integer bufferCasoParametro, Integer idOperacao, List<BufferFilaTO> bufferList) throws Exception {
		Boolean flagNaoEncontrado = true;
		Date dataAtual = atualizaBufferFilaDAO.getDataBanco();
		try {
		
		for (BufferFilaTO bff : bufferList) {
			if (configuracaoFila.getIdConfiguracaoFila().equals(bff.getIdFila())) {
				flagNaoEncontrado = Boolean.FALSE;
				if (bff.getQuantidade() < bufferCasoParametro) {
					
					Integer difBuffer = bufferCasoParametro - bff.getQuantidade();
					List<CasoTO> casolst = atualizaBufferFilaDAO.buscaCasosOrdernadosPorFilaSemUsuario(configuracaoFila.getSqlOrder(), configuracaoFila, difBuffer);
					
					for (CasoTO casoTO : casolst) {
						calculoSlaUtil.loadSla(casoTO, dataAtual);
					}
					
					atualizaBufferFilaDAO.insereCasoBuffer(casolst);
					flagNaoEncontrado = Boolean.FALSE;
					
					return;
				}
			}
		}
		
		if (flagNaoEncontrado) {
			List<CasoTO> casolst = atualizaBufferFilaDAO.buscaCasosOrdernadosPorFilaSemUsuario(configuracaoFila.getSqlOrder(), configuracaoFila, bufferCasoParametro);
			if (casolst != null && !casolst.isEmpty()) {
				for (CasoTO casoTO : casolst) {
					calculoSlaUtil.loadSla(casoTO, dataAtual);
				}
				atualizaBufferFilaDAO.insereCasoBuffer(casolst);
			}
		}
	} catch (Exception e) {
		StringBuilder errors = new StringBuilder("[Operação: ");
		errors.append(idOperacao);
		errors.append("] ");
		errors.append(" Erro na iniciaBufferFila: ");
		errors.append(e.getMessage());
		logger.log(Level.SEVERE, errors.toString(), e);
	
		throw new JobExecutionException(e);
	}
	}
}
