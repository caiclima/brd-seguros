package br.com.callink.cad.jobs;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import br.com.callink.cad.dao.AtualizaDataPrevistaFimSlaDAO;
import br.com.callink.cad.to.CasoTO;
import br.com.callink.cad.to.SlaFilaTO;
import br.com.callink.cad.util.CalculoSlaHelper;
import br.com.callink.cad.util.CollectionUtils;
import br.com.callink.cad.util.Constantes;
import br.com.callink.cad.util.TransactionUtils;

/**
 * @author swb_samuel
 *
 */
public class JobAtualizaDataPrevistaFimSla extends CadJob {

	private final Logger logger = Logger.getLogger(JobAtualizaDataPrevistaFimSla.class.getName());
	private CalculoSlaHelper calculoSlaUtil;
	private AtualizaDataPrevistaFimSlaDAO dao;
	private List<CasoTO> listaCasos;

	private void setUp(Integer idOperacao) throws Exception {
		if (calculoSlaUtil == null) {
			calculoSlaUtil = new CalculoSlaHelper(getFeriadosOperacao(idOperacao), getJornadaOperacao(idOperacao), getSlaFilaOperacao(idOperacao));
		}
		dao = new AtualizaDataPrevistaFimSlaDAO();
		listaCasos = new ArrayList<CasoTO>();
	}

	@Override
	protected void process(Integer idTenant, Integer idOperacao, String nome) throws Exception {
		List<CasoTO> _casos = null;
		try {
			setUp(idOperacao);
			_casos = dao.buscaCasosEnfileirados(idOperacao);
			calcularDataPrevistaFimSla(_casos);
			executaOperacoes();
		} catch (Exception e) {
			StringBuilder errors = new StringBuilder("[Operação: ");
			errors.append(idOperacao);
			errors.append("] ");
			if(_casos != null) {
				errors.append("Casos a serem processados:[ ");
				for(CasoTO c: _casos) {
					errors.append(c.getIdCaso()+",");
				}
				errors.append("]");
			}
			errors.append(e.getMessage());
			logger.log(Level.SEVERE, errors.toString(), e);
			throw e;
		}
	}

	private void calcularDataPrevistaFimSla(List<CasoTO> _casos) throws Exception {
		if (CollectionUtils.hasValue(_casos)) {
			Map<Integer, List<CasoTO>> group = groupByIdConfiguracaoFila(_casos);

			for (Integer idConfiguracaoFila : group.keySet()) {
				SlaFilaTO slaFila = buscaSla(idConfiguracaoFila);

				if (slaFila != null) {
					List<CasoTO> list = group.get(idConfiguracaoFila);

					for (CasoTO caso : list) {
						if (slaFila.getSla() != null && slaFila.getSla() != null) {
							caso.setDataPrevistaFimSla(calculoSlaUtil.somarHorasUteis(slaFila, caso.getDataAbertura(), slaFila.getSla(),caso.getIdOperacao()));
						} else {
							caso.setDataPrevistaFimSla(caso.getDataAbertura());
						}

						listaCasos.add(caso);
					}
				}
			}
		}
	}

	private Map<Integer, List<CasoTO>> groupByIdConfiguracaoFila(List<CasoTO> _casos) {
		Map<Integer, List<CasoTO>> group = new HashMap<Integer, List<CasoTO>>();

		for (CasoTO casoTO : _casos) {
			if (group.containsKey(casoTO.getIdConfiguracaoFila())) {
				group.get(casoTO.getIdConfiguracaoFila()).add(casoTO);

			} else {
				List<CasoTO> itens = new ArrayList<CasoTO>();
				itens.add(casoTO);

				group.put(casoTO.getIdConfiguracaoFila(), itens);
			}
		}
		return group;
	}

	private void executaOperacoes() throws Exception {
		if (CollectionUtils.hasValue(listaCasos)) {
			List<List<CasoTO>> listslistaCasoUpdate = TransactionUtils.subLists(listaCasos, Constantes.NRO_REGISTROS_COMMIT);
			for (List<CasoTO> update : listslistaCasoUpdate) {
				for (CasoTO casoTO : update) {
					dao.atualizaDataPrevistaFimSlaEDataAbertura(casoTO);
				}
			}
		}
	}

	private SlaFilaTO buscaSla(Integer idConfiguracaoFila) throws Exception {
		SlaFilaTO slaFilaTO = dao.findSlaFilaByConfFilaAndDataFimNull(idConfiguracaoFila);

		if (slaFilaTO != null) {
			return slaFilaTO;
		} else {
			logger.log(Level.SEVERE, "Fila não possui SLA. Fila id: " + idConfiguracaoFila);
			return null;
		}
	}
}
