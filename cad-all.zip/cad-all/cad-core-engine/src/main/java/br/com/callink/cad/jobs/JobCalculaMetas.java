package br.com.callink.cad.jobs;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import br.com.callink.cad.dao.CalculaMetasDAO;
import br.com.callink.cad.to.CabMetaFullTO;
import br.com.callink.cad.to.CabMetaTO;
import br.com.callink.cad.to.CabUphTO;
import br.com.callink.cad.to.EquipeMetaTO;
import br.com.callink.cad.to.GoalFinalTO;
import br.com.callink.cad.to.MetaFilaTO;
import br.com.callink.cad.to.MetaUphTO;
import br.com.callink.cad.to.StatusUsuarioTO;
import br.com.callink.cad.to.UsuarioTO;
import br.com.callink.cad.util.DateUtils;
import br.com.callink.cad.util.ImagesnMetaEnum;

public class JobCalculaMetas extends CadJob {

	private final Logger logger = Logger.getLogger(JobCalculaMetas.class.getName());
	
	private CalculaMetasDAO dao;

	private Date dataBancoAtual;
	private List<GoalFinalTO> listGoalFinal;

	private void setUp() throws Exception {
		if (dao == null) {
			dao = new CalculaMetasDAO();
		}
	}

	@Override
	protected void process(Integer idTenant, Integer idOperacao, String nome) throws Exception {
		try {
			setUp();
			calculaMetasUph(idOperacao);
		} catch(Exception e){
			StringBuilder errors = new StringBuilder("[Operação: ");
			errors.append(idOperacao);
			errors.append("] ");
			errors.append(e.getMessage());
			logger.log(Level.SEVERE, errors.toString(), e);
			throw e;
		}
	}

	private void calculaMetasUph(Integer idOperacao) throws Exception {
		listGoalFinal = dao.buscaGoalsAtivos(idOperacao);

		Map<String, CabMetaTO> mapCabMeta = new HashMap<String, CabMetaTO>();
		dataBancoAtual = dao.getDataBanco();

		List<Integer> idsEquipes = dao.findEquipeAtivos(idOperacao);

		if (idsEquipes != null && !idsEquipes.isEmpty()) {
			for (Integer idEquipe : idsEquipes) {
				List<UsuarioTO> usuarios = dao.buscaUsuariosPorEquipe(idEquipe, idOperacao);

				if (usuarios != null && !usuarios.isEmpty()) {
					List<Integer> idsConfigFilasEquipeFilas = dao.findFilasByEquipeAndOperacao(idEquipe, idOperacao);

					List<EquipeMetaTO> equipeMetaListTO = new ArrayList<EquipeMetaTO>();

					if (idsConfigFilasEquipeFilas != null && !idsConfigFilasEquipeFilas.isEmpty()) {
						for (Integer idConfigFilaEquipeFila : idsConfigFilasEquipeFilas) {
							EquipeMetaTO equipeMetaTO = new EquipeMetaTO();

							equipeMetaTO.setCasosFechados(Integer.valueOf(0));
							equipeMetaTO.setTempoTotalEquipe(Double.valueOf(0d));

							equipeMetaListTO.add(equipeMetaTO);

							for (UsuarioTO usuario : usuarios) {
								
								MetaFilaTO metaFilaTo = new MetaFilaTO();

								// tempo total usuario em todas as filas
								List<StatusUsuarioTO> listStatusTotal = dao.buscaStatusUsuarioByUserEquipe(null,
										idEquipe, usuario, DateUtils.addFirstTimeInDate(dataBancoAtual),
										DateUtils.addLastTimeInDate(dataBancoAtual));

								Double tempoTotalUsuarioTodasFilas = Double.valueOf(tempoGastoUsuario(listStatusTotal));

								// tempo total usuario na fila
								List<StatusUsuarioTO> listStatus = dao.buscaStatusUsuarioByUserEquipe(
										idConfigFilaEquipeFila, idEquipe, usuario,
										DateUtils.addFirstTimeInDate(dataBancoAtual),
										DateUtils.addLastTimeInDate(dataBancoAtual));

								Double tempoTotalUsuario = Double.valueOf(tempoGastoUsuario(listStatus));
								Integer casosFechadosUsuario = dao.quantidadeCasosFechados(usuario.getIdUsuario(),
										idConfigFilaEquipeFila, DateUtils.addFirstTimeInDate(dataBancoAtual),
										DateUtils.addLastTimeInDate(dataBancoAtual));
								equipeMetaTO.setCasosFechados(equipeMetaTO.getCasosFechados() + casosFechadosUsuario);

								// converte de milisegundos para hora
								Double tmo = (tempoTotalUsuario / Double.valueOf(1000 * 60 * 60))
										/ Double.valueOf(casosFechadosUsuario);

								Double uphRealizado = 1 / tmo;

								if (uphRealizado.equals(Double.NaN) || uphRealizado.equals(Double.NEGATIVE_INFINITY)
										|| uphRealizado.equals(Double.POSITIVE_INFINITY)) {
									uphRealizado = 0d;
								}

								CabUphTO cab = dao.findUltimaMetaConfigura(idConfigFilaEquipeFila);
								Double uphMeta = cab != null && cab.getMeta() != null ? cab.getMeta() : 0d;

								metaFilaTo.setUph(uphRealizado);
								metaFilaTo.setMeta(uphMeta);
								metaFilaTo.setFila(dao.findConfigFilaByPk(idConfigFilaEquipeFila));
								metaFilaTo.setIndiceGoal(uphMeta.equals(0d) ? 0d : (uphRealizado / uphMeta));
								metaFilaTo.setLogin(usuario.getLogin());

								if (cab != null) {
									metaFilaTo = montaRegraGoal(metaFilaTo, dao.findMetaByCabUph(cab), 
											tempoTotalUsuario, tempoTotalUsuarioTodasFilas);
								} else {
									metaFilaTo.setImagemGoal(ImagesnMetaEnum.CINZA.getCaminho());
									metaFilaTo.setGoalFinal(0d);
									metaFilaTo.setPesoMeta(0);
								}

								equipeMetaTO.setConfiguracaoFila(idConfigFilaEquipeFila);
								equipeMetaTO
										.setTempoTotalEquipe(equipeMetaTO.getTempoTotalEquipe() + tempoTotalUsuario);
								metaFilaTo.setEquipeMetaTO(equipeMetaTO);

								if (mapCabMeta.containsKey(usuario.getLogin())) {
									mapCabMeta.get(usuario.getLogin()).getListaMetaFilaTO().add(metaFilaTo);
								} else {
									CabMetaTO cabMetaTO = new CabMetaTO();
									cabMetaTO.setListaMetaFilaTO(new ArrayList<MetaFilaTO>());
									cabMetaTO.getListaMetaFilaTO().add(metaFilaTo);
									cabMetaTO.setIdUsuario(usuario.getIdUsuario());
									mapCabMeta.put(usuario.getLogin(), cabMetaTO);
								}

								if (tempoTotalUsuario == 0) {
									metaFilaTo.setImagemGoal(ImagesnMetaEnum.CINZA.getCaminho());
								}

							}

							Double calculo = equipeMetaTO.getTempoTotalEquipe() / Double.valueOf(1000 * 60 * 60);
							if (calculo > Double.valueOf(0)) {
								equipeMetaTO.setUphEquipe(equipeMetaTO.getCasosFechados() == 0 ? 0d : 1 / (calculo / equipeMetaTO.getCasosFechados()));
							} else {
								equipeMetaTO.setUphEquipe(Double.valueOf(0));
							}
						}
					}

					calculaGMediaPonderadaFinal(mapCabMeta);

					dao.deleteCabMetaPorOperacao(idOperacao);
					dao.insereCabMeta(geraCabMetasInsert(mapCabMeta));
					dao.atualizaStatusLogado(getIconPerUser(mapCabMeta));
				}
			}
		}
	}

	private Map<String, List<Integer>> getIconPerUser(Map<String, CabMetaTO> mapCabMeta) {
		Map<String, List<Integer>> map = new HashMap<>();
		for (Map.Entry<String, CabMetaTO> entry : mapCabMeta.entrySet()) {

			if (map.containsKey(ImagesnMetaEnum.convertDescToImagem(entry.getValue().getImageGFinal()))) {
				map.get(ImagesnMetaEnum.convertDescToImagem(entry.getValue().getImageGFinal())).add(
						entry.getValue().getIdUsuario());

			} else {
				List<Integer> users = new ArrayList<>();
				users.add(entry.getValue().getIdUsuario());

				map.put(ImagesnMetaEnum.convertDescToImagem(entry.getValue().getImageGFinal()), users);
			}
		}
		return map;
	}

	private List<CabMetaFullTO> geraCabMetasInsert(Map<String, CabMetaTO> mapCabMeta) {
		List<CabMetaFullTO> toReturn = new ArrayList<CabMetaFullTO>();
		for (Map.Entry<String, CabMetaTO> entry : mapCabMeta.entrySet()) {
			for (int i = 0; i < entry.getValue().getListaMetaFilaTO().size(); i++) {
				MetaFilaTO metaFilaTO = entry.getValue().getListaMetaFilaTO().get(i);
				CabMetaFullTO to = new CabMetaFullTO();
				if (i == 0) {
					to.setFlagTotalizador(Boolean.TRUE);
				} else {
					to.setFlagTotalizador(Boolean.FALSE);
				}
				to.setIdUsuario(entry.getValue().getIdUsuario());
				to.setMediaPonderadaFinal(entry.getValue().getgMediaPonderadaFinal());
				to.setImageGFinal(ImagesnMetaEnum.convertDescToImagem(entry.getValue().getImageGFinal()));
				to.setNomeConfiguracaoFila(metaFilaTO.getFila().getNome());
				to.setUph(metaFilaTO.getUph());
				to.setMeta(metaFilaTO.getMeta());
				to.setIndiceGoal(metaFilaTO.getIndiceGoal());
				to.setIdConfiguracaoFila(metaFilaTO.getEquipeMetaTO().getConfiguracaoFila());
				to.setTempoTotalEquipe(metaFilaTO.getEquipeMetaTO().getTempoTotalEquipe());
				to.setCasosFechados(metaFilaTO.getEquipeMetaTO().getCasosFechados());
				to.setUphEquipe(metaFilaTO.getEquipeMetaTO().getUphEquipe());
				to.setLogin(metaFilaTO.getLogin());
				to.setImagemGoalFinal(metaFilaTO.getImagemGoal());
				to.setGoalFinal(metaFilaTO.getGoalFinal());
				to.setIdOperacao(metaFilaTO.getFila().getIdOperacao());
				toReturn.add(to);
			}
		}
		return toReturn;
	}

	/**
	 * calcula regra de goal/indice do usuario na fila
	 * 
	 * @param indiceGoal
	 * @param metasUph
	 * @return
	 */
	private MetaFilaTO montaRegraGoal(MetaFilaTO metaTO, List<MetaUphTO> metasUph, 
			Double tempoTotalUsuario, Double tempoTotalUsuarioTodasFilas) {

		Collections.sort(metasUph);

		List<Double> metas = new ArrayList<Double>();

		for (MetaUphTO meta : metasUph) {
			metas.add(meta.getMeta());
		}

		Collections.sort(metas);
		Double ind = metaTO.getIndiceGoal() * 100d;
		int retorno = Collections.binarySearch(metas, ind);
		MetaUphTO meta = null;
		// incrementa + 1 e retorna numero positivo
		retorno = Math.abs(++retorno);
		if (metasUph.size() < retorno) {
			 meta = metasUph.get(metasUph.size());
		} else {
			retorno = retorno == 0 ? 0 : retorno - 1;
		    meta = metasUph.get(retorno);
		}
		
		metaTO.setImagemGoal(ImagesnMetaEnum.convertDescToImagem(meta.getNomeImagem()));
		metaTO.setGoalFinal(tempoTotalUsuarioTodasFilas != 0 ? meta.getGoal()
				* (tempoTotalUsuario / tempoTotalUsuarioTodasFilas) : 0d);
		metaTO.setPesoMeta(meta.getGoal());

		
		return metaTO;

	}

	/**
	 * calcula tempo gasto do usuario em uma determinada fila
	 * 
	 * @param listStatusUsuario
	 * @return
	 */
	private Long tempoGastoUsuario(List<StatusUsuarioTO> listStatusUsuario) {

		Long tempo = 0l;
		for (StatusUsuarioTO statusUsuario : listStatusUsuario) {
			if (statusUsuario != null && statusUsuario.getDataInicio() != null) {
				long dateFinal = statusUsuario.getDataFim() == null ? dataBancoAtual.getTime() : statusUsuario
						.getDataFim().getTime();
				tempo += dateFinal - statusUsuario.getDataInicio().getTime();
			}
		}
		return tempo;
	}

	private void calculaGMediaPonderadaFinal(Map<String, CabMetaTO> mapCabMeta) {
		for (Map.Entry<String, CabMetaTO> entry : mapCabMeta.entrySet()) {
			Double somaGoals = 0d;
			Integer pesoMeta = 0;
			CabMetaTO cabMetaTO = entry.getValue();
			for (Iterator<MetaFilaTO> iterator = cabMetaTO.getListaMetaFilaTO().iterator(); iterator.hasNext();) {
				MetaFilaTO type = iterator.next();
				
				somaGoals = somaGoals + (type.getIndiceGoal() * type.getPesoMeta()); 
				pesoMeta = pesoMeta + type.getPesoMeta();
			}
			if(pesoMeta == 0) { // em caso de zero dividir por 1, nao muda no resultado
				pesoMeta =1;
			}
			
			Double mediaPondera = somaGoals/pesoMeta;
			
			cabMetaTO.setgMediaPonderadaFinal(mediaPondera);
			
			if(mediaPondera == 0) {
				cabMetaTO.setImageGFinal(ImagesnMetaEnum.CINZA.getCaminho());
			}
			
			for (GoalFinalTO goal : listGoalFinal) {
				
				if (mediaPondera >= goal.getGoalInicial() && mediaPondera <= goal.getGoalFinal()) {
					cabMetaTO.setImageGFinal(goal.getNomeImagem());
					break;
				}
				if ((listGoalFinal.indexOf(goal) == listGoalFinal.size() - 1) && mediaPondera >= goal.getGoalFinal()) {
					cabMetaTO.setImageGFinal(goal.getNomeImagem());
					break;
				}
			}
		}
	}
}
