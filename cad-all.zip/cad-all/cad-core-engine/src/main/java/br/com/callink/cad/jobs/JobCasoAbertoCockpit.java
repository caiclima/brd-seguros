package br.com.callink.cad.jobs;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import br.com.callink.cad.dao.CasoAbertoCockpitDAO;
import br.com.callink.cad.dao.ParametroSistemaDAO;
import br.com.callink.cad.enumeration.ParametroSistemaOperacaoEnum;
import br.com.callink.cad.to.CasoAbertoCockpitDetalheTO;
import br.com.callink.cad.to.CasoAbertoCockpitTO;
import br.com.callink.cad.to.CasoTO;
import br.com.callink.cad.util.CalculoSlaHelper;

public class JobCasoAbertoCockpit extends CadJob {

	private final Logger logger = Logger.getLogger(JobCasoAbertoCockpit.class.getName());
	
	private static final String TOTAL = "TOTAL";
	private CasoAbertoCockpitDAO dao;
	private CalculoSlaHelper calculoSlaUtil;
	private ParametroSistemaDAO parametroSistemaDAO;
	
	private void setUp(Integer idOperacao) throws Exception {
		dao = new CasoAbertoCockpitDAO();
		
		if (parametroSistemaDAO == null) {
			parametroSistemaDAO = new ParametroSistemaDAO();
		}
		
		calculoSlaUtil = new CalculoSlaHelper(getFeriadosOperacao(idOperacao),
				getJornadaOperacao(idOperacao),
				getSlaFilaOperacao(idOperacao));
	}

	@Override
	protected void process(Integer idTenant, Integer idOperacao, String nome) throws Exception {
		setUp(idOperacao);

		List<CasoTO> casos = dao.buscaCasoAbertoSemPendencia(idOperacao);
		Date dataAtual = dao.getDataBanco();
		for (CasoTO casoTO : casos) {
			calculoSlaUtil.loadSla(casoTO, dataAtual);
		}

		addRelatorioList(casos, idOperacao);
	}

	private void addRelatorioList(List<CasoTO> casoList, Integer idOperacao) throws Exception {
		if (casoList == null || casoList.isEmpty()) {
			return;
		}

		Map<Integer, Map<String, CasoAbertoCockpitTO>> mapCasoAbertoPorOperacao = new HashMap<Integer, Map<String, CasoAbertoCockpitTO>>();
		Map<Integer, Map<String, CasoAbertoCockpitTO>> mapCasoAbertoFilaPorOperacao = new HashMap<Integer, Map<String, CasoAbertoCockpitTO>>();

		Double coluna1;
		Double coluna2;
		Double coluna3;
		Double coluna4;
		Double coluna5;
		Double coluna6;

		try {
			coluna1 = Double.valueOf(parametroSistemaDAO.findValorParametroSistemaOperacao(ParametroSistemaOperacaoEnum.SLA_COLUNA_1.toString(), idOperacao));
			coluna2 = Double.valueOf(parametroSistemaDAO.findValorParametroSistemaOperacao(ParametroSistemaOperacaoEnum.SLA_COLUNA_2.toString(), idOperacao));
			coluna3 = Double.valueOf(parametroSistemaDAO.findValorParametroSistemaOperacao(ParametroSistemaOperacaoEnum.SLA_COLUNA_3.toString(), idOperacao));
			coluna4 = Double.valueOf(parametroSistemaDAO.findValorParametroSistemaOperacao(ParametroSistemaOperacaoEnum.SLA_COLUNA_4.toString(), idOperacao));
			coluna5 = Double.valueOf(parametroSistemaDAO.findValorParametroSistemaOperacao(ParametroSistemaOperacaoEnum.SLA_COLUNA_5.toString(), idOperacao));
			coluna6 = Double.valueOf(parametroSistemaDAO.findValorParametroSistemaOperacao(ParametroSistemaOperacaoEnum.SLA_COLUNA_6.toString(), idOperacao));

		} catch (NumberFormatException ex) {
			logger.log(Level.SEVERE,ex.getMessage(), ex);
			throw ex;
		}

		CasoAbertoCockpitTO casoTotal = new CasoAbertoCockpitTO();
		CasoAbertoCockpitTO casoTotalFila = new CasoAbertoCockpitTO();
		casoTotal.setTipoCaso(TOTAL);
		casoTotal.setFlagFila(Boolean.FALSE);
		casoTotal.setIdOperacao(idOperacao);
		casoTotalFila.setNomeFilaAtendimento(TOTAL);
		casoTotalFila.setFlagFila(Boolean.TRUE);
		casoTotalFila.setIdOperacao(idOperacao);

		Map<String, CasoAbertoCockpitTO> mapCasoAberto = new HashMap<>();
		Map<String, CasoAbertoCockpitTO> mapCasoAbertoFila = new HashMap<>();
		
		for (CasoTO caso : casoList) {
			try {
			
				if (mapCasoAbertoPorOperacao.containsKey(caso.getIdOperacao())) {
					mapCasoAberto = mapCasoAbertoPorOperacao.get(caso.getIdOperacao());
				}
	
				if (mapCasoAbertoFilaPorOperacao.containsKey(caso.getIdOperacao())) {
					mapCasoAbertoFila = mapCasoAbertoFilaPorOperacao.get(caso.getIdOperacao());
				}
	
				Double porcentagemSla = caso.getPorcentagemSla();
				CasoAbertoCockpitTO casoAbertoCockpit = mapCasoAberto.get(caso.getNomeTipoCaso());
				CasoAbertoCockpitTO casoAbertoCockpitFila = mapCasoAbertoFila.get(caso.getNomeConfiguracaoFila());
	
				if (casoAbertoCockpit == null) {
					casoAbertoCockpit = new CasoAbertoCockpitTO();
					casoAbertoCockpit.setTipoCaso(caso.getNomeTipoCaso());
					casoAbertoCockpit.setFlagFila(Boolean.FALSE);
				}
	
				if (casoAbertoCockpitFila == null) {
					casoAbertoCockpitFila = new CasoAbertoCockpitTO();
					casoAbertoCockpitFila.setNomeFilaAtendimento(caso.getNomeConfiguracaoFila());
					casoAbertoCockpitFila.setFlagFila(Boolean.TRUE);
				}
				
				casoAbertoCockpit.getCasosDetalhados().add(caso);
				casoAbertoCockpitFila.getCasosDetalhados().add(caso);
	
				casoAbertoCockpit.setIdOperacao(caso.getIdOperacao());
				casoAbertoCockpitFila.setIdOperacao(caso.getIdOperacao());
	
				// verifica a qual coluna pertence a porcentagem para relatorio por tipo manifestacao
				verificaPorcentagemPorColuna(coluna1, coluna2, coluna3, coluna4, coluna5, coluna6, casoTotal, porcentagemSla, casoAbertoCockpit);
	
				// verifica a qual coluna pertence a porcentagem para relatorio por fila atendimento
				verificaPorcentagemPorColuna(coluna1, coluna2, coluna3, coluna4, coluna5, coluna6, casoTotalFila, porcentagemSla, casoAbertoCockpitFila);
	
				casoAbertoCockpit.calculaTotalPercentual(casoList.size());
				casoAbertoCockpitFila.calculaTotalPercentual(casoList.size());
	
				mapCasoAberto.put(caso.getNomeTipoCaso(), casoAbertoCockpit);
				mapCasoAbertoFila.put(caso.getNomeConfiguracaoFila(), casoAbertoCockpitFila);
	
				mapCasoAbertoPorOperacao.put(caso.getIdOperacao(), mapCasoAberto);
				mapCasoAbertoFilaPorOperacao.put(caso.getIdOperacao(), mapCasoAbertoFila);
			
			} catch(Exception e) {
				StringBuilder errors = new StringBuilder("[Operação: ");
				errors.append(idOperacao);
				errors.append("] ");
				errors.append(String.format( "[Id Caso: %d ]", caso.getIdCaso()));
				errors.append(e.getMessage());
				logger.log(Level.SEVERE, errors.toString(), e);
				throw new Exception(e);
			}
		}

		casoTotal.calculaTotalPercentual(casoTotal.getQtdTotal());
		casoTotalFila.calculaTotalPercentual(casoTotalFila.getQtdTotal());
		mapCasoAberto.put(casoTotal.getTipoCaso(), casoTotal);
		mapCasoAbertoFila.put(casoTotalFila.getNomeFilaAtendimento(), casoTotalFila);

		ArrayList<CasoAbertoCockpitTO> salvaListCasoAbertoCockpit = new ArrayList<CasoAbertoCockpitTO>(mapCasoAberto.values());
		salvaListCasoAbertoCockpit.addAll(mapCasoAbertoFila.values());

		// Remove antes para inserir novamente
		Date dataBanco = dao.getDataBanco();
		
		dao.deleteDetalhe(dataBanco, idOperacao);
		dao.delete(dataBanco, idOperacao);
		
		dao.insert(salvaListCasoAbertoCockpit, idOperacao);
		
		// Insere casos aberto cockpit detalhe
		List<CasoAbertoCockpitDetalheTO> casosAbertosCockpitDetalhe = new ArrayList<CasoAbertoCockpitDetalheTO>();
		
		List<CasoAbertoCockpitTO> itensInseridos =  dao.getListCasoAberto(dataBanco);
		
		if (salvaListCasoAbertoCockpit != null && itensInseridos != null) {
			for (CasoAbertoCockpitTO item : salvaListCasoAbertoCockpit) {
				
				for (CasoAbertoCockpitTO casoAbertoCockpitTO : itensInseridos) {
					
					if (item.equalsProperties(casoAbertoCockpitTO)) {
						item.setIdCasoAbertoCockpit(casoAbertoCockpitTO.getIdCasoAbertoCockpit());
					}
				}
			}
		}
		
		for (CasoAbertoCockpitTO casoAbertoCockpitTO : salvaListCasoAbertoCockpit) {
			for (CasoTO casoTO : casoAbertoCockpitTO.getCasosDetalhados()) {
				CasoAbertoCockpitDetalheTO casoAbertoDetalheTO = new CasoAbertoCockpitDetalheTO();
				casoAbertoDetalheTO.setIdCasoAbertoCockpit(casoAbertoCockpitTO.getIdCasoAbertoCockpit());
				casoAbertoDetalheTO.setIdCaso(casoTO.getIdCaso());
				casoAbertoDetalheTO.setIdExterno(casoTO.getIdExterno());
				casoAbertoDetalheTO.setIdTipoCaso(casoTO.getIdTipoCaso());
				casoAbertoDetalheTO.setTipoCaso(casoTO.getNomeTipoCaso());
				casoAbertoDetalheTO.setIdConfiguracaoFila(casoTO.getIdConfiguracaoFila());
				casoAbertoDetalheTO.setConfiguracaoFila(casoTO.getNomeConfiguracaoFila());
				casoAbertoDetalheTO.setPercentual(casoTO.getPorcentagemSla());
				casoAbertoDetalheTO.setIdOperacao(casoTO.getIdOperacao());
				
				casosAbertosCockpitDetalhe.add(casoAbertoDetalheTO);
			}
		}
		dao.insertDetalhe(casosAbertosCockpitDetalhe, idOperacao);
	}

	/**
	 * Verifica a qual coluna pertence a porcentagem
	 * 
	 * @param coluna1
	 * @param coluna2
	 * @param coluna3
	 * @param coluna4
	 * @param coluna5
	 * @param coluna6
	 * @param casoTotal
	 * @param porcentagemSla
	 * @param casoAbertoCockpit
	 */
	private void verificaPorcentagemPorColuna(Double coluna1, Double coluna2, Double coluna3, Double coluna4, Double coluna5, Double coluna6,
			CasoAbertoCockpitTO casoTotal, Double porcentagemSla, CasoAbertoCockpitTO casoAbertoCockpit) {
		// Verifica a qual coluna pertence aquela porcentagem
		if (porcentagemSla <= coluna1) {
			casoAbertoCockpit.addQtdPrimeiroDia();
			casoTotal.addQtdPrimeiroDia();
		} else if (porcentagemSla <= coluna2) {
			casoAbertoCockpit.addQtdSegundoDia();
			casoTotal.addQtdSegundoDia();
		} else if (porcentagemSla <= coluna3) {
			casoAbertoCockpit.addQtdTerceiroDia();
			casoTotal.addQtdTerceiroDia();
		} else if (porcentagemSla <= coluna4) {
			casoAbertoCockpit.addQtdQuartoDia();
			casoTotal.addQtdQuartoDia();
		} else if (porcentagemSla <= coluna5) {
			casoAbertoCockpit.addQtdQuintoDia();
			casoTotal.addQtdQuintoDia();
		} else if (porcentagemSla <= coluna6) {
			casoAbertoCockpit.addQtdSextoDia();
			casoTotal.addQtdSextoDia();
		} else {
			casoAbertoCockpit.addQtdRestanteDia();
			casoTotal.addQtdRestanteDia();
		}
	}
}
