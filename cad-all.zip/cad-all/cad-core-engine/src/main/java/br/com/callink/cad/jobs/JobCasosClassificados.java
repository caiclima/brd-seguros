package br.com.callink.cad.jobs;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import br.com.callink.cad.dao.CasosClassificadosDAO;
import br.com.callink.cad.to.CasoClassificadoCockpitDetalheTO;
import br.com.callink.cad.to.CasoClassificadoCockpitTO;
import br.com.callink.cad.to.CasoClassificadoCockpitTipoCaso;
import br.com.callink.cad.to.CasoTO;
import br.com.callink.cad.util.CalculoSlaHelper;

/**
 * @author swb_halan
 * 
 */
public class JobCasosClassificados extends CadJob {

	private final Logger logger = Logger.getLogger(getClass().getName());
	private CasosClassificadosDAO dao;

	private void setUp() {
		if (dao == null) {
			dao = new CasosClassificadosDAO();
		}
	}

	@Override
	protected void process(Integer idTenant, Integer idOperacao, String nome) throws Exception {
		setUp();
		geraCasosClassificados(idOperacao);
	}

	public void geraCasosClassificados(Integer idOperacao) throws Exception {
		List<CasoTO> casosTO = dao.buscaCasosAbertos(idOperacao);
		logger.info(MessageFormat.format("Encontrado {0} casos abertos da operação {1}", casosTO.size(), idOperacao));
		
		CalculoSlaHelper calculoSlaUtil = new CalculoSlaHelper(getFeriadosOperacao(idOperacao),
				getJornadaOperacao(idOperacao),
				getSlaFilaOperacao(idOperacao));
		Date dataAtual = dao.getDataBanco();
		logger.info("Calculando SLA...");
		for (CasoTO to : casosTO) {
			try {
				if (to.getSlaFilaTO() != null && to.getSlaFilaTO().getIdSlaFila() != 0) {
					calculoSlaUtil.loadSla(to, dataAtual);
				}
			} catch (Exception e) {
				StringBuilder errors = new StringBuilder("[Operação: ");
				errors.append(idOperacao);
				errors.append("] ");
				errors.append(String.format("[Id Caso: %d ]", to.getIdCaso()));
				errors.append(e.getMessage());
				logger.log(Level.SEVERE, errors.toString(), e);
				throw new Exception(e);
			}
		}
		logger.info(MessageFormat.format("expurga casos classificados da operação {0}...", idOperacao));
		dao.expurgaCasoClassificadoDetalhePorOperacao(idOperacao);
		dao.expurgaCasoClassificadoPorOperacao(idOperacao);
		addRelatorioList(casosTO, idOperacao);
	}

	/**
	 * Procedimento que gera os dados computados para o relatorio Casos Classificados O SLA deve ser enviado em MINUTOS
	 * 
	 * @param Caso
	 * @param sla
	 * @throws Exception
	 */
	private void addRelatorioList(List<CasoTO> casoList, Integer idOperacao) throws Exception {
		logger.info("Gerando relatório... ");
		Map<String, CasoClassificadoCockpitTipoCaso> mapaCasosClassif = new HashMap<String, CasoClassificadoCockpitTipoCaso>();
		if (casoList == null || casoList.isEmpty()) {
			return;
		}
		List<CasoClassificadoCockpitTipoCaso> listaCasosManif = new ArrayList<CasoClassificadoCockpitTipoCaso>();
		Integer contadorDiv = 0;
		for (CasoTO caso : casoList) {
			
		try {
			CasoClassificadoCockpitTipoCaso casoClassificadoCockpitTipoCaso = mapaCasosClassif.get(caso.getIdOperacao()+caso.getNomeTipoCaso());

			if (casoClassificadoCockpitTipoCaso == null) {
				casoClassificadoCockpitTipoCaso = new CasoClassificadoCockpitTipoCaso();
				casoClassificadoCockpitTipoCaso.setTipoCaso(caso.getNomeTipoCaso());
				casoClassificadoCockpitTipoCaso.setNomeDiv("divClassificaCasoGrafico" + contadorDiv);
				casoClassificadoCockpitTipoCaso.setIdOperacao(caso.getIdOperacao());
				listaCasosManif.add(casoClassificadoCockpitTipoCaso);
				contadorDiv++;
			}

			if (caso.getPorcentagemSla() != null && caso.getPorcentagemSla().compareTo(100d) > 0) {
				casoClassificadoCockpitTipoCaso.addCasoClassificaForaPrazo(caso);
			} else {
				casoClassificadoCockpitTipoCaso.addCasoClassificaDentroPrazo(caso);
			}
			
			mapaCasosClassif.put(caso.getIdOperacao()+caso.getNomeTipoCaso(), casoClassificadoCockpitTipoCaso);
		} catch (Exception e) {
			StringBuilder errors = new StringBuilder();
			errors.append(String.format( "[Id Caso: %d ]", caso.getIdCaso()));
			errors.append(e.getMessage());
			logger.log(Level.SEVERE, errors.toString(), e);
			throw new Exception(e);
		}
		}
		
		List<CasoClassificadoCockpitDetalheTO> casosDetalhe = new ArrayList<CasoClassificadoCockpitDetalheTO>();
		
		List<CasoClassificadoCockpitTO> casosClassificadosCockpit = new ArrayList<CasoClassificadoCockpitTO>();
		for (CasoClassificadoCockpitTipoCaso casoManif : listaCasosManif) {
			casosClassificadosCockpit.addAll(montaTO(casoManif));
		}
		dao.saveCasoClassificado(casosClassificadosCockpit);
		
	List<CasoClassificadoCockpitTO> itensInseridos = dao.buscaCasosInserido(idOperacao);

		if (itensInseridos != null && casosClassificadosCockpit != null) {
			for (CasoClassificadoCockpitTO item : casosClassificadosCockpit) {

				for (CasoClassificadoCockpitTO casoClassificadoCockpitTO : itensInseridos) {

					if (item.equalsProperties(casoClassificadoCockpitTO)) {
						item.setIdCasoClassificado(casoClassificadoCockpitTO.getIdCasoClassificado());
					}
				}
			}
		}

		// Inserir detalhe
		for (CasoClassificadoCockpitTO casoClassCockpit : casosClassificadosCockpit) {
			for (CasoTO caso : casoClassCockpit.getCasos()) {
				CasoClassificadoCockpitDetalheTO casoDetalhe = new CasoClassificadoCockpitDetalheTO();
				casoDetalhe.setIdCasoClassificado(casoClassCockpit.getIdCasoClassificado());
				casoDetalhe.setIdCaso(caso.getIdCaso());
				casoDetalhe.setIdExterno(caso.getIdExterno());
				casoDetalhe.setIdTipoCaso(caso.getIdTipoCaso());
				casoDetalhe.setTipoCaso(caso.getNomeTipoCaso());
				casoDetalhe.setIdEventoPai(caso.getMotivo1());
				casoDetalhe.setEventoPai(caso.getMotivo1Nome());
				casoDetalhe.setFlagDentroPrazo(caso.getFlagDentroPrazo());
				casoDetalhe.setIdOperacao(caso.getIdOperacao());
				casosDetalhe.add(casoDetalhe);
			}
		}

		dao.saveCasoClassificadoDetalhe(casosDetalhe);
	}

	private List<CasoClassificadoCockpitTO> montaTO(CasoClassificadoCockpitTipoCaso caso) {
		List<CasoClassificadoCockpitTO> toReturn = new ArrayList<CasoClassificadoCockpitTO>();
		for (int i = 0; i < caso.getCasoClassificacaoCockpitList().size(); i++) {
			CasoClassificadoCockpitTO to = new CasoClassificadoCockpitTO();
			if (i == 0) {
				to.setFlagTotalizador(Boolean.TRUE);
			} else {
				to.setFlagTotalizador(Boolean.FALSE);
			}
			to.setTipoCaso(caso.getTipoCaso());
			to.setNomeDiv(caso.getNomeDiv());
			to.setTotalDentroPrazo(caso.getTotalDentroPrazo());
			to.setTotalForaPrazo(caso.getTotalForaPrazo());
			to.setPercentualTotalDentroPrazo(caso.getPercentualTotalDentroPrazo());
			to.setPercentualTotalForaPrazo(caso.getPercentualTotalForaPrazo());
			to.setIdOperacao(caso.getIdOperacao());
			to.setTop(caso.getCasoClassificacaoCockpitList().get(i).getTop());
			to.setEventoPai(caso.getCasoClassificacaoCockpitList().get(i).getEventoPai());
			to.setVolumeTotal(caso.getCasoClassificacaoCockpitList().get(i).getVolumeTotal());
			to.setVolumeDentroPrazo(caso.getCasoClassificacaoCockpitList().get(i).getVolumeDentroPrazo());
			to.setPercentualDentroPrazo(caso.getCasoClassificacaoCockpitList().get(i).getPercentualDentroPrazo());
			to.setVolumeForaPrazo(caso.getCasoClassificacaoCockpitList().get(i).getVolumeForaPrazo());
			to.setPercentualForaPrazo(caso.getCasoClassificacaoCockpitList().get(i).getPercentualForaPrazo());
			to.setCasos(caso.getCasoClassificacaoCockpitList().get(i).getCasos());
			toReturn.add(to);
		}
		return toReturn;
	}
}
