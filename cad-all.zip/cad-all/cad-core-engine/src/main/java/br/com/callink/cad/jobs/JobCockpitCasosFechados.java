package br.com.callink.cad.jobs;

import java.text.MessageFormat;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import br.com.callink.cad.dao.CockpitCasosFechadosDAO;
import br.com.callink.cad.to.CockpitCasosFechadosTO;

/**
 * @author swb_samuel
 * 
 */
public class JobCockpitCasosFechados extends CadJob {

	private Logger logger = Logger.getLogger(getClass().getName());
	private CockpitCasosFechadosDAO dao;

	private void setUp() {
		if (dao == null) {
			dao = new CockpitCasosFechadosDAO();
		}
	}

	@Override
	protected void process(Integer idTenant, Integer idOperacao, String nome) throws Exception {
		try {
			setUp();
			
			Date dataAtual = dao.getDataBanco();
			dao.expurgaCockpitCasosFechadosPorOperacao(idOperacao, dataAtual);
			List<CockpitCasosFechadosTO> dataSource = dao.retornaCasoFimSLADiario(dataAtual, idOperacao);
			
			if(dataSource != null && !dataSource.isEmpty()){
				logger.info(MessageFormat.format("Foram encontrados {0} casos.", dataSource.size()));
				dao.save(dataSource, dataAtual);
			}else{
				logger.info("Não foi encontrado nenhum caso fechado!");
			}
		}catch (Exception e) {
			StringBuilder errors = new StringBuilder("[Operação: ");
			errors.append(idOperacao);
			errors.append("] ");
			errors.append(e.getMessage());
			logger.log(Level.SEVERE, errors.toString(), e);
			throw new Exception(e);
		}
	}
}
