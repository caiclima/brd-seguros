package br.com.callink.cad.jobs;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import br.com.callink.cad.dao.EnfileiraCasoDAO;
import br.com.callink.cad.dao.EnviaCasoParaUsuarioSugeridoDAO;
import br.com.callink.cad.dao.ParametroSistemaDAO;
import br.com.callink.cad.sla.util.TempoUtilHelper;
import br.com.callink.cad.to.CasoTO;
import br.com.callink.cad.to.ConfiguracaoFilaTO;
import br.com.callink.cad.to.LogSlaCasoTO;
import br.com.callink.cad.to.LogTO;
import br.com.callink.cad.to.SlaFilaTO;
import br.com.callink.cad.util.CalculoSlaHelper;
import br.com.callink.cad.util.CollectionUtils;
import br.com.callink.cad.util.ConstantesParametro;

/**
 * @author swb_brunocamargo
 * @author swb_samuel
 * 
 */
public class JobEnfileiraCaso extends CadJob {

	private final Logger logger = Logger.getLogger(JobEnfileiraCaso.class.getName());

	private EnfileiraCasoDAO dao;
	private ParametroSistemaDAO parametroSistemaDAO;
	private CalculoSlaHelper calculoSlaUtil;
	private List<LogSlaCasoTO> listaLogSlaCasoInsert;

	private EnviaCasoParaUsuarioSugeridoDAO enviaCasoParaUsuarioSugeridoDAO;
	private List<LogTO> listaLogInsert;
	private List<CasoTO> listaCasos;

	private void setUp(Integer idOperacao) throws Exception {
		if (dao == null) {
			dao = new EnfileiraCasoDAO();
		}
		if (parametroSistemaDAO == null) {
			parametroSistemaDAO = new ParametroSistemaDAO();
		}
		if (calculoSlaUtil == null) {
			calculoSlaUtil = new CalculoSlaHelper(getFeriadosOperacao(idOperacao), getJornadaOperacao(idOperacao), getSlaFilaOperacao(idOperacao));
		}

		enviaCasoParaUsuarioSugeridoDAO = new EnviaCasoParaUsuarioSugeridoDAO();

		listaLogSlaCasoInsert = new ArrayList<LogSlaCasoTO>();
	}

	@Override
	public void process(Integer idTenant, Integer idOperacao, String nome) throws Exception {
		try {
			setUp(idOperacao);
			dao.classificaMotivos();
			classificaCasos(idOperacao);

			listaCasos = new ArrayList<CasoTO>();
			listaLogInsert = new ArrayList<LogTO>();

			List<CasoTO> _casos = enviaCasoParaUsuarioSugeridoDAO.buscaCasosAbertosComUsuarioSugerido(idOperacao);
			enviaCasoParaUsuarioSugerido(_casos);
			executaOperacoes();

			dao.updateCasosNaoClassificadosParaClassificar(idOperacao);
			dao.retiraCasosJaFinalizadosBuffer(idOperacao);

		} catch (Exception e) {
			StringBuilder errors = new StringBuilder("[Operação: ");
			errors.append(idOperacao);
			errors.append("] ");
			errors.append(e.getMessage());
			logger.log(Level.SEVERE, errors.toString(), e);
			throw new Exception(e);
		}
	}

	private void classificaCasos(Integer idOperacao) throws Exception {
		if (idOperacao != null) {
			String valorParametro = parametroSistemaDAO.findValorParametroSistemaOperacao(ConstantesParametro.FLAG_PROCESSANDO_SPA.getMnemonico(), idOperacao);
			boolean flagProcessandoSPA = valorParametro != null ? Boolean.valueOf(valorParametro) : false;

			// Verifica se o SPA não está carregando os mailings
			if (!flagProcessandoSPA) {

				// Removendo os casos das filas que necessitam de build.
				dao.removeFilaCasosBuild(idOperacao);
				dao.removeFilaClassificacaoCasoBuild(idOperacao);

				// Buscando todas as filas cadastradas e inserindo os casos
				// nessas filas.
				final List<ConfiguracaoFilaTO> configuracaoFilasEnfileiramento = dao.buscaFilaAtivaPorPrioridadeEOperacao(idOperacao);
				final Date dataAtual = dao.getDataBanco();
				SlaFilaTO slaFila = null;

				// Atualizando as filas para que não seja feito o build das
				// mesmas.
				dao.updateConfiguracaoFilaBuild(idOperacao);

				for (ConfiguracaoFilaTO confFila : configuracaoFilasEnfileiramento) {
					slaFila = buscaSlaFila(confFila.getIdConfiguracaoFila());

					if (slaFila != null) {
						if (slaFila.getFlagReIniciaSLA()) {
							/*
							 * Cria log do sla, em memória, para os casos que
							 * possuiam sla outra fila anterior
							 */
							criarLogSlaAnterior(confFila, idOperacao, dataAtual);

							/*
							 * Reinicia o SLA dos casos que possuiam sla de
							 * outra fila anterior
							 */
							reiniciarSla(confFila, idOperacao, dataAtual);
						}

						/*
						 * Enfileira os casos para nova fila e sla
						 */
						enfileiraCasos(confFila, slaFila, idOperacao, dataAtual);
						salvarLogSlaAnterior();
					}
				}

			} else {
				logger.info("CLASSIFICA CASO - AGUARDANDO IMPORTAÇÃO SPA.");
			}
		}
	}

	private void salvarLogSlaAnterior() throws Exception {
		if (CollectionUtils.hasValue(listaLogSlaCasoInsert)) {
			dao.insereLogSlaCaso(listaLogSlaCasoInsert);
		}
	}

	private void criarLogSlaAnterior(ConfiguracaoFilaTO confFila, Integer idOperacao, Date dataAtual) throws Exception {
		/*
		 * Busca os casos que se encaixam na configuração dessa fila que possua
		 * sla de outra fila
		 */
		final List<CasoTO> casos = buscaCasosFiltroPorFilaComSlaAntigo(confFila, idOperacao);

		if (CollectionUtils.hasValue(casos)) {
			for (CasoTO casoTO : casos) {
				try {
				if (casoTO.getSlaFilaTO() != null && casoTO.getSlaFilaTO().getIdSlaFila() != null) {
					LogSlaCasoTO logSlaCaso = new LogSlaCasoTO();

					// Cria log com SLA antigo, data abertura antiga, e nova
					// data de abertura
					logSlaCaso.setIdCaso(casoTO.getIdCaso());
					logSlaCaso.setDataAbertura(casoTO.getDataAbertura());
					logSlaCaso.setDataAlteracao(dataAtual);
					logSlaCaso.setIdSlaFila(casoTO.getSlaFilaTO().getIdSlaFila());
					logSlaCaso.setIdConfiguracaoFila(casoTO.getIdConfiguracaoFila());

					// Calcula o SLA do caso.
					CasoTO casoCalcSla = new CasoTO();
					casoCalcSla.setIdCaso(casoTO.getIdCaso());
					casoCalcSla.setIdOperacao(casoTO.getIdOperacao());
					casoCalcSla.setDataAbertura(logSlaCaso.getDataAbertura());
					casoCalcSla.setDataCadastro(casoTO.getDataCadastro());
					casoCalcSla.setIdExterno(casoTO.getIdExterno());
					casoCalcSla.setSlaFilaTO(new SlaFilaTO(casoTO.getSlaFilaTO().getIdSlaFila()));

					calculoSlaUtil.loadSla(casoCalcSla, dataAtual);

					logSlaCaso.setPercentualGasto(casoCalcSla.getPorcentagemSla());
					logSlaCaso.setTempoSla(TempoUtilHelper.retornaSlaMinutos(casoCalcSla.getSlaEmMinutos()));

					listaLogSlaCasoInsert.add(logSlaCaso);
				}
				
			}catch (Exception e) {
				StringBuilder errors = new StringBuilder();
				errors.append(String.format( "[Id Caso: %d ]", casoTO.getIdCaso()));
				errors.append(e.getMessage());
				logger.log(Level.SEVERE, errors.toString(), e);
				throw new Exception(e);
			}
			}
		}
	}

	private void reiniciarSla(ConfiguracaoFilaTO configuracaoFilaTO, Integer idOperacao, Date newDate) throws Exception {
		StringBuilder sqlFrom = gerarFrom(configuracaoFilaTO);
		StringBuilder sqlWhere = gerarWhere(configuracaoFilaTO);

		dao.reiniciarSlaDeCasosQueMudaramDeFila(newDate, sqlFrom.toString(), sqlWhere.toString(), idOperacao);
	}

	private void enfileiraCasos(ConfiguracaoFilaTO configuracaoFilaTO, SlaFilaTO slaFilaTO, Integer idOperacao, Date newDate) throws Exception {
		StringBuilder sqlFrom = gerarFrom(configuracaoFilaTO);
		StringBuilder sqlWhere = gerarWhere(configuracaoFilaTO);
		
		final List<Integer> idscasos = dao.buscaCasosParaEnfileirar(sqlFrom.toString(), sqlWhere.toString(), idOperacao, getDataInitJob());
		
		if (CollectionUtils.hasValue(idscasos)) {
			/*
			 * Enfileira os casos para a fila e insere log
			 */
			dao.enfileiraCasos(configuracaoFilaTO.getIdConfiguracaoFila(), slaFilaTO.getIdSlaFila(), idscasos);
			dao.insereLogDeClassificacao(idscasos, newDate);

			/*
			 * remove caso da fila_classificação e insere novamente em outra
			 * fila
			 */
			dao.removeFilaClassificaoCaso(idscasos);
			dao.insereCasoFila(configuracaoFilaTO.getIdConfiguracaoFila(), idscasos);
		}
	}

	private List<CasoTO> buscaCasosFiltroPorFilaComSlaAntigo(ConfiguracaoFilaTO configuracaoFilaTO, Integer idOperacao) throws Exception {
		StringBuilder sqlFrom = gerarFrom(configuracaoFilaTO);
		StringBuilder sqlWhere = gerarWhere(configuracaoFilaTO);

		return dao.buscaCasosFiltroPorFilaSemUsuario(sqlFrom.toString(), sqlWhere.toString(), idOperacao);
	}

	private StringBuilder gerarFrom(ConfiguracaoFilaTO configuracaoFilaTO) throws Exception {
		if (configuracaoFilaTO == null) {
			throw new Exception("A configuração do caso deve ser informada.");
		}

		String valorParametro = parametroSistemaDAO.findValorParametroSistema(ConstantesParametro.PARAM_FROM_CONSULTA_CASO.getMnemonico());
		StringBuilder sqlFrom = new StringBuilder();
		if (configuracaoFilaTO.getSqlFrom() != null && !configuracaoFilaTO.getSqlFrom().isEmpty()) {
			if(configuracaoFilaTO.getFlagSqlAvancado() == null || configuracaoFilaTO.getFlagSqlAvancado() == true) {
				sqlFrom.append(valorParametro).append(", ");
			}
			sqlFrom.append(configuracaoFilaTO.getSqlFrom());
		} else {
			sqlFrom.append(valorParametro);
		}

		if (sqlFrom.toString().isEmpty()) {
			throw new Exception("O FROM na ConfiguracaoFila não pode ser nulo, O parametro que configura o from no parametro de sistema e o from da fila estão nulos." + " Fila: " + configuracaoFilaTO.getNome() + " - ID " + configuracaoFilaTO.getIdConfiguracaoFila());
		}

		return sqlFrom;
	}

	private StringBuilder gerarWhere(ConfiguracaoFilaTO configuracaoFilaTO) throws Exception {
		if (configuracaoFilaTO == null) {
			throw new Exception("A configuração do caso deve ser informada.");
		}

		String valorParametro = parametroSistemaDAO.findValorParametroSistema(ConstantesParametro.PARAM_FILTER_CONSULTA_CASO.getMnemonico());
		StringBuilder sqlWhere = new StringBuilder();
		if (configuracaoFilaTO.getSqlWhere() != null && !configuracaoFilaTO.getSqlWhere().isEmpty()) {
			sqlWhere.append(valorParametro).append(" and ( ");
			sqlWhere.append(configuracaoFilaTO.getSqlWhere());
			sqlWhere.append(" ) ");
		} else {
			sqlWhere.append(valorParametro);
		}

		if (sqlWhere.toString().isEmpty()) {
			throw new Exception("O WHERE na ConfiguracaoFila não pode ser nulo,");
		}

		return sqlWhere;
	}

	private SlaFilaTO buscaSlaFila(Integer idConfiguracaoFila) throws Exception {
		SlaFilaTO slaFilaTO = dao.findSlaFilaByConfFilaAndDataFimNull(idConfiguracaoFila);
		
		if (slaFilaTO == null || slaFilaTO.getIdSlaFila() == null) {
			logger.log(Level.SEVERE, "Fila não possui Sla. Fila id: " + idConfiguracaoFila);
			//return null;
		}
		return slaFilaTO;
	}

	private void enviaCasoParaUsuarioSugerido(List<CasoTO> casos) throws Exception {
		if (CollectionUtils.hasValue(casos)) {
			for (CasoTO caso : casos) {
				
				try {
				
				if (caso.getIdUsuarioSugerido() != null) {
					boolean valido = enviaCasoParaUsuarioSugeridoDAO.existeUsuario(caso.getIdUsuarioSugerido());

					if (valido) {
						valido = enviaCasoParaUsuarioSugeridoDAO.possuiEquipe(caso.getIdUsuarioSugerido());

						if (valido) {
							valido = enviaCasoParaUsuarioSugeridoDAO.possuiOperacao(caso.getIdUsuarioSugerido());

							if (valido) {
								valido = enviaCasoParaUsuarioSugeridoDAO.atendeFila(caso.getIdUsuarioSugerido(), caso.getIdConfiguracaoFila());

								if (valido) {
									caso.setIdUsuario(caso.getIdUsuarioSugerido());

								} else {
									saveLog(caso, MessageFormat.format("Usuário sugerido: {0}, NÂO atende à fila do caso : {1}.", caso.getIdUsuarioSugerido().toString(), caso.getIdCaso().toString()));
								}

							} else {
								saveLog(caso, MessageFormat.format("Usuário sugerido: {0}, NÂO possui operação.", caso.getIdUsuarioSugerido().toString()));
							}

						} else {
							saveLog(caso, MessageFormat.format("Usuário sugerido: {0}, NÂO possui equipe.", caso.getIdUsuarioSugerido().toString()));
						}

					} else {
						saveLog(caso, MessageFormat.format("Usuário sugerido: {0}, NÂO existe.", caso.getIdUsuarioSugerido().toString()));
					}

					caso.setIdUsuarioSugerido(null);
					saveCaso(caso);
				}
			}catch (Exception e) {
				StringBuilder errors = new StringBuilder();
				errors.append(String.format( "[Id Caso: %d ]", caso.getIdCaso()));
				errors.append(e.getMessage());
				logger.log(Level.SEVERE, errors.toString(), e);
				throw new Exception(e);
			}
			}
		}
	}

	private void executaOperacoes() throws Exception {
		if (CollectionUtils.hasValue(listaCasos)) {
			enviaCasoParaUsuarioSugeridoDAO.atualizaUsuarioCaso(listaCasos);
		}
		if (CollectionUtils.hasValue(listaLogInsert)) {
			enviaCasoParaUsuarioSugeridoDAO.insereLog(listaLogInsert);
		}
	}

	private void saveCaso(CasoTO caso) {
		listaCasos.add(caso);
	}

	private void saveLog(CasoTO casoTO, String descricao) throws Exception {
		LogTO log = new LogTO();
		log.setIdCaso(casoTO.getIdCaso());
		log.setIdStatus(casoTO.getIdStatus());
		if (casoTO.getIdUsuario() != null && casoTO.getIdUsuario() != 0) {
			log.setIdUsuario(casoTO.getIdUsuario());
		}
		log.setIdConfiguracaoFila(casoTO.getIdConfiguracaoFila());
		log.setDescricao(descricao);
		log.setDataLog(enviaCasoParaUsuarioSugeridoDAO.getDataBanco());
		log.setDataAbertura(casoTO.getDataAbertura());
		log.setIdEvento(casoTO.getIdEvento());
		listaLogInsert.add(log);
	}
}
