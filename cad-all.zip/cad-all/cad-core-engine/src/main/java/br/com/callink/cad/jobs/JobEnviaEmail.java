package br.com.callink.cad.jobs;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.rpc.ServiceException;

import org.quartz.JobExecutionException;

import br.com.callink.cad.crypto.impl.RSACryptoImpl;
import br.com.callink.cad.dao.ConfiguracaoCaixaEmailDAO;
import br.com.callink.cad.dao.EnviaEmailDAO;
import br.com.callink.cad.dao.ParametroSistemaDAO;
import br.com.callink.cad.to.AnexoTO;
import br.com.callink.cad.to.ConfiguracaoCaixaEmailTO;
import br.com.callink.cad.to.EmailTO;
import br.com.callink.cad.util.ArquivoUtils;
import br.com.callink.cad.util.Constantes;
import br.com.callink.cad.util.SendEmail;
import br.com.callink.cad.util.TransactionUtils;

/**
 * @author swb_brunocamargo
 * 
 */
public class JobEnviaEmail extends CadJob {

	private Logger logger = Logger.getLogger(JobEnviaEmail.class.getName());
	private EnviaEmailDAO dao;
	private ParametroSistemaDAO parametroSistemaDAO;
	private ConfiguracaoCaixaEmailDAO configuracaoCaixaEmailDAO;

	private Map<Integer, Boolean> mapUpdtEmail;
	private List<EmailTO> listUpdtEmail;

	private void setUp() throws Exception {
		if (dao == null) {
			dao = new EnviaEmailDAO();
		}
		if (parametroSistemaDAO == null) {
			parametroSistemaDAO = new ParametroSistemaDAO();
		}
		if (configuracaoCaixaEmailDAO == null) {
			configuracaoCaixaEmailDAO = new ConfiguracaoCaixaEmailDAO();
		}
		if (mapUpdtEmail == null) {
			mapUpdtEmail = new LinkedHashMap<Integer, Boolean>();
		}
		if (listUpdtEmail == null) {
			listUpdtEmail = new ArrayList<EmailTO>();
		}
	}

	@Override
	protected void process(Integer idTenant, Integer idOperacao, String nome) throws Exception {
		setUp();
		enviaEmail(idOperacao);
	}

	private List<EmailTO> findEmailsEnvioPendente(Integer idOperacao) throws JobExecutionException {
		try {
			return dao.findEmailsEnvioPendente(Boolean.TRUE, Boolean.TRUE, Boolean.FALSE, idOperacao);
		} catch (Exception e) {
			throw new JobExecutionException("Erro ao buscar emails a serem enviados.", e);
		}
	}

	public void enviaEmail(Integer idOperacao) throws Exception {
		String nomeCaixaEmail = "";
		SendEmail sendEmail = null;
		try {

			String parametroEmailUsuario = null;
			String parametroEmailSenha = null;
			String parametroEmailTransportProtocol = null;
			String parametroEmailSmtpHost = null;
			String parametroEmailSmtpPort = null;
			String parametroEmailSmtpAuth = null;
			Boolean ssl = Boolean.FALSE;

			ConfiguracaoCaixaEmailTO configuracaoCaixaEmailTO = null;

			List<EmailTO> emailsEnvioPendente = findEmailsEnvioPendente(idOperacao);

			if (!emailsEnvioPendente.isEmpty()) {
				for (EmailTO email : emailsEnvioPendente) {
					if (email == null) {
						continue;
					}

					if (email != null && email.getIdConfiguracaoCaixaEmail() != null && !email.getIdConfiguracaoCaixaEmail().equals(0)) {

						configuracaoCaixaEmailTO = configuracaoCaixaEmailDAO.findById(email.getIdConfiguracaoCaixaEmail());
					} else {

						configuracaoCaixaEmailTO = configuracaoCaixaEmailDAO.findAtivosPrincipalPorOperacao(idOperacao, Boolean.TRUE);
					}

					nomeCaixaEmail = "Caixa de Email " + (configuracaoCaixaEmailTO != null ? configuracaoCaixaEmailTO.getEmail() : " - ") + "ID configuração caixa de Email: " + (configuracaoCaixaEmailTO != null ? configuracaoCaixaEmailTO.getIdConfiguracaoCaixaEmail().toString() : "-");

					if (configuracaoCaixaEmailTO == null || configuracaoCaixaEmailTO.getIdConfiguracaoCaixaEmail() == null) {

						logger.info("Email não enviado motivo: Email id: " + email.getIdEmail() + " não possui caixa de email e operação id: " + idOperacao + " não possui caixa de email principal.");

						email.setFlagErroEnvio(Boolean.TRUE);
						mapUpdtEmail.put(email.getIdEmail(), Boolean.valueOf(email.getFlagErroEnvio()));
						continue;
					}

					parametroEmailUsuario = configuracaoCaixaEmailTO.getUsuarioConfiguracaoCaixaEmail();
					parametroEmailSenha = new RSACryptoImpl().decrypt(configuracaoCaixaEmailTO.getSenhaConfiguracaoCaixaEmail());
					parametroEmailTransportProtocol = configuracaoCaixaEmailTO.getProtocolConfiguracaoCaixaEmail();
					parametroEmailSmtpHost = configuracaoCaixaEmailTO.getSmtpConfiguracaoCaixaEmail();
					parametroEmailSmtpPort = configuracaoCaixaEmailTO.getSmtpPortConfiguracaoCaixaEmail();
					parametroEmailSmtpAuth = configuracaoCaixaEmailTO.getAuthConfiguracaoCaixaEmail();
					ssl = configuracaoCaixaEmailTO.getFlagSsl();
					sendEmail = new SendEmail(parametroEmailUsuario, parametroEmailSenha, parametroEmailTransportProtocol, parametroEmailSmtpHost, parametroEmailSmtpAuth, parametroEmailSmtpPort, ssl);

					Integer tentativasEnvio = 0;
					// enqto a FlagEnvioPendente estiver ligada, tentar enviar
					while (email.getFlagEnvioPendente()) {
						try {
							// se ja houveram mais de 5 tentativas de enviar o
							// email..
							if (tentativasEnvio > 5) {

								email.setFlagErroEnvio(Boolean.TRUE);
								mapUpdtEmail.put(email.getIdEmail(), Boolean.valueOf(email.getFlagErroEnvio()));

								// seta essa flag para sair do laço
								email.setFlagEnvioPendente(Boolean.FALSE);
								throw new ServiceException("Email excedeu tentativas de envio. ID Email: " + email.getIdEmail());
							}

							List<AnexoTO> anexos = new ArrayList<AnexoTO>();

							// tentando enviar o email
							if (email.getGrupoAnexo() != null && email.getGrupoAnexo().getIdGrupoAnexo() != null && email.getGrupoAnexo().getIdGrupoAnexo() != 0) {

								anexos = dao.buscaPorGrupoAnexo(email.getGrupoAnexo().getIdGrupoAnexo());

								if (anexos != null && anexos.size() > 0) {
									carregaBytesAnexo(anexos);
								}
							}

							sendEmail.send(email.getRemetente(), email.getDestinatario(), email.getDestinatarioCopia(), email.getAssunto(), email.getConteudo(), anexos);

							email.setFlagEnvioPendente(Boolean.FALSE);
							email.setFlagErroEnvio(Boolean.FALSE);
							listUpdtEmail.add(email);

						} catch (Exception ex) {
							// caso haja erro no envio de email, começa a
							// incrementar tentativas de envio
							StringBuilder errors = new StringBuilder("[Operação: ");
							errors.append(idOperacao);
							errors.append("] ");
							errors.append(String.format(" Id configuracao Caixa Email: %d ", email.getIdConfiguracaoCaixaEmail()));
							errors.append(ex.getMessage());
							logger.log(Level.SEVERE, errors.toString(), ex);
							
							tentativasEnvio++;
						}
					}
				}
			}
			for (Map<Integer, Boolean> map : TransactionUtils.subMaps(mapUpdtEmail, Constantes.NRO_REGISTROS_COMMIT)) {
				dao.updateFlagErroEnvio(map);
			}
			for (List<EmailTO> list : TransactionUtils.subLists(listUpdtEmail, Constantes.NRO_REGISTROS_COMMIT)) {
				dao.updateEmail(list);
			}
		} catch (Exception ex) {
			StringBuilder errors = new StringBuilder("[Operação: ");
			errors.append(idOperacao);
			errors.append("] ");
			errors.append(ex.getMessage());
			logger.log(Level.SEVERE, errors.toString(), ex);
			throw new Exception(ex);
		}finally{
			logger.log(Level.WARNING, nomeCaixaEmail);
		}
	}

	public List<AnexoTO> carregaBytesAnexo(List<AnexoTO> anexos) throws ServiceException {
		
			for (AnexoTO anx : anexos) {
				try {
					String caminho = null;
					if (anx.getDiretorio().lastIndexOf("\\") + 1 == anx.getDiretorio().length()) {
						caminho = anx.getDiretorio() + anx.getNomeFake();
					} else {
						caminho = anx.getDiretorio() + "\\" + anx.getNomeFake();
					}
					anx.setDados(ArquivoUtils.getBytesArquivo(caminho));
					
				} catch (IOException ex) {
					logger.log(Level.SEVERE, String.format("Erro ao carregar anexo com id: %d", anx.getIdAnexo()), ex);
					throw new ServiceException("Falha ao carregar anexo.", ex);
				}
			}
		return anexos;
	}

}
