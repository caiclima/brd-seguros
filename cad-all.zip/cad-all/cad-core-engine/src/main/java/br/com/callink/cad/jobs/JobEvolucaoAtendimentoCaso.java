package br.com.callink.cad.jobs;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.quartz.JobExecutionException;

import br.com.callink.cad.dao.EvolucaoAtendimentoCasoDAO;
import br.com.callink.cad.to.CasoTO;
import br.com.callink.cad.to.EvolucaoAtendimentoDetalheTO;
import br.com.callink.cad.to.EvolucaoAtendimentoTO;
import br.com.callink.cad.util.CalculoSlaHelper;
import br.com.callink.cad.util.Constantes;
import br.com.callink.cad.util.TransactionUtils;

/**
 * @author swb_halan
 * 
 */
public class JobEvolucaoAtendimentoCaso extends CadJob {

	private final Logger logger = Logger.getLogger(getClass().getName());
	private EvolucaoAtendimentoCasoDAO dao;

	private static final String ENTRANTE = "NOVO";
	private static final String REABERTO = "REABERTO";
	private static final String PENDENTE = "PENDENTE";
	private static final String FECHADO = "FECHADO";

	private void setUp() {
		if (dao == null) {
			dao = new EvolucaoAtendimentoCasoDAO();
		}
	}

	@Override
	protected void process(Integer idTenant, Integer idOperacao, String nome) throws Exception {
		setUp();
		geraEvolucaoAtendimento(idOperacao);
	}

	public void geraEvolucaoAtendimento(Integer idOperacao) throws JobExecutionException {
		try {
			logger.info("Buscando casos entrantes do dia...");
			List<CasoTO> casosEntrantes = dao.buscaCasoEntranteDia(idOperacao);
			logger.info("Buscando casos reabertos do dia...");
			List<CasoTO> casosReabertos = dao.buscaCasoReabertoDia(idOperacao);
			logger.info("Buscando casos abertos sem pendencia...");
			List<CasoTO> casosPendentes = dao.buscaCasoAbertoSemPendencia(idOperacao);
			Date dataAtual = dao.getDataBanco();
			List<CasoTO> casoList = new ArrayList<CasoTO>();

			logger.info("Calculando SLA de casos pendentes...");
			CalculoSlaHelper calculoSlaUtil = new CalculoSlaHelper(getFeriadosOperacao(idOperacao), getJornadaOperacao(idOperacao), getSlaFilaOperacao(idOperacao));
			for (CasoTO caso : casosPendentes) {
				try {
					if (caso.getSlaFilaTO() != null && caso.getSlaFilaTO().getIdSlaFila() != 0) {
						calculoSlaUtil.loadSla(caso, dataAtual);
					}
					casoList.add(caso);
				} catch (Exception e) {
					StringBuilder errors = new StringBuilder("[Operação: ");
					errors.append(idOperacao);
					errors.append("] ");
					errors.append(String.format("[Id Caso: %d ]", caso.getIdCaso()));
					errors.append(e.getMessage());
					logger.log(Level.SEVERE, errors.toString(), e);
					throw new Exception(e);
				}
			}

			logger.info("Buscando casos fechados do dia e calculando SLA...");
			List<CasoTO> casosFechados = new ArrayList<>();
			for (CasoTO to : dao.buscaCasosFechadosNoDia(idOperacao)) {
				try {
					if (to.getSlaFilaTO() != null && to.getSlaFilaTO().getIdSlaFila() != 0) {
						calculoSlaUtil.loadSla(to, dataAtual);
					}
					casosFechados.add(to);
				} catch (Exception e) {
					StringBuilder errors = new StringBuilder("[Operação: ");
					errors.append(idOperacao);
					errors.append("] ");
					errors.append(String.format("[Id Caso: %d ]", to.getIdCaso()));
					errors.append(e.getMessage());
					logger.log(Level.SEVERE, errors.toString(), e);
					throw new Exception(e);
				}
			}

			logger.info("Buscando casos pendentes de checagem...");
			List<CasoTO> casosFechadosPendente = dao.buscaCasosPendenteChecagem(idOperacao);
			if (casosFechadosPendente != null) {
				casosFechados.addAll(casosFechadosPendente);
			}

			Map<String, EvolucaoAtendimentoTO> agrupadorTipos = new HashMap<String, EvolucaoAtendimentoTO>();
			Map<String, EvolucaoAtendimentoTO> agrupadorFilas = new HashMap<String, EvolucaoAtendimentoTO>();

			List<EvolucaoAtendimentoTO> evolucaoAtendimentos = new ArrayList<EvolucaoAtendimentoTO>();
			Calendar calendar = new GregorianCalendar(Calendar.getInstance().get(Calendar.YEAR), Calendar.getInstance().get(Calendar.MONTH), Calendar.getInstance().get(Calendar.DAY_OF_MONTH));

			logger.info("Processando evolução atendimento...");

			try {
				EvolucaoAtendimentoTO evolucaoAtendimento = null;

				for (CasoTO caso : casosEntrantes) {
					if (caso.getIdTipoCaso() != null) {
						if (agrupadorTipos.containsKey(ENTRANTE+caso.getIdTipoCaso())) {
							evolucaoAtendimento = agrupadorTipos.get(ENTRANTE+caso.getIdTipoCaso());
						} else {
							evolucaoAtendimento = new EvolucaoAtendimentoTO();
							evolucaoAtendimento.setTipoCaso(caso.getNomeTipoCaso());
							evolucaoAtendimento.setOperacao(caso.getIdOperacao());
							evolucaoAtendimento.setFlagFiltroFila(Boolean.FALSE);

							agrupadorTipos.put(ENTRANTE+caso.getIdTipoCaso(), evolucaoAtendimento);
						}

						evolucaoAtendimento.addTotalEntrantes();

						// Adiciona em uma lista para incluir na tabela
						// detalhada posteriormente
						caso.setMnemonico(ENTRANTE);
						evolucaoAtendimento.getCasosDetalhados().add(caso);
					}

					if (caso.getIdConfiguracaoFila() != null) {
						if (agrupadorFilas.containsKey(ENTRANTE+caso.getIdConfiguracaoFila())) {
							evolucaoAtendimento = agrupadorFilas.get(ENTRANTE+caso.getIdConfiguracaoFila());
						} else {
							evolucaoAtendimento = new EvolucaoAtendimentoTO();
							evolucaoAtendimento.setConfiguracaoFila(caso.getNomeConfiguracaoFila());
							evolucaoAtendimento.setOperacao(caso.getIdOperacao());
							evolucaoAtendimento.setFlagFiltroFila(Boolean.TRUE);

							agrupadorFilas.put(ENTRANTE+caso.getIdConfiguracaoFila(), evolucaoAtendimento);
						}

						evolucaoAtendimento.addTotalEntrantes();

						// Adiciona em uma lista para incluir na tabela
						// detalhada posteriormente
						caso.setMnemonico(ENTRANTE);
						evolucaoAtendimento.getCasosDetalhados().add(caso);
					}
				}

				for (CasoTO caso : casosReabertos) {
					if (caso.getIdTipoCaso() != null) {
						if (agrupadorTipos.containsKey(REABERTO+caso.getIdTipoCaso())) {
							evolucaoAtendimento = agrupadorTipos.get(REABERTO+caso.getIdTipoCaso());
						} else {
							evolucaoAtendimento = new EvolucaoAtendimentoTO();
							evolucaoAtendimento.setTipoCaso(caso.getNomeTipoCaso());
							evolucaoAtendimento.setOperacao(caso.getIdOperacao());
							evolucaoAtendimento.setFlagFiltroFila(Boolean.FALSE);

							agrupadorTipos.put(REABERTO+caso.getIdTipoCaso(), evolucaoAtendimento);
						}

						evolucaoAtendimento.addTotalReabertos();

						// Adiciona em uma lista para incluir na tabela
						// detalhada posteriormente
						caso.setMnemonico(REABERTO);
						evolucaoAtendimento.getCasosDetalhados().add(caso);
					}

					if (caso.getIdConfiguracaoFila() != null) {
						if (agrupadorFilas.containsKey(REABERTO+caso.getIdConfiguracaoFila())) {
							evolucaoAtendimento = agrupadorFilas.get(REABERTO+caso.getIdConfiguracaoFila());
						} else {
							evolucaoAtendimento = new EvolucaoAtendimentoTO();
							evolucaoAtendimento.setConfiguracaoFila(caso.getNomeConfiguracaoFila());
							evolucaoAtendimento.setOperacao(caso.getIdOperacao());
							evolucaoAtendimento.setFlagFiltroFila(Boolean.TRUE);

							agrupadorFilas.put(REABERTO+caso.getIdConfiguracaoFila(), evolucaoAtendimento);
						}

						evolucaoAtendimento.addTotalReabertos();

						// Adiciona em uma lista para incluir na tabela
						// detalhada posteriormente
						caso.setMnemonico(REABERTO);
						evolucaoAtendimento.getCasosDetalhados().add(caso);
					}
				}

				for (CasoTO caso : casosPendentes) {
					if (caso.getIdTipoCaso() != null) {
						if (agrupadorTipos.containsKey(PENDENTE+caso.getIdTipoCaso())) {
							evolucaoAtendimento = agrupadorTipos.get(PENDENTE+caso.getIdTipoCaso());
						} else {
							evolucaoAtendimento = new EvolucaoAtendimentoTO();
							evolucaoAtendimento.setTipoCaso(caso.getNomeTipoCaso());
							evolucaoAtendimento.setOperacao(caso.getIdOperacao());
							evolucaoAtendimento.setFlagFiltroFila(Boolean.FALSE);

							agrupadorTipos.put(PENDENTE+caso.getIdTipoCaso(), evolucaoAtendimento);
						}

						if (caso.getPorcentagemSla() != null && caso.getPorcentagemSla() > 100) {
							evolucaoAtendimento.addPendenteForaPrazo();
						} else {
							evolucaoAtendimento.addPendenteDentroPrazo();
						}

						// Adiciona em uma lista para incluir na tabela
						// detalhada posteriormente
						caso.setMnemonico(PENDENTE);
						evolucaoAtendimento.getCasosDetalhados().add(caso);
					}

					if (caso.getIdConfiguracaoFila() != null) {
						if (agrupadorFilas.containsKey(PENDENTE+caso.getIdConfiguracaoFila())) {
							evolucaoAtendimento = agrupadorFilas.get(PENDENTE+caso.getIdConfiguracaoFila());
						} else {
							evolucaoAtendimento = new EvolucaoAtendimentoTO();
							evolucaoAtendimento.setConfiguracaoFila(caso.getNomeConfiguracaoFila());
							evolucaoAtendimento.setOperacao(caso.getIdOperacao());
							evolucaoAtendimento.setFlagFiltroFila(Boolean.TRUE);

							agrupadorFilas.put(PENDENTE+caso.getIdConfiguracaoFila(), evolucaoAtendimento);
						}

						if (caso.getPorcentagemSla() != null && caso.getPorcentagemSla() > 100) {
							evolucaoAtendimento.addPendenteForaPrazo();
						} else {
							evolucaoAtendimento.addPendenteDentroPrazo();
						}

						// Adiciona em uma lista para incluir na tabela
						// detalhada posteriormente
						caso.setMnemonico(PENDENTE);
						evolucaoAtendimento.getCasosDetalhados().add(caso);
					}
				}

				for (CasoTO caso : casosFechados) {
					if (caso.getIdTipoCaso() != null) {
						if (agrupadorTipos.containsKey(FECHADO+caso.getIdTipoCaso())) {
							evolucaoAtendimento = agrupadorTipos.get(FECHADO+caso.getIdTipoCaso());
						} else {
							evolucaoAtendimento = new EvolucaoAtendimentoTO();
							evolucaoAtendimento.setTipoCaso(caso.getNomeTipoCaso());
							evolucaoAtendimento.setOperacao(caso.getIdOperacao());
							evolucaoAtendimento.setFlagFiltroFila(Boolean.FALSE);

							agrupadorTipos.put(FECHADO+caso.getIdTipoCaso(), evolucaoAtendimento);
						}

						if (caso.getPorcentagemSla() != null && caso.getPorcentagemSla() > 100) {
							evolucaoAtendimento.addFechadoForaPrazo();
						} else {
							evolucaoAtendimento.addFechadoDentroPrazo();
						}

						// Adiciona em uma lista para incluir na tabela
						// detalhada posteriormente
						caso.setMnemonico(FECHADO);
						evolucaoAtendimento.getCasosDetalhados().add(caso);
					}

					if (caso.getIdConfiguracaoFila() != null) {
						if (agrupadorFilas.containsKey(FECHADO+caso.getIdConfiguracaoFila())) {
							evolucaoAtendimento = agrupadorFilas.get(FECHADO+caso.getIdConfiguracaoFila());
						} else {
							evolucaoAtendimento = new EvolucaoAtendimentoTO();
							evolucaoAtendimento.setConfiguracaoFila(caso.getNomeConfiguracaoFila());
							evolucaoAtendimento.setOperacao(caso.getIdOperacao());
							evolucaoAtendimento.setFlagFiltroFila(Boolean.TRUE);

							agrupadorFilas.put(FECHADO+caso.getIdConfiguracaoFila(), evolucaoAtendimento);
						}

						if (caso.getPorcentagemSla() != null && caso.getPorcentagemSla() > 100) {
							evolucaoAtendimento.addFechadoForaPrazo();
						} else {
							evolucaoAtendimento.addFechadoDentroPrazo();
						}

						// Adiciona em uma lista para incluir na tabela
						// detalhada posteriormente
						caso.setMnemonico(FECHADO);
						evolucaoAtendimento.getCasosDetalhados().add(caso);
					}
				}

				for (String key : agrupadorTipos.keySet()) {
					evolucaoAtendimento = agrupadorTipos.get(key);

					evolucaoAtendimento.setDataRelatorio(calendar.getTime());
					evolucaoAtendimento.calculaSaldo();
					evolucaoAtendimentos.add(evolucaoAtendimento);
				}

				for (String key : agrupadorFilas.keySet()) {
					evolucaoAtendimento = agrupadorFilas.get(key);

					evolucaoAtendimento.setDataRelatorio(calendar.getTime());
					evolucaoAtendimento.calculaSaldo();
					evolucaoAtendimentos.add(evolucaoAtendimento);
				}

			} catch (Exception e) {
				StringBuilder errors = new StringBuilder("[Operação: ");
				errors.append(idOperacao);
				errors.append("] ");
				errors.append(e.getMessage());
				logger.log(Level.SEVERE, errors.toString(), e);
				throw new Exception(e);
			}

			// Expurga dados do dia para inserir novamente
			dao.removeEvolucaoAtendimentoDetalhe(idOperacao);
			dao.removeEvolucaoAtendimento(idOperacao);

			for (List<EvolucaoAtendimentoTO> list : TransactionUtils.subLists(evolucaoAtendimentos, Constantes.NRO_REGISTROS_COMMIT)) {
				dao.saveEvolucaoAtendimento(list);
			}

			// Insere relatorio detalhado de evolucao atendimento
			List<EvolucaoAtendimentoDetalheTO> listEvolucaoDetalhe = new ArrayList<EvolucaoAtendimentoDetalheTO>();

			for (EvolucaoAtendimentoTO evo : evolucaoAtendimentos) {
				for (CasoTO caso : evo.getCasosDetalhados()) {
					EvolucaoAtendimentoDetalheTO evolucaoDetalhe = new EvolucaoAtendimentoDetalheTO();
					evolucaoDetalhe.setIdEvolucaoAtendimento(evo.getIdEvolucaoAtendimento());
					evolucaoDetalhe.setIdCaso(caso.getIdCaso());
					evolucaoDetalhe.setIdExterno(caso.getIdExterno());
					evolucaoDetalhe.setIdTipoCaso(caso.getIdTipoCaso());
					evolucaoDetalhe.setTipoCaso(caso.getNomeTipoCaso());
					evolucaoDetalhe.setIdConfiguracaoFila(caso.getIdConfiguracaoFila());
					evolucaoDetalhe.setConfiguracaoFila(caso.getNomeConfiguracaoFila());
					evolucaoDetalhe.setMnemonico(caso.getMnemonico());
					evolucaoDetalhe.setFlagDentroPrazo(caso.getFlagDentroPrazo());
					evolucaoDetalhe.setIdOperacao(caso.getIdOperacao());
					evolucaoDetalhe.setDataRelatorio(calendar.getTime());

					listEvolucaoDetalhe.add(evolucaoDetalhe);
				}
			}

			dao.saveEvolucaoAtendimentoDetalhe(listEvolucaoDetalhe);

		} catch (Exception e) {
			throw new JobExecutionException(e);
		}
	}
}
