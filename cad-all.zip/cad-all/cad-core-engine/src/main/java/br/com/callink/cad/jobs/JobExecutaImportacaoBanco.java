package br.com.callink.cad.jobs;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import br.com.callink.cad.crypto.CryptographyException;
import br.com.callink.cad.crypto.impl.AESCryptoImpl;
import br.com.callink.cad.crypto.impl.RSACryptoImpl;
import br.com.callink.cad.dao.CampoDinamicoDAO;
import br.com.callink.cad.dao.CamposLayoutDAO;
import br.com.callink.cad.dao.FonteDadosDAO;
import br.com.callink.cad.dao.ImportCasoDAO;
import br.com.callink.cad.dao.LayoutImportacaoDAO;
import br.com.callink.cad.dao.LoteCasoDAO;
import br.com.callink.cad.dao.RegraImportacaoDAO;
import br.com.callink.cad.to.CampoDinamicoTO;
import br.com.callink.cad.to.CamposLayoutTO;
import br.com.callink.cad.to.EmailTO;
import br.com.callink.cad.to.FonteDadosTO;
import br.com.callink.cad.to.ImportCasoTO;
import br.com.callink.cad.to.LayoutImportacaoTO;
import br.com.callink.cad.to.LoteCasoTO;
import br.com.callink.cad.to.RegraImportacaoTO;
import br.com.callink.cad.util.CollectionUtils;
import br.com.callink.cad.util.ConnectionUtil;
import br.com.callink.cad.util.StringUtils;

/**
 * @author swb_brunocamargo
 * 
 */
public class JobExecutaImportacaoBanco extends CadJob {

	private Logger logger = Logger.getLogger(JobExecutaImportacaoBanco.class.getName());

	private LoteCasoDAO loteCasoDAO;
	private LayoutImportacaoDAO layoutImportacaoDAO;
	private CamposLayoutDAO camposLayoutDAO;
	private CampoDinamicoDAO campoDinamicoDAO;
	private FonteDadosDAO fonteDadosDAO;
	private ImportCasoDAO dao;
	private RegraImportacaoDAO regraImportacaoDAO;

	private Map<Integer, Boolean> mapUpdtEmail;
	private List<EmailTO> listUpdtEmail;

	private final String TIPO_EXECUCAO = "AGENDADO";
	private final String TIPO_PROCESSO = "BANCO";
	private final String STATUS_EXECUCAO_IMPORTANDO = "IMPORTANDO";
	private final String STATUS_EXECUCAO_CANCELADO = "CANCELADO";
	private final String STATUS_PENDENTE_IMPORTANDO = "PENDENTE";
	private final String STATUS_FINALIZADO = "FINALIZADO";
	private final String TEMPO_EXECUCACAO_PRE_BUSCA_DADOS = "PRE_BUSCA_DE_DADOS";
	private final String TEMPO_EXECUCACAO_POS_BUSCA_DADOS = "POS_BUSCA_DE_DADOS";

	private void setUp() throws Exception {
		if (mapUpdtEmail == null) {
			mapUpdtEmail = new LinkedHashMap<Integer, Boolean>();
		}
		if (listUpdtEmail == null) {
			listUpdtEmail = new ArrayList<EmailTO>();
		}

		if (loteCasoDAO == null) {
			loteCasoDAO = new LoteCasoDAO();
		}
		if (layoutImportacaoDAO == null) {
			layoutImportacaoDAO = new LayoutImportacaoDAO();
		}
		if (camposLayoutDAO == null) {
			camposLayoutDAO = new CamposLayoutDAO();
		}
		if (fonteDadosDAO == null) {
			fonteDadosDAO = new FonteDadosDAO();
		}
		if (campoDinamicoDAO == null) {
			campoDinamicoDAO = new CampoDinamicoDAO();
		}
		if (regraImportacaoDAO == null) {
			regraImportacaoDAO = new RegraImportacaoDAO();
		}
		if (dao == null) {
			dao = new ImportCasoDAO();
		}
	}

	@Override
	protected void process(Integer idTenant, Integer idOperacao, String nome) throws Exception {
		setUp();
		importacaoBanco(idOperacao, getJobTO().getId());
	}

	public void importacaoBanco(Integer idOperacao, Integer idJob) {
		Integer idLoteCaso = null;
		try {

			ConnectionUtil conn = new ConnectionUtil();
			RSACryptoImpl rsa = new RSACryptoImpl();

			List<LayoutImportacaoTO> listLayoutImportacaoTOs = layoutImportacaoDAO.buscaLayoutImportacaoByJob(idJob);

			if (listLayoutImportacaoTOs == null || listLayoutImportacaoTOs.isEmpty()) {

				throw new Exception(" Não foi encontrado nenhum layout para a job: " + getJobTO().getNome());
			} else if (listLayoutImportacaoTOs.size() > 1) {

				throw new Exception(" Foi encontrado mais de um layout para a job: " + getJobTO().getNome());
			}

			LayoutImportacaoTO layoutImportacaoTO = listLayoutImportacaoTOs.get(0);

			if (layoutImportacaoTO.getIdOperacao() == null || !layoutImportacaoTO.getIdOperacao().equals(idOperacao)) {
				throw new Exception("A opreração do layout não coincide com a operação associada a job ");
			}

			List<CampoDinamicoTO> camposCriptografados = campoDinamicoDAO.getFieldsCriptografados(idOperacao);
			List<CamposLayoutTO> listCamposLayoutTOs = camposLayoutDAO.buscaCamposByJob(idJob);
			FonteDadosTO fonteDadosTO = fonteDadosDAO.buscaFonteDadosById(layoutImportacaoTO.getIdFonteDados());

			Connection connection = conn.getConnection(fonteDadosTO.getDriver(), fonteDadosTO.getUrl(), fonteDadosTO.getUsuario(), rsa.decrypt(fonteDadosTO.getSenha()));

			if (connection == null || connection.isClosed()) {
				throw new Exception("A conexão com o banco do layout esta fechada ou não existe.");
			}
			connection.setAutoCommit(false);

			PreparedStatement stm = connection.prepareStatement(layoutImportacaoTO.getSqlText());

			Date dataAtual = layoutImportacaoDAO.getDataBanco();
			DateFormat df = new SimpleDateFormat("yyyyMMdd_HHmmss");

			LoteCasoTO loteCaso = new LoteCasoTO();
			loteCaso.setHorarioAgendamento(dao.getDataBanco());
			loteCaso.setTipoExecucao(TIPO_EXECUCAO);
			loteCaso.setStatusExecucao(STATUS_EXECUCAO_IMPORTANDO);
			loteCaso.setTipoProcesso(TIPO_PROCESSO);
			loteCaso.setFlagAtivo(Boolean.TRUE);
			loteCaso.setIdOperacao(idOperacao);
			loteCaso.setIdLayout(layoutImportacaoTO.getIdLayout());
			loteCaso.setNomeArquivo(layoutImportacaoTO.getNome() + " " + df.format(dataAtual));
			loteCaso = loteCasoDAO.savarLoteCaso(loteCaso);
			idLoteCaso = loteCaso.getIdLoteCaso();
			executaRegrasImport(connection, layoutImportacaoTO.getIdLayout(), TEMPO_EXECUCACAO_PRE_BUSCA_DADOS);

			ResultSet rs = stm.executeQuery();
			List<String> alias = getAliasQuery(listCamposLayoutTOs, layoutImportacaoTO.getSqlText());

			List<ImportCasoTO> listImport = new ArrayList<ImportCasoTO>();
			String idExterno = "";
			int countRegistrosInseridos = 0;
			int countTotalRegistros = 0;
			boolean isCriptografado = Boolean.FALSE;

			while (rs.next()) {
				Map<String, String> mapDados = new HashMap<String, String>();
				countTotalRegistros++;

				if (!alias.isEmpty()) {
					idExterno = "";

					for (String item : alias) {
						for (CamposLayoutTO campo : listCamposLayoutTOs) {
							if (campo.getCampoImportCaso().equalsIgnoreCase(item)) {

								if (CollectionUtils.hasValue(camposCriptografados)) {
									for (CampoDinamicoTO campoCript : camposCriptografados) {
										if (campo.getCampoCaso().toUpperCase().equals(campoCript.getNomeColuna().toUpperCase())) {
											try {
												AESCryptoImpl aes = new AESCryptoImpl();
												campo.setValor(aes.encrypt(rs.getString(item)));
												isCriptografado = Boolean.TRUE;
												break;

											} catch (CryptographyException e) {
												throw new Exception("Erro ao criptografar campo: " + campo.getCammpoNome(), e);
											}
										}
									}
								}

								if (!isCriptografado) {
									campo.setValor(rs.getString(item));

									if (campo.getFlagIdentificador() != null && campo.getFlagIdentificador()) {
										idExterno = campo.getValor();
									}
								}

								mapDados.put(campo.getCampoImportCaso(), campo.getValor());
								isCriptografado = Boolean.FALSE;
								break;
							}
						}
					}

					ImportCasoTO importCasoTO = new ImportCasoTO();
					importCasoTO.setIdLoteCaso(loteCaso.getIdLoteCaso());
					importCasoTO.setIdLayout(layoutImportacaoTO.getIdLayout());
					importCasoTO.setIdExterno(idExterno);
					importCasoTO.setFlagImportRejeitado(false);
					importCasoTO.setMapDados(mapDados);

					listImport.add(importCasoTO);

					countRegistrosInseridos++;
				}
			}

			executaRegrasImport(connection, layoutImportacaoTO.getIdLayout(), TEMPO_EXECUCACAO_POS_BUSCA_DADOS);

			if (listImport != null && !listImport.isEmpty()) {
				dao.inserImportCasoNative(listImport);
			}

			if (countTotalRegistros > 0 && countRegistrosInseridos == 0) {
				loteCasoDAO.atualizaLoteStatusQuantidade(loteCaso.getIdLoteCaso(), countTotalRegistros, 0, 0, 0,
						"Foram encontradas " + countTotalRegistros + " linhas, porém nenhum campo foi associado aos campos do layout.", STATUS_FINALIZADO);
			} else if (countTotalRegistros == 0 && countRegistrosInseridos == 0) {
				loteCasoDAO.atualizaLoteStatusQuantidade(loteCaso.getIdLoteCaso(), 0, 0, 0, 0, null, STATUS_FINALIZADO);
			} else {
				loteCasoDAO.atualizaStatusExecucaoLoteCaso(loteCaso.getIdLoteCaso(), STATUS_PENDENTE_IMPORTANDO);
			}
		} catch (Exception ex) {
			try {
				loteCasoDAO.atualizaStatusExecucaoLoteCaso(idLoteCaso, STATUS_EXECUCAO_CANCELADO);
			} catch (Exception e) {
				StringBuilder errors = new StringBuilder("[Operação: ");
				errors.append(idOperacao);
				errors.append(", JOB: ");
				errors.append(idJob);
				errors.append("] ");
				errors.append(ex.getMessage());
			}
			StringBuilder errors = new StringBuilder("[Operação: ");
			errors.append(idOperacao);
			errors.append(", JOB: ");
			errors.append(idJob);
			errors.append("] ");
			errors.append(ex.getMessage());
			logger.log(Level.SEVERE, errors.toString(), ex);
		}
	}

	private void executaRegrasImport(Connection connection, Integer idLayout, String tempoExecucao) throws Exception, SQLException {
		List<RegraImportacaoTO> regras = regraImportacaoDAO.buscaRegrasExecucaoBancoByLayout(idLayout, tempoExecucao);
		if (CollectionUtils.hasValue(regras)) {
			for (RegraImportacaoTO regraImportacaoTO : regras) {
				PreparedStatement stmRegra = connection.prepareStatement(regraImportacaoTO.getSql());
				stmRegra.executeUpdate();
				connection.commit();
				stmRegra.close();
			}
		}
	}

	private List<String> getAliasQuery(List<CamposLayoutTO> campos, String sqlText) {
		List<String> alias = new ArrayList<String>();
		if (!campos.isEmpty() && !StringUtils.isEmpty(sqlText)) {
			for (CamposLayoutTO camposLayoutTO : campos) {
				if (sqlText.toUpperCase().contains(camposLayoutTO.getCampoImportCaso().toUpperCase())) {
					alias.add(camposLayoutTO.getCampoImportCaso().toUpperCase());
				}
			}
		}
		return alias;
	}

}
