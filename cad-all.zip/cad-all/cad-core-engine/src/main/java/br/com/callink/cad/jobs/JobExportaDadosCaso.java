package br.com.callink.cad.jobs;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.quartz.JobExecutionException;

import br.com.callink.cad.crypto.CryptographyException;
import br.com.callink.cad.crypto.impl.AESCryptoImpl;
import br.com.callink.cad.dao.CampoDinamicoDAO;
import br.com.callink.cad.dao.CampoDominioDAO;
import br.com.callink.cad.dao.CasoDAO;
import br.com.callink.cad.dao.ConfiguracaoCaixaEmailDAO;
import br.com.callink.cad.dao.ExportaCasoSchedulerDAO;
import br.com.callink.cad.dao.FiltroCasoDAO;
import br.com.callink.cad.dao.FiltroExportarCasoDAO;
import br.com.callink.cad.dao.ParametroSistemaDAO;
import br.com.callink.cad.dao.RecebeEmailDAO;
import br.com.callink.cad.enumeration.ParametroSistemaOperacaoEnum;
import br.com.callink.cad.sla.util.MascaraUtilHelper;
import br.com.callink.cad.to.AnexoTO;
import br.com.callink.cad.to.CampoDinamicoTO;
import br.com.callink.cad.to.CampoDominioSelecionadoTO;
import br.com.callink.cad.to.CamposCasoToExport;
import br.com.callink.cad.to.CamposFiltroCasoEnum;
import br.com.callink.cad.to.CasoFindTO;
import br.com.callink.cad.to.CasoTO;
import br.com.callink.cad.to.ConfiguracaoCaixaEmailTO;
import br.com.callink.cad.to.DadosDinamicos;
import br.com.callink.cad.to.EmailTO;
import br.com.callink.cad.to.ExportaCasoSchedulerTO;
import br.com.callink.cad.to.FiltroCasoCampoTO;
import br.com.callink.cad.to.FiltroDadosDinamicosTO;
import br.com.callink.cad.to.FiltroExportarDadosCampoTO;
import br.com.callink.cad.to.GrupoAnexoTO;
import br.com.callink.cad.to.GrupoCampoDominioTO;
import br.com.callink.cad.to.LinhaCampoDinamicoTabelaTO;
import br.com.callink.cad.to.TipoCampoDinamico;
import br.com.callink.cad.util.ArquivoUtils;
import br.com.callink.cad.util.CalculoSlaHelper;
import br.com.callink.cad.util.CollectionUtils;
import br.com.callink.cad.util.CollectionUtils.Filter;
import br.com.callink.cad.util.CsvUtils;
import br.com.callink.cad.util.DateUtils;

public class JobExportaDadosCaso extends CadJob {

	private Logger logger = Logger.getLogger(JobExportaDadosCaso.class.getName());
	private RecebeEmailDAO emailDAO;
	private ParametroSistemaDAO parametroSistemaDAO;
	private ExportaCasoSchedulerDAO exportaCasoSchedulerDAO;
	private CampoDinamicoDAO campoDinamicoDAO;
	private CampoDominioDAO campoDominioDAO;
	private CasoDAO casoDAO;
	private CalculoSlaHelper calculoSlaUtil;
	private FiltroCasoDAO filtroCasoDAO;
	private FiltroExportarCasoDAO filtroExportarCasoDAO;
	private RecebeEmailDAO recebeEmailDAO;
	private ConfiguracaoCaixaEmailDAO configuracaoCaixaEmailDAO;
	private MascaraUtilHelper maskUtil;
	
	private static final String EMPTY_STRING = "";
	private static final String LIMITE_LINHAS_EXPORTACAO = "limiteLinhasExportacaoDados";
	
	private void setUp(Integer idOperacao) throws Exception {
		if (emailDAO == null) {
			emailDAO = new RecebeEmailDAO();
		}
		if (parametroSistemaDAO == null) {
			parametroSistemaDAO = new ParametroSistemaDAO();
		}
		if (exportaCasoSchedulerDAO == null) {
			exportaCasoSchedulerDAO = new ExportaCasoSchedulerDAO();
		}
		if (campoDinamicoDAO == null) {
			campoDinamicoDAO = new CampoDinamicoDAO();
		}
		if (campoDominioDAO == null) {
			campoDominioDAO = new CampoDominioDAO();
		}
		if (casoDAO == null) {
			casoDAO = new CasoDAO();
		}
		if (calculoSlaUtil == null) {
			calculoSlaUtil = new CalculoSlaHelper(getFeriadosOperacao(idOperacao),
					getJornadaOperacao(idOperacao),
					getSlaFilaOperacao(idOperacao));
		}
		if (filtroCasoDAO == null) {
			filtroCasoDAO = new FiltroCasoDAO();
		}
		if (filtroExportarCasoDAO == null) {
			filtroExportarCasoDAO = new FiltroExportarCasoDAO();
		}
		if (recebeEmailDAO == null) {
			recebeEmailDAO = new RecebeEmailDAO();
		}
		if (configuracaoCaixaEmailDAO == null) {
			configuracaoCaixaEmailDAO = new ConfiguracaoCaixaEmailDAO();
		}
		if (maskUtil == null) {
			maskUtil = MascaraUtilHelper.getInstance();
		}
	}

	@Override
	protected void process(Integer idTenant, Integer idOperacao, String nome) throws Exception {
		try {
			if (idOperacao == null) {
				return;
			}
			setUp(idOperacao);
			
			ExportaCasoSchedulerTO exportaCasoScheduler = exportaCasoSchedulerDAO.findExportaCasoSchedulerByJob(getJobTO().getId());
			
			if (exportaCasoScheduler != null) {
				// Busca os dados dos casos
				List<CasoTO> casos = buscaDados(exportaCasoScheduler, idOperacao);
				
				// Busca os campos para exportar
				List<FiltroExportarDadosCampoTO> camposExportar = filtroExportarCasoDAO.findCamposFiltroExportarCaso(exportaCasoScheduler.getIdFiltroExportarDados());
				
				// Gera o arquivo
				StringBuffer arquivo = gerarContentCSV(casos, camposExportar);
				
				// Envia o arquivo por e-mail ou salva em diretorio
				if (exportaCasoScheduler.getDiretorioDestino() != null && !exportaCasoScheduler.getDiretorioDestino().isEmpty()) {
					salvaArquivo(arquivo, exportaCasoScheduler.getDiretorioDestino());
				} else if (exportaCasoScheduler.getEmailDestino() != null && !exportaCasoScheduler.getEmailDestino().isEmpty()) {
					salvaEmailArquivo(arquivo, exportaCasoScheduler.getEmailDestino(), idOperacao);
				}
			}
		} catch (Exception e) {
			StringBuilder errors = new StringBuilder("[Operação: ");
			errors.append(idOperacao);
			errors.append("] ");
			errors.append(" Erro na JobExportaDadosCaso: ");
			errors.append(e.getMessage());
			logger.log(Level.SEVERE, errors.toString(), e);
			throw e;
		}
	}

	private List<CasoTO> buscaDados(ExportaCasoSchedulerTO exportaCasoScheduler, Integer idOperacao) throws Exception {
		List<CasoTO> casos = null;
		try {
			List<FiltroCasoCampoTO> listCamposFiltro = filtroCasoDAO.findCamposFiltroCaso(exportaCasoScheduler.getIdFiltroCaso());
			
			CasoFindTO casoFind = new CasoFindTO();
			casoFind.setIdOperacao(idOperacao);
			casoFind.setListFiltroCasoCampos(listCamposFiltro);
			casoFind.setFiltroDadosDinamicos(getFiltroDadosDinamicos(idOperacao));
			casoFind.setDatasExportaCasoScheduler(exportaCasoSchedulerDAO.findExportaCasoSchedulerDataByExporta(exportaCasoScheduler.getIdExportaCasoScheduler()));
			casos = buscaPorFiltros(casoFind);
			
			String valorParamLimiteLinhas = parametroSistemaDAO.findValorParametroSistemaOperacao(LIMITE_LINHAS_EXPORTACAO, idOperacao);
			if (valorParamLimiteLinhas != null && !valorParamLimiteLinhas.isEmpty()
					&& casos != null && !casos.isEmpty() && Integer.valueOf(valorParamLimiteLinhas).compareTo(casos.size()) < 0) {
				StringBuilder msg = new StringBuilder();
				msg.append("Quantidade de registros retornados na exportação de dados excede o limite máximo estabelecido no parâmetro de sistema '")
				   .append(LIMITE_LINHAS_EXPORTACAO).append("'. Quantidade retornada: ").append(casos.size()).append(", quantidade parametrizada: ")
				   .append(valorParamLimiteLinhas);
				throw new JobExecutionException(msg.toString());
			}
			
			buscaDadosDinamicos(casos);
			
			return casos;
		} catch (Exception e) {
			StringBuilder errors = new StringBuilder("[Operação: ");
			errors.append(idOperacao);
			errors.append("] ");
			errors.append(" Erro ao buscar dados dos casos: ");
			errors.append(e.getMessage());
			logger.log(Level.SEVERE, errors.toString(), e);
			throw e;
		}
	}
	
	private void buscaDadosDinamicos(List<CasoTO> casos) throws Exception {
		// Busca dados de campos lista unica, multipla, tabela, criptografado
		for (CasoTO caso : casos) {
			descriptografaEMascaraValores(caso.getDadosDinamicos());
			
			campoDominioDAO.buscaValoresCamposDinamicosListaCaso(caso.getDadosDinamicos(), caso.getIdCaso());
		}
	}
	
	private StringBuffer gerarContentCSV(List<CasoTO> casoList, List<FiltroExportarDadosCampoTO> camposToExport) throws Exception {
		try {
			Map<String, Integer> control = new HashMap<String, Integer>();
			List<Object> tabela = new ArrayList<Object>();
			List<Object> linhaAtual = null;
			List<Object> linhaHeader = null;
			List<LinhaCampoDinamicoTabelaTO> linhas = null;
			List<Object> aux = null;
			boolean insereHeader = true;
			
			if (CollectionUtils.hasValue(camposToExport)) {
				linhaHeader = new ArrayList<Object>();
				
				if (CollectionUtils.hasValue(casoList)) {
					for (CasoTO itemTO : casoList) {
						
						linhaAtual = new ArrayList<Object>();
						
						for (FiltroExportarDadosCampoTO campo : camposToExport) {
							if (campo.getFlagCampoDinamico()) {
								for (DadosDinamicos dados : itemTO.getDadosDinamicos()) {
									if (dados != null) {
										if (dados.getDadosColuna().getNomeColuna().equals(campo.getKeyCampo())) {
											if (!TipoCampoDinamico.TABELA.equals(dados.getDadosColuna().getTipoCampo())) {
												if (insereHeader) {
													linhaHeader.add(campo.getLabelCampo());
												}
												if (TipoCampoDinamico.BOOLEAN.equals(dados.getDadosColuna().getTipoCampo())) {
													linhaAtual.add(dados.getValor() == null ? EMPTY_STRING : (dados.getValor().equals("1") ? "SIM" : "NÃO"));
												} else {
													linhaAtual.add(dados.getValor() == null ? EMPTY_STRING : dados.getValor());
												}
											}
										}
									}
								}
								
							} else {
								if (insereHeader) {
									linhaHeader.add(campo.getLabelCampo());
								}
								linhaAtual.add(criarColunaCaso(itemTO, campo));
							}
						}
						
						DadosDinamicos[] tableFields = CollectionUtils.filter(itemTO.getDadosDinamicos(),
						        new Filter<DadosDinamicos>() {
							        @Override
							        public boolean match(DadosDinamicos candidate) {
								        return candidate != null && candidate.getDadosColuna() != null
								                && TipoCampoDinamico.TABELA.equals(candidate.getDadosColuna().getTipoCampo());
							        }
						        });
						
						boolean exportouTabelas = false;
						
						if (CollectionUtils.hasValue(tableFields)) {
							for (DadosDinamicos dados : tableFields) {
								if (insereHeader) {
									linhas = exportaTabelas(camposToExport, dados, itemTO.getIdCaso(), linhaHeader, control);
								} else {
									linhas = exportaTabelas(camposToExport, dados, itemTO.getIdCaso(), null, null);
								}
								
								if (CollectionUtils.hasValue(linhas)) {
									exportouTabelas = true;
									
									for (LinhaCampoDinamicoTabelaTO linhaCampoDinamicoTabelaTO : linhas) {
										aux = new ArrayList<Object>(linhaAtual);
										
										for (CampoDinamicoTO dadosDinamicos : linhaCampoDinamicoTabelaTO.getColunas()) {
											while (aux.size() <= control.get(dados.getDadosColuna().getIdCampoDinamico()+dadosDinamicos.getNomeColuna())) {
												aux.add("");
											}
											
											aux.add(control.get(dados.getDadosColuna().getIdCampoDinamico()+dadosDinamicos.getNomeColuna()), dadosDinamicos.getValor());
										}
										tabela.add(aux.toArray());
									}
								}
							}
						}
						
						if (!exportouTabelas) {
							tabela.add(linhaAtual.toArray());
						}
						insereHeader = false;
					}
					tabela.add(0, linhaHeader.toArray());
				}
			}
			
			CsvUtils csv = new CsvUtils("casos.csv", null);
			return csv.createContents(tabela.toArray());
		} catch (Exception e) {
			StringBuilder errors = new StringBuilder("Erro ao gerar arquivo CSV: ");
			errors.append(e.getMessage());
			logger.log(Level.SEVERE, errors.toString(), e);
			throw e;
		}
	}
	
	private void salvaArquivo(StringBuffer arquivo, String diretorioDestino) throws Exception {
		try {
			DateFormat df = new SimpleDateFormat("yyyyMMdd_HHmmss");
			
			StringBuilder caminhoArquivo = new StringBuilder(diretorioDestino);
			File diretorio = new File(caminhoArquivo.toString());
			if (!diretorio.exists()) {
				diretorio.mkdirs();
			}
			if (!"/".equals(diretorioDestino.charAt(diretorioDestino.length() - 1))
					|| "\\".equals(diretorioDestino.charAt(diretorioDestino.length() - 1))) {
				caminhoArquivo.append("/");
			}
			
			caminhoArquivo.append("Exportacao_dados_").append(df.format(casoDAO.getDataBanco())).append(".csv");
			
			BufferedWriter bwr = new BufferedWriter(new FileWriter(new File(caminhoArquivo.toString())));
            
            bwr.write(arquivo.toString());
            bwr.flush();
            bwr.close();
		} catch (Exception e) {
			StringBuilder errors = new StringBuilder("Erro ao salvar arquivo no diretório destino: ");
			errors.append(e.getMessage());
			logger.log(Level.SEVERE, errors.toString(), e);
			throw e;
		}
	}
	
	private void salvaEmailArquivo(StringBuffer arquivo, String emailDestino, Integer idOperacao) throws Exception {
		try {
			String diretorio = parametroSistemaDAO.findValorParametroSistemaOperacao(
					ParametroSistemaOperacaoEnum.PARAM_DIRETORIO_ANEXO.getParametroSistemaOperacao(), idOperacao);
			if (diretorio == null || diretorio.isEmpty()) {
				throw new Exception("Diret\u00F3rio para salvar anexo n\u00E3o est\u00E1 cadastrado.");
			}
			
			ConfiguracaoCaixaEmailTO config = configuracaoCaixaEmailDAO.findAtivosPrincipalPorOperacao(idOperacao, Boolean.TRUE);
			if (config == null || config.getIdConfiguracaoCaixaEmail() == null) {
				throw new Exception("Não existe caixa de email para a operação: " + idOperacao);
			}
			
			DateFormat df = new SimpleDateFormat("yyyyMMdd_HHmmss");
			StringBuilder nomeArquivo = new StringBuilder("Exportacao_dados_").append(df.format(casoDAO.getDataBanco())).append(".csv");
			
			EmailTO mail = new EmailTO();
			mail.setAssunto("Exportação dados CAD");
			mail.setConteudo("Email automático do processo de exportação de dados do CAD.");
			mail.setDestinatario(emailDestino);
			mail.setRemetente(config.getEmail());
			mail.setIdConfiguracaoCaixaEmail(config.getIdConfiguracaoCaixaEmail());
			mail.setFlagPossuiCaso(Boolean.TRUE);
			mail.setFlagLido(Boolean.FALSE);
			mail.setFlagErroEnvio(Boolean.FALSE);
			mail.setFlagEnvio(Boolean.TRUE);
			mail.setFlagEnvioPendente(Boolean.TRUE);
			mail.setFlagDesativado(Boolean.FALSE);
			mail.setIdOperacao(idOperacao);
			
			AnexoTO anexo = new AnexoTO();
			anexo.setDados(arquivo.toString().getBytes());
			anexo.setDiretorio(diretorio);
			anexo.setNomeReal(nomeArquivo.toString());
			
			GrupoAnexoTO grupoAnexo = new GrupoAnexoTO();
			grupoAnexo.setAnexoList(Arrays.asList(anexo));

			grupoAnexo = salvaGrupoAnexo(grupoAnexo, idOperacao);

			mail.setGrupoAnexo(grupoAnexo);
			
			recebeEmailDAO.saveEmail(mail);
		} catch (Exception e) {
			StringBuilder errors = new StringBuilder("Erro ao enviar e-mail com arquivo: ");
			errors.append(e.getMessage());
			logger.log(Level.SEVERE, errors.toString(), e);
			throw e;
		}
	}
	
	private List<CasoTO> buscaPorFiltros(CasoFindTO casoFind) throws Exception {
		Iterator<FiltroCasoCampoTO> it = casoFind.getListFiltroCasoCampos().iterator();
		while (it.hasNext()) {
			FiltroCasoCampoTO cp = it.next();
			CamposFiltroCasoEnum campoEnum = CamposFiltroCasoEnum.getEnumByNomeCampo(cp.getCampoNome());

			if (campoEnum != null) {
				try {
					if (campoEnum.getVariavelQuery().equalsIgnoreCase("sla_menor")) {
						Long slaEmMinutos = (long) DateUtils.retornaMinutos(cp.getCampoValor());
						casoFind.setSlaEmMinutos(slaEmMinutos);
					} else if (campoEnum.getVariavelQuery().equalsIgnoreCase("sla_maior")) {
						Long slaEmMinutosMaior = (long) DateUtils.retornaMinutos(cp.getCampoValor());
						casoFind.setSlaEmMinutosMaior(slaEmMinutosMaior);
					}
				} catch (Exception e) {
					throw new Exception("Para filtro por SLA, informe o valor no formato HH:mm", e);
				}
			}
		}

		if (CollectionUtils.hasValue(casoFind.getFiltroDadosDinamicos())) {
			for (FiltroDadosDinamicosTO filtrodinamico : casoFind.getFiltroDadosDinamicos()) {
				criptografaValores(filtrodinamico);
			}
		}

		List<CasoTO> casoList = casoDAO.buscaPorFiltroSQL(casoFind);

		if (CollectionUtils.hasValue(casoList)) {
			/*List<Integer> _skipMask = perfilCampoDinamicoService.buscarTodosCamposAtivosQueNaoRequerMascaraPorUsuario(idUsuario);
			for (CasoTO casoDetalhadoTO : casoList) {
				descriptografaEMascaraValores(idUsuario, casoDetalhadoTO.getDadosDinamicos(), _skipMask);
			}*/

			CasoTO cso = null;
			Date data = casoDAO.getDataBanco();

			if (casoFind.getSlaEmMinutos() != null || casoFind.getSlaEmMinutosMaior() != null) {
				for (Iterator<CasoTO> iterator = casoList.iterator(); iterator.hasNext();) {
					CasoTO casoDetalhe = (CasoTO) iterator.next();
					cso = casoDetalhe;

					if (casoFind.getSlaEmMinutos() != null) {
						cso = calculoSlaUtil.verificaSlaMaiorParametro(cso, casoFind.getSlaEmMinutos() == null ? 0 : casoFind.getSlaEmMinutos(), data);

						if (cso == null) {
							iterator.remove();
							continue;
						}
					}

					if (casoFind.getSlaEmMinutosMaior() != null) {
						cso = calculoSlaUtil.verificaSlaMenorParametro(cso, casoFind.getSlaEmMinutosMaior() == null ? 0 : casoFind.getSlaEmMinutosMaior(), data);

						if (cso == null) {
							iterator.remove();
							continue;
						}
					}
					casoDetalhe.setPorcentagemSla(cso.getPorcentagemSla());
					casoDetalhe.setSlaEmMinutos(cso.getSlaEmMinutos());
					casoDetalhe.setDataFimSla(cso.getDataFimSla());
					casoDetalhe.setIconeSla(cso.getIconeSla());
				}
			} else {
				for (CasoTO casItem : casoList) {
					cso = calculoSlaUtil.loadSla(casItem, data);
					casItem.setPorcentagemSla(cso.getPorcentagemSla());
					casItem.setSlaEmMinutos(cso.getSlaEmMinutos());
					casItem.setDataFimSla(cso.getDataFimSla());
					casItem.setIconeSla(cso.getIconeSla());
				}
			}
		}
		return casoList;
	}
	
	public FiltroDadosDinamicosTO[] getFiltroDadosDinamicos(Integer idOperacao) throws Exception {
		FiltroDadosDinamicosTO[] filtroDadosDinamicos = null;
		List<CampoDinamicoTO> campos = getCamposDinamicos(idOperacao);

		if (CollectionUtils.hasValue(campos)) {
			filtroDadosDinamicos = new FiltroDadosDinamicosTO[campos.size()];

			for (CampoDinamicoTO cd : campos) {
				filtroDadosDinamicos[campos.indexOf(cd)] = new FiltroDadosDinamicosTO(cd);
			}
		}
		return filtroDadosDinamicos;
	}
	
	public List<CampoDinamicoTO> getCamposDinamicos(Integer idOperacao) throws Exception {
		List<CampoDinamicoTO> campos = null;
		campos = campoDinamicoDAO.buscaAtivosPorOperacaoComRange(idOperacao);

		return campos;
	}
	
	private void criptografaValores(FiltroDadosDinamicosTO filtrodinamico) throws Exception {
		if (filtrodinamico != null && TipoCampoDinamico.CRIPTOGRAFADO.equals(filtrodinamico.CAMPO_DINAMICO.getTipoCampo())
				&& filtrodinamico.getValorA() != null && !filtrodinamico.getValorA().toString().isEmpty()) {
			try {
				AESCryptoImpl aes = new AESCryptoImpl();
				filtrodinamico.setValorA(aes.encrypt((String) filtrodinamico.getValorA()));

			} catch (CryptographyException e) {
				throw new Exception("Erro ao descriptografar campo: " + filtrodinamico.CAMPO_DINAMICO.getNome());
			}
		}
	}
	
	private void descriptografaEMascaraValores(DadosDinamicos[] dadosDinamicos) throws Exception {
		if (CollectionUtils.hasValue(dadosDinamicos)) {
			for (DadosDinamicos dado : dadosDinamicos) {
				final boolean MASK_ALL_CHAR = dado.getDadosColuna().getFlagMascaraTodosCaracteres() != null && dado.getDadosColuna().getFlagMascaraTodosCaracteres();
				final String MASK = dado.getDadosColuna().getMascara();

				if (dado.getValor() != null && !dado.getValor().toString().isEmpty()) {
					if (TipoCampoDinamico.CRIPTOGRAFADO.equals(dado.getDadosColuna().getTipoCampo())) {
						if (dado.getDadosColuna().getFlagExportarValorReal() != null && dado.getDadosColuna().getFlagExportarValorReal()
								&& dado.getValor() != null && !dado.getValor().toString().isEmpty()) {
							try {
								AESCryptoImpl aes = new AESCryptoImpl();
								dado.getDadosColuna().setValor(maskUtil.aplicarMascara(MASK_ALL_CHAR, MASK, aes.decrypt(dado.getValor().toString())));
								dado.setValor(maskUtil.aplicarMascara(MASK_ALL_CHAR, MASK, aes.decrypt(dado.getValor().toString())));

							} catch (CryptographyException e) {
								throw new Exception("Erro ao descriptografar campo: " + dado.getDadosColuna().getLabel(), e);
							}
						}
						
					} else {
						dado.getDadosColuna().setValor(maskUtil.aplicarMascara(MASK_ALL_CHAR, MASK, dado.getValor().toString()));
						dado.setValor(maskUtil.aplicarMascara(MASK_ALL_CHAR, MASK, dado.getValor().toString()));
					}
				}
			}
		}
	}
	
	private List<LinhaCampoDinamicoTabelaTO> exportaTabelas(List<FiltroExportarDadosCampoTO> camposToExport, DadosDinamicos table,
	        Integer idCaso, List<Object> linhaHeader, Map<String, Integer> control) throws Exception {
		
		for (FiltroExportarDadosCampoTO campo : camposToExport) {
			if (campo.getFlagCampoDinamico()) {
				if (table.getDadosColuna().getNomeColuna().equals(campo.getKeyCampo())) {
					final List<CampoDinamicoTO> camposTabela = campoDinamicoDAO.buscaCamposPorTabela(table.getDadosColuna()
					        .getIdCampoDinamico());
					table.setCamposTabela(camposTabela.toArray(new CampoDinamicoTO[camposTabela.size()]));
					
					if (linhaHeader != null) {
						for (CampoDinamicoTO campoDinamicoTO : table.getCamposTabela()) {
							linhaHeader.add(campoDinamicoTO.getLabel());
							control.put(table.getDadosColuna().getIdCampoDinamico() + campoDinamicoTO.getNomeColuna(), linhaHeader.lastIndexOf(campoDinamicoTO.getLabel()));
						}
					}
					return campoDinamicoDAO.buscaValores(table.getDadosColuna().getIdCampoDinamico(),
					        Arrays.asList(table.getCamposTabela()), idCaso);
				}
			}
		}
		return null;
	}
	
	private Object criarColunaCaso(CasoTO caso, FiltroExportarDadosCampoTO campo) {
		if (CamposCasoToExport.DESCRICAO.name().equals(campo.getKeyCampo())) {
			return caso.getDescricao() == null ? EMPTY_STRING : caso.getDescricao();
			
		} else if (CamposCasoToExport.CLASSIFICACAO_COUNT.name().equals(campo.getKeyCampo())) {
			return caso.getClassificacaoCount() == null ? EMPTY_STRING : caso.getClassificacaoCount().toString();
			
		} else if (CamposCasoToExport.EDICAO_TELEFONE_COUNT.name().equals(campo.getKeyCampo())) {
			return caso.getEdicaoTelefoneCount() == null ? EMPTY_STRING : caso.getEdicaoTelefoneCount().toString();
			
		} else if (CamposCasoToExport.PERCENTUAL_SLA.name().equals(campo.getKeyCampo())) {
			return formatPercent(caso.getPorcentagemSla());
			
		} else if (CamposCasoToExport.SLA_MINUTOS.name().equals(campo.getKeyCampo())) {
			return caso.getSlaEmMinutos() == null ? EMPTY_STRING : caso.getSlaEmMinutos();
			
		} else if (CamposCasoToExport.SLA_TOTAL.name().equals(campo.getKeyCampo())) {
			return caso.getSlaTotalMinutos() == null ? EMPTY_STRING : caso.getSlaTotalMinutos();
			
		} else if (CamposCasoToExport.ID_CASO.name().equals(campo.getKeyCampo())) {
			return caso.getIdCaso() == null ? EMPTY_STRING : caso.getIdCaso().toString();
			
		} else if (CamposCasoToExport.ID_CASO_PAI.name().equals(campo.getKeyCampo())) {
			return caso.getIdCasoPai() == null ? EMPTY_STRING : caso.getIdCasoPai().toString();
			
		} else if (CamposCasoToExport.ID_ANALISTA.name().equals(campo.getKeyCampo())) {
			return caso.getLoginUsuario() == null ? EMPTY_STRING : caso.getLoginUsuario();
			
		} else if (CamposCasoToExport.ID_USUARIO_SUGERIDO.name().equals(campo.getKeyCampo())) {
			return caso.getLoginUsuarioSugerido() == null ? EMPTY_STRING : caso.getLoginUsuarioSugerido();
			
		} else if (CamposCasoToExport.ID_CONFIGURACAO_FILA.name().equals(campo.getKeyCampo())) {
			return caso.getNomeConfiguracaoFila() == null ? EMPTY_STRING : caso.getNomeConfiguracaoFila();
			
		} else if (CamposCasoToExport.ID_STATUS.name().equals(campo.getKeyCampo())) {
			return caso.getNomeStatus() == null ? EMPTY_STRING : caso.getNomeStatus();
			
		} else if (CamposCasoToExport.ID_EXTERNO.name().equals(campo.getKeyCampo())) {
			return caso.getIdExterno() == null ? EMPTY_STRING : caso.getIdExterno();
			
		} else if (CamposCasoToExport.ID_SLA_FILA.name().equals(campo.getKeyCampo())) {
			return caso.getSlaFilaTO() == null || caso.getSlaFilaTO().getDescricao() == null ? EMPTY_STRING : caso.getSlaFilaTO().getDescricao();
			
		} else if (CamposCasoToExport.ID_CAUSA.name().equals(campo.getKeyCampo())) {
			return caso.getNomeCausa() == null ? EMPTY_STRING : caso.getNomeCausa();
			
		} else if (CamposCasoToExport.ID_EVENTO.name().equals(campo.getKeyCampo())) {
			StringBuilder arvore = montaArvoreMotivos(caso);
			return arvore == null ? EMPTY_STRING : arvore.toString();
			
		} else if (CamposCasoToExport.ID_TIPO_CASO.name().equals(campo.getKeyCampo())) {
			return caso.getNomeTipoCaso() == null ? EMPTY_STRING : caso.getNomeTipoCaso();
			
		} else if (CamposCasoToExport.ID_CANAL.name().equals(campo.getKeyCampo())) {
			return caso.getNomeCanal() == null ? EMPTY_STRING : caso.getNomeCanal();
			
		} else if (CamposCasoToExport.ID_OUTRA_AREA.name().equals(campo.getKeyCampo())) {
			return caso.getNomeOutraArea() == null ? EMPTY_STRING : caso.getNomeOutraArea();
			
		} else if (CamposCasoToExport.ID_JUNCAO.name().equals(campo.getKeyCampo())) {
			return caso.getNomeJuncao() == null ? EMPTY_STRING : caso.getNomeJuncao();
			
		} else if (CamposCasoToExport.ID_OPERACAO.name().equals(campo.getKeyCampo())) {
			return caso.getNomeOperacao() == null ? EMPTY_STRING : caso.getNomeOperacao();
			
		} else if (CamposCasoToExport.DATA_ABERTURA.name().equals(campo.getKeyCampo())) {
			return formatData(caso.getDataAbertura());
			
		} else if (CamposCasoToExport.DATA_CADASTRO.name().equals(campo.getKeyCampo())) {
			return formatData(caso.getDataCadastro());
			
		} else if (CamposCasoToExport.DATA_ALTERACAO.name().equals(campo.getKeyCampo())) {
			return formatData(caso.getDataAlteracao());
			
		} else if (CamposCasoToExport.DATA_FIM_SLA.name().equals(campo.getKeyCampo())) {
			return formatData(caso.getDataFimSla());
			
		} else if (CamposCasoToExport.DATA_PREVISTA_FIM_SLA.name().equals(campo.getKeyCampo())) {
			return formatData(caso.getDataPrevistaFimSla());
			
		} else if (CamposCasoToExport.DATA_ENCERRAMENTO.name().equals(campo.getKeyCampo())) {
			return formatData(caso.getDataEncerramento());
			
		} else if (CamposCasoToExport.FLAG_CLASSIFICA.name().equals(campo.getKeyCampo())) {
			return formatBoolean(caso.isFlagClassifica());
			
		} else if (CamposCasoToExport.FLAG_FINALIZADO.name().equals(campo.getKeyCampo())) {
			return formatBoolean(caso.isFlagFinalizado());
			
		} else if (CamposCasoToExport.FLAG_CRIADO_MANUAL.name().equals(campo.getKeyCampo())) {
			return formatBoolean(caso.getFlagCriadoManual());
			
		} else if (CamposCasoToExport.FLAG_EM_ATENDIMENTO.name().equals(campo.getKeyCampo())) {
			return formatBoolean(caso.getFlagEmAtendimento());
			
		} else if (CamposCasoToExport.FLAG_REABERTO.name().equals(campo.getKeyCampo())) {
			return formatBoolean(caso.getFlagReaberto());
			
		} else if (CamposCasoToExport.FLAG_RECLASSIFICA_REABERTURA.name().equals(campo.getKeyCampo())) {
			return formatBoolean(caso.isFlagReclassificaReabertura());
			
		} else if (CamposCasoToExport.FLAG_TELEFONE_EDITADO.name().equals(campo.getKeyCampo())) {
			return formatBoolean(caso.getFlagTelefoneEditado());
			
		} else if (CamposCasoToExport.FLAG_RECHAMADO.name().equals(campo.getKeyCampo())) {
			return formatBoolean(caso.getFlagReaberto());
			
		} else {
			return EMPTY_STRING;
		}
	}
	
	private String formatPercent(Double val) {
		NumberFormat percentFormat = NumberFormat.getPercentInstance();
		percentFormat.setMaximumFractionDigits(1);
		return percentFormat.format(val);
	}
	
	private String formatBoolean(Boolean val) {
		if (val == null) {
			return EMPTY_STRING;
		}
		return val ? "SIM" : "NÃO";
	}
	
	private String formatData(Date val) {
		if (val == null) {
			return EMPTY_STRING;
		}
		return new SimpleDateFormat("dd/MM/YYYY HH:mm:ss").format(val);
	}
	
	private StringBuilder montaArvoreMotivos(CasoTO caso) {
		StringBuilder arvore = new StringBuilder();
		
		if (caso.getMotivo1Nome() != null) {
			arvore.append(caso.getMotivo1Nome());
			
			if (caso.getMotivo2Nome() != null) {
				arvore.append(" >>> ");
				arvore.append(caso.getMotivo2Nome());
				
				if (caso.getMotivo3Nome() != null) {
					arvore.append(" >>> ");
					arvore.append(caso.getMotivo3Nome());
					
					if (caso.getMotivo4Nome() != null) {
						arvore.append(" >>> ");
						arvore.append(caso.getMotivo4Nome());
						
						if (caso.getMotivo5Nome() != null) {
							arvore.append(" >>> ");
							arvore.append(caso.getMotivo5Nome());
							
							if (caso.getMotivo6Nome() != null) {
								arvore.append(" >>> ");
								arvore.append(caso.getMotivo6Nome());
							}
						}
					}
				}
			}
			
		} else {
			arvore.append(caso.getNomeEvento());
		}
		
		return arvore;
	}
	
	public void atualizaValorTipoLista(DadosDinamicos dadosDinamicos) throws Exception {
		if (dadosDinamicos.getValor() != null) {
			GrupoCampoDominioTO grupoCampoDominio = new GrupoCampoDominioTO();
			grupoCampoDominio.setIdGrupoCampoDominio((Integer) dadosDinamicos.getValor());
			
			if (grupoCampoDominio != null && grupoCampoDominio.getIdGrupoCampoDominio() != null) {
				List<CampoDominioSelecionadoTO> listCampoDominioSelecionados = campoDominioDAO.findCampoDominioSelecionadoByGrupo(grupoCampoDominio.getIdGrupoCampoDominio());
				List<String> listCampoDominios = new ArrayList<String>();
				for (CampoDominioSelecionadoTO campoDominioSelecionadoTmp : listCampoDominioSelecionados) {
					listCampoDominios.add(campoDominioSelecionadoTmp.getCampoDominio().getValor());
				}
				dadosDinamicos.setValorList(listCampoDominios);
			}
		}
	}
	
	public GrupoAnexoTO salvaGrupoAnexo(GrupoAnexoTO grupoAnexo, Integer idOperacao) throws Exception {
		if (grupoAnexo != null && grupoAnexo.getAnexoList() != null && !grupoAnexo.getAnexoList().isEmpty()) {
			grupoAnexo.setNome("log");
			grupoAnexo.setDescricao("log descricao");
			if (grupoAnexo.getPK() == null) {
				recebeEmailDAO.saveGrupoAnexo(grupoAnexo);
			} else {
				recebeEmailDAO.updateGrupoAnexo(grupoAnexo);
			}
			Date dataAtual = recebeEmailDAO.getDataBanco();
			if (grupoAnexo.getAnexoList() != null) {
				for (AnexoTO anexo : grupoAnexo.getAnexoList()) {
					if (anexo.getPK() == null) {
						anexo.setGrupoAnexo(grupoAnexo);
						anexo.setNomeFake(grupoAnexo.getPK() + anexo.getNomeReal());
						anexo.setDataCriacao(dataAtual);

						recebeEmailDAO.saveAnexo(anexo);

						try {
							ArquivoUtils.gravarArquivo(anexo.getNomeFake(), anexo.getDiretorio(), anexo.getDados());
						} catch (Exception e) {
							StringBuilder errors = new StringBuilder("[Operação: ");
							errors.append(idOperacao);
							errors.append("] ");
							errors.append("Erro ao salvar anexo em diretório: " + anexo.getDiretorio() + " - ");
							errors.append(e.getMessage());
							logger.log(Level.SEVERE, errors.toString(), e);
						}
					}
				}
			}
		}
		return grupoAnexo;
	}

}
