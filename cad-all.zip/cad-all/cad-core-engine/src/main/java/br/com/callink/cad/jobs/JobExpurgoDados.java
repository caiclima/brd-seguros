package br.com.callink.cad.jobs;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import br.com.callink.cad.dao.CasoDAO;
import br.com.callink.cad.dao.ParametroSistemaDAO;
import br.com.callink.cad.enumeration.ParametroSistemaOperacaoEnum;
import br.com.callink.cad.util.StringUtils;

/**
 * @author William D. Silva
 * 
 */
public class JobExpurgoDados extends CadJob {

	private String schemaDbReport;
	private Logger logger = Logger.getLogger(JobExpurgoDados.class.getName());
	private CasoDAO dao;
	private ParametroSistemaDAO parametroDao;

	/**
	 * Setup
	 * 
	 * @throws Exception
	 */
	private void setUp(Integer idTenant) throws Exception {

		if (dao == null) {
			dao = new CasoDAO();
		}

		if (parametroDao == null) {
			parametroDao = new ParametroSistemaDAO();
		}

		schemaDbReport = getSchemaDbReport(idTenant);
	}

	@Override
	protected void process(Integer idTenant, Integer idOperacao, String nome) throws Exception {

		logger.info("Inicio do processo de expurgo de dados");
		setUp(idTenant);
		String quantidadeDias = buscaParametroOperacao(ParametroSistemaOperacaoEnum.QTD_DIAS_EXPURGO_DADOS_GERAL.getParametroSistemaOperacao(), idOperacao, Boolean.FALSE);
		String diretorioAnexo = buscaParametroOperacao(ParametroSistemaOperacaoEnum.PARAM_DIRETORIO_ANEXO.getParametroSistemaOperacao(), idOperacao, Boolean.FALSE);
		Integer dias = Integer.parseInt(StringUtils.isEmpty(quantidadeDias) && StringUtils.isNumeric(quantidadeDias) ? "0":quantidadeDias);
		List<Integer> idCases = new ArrayList<Integer>();
		if (true) {
			try {
				idCases = extracaoDados(0, idOperacao);
	
				if (!idCases.isEmpty()) {
					realizaExpurgo(idCases, schemaDbReport, dias, idOperacao);
					dao.deleteArchivesByCase(idCases,diretorioAnexo);
				} else {
					realizaExpurgoPeriodo(schemaDbReport, dias, idOperacao);
					logger.info("Nenhum caso encontrado para realizar o expurgo");
				}
			} catch (Exception e) {
				StringBuilder str = new StringBuilder();
				str.append("Erro ao realizar o expurgo dos dados. Casos: ");
				if(idCases != null && !idCases.isEmpty()) {
					for(Integer i : idCases) {
						str.append(i).append(",");
					}
				}
				str.append(" - Schema: ").append(schemaDbReport).append(" - Dias: ").append(dias);
				
				logger.log(Level.SEVERE, str.toString());
				
				throw e;
			}
		}else{
			logger.info("=> Parametro de quantidades dos dias de expurgo é igual a Zero - Não será realizado o expurgo");
		}
	
		
		
	}

	/**
	 * Realizando expurgo de dados por periodo
	 * 
	 * @param schemaDB
	 * @param quantidadeDias
	 * @throws Exception
	 */
	private void realizaExpurgoPeriodo(String schemaDB, int quantidadeDias, Integer idOperacao) throws Exception {
		dao.realizaExpurgo(null, schemaDB, quantidadeDias, idOperacao);

	}

	/**
	 * Busca parametros para execução
	 * 
	 * @param string
	 * @param idOperacao
	 * @param isParametroOperacao
	 * @return
	 * @throws Exception
	 */
	private String buscaParametroOperacao(String string, Integer idOperacao, Boolean isParametroOperacao) throws Exception {
		logger.info("Buscando parametros para execução");
		String valor = "";
		try {
			if (isParametroOperacao) {
				valor = parametroDao.findValorParametroSistema(string);
			} else {
				valor = parametroDao.findValorParametroSistemaOperacao(string, idOperacao);
			}
		} catch (Exception e) {
			logger.info("=> Erro ao buscar parametro");
			throw new Exception(e);
		}

		return valor;
	}

	/**
	 * Realiza expurgo de dados por casos
	 * 
	 * @param idCases
	 * @param schemaDB
	 * @param quantidadeDias
	 * @throws Exception
	 */
	private void realizaExpurgo(List<Integer> idCases, String schemaDB, Integer quantidadeDias, Integer idOperacao) throws Exception {
		
		for (Integer id : idCases) {
			dao.insertLogExecution(id, quantidadeDias);
		}
		dao.realizaExpurgo(idCases, schemaDB, quantidadeDias, idOperacao);

	}

	/**
	 * Busca de casos para expurgo
	 * 
	 * @param quantidadeDias
	 * @return
	 * @throws Exception
	 */
	private List<Integer> extracaoDados(Integer quantidadeDias, Integer idOperacao) throws Exception {
		logger.info("Buscando casos para expurgo");
		List<Integer> ids = null;
		try {
			ids = dao.findByDateFinally(quantidadeDias, idOperacao);
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Erro ao buscar casos para expurgo",e);
			throw new Exception(e);
		}
		return ids;
	}

}
