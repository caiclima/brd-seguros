package br.com.callink.cad.jobs;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import br.com.callink.cad.dao.FinalizaStatusUsuarioInativoDAO;
import br.com.callink.cad.dao.ParametroSistemaDAO;
import br.com.callink.cad.enumeration.ParametroSistemaOperacaoEnum;

/**
 * @author swb_samuel
 * 
 */
public class JobFinalizaStatusUsuarioInativo extends CadJob {

	private final Logger logger = Logger.getLogger(getClass().getName());
	private ParametroSistemaDAO parametroSistemaDAO;
	private FinalizaStatusUsuarioInativoDAO dao;

	private void setUp() throws Exception {
		if (parametroSistemaDAO == null) {
			parametroSistemaDAO = new ParametroSistemaDAO();
		}

		if (dao == null) {
			dao = new FinalizaStatusUsuarioInativoDAO();
		}
	}

	@Override
	protected void process(Integer idTenant, Integer idOperacao, String nome) throws Exception {
		List<Integer> listaUsuario =null;
		try {
			setUp();
			logger.info("Buscando parametro tempoExpiraSession ");
			String minutosFinalizaSessao = parametroSistemaDAO.findValorParametroSistemaOperacao(
					ParametroSistemaOperacaoEnum.TEMPO_EXPIRA_SESSION.getParametroSistemaOperacao(), idOperacao);
	
			logger.info("Buscando usuarios inativos ");
			 listaUsuario = dao
					.validaFinalizaStatusUsuario(idOperacao, Integer.valueOf(minutosFinalizaSessao));
	
			logger.info("Atualizando casos  ");
			dao.atualizaFlagEmAtendimentoParaFalse(listaUsuario);
	
			logger.info("Atualizando registro de login ");
			dao.atualizaFlagLogado(listaUsuario);
	
			logger.info("Finalizando status do usuario");
			dao.finalizaStatusUsuarioSemDataFim();
		}catch (Exception e) {
			StringBuilder errors = new StringBuilder("[Operação: ");
			errors.append(idOperacao);
			errors.append("] ");
			if(listaUsuario != null) {
				errors.append("[Usuários :");
				for(Integer i:listaUsuario) {
					errors.append(String.format( "[ %d, ]", i));
				}
				errors.append("]");
			}
			errors.append(e.getMessage());
			logger.log(Level.SEVERE, errors.toString(), e);
			throw new Exception(e);
		}
	}
}
