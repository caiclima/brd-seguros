package br.com.callink.cad.jobs;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import br.com.callink.cad.crypto.impl.RSACryptoImpl;
import br.com.callink.cad.dao.ConfiguracaoCaixaEmailDAO;
import br.com.callink.cad.dao.NotificaCasoNaoClassificadoDAO;
import br.com.callink.cad.dao.ParametroSistemaDAO;
import br.com.callink.cad.enumeration.NotificacaoEnum;
import br.com.callink.cad.to.CasoTO;
import br.com.callink.cad.to.ConfiguracaoCaixaEmailTO;
import br.com.callink.cad.to.OperacaoTO;
import br.com.callink.cad.util.Constantes;
import br.com.callink.cad.util.ConstantesParametro;
import br.com.callink.cad.util.SendEmail;
import br.com.callink.cad.util.StringUtils;

/**
 * @author swb_brunocamargo
 * 
 */
public class JobNotificaCasoNaoClassificado extends CadJob {

	private Logger logger = Logger.getLogger(JobNotificaCasoNaoClassificado.class.getName());
	private NotificaCasoNaoClassificadoDAO dao;
	private ParametroSistemaDAO parametroSistemaDAO;
	private ConfiguracaoCaixaEmailDAO configuracaoCaixaEmailDAO;
	private StringBuilder conteudo;
	private String assunto;

	private void setUp() throws Exception {
		if (dao == null) {
			dao = new NotificaCasoNaoClassificadoDAO();
		}
		if (parametroSistemaDAO == null) {
			parametroSistemaDAO = new ParametroSistemaDAO();
		}
		if(configuracaoCaixaEmailDAO == null) {
			configuracaoCaixaEmailDAO = new ConfiguracaoCaixaEmailDAO();
		}
		if (conteudo == null) {
			conteudo = new StringBuilder().append(parametroSistemaDAO
					.findValorParametroSistema(ConstantesParametro.CORPO_EMAIL_NOTIF_CASO_NAO_CLASSIFICADO
							.getMnemonico()));
		}
		if (StringUtils.isEmpty(assunto)) {
			assunto = parametroSistemaDAO
					.findValorParametroSistema(ConstantesParametro.ASSUNTO_EMAIL_NOTIF_CASO_NAO_CLASSIFICADO
							.getMnemonico());
		}
	}

	@Override
	protected void process(Integer idTenant, Integer idOperacao, String nome) throws Exception {
		setUp();
		processarNotificacoes(idOperacao);
	}

	private void processarNotificacoes(Integer idOperacao) throws Exception {
		Date dataAtual = dao.getDataBanco();
		OperacaoTO operacao = dao.buscaDadosOperacao(idOperacao);

		if (operacao == null) {
			logger.info("Operacao nao encontrada ou inativa. Id: " + idOperacao);
		}

		List<String> casosNaoClassificados = new ArrayList<>();
		for (CasoTO caso : dao.buscaCasosSemFila(operacao.getIdOperacao())) {
			if (caso.getDataUltimoLog() != null
					&& dataAtual.getTime() - caso.getDataUltimoLog().getTime() > Constantes.TEMPO_LIMITE_CASO_NAO_CLASSIFICADO) {
				casosNaoClassificados.add(caso.getIdExterno());
			} else if (caso.getDataAbertura() != null
					&& dataAtual.getTime() - caso.getDataAbertura().getTime() > Constantes.TEMPO_LIMITE_CASO_NAO_CLASSIFICADO) {
				casosNaoClassificados.add(caso.getIdExterno());
			}
		}
		if (!casosNaoClassificados.isEmpty()) {
			if (StringUtils.isEmpty(operacao.getEmailsAdm())) {
				logger.warning("Nenhum destinatario configurado para a operacao: " + operacao.getNomeOperacao() + " Id: "
						+ operacao.getIdOperacao());
				return;
			}
			try {
				enviaEmail(operacao.getIdOperacao(), operacao.getEmailsAdm(), casosNaoClassificados);
			} catch (IllegalArgumentException iae) {
				logger.info(iae.getMessage() + " Operacao: " + operacao.getNomeOperacao() + " Id: "
						+ operacao.getIdOperacao());
			} catch (Exception e) {
				logger.info(e.getMessage());
				logger.info("Erro ao enviar email para a operacao: " + operacao.getNomeOperacao() + " Id: "
						+ operacao.getIdOperacao());
			}
		}
	}

	private void enviaEmail(Integer idOperacao, String destinatarios, List<String> idsExternos) throws Exception {
		ConfiguracaoCaixaEmailTO configuracaoCaixaEmailTO = null;
		try {
			configuracaoCaixaEmailTO = configuracaoCaixaEmailDAO.findAtivosPrincipalPorOperacao(idOperacao, Boolean.TRUE);
	
			if (configuracaoCaixaEmailTO == null || configuracaoCaixaEmailTO.getIdConfiguracaoCaixaEmail() == null) {
				logger.info("A operação id: " + idOperacao + " não possui caixa de email principal.");
				return;
			}
	
			String parametroEmailUsuario = configuracaoCaixaEmailTO.getUsuarioConfiguracaoCaixaEmail();
			String parametroEmailSenha = new RSACryptoImpl().decrypt(configuracaoCaixaEmailTO.getSenhaConfiguracaoCaixaEmail());
			String parametroEmailTransportProtocol = configuracaoCaixaEmailTO.getProtocolConfiguracaoCaixaEmail();
			String parametroEmailSmtpHost = configuracaoCaixaEmailTO.getSmtpConfiguracaoCaixaEmail();
			String parametroEmailSmtpPort = configuracaoCaixaEmailTO.getSmtpPortConfiguracaoCaixaEmail();
			String parametroEmailSmtpAuth = configuracaoCaixaEmailTO.getAuthConfiguracaoCaixaEmail();
	
			SendEmail sendEmail = new SendEmail(parametroEmailUsuario, parametroEmailSenha, parametroEmailTransportProtocol,
					parametroEmailSmtpHost, parametroEmailSmtpAuth,	parametroEmailSmtpPort);
	
			StringBuilder conteudo = this.conteudo;
			for (String idExterno : idsExternos) {
				conteudo.append("\n" + idExterno);
			}
			
			enviaNotificacaoAdmin(conteudo.toString(), NotificacaoEnum.ALERTA);
			
			sendEmail.send(parametroEmailUsuario, destinatarios, null, assunto, conteudo.toString(),null);
		} catch (Exception e) {
			StringBuilder errors = new StringBuilder("[Operação: ");
			errors.append(idOperacao);
			errors.append("] ");
			if(configuracaoCaixaEmailTO != null) {
				errors.append(String.format( "[Configuração de Email: %s ]", configuracaoCaixaEmailTO.getEmail()));
			}
			errors.append(e.getMessage());
			logger.log(Level.SEVERE, errors.toString(), e);
			throw new Exception(e);
		}
	}
}
