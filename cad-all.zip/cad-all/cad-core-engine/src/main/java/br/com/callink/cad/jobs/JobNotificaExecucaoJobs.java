package br.com.callink.cad.jobs;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import br.com.callink.cad.dao.AssociaOperacaoJobDAO;
import br.com.callink.cad.dao.ConfiguracaoCaixaEmailDAO;
import br.com.callink.cad.dao.NotificaCasoNaoClassificadoDAO;
import br.com.callink.cad.dao.ParametroSistemaDAO;
import br.com.callink.cad.dao.RecebeEmailDAO;
import br.com.callink.cad.enumeration.NotificacaoEnum;
import br.com.callink.cad.to.AssociaOperacaoJobTO;
import br.com.callink.cad.to.ConfiguracaoCaixaEmailTO;
import br.com.callink.cad.to.EmailTO;
import br.com.callink.cad.to.JobTO;
import br.com.callink.cad.to.OperacaoTO;
import br.com.callink.cad.util.DateUtils;
import br.com.callink.cad.util.StringUtils;

public class JobNotificaExecucaoJobs extends CadJob {

	private Logger logger = Logger.getLogger(JobNotificaExecucaoJobs.class.getName());
	private ParametroSistemaDAO parametroSistemaDAO;
	private RecebeEmailDAO recebeEmailDAO;
	private ConfiguracaoCaixaEmailDAO configuracaoCaixaEmailDAO;
	private NotificaCasoNaoClassificadoDAO notificaCasoNaoClassificadoDAO;
	private AssociaOperacaoJobDAO associaOperacaoJobDAO;
	private static final String PARAMETRO_NOTIFICACAO_EXECUCAO_JOBS = "flagNotificacaoExecucaoJobs";
	private static final String PARAMETRO_MINUTOS_EXECUCAO_JOBS = "minutosExecucaoJobs";
	
	private void setUp() throws Exception {
		if (parametroSistemaDAO == null) {
			parametroSistemaDAO = new ParametroSistemaDAO();
		}
		if (recebeEmailDAO == null) {
			recebeEmailDAO = new RecebeEmailDAO();
		}
		if (configuracaoCaixaEmailDAO == null) {
			configuracaoCaixaEmailDAO = new ConfiguracaoCaixaEmailDAO();
		}
		if (configuracaoCaixaEmailDAO == null) {
			configuracaoCaixaEmailDAO = new ConfiguracaoCaixaEmailDAO();
		}
		if (notificaCasoNaoClassificadoDAO == null) {
			notificaCasoNaoClassificadoDAO = new NotificaCasoNaoClassificadoDAO();
		}
		if (associaOperacaoJobDAO == null) {
			associaOperacaoJobDAO = new AssociaOperacaoJobDAO();
		}
	}

	@Override
	protected void process(Integer idTenant, Integer idOperacao, String nome) throws Exception {
		try {
			setUp();

			OperacaoTO operacao = notificaCasoNaoClassificadoDAO.buscaDadosOperacao(idOperacao);
			if (StringUtils.isEmpty(operacao.getEmailsAdm())) {
				logger.warning("Nenhum destinatário configurado para a operação: " + operacao.getNomeOperacao() + " Id: " + operacao.getIdOperacao());
				return;
			}
			
			ConfiguracaoCaixaEmailTO configuracaoCaixaEmailTO = configuracaoCaixaEmailDAO.findAtivosPrincipalPorOperacao(idOperacao, true);
			if (configuracaoCaixaEmailTO == null || configuracaoCaixaEmailTO.getIdConfiguracaoCaixaEmail() == null) {
				logger.log(Level.SEVERE, "Não existe caixa de email principal para a operação: " + idOperacao);
				return;
			}
			
			String flagNotifica = parametroSistemaDAO.findValorParametroSistemaOperacao(PARAMETRO_NOTIFICACAO_EXECUCAO_JOBS, idOperacao);
			if (flagNotifica == null || !Boolean.valueOf(flagNotifica)) {
				return;
			}
			
			String paramMinutosConfig = parametroSistemaDAO.findValorParametroSistemaOperacao(PARAMETRO_MINUTOS_EXECUCAO_JOBS, idOperacao);
			Integer minutosParam = paramMinutosConfig != null && !paramMinutosConfig.isEmpty() ? Integer.valueOf(paramMinutosConfig) : null;
			
			List<AssociaOperacaoJobTO> list = associaOperacaoJobDAO.findByOperacao(idOperacao);
			List<EmailTO> listaEmails = new ArrayList<EmailTO>();
			
			Date dataBanco = associaOperacaoJobDAO.getDataBanco();
			long minutosExecutando = 0;
			
			for (AssociaOperacaoJobTO associa : list) {
				minutosExecutando = 0;
				if (associa.getFlagExecutando() && associa.getDataStartExec().before(dataBanco)) {
					minutosExecutando = DateUtils.diferencaEmMinutos(associa.getDataStartExec(), dataBanco);
					
					if (associa.getMinutosExecucao() != null && associa.getMinutosExecucao() > 0) {
						if (minutosExecutando > associa.getMinutosExecucao()) {
							listaEmails.add(criaEmail(operacao.getEmailsAdm(), configuracaoCaixaEmailTO.getIdConfiguracaoCaixaEmail(),
									configuracaoCaixaEmailTO.getEmail(), idOperacao, associa.getJobTO(), associa.getMinutosExecucao(), minutosExecutando));
						}
					} else {
						if (minutosParam != null && minutosExecutando > minutosParam) {
							listaEmails.add(criaEmail(operacao.getEmailsAdm(), configuracaoCaixaEmailTO.getIdConfiguracaoCaixaEmail(),
									configuracaoCaixaEmailTO.getEmail(), idOperacao, associa.getJobTO(), minutosParam, minutosExecutando));
						}
					}
				}
			}
			salvaEmailsNotificacao(listaEmails);
		} catch (Exception ex) {
			StringBuilder errors = new StringBuilder("[Operação: ");
			errors.append(idOperacao);
			errors.append("] ");
			errors.append(ex.getMessage());
			logger.log(Level.SEVERE, errors.toString(), ex);
			throw new Exception(ex);
		}
	}
	
	private EmailTO criaEmail(String destinatarios, Integer idCaixaEmail, String remetente, Integer idOperacao,
			JobTO job, Integer minutosConfigurados, long minutosExecucao) throws Exception {
		EmailTO emailTO = new EmailTO();
		emailTO.setDataEnvio(recebeEmailDAO.getDataBanco());
		emailTO.setAssunto("Notificação tempo de execução excedido de job");
		emailTO.setDestinatario(destinatarios);
		emailTO.setRemetente(remetente);
		emailTO.setIdConfiguracaoCaixaEmail(idCaixaEmail);
		emailTO.setFlagPossuiCaso(Boolean.FALSE);
		emailTO.setFlagLido(Boolean.FALSE);
		emailTO.setFlagErroEnvio(Boolean.FALSE);
		emailTO.setFlagEnvio(Boolean.TRUE);
		emailTO.setFlagEnvioPendente(Boolean.TRUE);
		emailTO.setFlagDesativado(Boolean.FALSE);
		emailTO.setIdOperacao(idOperacao);
		
		StringBuilder sb = new StringBuilder();
		sb.append("A job de nome '").append(job.getNome()).append("' (Id: ").append(job.getId()).append(")")
		  .append(" ultrapassou o tempo de execução configurado na associação com operação.").append("<br/>")
		  .append("Minutos configurados: ").append(minutosConfigurados).append("<br/>")
		  .append("Tempo de execução decorrido: ").append(minutosExecucao).append(" minutos.");
		
		emailTO.setConteudo(sb.toString());
		
		enviaNotificacaoAdmin(emailTO.getConteudo(), NotificacaoEnum.ALERTA);
		
		return emailTO;
	}
	
	private void salvaEmailsNotificacao(List<EmailTO> emails) throws Exception {
		if (emails != null && !emails.isEmpty()) {
			for (EmailTO email : emails) {
				recebeEmailDAO.saveEmail(email);
			}
		}
	}
	
}
