package br.com.callink.cad.jobs;

import java.io.Reader;
import java.io.StringReader;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import listarcomentarios.server.ListarComentarios;
import listarcomentarios.server.ListarComentariosResponse;
import listarconsideracoesconsumidor.server.ListarConsideracoesConsumidor;
import listarconsideracoesconsumidor.server.ListarConsideracoesConsumidorResponse;
import listarconsideracoesempresa.server.ListarConsideracoesEmpresa;
import listarconsideracoesempresa.server.ListarConsideracoesEmpresaResponse;
import listarreclamacoes.server.ListarReclamacoes;
import listarreclamacoes.server.ListarReclamacoesResponse;
import listarreplicas.server.ListarReplicas;
import listarreplicas.server.ListarReplicasResponse;
import listarrespostas.server.ListarRespostas;
import listarrespostas.server.ListarRespostasResponse;

import org.joda.time.DateTimeConstants;

import autenticaparceiro.server.AutenticaParceiro;
import autenticaparceiro.server.AutenticaParceiroResponse;
import br.com.callink.cad.dao.CamposLayoutDAO;
import br.com.callink.cad.dao.ImportCasoDAO;
import br.com.callink.cad.dao.LayoutImportacaoDAO;
import br.com.callink.cad.dao.LoteCasoDAO;
import br.com.callink.cad.dao.ParametroSistemaDAO;
import br.com.callink.cad.dao.PreparaImportacaoRADAO;
import br.com.callink.cad.enumeration.ParametroSistemaOperacaoEnum;
import br.com.callink.cad.to.CamposLayoutTO;
import br.com.callink.cad.to.ControleAcessoReclameAquiTO;
import br.com.callink.cad.to.ImportCasoTO;
import br.com.callink.cad.to.LayoutImportacaoTO;
import br.com.callink.cad.to.LoteCasoTO;
import br.com.callink.cad.to.ParceiroReclameAquiTO;
import br.com.callink.cad.util.CollectionUtils;
import br.com.callink.cad.util.ConstantesParametro;
import br.com.callink.cad.util.DateUtils;
import br.com.callink.cad.util.StringUtils;
import br.com.callink.ra.enumaration.StatusConsideracao;
import br.com.callink.ra.enumaration.StatusReclamacao;
import br.com.callink.ra.exception.RAServiceException;
import br.com.callink.ra.to.ComentarioTO;
import br.com.callink.ra.to.ConsideracaoConsumidorTO;
import br.com.callink.ra.to.ConsideracaoEmpresaTO;
import br.com.callink.ra.to.ReclamacaoTO;
import br.com.callink.ra.to.ReplicaTO;
import br.com.callink.ra.to.RespostaTO;
import br.com.callink.ra.to.list.ComentarioList;
import br.com.callink.ra.to.list.ConsideracaoConsumidorList;
import br.com.callink.ra.to.list.ConsideracaoEmpresaList;
import br.com.callink.ra.to.list.ReclamacaoList;
import br.com.callink.ra.to.list.ReplicaList;
import br.com.callink.ra.to.list.RespostaList;
import empresas.server.DadosListaComentario;
import empresas.server.DadosListaReclamacao;
import empresas.server.DadosListaRegistro;
import empresas.server.DadosListaReplica;
import empresas.server.DadosParceiro;
import empresas.server.RegistrosDoWSDLStub;

public class JobPreparaImportacaoRA extends CadJob {

	private Logger logger = Logger.getLogger(JobPreparaImportacaoRA.class.getName());

	private PreparaImportacaoRADAO preparaImportacaoRADAO;
	private ParametroSistemaDAO parametroSistemaDAO;
	private LayoutImportacaoDAO layoutImportacaoDAO;
	private CamposLayoutDAO camposLayoutDAO;
	private LoteCasoDAO loteCasoDAO;
	private ImportCasoDAO dao;

	private final String MSG_CHAVE_EXPIRADA = "Chave Invalida ou expirada!";
	private final String TIPO_EXECUCAO = "AGENDADO";
	private final String TIPO_PROCESSO = "RA";
	private final String STATUS_EXECUCAO_IMPORTANDO = "IMPORTANDO";
	private final String STATUS_EXECUCAO_PENDENTE = "PENDENTE";
	private final String REPLICA_CONSUMIDOR = "CADASTRO";

	private enum CamposReclamacao {
		ID, ASSUNTO, TITULO, DATA, TEXTO, DADOS_COMPLEMENTARES, DATA_RESPOSTA, RESPOSTA, DATA_CONSIDERACAO, CONSIDERACAO, NOTA, NOME_RECLAMANTE, CPF_RECLAMANTE, RG_RECLAMANTE, EMAIL_RECLAMANTE, CONTATO1_RECLAMANTE, CONTATO2_RECLAMANTE, CONTATO3_RECLAMANTE, ESTADO_RECLAMANTE, CIDADE_RECLAMANTE, ;
	}

	private void setUp() throws Exception {
		if (preparaImportacaoRADAO == null) {
			preparaImportacaoRADAO = new PreparaImportacaoRADAO();
		}
		if (layoutImportacaoDAO == null) {
			layoutImportacaoDAO = new LayoutImportacaoDAO();
		}
		if (parametroSistemaDAO == null) {
			parametroSistemaDAO = new ParametroSistemaDAO();
		}
		if (camposLayoutDAO == null) {
			camposLayoutDAO = new CamposLayoutDAO();
		}
		if (loteCasoDAO == null) {
			loteCasoDAO = new LoteCasoDAO();
		}
		if (dao == null) {
			dao = new ImportCasoDAO();
		}
	}

	@Override
	protected void process(Integer idTenant, Integer idOperacao, String nome) throws Exception {
		setUp();

		List<LayoutImportacaoTO> listLayoutImportacaoTOs = layoutImportacaoDAO.buscaLayoutImportacaoByJob(getJobTO().getId());

		if (listLayoutImportacaoTOs == null || listLayoutImportacaoTOs.isEmpty()) {
			throw new Exception(" Não foi encontrado nenhum layout para a job: " + getJobTO().getNome());

		} else if (listLayoutImportacaoTOs.size() > 1) {
			throw new Exception(" Foi encontrado mais de um layout para a job: " + getJobTO().getNome());
		}

		final LayoutImportacaoTO layoutImportacaoTO = listLayoutImportacaoTOs.get(0);
		final ParceiroReclameAquiTO parceiro = preparaImportacaoRADAO.buscaParceiroPorLayout(layoutImportacaoTO.getIdLayout());

		if (parceiro == null) {
			throw new Exception(" Não foi encontrado nenhum parceiro associado ao layout: " + layoutImportacaoTO.getIdLayout());
		}

		final Date dataAtual = preparaImportacaoRADAO.getDataBanco();
		ControleAcessoReclameAquiTO ctrl = preparaImportacaoRADAO.buscaControleAcesso(parceiro.getIdParceiro());

		if (ctrl == null) {
			String token = autenticaParceiro(parceiro.getTargetEndpoint(), parceiro.getUsuario(), parceiro.getSenha(), parceiro.getIdEmpresa());
			ctrl = preparaImportacaoRADAO.salvaControleAcesso(parceiro.getIdParceiro(), token, dataAtual);
		}

		final Date dataUltimaExecucao = buscaDataUltimaExecucao(idOperacao);
		Date dataFim = null;
		Date dataIni = null;

		if (dataUltimaExecucao == null) {
			dataIni = DateUtils.addFirstTimeInDate(dataAtual);
			dataFim = DateUtils.addLastTimeInDate(dataAtual);

		} else {
			if (DateUtils.isSameDay(dataUltimaExecucao, dataAtual)) {
				dataIni = DateUtils.addFirstTimeInDate(dataUltimaExecucao);
				dataFim = DateUtils.addLastTimeInDate(dataAtual);

			} else {
				final String valorParametro = parametroSistemaDAO.findValorParametroSistema(ConstantesParametro.INTERVALO_MAXIMO_DIAS_PARA_CONSULTAS_RA
						.getMnemonico());

				final Integer dias = Integer.valueOf(valorParametro);

				if (DateUtils.diferencaEmSegundos(dataUltimaExecucao, dataAtual) > (dias * DateTimeConstants.SECONDS_PER_DAY)) {
					dataIni = dataUltimaExecucao;
					dataFim = DateUtils.somarDias(dataIni, dias);

				} else {
					dataIni = dataUltimaExecucao;
					dataFim = dataAtual;
				}
			}
		}

		execute(idOperacao, layoutImportacaoTO.getIdLayout(), layoutImportacaoTO.getIdStatusInicial(), layoutImportacaoTO.getIdStatusFinaliza(), parceiro,
				ctrl, dataFim, dataIni);
	}

	/**
	 * @param idOperacao
	 * @param layoutImportacaoTO
	 * @param parceiro
	 * @param ctrl
	 * @param dataFim
	 * @param dataIni
	 * @throws Exception
	 */
	private void execute(Integer idOperacao, final Integer idLayout, final Integer idStatusInicial, final Integer idStatusFinaliza,
			final ParceiroReclameAquiTO parceiro, ControleAcessoReclameAquiTO ctrl, Date dataFim, Date dataIni) throws Exception {

		final List<CamposLayoutTO> listCamposLayout = camposLayoutDAO.buscaCamposByLayout(idLayout);

		if (CollectionUtils.isEmpty(listCamposLayout)) {
			throw new Exception(" Não foi encontrado nenhum parceiro associado ao layout: " + idLayout);
		}

		final DateFormat df = new SimpleDateFormat("yyyyMMddHHmm");
		final String dataFinal = df.format(dataFim);
		final String dataInicial = df.format(dataIni);
		final String columnName = getCampoCasoRecId(listCamposLayout);

		/*
		 * Processa as reclamações do período e insere na import caso
		 */
		processarReclamacoes(idOperacao, idLayout, parceiro, ctrl, dataFinal, dataInicial, listCamposLayout);

		/*
		 * Insere um log para o caso correspondente à reclamação
		 */
		processarRespostas(parceiro, ctrl, dataFinal, dataInicial, columnName);

		/*
		 * Insere um log para o caso correspondente à reclamação
		 */
		processarComentarios(parceiro, ctrl, dataFinal, dataInicial, columnName);

		/*
		 * Insere um log para o caso correspondente à reclamação, e reabre o caso se o mesmo estiver fechado
		 */
		processarReplicas(parceiro, ctrl, dataFinal, dataInicial, columnName, idStatusInicial);

		/*
		 * Insere um log para o caso correspondente à reclamação e reabre ou finaliza o caso de acordo com o status da consideracao
		 */
		processarConsideracoes(parceiro, ctrl, dataFinal, dataInicial, columnName, idStatusInicial, idStatusFinaliza);

		atualizaControleDeAcesso(ctrl.getIdControleAcesso(), idLayout, columnName);
		atualizaDataUltimaExecucao(idOperacao, dataFim);
	}

	/**
	 * @param idOperacao
	 * @param idLayout
	 * @param parceiro
	 * @param ctrl
	 * @param dataFinal
	 * @param dataInicial
	 * @param listCamposLayout
	 * @return
	 * @throws Exception
	 */
	private void processarReclamacoes(final Integer idOperacao, final Integer idLayout, final ParceiroReclameAquiTO parceiro,
			final ControleAcessoReclameAquiTO ctrl, final String dataFinal, final String dataInicial, final List<CamposLayoutTO> listCamposLayout)
			throws Exception {

		LoteCasoTO loteCaso = null;
 		final String columnImport = getCampoImportRecId(listCamposLayout);
		final List<ImportCasoTO> listImportCasos = new ArrayList<ImportCasoTO>();

		ReclamacaoList listarReclamacoes = listarReclamacoes(parceiro, ctrl, dataInicial, dataFinal, StatusReclamacao.NAO_ATENDIDA.getId());
		if (listarReclamacoes != null) {
			if (loteCaso == null || loteCaso.getIdLoteCaso() == null) {
				loteCaso = salvarLoteCaso(idOperacao, idLayout);
			}
			listImportCasos.addAll(criaImportCaso(listCamposLayout, loteCaso, listarReclamacoes.getReclamacoes(), columnImport));
		}

		listarReclamacoes = listarReclamacoes(parceiro, ctrl, dataInicial, dataFinal, StatusReclamacao.ATENDIDA.getId());
		if (listarReclamacoes != null) {
			if (loteCaso == null || loteCaso.getIdLoteCaso() == null) {
				loteCaso = salvarLoteCaso(idOperacao, idLayout);
			}
			listImportCasos.addAll(criaImportCaso(listCamposLayout, loteCaso, listarReclamacoes.getReclamacoes(), columnImport));
		}

		listarReclamacoes = listarReclamacoes(parceiro, ctrl, dataInicial, dataFinal, StatusReclamacao.EM_REPLICA.getId());
		if (listarReclamacoes != null) {
			if (loteCaso == null || loteCaso.getIdLoteCaso() == null) {
				loteCaso = salvarLoteCaso(idOperacao, idLayout);
			}
			listImportCasos.addAll(criaImportCaso(listCamposLayout, loteCaso, listarReclamacoes.getReclamacoes(), columnImport));
		}

		listarReclamacoes = listarReclamacoes(parceiro, ctrl, dataInicial, dataFinal, StatusReclamacao.AVALIADA.getId());
		if (listarReclamacoes != null) {
			if (loteCaso == null || loteCaso.getIdLoteCaso() == null) {
				loteCaso = salvarLoteCaso(idOperacao, idLayout);
			}
			listImportCasos.addAll(criaImportCaso(listCamposLayout, loteCaso, listarReclamacoes.getReclamacoes(), columnImport));
		}

		orderListByRecId(listImportCasos, listCamposLayout);

		if (CollectionUtils.hasValue(listImportCasos)) {
			dao.inserImportCasoNative(listImportCasos);

			loteCasoDAO.atualizaStatusExecucaoLoteCaso(loteCaso.getIdLoteCaso(), STATUS_EXECUCAO_PENDENTE);
		}
	}

	/**
	 * @param parceiro
	 * @param ctrl
	 * @param dataFinal
	 * @param dataInicial
	 * @param columnName
	 * @return
	 * @throws Exception
	 */
	private void processarRespostas(final ParceiroReclameAquiTO parceiro, final ControleAcessoReclameAquiTO ctrl, final String dataFinal,
			final String dataInicial, final String columnName) throws Exception {

		final RespostaList listarRespostas = listarRespostas(parceiro, ctrl, dataInicial, dataFinal);
		if (listarRespostas != null) {
			List<RespostaTO> repostas = listarRespostas.getRepostas();

			if (CollectionUtils.hasValue(repostas)) {
				Collections.sort(repostas, new Comparator<RespostaTO>() {

					@Override
					public int compare(RespostaTO o1, RespostaTO o2) {
						return o1.getCodigo().compareTo(o2.getCodigo());
					}
				});
				
				repostas = preparaImportacaoRADAO.retiraRespostasProcessadas(repostas);

				/*
				 * salva um log da interação
				 */
				preparaImportacaoRADAO.salvarLogResposta(columnName, repostas);
			}
		}
	}

	/**
	 * @param parceiro
	 * @param ctrl
	 * @param dataFinal
	 * @param dataInicial
	 * @param columnName
	 * @throws Exception
	 */
	private void processarComentarios(final ParceiroReclameAquiTO parceiro, final ControleAcessoReclameAquiTO ctrl, final String dataFinal,
			final String dataInicial, final String columnName) throws Exception {

		final ComentarioList listarComentarios = listarComentarios(parceiro, ctrl, dataInicial, dataFinal);
		if (listarComentarios != null) {
			List<ComentarioTO> comentarios = listarComentarios.getComentarios();

			if (CollectionUtils.hasValue(comentarios)) {
				Collections.sort(comentarios, new Comparator<ComentarioTO>() {

					@Override
					public int compare(ComentarioTO o1, ComentarioTO o2) {
						return o1.getId().compareTo(o2.getId());
					}
				});
				
				comentarios = preparaImportacaoRADAO.retiraComentariosProcessados(comentarios);

				/*
				 * salva um log da interação
				 */
				preparaImportacaoRADAO.salvarLogComentario(columnName, comentarios);
			}
		}
	}

	/**
	 * @param parceiro
	 * @param ctrl
	 * @param dataFinal
	 * @param dataInicial
	 * @param columnName
	 * @param idStatus
	 * @return
	 * @throws Exception
	 */
	private void processarReplicas(final ParceiroReclameAquiTO parceiro, final ControleAcessoReclameAquiTO ctrl, final String dataFinal,
			final String dataInicial, final String columnName, final Integer idStatus) throws Exception {

		final ReplicaList listarReplicas = listarReplicas(parceiro, ctrl, dataInicial, dataFinal);
		if (listarReplicas != null) {
			List<ReplicaTO> replicas = listarReplicas.getReplicas();

			if (CollectionUtils.hasValue(replicas)) {
				Collections.sort(replicas, new Comparator<ReplicaTO>() {

					@Override
					public int compare(ReplicaTO o1, ReplicaTO o2) {
						return o1.getId().compareTo(o2.getId());
					}
				});
				
				replicas = preparaImportacaoRADAO.retiraReplicasProcessadas(replicas);
				
				// apenas reabre se houver nova replica do cosumidor
				final List<Long> reclamacoes = new ArrayList<Long>();
				for (ReplicaTO replicaTO : replicas) {
					if(replicaTO.getOrigem().equals(REPLICA_CONSUMIDOR)){
						reclamacoes.add(replicaTO.getReclamacao());
					}
				}

				/*
				 * Reabre o caso das reclamações, para possibilitar a realização das ações no CAD
				 */
				preparaImportacaoRADAO.reabrirCasos(idStatus, dao.getDataBanco(), columnName, reclamacoes);

				/*
				 * salva um log da interação
				 */
				preparaImportacaoRADAO.salvarLogReplica(columnName, replicas);
			}
		}
	}

	/**
	 * @param parceiro
	 * @param ctrl
	 * @param dataFinal
	 * @param dataInicial
	 * @param columnName
	 * @throws Exception
	 */
	private void processarConsideracoes(final ParceiroReclameAquiTO parceiro, final ControleAcessoReclameAquiTO ctrl, final String dataFinal,
			final String dataInicial, final String columnName, int idStatusInicial, int idStatusFinaliza) throws Exception {

		/*
		 * Considerações do consumidor
		 */
		final ConsideracaoConsumidorList listarConsideracoesConsumidor = listarConsideracoesConsumidor(parceiro, ctrl, dataInicial, dataFinal);
		if (listarConsideracoesConsumidor != null) {
			List<ConsideracaoConsumidorTO> consideracoes = listarConsideracoesConsumidor.getConsideracoes();

			if (CollectionUtils.hasValue(consideracoes)) {
				Collections.sort(consideracoes, new Comparator<ConsideracaoConsumidorTO>() {

					@Override
					public int compare(ConsideracaoConsumidorTO o1, ConsideracaoConsumidorTO o2) {
						return o1.getCodigo().compareTo(o2.getCodigo());
					}
				});

				consideracoes = preparaImportacaoRADAO.retiraConsideracoesProcessadas(consideracoes);
				
				/*
				 * Reabre o caso, se ele estiver fechado, das reclamações que tiveram considerações do consumidor com status 'nao resolvido', para que seja
				 * possivel realizar a acao de consideração final da empresa e solicitar mediacao
				 */
				final List<Long> reclamacoesNaoResolvidas = getRecIDFromConsideracoesNaoResolvidas(consideracoes);
				preparaImportacaoRADAO.reabrirCasos(idStatusInicial, dao.getDataBanco(), columnName, reclamacoesNaoResolvidas);

				/*
				 * Finaliza o caso, se ele estiver aberto, das reclamações que tiveram considerações do consumidor com status 'resolvido'
				 */
				final List<Long> reclamacoesResolvidas = getRecIDFromConsideracoesResolvidas(consideracoes);
				preparaImportacaoRADAO.finalizarCasos(idStatusFinaliza, dao.getDataBanco(), columnName, reclamacoesResolvidas);

				/*
				 * salva um log da interação
				 */
				preparaImportacaoRADAO.salvarLogConsideracaoConsumidor(columnName, consideracoes);
			}
		}

		/*
		 * Considerações da empresa
		 */
		final ConsideracaoEmpresaList listarConsideracoesEmpresa = listarConsideracoesEmpresa(parceiro, ctrl, dataInicial, dataFinal);
		if (listarConsideracoesEmpresa != null) {
			final List<ConsideracaoEmpresaTO> consideracoes = listarConsideracoesEmpresa.getConsideracoes();

			if (CollectionUtils.hasValue(consideracoes)) {
				Collections.sort(consideracoes, new Comparator<ConsideracaoEmpresaTO>() {

					@Override
					public int compare(ConsideracaoEmpresaTO o1, ConsideracaoEmpresaTO o2) {
						return o1.getCodigo().compareTo(o2.getCodigo());
					}
				});

				/*
				 * salva um log da interação
				 */
				preparaImportacaoRADAO.salvarLogConsideracaoEmpresa(columnName, consideracoes);
			}
		}
	}

	/**
	 * @param consideracoes
	 * @return
	 */
	private List<Long> getRecIDFromConsideracoesNaoResolvidas(final List<ConsideracaoConsumidorTO> consideracoes) {
		final List<Long> reclamacoes = new ArrayList<Long>();
		for (ConsideracaoConsumidorTO consideracaoTO : consideracoes) {
			if (StatusConsideracao.NAO_RESOLVIDO.getValor().equalsIgnoreCase(consideracaoTO.getStatus())) {
				reclamacoes.add(consideracaoTO.getReclamacao());
			}
		}
		return reclamacoes;
	}

	private List<Long> getRecIDFromConsideracoesResolvidas(final List<ConsideracaoConsumidorTO> consideracoes) {
		final List<Long> reclamacoes = new ArrayList<Long>();
		for (ConsideracaoConsumidorTO consideracaoTO : consideracoes) {
			if (StatusConsideracao.RESOLVIDO.getValor().equalsIgnoreCase(consideracaoTO.getStatus())) {
				reclamacoes.add(consideracaoTO.getReclamacao());
			}
		}
		return reclamacoes;
	}
	
	/**
	 * Autentica um parceiro na base de dados do ReclameAQUI®, todos os usuários autenticados pelo WebService devem estar préviamente cadastrados. Este método
	 * retorna uma chave de acesso, que tem vigência de 3 horas, e deve ser utilizada na chamada de todos os demais métodos do WebService.
	 * 
	 * @param usuario
	 * @param senha
	 * @param idEmpresa
	 * @return
	 * @throws RAServiceException
	 */
	public String autenticaParceiro(String targetEndpoint, String usuario, String senha, int idEmpresa) throws RAServiceException {
		try {
			logger.info("autenticaParceiro...");
			final DadosParceiro input = new DadosParceiro();
			input.setUsuario(usuario);
			input.setSenha(senha);
			input.setEmpresa(idEmpresa);

			final AutenticaParceiro param = new AutenticaParceiro();
			param.setDadosParceiro(input);

			final RegistrosDoWSDLStub stub = new RegistrosDoWSDLStub(targetEndpoint);
			final AutenticaParceiroResponse response = stub.autenticaParceiro(param);

			return response.getRetorno();

		} catch (Exception e) {
			logger.log(Level.SEVERE, e.getMessage(), e);
			throw new RAServiceException(e.getMessage(), e);
		}
	}

	/**
	 * Este método lista reclamações por status, até 50 por vez, entre um determinado período de tempo. A diferença entre a data inicial e final não pode ser
	 * superior a 7 dias.
	 * 
	 * @param parceiro
	 * @param ctrl
	 * @param dataInicial
	 *            - string (yyyyMMddHHmm)
	 * @param dataFinal
	 *            - string (yyyyMMddHHmm)
	 * @param tipo
	 *            - Status das reclamações desejadas (Não Atendida => 1,Atendida => 2,Em Replica => 3,Avaliada / Finalizada => 4)
	 * @return
	 * @throws RAServiceException
	 */
	public ReclamacaoList listarReclamacoes(ParceiroReclameAquiTO parceiro, ControleAcessoReclameAquiTO ctrl, String dataInicial, String dataFinal, int tipo)
			throws RAServiceException {

		try {
			logger.info("listarReclamacoes...");
			final DadosListaReclamacao input = new DadosListaReclamacao();
			input.setChaveAcesso(ctrl.getUltimaChaveAcesso());
			input.setDataFinal(dataFinal);
			input.setDataInicial(dataInicial);
			input.setRecInicial(ctrl.getIdUltimaRecImportada() == null ? 0 : ctrl.getIdUltimaRecImportada());
			input.setTipo(tipo);

			final ListarReclamacoes param = new ListarReclamacoes();
			param.setDadosListaReclamacao(input);

			final RegistrosDoWSDLStub stub = new RegistrosDoWSDLStub(parceiro.getTargetEndpoint());
			final ListarReclamacoesResponse response = stub.listarReclamacoes(param);

			if (response != null && StringUtils.isNotEmpty(response.getRetorno())) {
				logger.info(response.getRetorno());

				if (!response.getRetorno().contains("<registros>")) {
					if (response.getRetorno().equals(MSG_CHAVE_EXPIRADA)) {
						final String chaveAcesso = autenticaParceiro(parceiro.getTargetEndpoint(), parceiro.getUsuario(), parceiro.getSenha(),
								parceiro.getIdEmpresa());
						ctrl = preparaImportacaoRADAO.atualizaControleAcesso(ctrl.getIdControleAcesso(), ctrl.getIdParceiro(), ctrl.getIdUltimaRecImportada(),
								chaveAcesso);
						return listarReclamacoes(parceiro, ctrl, dataInicial, dataFinal, tipo);
					}

					return null;
				}

				return (ReclamacaoList) unmarshall(response.getRetorno(), ReclamacaoList.class, true);
			}

			return null;

		} catch (Exception e) {
			logger.log(Level.SEVERE, e.getMessage(), e);
			throw new RAServiceException(e.getMessage(), e);
		}
	}

	/**
	 * Este método lista os comentários de consumidores, até 50 por vez, postados em uma determinada faixa de tempo. A diferença entre a data inicial e final
	 * não pode ser superior a 7 dias.
	 * 
	 * @param parceiro
	 * @param ctrl
	 * @param dataInicial
	 *            - string (yyyyMMddHHmm)
	 * @param dataFinal
	 *            - string (yyyyMMddHHmm)
	 * @return
	 * @throws RAServiceException
	 */
	public RespostaList listarRespostas(ParceiroReclameAquiTO parceiro, ControleAcessoReclameAquiTO ctrl, String dataInicial, String dataFinal)
			throws RAServiceException {

		try {
			logger.info("listarRespostas...");
			final DadosListaRegistro input = new DadosListaRegistro();
			input.setChaveAcesso(ctrl.getUltimaChaveAcesso());
			input.setDataFinal(dataFinal);
			input.setDataInicial(dataInicial);
			input.setPosicao(0);

			final ListarRespostas param = new ListarRespostas();
			param.setDadosListaRegistro(input);

			final RegistrosDoWSDLStub stub = new RegistrosDoWSDLStub(parceiro.getTargetEndpoint());
			final ListarRespostasResponse response = stub.listarRespostas(param);

			if (response != null && StringUtils.isNotEmpty(response.getRetorno())) {
				logger.info(response.getRetorno());

				if (!response.getRetorno().contains("<registros>")) {
					if (response.getRetorno().equals(MSG_CHAVE_EXPIRADA)) {
						final String chaveAcesso = autenticaParceiro(parceiro.getTargetEndpoint(), parceiro.getUsuario(), parceiro.getSenha(),
								parceiro.getIdEmpresa());
						ctrl = preparaImportacaoRADAO.atualizaControleAcesso(ctrl.getIdControleAcesso(), ctrl.getIdParceiro(), ctrl.getIdUltimaRecImportada(),
								chaveAcesso);
						return listarRespostas(parceiro, ctrl, dataInicial, dataFinal);
					}

					return null;
				}

				return (RespostaList) unmarshall(response.getRetorno(), RespostaList.class, false);
			}

			return null;

		} catch (Exception e) {
			logger.log(Level.SEVERE, e.getMessage(), e);
			throw new RAServiceException(e.getMessage(), e);
		}
	}

	/**
	 * @param parceiro
	 * @param ctrl
	 * @param dataInicial
	 * @param dataFinal
	 * @return
	 * @throws RAServiceException
	 */
	public ComentarioList listarComentarios(ParceiroReclameAquiTO parceiro, ControleAcessoReclameAquiTO ctrl, String dataInicial, String dataFinal)
			throws RAServiceException {

		try {
			logger.info("listarComentarios...");
			final DadosListaComentario input = new DadosListaComentario();
			input.setChaveAcesso(ctrl.getUltimaChaveAcesso());
			input.setDataFinal(dataFinal);
			input.setDataInicial(dataInicial);
			input.setComInicial(0);

			final ListarComentarios param = new ListarComentarios();
			param.setDadosListaComentario(input);

			final RegistrosDoWSDLStub stub = new RegistrosDoWSDLStub(parceiro.getTargetEndpoint());
			final ListarComentariosResponse response = stub.listarComentarios(param);

			if (response != null && StringUtils.isNotEmpty(response.getRetorno())) {
				logger.info(response.getRetorno());

				if (!response.getRetorno().contains("<registros>")) {
					if (response.getRetorno().equals(MSG_CHAVE_EXPIRADA)) {
						final String chaveAcesso = autenticaParceiro(parceiro.getTargetEndpoint(), parceiro.getUsuario(), parceiro.getSenha(),
								parceiro.getIdEmpresa());
						ctrl = preparaImportacaoRADAO.atualizaControleAcesso(ctrl.getIdControleAcesso(), ctrl.getIdParceiro(), ctrl.getIdUltimaRecImportada(),
								chaveAcesso);
						return listarComentarios(parceiro, ctrl, dataInicial, dataFinal);
					}

					return null;
				}

				return (ComentarioList) unmarshall(response.getRetorno(), ComentarioList.class, false);
			}

			return null;

		} catch (Exception e) {
			logger.log(Level.SEVERE, e.getMessage(), e);
			throw new RAServiceException(e.getMessage(), e);
		}
	}

	/**
	 * Este método lista réplicas, até 50 por vez, entre um determinado período de tempo. A diferença entre a data inicial e final não pode ser superior a 7
	 * dias.
	 * 
	 * @param parceiro
	 * @param ctrl
	 * @param dataInicial
	 *            - string (yyyyMMddHHmm)
	 * @param dataFinal
	 *            - string (yyyyMMddHHmm)
	 * @return
	 * @throws RAServiceException
	 */
	public ReplicaList listarReplicas(ParceiroReclameAquiTO parceiro, ControleAcessoReclameAquiTO ctrl, String dataInicial, String dataFinal)
			throws RAServiceException {

		try {
			logger.info("listarReplicas...");
			final DadosListaReplica input = new DadosListaReplica();
			input.setChaveAcesso(ctrl.getUltimaChaveAcesso());
			input.setDataFinal(dataFinal);
			input.setDataInicial(dataInicial);
			input.setRepInicial(ctrl.getIdUltimaRepImportada() == null ? 0 : ctrl.getIdUltimaRepImportada());

			final ListarReplicas param = new ListarReplicas();
			param.setDadosListaReplica(input);

			final RegistrosDoWSDLStub stub = new RegistrosDoWSDLStub(parceiro.getTargetEndpoint());
			final ListarReplicasResponse response = stub.listarReplicas(param);

			if (response != null && StringUtils.isNotEmpty(response.getRetorno())) {
				logger.info(response.getRetorno());

				if (!response.getRetorno().contains("<registros>")) {
					if (response.getRetorno().equals(MSG_CHAVE_EXPIRADA)) {
						final String chaveAcesso = autenticaParceiro(parceiro.getTargetEndpoint(), parceiro.getUsuario(), parceiro.getSenha(),
								parceiro.getIdEmpresa());
						ctrl = preparaImportacaoRADAO.atualizaControleAcesso(ctrl.getIdControleAcesso(), ctrl.getIdParceiro(), ctrl.getIdUltimaRecImportada(),
								chaveAcesso);
						return listarReplicas(parceiro, ctrl, dataInicial, dataFinal);
					}

					return null;
				}

				return (ReplicaList) unmarshall(response.getRetorno(), ReplicaList.class, false);
			}

			return null;

		} catch (Exception e) {
			logger.log(Level.SEVERE, e.getMessage(), e);
			throw new RAServiceException(e.getMessage(), e);
		}
	}

	/**
	 * Este método lista considerações finais da empresa, até 50 por vez, entre um determinado período de tempo. A diferença entre a data inicial e final não
	 * pode ser superior a 7 dias.
	 * 
	 * @param parceiro
	 * @param ctrl
	 * @param dataInicial
	 *            - string (aaaammddhhii)
	 * @param dataFinal
	 *            - string (aaaammddhhii)
	 * @return
	 * @throws RAServiceException
	 */
	public ConsideracaoEmpresaList listarConsideracoesEmpresa(ParceiroReclameAquiTO parceiro, ControleAcessoReclameAquiTO ctrl, String dataInicial,
			String dataFinal) throws RAServiceException {

		try {
			logger.info("listarConsideracoesEmpresa...");
			final DadosListaRegistro input = new DadosListaRegistro();
			input.setChaveAcesso(ctrl.getUltimaChaveAcesso());
			input.setDataFinal(dataFinal);
			input.setDataInicial(dataInicial);
			input.setPosicao(0);

			final ListarConsideracoesEmpresa param = new ListarConsideracoesEmpresa();
			param.setDadosListaRegistro(input);

			final RegistrosDoWSDLStub stub = new RegistrosDoWSDLStub(parceiro.getTargetEndpoint());
			final ListarConsideracoesEmpresaResponse response = stub.listarConsideracoesEmpresa(param);

			if (response != null && StringUtils.isNotEmpty(response.getRetorno())) {
				logger.info(response.getRetorno());

				if (!response.getRetorno().contains("<registros>")) {
					if (response.getRetorno().equals(MSG_CHAVE_EXPIRADA)) {
						final String chaveAcesso = autenticaParceiro(parceiro.getTargetEndpoint(), parceiro.getUsuario(), parceiro.getSenha(),
								parceiro.getIdEmpresa());
						ctrl = preparaImportacaoRADAO.atualizaControleAcesso(ctrl.getIdControleAcesso(), ctrl.getIdParceiro(), ctrl.getIdUltimaRecImportada(),
								chaveAcesso);
						return listarConsideracoesEmpresa(parceiro, ctrl, dataInicial, dataFinal);
					}

					return null;
				}

				return (ConsideracaoEmpresaList) unmarshall(response.getRetorno(), ConsideracaoEmpresaList.class, false);
			}

			return null;

		} catch (Exception e) {
			logger.log(Level.SEVERE, e.getMessage(), e);
			throw new RAServiceException(e.getMessage(), e);
		}
	}

	/**
	 * Este método lista considerações finais de consumidores, até 50 por vez, entre um determinado período de tempo. A diferença entre a data inicial e final
	 * não pode ser superior a 7 dias
	 * 
	 * @param parceiro
	 * @param ctrl
	 * @param dataInicial
	 *            - string (aaaammddhhii)
	 * @param dataFinal
	 *            - string (aaaammddhhii)
	 * @return
	 * @throws RAServiceException
	 */
	public ConsideracaoConsumidorList listarConsideracoesConsumidor(ParceiroReclameAquiTO parceiro, ControleAcessoReclameAquiTO ctrl, String dataInicial,
			String dataFinal) throws RAServiceException {

		try {
			logger.info("listarConsideracoesConsumidor...");
			final DadosListaRegistro input = new DadosListaRegistro();
			input.setChaveAcesso(ctrl.getUltimaChaveAcesso());
			input.setDataFinal(dataFinal);
			input.setDataInicial(dataInicial);
			input.setPosicao(0);

			final ListarConsideracoesConsumidor param = new ListarConsideracoesConsumidor();
			param.setDadosListaRegistro(input);

			final RegistrosDoWSDLStub stub = new RegistrosDoWSDLStub(parceiro.getTargetEndpoint());
			final ListarConsideracoesConsumidorResponse response = stub.listarConsideracoesConsumidor(param);

			if (response != null && StringUtils.isNotEmpty(response.getRetorno())) {
				logger.info(response.getRetorno());

				if (!response.getRetorno().contains("<registros>")) {
					if (response.getRetorno().equals(MSG_CHAVE_EXPIRADA)) {
						final String chaveAcesso = autenticaParceiro(parceiro.getTargetEndpoint(), parceiro.getUsuario(), parceiro.getSenha(),
								parceiro.getIdEmpresa());
						ctrl = preparaImportacaoRADAO.atualizaControleAcesso(ctrl.getIdControleAcesso(), ctrl.getIdParceiro(), ctrl.getIdUltimaRecImportada(),
								chaveAcesso);
						return listarConsideracoesConsumidor(parceiro, ctrl, dataInicial, dataFinal);
					}

					return null;
				}

				return (ConsideracaoConsumidorList) unmarshall(response.getRetorno(), ConsideracaoConsumidorList.class, false);
			}

			return null;

		} catch (Exception e) {
			logger.log(Level.SEVERE, e.getMessage(), e);
			throw new RAServiceException(e.getMessage(), e);
		}
	}

	/**
	 * @param xmlString
	 * @param clazz
	 * @return
	 * @throws XMLStreamException
	 * @throws JAXBException
	 */
	private Object unmarshall(String xmlString, Class<?> clazz, boolean replaceRegistros) throws XMLStreamException, JAXBException {
		if (replaceRegistros) {
			xmlString = xmlString.replace("<registros>", "").replace("</registros>", "");
		}
		Reader reader = new StringReader(xmlString);
		XMLInputFactory factory = XMLInputFactory.newInstance();
		XMLStreamReader xmlReader = factory.createXMLStreamReader(reader);

		final JAXBContext jaxbContext = JAXBContext.newInstance(new Class[] { clazz });
		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();

		return jaxbUnmarshaller.unmarshal(xmlReader);
	}

	/**
	 * @param idOperacao
	 * @param idLayout
	 * @return
	 * @throws Exception
	 */
	private LoteCasoTO salvarLoteCaso(final Integer idOperacao, final int idLayout) throws Exception {
		logger.info("Salvando lote caso...");
		LoteCasoTO loteCaso = new LoteCasoTO();
		loteCaso.setHorarioAgendamento(loteCasoDAO.getDataBanco());
		loteCaso.setTipoExecucao(TIPO_EXECUCAO);
		loteCaso.setStatusExecucao(STATUS_EXECUCAO_IMPORTANDO);
		loteCaso.setTipoProcesso(TIPO_PROCESSO);
		loteCaso.setFlagAtivo(Boolean.TRUE);
		loteCaso.setIdOperacao(idOperacao);
		loteCaso.setIdLayout(idLayout);
		loteCaso = loteCasoDAO.savarLoteCaso(loteCaso);
		logger.info("Lote caso salvo com sucesso. ID: " + loteCaso.getIdLayout());

		return loteCaso;
	}

	/**
	 * @param listCamposLayout
	 * @param loteCaso
	 * @param reclamacoes
	 * @return
	 * @throws Exception
	 */
	private List<ImportCasoTO> criaImportCaso(List<CamposLayoutTO> listCamposLayout, LoteCasoTO loteCaso, List<ReclamacaoTO> reclamacoes, String columnImport) throws Exception {
		reclamacoes = preparaImportacaoRADAO.retiraReclamacoesProcessadas(reclamacoes, columnImport);
		
		List<ImportCasoTO> listImportCasos = new ArrayList<ImportCasoTO>();
		if (reclamacoes != null && CollectionUtils.hasValue(reclamacoes)) {
			for (ReclamacaoTO rec : reclamacoes) {
				ImportCasoTO importCaso = setParametrosImportCaso(listCamposLayout, rec, loteCaso.getIdLayout());
				importCaso.setIdLayout(loteCaso.getIdLayout());
				importCaso.setIdLoteCaso(loteCaso.getIdLoteCaso());
				importCaso.setFlagImportRejeitado(Boolean.FALSE);
				listImportCasos.add(importCaso);
			}
		}
		return listImportCasos;
	}

	/**
	 * @param idOperacao
	 * @return
	 * @throws Exception
	 */
	private Date buscaDataUltimaExecucao(Integer idOperacao) throws Exception {
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date dataUltimaExecucao = null;

		try {
			String valorParametro = parametroSistemaDAO.findValorParametroSistemaOperacao(
					ParametroSistemaOperacaoEnum.ULTIMA_EXECUCAO_IMPORTACAO_RA.getParametroSistemaOperacao(), idOperacao);

			if (StringUtils.isNotEmpty(valorParametro)) {
				dataUltimaExecucao = df.parse(valorParametro);
			}
		} catch (Exception e) {
			logger.info(e.getMessage());
			logger.info("Erro ao obter parâmetro de data última execução. Parâmetro: "
					+ ParametroSistemaOperacaoEnum.ULTIMA_EXECUCAO_IMPORTACAO_RA.getParametroSistemaOperacao() + ", operação: " + idOperacao);
		}
		return dataUltimaExecucao;
	}

	/**
	 * @param idControleAcesso
	 * @param lastId
	 * @throws Exception
	 */
	private void atualizaControleDeAcesso(final int idControleAcesso, final int idLayout, String campoCaso) throws Exception {
		logger.info("Atualizando controle de acesso");
		preparaImportacaoRADAO.atualizaControleAcesso(idControleAcesso, idLayout, campoCaso);
	}

	/**
	 * Atualiza execução da job
	 * 
	 * @param idOperacao
	 * @param data
	 * @throws Exception
	 */
	private void atualizaDataUltimaExecucao(Integer idOperacao, Date data) throws Exception {
		logger.info("atualizando data da última execução...");
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			parametroSistemaDAO.atualizaValorParametroSistemaOperacao(ParametroSistemaOperacaoEnum.ULTIMA_EXECUCAO_IMPORTACAO_RA.getParametroSistemaOperacao(),
					idOperacao, df.format(data));
		} catch (Exception e) {
			logger.info(e.getMessage());
			logger.info("Erro ao atualizar parâmetro de data última execução. Parâmetro: "
					+ ParametroSistemaOperacaoEnum.ULTIMA_EXECUCAO_IMPORTACAO_RA.getParametroSistemaOperacao() + ", operação: " + idOperacao);
		}
	}

	/**
	 * @param listImportCasos
	 * @param listCamposLayout
	 */
	private void orderListByRecId(final List<ImportCasoTO> listImportCasos, final List<CamposLayoutTO> listCamposLayout) {
		final String key = getCampoImportRecId(listCamposLayout);
		Collections.sort(listImportCasos, new Comparator<ImportCasoTO>() {

			@Override
			public int compare(ImportCasoTO o1, ImportCasoTO o2) {
				return o1.getMapDados().get(key).compareTo(o2.getMapDados().get(key));
			}
		});
	}

	/**
	 * @param listCamposLayout
	 * @return
	 */
	private String getCampoImportRecId(List<CamposLayoutTO> listCamposLayout) {
		for (CamposLayoutTO campoLayout : listCamposLayout) {
			if (CamposReclamacao.ID.name().equals(campoLayout.getCammpoNome())) {
				return campoLayout.getCampoImportCaso();
			}
		}
		return null;
	}

	/**
	 * @param listCamposLayout
	 * @return
	 */
	private String getCampoCasoRecId(List<CamposLayoutTO> listCamposLayout) {
		for (CamposLayoutTO campoLayout : listCamposLayout) {
			if (CamposReclamacao.ID.name().equals(campoLayout.getCammpoNome())) {
				return campoLayout.getCampoCaso();
			}
		}
		return null;
	}

	/**
	 * @param listCamposLayout
	 * @param recTo
	 * @param idLayout
	 * @return
	 * @throws Exception
	 */
	private ImportCasoTO setParametrosImportCaso(List<CamposLayoutTO> listCamposLayout, ReclamacaoTO recTo, Integer idLayout) throws Exception {
		ImportCasoTO importCaso = new ImportCasoTO();

		for (CamposLayoutTO campoLayout : listCamposLayout) {
			if (CamposReclamacao.ID.name().equals(campoLayout.getCammpoNome())) {
				if (recTo.getId() != null) {
					importCaso.getMapDados().put(campoLayout.getCampoImportCaso(), recTo.getId().toString());
				} else {
					importCaso.getMapDados().put(campoLayout.getCampoImportCaso(), null);
				}
			}
			if (CamposReclamacao.ASSUNTO.name().equals(campoLayout.getCammpoNome())) {
				if (StringUtils.isNotEmpty(recTo.getAssunto())) {
					importCaso.getMapDados().put(campoLayout.getCampoImportCaso(), recTo.getAssunto());
				} else {
					importCaso.getMapDados().put(campoLayout.getCampoImportCaso(), null);
				}
			}
			if (CamposReclamacao.TITULO.name().equals(campoLayout.getCammpoNome())) {
				if (StringUtils.isNotEmpty(recTo.getTitulo())) {
					importCaso.getMapDados().put(campoLayout.getCampoImportCaso(), recTo.getTitulo());
				} else {
					importCaso.getMapDados().put(campoLayout.getCampoImportCaso(), null);
				}
			}
			if (CamposReclamacao.DATA.name().equals(campoLayout.getCammpoNome())) {
				if (recTo.getData() != null) {
					importCaso.getMapDados().put(campoLayout.getCampoImportCaso(), new Timestamp(recTo.getData().getTime()).toString());
				} else {
					importCaso.getMapDados().put(campoLayout.getCampoImportCaso(), null);
				}
			}
			if (CamposReclamacao.TEXTO.name().equals(campoLayout.getCammpoNome())) {
				if (StringUtils.isNotEmpty(recTo.getTexto())) {
					importCaso.getMapDados().put(campoLayout.getCampoImportCaso(), recTo.getTexto());
				} else {
					importCaso.getMapDados().put(campoLayout.getCampoImportCaso(), null);
				}
			}
			if (CamposReclamacao.DADOS_COMPLEMENTARES.name().equals(campoLayout.getCammpoNome())) {
				if (StringUtils.isNotEmpty(recTo.getDados_complementares())) {
					importCaso.getMapDados().put(campoLayout.getCampoImportCaso(), recTo.getDados_complementares());
				} else {
					importCaso.getMapDados().put(campoLayout.getCampoImportCaso(), null);
				}
			}
			if (CamposReclamacao.DATA_RESPOSTA.name().equals(campoLayout.getCammpoNome())) {
				if (recTo.getData_resposta() != null) {
					importCaso.getMapDados().put(campoLayout.getCampoImportCaso(), new Timestamp(recTo.getData_resposta().getTime()).toString());
				} else {
					importCaso.getMapDados().put(campoLayout.getCampoImportCaso(), null);
				}
			}
			if (CamposReclamacao.RESPOSTA.name().equals(campoLayout.getCammpoNome())) {
				if (StringUtils.isNotEmpty(recTo.getResposta())) {
					importCaso.getMapDados().put(campoLayout.getCampoImportCaso(), recTo.getResposta());
				} else {
					importCaso.getMapDados().put(campoLayout.getCampoImportCaso(), null);
				}
			}
			if (CamposReclamacao.DATA_CONSIDERACAO.name().equals(campoLayout.getCammpoNome())) {
				if (recTo.getData_consideracao() != null) {
					importCaso.getMapDados().put(campoLayout.getCampoImportCaso(), new Timestamp(recTo.getData_consideracao().getTime()).toString());
				} else {
					importCaso.getMapDados().put(campoLayout.getCampoImportCaso(), null);
				}
			}
			if (CamposReclamacao.CONSIDERACAO.name().equals(campoLayout.getCammpoNome())) {
				if (StringUtils.isNotEmpty(recTo.getConsideracao())) {
					importCaso.getMapDados().put(campoLayout.getCampoImportCaso(), recTo.getConsideracao());
				} else {
					importCaso.getMapDados().put(campoLayout.getCampoImportCaso(), null);
				}
			}
			if (CamposReclamacao.NOTA.name().equals(campoLayout.getCammpoNome())) {
				if (StringUtils.isNotEmpty(recTo.getNota())) {
					importCaso.getMapDados().put(campoLayout.getCampoImportCaso(), recTo.getNota());
				} else {
					importCaso.getMapDados().put(campoLayout.getCampoImportCaso(), null);
				}
			}
			if (CamposReclamacao.NOME_RECLAMANTE.name().equals(campoLayout.getCammpoNome())) {
				if (StringUtils.isNotEmpty(recTo.getNome_reclamante())) {
					importCaso.getMapDados().put(campoLayout.getCampoImportCaso(), recTo.getNome_reclamante());
				} else {
					importCaso.getMapDados().put(campoLayout.getCampoImportCaso(), null);
				}
			}
			if (CamposReclamacao.CPF_RECLAMANTE.name().equals(campoLayout.getCammpoNome())) {
				if (StringUtils.isNotEmpty(recTo.getCpf_reclamante())) {
					importCaso.getMapDados().put(campoLayout.getCampoImportCaso(), recTo.getCpf_reclamante());
				} else {
					importCaso.getMapDados().put(campoLayout.getCampoImportCaso(), null);
				}
			}
			if (CamposReclamacao.RG_RECLAMANTE.name().equals(campoLayout.getCammpoNome())) {
				if (StringUtils.isNotEmpty(recTo.getRg_reclamante())) {
					importCaso.getMapDados().put(campoLayout.getCampoImportCaso(), recTo.getRg_reclamante());
				} else {
					importCaso.getMapDados().put(campoLayout.getCampoImportCaso(), null);
				}
			}
			if (CamposReclamacao.EMAIL_RECLAMANTE.name().equals(campoLayout.getCammpoNome())) {
				if (StringUtils.isNotEmpty(recTo.getEmail_reclamante())) {
					importCaso.getMapDados().put(campoLayout.getCampoImportCaso(), recTo.getEmail_reclamante());
				} else {
					importCaso.getMapDados().put(campoLayout.getCampoImportCaso(), null);
				}
			}
			if (CamposReclamacao.CONTATO1_RECLAMANTE.name().equals(campoLayout.getCammpoNome())) {
				if (StringUtils.isNotEmpty(recTo.getContato1_reclamante())) {
					importCaso.getMapDados().put(campoLayout.getCampoImportCaso(), recTo.getContato1_reclamante());
				} else {
					importCaso.getMapDados().put(campoLayout.getCampoImportCaso(), null);
				}
			}
			if (CamposReclamacao.CONTATO2_RECLAMANTE.name().equals(campoLayout.getCammpoNome())) {
				if (StringUtils.isNotEmpty(recTo.getContato2_reclamante())) {
					importCaso.getMapDados().put(campoLayout.getCampoImportCaso(), recTo.getContato2_reclamante());
				} else {
					importCaso.getMapDados().put(campoLayout.getCampoImportCaso(), null);
				}
			}
			if (CamposReclamacao.CONTATO3_RECLAMANTE.name().equals(campoLayout.getCammpoNome())) {
				if (StringUtils.isNotEmpty(recTo.getContato3_reclamante())) {
					importCaso.getMapDados().put(campoLayout.getCampoImportCaso(), recTo.getContato3_reclamante());
				} else {
					importCaso.getMapDados().put(campoLayout.getCampoImportCaso(), null);
				}
			}
			if (CamposReclamacao.ESTADO_RECLAMANTE.name().equals(campoLayout.getCammpoNome())) {
				if (StringUtils.isNotEmpty(recTo.getEstado_reclamante())) {
					importCaso.getMapDados().put(campoLayout.getCampoImportCaso(), recTo.getEstado_reclamante());
				}
			}
			if (CamposReclamacao.CIDADE_RECLAMANTE.name().equals(campoLayout.getCammpoNome())) {
				if (StringUtils.isNotEmpty(recTo.getCidade_reclamante())) {
					importCaso.getMapDados().put(campoLayout.getCampoImportCaso(), recTo.getCidade_reclamante());
				} else {
					importCaso.getMapDados().put(campoLayout.getCampoImportCaso(), null);
				}
			}
			if (campoLayout.getFlagIdentificador() != null && campoLayout.getFlagIdentificador()) {
				importCaso.setIdExterno(importCaso.getMapDados().get(campoLayout.getCampoImportCaso()));
			}
		}

		return importCaso;
	}
}