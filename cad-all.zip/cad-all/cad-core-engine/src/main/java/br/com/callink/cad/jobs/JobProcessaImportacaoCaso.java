package br.com.callink.cad.jobs;

import java.text.MessageFormat;
import java.util.logging.Level;
import java.util.logging.Logger;

import br.com.callink.cad.dao.LoteCasoDAO;
import br.com.callink.cad.to.LoteCasoTO;

/**
 * @author swb_brunocamargo
 * 
 */
public class JobProcessaImportacaoCaso extends CadJob {

	private final Logger logger = Logger.getLogger(JobProcessaImportacaoCaso.class.getName());

	private LoteCasoDAO dao;

	private void setUp() throws Exception {
		if (dao == null) {
			dao = new LoteCasoDAO();
		}
	}

	@Override
	public void process(Integer idTenant, Integer idOperacao, String nome) throws Exception {
		setUp();
		importaCaso(idOperacao);
	}

	private void importaCaso(Integer idOperacao) throws Exception {
		if (idOperacao != null) {
			LoteCasoTO loteCasoTO = dao.buscaLoteCasoPendente(idOperacao);
			
			try {
				if(loteCasoTO != null && loteCasoTO.getIdLoteCaso() != null) {
					logger.info("Executando import caso. Lote caso id: "+loteCasoTO.getIdLoteCaso());
					dao.execProcedureImportacao(loteCasoTO.getIdLoteCaso());
					logger.info("Conclusão de importação import caso. Lote caso id: "+loteCasoTO.getIdLoteCaso());
				} else {
					logger.info(MessageFormat.format("Nenhuma importação a ser processada! - Operação: {0} ", idOperacao));
				}
			} catch (Exception e) {
				StringBuilder errors = new StringBuilder("[Operação: ");
				errors.append(idOperacao);
				errors.append("] ");
				if(loteCasoTO != null) {
					errors.append(String.format("[Lote Caso ID] : %s ", loteCasoTO.getIdLoteCaso()));
				}
				errors.append(e.getMessage());
				logger.log(Level.SEVERE, errors.toString(), e);
				throw new Exception(e);
			}
		}
	}

	
}
