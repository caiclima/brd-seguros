package br.com.callink.cad.jobs;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import br.com.callink.cad.dao.ParametroSistemaDAO;
import br.com.callink.cad.dao.ProcessaReaberturaCasoDAO;
import br.com.callink.cad.to.CasoTO;
import br.com.callink.cad.to.EquipeTO;
import br.com.callink.cad.to.UsuarioTO;
import br.com.callink.cad.util.Constantes;
import br.com.callink.cad.util.ConstantesParametro;
import br.com.callink.cad.util.TransactionUtils;

/**
 * @author swb_brunocamargo
 * 
 */
public class JobProcessaReaberturaCaso extends CadJob {

	private Logger logger = Logger.getLogger(JobProcessaReaberturaCaso.class.getName());
	
	private ProcessaReaberturaCasoDAO dao;
	private ParametroSistemaDAO parametroSistemaDAO;

	private void setUp() throws Exception {
		if (dao == null) {
			dao = new ProcessaReaberturaCasoDAO();
		}
		if (parametroSistemaDAO == null) {
			parametroSistemaDAO = new ParametroSistemaDAO();
		}
	}

	@Override
	protected void process(Integer idTenant, Integer idOperacao, String nome) throws Exception {
		setUp();
		preparaReaberturasLiberaCasos(idOperacao);
	}

	public void preparaReaberturasLiberaCasos(Integer idOperacao) throws Exception {

		String valorParametro = parametroSistemaDAO.findValorParametroSistemaOperacao(ConstantesParametro.FLAG_PROCESSANDO_SPA.getMnemonico(), idOperacao);
		boolean flagProcessandoSPA = valorParametro != null ? Boolean.valueOf(valorParametro) : false;

		String valorParametroReabreCaso = parametroSistemaDAO.findValorParametroSistemaOperacao(ConstantesParametro.REABRE_CASO_ATENDENTE.getMnemonico(), idOperacao);
		boolean reabreCasoUsuario = valorParametroReabreCaso != null ? Boolean.valueOf(valorParametroReabreCaso) : false;

		// Verifica se o SPA não está carregando os maillings
		if (!flagProcessandoSPA) {

			List<CasoTO> listProcessaReaberturaCasoTOs = dao.buscaCasoReclassificaReabertura(idOperacao);
			List<Integer> usersPk = dao.buscaUsuariosLogados(idOperacao);

			if (usersPk != null && !usersPk.isEmpty() && reabreCasoUsuario) {
				List<CasoTO> casosUpdate = new ArrayList<CasoTO>();
				for (Integer idUsuario : usersPk) {
				  try {
					List<CasoTO> casoRemove = new ArrayList<CasoTO>();
					for (CasoTO caso : listProcessaReaberturaCasoTOs) {

						if (caso.getIdUsuario() != null && idUsuario != null && caso.getIdUsuario().equals(idUsuario)) {

							// Validando se o usuario está ativo.
							UsuarioTO usuario = dao.findUsuarioByPk(caso.getIdUsuario());
							if (usuario != null && usuario.getIdUsuario() != null && usuario.getFlagAtivo()) {

								// Validando se o usuario ainda pertence a equipe
								EquipeTO equipe = dao.findEquipeByPk(usuario.getIdEquipe());
								if (equipe != null && equipe.getIdEquipe() != null && equipe.getFlagAtivo()) {

									caso.setFlagReclassificaReabertura(Boolean.FALSE);
									caso.setFlagClassifica(Boolean.FALSE);
									casosUpdate.add(caso);
									casoRemove.add(caso);
								}
							}
						}
					}

					listProcessaReaberturaCasoTOs.removeAll(casoRemove);

					if (listProcessaReaberturaCasoTOs.isEmpty()) {
						break;
					}
					
				} catch (Exception e) {
					StringBuilder errors = new StringBuilder("[Operação: ");
					errors.append(idOperacao);
					errors.append("] ");
					
					errors.append(e.getMessage());
					logger.log(Level.SEVERE, errors.toString(), e);
					throw new Exception(e);
				}
					
				}
				for (List<CasoTO> update : TransactionUtils.subLists(casosUpdate, Constantes.NRO_REGISTROS_COMMIT)) {
					dao.updateCaso(update);
				}
			}

			if (listProcessaReaberturaCasoTOs != null && !listProcessaReaberturaCasoTOs.isEmpty()) {
				List<CasoTO> casosUpdate = new ArrayList<CasoTO>();

				for (CasoTO caso : listProcessaReaberturaCasoTOs) {
					caso.setFlagReclassificaReabertura(Boolean.FALSE);
					caso.setIdUsuario(null);
					caso.setIdConfiguracaoFila(null);

					casosUpdate.add(caso);
				}
				for (List<CasoTO> update : TransactionUtils.subLists(casosUpdate, Constantes.NRO_REGISTROS_COMMIT)) {
					dao.updateCaso(update);
				}

			}
		}
	}
}
