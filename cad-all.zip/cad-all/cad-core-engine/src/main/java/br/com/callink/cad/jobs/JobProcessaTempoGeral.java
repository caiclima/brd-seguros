package br.com.callink.cad.jobs;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import br.com.callink.cad.dao.ParametroSistemaDAO;
import br.com.callink.cad.dao.ProcessaTempoGeralDAO;
import br.com.callink.cad.enumeration.ParametroSistemaOperacaoEnum;
import br.com.callink.cad.util.Constantes;
import br.com.callink.cad.util.DateUtils;
import br.com.callink.cad.util.TransactionUtils;

/**
 * @author swb_samuel
 * 
 */
public class JobProcessaTempoGeral extends CadJob {

	private ProcessaTempoGeralDAO dao;
	private ParametroSistemaDAO parametroSistemaDAO;
	private Logger logger = Logger.getLogger(JobProcessaTempoGeral.class.getName());

	private void setUp() {
		if (dao == null) {
			dao = new ProcessaTempoGeralDAO();
		}
		if (parametroSistemaDAO == null) {
			parametroSistemaDAO = new ParametroSistemaDAO();
		}
	}

	@Override
	protected void process(Integer idTenant, Integer idOperacao, String nome) throws Exception {
		setUp();
		geraTempoGeralDia(idOperacao);
		geraTempoGeralPorOperadorPorDia(idOperacao);
	}

	private void geraTempoGeralPorOperadorPorDia(Integer idOperacao) throws Exception {
		try {
			Date dataAtual = DateUtils.addFirstTimeInDate(dao.getDataBanco());
			Calendar calCalculo = Calendar.getInstance();
			calCalculo.setTime(dataAtual);
			List<Date> listRelatorio = new ArrayList<Date>();
			
			Date dataUltimaExecucao = buscaDataUltimaExecucao(idOperacao, ParametroSistemaOperacaoEnum.ULTIMA_EXECUCAO_TEMPO_GERAL_OPERADOR.getParametroSistemaOperacao());
			
			if (dataUltimaExecucao != null) {
				Long dados = Long.valueOf(diferencaEmDias(dataAtual, dataUltimaExecucao));
				int quantDias = dados.intValue();
				for (int i = quantDias; i > 0; i--) {
					calCalculo.add(Calendar.DAY_OF_MONTH, -i);
	
					listRelatorio.add(calCalculo.getTime());
					calCalculo.setTime(dataAtual);
				}
			}
			
			listRelatorio.add(dataAtual);
			
			for (List<Date> list : TransactionUtils.subLists(listRelatorio, Constantes.NRO_REGISTROS_COMMIT)) {
				dao.geraRelatorioTempoGeralOperador(list, idOperacao);
			}
			
			atualizaDataUltimaExecucao(idOperacao, parametroSistemaDAO.getDataBanco(),
					ParametroSistemaOperacaoEnum.ULTIMA_EXECUCAO_TEMPO_GERAL_OPERADOR.getParametroSistemaOperacao());
		} catch (Exception e) {
			StringBuilder errors = new StringBuilder("[Operação: ");
			errors.append(idOperacao);
			errors.append("] ");
			errors.append("Erro gerar TempoGeral Por Operador Por Dia ");
			errors.append(e.getMessage());
			logger.log(Level.SEVERE, errors.toString(), e);
			throw e;
		}
	}

	private void geraTempoGeralDia(Integer idOperacao) throws Exception {
		try {
			Date dataAtual = DateUtils.addFirstTimeInDate(dao.getDataBanco());
			Calendar calCalculo = Calendar.getInstance();
			calCalculo.setTime(dataAtual);
			List<Date> listRelatorio = new ArrayList<Date>();
			
			Date dataUltimaExecucao = buscaDataUltimaExecucao(idOperacao, ParametroSistemaOperacaoEnum.ULTIMA_EXECUCAO_TEMPO_GERAL.getParametroSistemaOperacao());
			
			if (dataUltimaExecucao != null) {
				Long dados = Long.valueOf(diferencaEmDias(dataAtual, dataUltimaExecucao));
				int quantDias = dados.intValue();
				for (int i = quantDias; i > 0; i--) {
					calCalculo.add(Calendar.DAY_OF_MONTH, -i);
					
					listRelatorio.add(calCalculo.getTime());
					calCalculo.setTime(dataAtual);
				}
			}
			
			listRelatorio.add(dataAtual);
	
			for (List<Date> list : TransactionUtils.subLists(listRelatorio, Constantes.NRO_REGISTROS_COMMIT)) {
				dao.geraRelatorioTempoGeral(list, idOperacao);
			}
			
			atualizaDataUltimaExecucao(idOperacao, parametroSistemaDAO.getDataBanco(),
					ParametroSistemaOperacaoEnum.ULTIMA_EXECUCAO_TEMPO_GERAL.getParametroSistemaOperacao());
		} catch (Exception e) {
			StringBuilder errors = new StringBuilder("[Operação: ");
			errors.append(idOperacao);
			errors.append("] ");
			errors.append("Erro gerar TempoGeral Dia ");
			errors.append(e.getMessage());
			logger.log(Level.SEVERE, errors.toString(), e);
			throw e;
		}
	}

	private long diferencaEmDias(Date dataFim, Date dataInicio) {
		long diferenca = dataFim.getTime() - dataInicio.getTime();

		// Quantidade de milissegundos em um dia
		int tempoDia = 1000 * 60 * 60 * 24;
		return diferenca / tempoDia;
	}
	
	private Date buscaDataUltimaExecucao(Integer idOperacao, String parametroUltimaExec) throws Exception {
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date dataUltimaExecucao = null;
		
		try {
			String valorParametro = parametroSistemaDAO.findValorParametroSistemaOperacao(parametroUltimaExec, idOperacao);
			
			if (valorParametro != null && !valorParametro.isEmpty()) {
				dataUltimaExecucao = df.parse(valorParametro);
			}
		} catch (Exception e) {
			StringBuilder errors = new StringBuilder("[");
			errors.append("Erro ao obter parâmetro de data última execução. Parâmetro: "
					+ parametroUltimaExec + ", operação: " + idOperacao);
			errors.append("] ");
			errors.append(e.getMessage());
			logger.log(Level.SEVERE, errors.toString(), e);
		}
		return dataUltimaExecucao;
	}
	
	private void atualizaDataUltimaExecucao(Integer idOperacao, Date data, String parametroUltimaExec) throws Exception {
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			parametroSistemaDAO.atualizaValorParametroSistemaOperacao(parametroUltimaExec, idOperacao, df.format(data));
		} catch (Exception e) {
			StringBuilder errors = new StringBuilder("[ ");
			errors.append("Erro ao atualizar parâmetro de data última execução. Parâmetro: "
					+ parametroUltimaExec
					+ ", operação: " + idOperacao);
			errors.append("] ");
			errors.append(e.getMessage());
			logger.log(Level.SEVERE, errors.toString(), e);
		}
	}
	
}
