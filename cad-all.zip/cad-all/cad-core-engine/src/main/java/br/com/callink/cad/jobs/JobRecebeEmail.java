package br.com.callink.cad.jobs;

import java.sql.Timestamp;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.mail.Flags;
import javax.mail.Message;
import javax.mail.MessagingException;

import org.quartz.JobExecutionException;

import br.com.callink.cad.crypto.impl.RSACryptoImpl;
import br.com.callink.cad.dao.ConfiguracaoCaixaEmailDAO;
import br.com.callink.cad.dao.EstrategiaCartaoDAO;
import br.com.callink.cad.dao.ParametroSistemaDAO;
import br.com.callink.cad.dao.RecebeEmailDAO;
import br.com.callink.cad.enumeration.ParametroSistemaOperacaoEnum;
import br.com.callink.cad.to.AnexoTO;
import br.com.callink.cad.to.CamposLayoutTO;
import br.com.callink.cad.to.CasoTO;
import br.com.callink.cad.to.ConfiguracaoAcaoAutomaticaTO;
import br.com.callink.cad.to.ConfiguracaoCaixaEmailTO;
import br.com.callink.cad.to.EmailTO;
import br.com.callink.cad.to.EstrategiaCartaoTO;
import br.com.callink.cad.to.GrupoAnexoTO;
import br.com.callink.cad.to.ImportCasoTO;
import br.com.callink.cad.to.LayoutImportacaoTO;
import br.com.callink.cad.to.LogTO;
import br.com.callink.cad.to.LoteCasoTO;
import br.com.callink.cad.util.AcaoAutomaticaExecutor;
import br.com.callink.cad.util.ArquivoUtils;
import br.com.callink.cad.util.CollectionUtils;
import br.com.callink.cad.util.Constantes;
import br.com.callink.cad.util.EstrategiaCartaoHelper;
import br.com.callink.cad.util.ReceiveMail;
import br.com.callink.cad.util.StringUtils;
import br.com.callink.cad.util.TransactionUtils;

/**
 * @author swb_brunocamargo
 * 
 */
public class JobRecebeEmail extends CadJob {

	private Logger logger = Logger.getLogger(JobRecebeEmail.class.getName());

	private enum CampoEmail {
		DE, ASSUNTO, DATA_RECEBIDA, DATA_ENVIADA, CORPO,
	}

	private final String TIPO_EXECUCAO = "AGENDADO";
	private final String TIPO_PROCESSO = "EMAIL";
	private final String STATUS_EXECUCAO_IMPORTANDO = "IMPORTANDO";
	private final String STATUS_EXECUCAO_PENDENTE = "PENDENTE";

	private RecebeEmailDAO dao;
	private ParametroSistemaDAO parametroSistemaDAO;
	private ConfiguracaoCaixaEmailDAO configuracaoCaixaEmailDAO;
	private ReceiveMail receiveMail;
	private EstrategiaCartaoHelper estrategiaCartaoHelper;
	private EstrategiaCartaoDAO estrategiaCartaoDAO;

	private void setUp() throws Exception {
		if (dao == null) {
			dao = new RecebeEmailDAO();
		}
		if (parametroSistemaDAO == null) {
			parametroSistemaDAO = new ParametroSistemaDAO();
		}
		if (configuracaoCaixaEmailDAO == null) {
			configuracaoCaixaEmailDAO = new ConfiguracaoCaixaEmailDAO();
		}
		if (estrategiaCartaoHelper == null) {
			estrategiaCartaoHelper = new EstrategiaCartaoHelper();
		}
		if (estrategiaCartaoDAO == null) {
			estrategiaCartaoDAO = new EstrategiaCartaoDAO();
		}
	}

	@Override
	protected void process(Integer idTenant, Integer idOperacao, String nome) throws Exception {
		String nomeCaixaEmail = "";
		try {
			setUp();

			ConfiguracaoCaixaEmailTO configuracaoCaixaEmailTO = configuracaoCaixaEmailDAO.findAtivosDataProcessandoPorOperacao(idOperacao);
			nomeCaixaEmail = "Caixa de Email " + (configuracaoCaixaEmailTO != null ? configuracaoCaixaEmailTO.getEmail() : " - ")
					+ "ID configuração caixa de Email: "
					+ (configuracaoCaixaEmailTO != null ? configuracaoCaixaEmailTO.getIdConfiguracaoCaixaEmail().toString() : "-");

			if (configuracaoCaixaEmailTO == null) {

				logger.log(Level.SEVERE, "Não existe caixa de email para a operação: " + idOperacao);
			} else {

				String parametroEmailAccount = configuracaoCaixaEmailTO.getEmail();
				String parametroEmailUsuario = configuracaoCaixaEmailTO.getUsuarioConfiguracaoCaixaEmail();
				String parametroEmailSenha = new RSACryptoImpl().decrypt(configuracaoCaixaEmailTO.getSenhaConfiguracaoCaixaEmail());
				String parametroEmailPopHost = configuracaoCaixaEmailTO.getPophostConfiguracaoCaixaEmail();
				String parametroEmailFolder = configuracaoCaixaEmailTO.getFolderConfiguracaoCaixaEmail();
				String parametroEmailProtocoloStore = configuracaoCaixaEmailTO.getProtocolStoreConfiguracaoCaixaEmail();
				String parametroImapPort = configuracaoCaixaEmailTO.getImapPortConfiguracaoCaixaEmail();

				receiveMail = new ReceiveMail(parametroEmailAccount, parametroEmailUsuario, parametroEmailSenha, parametroEmailPopHost,
						parametroEmailProtocoloStore, parametroEmailFolder, parametroImapPort);

				configuracaoCaixaEmailDAO.updateGetDateDataProcessando(configuracaoCaixaEmailTO.getIdConfiguracaoCaixaEmail());

				List<EmailTO> emails = receiveMail.listaEmail(idOperacao);

				salvaReceivedMails(emails, idOperacao, configuracaoCaixaEmailTO.getIdConfiguracaoCaixaEmail(), idTenant);
				importCaso(emails, idOperacao, configuracaoCaixaEmailTO.getIdConfiguracaoCaixaEmail());
			}

		} finally {
			if (receiveMail != null) {
				try {
					receiveMail.close();
				} catch (MessagingException e) {
					throw new JobExecutionException(e);
				}
			}
			logger.log(Level.WARNING, nomeCaixaEmail);
		}
	}

	public void salvaReceivedMails(List<EmailTO> emails, int idOperacao, Integer idConfiguracaoCaixaEmail, Integer idTenant) throws Exception {

		String diretorio = parametroSistemaDAO.findValorParametroSistemaOperacao(
				ParametroSistemaOperacaoEnum.PARAM_DIRETORIO_ANEXO.getParametroSistemaOperacao(), idOperacao);

		if (diretorio == null || diretorio.isEmpty()) {
			throw new Exception("Diret\u00F3rio para salvar anexo n\u00E3o est\u00E1 cadastrado.");
		}

		if (CollectionUtils.hasValue(emails)) {
			final List<EstrategiaCartaoTO> estrategias = estrategiaCartaoDAO.buscarEstrategiasPorOperacao(idOperacao);
			
			for (EmailTO mail : emails) {
				if (mail.getAssunto() != null) {
					try {
						GrupoAnexoTO grupoAnexo = new GrupoAnexoTO();

						if (idConfiguracaoCaixaEmail != null) {
							// Verifica se tem emails a ignorar na configuracao de caixa de email
							// Caso existam e o email seja desse remetente, o email nao sera internalizado
							ConfiguracaoCaixaEmailTO caixa = configuracaoCaixaEmailDAO.findById(idConfiguracaoCaixaEmail);
							
							String[] emailsIgnorar = caixa.getEmailDesconsiderar() != null && !caixa.getEmailDesconsiderar().isEmpty()
									? caixa.getEmailDesconsiderar().toLowerCase().split(",") : null;
							
							if (emailsIgnorar != null && emailsIgnorar.length > 0) {
								boolean flagEmailIgnorar = false;
								for (String em : emailsIgnorar) {
									if (!em.trim().isEmpty() && mail.getRemetente().toLowerCase().contains(em.trim())) {
										flagEmailIgnorar = true;
										break;
									}
								}
								if (flagEmailIgnorar) {
									continue;
								}
							}
							
							// Verifica se tem filtro definido de assunto para ignorar configurado na caixa de email
							// Caso exista e o assunto comecar com o filtro, o email nao sera internalizado
							String assuntoIgnorar = caixa.getAssuntoDesconsiderar() != null && !caixa.getAssuntoDesconsiderar().isEmpty()
									? caixa.getAssuntoDesconsiderar().toLowerCase() : null;
							
							if (assuntoIgnorar != null && !assuntoIgnorar.isEmpty()) {
								if (assuntoIgnorar.length() <= mail.getAssunto().length()
										&& mail.getAssunto().toLowerCase().startsWith(assuntoIgnorar)) {
									continue;
								}
							}
							
							mail.setIdConfiguracaoCaixaEmail(idConfiguracaoCaixaEmail);
						}

						if (mail.getListaAnexos() != null && mail.getListaAnexos().size() > 0) {

							grupoAnexo.setAnexoList(mail.getListaAnexos());

							for (AnexoTO anexo : grupoAnexo.getAnexoList()) {
								anexo.setDiretorio(diretorio);
							}
							grupoAnexo = save(grupoAnexo, idOperacao);

							mail.setGrupoAnexo(grupoAnexo);
						}

						if (mail.getMensagemHtml() != null && !mail.getMensagemHtml().toString().isEmpty() && mail.getConteudo() == null) {
							if (CollectionUtils.hasValue(estrategias)) {
								mail.setConteudo(estrategiaCartaoHelper.mascararCartoes(mail.getMensagemHtml().toString(), estrategias));
							} else {
								mail.setConteudo(mail.getMensagemHtml().toString());
							}
						} else if (mail.getMensagemTxt() != null && !mail.getMensagemTxt().toString().isEmpty() && mail.getConteudo() == null) {
							if (CollectionUtils.hasValue(estrategias)) {
								mail.setConteudo(estrategiaCartaoHelper.mascararCartoes(mail.getMensagemTxt().toString(), estrategias));
							} else {
								mail.setConteudo(mail.getMensagemTxt().toString());
							}
						}
						
						int inicio = mail.getAssunto().indexOf(Constantes.SEPARADOR_INICIAL) + 1;
						int fim = mail.getAssunto().indexOf(Constantes.SEPARADOR_FINAL);

						String manifestacao = null;
						List<CasoTO> casos = null;
						if (fim > 0 && fim > inicio) {
							manifestacao = mail.getAssunto().substring(inicio, fim);
							casos = dao.buscaPorIdExterno(manifestacao);
						}
						
						if (CollectionUtils.hasValue(estrategias)) {
							mail.setAssunto(estrategiaCartaoHelper.mascararCartoes(mail.getAssunto(), estrategias));
						}

						if (casos != null && casos.size() > 0) {

							mail.setFlagPossuiCaso(Boolean.TRUE);

							dao.saveEmail(mail);
							
							CasoTO casoMail = dao.loadCasoTO(casos.get(0).getIdCaso());
							
							LogTO log = new LogTO();
							log.setIdGrupoAnexo(grupoAnexo.getIdGrupoAnexo());
							log.setIdCaso(casoMail.getIdCaso());
							log.setDescricao("EMAIL RECEBIDO");
							log.setIdEmail(mail.getIdEmail());
							log.setIdStatus(casoMail.getIdStatus());
							log.setIdConfiguracaoFila(casoMail.getIdConfiguracaoFila());
							log.setDataLog(dao.getDataBanco());
							log.setDataAbertura(casoMail.getDataAbertura());
							log.setIdSlaFila(casoMail.getSlaFilaTO()!= null ? casoMail.getSlaFilaTO().getIdSlaFila() : null);
							log.setIdEvento(casoMail.getIdEvento());
							dao.saveLog(log);
							
							// Busca configurações ações automáticas caso existam, e executa
							AcaoAutomaticaExecutor acaoExecutor = new AcaoAutomaticaExecutor();
							List<ConfiguracaoAcaoAutomaticaTO> configuracoes = acaoExecutor.buscaConfiguracoesAutoEmailRecebido(casoMail);
							if (configuracoes != null && !configuracoes.isEmpty()) {
								acaoExecutor.executaConfiguracaoAcaoAutomatica(casoMail, configuracoes, mail, idTenant);
							}
						} else {
							mail.setFlagPossuiCaso(Boolean.FALSE);

							dao.saveEmail(mail);
						}
					} catch (Exception e) {
						StringBuilder errors = new StringBuilder("[Operação: ");
						errors.append(idOperacao);
						errors.append("] ");
						errors.append(e.getMessage());
						logger.log(Level.SEVERE, errors.toString(), e);
					} finally {
						// Percorre os emails do servidor para verificar
						// se o processo ocorreu corretamente e se o email está marcado para exclusao
						Message[] message = receiveMail.getMessage();
						for (Message msg : message) {
							if (msg.getMessageNumber() == mail.getNumeroExternoEmail()) {
								if (mail.getIdEmail() != null) {
									try {
										msg.setFlag(Flags.Flag.DELETED, true);
									} catch (Exception e) {
										StringBuilder errors = new StringBuilder("Erro EMAIL [Operação: ");
										errors.append(idOperacao);
										errors.append("] ");
										errors.append(e.getMessage());
										logger.log(Level.SEVERE, errors.toString(), e);
									}
								}
								break;
							}
						}
					}
				}
			}
		}

	}

	public void importCaso(List<EmailTO> emails, Integer idOperacao, Integer idCaixaEmail) throws Exception {
		if (CollectionUtils.hasValue(emails)) {
			final LayoutImportacaoTO layout = dao.buscaLayoutImportacaoEmailPorCaixaEmail(idCaixaEmail);

			if (layout != null && layout.getIdLayout() != null) {
				if (!StringUtils.isEmpty(layout.getEmailUnico())) {
					emails = filterEmailUnicList(emails, layout.getEmailUnico());
				}
				if (!StringUtils.isEmpty(layout.getEmailIgnorados())) {
					emails = filterEmailIgnoreList(emails, layout.getEmailIgnorados());
				}
				if (!CollectionUtils.hasValue(emails)) {
					return;
				}
				if (layout == null || layout.getIdLayout() == null) {
					return;
				}
				final List<CamposLayoutTO> campos = dao.buscaCamposByLayout(layout.getIdLayout());

				if (CollectionUtils.isEmpty(campos)) {
					logger.log(Level.SEVERE, MessageFormat.format("O layout {0} NÂO possui campos", layout.getIdLayout().toString()));
					return;
				}

				LoteCasoTO loteCaso = new LoteCasoTO();
				loteCaso.setHorarioAgendamento(dao.getDataBanco());
				loteCaso.setTipoExecucao(TIPO_EXECUCAO);
				loteCaso.setStatusExecucao(STATUS_EXECUCAO_IMPORTANDO);
				loteCaso.setTipoProcesso(TIPO_PROCESSO);
				loteCaso.setFlagAtivo(Boolean.TRUE);
				loteCaso.setIdOperacao(idOperacao);
				loteCaso.setIdLayout(layout.getIdLayout());
				loteCaso = dao.savarLoteCaso(loteCaso);

				List<ImportCasoTO> listImportCasos = new ArrayList<ImportCasoTO>();
				for (EmailTO emailTO : emails) {
					if (!emailTO.getFlagPossuiCaso()) {
						ImportCasoTO importCaso = setParametrosImportCaso(campos, emailTO, layout.getIdLayout());
						importCaso.setIdLayout(loteCaso.getIdLayout());
						importCaso.setIdLoteCaso(loteCaso.getIdLoteCaso());
						importCaso.setFlagImportRejeitado(Boolean.FALSE);
						importCaso.setIdEmail(emailTO.getIdEmail());
						listImportCasos.add(importCaso);
					}
				}
				if (CollectionUtils.hasValue(listImportCasos)) {
					for (List<ImportCasoTO> list : TransactionUtils.subLists(listImportCasos, Constantes.NRO_REGISTROS_COMMIT)) {
						dao.inserImportCasoNative(list);
					}
				}
				dao.atualizaStatusExecucaoLoteCaso(loteCaso.getIdLoteCaso(), STATUS_EXECUCAO_PENDENTE);
			}
		}
	}

	private List<EmailTO> filterEmailUnicList(List<EmailTO> emails, String emailUnico) {
		List<EmailTO> filterList = new ArrayList<EmailTO>();
		List<String> emailsUnico = getListEmail(emailUnico);
		if (emails != null && !emails.isEmpty()) {
			for (EmailTO emailTO : emails) {
				if (CollectionUtils.hasValue(emailsUnico)) {
					for (String item : emailsUnico) {
						if (emailTO.getRemetente() != null && emailTO.getRemetente().toUpperCase().contains(item.toUpperCase())) {
							filterList.add(emailTO);
						}
					}
				}
			}
		}

		return filterList;

	}

	private List<EmailTO> filterEmailIgnoreList(List<EmailTO> emails, String emailIgnorar) {
		List<EmailTO> filterList = new ArrayList<EmailTO>();
		List<String> emailsIgnore = getListEmail(emailIgnorar);
		Boolean containsItem = Boolean.FALSE;
		if (emails != null && !emails.isEmpty()) {
			for (EmailTO emailTO : emails) {
				if (CollectionUtils.hasValue(emailsIgnore)) {
					containsItem = Boolean.FALSE;
					for (String item : emailsIgnore) {
						if (emailTO.getRemetente() != null && emailTO.getRemetente().toUpperCase().contains(item.toUpperCase())) {
							containsItem = Boolean.TRUE;
						}
					}
					if (!containsItem) {
						filterList.add(emailTO);
					}
				}
			}
		}

		return filterList;

	}

	public List<String> getListEmail(String email) {
		List<String> emails = new ArrayList<String>();

		Boolean contemVirgula = email.contains(",");
		Boolean contemPontoVirgula = email.contains(";");
		if (!StringUtils.isEmpty(email)) {

			if (contemVirgula) {
				for (String dest : email.split(",")) {
					if (dest.contains(";")) {
						for (String destVir : dest.split(";")) {
							emails.add(destVir);
						}
					} else {
						emails.add(dest);
					}
				}
			} else {
				if (contemPontoVirgula) {
					for (String dest : email.split(";")) {
						emails.add(dest);
					}
				} else {
					emails.add(email);
				}
			}
		}

		return emails;
	}

	private ImportCasoTO setParametrosImportCaso(List<CamposLayoutTO> listCamposLayout, EmailTO emailTO, Integer idLayout) throws Exception {
		ImportCasoTO importCaso = new ImportCasoTO();
		String val = null;

		for (CamposLayoutTO campoLayout : listCamposLayout) {
			if (CampoEmail.DE.name().equals(campoLayout.getCammpoNome())) {
				val = preparaValor(emailTO.getIdEmail(), idLayout, campoLayout, emailTO.getRemetente());

				if (val != null) {
					importCaso.getMapDados().put(campoLayout.getCampoImportCaso(), val);
				}
			}
			if (CampoEmail.ASSUNTO.name().equals(campoLayout.getCammpoNome())) {
				val = preparaValor(emailTO.getIdEmail(), idLayout, campoLayout, emailTO.getAssunto());
				
				if (val != null) {
					importCaso.getMapDados().put(campoLayout.getCampoImportCaso(), val);
				}
			}
			if (CampoEmail.CORPO.name().equals(campoLayout.getCammpoNome())) {
				val = preparaValor(emailTO.getIdEmail(), idLayout, campoLayout, emailTO.getConteudo());

				if (val != null) {
					importCaso.getMapDados().put(campoLayout.getCampoImportCaso(), val);
				}
			}
			if (CampoEmail.DATA_ENVIADA.name().equals(campoLayout.getCammpoNome())) {
				val = preparaValor(emailTO.getIdEmail(), idLayout, campoLayout, emailTO.getDataEnvio());

				if (val != null) {
					importCaso.getMapDados().put(campoLayout.getCampoImportCaso(), val);
				}
			}
			if (CampoEmail.DATA_RECEBIDA.name().equals(campoLayout.getCammpoNome())) {
				val = preparaValor(emailTO.getIdEmail(), idLayout, campoLayout, emailTO.getDataRecebimento());

				if (val != null) {
					importCaso.getMapDados().put(campoLayout.getCampoImportCaso(), val);
				}
			}
			if(campoLayout.getFlagIdentificador()){
				importCaso.setIdExterno(val);
			}
		}

		return importCaso;
	}

	private String preparaValor(Integer idEmail, Integer idLayout, CamposLayoutTO campoLayout, Object val) throws Exception {
		/*
		 * Valida se o campo é obrigatório e se o valor foi preenchido
		 */
		validarCampoObrigatorio(idEmail, idLayout, campoLayout, val);
		String ret = null;

		/*
		 * Prepara o valor para ser inserido no banco de dados.
		 */
		if (CampoEmail.DATA_ENVIADA.name().equals(campoLayout.getCammpoNome()) || CampoEmail.DATA_RECEBIDA.name().equals(campoLayout.getCammpoNome())) {
			if (val != null && !val.toString().isEmpty()) {
				ret = new Timestamp(((Date) val).getTime()).toString();
			}

		} else {

			if (!StringUtils.isEmpty((String) val)) {
				if (campoLayout.getSize() != null && StringUtils.isNotValidLength((String) val, campoLayout.getSize())) {
					ret = StringUtils.truncate((String) val, campoLayout.getSize());

					String msg = MessageFormat.format("O campo {0} foi truncado para o tamanho definido no campo {1} da import caso.",
							campoLayout.getCammpoNome(), campoLayout.getCampoImportCaso());

					logger.info(msg);

				} else {
					ret = (String) val;
				}
			}
		}
		return corrigeAspas(ret);
	}
	
	private String corrigeAspas(String valorCampo) {
		if (valorCampo == null) {
			return valorCampo;
		}
		return valorCampo.replace("\'", "\"");
	}

	private void validarCampoObrigatorio(Integer idEmail, Integer idLayout, CamposLayoutTO campoLayout, Object val) throws Exception {
		if (campoLayout.isNotNull() && (val == null || val.toString().length() == 0)) {
			String msg = MessageFormat.format("O campo ''{0}'' é obrigatório para o layout ''{1}'', porém NÂO foi encontrado no email {2}.",
					campoLayout.getCammpoNome(), idLayout.toString(), idEmail.toString());

			logger.log(Level.SEVERE, msg);
			throw new Exception(msg);
		}
	}

	public GrupoAnexoTO save(GrupoAnexoTO grupoAnexo, Integer idOperacao) throws Exception {
		if (grupoAnexo != null && grupoAnexo.getAnexoList() != null && !grupoAnexo.getAnexoList().isEmpty()) {
			grupoAnexo.setNome("log");
			grupoAnexo.setDescricao("log descricao");
			if (grupoAnexo.getPK() == null) {
				dao.saveGrupoAnexo(grupoAnexo);
			} else {
				dao.updateGrupoAnexo(grupoAnexo);
			}
			Date dataAtual = dao.getDataBanco();
			if (grupoAnexo.getAnexoList() != null) {
				for (AnexoTO anexo : grupoAnexo.getAnexoList()) {
					if (anexo.getPK() == null) {
						anexo.setGrupoAnexo(grupoAnexo);
						anexo.setNomeFake(grupoAnexo.getPK() + anexo.getNomeReal());
						anexo.setDataCriacao(dataAtual);

						dao.saveAnexo(anexo);

						try {
							ArquivoUtils.gravarArquivo(anexo.getNomeFake(), anexo.getDiretorio(), anexo.getDados());
						} catch (Exception e) {
							StringBuilder errors = new StringBuilder("[Operação: ");
							errors.append(idOperacao);
							errors.append("] ");
							errors.append("Erro ao salvar anexo em diretório: " + anexo.getDiretorio() + " - ");
							errors.append(e.getMessage());
							logger.log(Level.SEVERE, errors.toString(), e);
						}
					}
				}
			}
		}
		return grupoAnexo;
	}
}
