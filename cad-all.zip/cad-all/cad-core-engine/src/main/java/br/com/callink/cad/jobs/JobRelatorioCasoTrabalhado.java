package br.com.callink.cad.jobs;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import br.com.callink.cad.dao.ParametroSistemaDAO;
import br.com.callink.cad.dao.RelatorioCasoTrabalhadoDAO;
import br.com.callink.cad.enumeration.ParametroSistemaOperacaoEnum;
import br.com.callink.cad.to.CasoTO;
import br.com.callink.cad.to.RelatorioCasoTrabalhado;
import br.com.callink.cad.to.SlaFilaTO;
import br.com.callink.cad.util.CalculoSlaHelper;
import br.com.callink.cad.util.CollectionUtils;
import br.com.callink.cad.util.Constantes;

public class JobRelatorioCasoTrabalhado extends CadJob {

	private Logger logger = Logger.getLogger(JobRelatorioCasoTrabalhado.class.getName());
	private RelatorioCasoTrabalhadoDAO dao;
	private ParametroSistemaDAO parametroSistemaDAO;
	private CalculoSlaHelper calculoSlaUtil;
	private String schemaDbReport;
	private static final String QTD_REGISTROS_DELETE_POR_VEZ = "qtdRegistrosDeletePorVez";

	private void setUp(Integer idTenant, Integer idOperacao) throws Exception {
		if(dao == null){
			dao = new RelatorioCasoTrabalhadoDAO();
		}
		if (parametroSistemaDAO == null) {
			parametroSistemaDAO = new ParametroSistemaDAO();
		}
		if (calculoSlaUtil == null) {
			calculoSlaUtil = new CalculoSlaHelper(getFeriadosOperacao(idOperacao),
					getJornadaOperacao(idOperacao),
					getSlaFilaOperacao(idOperacao));
		}
		
		schemaDbReport = getSchemaDbReport(idTenant);
	}

	@Override
	protected void process(Integer idTenant, Integer idOperacao, String nome) throws Exception {
		setUp(idTenant, idOperacao);
		Date dataAtual = dao.getDataBanco();

		/*
		 * Busca o parâmetro de quantidade de registros a serem deletados por vez
		 */
		String valorParamQtdRegistrosExpurgoPorVez = parametroSistemaDAO.findValorParametroSistema(QTD_REGISTROS_DELETE_POR_VEZ);
		Integer qtdRegistrosExpurgoPorVez = valorParamQtdRegistrosExpurgoPorVez != null && !valorParamQtdRegistrosExpurgoPorVez.isEmpty()
				? Integer.valueOf(valorParamQtdRegistrosExpurgoPorVez) : Constantes.QTD_PADRAO_REGISTROS_DELETE;
		
		dao.deletaReletorioPorDia(schemaDbReport, idOperacao, qtdRegistrosExpurgoPorVez);

		final List<RelatorioCasoTrabalhado> source = dao.buscaCasos(idOperacao);

		if (CollectionUtils.hasValue(source)) {
			// fazer calculo do sla para cada caso
			for (RelatorioCasoTrabalhado relatorio : source) {
				CasoTO caso = new CasoTO();
				try {
				
				caso.setIdCaso(relatorio.getIdCaso());
				caso.setIdOperacao(relatorio.getIdOperacao());
				caso.setDataAbertura(relatorio.getDataAbertura());
				caso.setDataCadastro(relatorio.getDataCadastro());
				caso.setSlaFilaTO(new SlaFilaTO(relatorio.getIdSlaFila() != null && relatorio.getIdSlaFila() > 0 ? relatorio.getIdSlaFila() : null));
				
				Date dataCalculo = caso.getDataEncerramento() != null ? caso.getDataEncerramento() : dataAtual;
				
				calculoSlaUtil.loadSla(caso, dataCalculo);
				
				relatorio.setPorcentagemSla((BigDecimal) (caso.getPorcentagemSla() == null ? caso.getPorcentagemSla() : BigDecimal.valueOf(caso.getPorcentagemSla())));
				relatorio.setSlaEmMinutosCaso(caso.getSlaEmMinutos());
				relatorio.setSlaTotalMinutos(caso.getSlaTotalMinutos());
				
				relatorio.setDataGeracao(dataAtual);
				
				}catch (Exception e) {
					StringBuilder errors = new StringBuilder("[Operação: ");
					errors.append(idOperacao);
					errors.append("] ");
					errors.append(String.format("Id do caso %d ",caso.getIdCaso()));
					errors.append(e.getMessage());
					logger.log(Level.SEVERE, errors.toString(), e);
					throw e;
				}
			}
			
			/**
			 * Faz expurgo dos dados de acordo com a quantidade de dias configurados
			 * Caso não exista quantidade de dias, ou seja zero, não faz
			 */
			Integer qtdDiasExpurgo = null;
			String valorParametroExpurgo = parametroSistemaDAO.findValorParametroSistemaOperacao(
					ParametroSistemaOperacaoEnum.QTD_DIAS_EXPURGO_DADOS.getParametroSistemaOperacao(), idOperacao);
			if (valorParametroExpurgo != null && !valorParametroExpurgo.isEmpty()) {
				qtdDiasExpurgo = Integer.valueOf(valorParametroExpurgo);
				
				if (qtdDiasExpurgo > 0) {
					executaExpurgoDados(idOperacao, qtdDiasExpurgo, dataAtual);
				}
			}
			
			dao.salvaRelatorio(schemaDbReport, source);
		}
	}
	
	private void executaExpurgoDados(Integer idOperacao, Integer qtdDiasExpurgo, Date dataAtual) throws Exception {
		try {
			dao.executaExpurgoDados(schemaDbReport, idOperacao, qtdDiasExpurgo, dataAtual);
			
		} catch (Exception e) {
			StringBuilder errors = new StringBuilder("[Operação: ");
			errors.append(idOperacao);
			errors.append("] ");
			errors.append(e.getMessage());
			logger.log(Level.SEVERE, errors.toString(), e);
		}
	}

}
