package br.com.callink.cad.jobs;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import br.com.callink.cad.crypto.CryptographyException;
import br.com.callink.cad.crypto.impl.AESCryptoImpl;
import br.com.callink.cad.dao.ParametroSistemaDAO;
import br.com.callink.cad.dao.RelatorioHistoricoCasoDAO;
import br.com.callink.cad.enumeration.ParametroSistemaOperacaoEnum;
import br.com.callink.cad.sla.util.MascaraUtilHelper;
import br.com.callink.cad.sla.util.TempoUtilHelper;
import br.com.callink.cad.to.CampoDinamicoTO;
import br.com.callink.cad.to.CasoTO;
import br.com.callink.cad.to.RelatorioHistoricoCasoTO;
import br.com.callink.cad.to.SlaFilaTO;
import br.com.callink.cad.to.TipoCampoDinamico;
import br.com.callink.cad.util.CalculoSlaHelper;
import br.com.callink.cad.util.CollectionUtils;
import br.com.callink.cad.util.Constantes;
import br.com.callink.cad.util.DateUtils;

public class JobRelatorioHistoricoCaso extends CadJob {

	private Logger logger = Logger.getLogger(JobRelatorioHistoricoCaso.class.getName());
	private RelatorioHistoricoCasoDAO dao;
	private ParametroSistemaDAO parametroSistemaDAO;
	private CalculoSlaHelper calculoSlaUtil;
	private MascaraUtilHelper maskUtil;
	private static final String QTD_REGISTROS_DELETE_POR_VEZ = "qtdRegistrosDeletePorVez";
	private String schemaDbReport;
	
	private void setUp(Integer idTenant, Integer idOperacao) throws Exception {
		if (dao == null) {
			dao = new RelatorioHistoricoCasoDAO();
		}
		if (parametroSistemaDAO == null) {
			parametroSistemaDAO = new ParametroSistemaDAO();
		}
		if (calculoSlaUtil == null) {
			calculoSlaUtil = new CalculoSlaHelper(getFeriadosOperacao(idOperacao),
					getJornadaOperacao(idOperacao),
					getSlaFilaOperacao(idOperacao));
		}
		if (maskUtil == null) {
			maskUtil = MascaraUtilHelper.getInstance();
		}
		
		schemaDbReport = getSchemaDbReport(idTenant);
	}
	
	@Override
	protected void process(Integer idTenant, Integer idOperacao, String nome) throws Exception {
		setUp(idTenant, idOperacao);
		
		//Pegando o schema
		Date dataCasoDeletado = buscaDataUltimaExecucao(idOperacao);
		
		geraNuvem(idOperacao, schemaDbReport);
		geraNuvemCasosDeletados(idOperacao, schemaDbReport, dataCasoDeletado);
		dao.insereEstruturaCampoDinamico(idOperacao, schemaDbReport);
	}
	
	private void geraNuvem(Integer idOperacao, String schemaDB) throws Exception {
		Date dataAtual = dao.getDataBanco();
		Date dataInicioExecucao = null;
		Date dataFimExecucao = null;
		Date dataUltimaExecucao = buscaDataUltimaExecucao(idOperacao);
		
		if (dataUltimaExecucao == null) {
			throw new Exception("Não foi possível encontrar o parâmetro de data da última execução.");
		}
		
		dataInicioExecucao = dataUltimaExecucao;
		
		/**
		 * Faz expurgo dos dados de acordo com a quantidade de dias configurados
		 * Caso não exista quantidade de dias, ou seja zero, não faz
		 */
		Integer qtdDiasExpurgo = null;
		String valorParametroExpurgo = parametroSistemaDAO.findValorParametroSistemaOperacao(
				ParametroSistemaOperacaoEnum.QTD_DIAS_EXPURGO_DADOS.getParametroSistemaOperacao(), idOperacao);
		if (valorParametroExpurgo != null && !valorParametroExpurgo.isEmpty()) {
			qtdDiasExpurgo = Integer.valueOf(valorParametroExpurgo);
			
			if (qtdDiasExpurgo > 0) {
				String valorParamQtdRegistrosExpurgoPorVez = parametroSistemaDAO.findValorParametroSistema(QTD_REGISTROS_DELETE_POR_VEZ);
				Integer qtdRegistrosExpurgoPorVez = valorParamQtdRegistrosExpurgoPorVez != null && !valorParamQtdRegistrosExpurgoPorVez.isEmpty()
						? Integer.valueOf(valorParamQtdRegistrosExpurgoPorVez) : Constantes.QTD_PADRAO_REGISTROS_DELETE;
				
				executaExpurgoDados(idOperacao, qtdDiasExpurgo, dataAtual, qtdRegistrosExpurgoPorVez);
			}
		}
		
		Boolean diaAtual = false;
		/**
		 * Se a data da última execução for mesmo dia da data atual, executa uma vez a partir da última execução, até a data/hora atual
		 * Se a data da última execução não for no mesmo dia, percorre cada dia executando até chegar na data/hora atual
		 */
		do {
			Date dataInicioCalculo = dataInicioExecucao;
			if (DateUtils.addFirstTimeInDate(dataInicioExecucao).equals(DateUtils.addFirstTimeInDate(dataAtual))) {
				dataFimExecucao = dataAtual;
				diaAtual = true;
				
				// Diminui em um hora para que não corra o risco de perder algum log por causa da data
				Calendar calCalculo = Calendar.getInstance();
				calCalculo.setTime(dataInicioExecucao);
				calCalculo.add(Calendar.HOUR_OF_DAY, -1);
				dataInicioCalculo = calCalculo.getTime();
			} else {
				dataFimExecucao = DateUtils.addLastTimeInDate(dataInicioExecucao);
				diaAtual = false;
			}
			
			geraNuvemHistoricoCaso(idOperacao, dataInicioCalculo, dataFimExecucao, dataAtual, diaAtual, schemaDB);
			
			Calendar cal = Calendar.getInstance();
			cal.setTime(dataInicioExecucao);
			cal.add(Calendar.DAY_OF_MONTH, 1);
			dataInicioExecucao = DateUtils.addFirstTimeInDate(cal.getTime());
			
			dataUltimaExecucao = dataFimExecucao;
			
		} while (dataUltimaExecucao.before(dataAtual));
		
		atualizaDataUltimaExecucao(idOperacao, dataAtual);
	}
	
	private void geraNuvemHistoricoCaso(Integer idOperacao, Date dataInicio, Date dataFim, Date dataInsercao, Boolean diaAtual, String schemaDB) throws Exception {
		try {
			Integer ultimoIdLogAberto = null;
			Integer ultimoIdLogFechado = null;
			Boolean continuaExecucaoAberto = true;
			Boolean continuaExecucaoFechado = true;
			List<CampoDinamicoTO> camposDinamicos = dao.buscaCamposDinamicos(idOperacao);
			while (continuaExecucaoFechado) {
				logger.info("Processando casos fechados Historico de Caso. Operacao: "+idOperacao+" - Ultimo Log Processado: "+ultimoIdLogFechado);
				List<RelatorioHistoricoCasoTO> listFechados = dao.geraNuvemHistoricoCasoPeriodoFechados(idOperacao, dataInicio, dataFim, diaAtual, 
						camposDinamicos, ultimoIdLogFechado,schemaDB);
				continuaExecucaoFechado = listFechados.size() >= 2500 ? true : false;
				ultimoIdLogFechado= processaLista(dataInsercao,	ultimoIdLogFechado, schemaDB, listFechados);
			}
			while (continuaExecucaoAberto) {
				logger.info("Processando casos abertos Historico de Caso. Operacao: "+idOperacao+" - Ultimo Log Processado: "+ultimoIdLogAberto);
				List<RelatorioHistoricoCasoTO> listAberto = dao.geraNuvemHistoricoCasoPeriodoAbertos(idOperacao, dataInicio, dataFim, diaAtual, 
						camposDinamicos, ultimoIdLogAberto,schemaDB);
			
				continuaExecucaoAberto = listAberto.size() >= 2500 ? true : false;
				ultimoIdLogAberto = processaLista(dataInsercao,	ultimoIdLogAberto, schemaDB, listAberto);
			}
		} catch (Exception e) {
			StringBuilder errors = new StringBuilder("[Operação: ");
			errors.append(idOperacao);
			errors.append("] ");
			errors.append(e.getMessage());
			logger.log(Level.SEVERE, errors.toString(), e);
		}
	}
				
	private Integer processaLista(Date dataInsercao, Integer ultimoIdLog, String schemaDB, List<RelatorioHistoricoCasoTO> list) throws Exception {
		for (int x = 0; x < list.size(); x++) {
			RelatorioHistoricoCasoTO historico = list.get(x);

			descriptografaEMascaraValores(historico.getCamposDinamicos());

			if (x == list.size() - 1) {
				ultimoIdLog = historico.getIdLog();
			}

			historico.setDataInsercao(dataInsercao);

			/**
			 * Cálculo de SLA
			 */
			CasoTO caso = new CasoTO();
			caso.setIdCaso(historico.getIdCaso());
			caso.setIdOperacao(historico.getIdOperacao());
			if (historico.getDataAberturaLogSla() != null) {
				caso.setDataAbertura(historico.getDataAberturaLogSla());
			} else {
				caso.setDataAbertura(historico.getDataAberturaCaso());
			}
			caso.setDataCadastro(historico.getDataCadastro());

			/**
			 * Caso não tenha SLA no log, utiliza SLA do caso para fazer o
			 * cálculo
			 */
			if (historico.getIdSlaFilaLogSla() != null && historico.getIdSlaFilaLogSla() > 0) {
				caso.setSlaFilaTO(new SlaFilaTO(historico.getIdSlaFilaLogSla()));
			} else {
				caso.setSlaFilaTO(new SlaFilaTO(historico.getIdSlaCaso()));
			}
			
			try {
				if (historico.getDataFimSla() != null && historico.getDataLog().compareTo(historico.getDataFimSla()) > 0) {
					calculoSlaUtil.loadSla(caso, historico.getDataFimSla());
				} else {
					calculoSlaUtil.loadSla(caso, historico.getDataLog());
				}
				
			} catch (Exception e) {
				throw new Exception("Erro ao calcular o SLA do caso. Log: " + historico.getIdHistorico(), e);
			}
			
			historico.setPercentualSla(caso.getPorcentagemSla());
			historico.setSlaMinutos(caso.getSlaEmMinutos());

			Long tempoTotal = null;
			if (caso.getSlaTotalMinutos() != null) {
				tempoTotal = caso.getSlaTotalMinutos() != null ? Long.valueOf(caso.getSlaTotalMinutos()) : null;
			} else {
				tempoTotal = historico.getSla() != null ? Long.valueOf(historico.getSla()) : null;
			}
			
			if (tempoTotal != null) {
				historico.setSlaTotal(TempoUtilHelper.formataMinutosEmHorasMinutos(tempoTotal));
			}

			dao.buscaValoresCamposDinamicosListaCaso(historico);

			dao.persisteCampoTabela(historico, schemaDB);
		}

		dao.persisteDadosNuvemHistoricoCaso(schemaDbReport, list);
		return ultimoIdLog;
	}
	
	private void descriptografaEMascaraValores(List<CampoDinamicoTO> camposDinamicos) throws Exception {
		if (CollectionUtils.hasValue(camposDinamicos)) {
			for (CampoDinamicoTO campoDinamicoTO : camposDinamicos) {
				final boolean MASK_ALL_CHAR = campoDinamicoTO.getFlagMascaraTodosCaracteres() != null && campoDinamicoTO.getFlagMascaraTodosCaracteres();
				final String MASK = campoDinamicoTO.getMascara();

				if (campoDinamicoTO.getValor() != null && !campoDinamicoTO.getValor().toString().isEmpty()) {
					if (TipoCampoDinamico.CRIPTOGRAFADO.equals(campoDinamicoTO.getTipoCampo())) {
						if (campoDinamicoTO.getFlagExportarValorReal() != null && campoDinamicoTO.getFlagExportarValorReal()
								&& campoDinamicoTO.getValor() != null && !campoDinamicoTO.getValor().toString().isEmpty()) {
							try {
								AESCryptoImpl aes = new AESCryptoImpl();
								campoDinamicoTO.setValor(maskUtil.aplicarMascara(MASK_ALL_CHAR, MASK, aes.decrypt(campoDinamicoTO.getValor().toString())));

							} catch (CryptographyException e) {
								throw new Exception("Erro ao descriptografar campo: " + campoDinamicoTO.getLabel(), e);
							}
						}
						
					} else {
						campoDinamicoTO.setValor(maskUtil.aplicarMascara(MASK_ALL_CHAR, MASK, campoDinamicoTO.getValor().toString()));
					}
				}
			}
		}
	}

	private Date buscaDataUltimaExecucao(Integer idOperacao) throws Exception {
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date dataUltimaExecucao = null;
		
		try {
			String valorParametro = parametroSistemaDAO.findValorParametroSistemaOperacao(
				ParametroSistemaOperacaoEnum.ULTIMA_EXECUCAO_HISTORICO_CASO.getParametroSistemaOperacao(), idOperacao);
			
			if (valorParametro != null && !valorParametro.isEmpty()) {
				dataUltimaExecucao = df.parse(valorParametro);
			}
		} catch (Exception e) {
			StringBuilder errors = new StringBuilder("[");
			errors.append("Erro ao obter parâmetro de data última execução. Parâmetro: "
					+ ParametroSistemaOperacaoEnum.ULTIMA_EXECUCAO_HISTORICO_CASO.getParametroSistemaOperacao() + ", operação: " + idOperacao);
			errors.append("] ");
			errors.append(e.getMessage());
			logger.log(Level.SEVERE, errors.toString(), e);
		}
		return dataUltimaExecucao;
	}
	
	private void atualizaDataUltimaExecucao(Integer idOperacao, Date data) throws Exception {
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			parametroSistemaDAO.atualizaValorParametroSistemaOperacao(
				ParametroSistemaOperacaoEnum.ULTIMA_EXECUCAO_HISTORICO_CASO.getParametroSistemaOperacao(),
				idOperacao, df.format(data));
		} catch (Exception e) {
			StringBuilder errors = new StringBuilder("[ ");
			errors.append("Erro ao atualizar parâmetro de data última execução. Parâmetro: "
					+ ParametroSistemaOperacaoEnum.ULTIMA_EXECUCAO_HISTORICO_CASO.getParametroSistemaOperacao() 
					+ ", operação: " + idOperacao);
			errors.append("] ");
			errors.append(e.getMessage());
			logger.log(Level.SEVERE, errors.toString(), e);
		}
	}
	
	private void executaExpurgoDados(Integer idOperacao, Integer qtdDiasExpurgo, Date dataAtual, Integer qtdRegistrosExpurgoPorVez) throws Exception {
		try {
			dao.executaExpurgoDados(schemaDbReport, idOperacao, qtdDiasExpurgo, dataAtual, qtdRegistrosExpurgoPorVez);
			
		} catch (Exception e) {
			StringBuilder errors = new StringBuilder("[Operação: ");
			errors.append(idOperacao);
			errors.append("] ");
			errors.append(e.getMessage());
			logger.log(Level.SEVERE, errors.toString(), e);
		}
	}
	
	private void geraNuvemCasosDeletados(Integer idOperacao, String schemaDB, Date dataCasoDeletado) throws Exception {
		try {
			// Insere os casos deletados do dia que ainda não estejam na base de relatorios
			dao.insereCasosDeletados(idOperacao, schemaDB, dataCasoDeletado);
		} catch (Exception e) {
			StringBuilder errors = new StringBuilder("[Erro ao gerar nuvem de casos deletados da operação: ");
			errors.append(idOperacao);
			errors.append("] ");
			errors.append(e.getMessage());
			logger.log(Level.SEVERE, errors.toString(), e);
		}
	}
	
}
