package br.com.callink.cad.jobs;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import br.com.callink.cad.dao.ParametroSistemaDAO;
import br.com.callink.cad.dao.RelatorioRespostaEnqueteDAO;
import br.com.callink.cad.enumeration.ParametroSistemaOperacaoEnum;
import br.com.callink.cad.to.RelatorioRespostaEnqueteTO;
import br.com.callink.cad.util.Constantes;
import br.com.callink.cad.util.DateUtils;

public class JobRelatorioRespostaEnquete extends CadJob {

	private Logger logger = Logger.getLogger(JobRelatorioRespostaEnquete.class.getName());
	private RelatorioRespostaEnqueteDAO dao;
	private ParametroSistemaDAO parametroSistemaDAO;
	private static final String QTD_REGISTROS_DELETE_POR_VEZ = "qtdRegistrosDeletePorVez";
	private String schemaDbReport;
	
	private void setUp(Integer idTenant) throws Exception {
		if (dao == null) {
			dao = new RelatorioRespostaEnqueteDAO();
		}
		if (parametroSistemaDAO == null) {
			parametroSistemaDAO = new ParametroSistemaDAO();
		}
		
		schemaDbReport = getSchemaDbReport(idTenant);
	}
	
	@Override
	protected void process(Integer idTenant, Integer idOperacao, String nome) throws Exception {
		setUp(idTenant);
		geraNuvem(idOperacao);
	}
	
	private void geraNuvem(Integer idOperacao) throws Exception {
		Date dataAtual = dao.getDataBanco();
		Date dataInicioExecucao = null;
		Date dataFimExecucao = null;
		Date dataUltimaExecucao = buscaDataUltimaExecucao(idOperacao);
		
		if (dataUltimaExecucao == null) {
			throw new Exception("Não foi possível encontrar o parâmetro de data da última execução.");
		}
		
		dataInicioExecucao = dataUltimaExecucao;
		
		/**
		 * Faz expurgo dos dados de acordo com a quantidade de dias configurados
		 * Caso não exista quantidade de dias, ou seja zero, não faz
		 */
		Integer qtdDiasExpurgo = null;
		String valorParametroExpurgo = parametroSistemaDAO.findValorParametroSistemaOperacao(
				ParametroSistemaOperacaoEnum.QTD_DIAS_EXPURGO_DADOS.getParametroSistemaOperacao(), idOperacao);
		if (valorParametroExpurgo != null && !valorParametroExpurgo.isEmpty()) {
			qtdDiasExpurgo = Integer.valueOf(valorParametroExpurgo);
			
			if (qtdDiasExpurgo > 0) {
				String valorParamQtdRegistrosExpurgoPorVez = parametroSistemaDAO.findValorParametroSistema(QTD_REGISTROS_DELETE_POR_VEZ);
				Integer qtdRegistrosExpurgoPorVez = valorParamQtdRegistrosExpurgoPorVez != null && !valorParamQtdRegistrosExpurgoPorVez.isEmpty()
						? Integer.valueOf(valorParamQtdRegistrosExpurgoPorVez) : Constantes.QTD_PADRAO_REGISTROS_DELETE;
				
				executaExpurgoDados(idOperacao, qtdDiasExpurgo, dataAtual, qtdRegistrosExpurgoPorVez);
			}
		}
		
		
		/**
		 * Se a data da última execução for mesmo dia da data atual, executa uma vez a partir da última execução, até a data/hora atual
		 * Se a data da última execução não for no mesmo dia, percorre cada dia executando até chegar na data/hora atual
		 */
		do {
			if (DateUtils.addFirstTimeInDate(dataInicioExecucao).equals(DateUtils.addFirstTimeInDate(dataAtual))) {
				dataFimExecucao = dataAtual;
			} else {
				dataFimExecucao = DateUtils.addLastTimeInDate(dataInicioExecucao);
			}
			
			geraNuvemEnquetes(idOperacao, dataInicioExecucao, dataFimExecucao, dataAtual);
			
			Calendar cal = Calendar.getInstance();
			cal.setTime(dataInicioExecucao);
			cal.add(Calendar.DAY_OF_MONTH, 1);
			dataInicioExecucao = DateUtils.addFirstTimeInDate(cal.getTime());
			
			dataUltimaExecucao = dataFimExecucao;
			
		} while (dataUltimaExecucao.before(dataAtual));
		
		atualizaDataUltimaExecucao(idOperacao, dataAtual);
	}
	
	private void geraNuvemEnquetes(Integer idOperacao, Date dataInicio, Date dataFim, Date dataInsercao) throws Exception {
		try {
			List<RelatorioRespostaEnqueteTO> list = dao.geraNuvemEnquetesPeriodo(idOperacao, dataInicio, dataFim);
			
			for (RelatorioRespostaEnqueteTO enquete : list) {
				enquete.setIdOperacao(idOperacao);
				enquete.setDataInsercao(dataInsercao);
				
				dao.persisteDadosNuvemEnquete(schemaDbReport, enquete);
			}
			
		} catch (Exception e) {
			StringBuilder errors = new StringBuilder("[Operação: ");
			errors.append(idOperacao);
			errors.append("] ");
			errors.append(e.getMessage());
			logger.log(Level.SEVERE, errors.toString(), e);
		}
	}
	
	private Date buscaDataUltimaExecucao(Integer idOperacao) throws Exception {
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date dataUltimaExecucao = null;
		
		try {
			String valorParametro = parametroSistemaDAO.findValorParametroSistemaOperacao(
				ParametroSistemaOperacaoEnum.ULTIMA_EXECUCAO_RESPOSTA_ENQUETE.getParametroSistemaOperacao(), idOperacao);
			
			if (valorParametro != null && !valorParametro.isEmpty()) {
				dataUltimaExecucao = df.parse(valorParametro);
			}
			
		} catch (Exception e) {
			StringBuilder errors = new StringBuilder("[ ");
			errors.append("Erro ao obter parâmetro de data última execução. Parâmetro: "
					+ ParametroSistemaOperacaoEnum.ULTIMA_EXECUCAO_RESPOSTA_ENQUETE.getParametroSistemaOperacao() 
					+ ", operação: " + idOperacao);
			errors.append("] ");
			errors.append(e.getMessage());
			logger.log(Level.SEVERE, errors.toString(), e);
		}
		return dataUltimaExecucao;
	}
	
	private void atualizaDataUltimaExecucao(Integer idOperacao, Date data) throws Exception {
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			parametroSistemaDAO.atualizaValorParametroSistemaOperacao(
				ParametroSistemaOperacaoEnum.ULTIMA_EXECUCAO_RESPOSTA_ENQUETE.getParametroSistemaOperacao(),
				idOperacao, df.format(data));
			
		} catch (Exception e) {
			StringBuilder errors = new StringBuilder("[ ");
			errors.append("Erro ao atualizar parâmetro de data última execução. Parâmetro: "
					+ ParametroSistemaOperacaoEnum.ULTIMA_EXECUCAO_RESPOSTA_ENQUETE.getParametroSistemaOperacao() 
					+ ", operação: " + idOperacao);
			errors.append("] ");
			errors.append(e.getMessage());
			logger.log(Level.SEVERE, errors.toString(), e);
		}
	}
	
	private void executaExpurgoDados(Integer idOperacao, Integer qtdDiasExpurgo, Date dataAtual, Integer qtdRegistrosExpurgoPorVez) throws Exception {
		try {
			dao.executaExpurgoDados(schemaDbReport, idOperacao, qtdDiasExpurgo, dataAtual, qtdRegistrosExpurgoPorVez);
		} catch (Exception e) {
			StringBuilder errors = new StringBuilder("[Operação: ");
			errors.append(idOperacao);
			errors.append("] ");
			errors.append(e.getMessage());
			logger.log(Level.SEVERE, errors.toString(), e);
		}
	}
	
}
