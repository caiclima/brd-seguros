package br.com.callink.cad.jobs;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.quartz.JobExecutionException;

import br.com.callink.cad.dao.ParametroSistemaDAO;
import br.com.callink.cad.dao.RetiraCasoUsuarioDao;
import br.com.callink.cad.enumeration.ParametroSistemaOperacaoEnum;
import br.com.callink.cad.sla.util.TempoUtilHelper;
import br.com.callink.cad.to.AnexoTO;
import br.com.callink.cad.to.AtendimentoCasoTO;
import br.com.callink.cad.to.CasoTO;
import br.com.callink.cad.to.GrupoAnexoTO;
import br.com.callink.cad.to.LogSlaCasoTO;
import br.com.callink.cad.to.LogTO;
import br.com.callink.cad.util.CalculoSlaHelper;
import br.com.callink.cad.util.Constantes;
import br.com.callink.cad.util.DateUtils;
import br.com.callink.cad.util.TransactionUtils;

/**
 * @author swb_brunocamargo
 * 
 */
public class JobRetiraCasoUsuario extends CadJob {

	private Logger logger = Logger.getLogger(JobRetiraCasoUsuario.class.getName());

	private ParametroSistemaDAO parametroSistemaDAO;
	private RetiraCasoUsuarioDao dao;

	private CalculoSlaHelper calculoSlaUtil;

	private List<Integer> listRemoveFilaClassificacaoCaso;
	private List<CasoTO> listUpdateCaso;
	private List<AtendimentoCasoTO> listInsereAtendimentoCaso;
	private List<LogTO> listInsereLog;

	private void setUp(Integer idOperacao) {
		try {
			if (dao == null) {
				dao = new RetiraCasoUsuarioDao();
			}
			if (parametroSistemaDAO == null) {
				parametroSistemaDAO = new ParametroSistemaDAO();
			}
			if (calculoSlaUtil == null) {
				calculoSlaUtil = new CalculoSlaHelper(getFeriadosOperacao(idOperacao),
						getJornadaOperacao(idOperacao),
						getSlaFilaOperacao(idOperacao));
			}
			if (listRemoveFilaClassificacaoCaso == null) {
				listRemoveFilaClassificacaoCaso = new ArrayList<Integer>();
			}
			if (listUpdateCaso == null) {
				listUpdateCaso = new ArrayList<CasoTO>();
			}
			if (listInsereAtendimentoCaso == null) {
				listInsereAtendimentoCaso = new ArrayList<AtendimentoCasoTO>();
			}
			if (listInsereLog == null) {
				listInsereLog = new ArrayList<LogTO>();
			}

		} catch (Exception e) {
			StringBuilder errors = new StringBuilder("[Operação: ");
			errors.append(idOperacao);
			errors.append("] ");
			errors.append(e.getMessage());
			logger.log(Level.SEVERE, errors.toString(), e);
		}
	}

	@Override
	protected void process(Integer idTenant, Integer idOperacao, String nome) throws Exception {
		setUp(idOperacao);
		executaRetiraCasoUsuario(idOperacao);
	}

	public void executaRetiraCasoUsuario(Integer idOperacao) {

		logger.info("JobRetiraCasoUsuario iniciada");

		verificaTempoCasoUsuario(idOperacao);

		logger.info("JobRetiraCasoUsuario Finalizada");
	}

	private void verificaTempoCasoUsuario(Integer idOperacao)  {
		try {
			logger.info("Executando processo que remove casos sem atendimento...");

			retiraCasoUsuariosInativos(idOperacao);
			
			logger.info("Fim processo que remove casos sem atendimento...");
			
		} catch (Exception ex) {
			StringBuilder errors = new StringBuilder("[Operação: ");
			errors.append(idOperacao);
			errors.append("] ");
			errors.append(ex.getMessage());
			logger.log(Level.SEVERE, errors.toString(), ex);
		}
	}

	private Boolean retiraCasoUsuariosInativos(Integer idOperacao) throws Exception {

		String valorParametro = parametroSistemaDAO
				.findValorParametroSistemaOperacao(
						ParametroSistemaOperacaoEnum.TEMPO_RETIRA_CASO_FILA_ATENDENTE.getParametroSistemaOperacao(),
						idOperacao);

		if (valorParametro != null && !valorParametro.isEmpty()) {

			List<CasoTO> casoList = dao.buscaCasoEmAtendimento(idOperacao);
			carregaSlas(casoList);

			for (CasoTO caso : casoList) {
				try {
					LogTO ultimoLog = null;
					List<LogTO> logList = findHistorico(caso);
					if (logList != null && !logList.isEmpty()) {
						ultimoLog = logList.get(logList.size() - 1);
	
						String slalogSplit[] = ultimoLog.getTempoGasto().split(":");
						Integer slaLog = (Integer.valueOf(slalogSplit[0]) * 60) + Integer.valueOf(slalogSplit[1]);
						
						if (slaLog > Integer.valueOf(valorParametro)) {
							caso.setIdUsuario(null);
							caso.setIdConfiguracaoFila(null);
							caso.setFlagClassifica(Boolean.TRUE);
							listRemoveFilaClassificacaoCaso.add(caso.getIdCaso());
	
							saveLog(caso, "Caso retirado do usuario por ficar inativo.");
							update(caso);
						}
					}
				} catch (Exception e) {
					StringBuilder errors = new StringBuilder("[Operação: ");
					errors.append(idOperacao);
					errors.append("] ");
					errors.append(String.format("Id do Caso: %d ",caso.getIdCaso()));
					errors.append(e.getMessage());
					logger.log(Level.SEVERE, errors.toString(), e);
					throw e;
				}
			}
			for (List<Integer> remove : TransactionUtils.subLists(listRemoveFilaClassificacaoCaso,
					Constantes.NRO_REGISTROS_COMMIT)) {
				dao.removeFilaClassificaoCaso(remove);
			}
			for (List<CasoTO> update : TransactionUtils.subLists(listUpdateCaso, Constantes.NRO_REGISTROS_COMMIT)) {
				dao.updateCaso(update);
			}
			for (List<AtendimentoCasoTO> insert : TransactionUtils.subLists(listInsereAtendimentoCaso,
					Constantes.NRO_REGISTROS_COMMIT)) {
				dao.insereAtendimentoCaso(insert);
			}
			for (List<LogTO> insert : TransactionUtils.subLists(listInsereLog, Constantes.NRO_REGISTROS_COMMIT)) {
				dao.insereLog(insert);
			}
		}

		return true;
	}

	public void update(CasoTO caso) throws Exception {

		String erros = validaCaso(caso);
		if (erros != null && !erros.isEmpty()) {
			throw new JobExecutionException(erros);
		}

		listUpdateCaso.add(caso);

		if (caso.getIdConfiguracaoFila() != null) {
			marcacaoAtendimentoCaso(caso);
		}
	}

	private void marcacaoAtendimentoCaso(CasoTO caso) throws Exception {
		AtendimentoCasoTO atendimentoCaso = new AtendimentoCasoTO();
		atendimentoCaso.setIdCaso(caso.getIdCaso());
		atendimentoCaso.setIdUsuario(caso.getIdUsuario());
		atendimentoCaso.setIdStatus(caso.getIdStatus());
		atendimentoCaso.setIdConfiguracaoFila(caso.getIdConfiguracaoFila());
		atendimentoCaso.setFlgInicio(Boolean.TRUE);

		listInsereAtendimentoCaso.add(atendimentoCaso);
	}

	private String validaCaso(CasoTO caso) throws Exception {
		StringBuilder erro = new StringBuilder();
		if (caso == null) {
			throw new Exception("Caso informado esta nulo.");
		}

		if (caso.getDataAbertura() == null) {
			erro.append("Campo obrigat\u00F3rio. : Data de abertura ").append("\n");
		}
		return erro.toString();
	}

	private void saveLog(CasoTO casoTO, String descricao) throws Exception {
		LogTO log = new LogTO();
		log.setIdCaso(casoTO.getIdCaso());
		log.setIdConfiguracaoFila(casoTO.getIdConfiguracaoFila());
		log.setDescricao(descricao);
		log.setDataLog(dao.getDataBanco());
		log.setDataAbertura(casoTO.getDataAbertura());
		if (log.getIdStatus() == null) {
			log.setIdStatus(casoTO.getIdStatus());
		}
		log.setIdUsuario(casoTO.getIdUsuario());
		log.setIdSlaFila(casoTO.getSlaFilaTO() != null && casoTO.getSlaFilaTO().getIdSlaFila() != null ? casoTO.getSlaFilaTO().getIdSlaFila() : null);
		log.setIdEvento(casoTO.getIdEvento());
		listInsereLog.add(log);
	}

	public List<LogTO> findHistorico(CasoTO caso) throws JobExecutionException {
		try {

			List<LogTO> logs = dao.buscaHistorioByCaso(caso.getIdCaso());

			if (logs == null || logs.isEmpty()) {
				return new ArrayList<LogTO>();
			}

			// Busca histórico de alteração de SLA do caso
			List<LogSlaCasoTO> logsSla = dao.findLogSlaByCaso(caso.getIdCaso());

			for (LogTO log : logs) {
				Date dataAbertura = caso.getDataAbertura();

				// Se a data do log for antes da data de abertura do caso, pega o histórico de alteração do SLA.
				// Pega a última data que for antes da data do log, e seta na data de abertura.
				if (caso.getDataAbertura().compareTo(log.getDataLog()) > 0) {
					for (LogSlaCasoTO logSlaCaso : logsSla) {
						if (logSlaCaso.getDataAbertura().compareTo(log.getDataLog()) > 0) {
							continue;
						} else {
							dataAbertura = logSlaCaso.getDataAbertura();
							break;
						}
					}
				}

				// seta o SLA de acordo c/ a data do log atual em relação à data de abertura
				log.setSlaLog(calculoSlaUtil.calculaSlaIntervaloEmMinutosFormatado(caso.getSlaFilaTO(), dataAbertura,
						log.getDataLog(), caso.getIdOperacao()));

				if (log.getIdGrupoAnexo() != null) {
					if (log.getGrupoAnexoTO() == null) {
						log.setGrupoAnexoTO(new GrupoAnexoTO());
					}
					log.getGrupoAnexoTO().setAnexoList(dao.buscaPorGrupoAnexo(log.getIdGrupoAnexo()));
				} else {
					log.setGrupoAnexoTO(new GrupoAnexoTO());
					log.getGrupoAnexoTO().setAnexoList(new ArrayList<AnexoTO>());
				}

				// se existe proximo log
				int i = logs.indexOf(log);
				if (i < logs.size() - 1) {
					// tempo gasto => tempo do log atual até proximo log (caso exista proximo)
					log.setTempoGasto(TempoUtilHelper.formataSegundosEmHMS(Long.valueOf(DateUtils
							.getSecondsBetweenDates(log.getDataLog(), logs.get(i + 1).getDataLog()))));
				} else {
					// se caso ja finalizado, tempo gasto => data ultimo log até data data encerramento
					if (caso.getDataEncerramento() != null) {
						log.setTempoGasto(TempoUtilHelper.formataSegundosEmHMS(Long.valueOf(DateUtils
								.getSecondsBetweenDates(log.getDataLog(), caso.getDataEncerramento()))));
					} else {
						// caso nao foi finalizado, tempo gasto => tempo do log atual até a data do banco (pois é o
						// ultimo log)
						log.setTempoGasto(TempoUtilHelper.formataSegundosEmHMS(Long.valueOf(DateUtils
								.getSecondsBetweenDates(log.getDataLog(), dao.getDataBanco()))));
					}
				}
			}

			return logs;

		} catch (Exception ex) {
			throw new JobExecutionException("Erro ao buscar hist\u00F3rico do caso", ex);
		}
	}

	public List<CasoTO> carregaSlas(List<CasoTO> casos) throws Exception {
		Date dataAtual = dao.getDataBanco();

		for (CasoTO caso : casos) {
			calculoSlaUtil.loadSla(caso, dataAtual);
		}

		return casos;
	}
}
