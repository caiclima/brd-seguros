package br.com.callink.cad.jobs;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import br.com.callink.cad.dao.NotificacaoDAO;
import br.com.callink.cad.dao.ParametroSistemaDAO;
import br.com.callink.cad.dao.UsuarioLogadoDAO;
import br.com.callink.cad.enumeration.NotificacaoEnum;
import br.com.callink.cad.enumeration.ParametroSistemaOperacaoEnum;
import br.com.callink.cad.to.UsuarioLogadoTO;

public class JobValidaTempoDisponivel extends CadJob {
	private final Logger logger = Logger.getLogger(getClass().getName());

	private ParametroSistemaDAO parametroSistemaDAO;
	private UsuarioLogadoDAO dao;
	private NotificacaoDAO notificacaoDao;
	
	public void setUp() throws Exception {

		if (dao == null) {
			dao = new UsuarioLogadoDAO();
		}
		if (notificacaoDao == null) {
			notificacaoDao = new NotificacaoDAO();
		}
		if (parametroSistemaDAO == null) {
			parametroSistemaDAO = new ParametroSistemaDAO();
		}
	}
	
	@Override
	protected void process(Integer idTenant, Integer idOperacao, String nome) throws Exception {
		setUp();
		logger.info("JobValidaTempoDisponivel iniciada");

		validaTemposDisponivel(idOperacao);
		logger.info("JobValidaTempoDisponivel finalizada");
	}
	
	private void validaTemposDisponivel(Integer idOperacao) throws Exception {
        
		if (idOperacao == null) {
			logger.log(Level.SEVERE, "A operacao nao foi configurada");
			return;
		}
		
		Integer tempoReal = null;
		String valorParamTempoDisp = parametroSistemaDAO.findValorParametroSistemaOperacao(ParametroSistemaOperacaoEnum.TEMPO_DISPONIVEL_ENVIA_CASO.toString(), idOperacao);
		Integer idStatusDisponivel = null; 
		String valorParamStatus = parametroSistemaDAO.findValorParametroSistemaOperacao(ParametroSistemaOperacaoEnum.ATENDENTE_STATUS_DISPONIVEL.toString(), idOperacao);
		
		if (valorParamTempoDisp == null || valorParamTempoDisp.isEmpty()) {
			logger.log(Level.SEVERE, "O parametro tempodisponivelenviacaso nao foi configurado");
			return;
		}
		try {
			tempoReal = Integer.valueOf(valorParamTempoDisp);
		} catch (Exception e) {
			logger.log(Level.SEVERE, "O parametro tempodisponivelenviacaso nao foi configurado corretamente. Operação: "+idOperacao, e);
			return;
		}
		
		if (valorParamStatus == null || valorParamStatus.isEmpty()) {
			logger.log(Level.SEVERE, "O parametro idusuariostatusdisponivel nao foi configurado. Operação: "+idOperacao);
			return;
		}
		try {
			idStatusDisponivel = Integer.valueOf(valorParamStatus);
		} catch (Exception e) {
			logger.log(Level.SEVERE, "O parametro idusuariostatusdisponivel nao foi configurado corretamente. Operação: "+idOperacao, e);
			return;
		}
		
		List<UsuarioLogadoTO> usuariosLogadosTO = dao.validaTempoDisponivel(idOperacao, tempoReal, idStatusDisponivel);
		
		for (UsuarioLogadoTO usrLogado : usuariosLogadosTO) {
			try {
				Integer qtdNotificacao = dao.quantidadeMensagemUsuario(usrLogado.getIdUsuario(), NotificacaoEnum.TEMPO_EXPIRADO.toString());
				
				if (qtdNotificacao.equals(Integer.valueOf(0))) {
					notificacaoDao.insereNotificacaoUsuario(NotificacaoEnum.TEMPO_EXPIRADO.toString(), usrLogado.getIdUsuario());
				}
			} catch (Exception e) {
				StringBuilder errors = new StringBuilder("[Operação: ");
				errors.append(idOperacao);
				errors.append("] ");
				errors.append(String.format("Usuário Logado: %s ",usrLogado.getLogin()));
				errors.append(e.getMessage());
				logger.log(Level.SEVERE, errors.toString(), e);
				throw e;
			}
		}
	}
}