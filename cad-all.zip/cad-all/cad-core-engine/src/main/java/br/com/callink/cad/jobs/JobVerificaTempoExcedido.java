package br.com.callink.cad.jobs;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import br.com.callink.cad.dao.CasoDAO;
import br.com.callink.cad.dao.ConfiguracaoAcaoAutomaticaDAO;
import br.com.callink.cad.dao.RecebeEmailDAO;
import br.com.callink.cad.to.CasoTO;
import br.com.callink.cad.to.ConfiguracaoAcaoAutomaticaTO;
import br.com.callink.cad.to.DataFiltro;
import br.com.callink.cad.util.AcaoAutomaticaExecutor;

public class JobVerificaTempoExcedido extends CadJob {

	private Logger logger = Logger.getLogger(JobVerificaTempoExcedido.class.getName());
	
	private CasoDAO casoDAO;
	private ConfiguracaoAcaoAutomaticaDAO configuracaoAcaoAutomaticaDAO;
	private RecebeEmailDAO recebeEmailDAO;
	
	private static final String TIPO_COMPARACAO_ANTES = "ANTES";
	private static final String TIPO_COMPARACAO_APOS = "APOS";
	
	private void setUp() throws Exception {
		if (casoDAO == null) {
			casoDAO = new CasoDAO();
		}
		if(recebeEmailDAO == null) {
			recebeEmailDAO = new RecebeEmailDAO();
		}
		if (configuracaoAcaoAutomaticaDAO == null) {
			configuracaoAcaoAutomaticaDAO = new ConfiguracaoAcaoAutomaticaDAO();
		}
	}
	
	@Override
	protected void process(Integer idTenant, Integer idOperacao, String nome) throws Exception {
		if (idOperacao == null) {
			return;
		}
		setUp();
		
		buscaExecutaAcoesAutomaticas(idOperacao,idTenant);
	}
	
	private void buscaExecutaAcoesAutomaticas(Integer idOperacao, Integer idTenant) throws Exception {
		try {
			AcaoAutomaticaExecutor acaoExecutor = new AcaoAutomaticaExecutor();
			
			// Busca configuracoes por tempo
			List<ConfiguracaoAcaoAutomaticaTO> configuracoes = configuracaoAcaoAutomaticaDAO.findByTipoConfiguracaoAndOperacao(
					AcaoAutomaticaExecutor.TIPO_TEMPO_EXCEDIDO, idOperacao);
			
			for (ConfiguracaoAcaoAutomaticaTO config : configuracoes) {
				if (config.getDataFiltro() == null || config.getTipoComparacao() == null) {
					throw new Exception("Não é possível realizar ação automática, pois configuração da ação não possui Data Filtro ou Tipo Comparação.");
				}
				
				// Busca casos com base no filtro das configuracoes
				List<CasoTO> casos = new ArrayList<CasoTO>();
				casos = casoDAO.findCasosByFiltrosConfiguracaoTempo(config, montaFiltroData(config));
				
				for (CasoTO caso : casos) {
					try {
					caso = recebeEmailDAO.loadCasoTO(caso.getIdCaso());
					acaoExecutor.executaConfiguracaoAcaoAutomatica(caso, config, null, idTenant);
					} catch (Exception e) {
						StringBuilder errors = new StringBuilder("[Operação: ");
						errors.append(idOperacao);
						errors.append("] ");
						errors.append(String.format("Id do caso: %d",caso.getIdCaso()));
						errors.append(e.getMessage());
						logger.log(Level.SEVERE, errors.toString(), e);
					}
				}
			}
		} catch (Exception e) {
			StringBuilder errors = new StringBuilder("[Operação: ");
			errors.append(idOperacao);
			errors.append("] ");
			errors.append(e.getMessage());
			logger.log(Level.SEVERE, errors.toString(), e);
		}
	}
	
	private StringBuilder montaFiltroData(ConfiguracaoAcaoAutomaticaTO configuracao) throws Exception {
		StringBuilder filtro = new StringBuilder();
		
		// Monta comparação para o filtro e o valor a ser comparado
		if (configuracao.getTipoComparacao().equals(TIPO_COMPARACAO_ANTES)) {
			filtro.append(" GETDATE() <= DATEADD(hh, -").append(configuracao.getHorasComparacao()).append(", ");
		} else if (configuracao.getTipoComparacao().equals(TIPO_COMPARACAO_APOS)) {
			filtro.append(" GETDATE() >= DATEADD(hh, ").append(configuracao.getHorasComparacao()).append(", ");
		}
		
		// Monta data que servirá de filtro
		boolean dataFixaFiltro = false;
		for (DataFiltro filtroData : DataFiltro.values()) {
			if (configuracao.getDataFiltro().equals(filtroData.name())) {
				filtro.append(" ").append(filtroData.getColuna()).append(") ");
				dataFixaFiltro = true;
				break;
			}
		}
		if (!dataFixaFiltro) {
			String pattern = "[(]([^)]+)[)]";
			Pattern r = Pattern.compile(pattern);
			Matcher m = r.matcher(configuracao.getDataFiltro());
			if (m.find()) {
				filtro.append(" CasoDetalhe.").append(m.group(1)).append(") ");
			}
		}
		
		return filtro;
	}
	
}
