package br.com.callink.cad.repository;



public interface ISchedulerManager {

	/**
	 * @throws Exception
	 */
	void execute() throws Exception;

}
