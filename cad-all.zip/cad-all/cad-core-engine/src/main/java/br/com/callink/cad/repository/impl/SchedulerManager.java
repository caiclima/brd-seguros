package br.com.callink.cad.repository.impl;

import java.text.MessageFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.annotation.PostConstruct;
import javax.ejb.Lock;
import javax.ejb.LockType;
import javax.ejb.Schedule;
import javax.ejb.Singleton;
import javax.ejb.Startup;

import org.quartz.CronScheduleBuilder;
import org.quartz.CronTrigger;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.TriggerBuilder;
import org.quartz.TriggerKey;
import org.quartz.impl.StdSchedulerFactory;
import org.quartz.impl.matchers.GroupMatcher;

import br.com.callink.cad.dao.JobDAO;
import br.com.callink.cad.repository.ISchedulerManager;
import br.com.callink.cad.to.JobTO;

@Startup
@Singleton
@Lock(LockType.WRITE)
public class SchedulerManager implements ISchedulerManager {

	public final static int TEMPO_MAXIMO_JOB_ATIVA = 180; 
	
	private Logger logger = Logger.getLogger(SchedulerManager.class.getName());
	private Scheduler scheduler;
	private JobDAO dao;
	private String sarID;
	
	@PostConstruct
	private void init() throws Exception {
		if (scheduler == null) {
			scheduler = StdSchedulerFactory.getDefaultScheduler();
			scheduler.start();
		}
		if (dao == null) {
			dao = new JobDAO();
		}
		
		//Gerar um ID unico para o SAR que está sendo executado.
		Date date = new Date();
		Random rd = new Random();
		Integer integer = rd.nextInt(10000000);
		
		sarID = String.valueOf(date.getTime()) + integer;
	}

	@Override
	//Ao mudar o tempo do scheduler, verificar o tempo que valida se a job está executando com sucesso ou não.
	@Schedule(second = "*/28", minute = "*", hour = "*", persistent = false, info = "SchedulerManager")
	public void execute() {
		
		//logger.log(Level.INFO, "SAR ID: "+sarID);
		
		try {
			final List<JobTO> jobs = dao.findJobs();

			if (jobs != null && !jobs.isEmpty()) {
				int qtdJobsExistentes = 0;
				int qtdJobsNecessarias = 0;

				Date data = null;
				JobKey jobKey = null;
				JobDetail job = null;
				TriggerKey triggerKey = null;
				CronTrigger trigger = null;

				for (JobTO jobTO : jobs) {
					qtdJobsExistentes = countJobsByJobGroup(jobTO.getId().toString());

					if (jobTO.getFlagAtivo() == null || !jobTO.getFlagAtivo()) {
						if (qtdJobsExistentes > 0) {
							logger.info(MessageFormat.format("JOB [{0} - {1}] foi inativada.", jobTO.getId().toString(), jobTO.getNome()));

							for (int i = 0; i < qtdJobsExistentes; i++) {
								jobKey = new JobKey(String.valueOf(i), jobTO.getId().toString());

								if (scheduler.deleteJob(jobKey)) {
									logger.info(MessageFormat.format("Job {0} removida.", jobKey.getName()));
								}
							}
						}
					} else {
						if (jobTO.getQuantidadeJob() > qtdJobsExistentes) {
							logger.info(MessageFormat.format("Número de threds da JOB [{0} - {1}]: {2}.", jobTO.getId().toString(), jobTO.getNome(),
									jobTO.getQuantidadeJob()));

							qtdJobsNecessarias = jobTO.getQuantidadeJob() - qtdJobsExistentes;

							for (int i = 0; i < qtdJobsNecessarias; i++) {
								jobKey = new JobKey(String.valueOf(i + qtdJobsExistentes), jobTO.getId().toString());
								triggerKey = new TriggerKey(jobKey.getName(), jobKey.getGroup());
								
								try {
									job = buildJob(jobKey, Class.forName(jobTO.getClazz()));

								} catch (ClassNotFoundException e) {
									logger.log(Level.SEVERE, MessageFormat.format("Classe não encontrada: {0}", jobTO.getClazz()));
									break;
								}
								trigger = buildTrigger(triggerKey, jobTO.getCronExpression());

								data = scheduler.scheduleJob(job, trigger);

								logger.info(MessageFormat.format("Job {0} agendada para {1}. Identificador SAR: {2}", jobKey.getName(), data, sarID));
							}

						} else if (jobTO.getQuantidadeJob() < qtdJobsExistentes) {
							logger.info(MessageFormat.format("Número de threds da JOB [{0} - {1}]: {2}.", jobTO.getId().toString(), jobTO.getNome(),
									jobTO.getQuantidadeJob()));

							qtdJobsNecessarias = qtdJobsExistentes - jobTO.getQuantidadeJob();

							for (int i = 0; i < qtdJobsNecessarias; i++) {
								jobKey = new JobKey(String.valueOf(i), jobTO.getId().toString());

								if (scheduler.deleteJob(jobKey)) {
									logger.info(MessageFormat.format("Job {0} removida.", jobKey.getName()));
								}
							}
						} else {
							Integer index = qtdJobsExistentes - 1;
							
							for (int i = index; i >= 0; i--) {
								jobKey = new JobKey(String.valueOf(i), jobTO.getId().toString());
								triggerKey = new TriggerKey(jobKey.getName(), jobKey.getGroup());
								
								trigger = getTriggerByTrigger(triggerKey);

								if (trigger != null && !trigger.getCronExpression().equals(jobTO.getCronExpression())) {
									trigger = trigger.getTriggerBuilder().withSchedule(CronScheduleBuilder.cronSchedule(jobTO.getCronExpression())).build();
									data = scheduler.rescheduleJob(trigger.getKey(), trigger);
									logger.info(MessageFormat.format("Job {0} reagendada para {1}.  Identificador SAR: {2}", jobKey.getName(), data, sarID));
								}
							}
						}
					}
				}
				

			} else {
				scheduler.clear();
				logger.info("Nenhuma JOB encontrada. Caso alguma tenha sido agendada anteriormente será removida após a execução!");
			}

			Integer idOperacao = null;
			Integer idJob = null;
			Integer executando = 0;
			try {
				idOperacao = null;
				idJob = null;
				executando = 0;
				List<JobExecutionContext> executionJobs = scheduler.getCurrentlyExecutingJobs();
				String ids = "";
				/**
				 * Atualizar a data de todas as jobs que pertence a esse SAR e que esteja em execução.  
				 */
				for (JobExecutionContext execJob:executionJobs) {
					idOperacao = (Integer)execJob.get("operacaoExecucao");
					executando = (Integer)execJob.get("executando");
					idJob = Integer.valueOf(execJob.getJobDetail().getKey().getGroup());
					
					if (idOperacao != null && idJob != null && executando == 1) {
						if (ids.isEmpty()) {
							ids = "( id_job = "+idJob+" and id_operacao = " + idOperacao +" ) " ;
						} else {
							ids = ids + " or ( id_job = "+idJob+" and id_operacao = " + idOperacao +" ) " ;
						}
					}
				}
				
				if (!ids.isEmpty()) {
					dao.updateControleJob(ids, sarID);
				}
				
				/**
				* update em todas as jobs de qualquer sar_id que estejam com o flag executando com mais que o parametro de tempo...
				* */
				dao.updateJobsComErro(TEMPO_MAXIMO_JOB_ATIVA);
				dao.updateJobsComErroSemControle(TEMPO_MAXIMO_JOB_ATIVA);
			} catch (Exception e) {
				logger.log(Level.SEVERE, "Erro ao controlar jobs em execução. Operacao: "+idOperacao+" - Job: "+idJob, e);
			} 
		} catch (Exception e) {
			logger.log(Level.SEVERE, e.getMessage());
		}
	}

	private CronTrigger getTriggerByTrigger(TriggerKey triggerKey) throws SchedulerException {
		return (CronTrigger) scheduler.getTrigger(triggerKey);
	}

	private int countJobsByJobGroup(String jobGroup) throws SchedulerException {
		Set<JobKey> jobKeys = scheduler.getJobKeys(GroupMatcher.jobGroupEquals(jobGroup));
		if (jobKeys != null && !jobKeys.isEmpty()) {
			return jobKeys.size();
		}
		return 0;
	}

	private CronTrigger buildTrigger(TriggerKey triggerKey, String cronExpression) {
		return TriggerBuilder.newTrigger().withIdentity(triggerKey).withSchedule(CronScheduleBuilder.cronSchedule(cronExpression)).build();
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private JobDetail buildJob(JobKey jobKey, Class jobClass) {
		return JobBuilder.newJob(jobClass).withIdentity(jobKey).withDescription(sarID).build();
	}
}

