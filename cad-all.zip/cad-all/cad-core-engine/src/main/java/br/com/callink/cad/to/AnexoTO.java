package br.com.callink.cad.to;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

/**
 * 
 * @author swb_brunocamargo
 *
 */
public class AnexoTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer idAnexo;
	private String nomeReal;
	private String nomeFake;
	private String diretorio;
	private Date dataCriacao;
	private GrupoAnexoTO grupoAnexo;
	
	private transient byte [] dados;
	private transient int tamanho;
	
	public AnexoTO() {
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((idAnexo == null) ? 0 : idAnexo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof AnexoTO)) {
			return false;
		}
		AnexoTO other = (AnexoTO) obj;
		if (idAnexo == null) {
			if (other.idAnexo != null) {
				return false;
			}
		} else if (!idAnexo.equals(other.idAnexo)) {
			return false;
		}
		return true;
	}

	public Integer getPK() {
		return idAnexo;
	}

	public void setPK(Integer pk) {
		idAnexo = pk;
	}

	public final Integer getIdAnexo() {
		return idAnexo;
	}

	public final void setIdAnexo(Integer idAnexo) {
		this.idAnexo = idAnexo;
	}

	public final String getNomeReal() {
		return nomeReal;
	}

	public final void setNomeReal(String nomeReal) {
		this.nomeReal = nomeReal;
	}

	public final String getNomeFake() {
		return nomeFake;
	}

	public final void setNomeFake(String nomeFake) {
		this.nomeFake = nomeFake;
	}

	public final String getDiretorio() {
		return diretorio;
	}

	public final void setDiretorio(String diretorio) {
		this.diretorio = diretorio;
	}

	public final Date getDataCriacao() {
		return dataCriacao == null ? null : new Date(dataCriacao.getTime());
	}

	public final void setDataCriacao(Date dataCriacao) {
		this.dataCriacao = dataCriacao == null ? null : new Date(dataCriacao.getTime());
	}

	public final GrupoAnexoTO getGrupoAnexo() {
		return grupoAnexo;
	}

	public final void setGrupoAnexo(GrupoAnexoTO grupoAnexo) {
		this.grupoAnexo = grupoAnexo;
	}

	public final byte[] getDados() {
		return dados;
	}

	public final void setDados(byte[] dados) {
		this.dados = dados.clone();
	}

	public final int getTamanho() {
		return tamanho;
	}

	public final void setTamanho(int tamanho) {
		this.tamanho = tamanho;
	}
	
	public static String getSqlCamposAnexo() {
        return new StringBuilder()
                .append(" \nAnexo.ID_ANEXO AS 'Anexo.ID_ANEXO', ")
                .append(" \nAnexo.NOME_REAL AS 'Anexo.NOME_REAL', ")
                .append(" \nAnexo.NOME_FAKE AS 'Anexo.NOME_FAKE', ")
                .append(" \nAnexo.DIRETORIO AS 'Anexo.DIRETORIO', ")
                .append(" \nAnexo.DATA_CRIACAO AS 'Anexo.DATA_CRIACAO', ")
                .append(" \nAnexo.ID_GRUPO_ANEXO AS 'Anexo.ID_GRUPO_ANEXO' ").toString();
    }

    public static String getSqlFromAnexo() {
        return " TB_ANEXO  AS Anexo with(nolock) ";
    }
    
    public static AnexoTO getAnexoByResultSet(ResultSet rs) {
        try {
        	
        	if(rs.getInt("Anexo.ID_ANEXO") == 0) {
        		return null;
        	}
        	
        	AnexoTO anexo = new AnexoTO();
        	anexo.setIdAnexo(rs.getInt("Anexo.ID_ANEXO"));
        	anexo.setNomeReal(rs.getString("Anexo.NOME_REAL"));
        	anexo.setNomeFake(rs.getString("Anexo.NOME_FAKE"));
        	anexo.setDiretorio(rs.getString("Anexo.DIRETORIO"));
        	anexo.setDataCriacao(rs.getTimestamp("Anexo.DATA_CRIACAO"));
        	anexo.setGrupoAnexo(rs.getInt("Anexo.ID_GRUPO_ANEXO") == 0 ? null : new GrupoAnexoTO(rs.getInt("Anexo.ID_GRUPO_ANEXO")));
            return anexo;
        } catch (SQLException ex) {
            throw new IllegalArgumentException(
                    "Erro ao montar objeto a partir do ResultSet", ex);
        }
    }
	
}
