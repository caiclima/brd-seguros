package br.com.callink.cad.to;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

/**
*
* @author swb_brunocamargo
* 
* */
public class AssociaOperacaoJobTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer idAssociaOperacaoJob;
	private Integer operacao;
	private Integer job;
	private Boolean flagAtivo;
	private Date dataStartExec;
	private Date dataFimExec;
	private Boolean flagExecutando;
	private String executor;
	private Boolean flagNotificaFalha;
	private String sarID;
	private Integer minutosExecucao;
  private Date dataControleSAR;
	
	private JobTO jobTO;
	
	public Integer getPK() {
		return idAssociaOperacaoJob;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((idAssociaOperacaoJob == null) ? 0 : idAssociaOperacaoJob
						.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof AssociaOperacaoJobTO)) {
			return false;
		}
		AssociaOperacaoJobTO other = (AssociaOperacaoJobTO) obj;
		if (idAssociaOperacaoJob == null) {
			if (other.idAssociaOperacaoJob != null) {
				return false;
			}
		} else if (!idAssociaOperacaoJob.equals(other.idAssociaOperacaoJob)) {
			return false;
		}
		return true;
	}

	public static String getSqlCamposAssociaOperacaoJob() {
		return new StringBuilder()
				.append(" \nAssociaOperacaoJob.id_associa_operacao_job AS 'AssociaOperacaoJob.id_associa_operacao_job',")
				.append(" \nAssociaOperacaoJob.id_operacao AS 'AssociaOperacaoJob.id_operacao',")
				.append(" \nAssociaOperacaoJob.id_job AS 'AssociaOperacaoJob.id_job',")
				.append(" \nAssociaOperacaoJob.flag_ativo AS 'AssociaOperacaoJob.flag_ativo',")
				.append(" \nAssociaOperacaoJob.data_start_exec AS 'AssociaOperacaoJob.data_start_exec',")
				.append(" \nAssociaOperacaoJob.data_fim_exec AS 'AssociaOperacaoJob.data_fim_exec',")
                .append(" \nAssociaOperacaoJob.flag_executando AS 'AssociaOperacaoJob.flag_executando',")
                .append(" \nAssociaOperacaoJob.executor AS 'AssociaOperacaoJob.executor',")
                .append(" \nAssociaOperacaoJob.flag_notifica_falha AS 'AssociaOperacaoJob.flag_notifica_falha',")
                .append(" \nAssociaOperacaoJob.sar_id AS 'AssociaOperacaoJob.sar_id',")
                .append(" \nAssociaOperacaoJob.data_controle_sar AS 'AssociaOperacaoJob.data_controle_sar',")
                .append(" \nAssociaOperacaoJob.minutos_execucao AS 'AssociaOperacaoJob.minutos_execucao'").toString();

	}

	public static String getSqlFromAssociaOperacaoJob() {
		return " TB_ASSOCIA_OPERACAO_JOB As AssociaOperacaoJob with(nolock) ";
	}

	public static AssociaOperacaoJobTO getAssociaOperacaoJobByResultSet(ResultSet resultSet) {
		try {
			if (resultSet.getInt("AssociaOperacaoJob.id_associa_operacao_job") == 0) {
				return null;
			}

			AssociaOperacaoJobTO to = new AssociaOperacaoJobTO();
			to.setIdAssociaOperacaoJob((Integer) resultSet.getObject("AssociaOperacaoJob.id_associa_operacao_job"));
			to.setOperacao((Integer) resultSet.getObject("AssociaOperacaoJob.id_operacao"));
			to.setJob((Integer) resultSet.getObject("AssociaOperacaoJob.id_job"));
			to.setFlagAtivo((Boolean) resultSet.getObject("AssociaOperacaoJob.flag_ativo"));
			to.setDataStartExec((Date) resultSet.getObject("AssociaOperacaoJob.data_start_exec"));
			to.setDataFimExec((Date) resultSet.getObject("AssociaOperacaoJob.data_fim_exec"));
			to.setFlagExecutando((Boolean) resultSet.getObject("AssociaOperacaoJob.flag_executando"));
			to.setExecutor((String) resultSet.getObject("AssociaOperacaoJob.executor"));
			to.setFlagNotificaFalha((Boolean) resultSet.getObject("AssociaOperacaoJob.flag_notifica_falha"));
			to.setSarID((String) resultSet.getObject("AssociaOperacaoJob.sar_id"));
			to.setDataFimExec((Date) resultSet.getObject("AssociaOperacaoJob.data_controle_sar"));
      to.setMinutosExecucao((Integer) resultSet.getObject("AssociaOperacaoJob.minutos_execucao"));
			return to;

		} catch (SQLException ex) {
			throw new IllegalArgumentException("Erro ao montar objeto a partir do ResultSet", ex);
		}
	}

	/**
	 * @return the idAssociaOperacaoJob
	 */
	public final Integer getIdAssociaOperacaoJob() {
		return idAssociaOperacaoJob;
	}

	/**
	 * @param idAssociaOperacaoJob the idAssociaOperacaoJob to set
	 */
	public final void setIdAssociaOperacaoJob(Integer idAssociaOperacaoJob) {
		this.idAssociaOperacaoJob = idAssociaOperacaoJob;
	}


	/**
	 * @return the operacao
	 */
	public final Integer getOperacao() {
		return operacao;
	}

	/**
	 * @param operacao the operacao to set
	 */
	public final void setOperacao(Integer operacao) {
		this.operacao = operacao;
	}

	/**
	 * @return the jobTO
	 */
	public final Integer getJob() {
		return job;
	}

	/**
	 * @param jobTO the jobTO to set
	 */
	public final void setJob(Integer job) {
		this.job = job;
	}

	/**
	 * @return the flagAtivo
	 */
	public final Boolean getFlagAtivo() {
		return flagAtivo;
	}

	/**
	 * @param flagAtivo the flagAtivo to set
	 */
	public final void setFlagAtivo(Boolean flagAtivo) {
		this.flagAtivo = flagAtivo;
	}

	/**
	 * @return the dataStartExec
	 */
	public final Date getDataStartExec() {
		return dataStartExec;
	}

	/**
	 * @param dataStartExec the dataStartExec to set
	 */
	public final void setDataStartExec(Date dataStartExec) {
		this.dataStartExec = dataStartExec;
	}

	/**
	 * @return the dataFimExec
	 */
	public final Date getDataFimExec() {
		return dataFimExec;
	}

	/**
	 * @param dataFimExec the dataFimExec to set
	 */
	public final void setDataFimExec(Date dataFimExec) {
		this.dataFimExec = dataFimExec;
	}

	/**
	 * @return the flagExecutando
	 */
	public final Boolean getFlagExecutando() {
		return flagExecutando;
	}

	/**
	 * @param flagExecutando the flagExecutando to set
	 */
	public final void setFlagExecutando(Boolean flagExecutando) {
		this.flagExecutando = flagExecutando;
	}

	/**
	 * @return the executor
	 */
	public final String getExecutor() {
		return executor;
	}

	/**
	 * @param executor the executor to set
	 */
	public final void setExecutor(String executor) {
		this.executor = executor;
	}

	/**
	 * @return the flagNotificaFalha
	 */
	public final Boolean getFlagNotificaFalha() {
		return flagNotificaFalha;
	}

	/**
	 * @param flagNotificaFalha the flagNotificaFalha to set
	 */
	public final void setFlagNotificaFalha(Boolean flagNotificaFalha) {
		this.flagNotificaFalha = flagNotificaFalha;
	}

	/**
	 * @return the sarID
	 */
	public final String getSarID() {
		return sarID;
	}

	/**
	 * @param sarID the sarID to set
	 */
	public final void setSarID(String sarID) {
		this.sarID = sarID;
	}

	/**
	 * @return the dataControleSAR
	 */
	public final Date getDataControleSAR() {
		return dataControleSAR;
	}

	/**
	 * @param dataControleSAR the dataControleSAR to set
	 */
	public final void setDataControleSAR(Date dataControleSAR) {
		this.dataControleSAR = dataControleSAR;
	}

	public Integer getMinutosExecucao() {
		return minutosExecucao;
	}

	public void setMinutosExecucao(Integer minutosExecucao) {
		this.minutosExecucao = minutosExecucao;
	}

	public JobTO getJobTO() {
		return jobTO;
	}

	public void setJobTO(JobTO jobTO) {
		this.jobTO = jobTO;
	}
	
}
