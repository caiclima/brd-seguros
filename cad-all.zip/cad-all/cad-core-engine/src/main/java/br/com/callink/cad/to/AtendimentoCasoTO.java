package br.com.callink.cad.to;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

/**
*
* @author swb_brunocamargo
* 
* */
public class AtendimentoCasoTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer idAtendimentoCaso;
	private Date dataMarcacao;
	private transient Boolean flgInicio;
	private Date dataInicio;
	private Date dataFim;
	private Integer idUsuario;
	private Integer idCaso;
	private Integer idStatus;
    private Integer idConfiguracaoFila;
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((idAtendimentoCaso == null) ? 0 : idAtendimentoCaso
						.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof AtendimentoCasoTO)) {
			return false;
		}
		AtendimentoCasoTO other = (AtendimentoCasoTO) obj;
		if (idAtendimentoCaso == null) {
			if (other.idAtendimentoCaso != null) {
				return false;
			}
		} else if (!idAtendimentoCaso.equals(other.idAtendimentoCaso)) {
			return false;
		}
		return true;
	}

	public Integer getPK() {
		return idAtendimentoCaso;
	}

	public void setPK(Integer pk) {
		this.idAtendimentoCaso = pk;
	}

	public final Integer getIdAtendimentoCaso() {
		return idAtendimentoCaso;
	}

	public final void setIdAtendimentoCaso(Integer idAtendimentoCaso) {
		this.idAtendimentoCaso = idAtendimentoCaso;
	}

	public final Date getDataMarcacao() {
		return dataMarcacao != null ? new Date(dataMarcacao.getTime()) : null;
	}

	public final void setDataMarcacao(Date dataMarcacao) {
		this.dataMarcacao = dataMarcacao != null ? new Date(dataMarcacao.getTime()) : null;
	}

	public final Boolean getFlgInicio() {
		if (flgInicio == null) {
			flgInicio = this.dataFim == null;
		}
		return flgInicio;
	}

	public final void setFlgInicio(Boolean flgInicio) {
		this.flgInicio = flgInicio;
	}

	public final Date getDataInicio() {
		return dataInicio == null ? null : new Date(dataInicio.getTime());
	}

	public final void setDataInicio(Date dataInicio) {
		this.dataInicio = dataInicio == null ? null : new Date(dataInicio.getTime());
	}

	public Date getDataFim() {
		return dataFim == null ? null : new Date(dataFim.getTime());
	}

	public void setDataFim(Date dataFim) {
		this.dataFim = dataFim == null ? null : new Date(dataFim.getTime());
	}

	public Integer getIdUsuario() {
		return idUsuario;
	}

	public void setIdUsuario(Integer idUsuario) {
		this.idUsuario = idUsuario;
	}

	public Integer getIdCaso() {
		return idCaso;
	}

	public void setIdCaso(Integer idCaso) {
		this.idCaso = idCaso;
	}

	public Integer getIdStatus() {
		return idStatus;
	}

	public void setIdStatus(Integer idStatus) {
		this.idStatus = idStatus;
	}

	public Integer getIdConfiguracaoFila() {
		return idConfiguracaoFila;
	}

	public void setIdConfiguracaoFila(Integer idConfiguracaoFila) {
		this.idConfiguracaoFila = idConfiguracaoFila;
	}

	public static String getSqlCamposAtendimentoCaso() {
		return new StringBuilder()
				.append(" \nAtendimentoCaso.ID_ATENDIMENTO_CASO AS 'AtendimentoCaso.ID_ATENDIMENTO_CASO',")
				.append(" \nAtendimentoCaso.DATA_MARCACAO AS 'AtendimentoCaso.DATA_MARCACAO',")
				.append(" \nAtendimentoCaso.DATA_INICIO AS 'AtendimentoCaso.DATA_INICIO',")
				.append(" \nAtendimentoCaso.DATA_FIM AS 'AtendimentoCaso.DATA_FIM',")
				.append(" \nAtendimentoCaso.ID_USUARIO AS 'AtendimentoCaso.ID_USUARIO',")
				.append(" \nAtendimentoCaso.ID_CASO AS 'AtendimentoCaso.ID_CASO',")
                .append(" \nAtendimentoCaso.ID_STATUS AS 'AtendimentoCaso.ID_STATUS',")
                .append(" \nAtendimentoCaso.ID_CONFIGURACAO_FILA AS 'AtendimentoCaso.ID_CONFIGURACAO_FILA'").toString();

	}

	public static String getSqlFromAtendimentoCaso() {
		return " TB_ATENDIMENTO_CASO As AtendimentoCaso with(nolock) ";
	}

	public static AtendimentoCasoTO getAtendimentoCasoByResultSet(ResultSet resultSet) {
		try {
			
			if(resultSet.getInt("AtendimentoCaso.ID_ATENDIMENTO_CASO") == 0) {
        		return null;
        	}
			
			AtendimentoCasoTO atendimentoCaso = new AtendimentoCasoTO();

			atendimentoCaso.setIdAtendimentoCaso(resultSet.getInt("AtendimentoCaso.ID_ATENDIMENTO_CASO"));
			atendimentoCaso.setDataMarcacao(resultSet.getTimestamp("AtendimentoCaso.DATA_MARCACAO"));
			atendimentoCaso.setDataInicio(resultSet.getTimestamp("AtendimentoCaso.DATA_INICIO"));
			atendimentoCaso.setDataFim(resultSet.getTimestamp("AtendimentoCaso.DATA_FIM"));
			atendimentoCaso.setIdUsuario(resultSet.getInt("AtendimentoCaso.ID_USUARIO") == 0 ? null : resultSet.getInt("AtendimentoCaso.ID_USUARIO"));
			atendimentoCaso.setIdCaso(resultSet.getInt("AtendimentoCaso.ID_CASO") == 0 ? null : resultSet.getInt("AtendimentoCaso.ID_CASO"));
			atendimentoCaso.setIdStatus(resultSet.getInt("AtendimentoCaso.ID_STATUS") == 0 ? null : resultSet.getInt("AtendimentoCaso.ID_STATUS"));
			atendimentoCaso.setIdConfiguracaoFila(resultSet.getInt("AtendimentoCaso.ID_CONFIGURACAO_FILA") == 0 ? null : resultSet.getInt("AtendimentoCaso.ID_CONFIGURACAO_FILA"));
            
			return atendimentoCaso;
		} catch (SQLException e) {
			throw new IllegalArgumentException("Erro ao montar objeto a partir do ResultSet", e);
		}
	}
	
}
