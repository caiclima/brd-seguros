package br.com.callink.cad.to;

import java.io.Serializable;
import java.util.Date;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

public class BufferCasoTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Queue<Integer> casoQueue;
	private Date dataUltimoCaso;

	public BufferCasoTO() {
		setCasoQueue(new ConcurrentLinkedQueue<Integer>());
	}

	/**
	 * Insere o ID do caso.
	 * 
	 * @param caso
	 */
	public void add(Integer caso) {
		if (!getCasoQueue().contains(caso)) {
			getCasoQueue().add(caso);
		}
	}

	/**
	 * Retorna o ID do Caso. Se não existir nenum caso na fila retorna null.
	 * 
	 * @return
	 */
	public Integer poll() {
		Integer idCaso = getCasoQueue().poll();
		if (idCaso != null) {
			dataUltimoCaso = new Date();
		}
		return idCaso;
	}

	public Date getDataUltimoCaso() {
		return dataUltimoCaso != null ? new Date(dataUltimoCaso.getTime()) : null;
	}

	public void setCasoQueue(Queue<Integer> casoQueue) {
		this.casoQueue = casoQueue;
	}

	public Queue<Integer> getCasoQueue() {
		return casoQueue;
	}

}
