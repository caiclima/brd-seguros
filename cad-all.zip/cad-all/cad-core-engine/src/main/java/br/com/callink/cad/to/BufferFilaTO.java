package br.com.callink.cad.to;

import java.io.Serializable;
import java.util.Date;


/**
 * 
 * @author Bruno Martins
 *
 */
public class BufferFilaTO implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Integer idCasoFilaAtendimento;
	private Integer idCaso;
	private Integer idFila;
	private Boolean flagEntregue;
	private Integer idUsuario;
	private Date dataEntregue;
	private Integer quantidade;

	public BufferFilaTO() {

	}

	public BufferFilaTO(Integer idFila, Integer quantidade) {
		this.idFila = idFila;
		this.quantidade = quantidade;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((idFila == null) ? 0 : idFila
						.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof BufferFilaTO)) {
			return false;
		}
		BufferFilaTO other = (BufferFilaTO) obj;
		if (idFila == null) {
			if (other.idFila != null) {
				return false;
			}
		} else if (!idFila.equals(other.idFila)) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return idFila.toString();
	}

	public Integer getPK() {
		return idCasoFilaAtendimento;
	}

	public void setPK(Integer pk) {
		this.idCasoFilaAtendimento = pk;
	}

	public static String getSqlCamposConfiguracaoFila() {

        return new StringBuilder()
                .append(" \nFilaAtendimento.ID_CASO_FILA_ATENDIMENTO AS 'FilaAtendimento.ID_CASO_FILA_ATENDIMENTO', ")
                .append(" \nFilaAtendimento.ID_CASO AS 'FilaAtendimento.ID_CASO', ")
                .append(" \nFilaAtendimento.ID_FILA AS 'FilaAtendimento.ID_FILA', ")
                .append(" \nFilaAtendimento.FLAG_ENTREGUE AS 'FilaAtendimento.FLAG_ENTREGUE', ")
                .append(" \nFilaAtendimento.ID_USUARIO AS 'FilaAtendimento.ID_USUARIO', ")
                .append(" \nFilaAtendimento.DATA_ENTREGUE AS 'FilaAtendimento.DATA_ENTREGUE', ")
                .append(" \nFilaAtendimento.ID_OPERACAO AS 'FilaAtendimento.ID_OPERACAO', ")
                .toString();
    }

    public static String getSqlFromConfiguracaoFila() {
        return " tb_caso_fila_atendimento AS FilaAtendimento with(nolock) ";
    }

	/**
	 * @return the idCasoFilaAtendimento
	 */
	public Integer getIdCasoFilaAtendimento() {
		return idCasoFilaAtendimento;
	}

	/**
	 * @param idCasoFilaAtendimento the idCasoFilaAtendimento to set
	 */
	public void setIdCasoFilaAtendimento(Integer idCasoFilaAtendimento) {
		this.idCasoFilaAtendimento = idCasoFilaAtendimento;
	}

	/**
	 * @return the idCaso
	 */
	public Integer getIdCaso() {
		return idCaso;
	}

	/**
	 * @param idCaso the idCaso to set
	 */
	public void setIdCaso(Integer idCaso) {
		this.idCaso = idCaso;
	}

	/**
	 * @return the idFila
	 */
	public Integer getIdFila() {
		return idFila;
	}

	/**
	 * @param idFila the idFila to set
	 */
	public void setIdFila(Integer idFila) {
		this.idFila = idFila;
	}

	/**
	 * @return the flagEntregue
	 */
	public Boolean getFlagEntregue() {
		return flagEntregue;
	}

	/**
	 * @param flagEntregue the flagEntregue to set
	 */
	public void setFlagEntregue(Boolean flagEntregue) {
		this.flagEntregue = flagEntregue;
	}

	/**
	 * @return the idUsuario
	 */
	public Integer getIdUsuario() {
		return idUsuario;
	}

	/**
	 * @param idUsuario the idUsuario to set
	 */
	public void setIdUsuario(Integer idUsuario) {
		this.idUsuario = idUsuario;
	}

	/**
	 * @return the dataEntregue
	 */
	public Date getDataEntregue() {
		return dataEntregue;
	}

	/**
	 * @param dataEntregue the dataEntregue to set
	 */
	public void setDataEntregue(Date dataEntregue) {
		this.dataEntregue = dataEntregue;
	}

	/**
	 * @return the quantidade
	 */
	public Integer getQuantidade() {
		return quantidade;
	}

	/**
	 * @param quantidade the quantidade to set
	 */
	public void setQuantidade(Integer quantidade) {
		this.quantidade = quantidade;
	}

}
