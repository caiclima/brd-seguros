package br.com.callink.cad.to;

import java.io.Serializable;

/**
 * 
 * @author swb_halan
 * 
 */
public class CabMetaFullTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer idCabMeta;
	private Double mediaPonderadaFinal;
	private Integer idUsuario;
	private String imageGFinal;
	private Integer idConfiguracaoFila;
	private Double tempoTotalEquipe;
	private Integer casosFechados;
	private Double uphEquipe;
	private String nomeConfiguracaoFila;
	private Double goalFinal;
	private String imagemGoalFinal;
	private Double indiceGoal;
	private String login;
	private Double meta;
	private Double uph;
	private Boolean flagTotalizador;
	private Integer idOperacao;

	public CabMetaFullTO() {
	}

	public CabMetaFullTO(Integer idCabMeta) {
		super();
		this.idCabMeta = idCabMeta;
	}

	public Integer getIdCabMeta() {
		return idCabMeta;
	}

	public void setIdCabMeta(Integer idCabMeta) {
		this.idCabMeta = idCabMeta;
	}

	public Double getMediaPonderadaFinal() {
		return mediaPonderadaFinal;
	}

	public void setMediaPonderadaFinal(Double mediaPonderadaFinal) {
		this.mediaPonderadaFinal = mediaPonderadaFinal;
	}

	public Integer getIdUsuario() {
		return idUsuario;
	}

	public void setIdUsuario(Integer idUsuario) {
		this.idUsuario = idUsuario;
	}

	public String getImageGFinal() {
		return imageGFinal;
	}

	public void setImageGFinal(String imageGFinal) {
		this.imageGFinal = imageGFinal;
	}

	public Integer getIdConfiguracaoFila() {
		return idConfiguracaoFila;
	}

	public void setIdConfiguracaoFila(Integer idConfiguracaoFila) {
		this.idConfiguracaoFila = idConfiguracaoFila;
	}

	public Double getTempoTotalEquipe() {
		return tempoTotalEquipe;
	}

	public void setTempoTotalEquipe(Double tempoTotalEquipe) {
		this.tempoTotalEquipe = tempoTotalEquipe;
	}

	public Integer getCasosFechados() {
		return casosFechados;
	}

	public void setCasosFechados(Integer casosFechados) {
		this.casosFechados = casosFechados;
	}

	public Double getUphEquipe() {
		return uphEquipe;
	}

	public void setUphEquipe(Double uphEquipe) {
		this.uphEquipe = uphEquipe;
	}

	public String getNomeConfiguracaoFila() {
		return nomeConfiguracaoFila;
	}

	public void setNomeConfiguracaoFila(String nomeConfiguracaoFila) {
		this.nomeConfiguracaoFila = nomeConfiguracaoFila;
	}

	public Double getGoalFinal() {
		return goalFinal;
	}

	public void setGoalFinal(Double goalFinal) {
		this.goalFinal = goalFinal;
	}

	public String getImagemGoalFinal() {
		return imagemGoalFinal;
	}

	public void setImagemGoalFinal(String imagemGoalFinal) {
		this.imagemGoalFinal = imagemGoalFinal;
	}

	public Double getIndiceGoal() {
		return indiceGoal;
	}

	public void setIndiceGoal(Double indiceGoal) {
		this.indiceGoal = indiceGoal;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public Double getMeta() {
		return meta;
	}

	public void setMeta(Double meta) {
		this.meta = meta;
	}

	public Double getUph() {
		return uph;
	}

	public void setUph(Double uph) {
		this.uph = uph;
	}

	public Boolean getFlagTotalizador() {
		return flagTotalizador;
	}

	public void setFlagTotalizador(Boolean flagTotalizador) {
		this.flagTotalizador = flagTotalizador;
	}

	public Integer getIdOperacao() {
		return idOperacao;
	}

	public void setIdOperacao(Integer idOperacao) {
		this.idOperacao = idOperacao;
	}

}
