/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.to;

import java.io.Serializable;
import java.util.List;


/**
 *
 * @author bruno
 */
public class CabMetaTO implements Cloneable, Serializable {
    
	private static final long serialVersionUID = 1L;
	
	private Integer idUsuario;
    private Double gMediaPonderadaFinal;
    private String imageGFinal;
    private List<MetaFilaTO> listaMetaFilaTO;

    public Integer getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(Integer idUsuario) {
        this.idUsuario = idUsuario;
    }

    public Double getgMediaPonderadaFinal() {
        return gMediaPonderadaFinal;
    }

    public void setgMediaPonderadaFinal(Double gMediaPonderadaFinal) {
        this.gMediaPonderadaFinal = gMediaPonderadaFinal;
    }

    public String getImageGFinal() {
        return imageGFinal;
    }

    public void setImageGFinal(String imageGFinal) {
        this.imageGFinal = imageGFinal;
    }

    public List<MetaFilaTO> getListaMetaFilaTO() {
        return listaMetaFilaTO;
    }

    public void setListaMetaFilaTO(List<MetaFilaTO> listaMetaFilaTO) {
        this.listaMetaFilaTO = listaMetaFilaTO;
    }
    
    
    
}
