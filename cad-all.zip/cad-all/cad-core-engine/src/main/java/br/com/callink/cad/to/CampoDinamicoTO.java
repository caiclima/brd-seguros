package br.com.callink.cad.to;

import java.io.Serializable;
import java.sql.ResultSet;
import java.util.Date;

public class CampoDinamicoTO implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Integer idCampoDinamico;
	private Date dataCriacao;
	private TipoCampoDinamico tipoCampo;
	private Integer sizeCampo;
	private String nomeColuna;
	private String label;
	private String chave;
	private Boolean flagAtivo;
	private Boolean flagExportarValorReal;
	private String separadorValor;
	private String separadorCampo;
	private String mascara;
	private Boolean flagMascaraTodosCaracteres;
	private Boolean flagDateTime;
	private String nome;
	
	private transient Object valor;
	
	public CampoDinamicoTO(CampoDinamicoTO campoDinamicoTO) {
		super();
		this.idCampoDinamico = campoDinamicoTO.getIdCampoDinamico();
		this.dataCriacao = campoDinamicoTO.getDataCriacao();
		this.tipoCampo = campoDinamicoTO.getTipoCampo();
		this.sizeCampo = campoDinamicoTO.getSizeCampo();
		this.nomeColuna = campoDinamicoTO.getNomeColuna();
		this.label = campoDinamicoTO.getLabel();
		this.chave = campoDinamicoTO.getChave();
		this.flagAtivo = campoDinamicoTO.getFlagAtivo();
		this.separadorValor = campoDinamicoTO.getSeparadorValor();
		this.separadorCampo = campoDinamicoTO.getSeparadorCampo();
		this.valor = campoDinamicoTO.getValor();
		this.flagExportarValorReal = campoDinamicoTO.getFlagExportarValorReal();
		this.mascara = campoDinamicoTO.getMascara();
		this.flagMascaraTodosCaracteres = campoDinamicoTO.getFlagMascaraTodosCaracteres();
		this.flagDateTime = campoDinamicoTO.getFlagDateTime();
		this.nome = campoDinamicoTO.getNome();
	}
	
	public CampoDinamicoTO() {
		
	}

	public Integer getIdCampoDinamico() {
		return idCampoDinamico;
	}
	
	public void setIdCampoDinamico(Integer idCampoDinamico) {
		this.idCampoDinamico = idCampoDinamico;
	}

	public Date getDataCriacao() {
		return dataCriacao;
	}
	
	public void setDataCriacao(Date dataCriacao) {
		this.dataCriacao = dataCriacao;
	}

	public TipoCampoDinamico getTipoCampo() {
		return tipoCampo;
	}
	
	public void setTipoCampo(TipoCampoDinamico tipoCampo) {
		this.tipoCampo = tipoCampo;
	}

	public Integer getSizeCampo() {
		return sizeCampo;
	}
	
	public void setSizeCampo(Integer sizeCampo) {
		this.sizeCampo = sizeCampo;
	}

	public String getNomeColuna() {
		return nomeColuna;
	}
	
	public void setNomeColuna(String nomeColuna) {
		this.nomeColuna = nomeColuna;
	}

	public String getLabel() {
		return label;
	}
	
	public void setLabel(String label) {
		this.label = label;
	}
	
	public String getChave() {
		return chave;
	}

	public void setChave(String chave) {
		this.chave = chave;
	}
	
	public Boolean getFlagAtivo() {
		return flagAtivo;
	}

	public void setFlagAtivo(Boolean flagAtivo) {
		this.flagAtivo = flagAtivo;
	}

	public Object getValor() {
		return valor;
	}

	public void setValor(Object valor) {
		this.valor = valor;
	}
	
	public String getSeparadorValor() {
		return separadorValor;
	}

	public void setSeparadorValor(String separadorValor) {
		this.separadorValor = separadorValor;
	}
	
	public String getSeparadorCampo() {
		return separadorCampo;
	}
	
	public void setSeparadorCampo(String separadorCampo) {
		this.separadorCampo = separadorCampo;
	}
	
	public Boolean getFlagExportarValorReal() {
		return flagExportarValorReal;
	}

	public void setFlagExportarValorReal(Boolean flagExportarValorReal) {
		this.flagExportarValorReal = flagExportarValorReal;
	}
	
	public String getMascara() {
		return mascara;
	}
	
	public void setMascara(String mascara) {
		this.mascara = mascara;
	}

	public Boolean getFlagMascaraTodosCaracteres() {
		return flagMascaraTodosCaracteres;
	}

	public void setFlagMascaraTodosCaracteres(Boolean flagMascaraTodosCaracteres) {
		this.flagMascaraTodosCaracteres = flagMascaraTodosCaracteres;
	}

	public Boolean getFlagDateTime() {
		return flagDateTime;
	}

	public void setFlagDateTime(Boolean flagDateTime) {
		this.flagDateTime = flagDateTime;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public static CampoDinamicoTO getCampoTOByResultSet(ResultSet resultSet) throws Exception {
		if(resultSet == null){
			return null;
		}
		
		CampoDinamicoTO to = new CampoDinamicoTO();
		
		to.setIdCampoDinamico(resultSet.getInt("id_campo_dinamico"));
		to.setNomeColuna(resultSet.getString("nome_coluna"));
		to.setLabel(resultSet.getString("nome"));
		
		return to;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((idCampoDinamico == null) ? 0 : idCampoDinamico.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CampoDinamicoTO other = (CampoDinamicoTO) obj;
		if (idCampoDinamico == null) {
			if (other.idCampoDinamico != null)
				return false;
		} else if (!idCampoDinamico.equals(other.idCampoDinamico))
			return false;
		return true;
	}
	
}
