package br.com.callink.cad.to;

import java.io.Serializable;

public class CampoDominioSelecionadoTO implements Serializable {
    
	private static final long serialVersionUID = 1L;

    private Integer idCampoDominioSelecionado;
	
    private CampoDominioTO campoDominio;
	
    private GrupoCampoDominioTO grupoCampoDominio;
    
    public CampoDominioSelecionadoTO() {
    }
    
    public Integer getIdCampoDominioSelecionado() {
		return idCampoDominioSelecionado;
	}

	public void setIdCampoDominioSelecionado(Integer idCampoDominioSelecionado) {
		this.idCampoDominioSelecionado = idCampoDominioSelecionado;
	}

	public CampoDominioTO getCampoDominio() {
		return campoDominio;
	}

	public void setCampoDominio(CampoDominioTO campoDominio) {
		this.campoDominio = campoDominio;
	}

	public GrupoCampoDominioTO getGrupoCampoDominio() {
		return grupoCampoDominio;
	}

	public void setGrupoCampoDominio(GrupoCampoDominioTO grupoCampoDominio) {
		this.grupoCampoDominio = grupoCampoDominio;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((getIdCampoDominioSelecionado() == null) ? 0 : getIdCampoDominioSelecionado().hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CampoDominioSelecionadoTO other = (CampoDominioSelecionadoTO) obj;
		if (getIdCampoDominioSelecionado() == null) {
			if (other.getIdCampoDominioSelecionado() != null)
				return false;
		} else if (!getIdCampoDominioSelecionado().equals(other.getIdCampoDominioSelecionado()))
			return false;
		return true;
	}
}
