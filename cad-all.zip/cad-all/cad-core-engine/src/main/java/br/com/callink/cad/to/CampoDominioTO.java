package br.com.callink.cad.to;

import java.io.Serializable;

public class CampoDominioTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer idCampoDominio;
	private String valorCampoDominio;
	private boolean flagAtivo;
	private String valor;
	
	public Integer getIdCampoDominio() {
		return idCampoDominio;
	}

	public void setIdCampoDominio(Integer idCampoDominio) {
		this.idCampoDominio = idCampoDominio;
	}

	public String getValorCampoDominio() {
		return valorCampoDominio;
	}

	public void setValorCampoDominio(String valorCampoDominio) {
		this.valorCampoDominio = valorCampoDominio;
	}

	public boolean isFlagAtivo() {
		return flagAtivo;
	}

	public void setFlagAtivo(boolean flagAtivo) {
		this.flagAtivo = flagAtivo;
	}

	public String getValor() {
		return valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		if (this.flagAtivo) {
			result = prime * result + ((idCampoDominio == null) ? 0 : idCampoDominio.hashCode());
		} else {
			result = prime * result + ((idCampoDominio == null) ? 0 : idCampoDominio.hashCode());
		}
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CampoDominioTO other = (CampoDominioTO) obj;
		if (this.flagAtivo) {
			if (idCampoDominio == null) {
				if (other.idCampoDominio != null)
					return false;
			} else if (!idCampoDominio.equals(other.idCampoDominio))
				return false;
		} else {
			if (idCampoDominio == null) {
				if (other.idCampoDominio != null)
					return false;
			} else if (!idCampoDominio.equals(other.idCampoDominio))
				return false;
		}

		return true;
	}
}
