package br.com.callink.cad.to;

import java.io.Serializable;
import java.sql.ResultSet;

public class CampoLayoutAlteracaoTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer idCampoLayoutAlteracao;
	private Integer idLayoutAlteracao;
	private String campoNome;
	private String campoValor;
	private Boolean flagCampoDinamico;
	
	public final Integer getIdCampoLayoutAlteracao() {
		return idCampoLayoutAlteracao;
	}
	public final void setIdCampoLayoutAlteracao(Integer idCampoLayoutAlteracao) {
		this.idCampoLayoutAlteracao = idCampoLayoutAlteracao;
	}
	public final Integer getIdLayoutAlteracao() {
		return idLayoutAlteracao;
	}
	public final void setIdLayoutAlteracao(Integer idLayoutAlteracao) {
		this.idLayoutAlteracao = idLayoutAlteracao;
	}
	public final String getCampoNome() {
		return campoNome;
	}
	public final void setCampoNome(String campoNome) {
		this.campoNome = campoNome;
	}
	public final String getCampoValor() {
		return campoValor;
	}
	public final void setCampoValor(String campoValor) {
		this.campoValor = campoValor;
	}
	public final Boolean getFlagCampoDinamico() {
		return flagCampoDinamico;
	}
	public final void setFlagCampoDinamico(Boolean flagCampoDinamico) {
		this.flagCampoDinamico = flagCampoDinamico;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((idCampoLayoutAlteracao == null) ? 0
						: idCampoLayoutAlteracao.hashCode());
		return result;
	}
	
	public static CampoLayoutAlteracaoTO getCamposLayoutTOByResultSet(ResultSet resultSet) throws Exception {
		if(resultSet == null){
			return null;
		}
		CampoLayoutAlteracaoTO to = new CampoLayoutAlteracaoTO();
		to.setCampoNome(resultSet.getString("campo_nome"));
		to.setCampoValor(resultSet.getString("campo_valor"));
		to.setFlagCampoDinamico(resultSet.getBoolean("flag_campo_dinamico"));
		to.setIdCampoLayoutAlteracao(resultSet.getInt("id_campo_layout_alteracao"));
		to.setIdLayoutAlteracao(resultSet.getInt("id_layout_alteracao"));
		return to;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof CampoLayoutAlteracaoTO)) {
			return false;
		}
		CampoLayoutAlteracaoTO other = (CampoLayoutAlteracaoTO) obj;
		if (idCampoLayoutAlteracao == null) {
			if (other.idCampoLayoutAlteracao != null) {
				return false;
			}
		} else if (!idCampoLayoutAlteracao.equals(other.idCampoLayoutAlteracao)) {
			return false;
		}
		return true;
	}
	
	
	
}
