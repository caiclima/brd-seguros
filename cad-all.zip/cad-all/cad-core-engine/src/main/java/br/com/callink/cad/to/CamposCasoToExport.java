package br.com.callink.cad.to;

public enum CamposCasoToExport {

	DESCRICAO("Descrição", false, false),

	CLASSIFICACAO_COUNT("Quantidade de classificações", false, false), 
	EDICAO_TELEFONE_COUNT("Quantidade de edições de telefones", false, false),

	PERCENTUAL_SLA("Percentual do SLA", false, false), 
	SLA_MINUTOS("SLA em minutos", true, true), 
	SLA_TOTAL("SLA total", false, false),

	ID_CASO("Caso", true, true), 
	ID_CASO_PAI("Caso pai", false, false), 
	ID_ANALISTA("Analista", true, true), 
	ID_CONFIGURACAO_FILA("Configuração fila", false, false), 
	ID_STATUS("Status", true, true), 
	ID_EXTERNO("ID Externo", false, false), 
	ID_SLA_FILA("Sla Fila", false, false), 
	ID_CAUSA("Causa", false,false), 
	ID_EVENTO("Evento", true, true), 
	ID_TIPO_CASO("Tipo Caso", true, true), 
	ID_CANAL("Canal", false, false), 
	ID_OUTRA_AREA("Outra Área", false, false), 
	ID_JUNCAO("Junção", false, false), 
	ID_OPERACAO("Operação", false, false),
	ID_USUARIO_SUGERIDO("Usuário Sugerido", false, false),

	DATA_ABERTURA("Data Abertura", false, false), 
	DATA_CADASTRO("Data Cadastro", false, false), 
	DATA_ALTERACAO("Data Alteração", false, false), 
	DATA_FIM_SLA("Data Fim SLA", false, false), 
	DATA_PREVISTA_FIM_SLA("Data prevista fim SLA", false, false), 
	DATA_ENCERRAMENTO("Data de fechamento", false, false),

	FLAG_CLASSIFICA("Aguardando classificação?", false, false), 
	FLAG_FINALIZADO("Finalizado?", false, false), 
	FLAG_CRIADO_MANUAL("Criado Manualmente?", false, false), 
	FLAG_EM_ATENDIMENTO("Em Atendimento?", false, false), 
	FLAG_REABERTO("Reaberto?", false, false), 
	FLAG_RECLASSIFICA_REABERTURA("Reaberto?",false, false), 
	FLAG_TELEFONE_EDITADO("Telefone Editado?", false, false),
	FLAG_RECHAMADO("Rechamado?", false, false),
	;

	CamposCasoToExport(String label, boolean disable, boolean selected) {
		this.label = label;
		this.disable = disable;
		this.selected = selected;
	}

	private boolean disable;
	private boolean selected;
	private String label;

	public boolean isDisable() {
		return disable;
	}
	
	public boolean isSelected() {
		return selected;
	}

	public String getLabel() {
		return label;
	}
}
