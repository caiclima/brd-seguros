package br.com.callink.cad.to;

/**
 * 
 * @author swb_brunnoromero
 * 
 */
public enum CamposFiltroCasoEnum {

	ID_CASO( "Id do Caso",true, false, null,"caso.id_caso", TipoCampoDinamico.NUMERO.toString() ),
	ID_CASO_PAI( "Caso Pai", true, false, null,"caso.id_caso_pai", TipoCampoDinamico.NUMERO.toString() ),
	ID_EXTERNO( "Id Externo", true, false, null,"caso.id_externo", TipoCampoDinamico.NUMERO.toString() ),
	DATA_ABERTURA( "Data Abertura", true, false, null,"caso.data_abertura", TipoCampoDinamico.DATA.toString() ),
	DATA_CADASTRO( "Data Cadastro", true, false, null,"caso.data_cadastro", TipoCampoDinamico.DATA.toString() ),
	DATA_ENCERRAMENTO( "Data Encerramento", true, false, null,"caso.data_encerramento", TipoCampoDinamico.DATA.toString() ),
	DATA_ALTERACAO( "Data Alteração", true, false, null,"caso.data_alteracao", TipoCampoDinamico.DATA.toString() ),
	DATA_FIM_SLA( "Data Fim SLA", true, false, null,"caso.data_fim_sla", TipoCampoDinamico.DATA.toString() ),
	DATA_PREVISTA_FIM_SLA( "Data Prevista SLA", true, false, null,"caso.data_prevista_fim_sla", TipoCampoDinamico.DATA.toString() ),
	FLAG_REABERTO( "Reaberto", true, false, null,"caso.flag_reaberto", TipoCampoDinamico.BOOLEAN.toString() ),
	FLAG_FINALIZADO( "Finalizado", true, false, null,"caso.flag_finalizado", TipoCampoDinamico.BOOLEAN.toString() ),
	FLAG_CRIADO_MANUAL( "Criado Manual", true, false, null,"caso.flag_criado_manual", TipoCampoDinamico.BOOLEAN.toString() ),
	EQUIPE( "Equipe", true, false, "Equipe.class","usuario.id_equipe", TipoCampoDinamico.NUMERO.toString() ),
	CLASSIFICACAO_COUNT( "Classificação", true, false, null,"caso.classificacao_count", TipoCampoDinamico.NUMERO.toString() ),
	FILA( "Fila", true, false, "ConfiguracaoFila.class","caso.id_configuracao_fila", TipoCampoDinamico.NUMERO.toString() ),
	USUARIO( "Usuário", true, false, "Usuario.class","usuario.id_usuario", TipoCampoDinamico.NUMERO.toString() ),
	ID_STATUS( "Situação", true, false, "Status.class","status.id_status", TipoCampoDinamico.NUMERO.toString() ),
	ID_CAUSA( "Causa", true, false, "Causa.class","caso.id_causa", TipoCampoDinamico.NUMERO.toString() ),
	ID_EVENTO( "Evento", true, false, "Evento.class","caso.id_evento", TipoCampoDinamico.NUMERO.toString() ),
	ID_TIPO_CASO( "Tipo do Caso", true, false, "TipoCaso.class","caso.id_tipo_caso", TipoCampoDinamico.NUMERO.toString() ),
	ID_OUTRA_AREA( "Outra Área", true, false, "OutraArea.class","caso.id_outra_area", TipoCampoDinamico.NUMERO.toString() ),
	ID_JUNCAO( "Junção", true, false, "Juncao.class","caso.id_juncao", TipoCampoDinamico.NUMERO.toString() ),
	ID_OPERACAO( "Operação", true, false, "Operacao.class","caso.id_operacao", TipoCampoDinamico.NUMERO.toString() ),
	CANAL( "Canal", true, false, "Canal.class","canal.id_canal", TipoCampoDinamico.NUMERO.toString() ),
	CASO_SEM_FILA( "Caso sem fila",true, false, null,"caso.id_configuracao_fila", TipoCampoDinamico.BOOLEAN.toString() ),
	FLAG_LIDO( "Email já Visualizado",true, false, null,"email.flag_lido", TipoCampoDinamico.BOOLEAN.toString() ),
	SLA_MAIOR( "SLA Maior", true, false,null,"sla_maior", "TIME" ),
	SLA_MENOR( "SLA Menor", true, false,null,"sla_menor", "TIME" ),
	LOTE_CASO( "Lote", true, false, "LoteCaso.class","loteCaso.id_lote_caso", TipoCampoDinamico.NUMERO.toString() ),
	DATA_REABERTURA( "Data Reabertura", true, false, null,"caso.data_ultima_reabertura", TipoCampoDinamico.DATA.toString() ),
	
	;

	private String nomeCampo;
	private Boolean exibir;
	private Boolean notNull;
	private String clazz;
	private String variavelQuery;
	private String type;

	CamposFiltroCasoEnum(String nomeCampo, Boolean exibir, Boolean notNull, String clazz, String variavelQuery, String type) {
		this.nomeCampo = nomeCampo;
		this.exibir = exibir;
		this.setNotNull(notNull);
		this.clazz = clazz;
		this.variavelQuery = variavelQuery;
		this.type = type;
	}

	public static CamposFiltroCasoEnum getEnumByNomeCampo(String nome) {
		CamposFiltroCasoEnum toReturn = null;
		for (CamposFiltroCasoEnum en : CamposFiltroCasoEnum.values()) {
			if (en.getNomeCampo().equalsIgnoreCase(nome)) {
				toReturn = en;
			}
		}
		return toReturn;
	}

	public String getNomeCampo() {
		return nomeCampo;
	}

	public void setNomeCampo(String nomeCampo) {
		this.nomeCampo = nomeCampo;
	}

	public Boolean getExibir() {
		return exibir;
	}

	public void setExibir(Boolean exibir) {
		this.exibir = exibir;
	}

	public Boolean getNotNull() {
		return notNull;
	}

	public void setNotNull(Boolean notNull) {
		this.notNull = notNull;
	}

	public String getClazz() {
		return clazz;
	}

	public void setClazz(String clazz) {
		this.clazz = clazz;
	}

	public String getVariavelQuery() {
		return variavelQuery;
	}

	public void setVariavelQuery(String variavelQuery) {
		this.variavelQuery = variavelQuery;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	
}
