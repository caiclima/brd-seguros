package br.com.callink.cad.to;

import java.io.Serializable;
import java.sql.ResultSet;

public class CamposLayoutTO implements Serializable {

	private static final long serialVersionUID = 1L;
	private String campoCaso;
	private String cammpoNome;
	private String campoImportCaso;
	private Boolean notNull;
	private Integer size;
	private Boolean flagIdentificador;
	private Boolean flagCampoDinamico;
	private String valor;

	public String getCampoCaso() {
		return campoCaso;
	}

	public void setCampoCaso(String campoCaso) {
		this.campoCaso = campoCaso;
	}

	public String getCammpoNome() {
		return cammpoNome;
	}

	public void setCammpoNome(String cammpoNome) {
		this.cammpoNome = cammpoNome;
	}

	public String getCampoImportCaso() {
		return campoImportCaso;
	}

	public void setCampoImportCaso(String campoImportCaso) {
		this.campoImportCaso = campoImportCaso;
	}
	
	public Boolean isNotNull() {
		return notNull;
	}

	public void setNotNull(Boolean isNotNull) {
		this.notNull = isNotNull;
	}

	public Integer getSize() {
		return size;
	}
	
	public void setSize(Integer size) {
		this.size = size;
	}
	
	public Boolean getFlagIdentificador() {
		return flagIdentificador;
	}

	public void setFlagIdentificador(Boolean flagIdentificador) {
		this.flagIdentificador = flagIdentificador;
	}
	
	public Boolean getFlagCampoDinamico() {
		return flagCampoDinamico;
	}
	
	public void setFlagCampoDinamico(Boolean flagCampoDinamico) {
		this.flagCampoDinamico = flagCampoDinamico;
	}
	
	public Boolean getNotNull() {
		return notNull;
	}

	public String getValor() {
		return valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}

	public static CamposLayoutTO getCamposLayoutTOByResultSet(ResultSet resultSet) throws Exception {
		if(resultSet == null){
			return null;
		}
		
		CamposLayoutTO to = new CamposLayoutTO();
		to.setCammpoNome(resultSet.getString("campoNome"));
		to.setCampoCaso(resultSet.getString("campoCaso"));
		to.setCampoImportCaso(resultSet.getString("campoImportCaso"));
		to.setNotNull(resultSet.getBoolean("notNull"));
		to.setSize((Integer) resultSet.getObject("size"));
		to.setFlagIdentificador((Boolean) resultSet.getObject("flagIdentificador"));
		to.setFlagCampoDinamico((Boolean) resultSet.getObject("flagCampoDinamico"));
		return to;
	}
	
}
