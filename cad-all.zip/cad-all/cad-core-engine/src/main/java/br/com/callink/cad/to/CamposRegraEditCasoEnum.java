package br.com.callink.cad.to;


public enum CamposRegraEditCasoEnum {

	ID_USUARIO_SUGERIDO("ID_USUARIO_SUGERIDO"),
	ID_TIPO_CASO("ID_TIPO_CASO"),
	ID_OUTRA_AREA("ID_OUTRA_AREA"),
	ID_JUNCAO("ID_JUNCAO"),
	ID_EXTERNO("ID_EXTERNO"),
	ID_EVENTO("ID_EVENTO" ),
	ID_CAUSA("ID_CAUSA" ),
	ID_CANAL("ID_CANAL"),
	DATA_ABERTURA("DATA_ABERTURA" ),
	DESCRICAO("DESCRICAO" ),
	DATA_AGENDAMENTO("DATA_AGENDAMENTO"),
	ID_CONFIGURACAO_FILA("ID_CONFIGURACAO_FILA" ),
	ID_STATUS("ID_STATUS" );

	private String nomeCampo;

	CamposRegraEditCasoEnum(String nomeCampo) {
		this.nomeCampo = nomeCampo;
	}

	public String getNomeCampo() {
		return nomeCampo;
	}

	public void setNomeCampo(String nomeCampo) {
		this.nomeCampo = nomeCampo;
	}

}
