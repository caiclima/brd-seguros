package br.com.callink.cad.to;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

public class CasoAbertoCockpitDetalheTO implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Integer idCasoAbertoCockpitDetalhe;
	private Integer idCasoAbertoCockpit;
	private Integer idCaso;
	private String idExterno;
    private Date dataProcessamento;
    private Integer idConfiguracaoFila;
    private String configuracaoFila;
    private Integer idTipoCaso;
    private String tipoCaso;
    private Double percentual;
	private Integer idOperacao;

    public CasoAbertoCockpitDetalheTO() {
    }

    public Integer getPK() {
        return this.idCasoAbertoCockpitDetalhe;
    }

    public void setPK(Integer pk) {
        this.idCasoAbertoCockpitDetalhe = pk;
    }

    public Integer getIdCasoAbertoCockpitDetalhe() {
		return idCasoAbertoCockpitDetalhe;
	}

	public void setIdCasoAbertoCockpitDetalhe(Integer idCasoAbertoCockpitDetalhe) {
		this.idCasoAbertoCockpitDetalhe = idCasoAbertoCockpitDetalhe;
	}

	public Integer getIdCasoAbertoCockpit() {
		return idCasoAbertoCockpit;
	}

	public void setIdCasoAbertoCockpit(Integer idCasoAbertoCockpit) {
		this.idCasoAbertoCockpit = idCasoAbertoCockpit;
	}

	public Integer getIdCaso() {
		return idCaso;
	}

	public void setIdCaso(Integer idCaso) {
		this.idCaso = idCaso;
	}

	public String getIdExterno() {
		return idExterno;
	}

	public void setIdExterno(String idExterno) {
		this.idExterno = idExterno;
	}

	public Integer getIdConfiguracaoFila() {
		return idConfiguracaoFila;
	}

	public void setIdConfiguracaoFila(Integer idConfiguracaoFila) {
		this.idConfiguracaoFila = idConfiguracaoFila;
	}

	public String getConfiguracaoFila() {
		return configuracaoFila;
	}

	public void setConfiguracaoFila(String configuracaoFila) {
		this.configuracaoFila = configuracaoFila;
	}

	public Integer getIdTipoCaso() {
		return idTipoCaso;
	}

	public void setIdTipoCaso(Integer idTipoCaso) {
		this.idTipoCaso = idTipoCaso;
	}

	public String getTipoCaso() {
		return tipoCaso;
	}

	public void setTipoCaso(String tipoCaso) {
		this.tipoCaso = tipoCaso;
	}

	public Double getPercentual() {
		return percentual;
	}

	public void setPercentual(Double percentual) {
		this.percentual = percentual;
	}

	public Date getDataProcessamento() {
        return dataProcessamento == null ? null : new Date(dataProcessamento.getTime());
    }

    public void setDataProcessamento(Date dataProcessamento) {
        this.dataProcessamento = dataProcessamento == null ? null : new Date(dataProcessamento.getTime());
    }
    
	public Integer getIdOperacao() {
		return idOperacao;
	}
	
	public void setIdOperacao(Integer idOperacao) {
		this.idOperacao = idOperacao;
	}

    public static String getSelectSqlCasoAbertoCockpitDetalhe() {
        StringBuilder select = new StringBuilder();
        select.append("\nCasoAbertoCockpitDetalhe.id_caso_aberto_cockpit_detalhe AS 'CasoAbertoCockpitDetalhe.id_caso_aberto_cockpit_detalhe', ");
        select.append("\nCasoAbertoCockpitDetalhe.id_caso_aberto_cockpit AS 'CasoAbertoCockpitDetalhe.id_caso_aberto_cockpit', ");
        select.append("\nCasoAbertoCockpitDetalhe.id_caso AS 'CasoAbertoCockpitDetalhe.id_caso', ");
        select.append("\nCasoAbertoCockpitDetalhe.id_externo AS 'CasoAbertoCockpitDetalhe.id_externo', ");
        select.append("\nCasoAbertoCockpitDetalhe.data_processamento AS 'CasoAbertoCockpitDetalhe.data_processamento',  ");
        select.append("\nCasoAbertoCockpitDetalhe.id_configuracao_fila AS 'CasoAbertoCockpitDetalhe.id_configuracao_fila',  ");
        select.append("\nCasoAbertoCockpitDetalhe.configuracao_fila AS 'CasoAbertoCockpitDetalhe.configuracao_fila',  ");
        select.append("\nCasoAbertoCockpitDetalhe.id_tipo_caso AS 'CasoAbertoCockpitDetalhe.id_tipo_caso',  ");
        select.append("\nCasoAbertoCockpitDetalhe.tipo_caso AS 'CasoAbertoCockpitDetalhe.tipo_caso',  ");
        select.append("\nCasoAbertoCockpitDetalhe.percentual AS 'CasoAbertoCockpitDetalhe.percentual', ");
        select.append("\nCasoAbertoCockpitDetalhe.id_operacao AS 'CasoAbertoCockpitDetalhe.id_operacao'  ");
        return select.toString();
    }

    public static String getSqlFromCasoAbertoCockpitDetalhe() {
        return " tb_caso_aberto_cockpit_detalhe as CasoAbertoCockpitDetalhe with(nolock) ";
    }

    public static CasoAbertoCockpitDetalheTO getCausaByResultSet(ResultSet rs) {
        try {
        	if (rs.getInt("CasoAbertoCockpitDetalhe.id_caso_aberto_cockpit_detalhe") == 0) {
        		return null;
        	}
            CasoAbertoCockpitDetalheTO casoAbertoCockpitDetalhe = new CasoAbertoCockpitDetalheTO();
            casoAbertoCockpitDetalhe.setIdCasoAbertoCockpitDetalhe((Integer)rs.getObject("CasoAbertoCockpitDetalhe.id_caso_aberto_cockpit_detalhe"));
            casoAbertoCockpitDetalhe.setIdCasoAbertoCockpit((Integer)rs.getObject("CasoAbertoCockpitDetalhe.id_caso_aberto_cockpit"));
            casoAbertoCockpitDetalhe.setIdCaso((Integer) rs.getObject("CasoAbertoCockpitDetalhe.id_caso"));
            casoAbertoCockpitDetalhe.setIdExterno((String) rs.getObject("CasoAbertoCockpitDetalhe.id_externo"));
            casoAbertoCockpitDetalhe.setDataProcessamento(rs.getTimestamp("CasoAbertoCockpitDetalhe.data_processamento"));
            casoAbertoCockpitDetalhe.setIdConfiguracaoFila(rs.getInt("CasoAbertoCockpitDetalhe.id_configuracao_fila"));
            casoAbertoCockpitDetalhe.setConfiguracaoFila(rs.getString("CasoAbertoCockpitDetalhe.configuracao_fila"));
            casoAbertoCockpitDetalhe.setIdTipoCaso(rs.getInt("CasoAbertoCockpitDetalhe.id_tipo_caso"));
            casoAbertoCockpitDetalhe.setTipoCaso(rs.getString("CasoAbertoCockpitDetalhe.tipo_caso"));
            casoAbertoCockpitDetalhe.setPercentual(rs.getDouble("CasoAbertoCockpitDetalhe.percentual"));
            casoAbertoCockpitDetalhe.setIdOperacao(rs.getInt("CasoAbertoCockpitDetalhe.id_operacao"));
            return casoAbertoCockpitDetalhe;
        } catch (SQLException ex) {
            throw new IllegalArgumentException("Erro ao montar objeto a partir do ResultSet", ex);
        }
    }
}
