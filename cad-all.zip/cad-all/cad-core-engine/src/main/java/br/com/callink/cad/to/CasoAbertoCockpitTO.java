package br.com.callink.cad.to;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class CasoAbertoCockpitTO implements Serializable {

	private static final long serialVersionUID = 1L;
	private Integer idCasoAbertoCockpit;
    private Boolean flagFila;
    private Date dataProcessamento;
    private String nomeFilaAtendimento;
    private String tipoCaso;
    private Integer qtdPrimeiroDia;
    private String percentualPrimeiroDia;
    private Integer qtdSegundoDia;
    private String percentualSegundoDia;
    private Integer qtdTerceiroDia;
    private String percentualTerceiroDia;
    private Integer qtdQuartoDia;
    private String percentualQuartoDia;
    private Integer qtdQuintoDia;
    private String percentualQuintoDia;
    private Integer qtdSextoDia;
    private String percentualSextoDia;
    private Integer qtdRestanteDia;
    private String percentualRestanteDia;
    private Integer qtdTotal;
    private String percentualTotal;
	private Integer idOperacao;
	
	private List<CasoTO> casosDetalhados;

    public CasoAbertoCockpitTO() {
        this.qtdPrimeiroDia = 0;
        this.qtdSegundoDia = 0;
        this.qtdTerceiroDia = 0;
        this.qtdQuartoDia = 0;
        this.qtdQuintoDia = 0;
        this.qtdSextoDia = 0;
        this.qtdRestanteDia = 0;
        this.qtdTotal = 0;

        this.percentualPrimeiroDia = "0";
        this.percentualSegundoDia = "0";
        this.percentualTerceiroDia = "0";
        this.percentualQuartoDia = "0";
        this.percentualQuintoDia = "0";
        this.percentualSextoDia = "0";
        this.percentualRestanteDia = "0";
        this.percentualTotal = "0";
    }

    public Integer getPK() {
        return this.idCasoAbertoCockpit;
    }

    public void setPK(Integer t) {
        this.idCasoAbertoCockpit = t;
    }

    public void setNomeFilaAtendimento(String nomeFilaAtendimento) {
        this.nomeFilaAtendimento = nomeFilaAtendimento;
    }

    public void setTipoCaso(String tipoCaso) {
        this.tipoCaso = tipoCaso;
    }

    public String getPercentualPrimeiroDia() {
        return percentualPrimeiroDia;
    }

    public String getPercentualQuartoDia() {
        return percentualQuartoDia;
    }

    public String getPercentualQuintoDia() {
        return percentualQuintoDia;
    }

    public String getPercentualRestanteDia() {
        return percentualRestanteDia;
    }

    public String getPercentualSegundoDia() {
        return percentualSegundoDia;
    }

    public String getPercentualSextoDia() {
        return percentualSextoDia;
    }

    public String getPercentualTerceiroDia() {
        return percentualTerceiroDia;
    }

    public String getPercentualTotal() {
        return percentualTotal;
    }

    public Integer getQtdPrimeiroDia() {
        return qtdPrimeiroDia;
    }

    public Integer getQtdQuartoDia() {
        return qtdQuartoDia;
    }

    public Integer getQtdQuintoDia() {
        return qtdQuintoDia;
    }

    public Integer getQtdRestanteDia() {
        return qtdRestanteDia;
    }

    public Integer getQtdSegundoDia() {
        return qtdSegundoDia;
    }

    public Integer getQtdSextoDia() {
        return qtdSextoDia;
    }

    public Integer getQtdTerceiroDia() {
        return qtdTerceiroDia;
    }

    public Integer getQtdTotal() {
        return qtdTotal;
    }

    public String getTipoCaso() {
        return tipoCaso;
    }

    public String getNomeFilaAtendimento() {
        return nomeFilaAtendimento;
    }

    public void setQtdPrimeiroDia(Integer qtdPrimeiroDia) {
        this.qtdPrimeiroDia = qtdPrimeiroDia;
    }

    public void setPercentualPrimeiroDia(String percentualPrimeiroDia) {
        this.percentualPrimeiroDia = percentualPrimeiroDia;
    }

    public void setQtdSegundoDia(Integer qtdSegundoDia) {
        this.qtdSegundoDia = qtdSegundoDia;
    }

    public void setPercentualSegundoDia(String percentualSegundoDia) {
        this.percentualSegundoDia = percentualSegundoDia;
    }

    public void setQtdTerceiroDia(Integer qtdTerceiroDia) {
        this.qtdTerceiroDia = qtdTerceiroDia;
    }

    public void setPercentualTerceiroDia(String percentualTerceiroDia) {
        this.percentualTerceiroDia = percentualTerceiroDia;
    }

    public void setQtdQuartoDia(Integer qtdQuartoDia) {
        this.qtdQuartoDia = qtdQuartoDia;
    }

    public void setPercentualQuartoDia(String percentualQuartoDia) {
        this.percentualQuartoDia = percentualQuartoDia;
    }

    public void setQtdQuintoDia(Integer qtdQuintoDia) {
        this.qtdQuintoDia = qtdQuintoDia;
    }

    public void setPercentualQuintoDia(String percentualQuintoDia) {
        this.percentualQuintoDia = percentualQuintoDia;
    }

    public void setQtdSextoDia(Integer qtdSextoDia) {
        this.qtdSextoDia = qtdSextoDia;
    }

    public void setPercentualSextoDia(String percentualSextoDia) {
        this.percentualSextoDia = percentualSextoDia;
    }

    public void setQtdRestanteDia(Integer qtdRestanteDia) {
        this.qtdRestanteDia = qtdRestanteDia;
    }

    public void setPercentualRestanteDia(String percentualRestanteDia) {
        this.percentualRestanteDia = percentualRestanteDia;
    }

    public void setQtdTotal(Integer qtdTotal) {
        this.qtdTotal = qtdTotal;
    }

    public void setPercentualTotal(String percentualTotal) {
        this.percentualTotal = percentualTotal;
    }

    public Integer getIdCasoAbertoCockpit() {
        return idCasoAbertoCockpit;
    }

    public void setIdCasoAbertoCockpit(Integer idCasoAbertoCockpit) {
        this.idCasoAbertoCockpit = idCasoAbertoCockpit;
    }

    public Boolean getFlagFila() {
        return flagFila;
    }

    public void setFlagFila(Boolean flagFila) {
        this.flagFila = flagFila;
    }

    public Date getDataProcessamento() {
        return dataProcessamento == null ? null : new Date(dataProcessamento.getTime());
    }

    public void setDataProcessamento(Date dataProcessamento) {
        this.dataProcessamento = dataProcessamento == null ? null : new Date(dataProcessamento.getTime());
    }
    
	public Integer getIdOperacao() {
		return idOperacao;
	}
	
	public void setIdOperacao(Integer idOperacao) {
		this.idOperacao = idOperacao;
	}

	public List<CasoTO> getCasosDetalhados() {
		if (casosDetalhados == null) {
			casosDetalhados = new ArrayList<CasoTO>();
		}
		return casosDetalhados;
	}

	public void setCasosDetalhados(List<CasoTO> casosDetalhados) {
		this.casosDetalhados = casosDetalhados;
	}

	public void addQtdPrimeiroDia() {
        this.qtdPrimeiroDia++;
        calculaPercentualCasoAberto();
    }

    public void addQtdSegundoDia() {
        this.qtdSegundoDia++;
        calculaPercentualCasoAberto();
    }

    public void addQtdTerceiroDia() {
        this.qtdTerceiroDia++;
        calculaPercentualCasoAberto();
    }

    public void addQtdQuartoDia() {
        this.qtdQuartoDia++;
        calculaPercentualCasoAberto();
    }

    public void addQtdQuintoDia() {
        this.qtdQuintoDia++;
        calculaPercentualCasoAberto();
    }

    public void addQtdSextoDia() {
        this.qtdSextoDia++;
        calculaPercentualCasoAberto();
    }

    public void addQtdRestanteDia() {
        this.qtdRestanteDia++;
        calculaPercentualCasoAberto();
    }

    private void calculaPercentualCasoAberto() {
        this.qtdTotal = this.qtdPrimeiroDia + this.qtdSegundoDia + this.qtdTerceiroDia + this.qtdQuartoDia + this.qtdQuintoDia + this.qtdSextoDia + this.qtdRestanteDia;
        DecimalFormat df = new DecimalFormat("###.##");
        if (qtdTotal > 0) {
            this.percentualPrimeiroDia = df.format((this.qtdPrimeiroDia.doubleValue() * Double.valueOf(100)) / qtdTotal.doubleValue());
            this.percentualSegundoDia = df.format((this.qtdSegundoDia.doubleValue() * Double.valueOf(100)) / qtdTotal.doubleValue());
            this.percentualTerceiroDia = df.format((this.qtdTerceiroDia.doubleValue() * Double.valueOf(100)) / qtdTotal.doubleValue());
            this.percentualQuartoDia = df.format((this.qtdQuartoDia.doubleValue() * Double.valueOf(100)) / qtdTotal.doubleValue());
            this.percentualQuintoDia = df.format((this.qtdQuintoDia.doubleValue() * Double.valueOf(100)) / qtdTotal.doubleValue());
            this.percentualSextoDia = df.format((this.qtdSextoDia.doubleValue() * Double.valueOf(100)) / qtdTotal.doubleValue());
            this.percentualRestanteDia = df.format((this.qtdRestanteDia.doubleValue() * Double.valueOf(100)) / qtdTotal.doubleValue());
        }
    }

    /**
     * Calcula o percentual que o casoAbertoCockpit representa em todo o map.
     *
     * @param totalCasos
     */
    public void calculaTotalPercentual(Integer totalCasos) {
        if (totalCasos > 0) {
            DecimalFormat df = new DecimalFormat("###.##");
            this.percentualTotal = df.format(((qtdTotal.doubleValue() * 100) / totalCasos.doubleValue()));
        }
    }

    public void adicionaOutros(CasoAbertoCockpitTO casoAbertoCockpit) {
        this.qtdPrimeiroDia = this.qtdPrimeiroDia + casoAbertoCockpit.getQtdPrimeiroDia();
        this.qtdSegundoDia = this.qtdSegundoDia + casoAbertoCockpit.getQtdSegundoDia();
        this.qtdTerceiroDia = this.qtdTerceiroDia + casoAbertoCockpit.getQtdTerceiroDia();
        this.qtdQuartoDia = this.qtdQuartoDia + casoAbertoCockpit.getQtdQuartoDia();
        this.qtdQuintoDia = this.qtdQuintoDia + casoAbertoCockpit.getQtdQuintoDia();
        this.qtdSextoDia = this.qtdSextoDia + casoAbertoCockpit.getQtdSextoDia();
        this.qtdRestanteDia = this.qtdRestanteDia + casoAbertoCockpit.getQtdRestanteDia();

        calculaPercentualCasoAberto();
    }

    public static String getSelectSqlCasoAbertoCockpit() {
        StringBuilder select = new StringBuilder();
        select.append("\nCasoAbertoCockpit.id_caso_aberto_cockpit AS 'CasoAbertoCockpit.id_caso_aberto_cockpit', ");
        select.append("\nCasoAbertoCockpit.flag_fila AS 'CasoAbertoCockpit.flag_fila',  ");
        select.append("\nCasoAbertoCockpit.data_processamento AS 'CasoAbertoCockpit.data_processamento',  ");
        select.append("\nCasoAbertoCockpit.nome_fila_atendimento AS 'CasoAbertoCockpit.nome_fila_atendimento',  ");
        select.append("\nCasoAbertoCockpit.tipo_manifestacao AS 'CasoAbertoCockpit.tipo_manifestacao',  ");
        select.append("\nCasoAbertoCockpit.qtd_primeiro_dia AS 'CasoAbertoCockpit.qtd_primeiro_dia',  ");
        select.append("\nCasoAbertoCockpit.percentual_primeiro_dia AS 'CasoAbertoCockpit.percentual_primeiro_dia',  ");
        select.append("\nCasoAbertoCockpit.qtd_segundo_dia AS 'CasoAbertoCockpit.qtd_segundo_dia',  ");
        select.append("\nCasoAbertoCockpit.percentual_segundo_dia AS 'CasoAbertoCockpit.percentual_segundo_dia',  ");
        select.append("\nCasoAbertoCockpit.qtd_terceiro_dia AS 'CasoAbertoCockpit.qtd_terceiro_dia',  ");
        select.append("\nCasoAbertoCockpit.percentual_terceiro_dia AS 'CasoAbertoCockpit.percentual_terceiro_dia',  ");
        select.append("\nCasoAbertoCockpit.qtd_quarto_dia AS 'CasoAbertoCockpit.qtd_quarto_dia',  ");
        select.append("\nCasoAbertoCockpit.percentual_quarto_dia AS 'CasoAbertoCockpit.percentual_quarto_dia',  ");
        select.append("\nCasoAbertoCockpit.qtd_quinto_dia AS 'CasoAbertoCockpit.qtd_quinto_dia',  ");
        select.append("\nCasoAbertoCockpit.percentual_quinto_dia AS 'CasoAbertoCockpit.percentual_quinto_dia',  ");
        select.append("\nCasoAbertoCockpit.qtd_sexto_dia AS 'CasoAbertoCockpit.qtd_sexto_dia',  ");
        select.append("\nCasoAbertoCockpit.percentual_sexto_dia AS 'CasoAbertoCockpit.percentual_sexto_dia',  ");
        select.append("\nCasoAbertoCockpit.qtd_restante_dia AS 'CasoAbertoCockpit.qtd_restante_dia',  ");
        select.append("\nCasoAbertoCockpit.percentual_restante_dia AS 'CasoAbertoCockpit.percentual_restante_dia',  ");
        select.append("\nCasoAbertoCockpit.qtd_total AS 'CasoAbertoCockpit.qtd_total',  ");
        select.append("\nCasoAbertoCockpit.percentual_total AS 'CasoAbertoCockpit.percentual_total' ");
        return select.toString();
    }

    public static String getSqlFromCasoAbertoCockpit() {
        return " tb_caso_aberto_cockpit as CasoAbertoCockpit with(nolock) ";
    }

    public static CasoAbertoCockpitTO getCausaByResultSet(ResultSet rs) {
        try {
        	
        	if(rs.getInt("CasoAbertoCockpit.id_caso_aberto_cockpit") == 0){
        		return null;
        	}
        	
            CasoAbertoCockpitTO casoAbertoCockpit = new CasoAbertoCockpitTO();
            casoAbertoCockpit.setDataProcessamento(rs.getTimestamp("CasoAbertoCockpit.data_processamento"));
            casoAbertoCockpit.setTipoCaso(rs.getString("CasoAbertoCockpit.tipo_manifestacao"));
            casoAbertoCockpit.setQtdTerceiroDia((Integer)rs.getObject("CasoAbertoCockpit.qtd_terceiro_dia"));
            casoAbertoCockpit.setQtdTotal((Integer)rs.getObject("CasoAbertoCockpit.qtd_total"));
            casoAbertoCockpit.setQtdSextoDia((Integer)rs.getObject("CasoAbertoCockpit.qtd_sexto_dia"));
            casoAbertoCockpit.setQtdSegundoDia((Integer)rs.getObject("CasoAbertoCockpit.qtd_segundo_dia"));
            casoAbertoCockpit.setQtdRestanteDia((Integer)rs.getObject("CasoAbertoCockpit.qtd_restante_dia"));
            casoAbertoCockpit.setQtdQuintoDia((Integer)rs.getObject("CasoAbertoCockpit.qtd_quinto_dia"));
            casoAbertoCockpit.setQtdQuartoDia((Integer)rs.getObject("CasoAbertoCockpit.qtd_quarto_dia"));
            casoAbertoCockpit.setQtdPrimeiroDia((Integer)rs.getObject("CasoAbertoCockpit.qtd_primeiro_dia"));
            casoAbertoCockpit.setPercentualTotal(rs.getString("CasoAbertoCockpit.percentual_total"));
            casoAbertoCockpit.setPercentualTerceiroDia(rs.getString("CasoAbertoCockpit.percentual_terceiro_dia"));
            casoAbertoCockpit.setPercentualSextoDia(rs.getString("CasoAbertoCockpit.percentual_sexto_dia"));
            casoAbertoCockpit.setPercentualSegundoDia(rs.getString("CasoAbertoCockpit.percentual_segundo_dia"));
            casoAbertoCockpit.setPercentualRestanteDia(rs.getString("CasoAbertoCockpit.percentual_restante_dia"));
            casoAbertoCockpit.setPercentualQuintoDia(rs.getString("CasoAbertoCockpit.percentual_quinto_dia"));
            casoAbertoCockpit.setNomeFilaAtendimento(rs.getString("CasoAbertoCockpit.nome_fila_atendimento"));
            casoAbertoCockpit.setIdCasoAbertoCockpit((Integer)rs.getObject("CasoAbertoCockpit.id_caso_aberto_cockpit"));
            casoAbertoCockpit.setFlagFila(rs.getBoolean("CasoAbertoCockpit.flag_fila"));
            casoAbertoCockpit.setPercentualQuartoDia(rs.getString("CasoAbertoCockpit.percentual_quarto_dia"));
            casoAbertoCockpit.setPercentualPrimeiroDia(rs.getString("CasoAbertoCockpit.percentual_primeiro_dia"));
            return casoAbertoCockpit;
        } catch (SQLException ex) {
            throw new IllegalArgumentException(
                    "Erro ao montar objeto a partir do ResultSet", ex);
        }
    }


	public boolean equalsProperties(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CasoAbertoCockpitTO other = (CasoAbertoCockpitTO) obj;
		if (flagFila == null) {
			if (other.flagFila != null)
				return false;
		} else if (!flagFila.equals(other.flagFila))
			return false;
		if (idOperacao == null) {
			if (other.idOperacao != null)
				return false;
		} else if (!idOperacao.equals(other.idOperacao))
			return false;
		if (nomeFilaAtendimento == null) {
			if (other.nomeFilaAtendimento != null)
				return false;
		} else if (!nomeFilaAtendimento.equals(other.nomeFilaAtendimento))
			return false;
		if (qtdPrimeiroDia == null) {
			if (other.qtdPrimeiroDia != null)
				return false;
		} else if (!qtdPrimeiroDia.equals(other.qtdPrimeiroDia))
			return false;
		if (qtdQuartoDia == null) {
			if (other.qtdQuartoDia != null)
				return false;
		} else if (!qtdQuartoDia.equals(other.qtdQuartoDia))
			return false;
		if (qtdQuintoDia == null) {
			if (other.qtdQuintoDia != null)
				return false;
		} else if (!qtdQuintoDia.equals(other.qtdQuintoDia))
			return false;
		if (qtdRestanteDia == null) {
			if (other.qtdRestanteDia != null)
				return false;
		} else if (!qtdRestanteDia.equals(other.qtdRestanteDia))
			return false;
		if (qtdSegundoDia == null) {
			if (other.qtdSegundoDia != null)
				return false;
		} else if (!qtdSegundoDia.equals(other.qtdSegundoDia))
			return false;
		if (qtdSextoDia == null) {
			if (other.qtdSextoDia != null)
				return false;
		} else if (!qtdSextoDia.equals(other.qtdSextoDia))
			return false;
		if (qtdTerceiroDia == null) {
			if (other.qtdTerceiroDia != null)
				return false;
		} else if (!qtdTerceiroDia.equals(other.qtdTerceiroDia))
			return false;
		if (qtdTotal == null) {
			if (other.qtdTotal != null)
				return false;
		} else if (!qtdTotal.equals(other.qtdTotal))
			return false;
		if (tipoCaso == null) {
			if (other.tipoCaso != null)
				return false;
		} else if (!tipoCaso.equals(other.tipoCaso))
			return false;
		return true;
	}

    
    
}
