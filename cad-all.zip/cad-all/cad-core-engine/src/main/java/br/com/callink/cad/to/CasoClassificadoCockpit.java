package br.com.callink.cad.to;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author brunomt
 */
public class CasoClassificadoCockpit {
    public static final String OUTROS = "OUTROS";
    private Integer top;
    private String eventoPai;
    private Integer volumeTotal;
    private Integer volumeDentroPrazo;
    private Double percentualDentroPrazo;
    private Integer volumeForaPrazo;
    private Double percentualForaPrazo;
    
    private List<CasoTO> casos;

    public CasoClassificadoCockpit() {
        volumeDentroPrazo = 0;
        volumeForaPrazo = 0;
        volumeTotal = 0;
    }
    
    public String getEventoPai() {
        return eventoPai;
    }

    public Double getPercentualDentroPrazo() {
        return percentualDentroPrazo;
    }

    public Double getPercentualForaPrazo() {
        return percentualForaPrazo;
    }

    public Integer getTop() {
        return top;
    }

    public Integer getVolumeDentroPrazo() {
        return volumeDentroPrazo;
    }

    public Integer getVolumeForaPrazo() {
        return volumeForaPrazo;
    }
    
    public Integer getVolumeTotal() {
        return volumeTotal;
    }

    public void setEventoPai(String eventoPai) {
        this.eventoPai = eventoPai;
    }

    public void setTop(Integer top) {
        this.top = top;
    }
    
    public void addVolumeDentroPrazo() {
        volumeDentroPrazo++;
        volumeTotal++;
        calculaPercentual();
    }
    
    public void addVolumeForaPrazo() {
        volumeForaPrazo++;
        volumeTotal++;
        calculaPercentual();
    }

    private void calculaPercentual() {
        if (volumeTotal != 0) {
            percentualDentroPrazo = ((volumeDentroPrazo.doubleValue() * Double.valueOf(100)) / volumeTotal);
        } else {
            percentualDentroPrazo = 0d;
        }
        if (volumeTotal != 0) {
            percentualForaPrazo = ((volumeForaPrazo.doubleValue() * Double.valueOf(100)) / volumeTotal);
        } else {
            percentualDentroPrazo = 0d;
        }
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final CasoClassificadoCockpit other = (CasoClassificadoCockpit) obj;
        if ((this.eventoPai == null) ? (other.eventoPai != null) : !this.eventoPai.equals(other.eventoPai)) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 89 * hash + (this.eventoPai != null ? this.eventoPai.hashCode() : 0);
        return hash;
    }

    void addCasoClassificaCockpit(CasoClassificadoCockpit casoClassificadoCockpit) {
        this.volumeDentroPrazo = this.volumeDentroPrazo + casoClassificadoCockpit.getVolumeDentroPrazo();
        this.volumeForaPrazo = this.volumeForaPrazo + casoClassificadoCockpit.getVolumeForaPrazo();
        this.volumeTotal = this.volumeTotal + casoClassificadoCockpit.getVolumeDentroPrazo() + casoClassificadoCockpit.getVolumeForaPrazo();
        calculaPercentual();
    }
    
    public List<CasoTO> getCasos() {
		if (casos == null) {
			casos = new ArrayList<CasoTO>();
		}
		return casos;
	}

	public void setCasos(List<CasoTO> casos) {
		this.casos = casos;
	}
    
}
