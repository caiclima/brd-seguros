package br.com.callink.cad.to;

import java.io.Serializable;

public class CasoClassificadoCockpitDetalheTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer idCasoClassificadoDetalhe;
	private Integer idCasoClassificado;
	private Integer idCaso;
	private String idExterno;
	private Integer idTipoCaso;
	private String tipoCaso;
	private Integer idEventoPai;
	private String eventoPai;
	private Boolean flagDentroPrazo;
	private Integer idOperacao;
	
	public Integer getIdCasoClassificadoDetalhe() {
		return idCasoClassificadoDetalhe;
	}
	public void setIdCasoClassificadoDetalhe(Integer idCasoClassificadoDetalhe) {
		this.idCasoClassificadoDetalhe = idCasoClassificadoDetalhe;
	}
	
	public Integer getIdCasoClassificado() {
		return idCasoClassificado;
	}
	public void setIdCasoClassificado(Integer idCasoClassificado) {
		this.idCasoClassificado = idCasoClassificado;
	}
	
	public Integer getIdCaso() {
		return idCaso;
	}
	public void setIdCaso(Integer idCaso) {
		this.idCaso = idCaso;
	}
	
	public String getIdExterno() {
		return idExterno;
	}
	public void setIdExterno(String idExterno) {
		this.idExterno = idExterno;
	}
	
	public Integer getIdTipoCaso() {
		return idTipoCaso;
	}
	public void setIdTipoCaso(Integer idTipoCaso) {
		this.idTipoCaso = idTipoCaso;
	}
	
	public String getTipoCaso() {
		return tipoCaso;
	}
	public void setTipoCaso(String tipoCaso) {
		this.tipoCaso = tipoCaso;
	}
	
	public Integer getIdEventoPai() {
		return idEventoPai;
	}
	public void setIdEventoPai(Integer idEventoPai) {
		this.idEventoPai = idEventoPai;
	}
	
	public String getEventoPai() {
		return eventoPai;
	}
	public void setEventoPai(String eventoPai) {
		this.eventoPai = eventoPai;
	}
	
	public Boolean getFlagDentroPrazo() {
		return flagDentroPrazo;
	}
	public void setFlagDentroPrazo(Boolean flagDentroPrazo) {
		this.flagDentroPrazo = flagDentroPrazo;
	}
	
	public Integer getIdOperacao() {
		return idOperacao;
	}
	public void setIdOperacao(Integer idOperacao) {
		this.idOperacao = idOperacao;
	}

}
