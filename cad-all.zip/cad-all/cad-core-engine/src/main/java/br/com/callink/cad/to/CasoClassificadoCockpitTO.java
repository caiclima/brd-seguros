package br.com.callink.cad.to;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * 
 * @author swb_halan
 * 
 */
public class CasoClassificadoCockpitTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer idCasoClassificado;
	private String tipoCaso;
	private String nomeDiv;
	private Integer top;
	private String eventoPai;
	private Integer volumeTotal;
	private Integer volumeDentroPrazo;
	private Double percentualDentroPrazo;
	private Integer volumeForaPrazo;
	private Double percentualForaPrazo;
	private Integer totalDentroPrazo;
	private Integer totalForaPrazo;
	private Double percentualTotalDentroPrazo;
	private Double percentualTotalForaPrazo;
	private Boolean flagTotalizador;
	private Integer idOperacao;
	
	private List<CasoTO> casos;

	public Integer getIdCasoClassificado() {
		return idCasoClassificado;
	}

	public void setIdCasoClassificado(Integer idCasoClassificado) {
		this.idCasoClassificado = idCasoClassificado;
	}

	public String getTipoCaso() {
		return tipoCaso;
	}

	public void setTipoCaso(String tipoCaso) {
		this.tipoCaso = tipoCaso;
	}

	public String getNomeDiv() {
		return nomeDiv;
	}

	public void setNomeDiv(String nomeDiv) {
		this.nomeDiv = nomeDiv;
	}

	public Integer getTop() {
		return top;
	}

	public void setTop(Integer top) {
		this.top = top;
	}

	public String getEventoPai() {
		return eventoPai;
	}

	public void setEventoPai(String eventoPai) {
		this.eventoPai = eventoPai;
	}

	public Integer getVolumeTotal() {
		return volumeTotal;
	}

	public void setVolumeTotal(Integer volumeTotal) {
		this.volumeTotal = volumeTotal;
	}

	public Integer getVolumeDentroPrazo() {
		return volumeDentroPrazo;
	}

	public void setVolumeDentroPrazo(Integer volumeDentroPrazo) {
		this.volumeDentroPrazo = volumeDentroPrazo;
	}

	public Double getPercentualDentroPrazo() {
		return percentualDentroPrazo;
	}

	public void setPercentualDentroPrazo(Double percentualDentroPrazo) {
		this.percentualDentroPrazo = percentualDentroPrazo;
	}

	public Integer getVolumeForaPrazo() {
		return volumeForaPrazo;
	}

	public void setVolumeForaPrazo(Integer volumeForaPrazo) {
		this.volumeForaPrazo = volumeForaPrazo;
	}

	public Double getPercentualForaPrazo() {
		return percentualForaPrazo;
	}

	public void setPercentualForaPrazo(Double percentualForaPrazo) {
		this.percentualForaPrazo = percentualForaPrazo;
	}

	public Integer getTotalDentroPrazo() {
		return totalDentroPrazo;
	}

	public void setTotalDentroPrazo(Integer totalDentroPrazo) {
		this.totalDentroPrazo = totalDentroPrazo;
	}

	public Integer getTotalForaPrazo() {
		return totalForaPrazo;
	}

	public void setTotalForaPrazo(Integer totalForaPrazo) {
		this.totalForaPrazo = totalForaPrazo;
	}

	public Double getPercentualTotalDentroPrazo() {
		return percentualTotalDentroPrazo;
	}

	public void setPercentualTotalDentroPrazo(Double percentualTotalDentroPrazo) {
		this.percentualTotalDentroPrazo = percentualTotalDentroPrazo;
	}

	public Double getPercentualTotalForaPrazo() {
		return percentualTotalForaPrazo;
	}

	public void setPercentualTotalForaPrazo(Double percentualTotalForaPrazo) {
		this.percentualTotalForaPrazo = percentualTotalForaPrazo;
	}

	public Boolean getFlagTotalizador() {
		return flagTotalizador;
	}

	public void setFlagTotalizador(Boolean flagTotalizador) {
		this.flagTotalizador = flagTotalizador;
	}

	public Integer getIdOperacao() {
		return idOperacao;
	}

	public void setIdOperacao(Integer idOperacao) {
		this.idOperacao = idOperacao;
	}

	public List<CasoTO> getCasos() {
		if (casos == null) {
			casos = new ArrayList<CasoTO>();
		}
		return casos;
	}

	public void setCasos(List<CasoTO> casos) {
		this.casos = casos;
	}


	public boolean equalsProperties(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CasoClassificadoCockpitTO other = (CasoClassificadoCockpitTO) obj;
		if (eventoPai == null) {
			if (other.eventoPai != null)
				return false;
		} else if (!eventoPai.equals(other.eventoPai))
			return false;
		if (idOperacao == null) {
			if (other.idOperacao != null)
				return false;
		} else if (!idOperacao.equals(other.idOperacao))
			return false;
		if (nomeDiv == null) {
			if (other.nomeDiv != null)
				return false;
		} else if (!nomeDiv.equals(other.nomeDiv))
			return false;
		if (tipoCaso == null) {
			if (other.tipoCaso != null)
				return false;
		} else if (!tipoCaso.equals(other.tipoCaso))
			return false;
		if (top == null) {
			if (other.top != null)
				return false;
		} else if (!top.equals(other.top))
			return false;
		if (totalDentroPrazo == null) {
			if (other.totalDentroPrazo != null)
				return false;
		} else if (!totalDentroPrazo.equals(other.totalDentroPrazo))
			return false;
		if (totalForaPrazo == null) {
			if (other.totalForaPrazo != null)
				return false;
		} else if (!totalForaPrazo.equals(other.totalForaPrazo))
			return false;
		if (volumeDentroPrazo == null) {
			if (other.volumeDentroPrazo != null)
				return false;
		} else if (!volumeDentroPrazo.equals(other.volumeDentroPrazo))
			return false;
		if (volumeForaPrazo == null) {
			if (other.volumeForaPrazo != null)
				return false;
		} else if (!volumeForaPrazo.equals(other.volumeForaPrazo))
			return false;
		if (volumeTotal == null) {
			if (other.volumeTotal != null)
				return false;
		} else if (!volumeTotal.equals(other.volumeTotal))
			return false;
		return true;
	}
	
	

}
