package br.com.callink.cad.to;

import java.io.Serializable;
import java.util.Date;

public class CasoDeletadoTO implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Integer idCasoDeletado;
	private Integer idCaso;
	private String idExterno;
	private Date dataCadastro;
	private Integer idLoteCaso;
	private Date dataExclusao;
	private Integer idUsuarioExclusao;
	
	public Integer getIdCasoDeletado() {
		return idCasoDeletado;
	}
	
	public void setIdCasoDeletado(Integer idCasoDeletado) {
		this.idCasoDeletado = idCasoDeletado;
	}
	
	public Integer getIdCaso() {
		return idCaso;
	}
	
	public void setIdCaso(Integer idCaso) {
		this.idCaso = idCaso;
	}
	
	public String getIdExterno() {
		return idExterno;
	}
	
	public void setIdExterno(String idExterno) {
		this.idExterno = idExterno;
	}
	
	public Date getDataCadastro() {
		return dataCadastro;
	}
	
	public void setDataCadastro(Date dataCadastro) {
		this.dataCadastro = dataCadastro;
	}
	
	public Integer getIdLoteCaso() {
		return idLoteCaso;
	}
	
	public void setIdLoteCaso(Integer idLoteCaso) {
		this.idLoteCaso = idLoteCaso;
	}
	
	public Date getDataExclusao() {
		return dataExclusao;
	}
	
	public void setDataExclusao(Date dataExclusao) {
		this.dataExclusao = dataExclusao;
	}
	
	public Integer getIdUsuarioExclusao() {
		return idUsuarioExclusao;
	}
	
	public void setIdUsuarioExclusao(Integer idUsuarioExclusao) {
		this.idUsuarioExclusao = idUsuarioExclusao;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((idCasoDeletado == null) ? 0 : idCasoDeletado.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CasoDeletadoTO other = (CasoDeletadoTO) obj;
		if (idCasoDeletado == null) {
			if (other.idCasoDeletado != null)
				return false;
		} else if (!idCasoDeletado.equals(other.idCasoDeletado))
			return false;
		return true;
	}
	
}
