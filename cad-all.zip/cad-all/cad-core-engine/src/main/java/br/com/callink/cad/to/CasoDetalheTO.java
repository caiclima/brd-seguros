package br.com.callink.cad.to;

import java.io.Serializable;

public class CasoDetalheTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer idCasoDetalhe;
	
	private CasoTO caso;
	
    private DadosDinamicos[] dadosDinamicos;
	
	public CasoDetalheTO() {
	}
	
	public CasoDetalheTO(Integer idCasoDetalhe) {
		this.idCasoDetalhe = idCasoDetalhe;
	}
	
	public Integer getIdCasoDetalhe() {
		return idCasoDetalhe;
	}
	
	public void setIdCasoDetalhe(Integer idCasoDetalhe) {
		this.idCasoDetalhe = idCasoDetalhe;
	}

	public CasoTO getCaso() {
		return caso;
	}

	public void setCaso(CasoTO caso) {
		this.caso = caso;
	}

	public DadosDinamicos[] getDadosDinamicos() {
		return dadosDinamicos;
	}
	
	public void setDadosDinamicos(DadosDinamicos[] dadosDinamicos) {
		this.dadosDinamicos = dadosDinamicos.clone();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((idCasoDetalhe == null) ? 0 : idCasoDetalhe.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CasoDetalheTO other = (CasoDetalheTO) obj;
		if (idCasoDetalhe == null) {
			if (other.idCasoDetalhe != null)
				return false;
		} else if (!idCasoDetalhe.equals(other.idCasoDetalhe))
			return false;
		return true;
	}
}
