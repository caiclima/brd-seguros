package br.com.callink.cad.to;

import java.io.Serializable;
import java.util.List;

public class CasoFindTO implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Long slaEmMinutos;
	private Long slaEmMinutosMaior;
	private Integer idOperacao;
	private FiltroDadosDinamicosTO[] filtroDadosDinamicos;
	private List<FiltroCasoCampoTO> listFiltroCasoCampos;
	private List<ExportaCasoSchedulerDataTO> datasExportaCasoScheduler;

	public CasoFindTO() {
	}
	
	public Long getSlaEmMinutos() {
		return slaEmMinutos;
	}

	public void setSlaEmMinutos(Long slaEmMinutos) {
		this.slaEmMinutos = slaEmMinutos;
	}

	public Long getSlaEmMinutosMaior() {
		return slaEmMinutosMaior;
	}

	public void setSlaEmMinutosMaior(Long slaEmMinutosMaior) {
		this.slaEmMinutosMaior = slaEmMinutosMaior;
	}

	public FiltroDadosDinamicosTO[] getFiltroDadosDinamicos() {
		return filtroDadosDinamicos;
	}

	public void setFiltroDadosDinamicos(FiltroDadosDinamicosTO[] filtroDadosDinamicos) {
		if (filtroDadosDinamicos != null) {
			this.filtroDadosDinamicos = filtroDadosDinamicos.clone();
		} else {
			this.filtroDadosDinamicos = null;
		}
	}

	public CampoDinamicoTO[] obterCamposDinamicos() {
		if (filtroDadosDinamicos != null) {
			CampoDinamicoTO[] campos = new CampoDinamicoTO[filtroDadosDinamicos.length];
			for (int i = 0; i < filtroDadosDinamicos.length; i++) {
				if (filtroDadosDinamicos[i] != null) {
					campos[i] = filtroDadosDinamicos[i].CAMPO_DINAMICO;
				}
			}
			return campos;
		}
		return null;
	}

	public Integer getIdOperacao() {
		return idOperacao;
	}

	public void setIdOperacao(Integer idOperacao) {
		this.idOperacao = idOperacao;
	}

	public List<FiltroCasoCampoTO> getListFiltroCasoCampos() {
		return listFiltroCasoCampos;
	}

	public void setListFiltroCasoCampos(List<FiltroCasoCampoTO> listFiltroCasoCampos) {
		this.listFiltroCasoCampos = listFiltroCasoCampos;
	}

	public List<ExportaCasoSchedulerDataTO> getDatasExportaCasoScheduler() {
		return datasExportaCasoScheduler;
	}

	public void setDatasExportaCasoScheduler(List<ExportaCasoSchedulerDataTO> datasExportaCasoScheduler) {
		this.datasExportaCasoScheduler = datasExportaCasoScheduler;
	}

}
