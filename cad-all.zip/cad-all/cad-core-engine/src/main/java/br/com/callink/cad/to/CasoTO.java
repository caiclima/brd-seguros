package br.com.callink.cad.to;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

/**
 * @author swb.brunocamargo
 * 
 */
public class CasoTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String statusNome;
	private String nomeJuncao;
	private String nomeOutraArea;
	private String nomeSlaFila;
	private String nomeCanal;
	private String nomeCausa;
	private Integer idCaso;
	private Integer idUsuario;
	private Integer idUsuarioSugerido;
	private boolean flagReclassificaReabertura;
	private boolean flagClassifica;
	private boolean flagFinalizado;
	private Integer idConfiguracaoFila;
	private String idExterno;
	private Date dataEncerramento;
	private Date dataCadastro;
	private Date dataAbertura;
	private Date dataPrevistaFimSla;
	private Date dataFimSla;
	private Integer idCasoPai;
	private Integer idCanal;
	private Integer idCausa;
	private Integer classificacaoCount;
	private String descricao;
	private Integer edicaoTelefoneCount;
	private Boolean flagCriadoManual;
	private Boolean flagEmAtendimento;
	private Boolean flagReaberto;
	private Boolean flagTelefoneEditado;
	private Integer idJuncao; 
	private Integer idOutraArea;
	private Integer idSlaFila;
	
	// nao pertence a tabela caso, usado apenas na JobNotificaCasoNaoClassificado
	private Date dataUltimoLog;
	private String nomeConfiguracaoFila;
	private Integer idTipoCaso;
	private String nomeTipoCaso;
	private Integer idOperacao;
	private SlaFilaTO slaFilaTO;
	private Integer idStatus;
	private Integer idEvento;
	private Integer motivo1;
	private Integer motivo2;
	private Integer motivo3;
	private Integer motivo4;
	private Integer motivo5;
	private Integer motivo6;
	private String motivo1Nome;
	private String motivo2Nome;
	private String motivo3Nome;
	private String motivo4Nome;
	private String motivo5Nome;
	private String motivo6Nome;
	private String slaEmMinutos;
	private Double porcentagemSla;
	private String iconeSla;
	private String slaTotalMinutos;
	private String mnemonico;

	private String loginUsuario;
	private String loginUsuarioSugerido;
	private String nomeStatus;
	private String nomeOperacao;
	private Date dataAlteracao;
	private String nomeEvento;
	private String corStatus;
	private Integer idLoteCaso;
	private String nomeArquivo;
	private DadosDinamicos[] dadosDinamicos;

	public CasoTO() {
	}

	public CasoTO(Integer idCaso) {
		this.idCaso = idCaso;
	}

	public Integer getIdCaso() {
		return idCaso;
	}

	public void setIdCaso(Integer idCaso) {
		this.idCaso = idCaso;
	}

	public Integer getIdUsuario() {
		return idUsuario;
	}

	public void setIdUsuario(Integer idUsuario) {
		this.idUsuario = idUsuario;
	}
	
	public Integer getIdUsuarioSugerido() {
		return idUsuarioSugerido;
	}
	
	public void setIdUsuarioSugerido(Integer idUsuarioSugerido) {
		this.idUsuarioSugerido = idUsuarioSugerido;
	}

	public boolean isFlagReclassificaReabertura() {
		return flagReclassificaReabertura;
	}

	public void setFlagReclassificaReabertura(boolean flagReclassificaReabertura) {
		this.flagReclassificaReabertura = flagReclassificaReabertura;
	}

	public boolean isFlagClassifica() {
		return flagClassifica;
	}

	public void setFlagClassifica(boolean flagClassifica) {
		this.flagClassifica = flagClassifica;
	}

	public boolean isFlagFinalizado() {
		return flagFinalizado;
	}

	public void setFlagFinalizado(boolean flagFinalizado) {
		this.flagFinalizado = flagFinalizado;
	}

	public Integer getIdConfiguracaoFila() {
		return idConfiguracaoFila;
	}

	public Date getDataFimSla() {
		return dataFimSla;
	}

	public void setDataFimSla(Date dataFimSla) {
		this.dataFimSla = dataFimSla;
	}

	public Date getDataEncerramento() {
		return dataEncerramento;
	}

	public void setDataEncerramento(Date dataEncerramento) {
		this.dataEncerramento = dataEncerramento;
	}
	
	public Date getDataPrevistaFimSla() {
		return dataPrevistaFimSla;
	}
	
	public void setDataPrevistaFimSla(Date dataPrevistaFimSla) {
		this.dataPrevistaFimSla = dataPrevistaFimSla == null ? null : new Date(dataPrevistaFimSla.getTime());;
	}

	public String getSlaEmMinutos() {
		return slaEmMinutos;
	}

	public void setSlaEmMinutos(String slaEmMinutos) {
		this.slaEmMinutos = slaEmMinutos;
	}

	public Double getPorcentagemSla() {
		return porcentagemSla;
	}

	public void setPorcentagemSla(Double porcentagemSla) {
		this.porcentagemSla = porcentagemSla;
	}

	public void setIdConfiguracaoFila(Integer idConfiguracaoFila) {
		this.idConfiguracaoFila = idConfiguracaoFila;
	}

	public Date getDataAbertura() {
		return dataAbertura;
	}

	public void setDataAbertura(Date dataAbertura) {
		this.dataAbertura = dataAbertura;
	}

	public String getIdExterno() {
		return idExterno;
	}

	public void setIdExterno(String idExterno) {
		this.idExterno = idExterno;
	}

	public Date getDataCadastro() {
		return dataCadastro;
	}

	public Integer getIdSlaFila() {
		return idSlaFila;
	}

	public void setIdSlaFila(Integer idSlaFila) {
		this.idSlaFila = idSlaFila;
	}

	public void setDataCadastro(Date dataCadastro) {
		this.dataCadastro = dataCadastro;
	}

	public String getNomeConfiguracaoFila() {
		return nomeConfiguracaoFila;
	}

	public void setNomeConfiguracaoFila(String nomeConfiguracaoFila) {
		this.nomeConfiguracaoFila = nomeConfiguracaoFila;
	}

	public Integer getIdTipoCaso() {
		return idTipoCaso;
	}

	public void setIdTipoCaso(Integer idTipoCaso) {
		this.idTipoCaso = idTipoCaso;
	}

	public String getNomeTipoCaso() {
		return nomeTipoCaso;
	}

	public void setNomeTipoCaso(String nomeTipoCaso) {
		this.nomeTipoCaso = nomeTipoCaso;
	}

	public Integer getIdJuncao() {
		return idJuncao;
	}

	public void setIdJuncao(Integer idJuncao) {
		this.idJuncao = idJuncao;
	}

	public Integer getIdOperacao() {
		return idOperacao;
	}

	public void setIdOperacao(Integer idOperacao) {
		this.idOperacao = idOperacao;
	}

	public SlaFilaTO getSlaFilaTO() {
		return slaFilaTO;
	}

	public void setSlaFilaTO(SlaFilaTO slaFilaTO) {
		this.slaFilaTO = slaFilaTO;
	}

	public Integer getIdOutraArea() {
		return idOutraArea;
	}

	public void setIdOutraArea(Integer idOutraArea) {
		this.idOutraArea = idOutraArea;
	}

	public Integer getIdStatus() {
		return idStatus;
	}

	public Integer getEdicaoTelefoneCount() {
		return edicaoTelefoneCount;
	}

	public void setEdicaoTelefoneCount(Integer edicaoTelefoneCount) {
		this.edicaoTelefoneCount = edicaoTelefoneCount;
	}

	public void setIdStatus(Integer idStatus) {
		this.idStatus = idStatus;
	}
	
	public Integer getIdEvento() {
		return idEvento;
	}
	
	public void setIdEvento(Integer idEvento) {
		this.idEvento = idEvento;
	}

	public Integer getMotivo1() {
		return motivo1;
	}
	
	public void setMotivo1(Integer motivo1) {
		this.motivo1 = motivo1;
	}

	public Integer getMotivo2() {
		return motivo2;
	}

	public void setMotivo2(Integer motivo2) {
		this.motivo2 = motivo2;
	}

	public Integer getMotivo3() {
		return motivo3;
	}
	
	public void setMotivo3(Integer motivo3) {
		this.motivo3 = motivo3;
	}
	
	public Integer getMotivo4() {
		return motivo4;
	}
	
	public void setMotivo4(Integer motivo4) {
		this.motivo4 = motivo4;
	}
	
	public Integer getMotivo5() {
		return motivo5;
	}

	public void setMotivo5(Integer motivo5) {
		this.motivo5 = motivo5;
	}

	public Integer getMotivo6() {
		return motivo6;
	}
	
	public void setMotivo6(Integer motivo6) {
		this.motivo6 = motivo6;
	}

	public String getMotivo1Nome() {
		return motivo1Nome;
	}
	
	public void setMotivo1Nome(String motivo1Nome) {
		this.motivo1Nome = motivo1Nome;
	}
	
	public String getMotivo2Nome() {
		return motivo2Nome;
	}
	
	public void setMotivo2Nome(String motivo2Nome) {
		this.motivo2Nome = motivo2Nome;
	}

	public String getMotivo3Nome() {
		return motivo3Nome;
	}
	
	public void setMotivo3Nome(String motivo3Nome) {
		this.motivo3Nome = motivo3Nome;
	}
	
	public Integer getClassificacaoCount() {
		return classificacaoCount;
	}

	public void setClassificacaoCount(Integer classificacaoCount) {
		this.classificacaoCount = classificacaoCount;
	}

	public String getMotivo4Nome() {
		return motivo4Nome;
	}
	
	public void setMotivo4Nome(String motivo4Nome) {
		this.motivo4Nome = motivo4Nome;
	}

	public String getMotivo5Nome() {
		return motivo5Nome;
	}
	
	public void setMotivo5Nome(String motivo5Nome) {
		this.motivo5Nome = motivo5Nome;
	}

	public String getMotivo6Nome() {
		return motivo6Nome;
	}
	
	public Integer getIdCanal() {
		return idCanal;
	}

	public void setIdCanal(Integer idCanal) {
		this.idCanal = idCanal;
	}

	public Boolean getFlagEmAtendimento() {
		return flagEmAtendimento;
	}

	public Boolean getFlagTelefoneEditado() {
		return flagTelefoneEditado;
	}

	public void setFlagTelefoneEditado(Boolean flagTelefoneEditado) {
		this.flagTelefoneEditado = flagTelefoneEditado;
	}

	public void setFlagEmAtendimento(Boolean flagEmAtendimento) {
		this.flagEmAtendimento = flagEmAtendimento;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public void setMotivo6Nome(String motivo6Nome) {
		this.motivo6Nome = motivo6Nome;
	}

	public String getIconeSla() {
		return iconeSla;
	}

	public Boolean getFlagReaberto() {
		return flagReaberto;
	}

	public void setFlagReaberto(Boolean flagReaberto) {
		this.flagReaberto = flagReaberto;
	}

	public void setIconeSla(String iconeSla) {
		this.iconeSla = iconeSla;
	}

	public String getSlaTotalMinutos() {
		return slaTotalMinutos;
	}

	public Boolean getFlagCriadoManual() {
		return flagCriadoManual;
	}

	public void setFlagCriadoManual(Boolean flagCriadoManual) {
		this.flagCriadoManual = flagCriadoManual;
	}

	public void setSlaTotalMinutos(String slaTotalMinutos) {
		this.slaTotalMinutos = slaTotalMinutos;
	}
	
	public Integer getIdCasoPai() {
		return idCasoPai;
	}

	public Integer getIdCausa() {
		return idCausa;
	}

	public void setIdCausa(Integer idCausa) {
		this.idCausa = idCausa;
	}

	public void setIdCasoPai(Integer idCasoPai) {
		this.idCasoPai = idCasoPai;
	}

	public static String getSqlColuns() {
		StringBuilder sql = new StringBuilder().append("\nCaso.ID_CASO AS 'Caso.ID_CASO' ")
				.append(", ").append("\nCaso.ID_USUARIO AS 'Caso.ID_USUARIO' ")
				.append(", ").append("\nCaso.ID_CANAL AS 'Caso.ID_CANAL' ")
				.append(", ").append("\nCaso.ID_CAUSA AS 'Caso.ID_CAUSA' ")
				.append(", ").append("\nCaso.flag_reclassifica_reabertura AS 'Caso.flag_reclassifica_reabertura' ")
				.append(", ").append("\nCaso.flag_classifica AS 'Caso.flag_classifica' ")
				.append(", ").append("\nCaso.id_configuracao_fila AS 'Caso.id_configuracao_fila' ")
				.append(", ").append("\nCaso.id_sla_fila AS 'Caso.id_sla_fila' ")
				.append(", ").append("\nCaso.data_abertura AS 'Caso.data_abertura' ")
				.append(", ").append("\nCaso.data_fim_sla AS 'Caso.data_fim_sla' ")
				.append(", ").append("\nCaso.data_cadastro AS 'Caso.data_cadastro' ")
				.append(", ").append("\nCaso.data_prevista_fim_sla AS 'Caso.data_prevista_fim_sla' ")
				.append(", ").append("\nCaso.id_usuario_sugerido AS 'Caso.id_usuario_sugerido' ")
				.append(", ").append("\nCaso.id_externo AS 'Caso.id_externo' ")
				.append(", ").append("\nCaso.id_evento AS 'Caso.id_evento' ")
				.append(", ").append("\nCaso.motivo_1 AS 'Caso.motivo_1' ")
				.append(", ").append("\nCaso.motivo_2 AS 'Caso.motivo_2' ")
				.append(", ").append("\nCaso.motivo_3 AS 'Caso.motivo_3' ")
				.append(", ").append("\nCaso.motivo_4 AS 'Caso.motivo_4' ")
				.append(", ").append("\nCaso.motivo_5 AS 'Caso.motivo_5' ")
				.append(", ").append("\nCaso.motivo_6 AS 'Caso.motivo_6' ")
				.append(", ").append("\nCaso.motivo_1_nome AS 'Caso.motivo_1_nome' ")
				.append(", ").append("\nCaso.motivo_2_nome AS 'Caso.motivo_2_nome' ")
				.append(", ").append("\nCaso.motivo_3_nome AS 'Caso.motivo_3_nome' ")
				.append(", ").append("\nCaso.motivo_4_nome AS 'Caso.motivo_4_nome' ")
				.append(", ").append("\nCaso.motivo_5_nome AS 'Caso.motivo_5_nome' ")
				.append(", ").append("\nCaso.motivo_6_nome AS 'Caso.motivo_6_nome' ")
				.append(", ").append("\nCaso.id_status AS 'Caso.id_status' ")
				.append(", ").append("\nCaso.id_operacao AS 'Caso.id_operacao' ")
				.append(", ").append("\nCaso.id_tipo_caso AS 'Caso.id_tipo_caso' ");

		return sql.toString();
	}

	public static String getSqlFrom() {
		StringBuilder sql = new StringBuilder().append(" FROM ").append(" TB_CASO  AS Caso with(nolock) ");

		return sql.toString();
	}

	public static CasoTO getCasoTOByResultSet(ResultSet resultSet) {
		try {
			if (resultSet.getInt("Caso.ID_CASO") == 0) {
				return null;
			}
			CasoTO to = new CasoTO();

			setCamposCaso(resultSet, to);
			
			return to;

		} catch (SQLException ex) {
			throw new IllegalArgumentException("Erro ao montar objeto a partir do ResultSet", ex);
		}
	}

	private static void setCamposCaso(ResultSet resultSet, CasoTO to)
			throws SQLException {
			to.setIdCaso((Integer) resultSet.getObject("Caso.ID_CASO"));
			to.setIdUsuario((Integer) resultSet.getObject("Caso.ID_USUARIO"));
			to.setIdCanal((Integer) resultSet.getObject("Caso.ID_CANAL"));
			to.setIdCausa((Integer) resultSet.getObject("Caso.ID_CAUSA"));
			to.setIdUsuarioSugerido((Integer) resultSet.getObject("Caso.id_usuario_sugerido"));
			to.setFlagReclassificaReabertura(resultSet.getBoolean("Caso.flag_reclassifica_reabertura"));
			to.setFlagClassifica(resultSet.getBoolean("Caso.flag_classifica"));
			to.setIdConfiguracaoFila((Integer) resultSet.getObject("Caso.id_configuracao_fila"));
			to.setSlaFilaTO(resultSet.getObject("Caso.id_sla_fila") != null ? new SlaFilaTO((Integer) resultSet.getObject("Caso.id_sla_fila")) : null);
			to.setDataAbertura(resultSet.getTimestamp("Caso.data_abertura"));
			to.setIdExterno((String) resultSet.getObject("Caso.id_externo"));
			to.setDataCadastro(resultSet.getTimestamp("Caso.data_cadastro"));
			to.setDataPrevistaFimSla(resultSet.getTimestamp("Caso.data_prevista_fim_sla"));
			to.setIdStatus((Integer) resultSet.getObject("Caso.id_status"));
			to.setIdEvento((Integer) resultSet.getObject("Caso.id_evento"));
			to.setMotivo1((Integer) resultSet.getObject("Caso.motivo_1"));
			to.setMotivo2((Integer) resultSet.getObject("Caso.motivo_2"));
			to.setMotivo3((Integer) resultSet.getObject("Caso.motivo_3"));
			to.setMotivo4((Integer) resultSet.getObject("Caso.motivo_4"));
			to.setMotivo5((Integer) resultSet.getObject("Caso.motivo_5"));
			to.setMotivo6((Integer) resultSet.getObject("Caso.motivo_6"));
			to.setMotivo1Nome((String) resultSet.getObject("Caso.motivo_1_nome"));
			to.setMotivo2Nome((String) resultSet.getObject("Caso.motivo_2_nome"));
			to.setMotivo3Nome((String) resultSet.getObject("Caso.motivo_3_nome"));
			to.setMotivo4Nome((String) resultSet.getObject("Caso.motivo_4_nome"));
			to.setMotivo5Nome((String) resultSet.getObject("Caso.motivo_5_nome"));
			to.setMotivo6Nome((String) resultSet.getObject("Caso.motivo_6_nome"));
			to.setIdOperacao((Integer) resultSet.getObject("Caso.id_operacao"));
			to.setIdTipoCaso((Integer) resultSet.getObject("Caso.id_tipo_caso"));
	}
	
	public static CasoTO getCasoTOByResultSetFull(ResultSet resultSet) {
		try {
			if (resultSet.getInt("Caso.ID_CASO") == 0) {
				return null;
			}
			CasoTO to = new CasoTO();

			setCamposCaso(resultSet, to);
			
			to.setStatusNome((String) resultSet.getObject("Caso.status_nome"));
			to.setNomeTipoCaso((String) resultSet.getObject("Caso.tipo_caso_nome"));
			to.setNomeConfiguracaoFila((String) resultSet.getObject("Caso.configuracao_fila_nome"));
			to.setNomeJuncao((String) resultSet.getObject("Caso.juncao_nome"));
			to.setNomeOutraArea((String) resultSet.getObject("Caso.outra_area_nome"));
			to.setNomeSlaFila((String) resultSet.getObject("Caso.sla_fila_nome"));
			to.setNomeCanal((String) resultSet.getObject("Caso.canal_nome"));
			to.setNomeCausa((String) resultSet.getObject("Caso.causa_nome"));
			
			return to;

		} catch (SQLException ex) {
			throw new IllegalArgumentException("Erro ao montar objeto a partir do ResultSet", ex);
		}
	}

	public Date getDataUltimoLog() {
		return dataUltimoLog;
	}

	public void setDataUltimoLog(Date dataUltimoLog) {
		this.dataUltimoLog = dataUltimoLog;
	}

	public final String getStatusNome() {
		return statusNome;
	}

	public final void setStatusNome(String statusNome) {
		this.statusNome = statusNome;
	}

	public final String getNomeJuncao() {
		return nomeJuncao;
	}

	public final void setNomeJuncao(String nomeJuncao) {
		this.nomeJuncao = nomeJuncao;
	}

	public final String getNomeOutraArea() {
		return nomeOutraArea;
	}

	public final void setNomeOutraArea(String nomeOutraArea) {
		this.nomeOutraArea = nomeOutraArea;
	}

	public final String getNomeSlaFila() {
		return nomeSlaFila;
	}

	public final void setNomeSlaFila(String nomeSlaFila) {
		this.nomeSlaFila = nomeSlaFila;
	}

	public final String getNomeCanal() {
		return nomeCanal;
	}

	public final void setNomeCanal(String nomeCanal) {
		this.nomeCanal = nomeCanal;
	}

	public final String getNomeCausa() {
		return nomeCausa;
	}

	public final void setNomeCausa(String nomeCausa) {
		this.nomeCausa = nomeCausa;
	}

	public Boolean getFlagDentroPrazo() {
		if (this.porcentagemSla != null && this.porcentagemSla  > 100) {
			return Boolean.FALSE;
		} else {
			return Boolean.TRUE;
		}
	}

	public String getMnemonico() {
		return mnemonico;
	}

	public void setMnemonico(String mnemonico) {
		this.mnemonico = mnemonico;
	}

	public String getLoginUsuario() {
		return loginUsuario;
	}

	public void setLoginUsuario(String loginUsuario) {
		this.loginUsuario = loginUsuario;
	}

	public String getLoginUsuarioSugerido() {
		return loginUsuarioSugerido;
	}

	public void setLoginUsuarioSugerido(String loginUsuarioSugerido) {
		this.loginUsuarioSugerido = loginUsuarioSugerido;
	}

	public String getNomeStatus() {
		return nomeStatus;
	}

	public void setNomeStatus(String nomeStatus) {
		this.nomeStatus = nomeStatus;
	}

	public String getNomeOperacao() {
		return nomeOperacao;
	}

	public void setNomeOperacao(String nomeOperacao) {
		this.nomeOperacao = nomeOperacao;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public String getNomeEvento() {
		return nomeEvento;
	}

	public void setNomeEvento(String nomeEvento) {
		this.nomeEvento = nomeEvento;
	}

	public String getCorStatus() {
		return corStatus;
	}

	public void setCorStatus(String corStatus) {
		this.corStatus = corStatus;
	}

	public Integer getIdLoteCaso() {
		return idLoteCaso;
	}

	public void setIdLoteCaso(Integer idLoteCaso) {
		this.idLoteCaso = idLoteCaso;
	}

	public String getNomeArquivo() {
		return nomeArquivo;
	}

	public void setNomeArquivo(String nomeArquivo) {
		this.nomeArquivo = nomeArquivo;
	}

	public DadosDinamicos[] getDadosDinamicos() {
		if (dadosDinamicos != null) {
			dadosDinamicos = dadosDinamicos.clone();
		}
		else{
			dadosDinamicos = new DadosDinamicos[0];
		}
		return dadosDinamicos;
	}

	public void setDadosDinamicos(DadosDinamicos[] dadosDinamicos) {
		if (dadosDinamicos != null) {
			this.dadosDinamicos = dadosDinamicos.clone();
		} else {
			this.dadosDinamicos = dadosDinamicos;
		}
	}
	
	public CasoDetalheTO buildCasoDetalhe() {
		CasoDetalheTO caso = new CasoDetalheTO();
		caso.setDadosDinamicos(getDadosDinamicos());
		return caso;
	}
	
}
