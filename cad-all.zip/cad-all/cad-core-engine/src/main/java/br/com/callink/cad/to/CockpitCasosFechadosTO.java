package br.com.callink.cad.to;

import java.io.Serializable;
import java.util.Date;

/**
 * @author swb_samuel
 *
 */
public class CockpitCasosFechadosTO implements Serializable {
	
	private static final long serialVersionUID = 1L;

	private Integer idCaso;
	private Date dataFim;
	private String idExterno;
	private Integer idConfiguracaoFila;
	private String nomeFila;
	private Integer idUsuario;
	private String loginUsuario;
	private Integer idEquipe;
	private String nomeEquipe;
	private Integer idOperacao;
	private Integer sla;
	private boolean flagSlaDentroPrazo;
	private String nomeUsuario;
	
	public Integer getIdCaso() {
		return idCaso;
	}

	public void setIdCaso(Integer idCaso) {
		this.idCaso = idCaso;
	}
	
	public Date getDataFim() {
		return dataFim;
	}

	public void setDataFim(Date dataFim) {
		this.dataFim = dataFim;
	}
	
	public String getIdExterno() {
		return idExterno;
	}
	
	public void setIdExterno(String idExterno) {
		this.idExterno = idExterno;
	}
	
	public Integer getIdConfiguracaoFila() {
		return idConfiguracaoFila;
	}
	
	public void setIdConfiguracaoFila(Integer idConfiguracaoFila) {
		this.idConfiguracaoFila = idConfiguracaoFila;
	}
	
	public String getNomeFila() {
		return nomeFila;
	}

	public void setNomeFila(String nomeFila) {
		this.nomeFila = nomeFila;
	}
	
	public Integer getIdUsuario() {
		return idUsuario;
	}
	
	public void setIdUsuario(Integer idUsuario) {
		this.idUsuario = idUsuario;
	}
	
	public String getLoginUsuario() {
		return loginUsuario;
	}

	public void setLoginUsuario(String loginUsuario) {
		this.loginUsuario = loginUsuario;
	}
	
	public Integer getIdEquipe() {
		return idEquipe;
	}
	
	public void setIdEquipe(Integer idEquipe) {
		this.idEquipe = idEquipe;
	}

	public String getNomeEquipe() {
		return nomeEquipe;
	}

	public void setNomeEquipe(String nomeEquipe) {
		this.nomeEquipe = nomeEquipe;
	}
	
	public Integer getIdOperacao() {
		return idOperacao;
	}
	
	public void setIdOperacao(Integer idOperacao) {
		this.idOperacao = idOperacao;
	}
	
	public Integer getSla() {
		return sla;
	}

	public void setSla(Integer sla) {
		this.sla = sla;
	}

	public boolean isFlagSlaDentroPrazo() {
		return flagSlaDentroPrazo;
	}

	public void setFlagSlaDentroPrazo(boolean flagSlaDentroPrazo) {
		this.flagSlaDentroPrazo = flagSlaDentroPrazo;
	}

	public String getNomeUsuario() {
		return nomeUsuario;
	}

	public void setNomeUsuario(String nomeUsuario) {
		this.nomeUsuario = nomeUsuario;
	}

	public static String getSqlColuns(){
		StringBuilder sql = new StringBuilder()
		 .append("\nCaso.ID_CASO AS 'Caso.ID_CASO' ")
		 .append(", ")
		 .append("\nCaso.DATA_FIM_SLA AS 'Caso.DATA_FIM_SLA' ")
		 .append(", ")
		 .append("\nCaso.ID_EXTERNO AS 'Caso.ID_EXTERNO' ")
		 .append(", ")
		 .append("\nConfiguracaoFila.ID_CONFIGURACAO_FILA AS 'ConfiguracaoFila.ID_CONFIGURACAO_FILA' ")
		 .append(", ")
		 .append("\nConfiguracaoFila.NOME AS 'ConfiguracaoFila.NOME' ")
		 .append(", ")
		 .append("\nCaso.ID_OPERACAO AS 'Caso.ID_OPERACAO' ")
		 .append(", ")
		 .append("\nUsuario.ID_USUARIO AS 'Usuario.ID_USUARIO' ")
		 .append(", ")
		 .append("\nUsuario.LOGIN AS 'Usuario.LOGIN' ")
		 .append(", ")
		 .append("\nUsuario.NOME AS 'Usuario.NOME' ")
		 .append(", ")
		 .append("\nEquipe.ID_EQUIPE AS 'Equipe.ID_EQUIPE' ")
		 .append(", ")
		 .append("\nEquipe.NOME AS 'Equipe.NOME' ")
		 .append(", ")
		 .append("\nCASE WHEN Caso.sla_minutos IS NOT NULL AND Caso.sla_minutos <> '0' ")
		 .append("\nTHEN (SUBSTRING (Caso.sla_minutos , 1 , CHARINDEX(':',Caso.sla_minutos) - 1) * 60 ) + (SUBSTRING (Caso.sla_minutos , CHARINDEX(':',Caso.sla_minutos)+1 , 2)) ")
		 .append("\nELSE 0  ")
		 .append("\nEND ")
		 .append("\nAS 'Caso.SLA_MINUTOS' ")
		 .append(", ")
		 .append("\nCASE when Caso.sla_minutos IS NULL then 1 when Caso.percentual_sla < 100 then 1 else 0 end AS 'Caso.PERCENTUAL_SLA' ");
		
		return sql.toString();
	}
	
	public static String getSqlFrom(){
		StringBuilder sql = new StringBuilder()
			.append("FROM ")
			.append(" TB_CASO  AS Caso with(nolock) ")
			.append("INNER JOIN ")
			.append("TB_TIPO_CASO  AS TipoCaso with(nolock) ")
			.append("ON Caso.ID_TIPO_CASO = TipoCaso.ID_TIPO_CASO ")
			.append("INNER JOIN ")
			.append("TB_CONFIGURACAO_FILA  AS ConfiguracaoFila with(nolock) ")
			.append("ON Caso.ID_CONFIGURACAO_FILA = ConfiguracaoFila.ID_CONFIGURACAO_FILA ")
			.append("LEFT JOIN ")
			.append("TB_USUARIO As Usuario with(nolock) ")
			.append("ON Caso.ID_USUARIO = Usuario.ID_USUARIO ")
			.append("INNER JOIN ")
			.append("TB_EQUIPE AS Equipe with(nolock) ")
			.append("ON Usuario.ID_EQUIPE = Equipe.ID_EQUIPE ");
		
		return sql.toString();
	}
}
