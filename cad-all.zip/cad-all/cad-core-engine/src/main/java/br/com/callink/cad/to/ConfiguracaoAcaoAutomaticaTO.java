package br.com.callink.cad.to;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ConfiguracaoAcaoAutomaticaTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer idConfiguracaoAcaoAutomatica;
	private String acao;
	private Integer idTipoCasoFiltro;
	private Integer idStatusFiltro;
	private Integer idEventoFiltro;
	private String dataFiltro;
	private Integer horasComparacao;
	private String tipoComparacao;
	private Integer idConfiguracaoCaixaEmail;
	private String destinatarioEmail;
	private String conteudoEmail;
	private Integer idLayoutAlteracao;
	private Integer idStatusDestino;
	private String tipoConfiguracao;
	private Integer idOperacao;
	private String restringirEmail;
	private String ignorarEmail;
	private Integer idEmailModelo;
	
	public ConfiguracaoAcaoAutomaticaTO() {
	}
	
	public Integer getIdConfiguracaoAcaoAutomatica() {
		return idConfiguracaoAcaoAutomatica;
	}
	
	public void setIdConfiguracaoAcaoAutomatica(Integer idConfiguracaoAcaoAutomatica) {
		this.idConfiguracaoAcaoAutomatica = idConfiguracaoAcaoAutomatica;
	}
	
	public String getAcao() {
		return acao;
	}
	
	public void setAcao(String acao) {
		this.acao = acao;
	}
	
	public Integer getIdTipoCasoFiltro() {
		return idTipoCasoFiltro;
	}
	
	public void setIdTipoCasoFiltro(Integer idTipoCasoFiltro) {
		this.idTipoCasoFiltro = idTipoCasoFiltro;
	}
	
	public Integer getIdStatusFiltro() {
		return idStatusFiltro;
	}
	
	public void setIdStatusFiltro(Integer idStatusFiltro) {
		this.idStatusFiltro = idStatusFiltro;
	}
	
	public Integer getIdEventoFiltro() {
		return idEventoFiltro;
	}
	
	public void setIdEventoFiltro(Integer idEventoFiltro) {
		this.idEventoFiltro = idEventoFiltro;
	}
	
	public String getDataFiltro() {
		return dataFiltro;
	}
	
	public void setDataFiltro(String dataFiltro) {
		this.dataFiltro = dataFiltro;
	}
	
	public Integer getHorasComparacao() {
		return horasComparacao;
	}
	
	public void setHorasComparacao(Integer horasComparacao) {
		this.horasComparacao = horasComparacao;
	}
	
	public String getTipoComparacao() {
		return tipoComparacao;
	}
	
	public void setTipoComparacao(String tipoComparacao) {
		this.tipoComparacao = tipoComparacao;
	}
	
	public Integer getIdConfiguracaoCaixaEmail() {
		return idConfiguracaoCaixaEmail;
	}
	
	public void setIdConfiguracaoCaixaEmail(Integer idConfiguracaoCaixaEmail) {
		this.idConfiguracaoCaixaEmail = idConfiguracaoCaixaEmail;
	}
	
	public String getDestinatarioEmail() {
		return destinatarioEmail;
	}

	public void setDestinatarioEmail(String destinatarioEmail) {
		this.destinatarioEmail = destinatarioEmail;
	}

	public String getConteudoEmail() {
		return conteudoEmail;
	}
	
	public void setConteudoEmail(String conteudoEmail) {
		this.conteudoEmail = conteudoEmail;
	}
	
	public Integer getIdLayoutAlteracao() {
		return idLayoutAlteracao;
	}
	
	public void setIdLayoutAlteracao(Integer idLayoutAlteracao) {
		this.idLayoutAlteracao = idLayoutAlteracao;
	}
	
	public Integer getIdStatusDestino() {
		return idStatusDestino;
	}
	
	public void setIdStatusDestino(Integer idStatusDestino) {
		this.idStatusDestino = idStatusDestino;
	}
	
	public String getTipoConfiguracao() {
		return tipoConfiguracao;
	}
	
	public void setTipoConfiguracao(String tipoConfiguracao) {
		this.tipoConfiguracao = tipoConfiguracao;
	}
	
	public Integer getIdOperacao() {
		return idOperacao;
	}
	
	public void setIdOperacao(Integer idOperacao) {
		this.idOperacao = idOperacao;
	}

	public String getRestringirEmail() {
		return restringirEmail;
	}

	public final Integer getIdEmailModelo() {
		return idEmailModelo;
	}

	public final void setIdEmailModelo(Integer idEmailModelo) {
		this.idEmailModelo = idEmailModelo;
	}

	public void setRestringirEmail(String restringirEmail) {
		this.restringirEmail = restringirEmail;
	}

	public String getIgnorarEmail() {
		return ignorarEmail;
	}

	public void setIgnorarEmail(String ignorarEmail) {
		this.ignorarEmail = ignorarEmail;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((idConfiguracaoAcaoAutomatica == null) ? 0
						: idConfiguracaoAcaoAutomatica.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ConfiguracaoAcaoAutomaticaTO other = (ConfiguracaoAcaoAutomaticaTO) obj;
		if (idConfiguracaoAcaoAutomatica == null) {
			if (other.idConfiguracaoAcaoAutomatica != null)
				return false;
		} else if (!idConfiguracaoAcaoAutomatica
				.equals(other.idConfiguracaoAcaoAutomatica))
			return false;
		return true;
	}
	
	public static String getSqlCamposConfiguracaoAcaoAutomatica() {
        return new StringBuilder()
                .append(" \nConfiguracaoAcaoAutomatica.ID_CONFIGURACAO_ACAO_AUTOMATICA AS 'ConfiguracaoAcaoAutomatica.ID_CONFIGURACAO_ACAO_AUTOMATICA', ")
                .append(" \nConfiguracaoAcaoAutomatica.ACAO AS 'ConfiguracaoAcaoAutomatica.ACAO', ")
                .append(" \nConfiguracaoAcaoAutomatica.ID_TIPO_CASO_FILTRO AS 'ConfiguracaoAcaoAutomatica.ID_TIPO_CASO_FILTRO', ")
                .append(" \nConfiguracaoAcaoAutomatica.ID_STATUS_FILTRO AS 'ConfiguracaoAcaoAutomatica.ID_STATUS_FILTRO', ")
                .append(" \nConfiguracaoAcaoAutomatica.ID_EVENTO_FILTRO AS 'ConfiguracaoAcaoAutomatica.ID_EVENTO_FILTRO', ")
                .append(" \nConfiguracaoAcaoAutomatica.DATA_FILTRO AS 'ConfiguracaoAcaoAutomatica.DATA_FILTRO', ")
                .append(" \nConfiguracaoAcaoAutomatica.HORAS_COMPARACAO AS 'ConfiguracaoAcaoAutomatica.HORAS_COMPARACAO', ")
                .append(" \nConfiguracaoAcaoAutomatica.ID_CONFIGURACAO_CAIXA_EMAIL AS 'ConfiguracaoAcaoAutomatica.ID_CONFIGURACAO_CAIXA_EMAIL', ")
                .append(" \nConfiguracaoAcaoAutomatica.CONTEUDO_EMAIL AS 'ConfiguracaoAcaoAutomatica.CONTEUDO_EMAIL', ")
                .append(" \nConfiguracaoAcaoAutomatica.ID_LAYOUT_ALTERACAO AS 'ConfiguracaoAcaoAutomatica.ID_LAYOUT_ALTERACAO', ")
                .append(" \nConfiguracaoAcaoAutomatica.ID_STATUS_DESTINO AS 'ConfiguracaoAcaoAutomatica.ID_STATUS_DESTINO', ")
                .append(" \nConfiguracaoAcaoAutomatica.ID_EMAIL_MODELO AS 'ConfiguracaoAcaoAutomatica.ID_EMAIL_MODELO', ")
                .append(" \nConfiguracaoAcaoAutomatica.ID_OPERACAO AS 'ConfiguracaoAcaoAutomatica.ID_OPERACAO', ")
                .append(" \nConfiguracaoAcaoAutomatica.TIPO_CONFIGURACAO AS 'ConfiguracaoAcaoAutomatica.TIPO_CONFIGURACAO', ")
                .append(" \nConfiguracaoAcaoAutomatica.DESTINATARIO_EMAIL AS 'ConfiguracaoAcaoAutomatica.DESTINATARIO_EMAIL', ")
                .append(" \nConfiguracaoAcaoAutomatica.TIPO_COMPARACAO AS 'ConfiguracaoAcaoAutomatica.TIPO_COMPARACAO', ")
                .append(" \nConfiguracaoAcaoAutomatica.RESTRINGIR_EMAIL AS 'ConfiguracaoAcaoAutomatica.RESTRINGIR_EMAIL', ")
                .append(" \nConfiguracaoAcaoAutomatica.IGNORAR_EMAIL AS 'ConfiguracaoAcaoAutomatica.IGNORAR_EMAIL' ").toString();
    }

    public static String getSqlFromConfiguracaoAcaoAutomatica() {
        return " TB_CONFIGURACAO_ACAO_AUTOMATICA AS ConfiguracaoAcaoAutomatica with(nolock) ";
    }
    
    public static ConfiguracaoAcaoAutomaticaTO getConfiguracaoAcaoAutomaticaByResultSet(ResultSet rs) {
        try {
        	if (rs.getInt("ConfiguracaoAcaoAutomatica.ID_CONFIGURACAO_ACAO_AUTOMATICA") == 0) {
        		return null;
        	}
        	ConfiguracaoAcaoAutomaticaTO configuracaoAcaoAutomaticaTO = new ConfiguracaoAcaoAutomaticaTO();
        	configuracaoAcaoAutomaticaTO.setIdConfiguracaoAcaoAutomatica(rs.getInt("ConfiguracaoAcaoAutomatica.ID_CONFIGURACAO_ACAO_AUTOMATICA"));
        	configuracaoAcaoAutomaticaTO.setAcao(rs.getString("ConfiguracaoAcaoAutomatica.ACAO"));
        	configuracaoAcaoAutomaticaTO.setIdTipoCasoFiltro((Integer) rs.getObject("ConfiguracaoAcaoAutomatica.ID_TIPO_CASO_FILTRO"));
        	configuracaoAcaoAutomaticaTO.setIdStatusFiltro((Integer) rs.getObject("ConfiguracaoAcaoAutomatica.ID_STATUS_FILTRO"));
        	configuracaoAcaoAutomaticaTO.setIdEventoFiltro((Integer) rs.getObject("ConfiguracaoAcaoAutomatica.ID_EVENTO_FILTRO"));
        	configuracaoAcaoAutomaticaTO.setDataFiltro(rs.getString("ConfiguracaoAcaoAutomatica.DATA_FILTRO"));
        	configuracaoAcaoAutomaticaTO.setHorasComparacao((Integer) rs.getObject("ConfiguracaoAcaoAutomatica.HORAS_COMPARACAO"));
        	configuracaoAcaoAutomaticaTO.setIdConfiguracaoCaixaEmail((Integer) rs.getObject("ConfiguracaoAcaoAutomatica.ID_CONFIGURACAO_CAIXA_EMAIL"));
        	configuracaoAcaoAutomaticaTO.setConteudoEmail(rs.getString("ConfiguracaoAcaoAutomatica.CONTEUDO_EMAIL"));
        	configuracaoAcaoAutomaticaTO.setIdLayoutAlteracao((Integer) rs.getObject("ConfiguracaoAcaoAutomatica.ID_LAYOUT_ALTERACAO"));
        	configuracaoAcaoAutomaticaTO.setIdStatusDestino((Integer) rs.getObject("ConfiguracaoAcaoAutomatica.ID_STATUS_DESTINO"));
        	configuracaoAcaoAutomaticaTO.setIdEmailModelo((Integer) rs.getObject("ConfiguracaoAcaoAutomatica.ID_EMAIL_MODELO"));
        	configuracaoAcaoAutomaticaTO.setIdOperacao((Integer) rs.getObject("ConfiguracaoAcaoAutomatica.ID_OPERACAO"));
        	configuracaoAcaoAutomaticaTO.setTipoConfiguracao(rs.getString("ConfiguracaoAcaoAutomatica.TIPO_CONFIGURACAO"));
        	configuracaoAcaoAutomaticaTO.setDestinatarioEmail(rs.getString("ConfiguracaoAcaoAutomatica.DESTINATARIO_EMAIL"));
        	configuracaoAcaoAutomaticaTO.setTipoComparacao(rs.getString("ConfiguracaoAcaoAutomatica.TIPO_COMPARACAO"));
        	configuracaoAcaoAutomaticaTO.setRestringirEmail(rs.getString("ConfiguracaoAcaoAutomatica.RESTRINGIR_EMAIL"));
        	configuracaoAcaoAutomaticaTO.setIgnorarEmail(rs.getString("ConfiguracaoAcaoAutomatica.IGNORAR_EMAIL"));
            return configuracaoAcaoAutomaticaTO;
        } catch (SQLException ex) {
            throw new IllegalArgumentException("Erro ao montar objeto a partir do ResultSet", ex);
        }
    }
	
}
