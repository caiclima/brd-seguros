package br.com.callink.cad.sau.toolbar.request;

import java.awt.EventQueue;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.LogLigacoes;
import br.com.callink.cad.pojo.ParametroGBO;
import br.com.callink.cad.sau.toolbar.util.ToolbarBussinessAppUtil;
import br.com.callink.cad.service.IAtendenteService;
import br.com.callink.cad.service.ICasoService;
import br.com.callink.cad.service.ILogLigacoesService;
import br.com.callink.cad.service.IParametroGBOService;
import br.com.callink.cad.service.IStatusAtendenteService;
import br.com.callink.cad.service.ITempoAtendimentoCasoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.util.Constantes;
import br.com.callink.toolbar.businessappintegrator.exception.ProcessException;
import br.com.callink.toolbar.businessappintegrator.process.RequestProcess;
import br.com.callink.toolbar.businessappintegrator.service.provider.ToolBarServerServiceProvider;
import br.com.callink.toolbar.commons.exception.ClientException;
import br.com.callink.toolbar.commons.message.MessageTO;
import br.com.callink.toolbar.commons.message.enun.TypeHostEnum;
import br.com.callink.toolbar.commons.message.enun.TypeMessageEnum;
import br.com.callink.toolbar.commons.message.request.IRequest;
import br.com.callink.toolbar.commons.message.request.impl.AvailableRequest;
import br.com.callink.toolbar.commons.message.request.impl.BusinessDialRequest;
import br.com.callink.toolbar.commons.message.request.impl.HangupRequest;
import br.com.callink.toolbar.commons.message.request.impl.HostRequest;
import br.com.callink.toolbar.commons.message.request.impl.LogoutRequest;
import br.com.callink.toolbar.commons.message.request.impl.MessengerRequest;
import br.com.callink.toolbar.commons.message.request.impl.StatusToolbarRequest;
import br.com.callink.toolbar.commons.message.request.impl.to.TypeMessageTO;
import br.com.callink.toolbar.commons.message.response.cache.ResponseCache;
import br.com.callink.toolbar.commons.message.response.impl.SuccessMessage;

import com.google.gson.Gson;

public class ToolbarBussinessAppRequestProcess extends RequestProcess {
	private static final Logger LOGGER = Logger.getLogger(ToolbarBussinessAppRequestProcess.class.getName());
    private static final String MSG_SUCCESS = "RECEIVED";
    private String urlGbo;
    
    private IParametroGBOService parametroGBOService;
    private IStatusAtendenteService statusAtendenteService;
    private ITempoAtendimentoCasoService tempoAtendimentoCasoService;
    private IAtendenteService atendenteService;
    private ILogLigacoesService logLigacoesService;
    private ICasoService casoService;
    
    
    public ToolbarBussinessAppRequestProcess(IParametroGBOService parametroGBOService2, IStatusAtendenteService statusAtendenteService2, ITempoAtendimentoCasoService tempoAtendimentoCasoService2, IAtendenteService atendenteService2, ILogLigacoesService logLigacoesService2, ICasoService casoService2) {
    	try {
    		parametroGBOService = parametroGBOService2;
    	    statusAtendenteService = statusAtendenteService2;
    	    tempoAtendimentoCasoService = tempoAtendimentoCasoService2;
    	    atendenteService = atendenteService2;
    	    logLigacoesService = logLigacoesService2;
    	    casoService = casoService2;
    	    
	    	if (parametroGBOService != null) {
		    		ParametroGBO parametroGBO = parametroGBOService.findByParam(Constantes.URL_SISTEMA);
			    	if (parametroGBO != null) { 
			    		urlGbo = parametroGBO.getValor();
			    	}
	    	}
    	} catch (Exception e) {
    		LOGGER.info("Erro ao buscar o parametro"+ e);
		}
    }
    
    public String process(final HostRequest request) throws ProcessException {
        try {
        	setIpPortaToolbarServer(request);
        	
            HostRequest hostRequest =
                    new HostRequest(new MessageTO());
                    
            hostRequest.setIpAddress(request.getServerIp());
            hostRequest.setPort(request.getServerPort());
            hostRequest.setUserId(request.getUserId());
            hostRequest.setUserSSO(request.getUserSSO());
            hostRequest.setBlockAllRequestBrowser(true);
            hostRequest.setDisposition(false);
            hostRequest.setTimeDisposition(null);
            hostRequest.setHost(urlGbo);
            hostRequest.setTypeHost(TypeHostEnum.HOME.getIdTypeHostEnum());
            hostRequest.setUserSSO(request.getUserSSO());

            LOGGER.info("Testando service process(final HostRequest request)");

            ToolBarServerServiceProvider.hostRequest(hostRequest);
        } catch (IllegalArgumentException e) {
           LOGGER.info(e.getMessage());
        } catch (ClientException ex) {
        	LOGGER.info(ex.getMessage());
        }
        return responseSuccessMessage(request);
    }
    
	public String process(final StatusToolbarRequest request) throws ProcessException {
		try {
			statusAtendenteService.alteraStatusToolbarGBO(request.getUserSSO(), request.getIdStatus());
			return responseSuccessMessage(request);
		} catch (Exception e) {
			throw new ProcessException("Erro ao Processar a mensagem StatusToolbarRequest", e);
		}
	}
	
	public String process(final AvailableRequest request) throws ProcessException {
		try {
			statusAtendenteService.alteraStatusToolbarGBODisponivel(request.getUserSSO());
			
			return responseSuccessMessage(request);
		} catch (Exception e) {
			throw new ProcessException("Erro ao alterar o status do atendente.",e);
		}
	}
	
	public String process(final LogoutRequest request) throws ProcessException {
		try{
			Atendente atendente = atendenteService.findByLogin(request.getUserSSO());
			tempoAtendimentoCasoService.salvaMarcacaoAtendimento(null, null, atendente, Boolean.FALSE);
			statusAtendenteService.salvarNovoStatusAtendendimento(null, atendente, null, Boolean.FALSE);
			return responseSuccessMessage(request);
		} catch (ServiceException | ValidationException e) {
			throw new ProcessException("Erro ao processar logout.",e);
		}
	}
	
	public String process(final HangupRequest request) throws ProcessException {
		try {
			List<LogLigacoes> listLogLigacoes = logLigacoesService.findByCallIDAndDateEndNull(request.getCallId());
			
			if (listLogLigacoes != null && listLogLigacoes.size() > 0) {
				LogLigacoes logLigacoes = listLogLigacoes.get(0);
				logLigacoes.setDataFim(new Date(System.currentTimeMillis()));
				
				logLigacoesService.update(logLigacoes);
			}
			
			return responseSuccessMessage(request);
		} catch (ServiceException | ValidationException e) {
			throw new ProcessException("Erro ao gravar log de telefonia durante hangup",e);
		}
	}
	
	public String process(MessengerRequest request) throws ProcessException {
		
		try{
			
			if(ToolbarBussinessAppUtil.ip_toolbar_server != null && 
				ToolbarBussinessAppUtil.porta_toolbar_server != null) {
				
				MessengerRequest messengerRequest = new MessengerRequest(new MessageTO());	
				
				messengerRequest.setIpAddress(ToolbarBussinessAppUtil.ip_toolbar_server);
				messengerRequest.setPort(ToolbarBussinessAppUtil.porta_toolbar_server);
				
				messengerRequest.setUserSSO(request.getUserSSO());
				messengerRequest.setMessage(request.getMessage());
				messengerRequest.setDateSent(request.getDateSent());
				messengerRequest.setIdMessage(0L);
				messengerRequest.setIdTypeResponseMessage(0);
				messengerRequest.setSourceName("GBO");
				messengerRequest.setUserSent(request.getUserSent());
				
				ToolBarServerServiceProvider.messenger(messengerRequest);
				
			} else {
				
				throw new ProcessException();
			}
		} catch (ClientException e) {
			throw new ProcessException("Erro ao enviar messangem para toolbar",e);
        }
        return null;
	}
	
	public String process(BusinessDialRequest businessDialRequest) throws ProcessException {
		
		try {
		businessDialRequest.setIpAddress(ToolbarBussinessAppUtil.ip_toolbar_server);
		businessDialRequest.setPort(ToolbarBussinessAppUtil.porta_toolbar_server);
		
		ToolBarServerServiceProvider.dial(businessDialRequest);
		
		} catch (Exception e) {
			throw new ProcessException("Erro ao realizar a ligação",e);
		}
		
		return null;
	}

    private String responseSuccessMessage(IRequest request) {
    	
        SuccessMessage successMessage = new SuccessMessage(new MessageTO() ,MSG_SUCCESS);
        successMessage.setIpAddress(request.getServerIp());
        successMessage.setPort(request.getServerPort());
        successMessage.setUserId(request.getUserId());
        successMessage.setUserSSO(request.getUserSSO());

        final TypeMessageTO typeMessageTO = new TypeMessageTO();
        typeMessageTO.setIdTypeMessage(TypeMessageEnum.SUCESS_MESSAGE.getIdTypeMessageEnum());
        typeMessageTO.setMessage(new Gson().toJson(successMessage));

        if (request.isOnlineProcessing()) {
            return new Gson().toJson(typeMessageTO);
        } else {
            EventQueue.invokeLater(new Runnable() {

                public void run() {

                    ResponseCache.offer(new Gson().toJson(typeMessageTO));
                }
            });
            return null;
        }
    }
    
    private void setIpPortaToolbarServer(IRequest request) {
    	if(request != null && request.getIpAddress() != null && request.getPort() != null) {
    		ToolbarBussinessAppUtil.ip_toolbar_server = request.getServerIp();
    		ToolbarBussinessAppUtil.porta_toolbar_server = request.getServerPort();
    	}
    }
}
