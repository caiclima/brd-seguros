package br.com.callink.cad.sau.toolbar.response;

import java.awt.EventQueue;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.LogLigacoes;
import br.com.callink.cad.pojo.StatusAtendente;
import br.com.callink.cad.sau.toolbar.util.ToolbarBussinessAppUtil;
import br.com.callink.cad.service.IAtendenteService;
import br.com.callink.cad.service.ICasoService;
import br.com.callink.cad.service.ILogLigacoesService;
import br.com.callink.cad.service.IStatusAtendenteService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.service.repository.ControleStatusAtendentes;
import br.com.callink.cad.util.Constantes;
import br.com.callink.toolbar.businessappintegrator.exception.ProcessException;
import br.com.callink.toolbar.businessappintegrator.process.ResponseIntegratorProcess;
import br.com.callink.toolbar.commons.message.MessageTO;
import br.com.callink.toolbar.commons.message.enun.TypeMessageEnum;
import br.com.callink.toolbar.commons.message.enun.TypeStatusPlataformaEnum;
import br.com.callink.toolbar.commons.message.request.impl.to.TypeMessageTO;
import br.com.callink.toolbar.commons.message.response.IResponse;
import br.com.callink.toolbar.commons.message.response.cache.ResponseCache;
import br.com.callink.toolbar.commons.message.response.impl.ChangeStatusResponse;
import br.com.callink.toolbar.commons.message.response.impl.DialCallRecordResponse;
import br.com.callink.toolbar.commons.message.response.impl.DroppedCallResponse;
import br.com.callink.toolbar.commons.message.response.impl.ReceivedCallResponse;
import br.com.callink.toolbar.commons.message.response.impl.SuccessMessage;

import com.google.gson.Gson;

public class ToolbarBussinessAppResponseProcess extends ResponseIntegratorProcess {

    private static final String MSG_SUCCESS = "RECEIVED";
    
    private ILogLigacoesService logLigacoesService;
    private IAtendenteService atendenteService;
    private ICasoService casoService;
    private IStatusAtendenteService statusAtendenteService;
    
    public ToolbarBussinessAppResponseProcess(
			IStatusAtendenteService statusAtendenteService2,
			IAtendenteService atendenteService2,
			ILogLigacoesService logLigacoesService2, ICasoService casoService2) {
    	
        logLigacoesService = logLigacoesService2;
        atendenteService = atendenteService2;
        casoService = casoService2;
        statusAtendenteService = statusAtendenteService2;
    	
	}

	public String process(final ReceivedCallResponse response) throws ProcessException {
    	try {
			
			LogLigacoes logLigacoes = new LogLigacoes();
			Atendente atendente = atendenteService.findByLogin(response.getUserSSO());
			
			logLigacoes.setAtendente(atendente);
			logLigacoes.setTelefoneCliente(response.getCallingDeviceID());
			logLigacoes.setCanalEntrada(response.getCalledDeviceID());
			logLigacoes.setRamal(response.getExtension());
			logLigacoes.setCallID(response.getCallId());
			logLigacoes.setEntrante(true);
			logLigacoes.setDataInicio(new Date(System.currentTimeMillis()));
			
			logLigacoesService.save(logLigacoes);
    		
    		return responseSuccessMessage(response);
    	} catch (ServiceException | ValidationException e) {
    		throw new ProcessException("Erro ao receber um receivedCallResponse", e);
    	}
    }
    
    public String process(final DialCallRecordResponse response) throws ProcessException {
		try {
			
			List<LogLigacoes> listLogLigacoes = logLigacoesService.findByCallIdNullForUserSSO(response.getUserSSO(), response.getPhoneNumber());
			
			Calendar dataAtual = new GregorianCalendar();
			dataAtual.setTime(logLigacoesService.getDataBanco());
			
			dataAtual.add(Calendar.SECOND, -5);
			
			if (listLogLigacoes != null && listLogLigacoes.size() > 0) {
				LogLigacoes logLigacoes = listLogLigacoes.get(0);
				if (logLigacoes.getDataInicio().compareTo(dataAtual.getTime()) < 0) {
					logLigacoes = novoLogLigacoes(response);
					logLigacoesService.saveInicioLogLigacoesRealizada(logLigacoes);
				} else {
					logLigacoes.setCallID(response.getCallId());
					logLigacoesService.update(logLigacoes);
				}
			} else {
				LogLigacoes logLigacoes = novoLogLigacoes(response);
				logLigacoesService.saveInicioLogLigacoesRealizada(logLigacoes);
			}
			
			return responseSuccessMessage(response);
		} catch (ServiceException | ValidationException e) {
			throw new ProcessException("Erro ao gravar log de telefonia durante dialCallRecord", e);
		}
    }

	private LogLigacoes novoLogLigacoes(final DialCallRecordResponse response) throws ServiceException {
		LogLigacoes logLigacoes = new LogLigacoes();
		List<Caso> listaCaso = casoService.atendentePossuiCasoEmAtendimento(response.getUserSSO());
		
		if (listaCaso != null && listaCaso.size() > 0) {
			logLigacoes.setCaso(listaCaso.get(0));
			logLigacoes.setAtendente(listaCaso.get(0).getAtendente());
		} else {
			logLigacoes.setAtendente(atendenteService.findByLogin(response.getUserSSO()));
		}
		
		logLigacoes.setDataInicio(logLigacoesService.getDataBanco());
		logLigacoes.setTelefoneCliente(response.getPhoneNumber());
		logLigacoes.setRamal(response.getExtension());
		logLigacoes.setEntrante(false);
		
		logLigacoes.setCallID(response.getCallId());
		
		return logLigacoes;
	}
    
    public String process(final DroppedCallResponse response) throws ProcessException {
		try {
			
			List<LogLigacoes> listLogLigacoes = logLigacoesService.findByCallIDAndDateEndNull(response.getCallId());
			
			if (listLogLigacoes != null && listLogLigacoes.size() > 0) {
				LogLigacoes logLigacoes = listLogLigacoes.get(0);
				logLigacoes.setDataFim(new Date(System.currentTimeMillis()));
				
				logLigacoesService.update(logLigacoes);
			}
			
			return responseSuccessMessage(response);
		} catch (ServiceException | ValidationException e) {
			throw new ProcessException("Erro ao gravar log de telefonia durante droppedCall", e);
		}
    }
    
    public String process(final ChangeStatusResponse response) throws ProcessException {
    	try {

	    		//Verificar se o atendente já está com um status de pausa. Se não, enviar para status PAUSA não identificado
				Atendente atendente = atendenteService.findByLogin(response.getUserSSO());
				StatusAtendente statusAtendente = ControleStatusAtendentes.getStatusAtendenteAtualPausa(atendente.getIdAtendente());
				
				if (statusAtendente != null) {
		    		if (response.getStatus() != null && response.getStatus().getStatusId().equals(TypeStatusPlataformaEnum.READY.getIdTypeStatusTelefoniaEnum())) {
		    			
		    			statusAtendenteService.alteraStatusToolbarGBODisponivel(response.getUserSSO());
		    			
		    		}
		    		
		    		if (response.getStatus() != null && response.getStatus().getStatusId().equals(TypeStatusPlataformaEnum.NOT_READY.getIdTypeStatusTelefoniaEnum())) {
		    			
		    			if (atendente != null) {
		    				
		    				if (statusAtendente != null && statusAtendente.getIdAtendenteStatus() != null && !statusAtendente.getIdAtendenteStatus().getPausaAtendimento()) {
		    					//Envia pausa não identificada
		    					statusAtendenteService.alteraStatusToolbarGBO(response.getUserSSO(), Integer.valueOf(Constantes.PAUSA_NAO_IDENTIFICADA));
		    				}
		    				
		    			}
		    			
		    		}
		    		
	    		return responseSuccessMessage(response);
			}
			return null;
    	} catch (ServiceException | ValidationException e) {
    		throw new ProcessException("Erro ao alterar o status da toolbar", e);
		}
    }

    private String responseSuccessMessage(IResponse response) {
        SuccessMessage successMessage = new SuccessMessage(new MessageTO() ,MSG_SUCCESS);
        successMessage.setIpAddress(ToolbarBussinessAppUtil.ip_toolbar_server);
        successMessage.setPort(ToolbarBussinessAppUtil.porta_toolbar_server);
        successMessage.setUserId(response.getUserId());
        successMessage.setUserSSO(response.getUserSSO());

        final TypeMessageTO typeMessageTO = new TypeMessageTO();
        typeMessageTO.setIdTypeMessage(TypeMessageEnum.SUCESS_MESSAGE.getIdTypeMessageEnum());
        typeMessageTO.setMessage(new Gson().toJson(successMessage));

        if (response.isOnlineProcessing()) {
            return new Gson().toJson(typeMessageTO);
        } else {
            EventQueue.invokeLater(new Runnable() {

                public void run() {

                    ResponseCache.offer(new Gson().toJson(typeMessageTO));
                }
            });
            return null;
        }
    }

}
