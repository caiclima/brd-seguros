package br.com.callink.cad.sau.toolbar.server;

import java.util.logging.Logger;

import br.com.callink.cad.pojo.ParametroGBO;
import br.com.callink.cad.sau.toolbar.request.ToolbarBussinessAppRequestProcess;
import br.com.callink.cad.sau.toolbar.response.ToolbarBussinessAppResponseProcess;
import br.com.callink.cad.service.IAtendenteService;
import br.com.callink.cad.service.ICasoService;
import br.com.callink.cad.service.ILogLigacoesService;
import br.com.callink.cad.service.IParametroGBOService;
import br.com.callink.cad.service.IStatusAtendenteService;
import br.com.callink.cad.service.ITempoAtendimentoCasoService;
import br.com.callink.cad.service.impl.ConfiguracaoFilaService;
import br.com.callink.cad.util.Constantes;
import br.com.callink.toolbar.businessappintegrator.socket.ToolBarBusinessAppServer;



public class GboBussinessAppServer {

	private static final Logger LOGGER = Logger.getLogger(ConfiguracaoFilaService.class.getName());
	
	private static GboBussinessAppServer gboBussinessAppServer;
	
	public static GboBussinessAppServer getInstance() {

        if (gboBussinessAppServer == null) {
        	gboBussinessAppServer = new GboBussinessAppServer();
        }
        return gboBussinessAppServer;
    }
	
	public void init(IParametroGBOService parametroGBOService, IStatusAtendenteService statusAtendenteService, 
			ITempoAtendimentoCasoService tempoAtendimentoCasoService, IAtendenteService atendenteService, 
			ILogLigacoesService logLigacoesService, ICasoService casoService){
		try {
			LOGGER.info("metodo : main Inicia ToolBarBusinessAppServer");

            ParametroGBO parametroGBO = parametroGBOService.findByParam(Constantes.FLAG_INICIA_BAPP_TOOLBAR);
            ParametroGBO parametroGBOPorta = parametroGBOService.findByParam(Constantes.PORTA_TOOLBAR_BAPP);
            Boolean validaIniciaBapp;
            
            try {
            	validaIniciaBapp = parametroGBO != null && !parametroGBO.getValor().isEmpty() ? Boolean.valueOf(parametroGBO.getValor()) : Boolean.FALSE;
            } catch (Exception e) {
				validaIniciaBapp = Boolean.FALSE;
			}
            
            if (validaIniciaBapp) {
            	if (parametroGBOPorta != null && parametroGBOPorta.getValor() != null && !parametroGBOPorta.getValor().isEmpty()) {
            		ToolBarBusinessAppServer.getInstance().init(new ToolbarBussinessAppRequestProcess(parametroGBOService, statusAtendenteService, 
            				tempoAtendimentoCasoService, atendenteService, logLigacoesService, casoService), 
            				new ToolbarBussinessAppResponseProcess(statusAtendenteService, atendenteService, logLigacoesService, casoService), 
            				Integer.valueOf(parametroGBOPorta.getValor()));
            	} else {
            		ToolBarBusinessAppServer.getInstance().init(new ToolbarBussinessAppRequestProcess(parametroGBOService, statusAtendenteService, 
            				tempoAtendimentoCasoService, atendenteService, logLigacoesService, casoService), 
            				new ToolbarBussinessAppResponseProcess(statusAtendenteService, atendenteService, logLigacoesService, casoService));
            	}
            }
        } catch (Exception exception) {
            LOGGER.info("metodo main Ocorreu um erro na ToolBarBusinessAppServer " + exception);
        } finally {
            LOGGER.info("metodo main ToolBarBusinessAppServer Finalizada ");
        }
	}
	
}
