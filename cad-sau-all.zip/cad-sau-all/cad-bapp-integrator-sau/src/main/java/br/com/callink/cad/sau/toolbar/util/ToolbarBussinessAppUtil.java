package br.com.callink.cad.sau.toolbar.util;

public final class ToolbarBussinessAppUtil {

	private ToolbarBussinessAppUtil() {
	}
	
	public static String ip_toolbar_server = null;
	public static Integer porta_toolbar_server = null;
}
