package br.com.callink.cad.sau.admin.web.backbean;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.backbean.AbstractAcompanhamentoCasoBB;
import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.pojo.Log;
import br.com.callink.cad.pojo.Status;
import br.com.callink.cad.sau.pojo.Assunto;
import br.com.callink.cad.sau.pojo.Canal;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.pojo.Estado;
import br.com.callink.cad.sau.pojo.Evento;
import br.com.callink.cad.sau.pojo.OutraArea;
import br.com.callink.cad.sau.pojo.TipoManifestacao;
import br.com.callink.cad.sau.pojo.to.AcompanhamentoCasoFind;
import br.com.callink.cad.sau.service.IAssuntoService;
import br.com.callink.cad.sau.service.ICanalService;
import br.com.callink.cad.sau.service.ICasoSauService;
import br.com.callink.cad.sau.service.IEstadoService;
import br.com.callink.cad.sau.service.IEventoService;
import br.com.callink.cad.sau.service.IOutraAreaService;
import br.com.callink.cad.sau.service.ITipoManifestacaoService;
import br.com.callink.cad.sau.util.CsvUtils;
import br.com.callink.cad.service.IAtendenteService;
import br.com.callink.cad.service.ICasoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.util.Constantes;
import br.com.callink.cad.util.Data;

/**
 * 
 * @author Rafael Peres dos santos
 */
@ViewScoped
@ManagedBean
public class AcompanhamentoCasoBB extends AbstractAcompanhamentoCasoBB<Caso> {

    private static final long serialVersionUID = -3924389514033190760L;
    
    @EJB
    private transient ICasoSauService casoSauService;
    @EJB
    private transient ITipoManifestacaoService tipoManifestacaoService;
    @EJB
    private transient ICanalService canalService;
    @EJB
    private transient IAssuntoService assuntoService;
    @EJB
    private transient IEventoService eventoService;
    @EJB
    private transient IEstadoService estadoService;
    @EJB
    private transient IOutraAreaService outraAreaService;
    @EJB
    private ICasoService casoService;
    @EJB
    private IAtendenteService atendenteService;
    
    private List<TipoManifestacao> tipoManifestacaoList;
    private List<Canal> canalList;
    private List<Evento> eventoList;
    private List<Assunto> assuntoList;
    private List<CasoSau> casoSauList;
    private List<Estado> estadoList;
    private List<OutraArea> outraAreaList;
    private List<Log> historicoCaso;
    
    private transient CasoSau casoSau;
    private transient CasoSau casoSauSelecionado;
    
    private String cpfCnpj;
    private String idManifestacao;
    
    private boolean selecionaTodosCanal;
    private boolean selecionaTodosEvento;
    private boolean selecionaTodosTipoManifestacao;
    private boolean selecionaTodosAssunto;
    private boolean selecionaTodasArea;
    private boolean selecionaTodosEstados;
    
    private transient List<String> canalNomeSelecionadoList;
    private transient List<String> eventoNomeSelecionadoList;
    private transient List<String> tipoManifestacaoNomeSelecionadoList;
    private transient List<String> assuntoNomeSelecionadoList;
    private transient List<String> estadoNomeSelecionadoList;
    private transient List<String> outraAreaNomeSelecionadoList;
        
    private transient List<Canal> canalSelecionadoList = new ArrayList<Canal>();
    private transient List<Evento> eventoSelecionadoList = new ArrayList<Evento>();
    private transient List<Assunto> assuntoSelecionadoList = new ArrayList<Assunto>();
    private transient List<TipoManifestacao> tipoManifestacaoSelecionadoList = new ArrayList<TipoManifestacao>();
    private transient List<Estado> estadoSelecionadoList = new ArrayList<Estado>();
    private transient List<OutraArea> outraAreaSelecionadoList = new ArrayList<OutraArea>();
    
    private Boolean flagRechamado;
    private String viaEntrada;
    
    private boolean flagMostraGridTipoManifestacao;
    private boolean flagMostraGridCanal;
    private boolean flagMostraGridAssunto;
    private boolean flagMostraGridEvento;
    private boolean flagMostraGridOutraArea;
    private boolean flagMostraGridEstado;
    
    @PostConstruct
    public void init() {
    	super.init();
        limpaCampos();

        HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        setContextPath(request.getContextPath() + "/exportarCsv");
        flagRechamado = Boolean.FALSE;
    }
    
    @Override
    public String filtrar() {

        try {

            if (validaConsulta()) {
                casoSau.setCaso(getCaso());
                if (StringUtils.isNotBlank(cpfCnpj)) {
                    casoSau.setCpfCnpj(cpfCnpj);
                }
                if (StringUtils.isNotBlank(idManifestacao)) {
                    casoSau.setManifestacao(idManifestacao);
                } else {
                    casoSau.setManifestacao(null);
                }
                Long slaEmMinutos = Data.retornaMinutos(getHora(), getMinuto());
                Long slaEmMinutosMaior = Data.retornaMinutos(getHoraMaior(), getMinutoMaior());
                
                setParametrosSelecionados();

                AcompanhamentoCasoFind acompanhamentoCasoFind = new AcompanhamentoCasoFind();
                acompanhamentoCasoFind.setCasoSau(casoSau);
                acompanhamentoCasoFind.setDataInicio(getDataInicio());
                acompanhamentoCasoFind.setDataFim(getDataFim());
                acompanhamentoCasoFind.setSlaEmMinutos(slaEmMinutos);
                acompanhamentoCasoFind.setCanalSelecionadoList(canalSelecionadoList);
                acompanhamentoCasoFind.setEventoSelecionadoList(eventoSelecionadoList);
                acompanhamentoCasoFind.setTipoManifestacaoSelecionadoList(tipoManifestacaoSelecionadoList);
                acompanhamentoCasoFind.setConfiguracaoFilaSelecionadoList(getConfiguracaoFilaSelecionadoList());
                acompanhamentoCasoFind.setStatusSelecionadoList(getStatusSelecionadoList());
                acompanhamentoCasoFind.setAtendenteSelecionadoList(getAtendenteSelecionadoList());
                acompanhamentoCasoFind.setAssuntoSelecionadoList(assuntoSelecionadoList);
                acompanhamentoCasoFind.setEquipeSelecionadoList(getEquipeSelecionadoList());             
                acompanhamentoCasoFind.setDataInicioFechamento(getDataInicioFechamento());
                acompanhamentoCasoFind.setDataFimFechamento(getDataFimFechamento());
                acompanhamentoCasoFind.setSlaEmMinutosMaior(slaEmMinutosMaior);
                acompanhamentoCasoFind.setFlagRechamadoCaso(getFlagRechamadoConsulta());
                acompanhamentoCasoFind.setViaEntrada(viaEntrada);
                acompanhamentoCasoFind.setEstadoSelecionadoList(getEstadoSelecionadoList());
                acompanhamentoCasoFind.setOutraAreaSelecionadoList(getOutraAreaSelecionadoList());
                if (!getFlagFechado().equals('T')) {
                	acompanhamentoCasoFind.setCasoFechado(getFlagFechado().equals('S') ? true : false);
                }
                setCasoSauList(casoSauService.buscaPorFiltros(acompanhamentoCasoFind));

                List<Caso> casoList = new ArrayList<Caso>();
                for (CasoSau casoSauI : casoSauList) {
                    casoList.add(casoSauI.getCaso());
                }
                geraGrafico(casoList);
                gerarCSV();
            }
        } catch (ServiceException e) {
            error(e);
        }
        return "";
    }

    private void setParametrosSelecionados() {

        if (canalList != null) {
            canalSelecionadoList.clear();
            for (Canal item : canalList) {
                if (item.getSelecionado() != null && item.getSelecionado()) {
                    canalSelecionadoList.add(item);
                }
            }
        }
        if (eventoList != null) {
            eventoSelecionadoList.clear();
            for (Evento item : eventoList) {
                if (item.getSelecionado() != null && item.getSelecionado()) {
                    eventoSelecionadoList.add(item);
                }
            }
        }
        if (tipoManifestacaoList != null) {
            tipoManifestacaoSelecionadoList.clear();
            for (TipoManifestacao item : tipoManifestacaoList) {
                if (item.getSelecionado() != null && item.getSelecionado()) {
                    tipoManifestacaoSelecionadoList.add(item);
                }
            }
        }
        if (outraAreaList != null) {
            outraAreaSelecionadoList.clear();
            for (OutraArea item : outraAreaList) {
                if (item.getSelecionado() != null && item.getSelecionado()) {
                	outraAreaSelecionadoList.add(item);
                }
            }
        }
        if (estadoList != null) {
            estadoSelecionadoList.clear();
            for (Estado item : estadoList) {
                if (item.getSelecionado() != null && item.getSelecionado()) {
                	estadoSelecionadoList.add(item);
                }
            }
        }
        if (tipoManifestacaoList != null) {
            tipoManifestacaoSelecionadoList.clear();
            for (TipoManifestacao item : tipoManifestacaoList) {
                if (item.getSelecionado() != null && item.getSelecionado()) {
                    tipoManifestacaoSelecionadoList.add(item);
                }
            }
        }
        
        
        if (getConfiguracaoFilaList() != null) {
            getConfiguracaoFilaSelecionadoList().clear();
            for (ConfiguracaoFila item : getConfiguracaoFilaList()) {
                if (item.getSelecionado() != null && item.getSelecionado()) {
                    getConfiguracaoFilaSelecionadoList().add(item);
                }
            }
        }
        if (getStatusList() != null) {
            getStatusSelecionadoList().clear();
            for (Status item : getStatusList()) {
                if (item.getSelecionado() != null && item.getSelecionado()) {
                    getStatusSelecionadoList().add(item);
                }
            }
        }
        if (getAtendenteList() != null) {
            getAtendenteSelecionadoList().clear();
            for (Atendente item : getAtendenteList()) {
                if (item.getSelecionado() != null && item.getSelecionado()) {
                    getAtendenteSelecionadoList().add(item);
                }
            }
        }
    }

    private boolean validaConsulta() {

        if (StringUtils.isNotBlank(idManifestacao)) {
            return Boolean.TRUE;
        }

        if ((getDataInicioFechamento() == null && getDataFimFechamento() == null && getDataInicio() == null && getDataFim() == null)) {
            error("Preencher campo data com per\u00EDodo de no m\u00E1ximo 60 dias.");
            return Boolean.FALSE;
        }
        
        if ((getDataInicio() != null && getDataFim() == null) || (getDataInicio() == null && getDataFim() != null)  ) {
            error("Preencher campo data abertura corretamente e com per\u00EDodo de no m\u00E1ximo 60 dias.");
            return Boolean.FALSE;
        }
        
        if ((getDataInicioFechamento() != null && getDataFimFechamento() == null) || (getDataInicioFechamento() == null && getDataFimFechamento() != null)  ) {
            error("Preencher campo data fechamento corretamente e com per\u00EDodo de no m\u00E1ximo 60 dias.");
            return Boolean.FALSE;
        }
        
        if (getDataInicio() != null && Data.diferencaEmDias(getDataFim(), getDataInicio()) > 60) {
            error("per\u00EDodo m\u00E1ximo permitido para o filtro de data abertura \u00E9 de 60 dias.");
            return Boolean.FALSE;
        }
        
        if (getDataInicioFechamento()!= null && Data.diferencaEmDias(getDataFimFechamento(), getDataInicioFechamento()) > 60) {
            error("per\u00EDodo m\u00E1ximo permitido para o filtro de data fechamento \u00E9 de 60 dias.");
            return Boolean.FALSE;
        }
        
        return Boolean.TRUE;
    }

    public void gerarCSV() {
        CsvUtils csv = new CsvUtils("casos.csv", null);

        List<Object> tabela = new ArrayList<Object>();
        List<Object> linhaAtual = new ArrayList<Object>();
        linhaAtual.add("MANIFESTACAO");
        linhaAtual.add("CPF/CNPJ");
        linhaAtual.add("CANAL");
        linhaAtual.add("ESTADO");
        linhaAtual.add("OUTRA_AREA");
        linhaAtual.add("DATA");
        linhaAtual.add("TIPO_MANIFESTACAO");
        linhaAtual.add("SLA");
        linhaAtual.add("ATENDENTE");
        linhaAtual.add("STATUS");
        linhaAtual.add("CARTAO");
        linhaAtual.add("TIPO_CARTAO");
        linhaAtual.add("REABERTURA");
        tabela.add(linhaAtual.toArray());

        if (getCasoSauList() != null) {
            for (CasoSau item : getCasoSauList()) {
                linhaAtual = new ArrayList<Object>();

                linhaAtual.add(item.getManifestacao());
                linhaAtual.add(item.getCpfCnpj());
                linhaAtual.add(item.getCanal().getNome());
                linhaAtual.add(item.getEstado() == null || item.getEstado().getNome() == null ? "" : item.getEstado());  
                linhaAtual.add(item.getOutraArea() == null || item.getOutraArea().getNome() == null  ? "" : item.getOutraArea());
                linhaAtual.add(item.getDataAbertura());
                linhaAtual.add(item.getTipoManifestacao().getNome());
                linhaAtual.add(item.getCaso().getSlaEmMinutos());

                if (item.getCaso().getAtendente() != null && item.getCaso().getAtendente().getLogin() != null) {
                    linhaAtual.add(item.getCaso().getAtendente().getLogin());
                } else {
                    linhaAtual.add("");
                }
                if (item.getCaso().getStatus() != null) {
                    linhaAtual.add(item.getCaso().getStatus().getNome());
                } else {
                    linhaAtual.add("");
                }
                if (StringUtils.isBlank(item.getCartao())) {
                    linhaAtual.add("");
                } else {
                    linhaAtual.add(item.getCartao());
                }
                if (StringUtils.isBlank(item.getTipoCartao())) {
                    linhaAtual.add("");
                } else {
                    linhaAtual.add(item.getTipoCartao());
                }
                if (item.getCaso().getFlagReaberto() != null && item.getCaso().getFlagReaberto()) {
                     linhaAtual.add("SIM");
                } else {
                    linhaAtual.add("NAO");
                }

                tabela.add(linhaAtual.toArray());
            }
        }
        HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();

        // COLOCA O OBJETO DO RELATORIO NA SESSAO
        if (request.getSession(false) != null) {
            request.getSession().setAttribute("arquivo",
                    csv.createContents(tabela.toArray()));
        } else {
            error("Sess\u00E3o expirada!");
        }
    }

    public void buscaAtendenteByFila() {

        try {
            if (getCasoSau().getCaso().getConfiguracaoFila() != null) {
                setAtendenteList(atendenteService.buscaPorFila(getCasoSau().getCaso().getConfiguracaoFila()));
            }
        } catch (ServiceException e) {
            error(e);
        }
    }
    

    @SuppressWarnings("unchecked")
	public void visualizaCasoSau(CasoSau casoSau) {
        try {
            this.casoSauSelecionado = casoSauService.load(casoSau);

            if (casoSauSelecionado != null) {
            
                if (casoSauSelecionado.getEvento() != null && casoSauSelecionado.getEvento().getIdEvento() != null) {
                    casoSauSelecionado.setEvento(eventoService.load(casoSauSelecionado.getEvento()));
                    casoSauSelecionado.getEvento().setAssunto(assuntoService.load(casoSauSelecionado.getEvento().getAssunto()));
                }
                getSessionMap().put("casoSelecionado", casoSauSelecionado);
            }
        } catch (ServiceException ex) {
            error(ex);
        }

    }
    
    public void limpaCampos() {
        setCasoSau(new CasoSau());
        getCasoSau().setCaso(new Caso());
        assuntoSelecionadoList = new ArrayList<Assunto>();
        
    }

    public final List<TipoManifestacao> getTipoManifestacaoList() {

        return tipoManifestacaoList;
    }

    public final void setTipoManifestacaoList(
            List<TipoManifestacao> tipoManifestacaoList) {
        this.tipoManifestacaoList = tipoManifestacaoList;
    }

    public final List<Canal> getCanalList() {

        return canalList;
    }

    public final void setCanalList(List<Canal> canalList) {
        this.canalList = canalList;
    }

    public final List<Evento> getEventoList() {
    	if(eventoList == null){
    		eventoList = new ArrayList<Evento>();
    	}
        return eventoList;
    }

    public final void setEventoList(List<Evento> eventoList) {
        this.eventoList = eventoList;
    }

    public final List<Assunto> getAssuntoList() {

        return assuntoList;
    }

    public void marcaOuDesmarca() {
    }

    public void marcaDesmarcaAssunto(Assunto assunto) {
        if (assunto != null && assunto.getSelecionado() != null) {
            if(assuntoNomeSelecionadoList == null){
                assuntoNomeSelecionadoList = new ArrayList<String>();
            }
            if (assunto.getSelecionado()) {
                if(!assuntoNomeSelecionadoList.contains(assunto.getNome())){
                    assuntoNomeSelecionadoList.add(assunto.getNome());
                    assuntoSelecionadoList.add(assunto);
                    eventoNomeSelecionadoList =  new ArrayList<String>();
                }
            } else {
                if(assuntoNomeSelecionadoList.contains(assunto.getNome())){
                    assuntoNomeSelecionadoList.remove(assunto.getNome());
                    assuntoSelecionadoList.remove(assunto);
                    eventoNomeSelecionadoList =  new ArrayList<String>();
                }
            }
            eventoList = null;
        } 
    }

    public void selecionaAssunto() {
        List<Assunto> list = new ArrayList<Assunto>();
        for (Assunto item : assuntoList) {
            if (item.getSelecionado() != null && item.getSelecionado()) {
                list.add(item);
            }
        }
        try {
            if (!list.isEmpty()) {
                setEventoList(eventoService.findByAssuntoList(list));
            } else {
                getEventoList();
            }
        } catch (ServiceException e) {
            error("Erro ao buscar Eventos vinculados ao(s) Assunto(s) selecionado(s)");
        }

    }

    public void selecionaTodosAssuntos() {
        for (Assunto item : assuntoList) {
            if (selecionaTodosAssunto == Boolean.TRUE) {
                item.setSelecionado(Boolean.TRUE);
            } else {
                item.setSelecionado(Boolean.FALSE);
            }
            marcaDesmarcaAssunto(item);
        }
        getEventoList().clear();
        getEventoList();
    }

    public void marcaDesmarcaEvento(Evento evento) {
        if (evento != null && evento.getSelecionado() != null) {
             if(eventoNomeSelecionadoList == null){
                eventoNomeSelecionadoList = new ArrayList<String>();
            }
            if (evento.getSelecionado()) {
                if(!eventoNomeSelecionadoList.contains(evento.getNome())){
                    eventoNomeSelecionadoList.add(evento.getNome());
                }
                
            } else {
                if(eventoNomeSelecionadoList.contains(evento.getNome())){
                    eventoNomeSelecionadoList.remove(evento.getNome());
                }
            }
        }
    }

    public void selecionaTodosEventos() {

        for (Evento item : eventoList) {
            if (selecionaTodosEvento == Boolean.TRUE) {
                item.setSelecionado(Boolean.TRUE);
            } else {
                item.setSelecionado(Boolean.FALSE);
            }
            marcaDesmarcaEvento(item);
        }
    }

    public void marcaDesmarcaTipoManifestacao(TipoManifestacao tipoManifestacao) {
        if (tipoManifestacao != null && tipoManifestacao.getSelecionado() != null) {
            if(tipoManifestacaoNomeSelecionadoList == null){
                tipoManifestacaoNomeSelecionadoList = new ArrayList<String>();
            }
            if (tipoManifestacao.getSelecionado()) {
                if(!tipoManifestacaoNomeSelecionadoList.contains(tipoManifestacao.getNome())){
                    tipoManifestacaoNomeSelecionadoList.add(tipoManifestacao.getNome());
                }
                
            } else {
                if(tipoManifestacaoNomeSelecionadoList.contains(tipoManifestacao.getNome())){
                    tipoManifestacaoNomeSelecionadoList.remove(tipoManifestacao.getNome());
                }
            }
        }
    }

    public void selecionaTodosTipoManifestacao() {

        for (TipoManifestacao item : tipoManifestacaoList) {
            if (selecionaTodosTipoManifestacao == Boolean.TRUE) {
                item.setSelecionado(Boolean.TRUE);
            } else {
                item.setSelecionado(Boolean.FALSE);
            }
            marcaDesmarcaTipoManifestacao(item);
        }
    }

    public void selecionaTodasOutraArea() {

        for (OutraArea outra : outraAreaList) {
            if (selecionaTodasArea == Boolean.TRUE) {
            	outra.setSelecionado(Boolean.TRUE);
            } else {
            	outra.setSelecionado(Boolean.FALSE);
            }
            marcaDesmarcaOutraArea(outra);
        }
    }
    
    public void marcaDesmarcaOutraArea(OutraArea outraArea) {
        if (outraArea != null && outraArea.getSelecionado() != null) {
            if(outraAreaNomeSelecionadoList == null){
            	outraAreaNomeSelecionadoList = new ArrayList<String>();
            }
            if (outraArea.getSelecionado()) {
                if(!outraAreaNomeSelecionadoList.contains(outraArea.getNome())){
                	outraAreaNomeSelecionadoList.add(outraArea.getNome());
                }
                
            } else {
                if(outraAreaNomeSelecionadoList.contains(outraArea.getNome())){
                	outraAreaNomeSelecionadoList.remove(outraArea.getNome());
                }
            }
        }
    }
    
    
    public void selecionaTodosEstado() {

        for (Estado estado : estadoList) {
            if (selecionaTodosEstados == Boolean.TRUE) {
            	estado.setSelecionado(Boolean.TRUE);
            } else {
            	estado.setSelecionado(Boolean.FALSE);
            }
            marcaDesmarcaEstado(estado);
        }
    }
    
    public void marcaDesmarcaEstado(Estado estado) {
        if (estado != null && estado.getSelecionado() != null) {
            if(estadoNomeSelecionadoList == null){
            	estadoNomeSelecionadoList = new ArrayList<String>();
            }
            if (estado.getSelecionado()) {
                if(!estadoNomeSelecionadoList.contains(estado.getNome())){
                	estadoNomeSelecionadoList.add(estado.getNome());
                }
                
            } else {
                if(estadoNomeSelecionadoList.contains(estado.getNome())){
                	estadoNomeSelecionadoList.remove(estado.getNome());
                }
            }
        }
    }
    
    public void marcaDesmarcaCanal(Canal canal) {
        if (canal != null && canal.getSelecionado() != null) {
            if(canalNomeSelecionadoList == null){
                canalNomeSelecionadoList = new ArrayList<String>();
            }
            if (canal.getSelecionado()) {
                if(!canalNomeSelecionadoList.contains(canal.getNome())){
                    canalNomeSelecionadoList.add(canal.getNome());
                }
                
            } else {
                if(canalNomeSelecionadoList.contains(canal.getNome())){
                    canalNomeSelecionadoList.remove(canal.getNome());
                }
            }
        }
    }

    public void selecionaTodosCanais() {

        for (Canal item : canalList) {
            if (selecionaTodosCanal == Boolean.TRUE) {
                item.setSelecionado(Boolean.TRUE);
            } else {
                item.setSelecionado(Boolean.FALSE);
            }
            marcaDesmarcaCanal(item);
        }
    }

    public final void setAssuntoList(List<Assunto> assuntoList) {
        this.assuntoList = assuntoList;
    }

    public final CasoSau getCasoSauSelecionado() {
        return casoSauSelecionado;
    }

    public final void setCasoSauSelecionado(CasoSau casoSauSelecionado) {
        this.casoSauSelecionado = casoSauSelecionado;
    }

    public final List<CasoSau> getCasoSauList() {
        return casoSauList;
    }

    public final void setCasoSauList(List<CasoSau> casoSauList) {
        this.casoSauList = casoSauList;
    }

    public final CasoSau getCasoSau() {
        return casoSau;
    }

    public final void setCasoSau(CasoSau casoSau) {
        this.casoSau = casoSau;
    }

    public final String getCpfCnpj() {
        return cpfCnpj;
    }

    public final void setCpfCnpj(String cpfCnpj) {
        this.cpfCnpj = cpfCnpj;
    }

    public List<Log> getHistoricoCaso() {
        return historicoCaso;
    }

    public void setHistoricoCaso(List<Log> historicoCaso) {
        this.historicoCaso = historicoCaso;
    }

    public final String getIdManifestacao() {
        return idManifestacao;
    }

    public final void setIdManifestacao(String idManifestacao) {
        this.idManifestacao = idManifestacao;
    }

    public final List<Canal> getCanalSelecionadoList() {
        return canalSelecionadoList;
    }

    public final void setCanalSelecionadoList(List<Canal> canalSelecionadoList) {
        this.canalSelecionadoList = canalSelecionadoList;
    }

    public final boolean isSelecionaTodosCanal() {
        return selecionaTodosCanal;
    }

    public final void setSelecionaTodosCanal(boolean selecionaTodosCanal) {
        this.selecionaTodosCanal = selecionaTodosCanal;
    }

    public final boolean isSelecionaTodosEvento() {
        return selecionaTodosEvento;
    }

    public final void setSelecionaTodosEvento(boolean selecionaTodosEvento) {
        this.selecionaTodosEvento = selecionaTodosEvento;
    }

    public final boolean isSelecionaTodosTipoManifestacao() {
        return selecionaTodosTipoManifestacao;
    }

    public final void setSelecionaTodosTipoManifestacao(
            boolean selecionaTodosTipoManifestacao) {
        this.selecionaTodosTipoManifestacao = selecionaTodosTipoManifestacao;
    }

    public final boolean isSelecionaTodosAssunto() {
        return selecionaTodosAssunto;
    }

    public final void setSelecionaTodosAssunto(boolean selecionaTodosAssunto) {
        this.selecionaTodosAssunto = selecionaTodosAssunto;
    }

    public String getAssuntoNomeSelecionadoList() {
        if(assuntoNomeSelecionadoList == null || assuntoNomeSelecionadoList.toString().equals(Constantes.LISTA_STRING_VAZIA)){
            return "";
        }
        return assuntoNomeSelecionadoList.toString();
    }

    public void setAssuntoNomeSelecionadoList(List<String> assuntoNomeSelecionadoList) {
        this.assuntoNomeSelecionadoList = assuntoNomeSelecionadoList;
    }

    

    public String getCanalNomeSelecionadoList() {
        if(canalNomeSelecionadoList == null || canalNomeSelecionadoList.toString().equals(Constantes.LISTA_STRING_VAZIA)){
            return "";
        }
        return canalNomeSelecionadoList.toString();
    }

    public void setCanalNomeSelecionadoList(List<String> canalNomeSelecionadoList) {
        this.canalNomeSelecionadoList = canalNomeSelecionadoList;
    }

    

    public String getEventoNomeSelecionadoList() {
        if(eventoNomeSelecionadoList == null || eventoNomeSelecionadoList.toString().equals(Constantes.LISTA_STRING_VAZIA)){
            return "";
        }
        return eventoNomeSelecionadoList.toString();
    }

    public void setEventoNomeSelecionadoList(List<String> eventoNomeSelecionadoList) {
        this.eventoNomeSelecionadoList = eventoNomeSelecionadoList;
    }

    
    
    public List<Evento> getEventoSelecionadoList() {
        return eventoSelecionadoList;
    }

    public void setEventoSelecionadoList(List<Evento> eventoSelecionadoList) {
        this.eventoSelecionadoList = eventoSelecionadoList;
    }

    public String getTipoManifestacaoNomeSelecionadoList() {
        
        if(tipoManifestacaoNomeSelecionadoList == null || tipoManifestacaoNomeSelecionadoList.toString().equals(Constantes.LISTA_STRING_VAZIA)){
            return "";
        }
        return tipoManifestacaoNomeSelecionadoList.toString();
    }

    public void setTipoManifestacaoNomeSelecionadoList(List<String> tipoManifestacaoNomeSelecionadoList) {
        this.tipoManifestacaoNomeSelecionadoList = tipoManifestacaoNomeSelecionadoList;
    }

    public List<TipoManifestacao> getTipoManifestacaoSelecionadoList() {
        return tipoManifestacaoSelecionadoList;
    }

    public void setTipoManifestacaoSelecionadoList(List<TipoManifestacao> tipoManifestacaoSelecionadoList) {
        this.tipoManifestacaoSelecionadoList = tipoManifestacaoSelecionadoList;
    }

    public Boolean getFlagRechamado() {
        return flagRechamado;
    }

    public void setFlagRechamado(Boolean flagRechamado) {
        this.flagRechamado = flagRechamado;
    }

    @Override
    public void escondeGridEspecialista() {
        flagMostraGridTipoManifestacao = Boolean.FALSE;
        flagMostraGridCanal = Boolean.FALSE;
        flagMostraGridAssunto = Boolean.FALSE;
        flagMostraGridEvento = Boolean.FALSE;
    }
    
    public void mostraGridTipoManifestacao() {
        try {
            if (tipoManifestacaoList == null) {
                setTipoManifestacaoList(tipoManifestacaoService.findAll("TipoManifestacao.NOME"));
            }
        } catch (ServiceException e) {
            error(e);
        }
    	
        flagMostraGridTipoManifestacao = Boolean.TRUE;
    }
    
    public void mostraGridOutraArea() {
        try {
            if (outraAreaList == null) {
                setOutraAreaList(outraAreaService.findAll("OutraArea.NOME"));
            }
        } catch (ServiceException e) {
            error(e);
        }
    	
        flagMostraGridOutraArea = Boolean.TRUE;
    }
    
    public void mostraGridEstado() {
        try {
            if (estadoList == null) {
                setEstadoList(estadoService.findAll("Estado.NOME"));
            }
        } catch (ServiceException e) {
            error(e);
        }
    	
        flagMostraGridEstado = Boolean.TRUE;
    }
    
    
    
    public void mostraGridCanal() {
        try {
            if (canalList == null) {
                setCanalList(canalService.findAll("Canal.NOME"));
            }
        } catch (ServiceException e) {
            error(e);
        }
    	
        flagMostraGridCanal = Boolean.TRUE;
    }
        
    public void mostraGridAssunto() {
        try {
            if (assuntoList == null) {
                setAssuntoList(assuntoService.findAll("Assunto.NOME"));
            }
        } catch (ServiceException e) {
            error(e);
        }
        
        flagMostraGridAssunto = Boolean.TRUE;
    }
    
    public void mostraGridEvento() {
        try {
            if (eventoList == null || eventoList.isEmpty()) {
                if (assuntoSelecionadoList != null && !assuntoSelecionadoList.isEmpty()) {
                    setEventoList(eventoService.findByAssuntoList(assuntoSelecionadoList));
                } else {
                    setEventoList(eventoService.findAll("Evento.NOME"));
                }
            }
        } catch (ServiceException e) {
            error(e);
        }
    	
        flagMostraGridEvento = Boolean.TRUE;
    }

    public boolean isFlagMostraGridAssunto() {
        return flagMostraGridAssunto;
    }

    public void setFlagMostraGridAssunto(boolean flagMostraGridAssunto) {
        this.flagMostraGridAssunto = flagMostraGridAssunto;
    }

    public boolean isFlagMostraGridCanal() {
        return flagMostraGridCanal;
    }

    public void setFlagMostraGridCanal(boolean flagMostraGridCanal) {
        this.flagMostraGridCanal = flagMostraGridCanal;
    }

    public boolean isFlagMostraGridEvento() {
        return flagMostraGridEvento;
    }

    public void setFlagMostraGridEvento(boolean flagMostraGridEvento) {
        this.flagMostraGridEvento = flagMostraGridEvento;
    }

    public boolean isFlagMostraGridTipoManifestacao() {
        return flagMostraGridTipoManifestacao;
    }

    public void setFlagMostraGridTipoManifestacao(boolean flagMostraGridTipoManifestacao) {
        this.flagMostraGridTipoManifestacao = flagMostraGridTipoManifestacao;
    }

	public String getViaEntrada() {
		return viaEntrada;
	}

	public void setViaEntrada(String viaEntrada) {
		this.viaEntrada = viaEntrada;
	}

	public List<Estado> getEstadoList() {
		return estadoList;
	}

	public void setEstadoList(List<Estado> estadoList) {
		this.estadoList = estadoList;
	}

	public List<OutraArea> getOutraAreaList() {
		return outraAreaList;
	}

	public void setOutraAreaList(List<OutraArea> outraAreaList) {
		this.outraAreaList = outraAreaList;
	}

	public boolean isSelecionaTodasArea() {
		return selecionaTodasArea;
	}

	public void setSelecionaTodasArea(boolean selecionaTodasArea) {
		this.selecionaTodasArea = selecionaTodasArea;
	}

	public boolean isSelecionaTodosEstados() {
		return selecionaTodosEstados;
	}

	public void setSelecionaTodosEstados(boolean selecionaTodosEstados) {
		this.selecionaTodosEstados = selecionaTodosEstados;
	}

	public String getEstadoNomeSelecionadoList() {
		if(estadoNomeSelecionadoList == null || estadoNomeSelecionadoList.toString().equals(Constantes.LISTA_STRING_VAZIA)){
            return "";
		}
		return estadoNomeSelecionadoList.toString();
	}

	public void setEstadoNomeSelecionadoList(List<String> estadoNomeSelecionadoList) {
		this.estadoNomeSelecionadoList = estadoNomeSelecionadoList;
	}

	public String getOutraAreaNomeSelecionadoList() {
		 if(outraAreaNomeSelecionadoList == null || outraAreaNomeSelecionadoList.toString().equals(Constantes.LISTA_STRING_VAZIA)){
	            return "";
	     }
		return outraAreaNomeSelecionadoList.toString();
	}

	public void setOutraAreaNomeSelecionadoList(List<String> outraAreaNomeSelecionadoList) {
		this.outraAreaNomeSelecionadoList = outraAreaNomeSelecionadoList;
	}

	public List<Estado> getEstadoSelecionadoList() {
		return estadoSelecionadoList;
	}

	public void setEstadoSelecionadoList(List<Estado> estadoSelecionadoList) {
		this.estadoSelecionadoList = estadoSelecionadoList;
	}

	public List<OutraArea> getOutraAreaSelecionadoList() {
		return outraAreaSelecionadoList;
	}

	public void setOutraAreaSelecionadoList(List<OutraArea> outraAreaSelecionadoList) {
		this.outraAreaSelecionadoList = outraAreaSelecionadoList;
	}

	public boolean isFlagMostraGridOutraArea() {
		return flagMostraGridOutraArea;
	}

	public void setFlagMostraGridOutraArea(boolean flagMostraGridOutraArea) {
		this.flagMostraGridOutraArea = flagMostraGridOutraArea;
	}

	public boolean isFlagMostraGridEstado() {
		return flagMostraGridEstado;
	}

	public void setFlagMostraGridEstado(boolean flagMostraGridEstado) {
		this.flagMostraGridEstado = flagMostraGridEstado;
	}

	@Override
	public void novo() {
		
	}

	@Override
	protected ICasoService getService() {
		return casoService;
	}
	
}
