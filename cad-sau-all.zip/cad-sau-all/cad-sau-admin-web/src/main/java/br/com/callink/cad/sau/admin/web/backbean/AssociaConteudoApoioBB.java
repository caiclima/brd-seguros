package br.com.callink.cad.sau.admin.web.backbean;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.model.SelectItem;

import br.com.callink.cad.sau.pojo.AssociaConteudoApoio;
import br.com.callink.cad.sau.pojo.Assunto;
import br.com.callink.cad.sau.pojo.ConteudoApoio;
import br.com.callink.cad.sau.pojo.Evento;
import br.com.callink.cad.sau.service.IAssociaConteudoApoioService;
import br.com.callink.cad.sau.service.IAssuntoService;
import br.com.callink.cad.sau.service.IConteudoApoioService;
import br.com.callink.cad.sau.service.IEventoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.util.JSFUtil;

/**
 * 
 * @author Ednaldo Caic [ednaldo@swb.com.br]
 * 
 */
@ManagedBean
@ViewScoped
public class AssociaConteudoApoioBB extends GboSauAdminGenericCrud<AssociaConteudoApoio,IAssociaConteudoApoioService> {

    private static final long serialVersionUID = 1L;
    private List<Evento> listEvento;
    private List<Assunto> listAssunto;
    private List<ConteudoApoio> listConteudoApoio;
    
    @EJB
    private IAssociaConteudoApoioService associaConteudoApoioService;
    
    @EJB
    private IEventoService eventoService;
    
    @EJB
    private IConteudoApoioService conteudoApoioService;
    
    @EJB
    private IAssuntoService assuntoService;
    
    @Override
	protected IAssociaConteudoApoioService getService() {
		return associaConteudoApoioService;
	}

    @PostConstruct
    public void init() {
    	novo();
        filtrar();
    }
    
    @Override
    public void novo() {
        setPojo(new AssociaConteudoApoio());
        getPojo().setEvento(new Evento());
        getPojo().setConteudoApoio(new ConteudoApoio());
        filtrar();
    }

    @Override
    public String filtrar() {
        try {
            setPojos(getService().buscaTodosComObjetosPreenchidos(getPojo()));
        } catch (ServiceException ex) {
            error("Erro ao tentar realizar pesquisa.");
        }
        return "";
    }

    public void filtrarEvento() {
        try {
            getPojo().getEvento().setFlagAtivo(Boolean.TRUE);
            listEvento = eventoService.findByExample(getPojo().getEvento(), "Evento.NOME");
        } catch (ServiceException ex) {
            error(ex);
        }
    }

    public void filtrarConteudoApoio() {
        try {
            getPojo().getConteudoApoio().setFlagAtivo(Boolean.TRUE);
            listConteudoApoio = conteudoApoioService.findByExample(getPojo().getConteudoApoio(), "ConteudoApoio.NOME");
        } catch (ServiceException ex) {
            error(ex);
        }
    }

	@Override
	public String salvar() {
		try {
			if (getPojo().getConteudoApoio() == null
					|| getPojo().getEvento() == null
					|| getPojo().getConteudoApoio().getDescricao() == null
					|| getPojo().getEvento().getNome() == null
					|| "".equals(getPojo().getConteudoApoio().getDescricao())
					|| "".equals(getPojo().getEvento().getNome())) {
				error(new ServiceException(
						"Os campos Conteúdo Apoio e Evento devem ser preenchidos."));
			} else {
				getService().save(getPojo());
				novo();
			}
		} catch (ValidationException ex) {
			error(ex.getMessage());
		} catch (ServiceException ex) {
			error(ex);
		}
		return null;
	}

    public String excluir(AssociaConteudoApoio associaConteudoApoio) {
        try {
            getService().delete(associaConteudoApoio);
            novo();
        }catch (ValidationException ex) {
        	error(ex.getMessage());
        } catch (ServiceException ex) {
            error(ex);
        }
        return null;
    }

    public void limpaEvento() {
        setEvento(new Evento());
    }

    public void setEvento(Evento evento) {
        getPojo().setEvento(evento);
    }


    public void limpaConteudoApoio() {
        getPojo().setConteudoApoio(new ConteudoApoio());
    }

    public void setConteudoApoio(ConteudoApoio conteudoApoio) {
        getPojo().setConteudoApoio(conteudoApoio);
    }

    public final List<Evento> getListEvento() {
        return listEvento;
    }

    public final void setListEvento(List<Evento> listEvento) {
        this.listEvento = listEvento;
    }

    public final List<SelectItem> getAssuntoList() {
        try {
            if (listAssunto == null || listAssunto.isEmpty()) {
                setListAssunto(assuntoService.findAtivos("Assunto.NOME"));
            }
        } catch (ServiceException e) {
            error(e);
        }
        return JSFUtil.toSelectItemConsulta(listAssunto);
    }

    public final void setAssuntoList(List<Assunto> listAssunto) {
        this.listAssunto = listAssunto;
    }

    public final List<Assunto> getListAssunto() {
        return listAssunto;
    }

    public final void setListAssunto(List<Assunto> listAssunto) {
        this.listAssunto = listAssunto;
    }

    public final List<ConteudoApoio> getListConteudoApoio() {
        return listConteudoApoio;
    }

    public final void setListConteudoApoio(List<ConteudoApoio> listConteudoApoio) {
        this.listConteudoApoio = listConteudoApoio;
    }

}
