package br.com.callink.cad.sau.admin.web.backbean;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.model.SelectItem;

import br.com.callink.cad.sau.pojo.AssociaQuestionario;
import br.com.callink.cad.sau.pojo.Assunto;
import br.com.callink.cad.sau.pojo.Evento;
import br.com.callink.cad.sau.pojo.Questionario;
import br.com.callink.cad.sau.service.IAssociaQuestionarioService;
import br.com.callink.cad.sau.service.IAssuntoService;
import br.com.callink.cad.sau.service.IEventoService;
import br.com.callink.cad.sau.service.IQuestionarioService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.util.JSFUtil;

/**
 * 
 * @author ubuntu
 * 
 */
@ManagedBean
@ViewScoped
public class AssociaQuestionarioBB extends GboSauAdminGenericCrud<AssociaQuestionario, IAssociaQuestionarioService> {

    private static final long serialVersionUID = 1L;
    private List<Evento> listEvento;
    private List<Assunto> listAssunto;
    private List<Questionario> listQuestionario;
    
    @EJB
    private IAssociaQuestionarioService associaQuestionarioService;
    @EJB
    private IAssuntoService assuntoService;
    @EJB
    private IEventoService eventoService;
    @EJB
    private IQuestionarioService questionarioService;
    
    
    @Override
    protected IAssociaQuestionarioService getService() {
    	return associaQuestionarioService;
    }

    
    @PostConstruct
    public void init() {
    	novo();
        filtrar();
        try {
            listAssunto = assuntoService.findAtivos("Assunto.NOME");
        } catch (ServiceException ex) {
            error(ex);
        }
    }

    @Override
    public void novo() {
        AssociaQuestionario poj = new AssociaQuestionario();
        Evento event = new Evento();
        event.setFlagAtivo(Boolean.TRUE);
        poj.setEvento(event);
        poj.setQuestionario(new Questionario());
        poj.setFlagCheckList(Boolean.TRUE);
        setPojo(poj);
        filtrar();
    }

    @Override
    public String filtrar() {
        try {
            setPojos(getService().findByExample(getPojo()));
        } catch (ServiceException ex) {
            error(ex);
        }
        return null;
    }

    public void filtrarEvento() {
        try {
            this.listEvento = eventoService.findByExample(getPojo().getEvento(), "Evento.NOME");
        } catch (ServiceException ex) {
            error(ex);
        }
    }

    public void filtrarQuestionario() {
        try {
            this.listQuestionario = questionarioService.findByExample(getPojo().getQuestionario(), "Questionario.DESCRICAO");
        } catch (ServiceException ex) {
            error(ex);
        }
    }

    @Override
    public String salvar() {
        try {
        	if (getPojo().getEvento() == null || getPojo().getEvento().getNome() == null
        			|| getPojo().getQuestionario() == null || getPojo().getQuestionario().getDescricao() == null
        			|| "".equals(getPojo().getEvento().getNome())
        			|| "".equals(getPojo().getQuestionario().getDescricao())) {
        		error(new ServiceException("Os campos Evento e Questionário devem ser preenchidos."));
        	} else {
	            getService().save(getPojo());
	            novo();
        	}
        } catch (ServiceException ex) {
            error(ex);
        } catch (ValidationException e) {
        	error(e.getMessage());
		}
        return null;
    }

    public String excluir(AssociaQuestionario associaQuestionario) {
        try {
            getService().delete(associaQuestionario);
            novo();
        } catch (ServiceException ex) {
            error(ex);
        } catch (ValidationException e) {
        	error(e.getMessage());
		}
        return null;
    }

    public void limpaEvento() {
        setEvento(new Evento());
    }

    public void setEvento(Evento evento) {
        getPojo().setEvento(evento);
    }

    public void limpaQuestionario() {
        getPojo().setQuestionario(new Questionario());
    }

    public void setQuestionario(Questionario questionario) {
        getPojo().setQuestionario(questionario);
    }

    public List<Evento> getListEvento() {
        return listEvento;
    }

    public void setListEvento(List<Evento> listEvento) {
        this.listEvento = listEvento;
    }

    public final List<SelectItem> getAssuntoList() {
        return JSFUtil.toSelectItemConsulta(listAssunto);
    }

    public final void setAssuntoList(List<Assunto> listAssunto) {
        this.listAssunto = listAssunto;
    }

    public List<Questionario> getListQuestionario() {
        return listQuestionario;
    }

    public void setListQuestionario(List<Questionario> listQuestionario) {
        this.listQuestionario = listQuestionario;
    }
}
