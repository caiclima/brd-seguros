package br.com.callink.cad.sau.admin.web.backbean;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.sau.pojo.Assunto;
import br.com.callink.cad.sau.service.IAssuntoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 *
 * @author Ednaldo Caic [ednaldo@swb.com.br]
 * @since 19/01/2012
 */
@ManagedBean
@ViewScoped
public class AssuntoBB extends GboSauAdminGenericCrud<Assunto, IAssuntoService> {

    private static final long serialVersionUID = 1L;
    
    private String flagAtivo;
    
    @EJB
    private IAssuntoService assuntoService;
    
    protected IAssuntoService getService() {
    	return assuntoService;
    }
    
    @PostConstruct
    public void init() {
    	setPojo(new Assunto());
    	atualiza();
    }

    @Override
    public String salvar() {
    	String ret = "";
    	
    	if (getPojo() == null || getPojo().getNome() == null || "".equals(getPojo().getNome())) {
    		error(new Exception("O campo Nome não pode estar vazio."));
    	} else {
	    	ret = super.salvar();
	    	if (getPojo().getPK() != null) {
	        	novo();
	        	atualiza();
	        }
    	}
        return ret;
    }

    
    @Override
    public void novo() {
    	setPojo(new Assunto());
        try {
            setPojos(getService().findByExample(getPojo(), "Assunto.NOME"));
        } catch (ServiceException e) {
            error(e);
        }
    }
    
    @Override
    public String filtrar() {
        try {
            setPojos(getService().findByExample(getPojo(), "Assunto.NOME"));
        } catch (ServiceException ex) {
            error(ex);
        }
        return null;
    }
    
	public String excluir(Assunto assunto) {
        try {
            getService().delete(assunto);
            atualiza();

        } catch (ServiceException ex) {
            error(ex);
        } catch (ValidationException e) {
        	error(e.getMessage());
		}
        return null;
    }

    public void alterar(Assunto assunto) {
        setPojo(assunto);
    }

	private void atualiza() {
        try {
            setPojos(getService().findByExample(getPojo(), "Assunto.NOME"));
            getPojo().setFlagAtivo(Boolean.TRUE);
            setFlagAtivo(Boolean.TRUE.toString());
        } catch (ServiceException ex) {
            error(ex);
        }
    }
	
	public String getFlagAtivo() {
		return flagAtivo;
	}

	public void setFlagAtivo(String flagAtivo) {
		this.flagAtivo = flagAtivo;
		
		if(StringUtils.isBlank(flagAtivo)){
			getPojo().setFlagAtivo(null);
		}else{
			getPojo().setFlagAtivo(Boolean.valueOf(flagAtivo));
		}
	}
}
