package br.com.callink.cad.sau.admin.web.backbean;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.sau.pojo.Canal;
import br.com.callink.cad.sau.service.ICanalService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 * 
 * @author brunomt [brunoam@swb.com.br]
 * 
 */
@ManagedBean
@ViewScoped
public class CanalBB extends GboSauAdminGenericCrud<Canal, ICanalService> {

    private static final long serialVersionUID = 1L;
    
    @EJB
    private ICanalService canalService;
    
    private String flagAtivo;
    
    private String flagCasoManual;
    
    protected ICanalService getService(){
    	return canalService;
    }

    @PostConstruct
    public void init() {
    	novo();
    }
    
    @Override
    public String salvar() {
        String ret = super.salvar();
        if (getPojo().getIdCanal() != null) {
            novo();
            filtrar();
        }
        return ret;
    }

    @Override
    public String filtrar() {
        try {
            setPojos(getService().findByExample(getPojo(), "Canal.NOME"));
        } catch (Exception e) {
            error(e);
        }
        return null;
    }

    public void alterar(Canal canal) {
        setPojo(canal);
    }

    public String excluir(Canal canal) {
        try {
            getService().inativar(canal);
        } catch (ServiceException ex) {
            error(ex);
        } catch (ValidationException e) {
        	error(e.getMessage());
		}
        return null;
    }

    @Override
    public void novo() {
        setPojo(new Canal());
		filtrar();
    }

	public String getFlagAtivo() {
		return flagAtivo;
	}

	public void setFlagAtivo(String flagAtivo) {
		this.flagAtivo = flagAtivo;
		
		if(StringUtils.isBlank(flagAtivo)){
			getPojo().setFlagAtivo(null);
		}else{
			getPojo().setFlagAtivo(Boolean.valueOf(flagAtivo));
		}
	}

	public String getFlagCasoManual() {
		return flagCasoManual;
	}

	public void setFlagCasoManual(String flagCasoManual) {
		this.flagCasoManual = flagCasoManual;
		
		if(StringUtils.isBlank(flagCasoManual)){
			getPojo().setFlagCasoManual(null);
		}else{
			getPojo().setFlagCasoManual(Boolean.valueOf(flagCasoManual));
		}
	}
}
