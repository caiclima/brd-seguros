package br.com.callink.cad.sau.admin.web.backbean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.model.SelectItem;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.engine.command.executor.IExecutorCommandService;
import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.Log;
import br.com.callink.cad.sau.pojo.CasoFechado;
import br.com.callink.cad.sau.pojo.Causa;
import br.com.callink.cad.sau.pojo.EventoCausa;
import br.com.callink.cad.sau.service.ICasoFechadoService;
import br.com.callink.cad.sau.service.IEventoCausaService;
import br.com.callink.cad.service.IAcaoService;
import br.com.callink.cad.service.IAtendenteService;
import br.com.callink.cad.service.ILogService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.util.Constantes;
import br.com.callink.cad.util.JSFUtil;
import br.com.callink.cad.util.PropertieUtils;

/**
 * 
 * @author brunomt [brunoam@swb.com.br]
 * 
 */
@ManagedBean
@ViewScoped
public class CasoFechadoBB extends GboSauAdminGenericCrud<CasoFechado, ICasoFechadoService> {

    private static final long serialVersionUID = 1L;
    private List<Causa> causaList;
    private Causa causaSelecionada;
    
    private List<Log> historicoCaso;
    
    @EJB
    private ICasoFechadoService casoFechadoService;
    @EJB
    private ILogService logService;
    @EJB
    private IEventoCausaService eventoCausaService;
    @EJB
    private IAcaoService acaoService;
    @EJB
    private IAtendenteService atendenteService;
    @EJB(beanName="ExecutorCommandService")
    private IExecutorCommandService executorCommandService;
    
    protected ICasoFechadoService getService() {
    	return casoFechadoService;
    }
    
    @PostConstruct
    public void init() {
    	setPojo(new CasoFechado());
    	try {
            setPojos(casoFechadoService.buscaCasosFechadosSpaAbertosGbo());
        } catch (ServiceException e) {
            error(e);
        }
    }

    @Override
    public String filtrar() {
        try {
            getPojos().clear();
            if (getPojo() != null && StringUtils.isNotBlank(getPojo().getManifestacao())) {
            	CasoFechado casoFechado = casoFechadoService.buscaPorManifestacao(getPojo().getManifestacao());
                if (casoFechado != null) {
                	getPojos().add(casoFechado);
                }
            } else {
                setPojos(casoFechadoService.buscaCasosFechadosSpaAbertosGbo());
            }
        } catch (ServiceException e) {
            error(e);
        }
        return "";
    }

    @Override
    public void novo() {
        try {
            setPojos(casoFechadoService.findAll());
        } catch (ServiceException e) {
            error(e);
        }
    }
    
    public void atualizaHistorico() {
        try {
            historicoCaso = logService.findHistorico(getPojo().getCasoSau().getCaso());
        } catch (ServiceException ex) {
            error(ex);
        }
    }

    public void buscaCausaList() {
        try {

            if (getPojo().getCasoSau().getEvento() == null || getPojo().getCasoSau().getEvento().getPK() == null) {
                error("Caso não pode ser finalizado pois não existe um evento vinculado ao caso aberto. Favor enviar caso para ser classificado.");
                return;
            }
            List<EventoCausa> eventoCausaList = eventoCausaService.findByEventoCausa(getPojo().getCasoSau().getEvento(), null);
            
            if(eventoCausaList == null || eventoCausaList.isEmpty()){
                error("Caso não pode ser finalizado pois não existe uma causa vinculada ao evento do caso aberto. Favor enviar caso para ser classificado.");
                return;
            }
            if (causaList == null) {
                setCausaList(new ArrayList<Causa>());
            }
            getCausaList().clear();
            for (EventoCausa eventoCausa : eventoCausaList) {
                causaList.add(eventoCausa.getCausa());
            }
            setCausaSelecionada(null);

        } catch (ServiceException e) {
            error("Erro ao buscar lista de causas");
        }
    }

    public void finalizaCaso() {
        try {

            if (causaSelecionada == null || causaSelecionada.getPK() == null) {
                error("Campo Obrigat\u00F3rio : Causa ");
                return;
            }

            String nomeAcaoFinalizar = PropertieUtils.getPropertieByArquivoAndChave(
                    Constantes.CAMINHO_ARQUIVO_PROPERTIES_CONFIGURACAO_TELA,
                    Constantes.NOME_ARQUIVO_PROPERTIE,
                    Constantes.CHAVE_NOME_ACAO_FINALIZAR_CASO_STGM);

            Acao acao = new Acao();
            acao.setNome(nomeAcaoFinalizar);
            acao = acaoService.findByNome(acao);

            if (acao == null) {
                error("Erro : N\u00E3o foi poss\u00EDvel finalizar o Caso, pois n\u00E3o foi encontrado uma A\u00E7\u00E3o Finalizar!");
                return;
            }
            
            Map<String, Object> parametros = new HashMap<String, Object>();
            
            Atendente atendente = atendenteService.findByLogin(getUserInfo().getUserLogin());
            
            parametros.put("caso", getPojo().getCasoSau().getCaso());
            parametros.put("acao", acao);
            parametros.put("observacao", "Caso finalizado pelo usuário: " + getUserInfo().getUserLogin() + " na tela de caso_fechado");
            parametros.put("casoSau", getPojo().getCasoSau());
            parametros.put("naoSalvaStatus", Boolean.TRUE);
            getPojo().getCasoSau().setCausa(causaSelecionada);
            getPojo().getCasoSau().getCaso().setAtendente(atendente);
            
            executorCommandService.execute(parametros);
            
            setPojo(new CasoFechado());
            filtrar();

        } catch (ServiceException ex) {
            error(ex);
        } catch (ValidationException e) {
        	error(e.getMessage());
		}
    }
    
    public void merge(CasoFechado casoFechado) {
        setPojo(casoFechado);
        atualizaHistorico();
    }

    public final Causa getCausaSelecionada() {
        return causaSelecionada;
    }

    public final void setCausaSelecionada(Causa causaSelecionada) {
        this.causaSelecionada = causaSelecionada;
    }

    public final List<SelectItem> getCausaList() {
        if (causaList == null) {
            setCausaList(new ArrayList<Causa>());
        }
        return JSFUtil.toSelectItemConsulta(causaList);
    }

    public final void setCausaList(List<Causa> causaList) {
        this.causaList = causaList;
    }

    public final List<Log> getHistoricoCaso() {
        return historicoCaso;
    }

    public final void setHistoricoCaso(List<Log> historicoCaso) {
        this.historicoCaso = historicoCaso;
    }

    
    
}
