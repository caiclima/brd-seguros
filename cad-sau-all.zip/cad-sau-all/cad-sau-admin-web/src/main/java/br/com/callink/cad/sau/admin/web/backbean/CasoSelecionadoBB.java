/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.sau.admin.web.backbean;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.Email;
import br.com.callink.cad.pojo.Log;
import br.com.callink.cad.pojo.LogLigacoes;
import br.com.callink.cad.pojo.ReaberturaCaso;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.pojo.Resposta;
import br.com.callink.cad.sau.pojo.ResultadoQuestionario;
import br.com.callink.cad.sau.service.ICasoSauService;
import br.com.callink.cad.sau.service.IRespostaService;
import br.com.callink.cad.sau.service.IResultadoQuestionarioService;
import br.com.callink.cad.service.ILogLigacoesService;
import br.com.callink.cad.service.ILogService;
import br.com.callink.cad.service.IReaberturaCasoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.coreutils.util.csv.CsvUtils;

/**
 *
 * @author Luiz Gustavo (luizgf@swb.com.br)
 */
@ManagedBean
@ViewScoped
public class CasoSelecionadoBB extends GboSauAdminGenericCrud<CasoSau, ICasoSauService> {

	private static final long serialVersionUID = -3067915637504531637L;
	private List<Log> historicoCaso;
    private CasoSau casoSau;
    private Boolean temQuestionario;
    private List<Object[]> listQuestionario;
    private Integer idResultadoQuestionarioSelecionado;
    private List<Resposta> listaRespostas;
    private List<Log> logEmails;
    private Email emailSelecionado;
    private List<LogLigacoes> logLigacoesList;
    private String contextPath;
    
    @EJB
    private ICasoSauService casoSauService;
    @EJB
    private IReaberturaCasoService reaberturaCasoService;
    @EJB
    private ILogService logService;
    @EJB
    private ILogLigacoesService logLigacoesService;
    @EJB
    private IResultadoQuestionarioService resultadoQuestionarioService;
    @EJB
    private IRespostaService respostaService;
    
    
    protected ICasoSauService getService() {
    	return casoSauService;
    }
    
    @PostConstruct
    public void init() {
    	setPojo(new CasoSau());
    	historicoCaso = new ArrayList<Log>();
        casoSau = new CasoSau();
        logEmails = new ArrayList<Log>();
        emailSelecionado = new Email();
        HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        setContextPath(request.getContextPath() + "/exportarCsv");
    }

    public void clean() {
    	
        getSessionMap().put("casoSelecionado", new CasoSau());
        casoSau = new CasoSau();
        historicoCaso = new ArrayList<Log>();
        emailSelecionado = new Email();
        if (listQuestionario != null) {
            listQuestionario.clear();
        }
        if (listaRespostas != null) {
            listaRespostas.clear();
        }
        if (logEmails != null) {
            logEmails.clear();
        }
    }
    
    public void visualizaCasoSauByCaso(Caso caso){
        try {
            setCasoSau(getService().findCasoSauByCaso(caso));
            getCasoSau().setCaso(caso);
            
        } catch (ServiceException ex) {
            error("Erro ao carregar caso.");
        }
    }

    public void atualiza() {
        CasoSau caso = (CasoSau) getSessionMap().get("casoSelecionado");
        if (caso != null && caso.getPK() != null) {
            casoSau = caso;
            atualizaHistorico();
            atualizaEmails();
            verificaRechamado();
            carregaQuestionarios();
        }
    }

    public boolean verificaRechamado() {
        try {
            List<ReaberturaCaso> reaberturaList = reaberturaCasoService.findByCaso(casoSau.getCaso());
            if (reaberturaList == null || reaberturaList.isEmpty()) {
                casoSau.setFlagRechamado(Boolean.FALSE);
            } else {
                casoSau.setFlagRechamado(Boolean.TRUE);
            }
        } catch (ServiceException ex) {
            error(ex);
        }
        return false;
    }

    public void gerarCSV() {
        
    	casoSau = (CasoSau) getSessionMap().get("casoSelecionado");
    	
    	CsvUtils csv = new CsvUtils("casos.csv", null);

        List<Object> tabela = new ArrayList<Object>();
        
        criaCsvCaso(tabela);
        
        HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        
        // COLOCA O OBJETO DO RELATORIO NA SESSAO
        if (request.getSession(false) != null) {
            request.getSession().setAttribute("arquivo",
                    csv.createContents(tabela.toArray()));
        } else {
            error("Sess\u00E3o expirada!");
        }
        
    }
    
    private void criaCsvCaso( List<Object> tabela){
    	
    	List<Object> linhaAtual = new ArrayList<Object>();
        
    	linhaAtual.add("MANIFESTACAO");
    	linhaAtual.add("TIPO DE MANIFESTACAO");
        linhaAtual.add("ASSUNTO");
        linhaAtual.add("CLIENTE");
        linhaAtual.add("CPF/CNPJ");
        linhaAtual.add("TELEFONE");
        linhaAtual.add("EVENTO");
        
        // do Log historico List
        linhaAtual.add("DATA DO CASO");
        linhaAtual.add("DESCRIÇÃO");
        linhaAtual.add("ANALISTA");
        linhaAtual.add("SLA");
        linhaAtual.add("TEMPO DECORRIDO");
        linhaAtual.add("AÇÃO");
        linhaAtual.add("STATUS");
        
        tabela.add(linhaAtual.toArray());
        
        if (historicoCaso != null) {
                
        	for (Log historico : historicoCaso) {
        	
        		linhaAtual = new ArrayList<Object>();
                linhaAtual.add(StringUtils.isBlank(casoSau.getManifestacao()) ? "" : casoSau.getManifestacao());
                
                if(casoSau.getTipoManifestacao()!=null && StringUtils.isNotBlank(casoSau.getTipoManifestacao().getNome())){
                	linhaAtual.add(casoSau.getTipoManifestacao().getNome());
                }else{
                	linhaAtual.add("");
                }
                
                linhaAtual.add(StringUtils.isBlank(casoSau.getAssunto())? "" : casoSau.getAssunto());
                linhaAtual.add(StringUtils.isBlank(casoSau.getNomeCliente()) ? "" : casoSau.getNomeCliente());
                linhaAtual.add(StringUtils.isBlank(casoSau.getCpfCnpj()) ? "" : casoSau.getCpfCnpj());
                linhaAtual.add(StringUtils.isBlank(casoSau.getTelefone()) ? "" : casoSau.getTelefone());
                
                if(casoSau.getEvento() != null && StringUtils.isNotBlank(casoSau.getEvento().getNome())){
                	linhaAtual.add(casoSau.getEvento().getNome());
                }else{
                	linhaAtual.add("");
                }
                
                linhaAtual.add(historico.getDataLog() == null ? "" : historico.getDataLog());
                linhaAtual.add(historico.getDescricao() == null ? "" : historico.getDescricao());
                
                if(historico.getAtendente() != null && StringUtils.isNotBlank(historico.getAtendente().getNome())){
                	linhaAtual.add(historico.getAtendente());
                }else{
                	linhaAtual.add("");
                }
                
                linhaAtual.add(StringUtils.isBlank(historico.getSlaLog()) ? "" : historico.getSlaLog());
                linhaAtual.add(StringUtils.isBlank(historico.getTempoGasto()) ? "" : historico.getTempoGasto());
                
                if(historico.getAcao()!=null && StringUtils.isNotBlank(historico.getAcao().getNome())){
                	linhaAtual.add(historico.getAcao().getNome());
                }else{
                	linhaAtual.add("");
                }
                
                if(historico.getStatus()!=null && StringUtils.isNotBlank(historico.getStatus().getNome())){
                	linhaAtual.add(historico.getStatus().getNome());
                }else{
                	linhaAtual.add("");
                }
                
                tabela.add(linhaAtual.toArray());
        	}
        }
    }
    
    public void atualizaHistorico() {
        try {
            historicoCaso = logService.findHistorico(casoSau.getCaso());
        } catch (ServiceException ex) {
            error(ex);
        }
    }
    
    public void atualizaHistoricoLigacoes() {
    	try {
            if (getPojo() != null) {
                this.setLogLigacoesList(logLigacoesService.findByFilters(casoSau.getManifestacao(), null, null, null, null));
            }
        } catch (ValidationException ex) {
            error(ex.getMessage());
        }catch (ServiceException ex) {
            error(ex);
        }
    }
    
    public void atualizaEmails() {
        try {
            logEmails = logService.findHistoricoEmail(casoSau.getCaso());
        } catch (ServiceException ex) {
            error(ex);
        }
    }

    public List<Log> getHistoricoCaso() {
        if (casoSau == null || casoSau.getPK() == null) {
            atualiza();
        }
        return historicoCaso;
    }

    public void setHistoricoCaso(List<Log> historicoCaso) {
        this.historicoCaso = historicoCaso;
    }

    public CasoSau getCasoSau() {
    	
    	if (casoSau==null || casoSau.getPK() == null) {
            atualiza();
        }
        return casoSau;
    }
    
    public void setCasoSau(CasoSau casoSau) {
        this.casoSau = casoSau;
    }
    
    

    public void carregaQuestionarios() {
        try {
            listQuestionario = resultadoQuestionarioService.questionariosRespondidos(casoSau.getIdCasoSau());
            if (listQuestionario != null && listQuestionario.size() > 0) {
                temQuestionario = true;
            } else {
                temQuestionario = false;
            }
        } catch (ServiceException ex) {
            error(ex);
        }
    }

    public void carregaRespostas(Integer idResultadoQuestionario) {
        try {
            this.listaRespostas = respostaService.respostasByResultadoQuestionario(new ResultadoQuestionario(idResultadoQuestionario));
            for(Resposta resposta:listaRespostas){
                resposta.getQuestao().setRendered(Boolean.TRUE);
            }
        } catch (ServiceException ex) {
            error(ex);
        }
    }

    public Integer getIdResultadoQuestionarioSelecionado() {
        return idResultadoQuestionarioSelecionado;
    }

    public void setIdResultadoQuestionarioSelecionado(Integer idResultadoQuestionarioSelecionado) {
        this.idResultadoQuestionarioSelecionado = idResultadoQuestionarioSelecionado;
    }

    public List<Object[]> getListQuestionario() {
        return listQuestionario;
    }

    public void setListQuestionario(List<Object[]> listQuestionario) {
        this.listQuestionario = listQuestionario;
    }

    public List<Resposta> getListaRespostas() {
        return listaRespostas;
    }

    public void setListaRespostas(List<Resposta> listaRespostas) {
        this.listaRespostas = listaRespostas;
    }

    public Boolean getTemQuestionario() {
        return temQuestionario;
    }

    public void setTemQuestionario(Boolean temQuestionario) {
        this.temQuestionario = temQuestionario;
    }

    public List<Log> getLogEmails() {
        if (casoSau == null || casoSau.getPK() == null) {
            atualiza();
        }
        return logEmails;
    }

    public void setLogEmails(List<Log> emails) {
        this.logEmails = emails;
    }
    
    public void visualizarEmail(Email email) {
        emailSelecionado = email;
        buscaAnexos(emailSelecionado.getGrupoAnexo().getIdGrupoAnexo());
    }
    
    public String getRemetenteOuDestinatario(Email email) {
        if (email.getFlagEnvio() == null) {
            return null;
        }
        return email.getFlagEnvio() ? //foi enviado pelo gbo? 
                email.getDestinatarioParaExibicao() == null ? //mostra destinatario p/ exibiçao se houver
                email.getDestinatario() : email.getDestinatarioParaExibicao() //senao mostra o campo destinatario
                : email.getRemetente(); //se foi recebido mostra remetente
    }

    public Email getEmailSelecionado() {
        return emailSelecionado;
    }

    public void setEmailSelecionado(Email emailSelecionado) {
        this.emailSelecionado = emailSelecionado;
        if (emailSelecionado.getGrupoAnexo() != null && emailSelecionado.getGrupoAnexo().getIdGrupoAnexo() != null) {
        	buscaAnexos(emailSelecionado.getGrupoAnexo().getIdGrupoAnexo());	
        }
    }
    
    public String getDestinatarioSelecionado() {
        if (emailSelecionado == null) {
            return null;
        }
        return emailSelecionado.getDestinatarioParaExibicao() == null ?
                emailSelecionado.getDestinatario() : emailSelecionado.getDestinatarioParaExibicao();
    }

	public List<LogLigacoes> getLogLigacoesList() {
		return logLigacoesList;
	}

	public void setLogLigacoesList(List<LogLigacoes> logLigacoesList) {
		this.logLigacoesList = logLigacoesList;
	}

	public String getContextPath() {
		return contextPath;
	}

	public void setContextPath(String contextPath) {
		this.contextPath = contextPath;
	}


	@Override
	public void novo() {
		try {
            setPojos(getService().findByExample(getPojo(), "CasoSau.MANIFESTACAO"));
        } catch (ServiceException e) {
            error(e);
        }
	}
    
}
