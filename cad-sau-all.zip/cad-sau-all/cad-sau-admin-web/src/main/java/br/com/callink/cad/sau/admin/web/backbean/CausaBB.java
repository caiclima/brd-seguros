/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.sau.admin.web.backbean;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.sau.pojo.Causa;
import br.com.callink.cad.sau.service.ICausaService;
import br.com.callink.cad.service.exception.ServiceException;

/**
 *
 * @author Rogerio
 */
@ManagedBean
@ViewScoped
public class CausaBB extends GboSauAdminGenericCrud<Causa, ICausaService> {

    private static final long serialVersionUID = 1L;
    
    
    private String flagAtivo;
    
    @EJB
    private ICausaService causaService;
    
    protected ICausaService getService() {
    	return causaService;
    }

    @PostConstruct
    public void init() {
    	setPojo(new Causa());
    	atualiza();
    }
    
    private void atualiza() {
        try {
            setPojos(getService().findByExample(new Causa(), "Causa.NOME"));
            getPojo().setFlagAtivo(Boolean.TRUE);
        } catch (ServiceException ex) {
            error(ex);
        }
    }

    public void salva() {
        try {
            super.salvar();
            atualiza();
        } catch (Exception ex) {
            error(ex);
        }
    }

    @Override
    public void novo() {
    	setPojo(new Causa());
        try {
            setPojos(getService().findByExample(new Causa(), "Causa.NOME"));
        } catch (ServiceException e) {
            error(e);
        }
    }

    @Override
    public String filtrar() {
        try {
            setPojos(getService().findByExample(getPojo(), "Causa.NOME"));
        } catch (ServiceException ex) {
            error(ex);
        }
        return null;
    }

    public String excluir(Causa causa) {
        try {
            getService().delete(causa);
            atualiza();
        } catch (Exception ex) {
            error(ex);
        }
        return null;
    }

    public void alterar(Causa causa) {

        setPojo(causa);

    }
    
    public String getFlagAtivo() {
		return flagAtivo;
	}

	public void setFlagAtivo(String flagAtivo) {
		this.flagAtivo = flagAtivo;
		
		if(StringUtils.isBlank(flagAtivo)){
			getPojo().setFlagAtivo(null);
		}else{
			getPojo().setFlagAtivo(Boolean.valueOf(flagAtivo));
		}
	}
}
