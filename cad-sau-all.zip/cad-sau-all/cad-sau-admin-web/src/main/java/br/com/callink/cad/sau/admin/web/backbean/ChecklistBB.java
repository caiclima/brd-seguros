package br.com.callink.cad.sau.admin.web.backbean;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.model.SelectItem;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.sau.pojo.Assunto;
import br.com.callink.cad.sau.pojo.Check;
import br.com.callink.cad.sau.pojo.Checklist;
import br.com.callink.cad.sau.pojo.Evento;
import br.com.callink.cad.sau.service.IAssociaChecklistService;
import br.com.callink.cad.sau.service.IAssuntoService;
import br.com.callink.cad.sau.service.ICheckService;
import br.com.callink.cad.sau.service.IChecklistService;
import br.com.callink.cad.sau.service.IEventoService;
import br.com.callink.cad.service.IAcaoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.util.JSFUtil;

@ManagedBean
@ViewScoped
public class ChecklistBB extends GboSauAdminGenericCrud<Checklist, IChecklistService> {

    
	private static final long serialVersionUID = 8027299367438517013L;
	
	private Check check;
	private boolean edicaoChecklist;
	private List<Check> listChecks;
	private int tempID;
	
    private List<Evento> listEvento;
    private List<Evento> listEventosSelecionados;
    private Acao acaoSelecionada;
    private Evento exemplo;
    private List<Assunto> listAssunto;
    private boolean selecionaTodosEvento;

    @EJB
    private IChecklistService checkListService;
    @EJB
    private ICheckService checkService;
    @EJB
    private IAssociaChecklistService associaChecklistService;
    @EJB
    private IAssuntoService assuntoService;
    @EJB
    private IEventoService eventoService;
    @EJB
    private IAcaoService acaoService;
    
    protected IChecklistService getService() {
    	return checkListService;
    }
    
    
    @PostConstruct
    public void init(){
    	novo();
        filtrar();
    }

	public void editarChecklist(Checklist checklist) {
		try {
			setPojo(checklist);
			Check checkLocal = new Check();
			checkLocal.setChecklist(checklist);
			getPojo().setChecks(checkService.findByExample(checkLocal));
			setListChecks(getPojo().getChecks());
			this.listEventosSelecionados = associaChecklistService.getEventosByChecklist(checklist);
			this.acaoSelecionada = associaChecklistService.findAcaoByChecklist(checklist);
            setListChecks(getPojo().getChecks());
			edicaoChecklist = true;
			getPojo().setChecks(new ArrayList<Check>());
			filtrarEvento();
	
			info("Checklist carregado na aba: Novo/Editar Checklist");

		} catch (ServiceException e) {
			 error(e);
		}
		
	}
    
	@Override
    public String salvar() {
        Checklist checklist = getPojo();
        if (validaChecklist(checklist)) {
            try {

                getListChecks().removeAll(getPojo().getChecks());

                for (Check checkLocal : getPojo().getChecks()) {
                	checkLocal.setIdCheck(null);
                }

                getPojo().getChecks().addAll(getListChecks());

                getService().salvaChecklist(checklist, listEventosSelecionados, acaoSelecionada);
                novo();
                filtrar();
                novoCheck();
                info("Dados salvos com sucesso");
            } catch (ServiceException ex) {
                error(ex, true);
            } catch (ValidationException e) {
            	error(e.getMessage());
    		}
        }
        return null;
    }

	private boolean validaChecklist(Checklist checklist) {
		
		try {
			boolean retorno = true;
			if (StringUtils.isEmpty(checklist.getDescricao())) {
				error("O campo Nome \u00E9 Obrigat\u00F3rio");
				retorno = false;
			}
			if ((listEventosSelecionados != null && listEventosSelecionados.size() >0 ) 
					&& (acaoSelecionada == null || acaoSelecionada.getIdAcao()==null)) {
				error("A ação dos eventos deve ser selecionada");
				retorno = false;
			}
			if (getListChecks() == null || getListChecks().isEmpty()) {
				error("O Checklist informado n\u00E3o possui quest\u00F5es!");
				retorno = false;
			}
			
			List<String> eventosRelacionados = associaChecklistService.existeAcaoEvento(listEventosSelecionados, acaoSelecionada, checklist);
	    	if(eventosRelacionados!=null && eventosRelacionados.size()>0){
	    		error("Esta a\u00E7\u00E3o j\u00E1 est\u00E1 relacionada em outro checklist aos eventos: " +eventosRelacionados.toString());
	    		retorno = false;
	    	}
	    	
	    	Boolean existeAcao = associaChecklistService.existeAcao(getAcaoSelecionada(), checklist);
	    	if(existeAcao && listEventosSelecionados.isEmpty()){
	    		error("Esta a\u00E7\u00E3o sem eventos j\u00E1 est\u00E1 relacionada em outro checklist! ");
	    		retorno = false;
	    	}
	    	
	    	
			return retorno;
		
		} catch (ServiceException e) {
			error(e);
		}
		return false;
	}
	 
    @Override
    public final void novo() {
        setPojo(new Checklist());
        getPojo().setFlagEnabled(true);
        setPojos(new ArrayList<Checklist>());
    	check = new Check();

    	setListChecks(new ArrayList<Check>());
    	listEventosSelecionados = new ArrayList<Evento>();
        this.exemplo = new Evento();
        acaoSelecionada = new Acao();
        try {
            listAssunto = assuntoService.findAtivos("Assunto.NOME");
        } catch (ServiceException ex) {
            error(ex);
        }
    }

    @Override
    public final String filtrar() {
    	 try {
             setPojos(getService().findByExample(getPojo(), "Checklist.DESCRICAO"));
             Evento evento = new Evento();
             evento.setFlagAtivo(Boolean.TRUE);
             this.listEvento = eventoService.findByExample(evento, "Evento.NOME");
         } catch (ServiceException ex) {
             error(ex);
         }
    	return null;
    }
    
    public void filtrarEvento() {
        try {
            this.listEvento = eventoService.findByExample(exemplo, "Evento.NOME");
            for (Evento evt : listEvento) {
                if (listEventosSelecionados != null && listEventosSelecionados.contains(evt)) {
                    evt.setSelecionado(Boolean.TRUE);
                }
            }
        } catch (ServiceException ex) {
            error(ex);
        }
    }

    public void editarCheck(Check check) {
        this.check = check;
    }
  
    public final void ativarCheck(Check check) {
    	check.setFlagEnabled(Boolean.TRUE);
    }
    
    public final void desativarCheck(Check check) {
    	check.setFlagEnabled(Boolean.FALSE);
    }
    
    public void excluirCheck(Check check) {
        getListChecks().remove(check);
    }
    
    public final void novoCheck() {
        check = new Check();
        check.setFlagEnabled(Boolean.TRUE);
        check.setIdCheck(tempID++);
    }
    
    public void salvarCheck() {

        getCheck().setChecklist(getPojo());

        if (!validaCheck()) {
            if (getListChecks().contains(check)) {
            	getListChecks().remove(check);
            	getListChecks().add(check);
            } else {
            	getListChecks().add(check);
                if (getPojo().getChecks() == null) {
                    getPojo().setChecks(new ArrayList<Check>());
                }
                getPojo().getChecks().add(check); 
            }
        }
        novoCheck();
    }
    
    public boolean validaCheck() {
        boolean erro = false;
        
        if (check == null) {
            error("Selecione um check.");
            return true;
        }
        
        if (StringUtils.isEmpty(check.getDescricao())) {
            error("O campo Descri\u00E7\u00E3o deve ser preenchido;");
            erro = true;
        }
        if (StringUtils.isEmpty(check.getRespostasPossiveis())){
            error("O campo Poss\u00EDveis respostas deve ser preenchido;");
            erro = true;
        }
        if (check.getOrdem() == null) {
            error("O campo Ordem deve ser preenchido;");
            erro = true;
        }
        return erro;
    }
    
    public List<SelectItem> getRespostaRequerida() {
        List<SelectItem> retorno = new ArrayList<SelectItem>();
        retorno.add(new SelectItem(Boolean.TRUE, "Sim"));
        retorno.add(new SelectItem(Boolean.FALSE, "N\u00E3o"));
        return retorno;
    }
    
    public List<SelectItem> getSelectListCheck() {
        return JSFUtil.toSelectItemConsulta(getListChecks());
    }
    
    public void removeEvento(Evento evento) {
        if (listEventosSelecionados != null) {
            listEventosSelecionados.remove(evento);
            if(getListEvento().contains(evento)){
                listEvento.get(listEvento.indexOf(evento)).setSelecionado(Boolean.FALSE);
            }
            if (edicaoChecklist) {
                info("Para concluir a remo\u00E7\u00E3o \u00E9 necess\u00E1rio clicar no bot\u00E3o Salvar");
                edicaoChecklist = false;
            }
        }
    }
    
    public void selecionaTodosEventos() {
        if (listEventosSelecionados == null) {
            listEventosSelecionados = new ArrayList<Evento>();
        }else{
            listEventosSelecionados.clear();
        }

        for (Evento item : getListEvento()) {
            if (selecionaTodosEvento) {
                item.setSelecionado(Boolean.TRUE);
                listEventosSelecionados.add(item);
            } else {
                item.setSelecionado(Boolean.FALSE);
            }
        }
    }

    public void selecionaEventos() {
	
    	if (listEventosSelecionados == null) {
            listEventosSelecionados = new ArrayList<Evento>();
        }

        for (Evento item : getListEvento()) {
            if (item.getSelecionado() && !listEventosSelecionados.contains(item)) {
				listEventosSelecionados.add(item);
            }else if (!item.getSelecionado() && listEventosSelecionados.contains(item)){
                listEventosSelecionados.remove(item);
            }
        }
    }
    
    //GETTERS AND SETTERS
	public Check getCheck() {
		return check;
	}

	public void setCheck(Check check) {
		this.check = check;
	}

	public boolean isEdicaoChecklist() {
		return edicaoChecklist;
	}

	public void setEdicaoChecklist(boolean edicaoChecklist) {
		this.edicaoChecklist = edicaoChecklist;
	}

	public List<Check> getListChecks() {
		
		if(listChecks==null){
			listChecks = new ArrayList<Check>();
		}
		
		return listChecks;
	}

	public void setListChecks(List<Check> listChecks) {
		this.listChecks = listChecks;
	}

	public List<Evento> getListEvento() {
		if(listEvento ==null){
			listEvento = new ArrayList<Evento>();
		}
		
		return listEvento;
	}

	public void setListEvento(List<Evento> listEvento) {
		this.listEvento = listEvento;
	}

	public List<Evento> getListEventosSelecionados() {
		return listEventosSelecionados;
	}

	public void setListEventosSelecionados(List<Evento> listEventosSelecionados) {
		this.listEventosSelecionados = listEventosSelecionados;
	}

	public Evento getExemplo() {
		return exemplo;
	}

	public void setExemplo(Evento exemplo) {
		this.exemplo = exemplo;
	}

	public List<SelectItem> getListAssunto() {
		return JSFUtil.toSelectItemConsulta(listAssunto);
	}
	
	public List<SelectItem> getListAcoes() {
		
		try {
			List<Acao>  listAcao = acaoService.findAtivos("Acao.NOME");
			return JSFUtil.toSelectItemConsulta(listAcao);
		} catch (ServiceException e) {
			error(e);
		}
		
		return null;
	}
	

	public void setListAssunto(List<Assunto> listAssunto) {
		this.listAssunto = listAssunto;
	}

	public boolean isSelecionaTodosEvento() {
		return selecionaTodosEvento;
	}

	public void setSelecionaTodosEvento(boolean selecionaTodosEvento) {
		this.selecionaTodosEvento = selecionaTodosEvento;
	}

	public Acao getAcaoSelecionada() {
		
		if(acaoSelecionada==null){
			acaoSelecionada = new Acao();
		}
		return acaoSelecionada;
	}

	public List<SelectItem> getOperadorApresentacao() {
        List<SelectItem> operador = new ArrayList<SelectItem>();
        operador.add(new SelectItem("", ""));
        operador.add(new SelectItem("IGUAL", "IGUAL"));
        operador.add(new SelectItem("DIFERENTE", "DIFERENTE"));
        return operador;
    }
	
	public void setAcaoSelecionada(Acao acaoSelecionada) {
		this.acaoSelecionada = acaoSelecionada;
	}
	

}
