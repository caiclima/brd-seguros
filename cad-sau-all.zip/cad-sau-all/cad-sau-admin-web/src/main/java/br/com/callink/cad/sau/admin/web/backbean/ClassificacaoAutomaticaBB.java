package br.com.callink.cad.sau.admin.web.backbean;

import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.model.SelectItem;

import br.com.callink.cad.sau.pojo.Assunto;
import br.com.callink.cad.sau.pojo.ClassificacaoAutomatica;
import br.com.callink.cad.sau.pojo.Evento;
import br.com.callink.cad.sau.service.IAssuntoService;
import br.com.callink.cad.sau.service.IClassificacaoAutomaticaService;
import br.com.callink.cad.sau.service.IEventoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.util.JSFUtil;

@ManagedBean
@ViewScoped
public class ClassificacaoAutomaticaBB
		extends
		GboSauAdminGenericCrud<ClassificacaoAutomatica, IClassificacaoAutomaticaService> {

	private static final long serialVersionUID = -2063357901595204203L;

	@EJB
	private IClassificacaoAutomaticaService classificacaoAutomaticaService;

	@EJB
	private IAssuntoService assuntoService;

	@EJB
	private IEventoService eventoService;

	private Assunto assuntoSelecionado;

	private List<Assunto> assuntos;

	private List<Evento> eventos;

	@PostConstruct
	private void init() {
		novo();
	}

	public void carregarEventos() {

		try {
			if (this.assuntoSelecionado != null) {
				this.eventos = eventoService
						.findByAssunto(this.assuntoSelecionado);
			}
		} catch (ServiceException e) {
			error(e);
		}
	}

	@Override
	public String salvar() {
		
		if (this.assuntoSelecionado != null){
			getPojo().setAssunto(this.assuntoSelecionado.getNome());
		}
		
		return super.salvar();
	}

	@Override
	public void editar(ClassificacaoAutomatica classificacaoAutomatica) {

		Assunto assuntoEx = new Assunto();
		assuntoEx.setNome(classificacaoAutomatica.getAssunto());

		try {
			List<Assunto> assuntos;
			assuntos = assuntoService.findByExample(assuntoEx);
			if (!assuntos.isEmpty()) {
				this.assuntoSelecionado = assuntos.get(0);
				carregarEventos();
			} else {
				throw new ServiceException(
						"Não foi possível encontrar o Assunto referente a Classificação selecionada.");
			}
			super.editar(classificacaoAutomatica);
		} catch (ServiceException e) {
			error(e);
		}
	}

	@Override
	public void novo() {

		setPojo(new ClassificacaoAutomatica());
		getPojo().setDataCriacao(new Date());
		getPojo().setLoginUsuario(getLoginUsuario());
		this.assuntoSelecionado = null;
	}

	@Override
	public String filtrar() {

		getPojo().setDataCriacao(null);
		getPojo().setLoginUsuario(null);
		return super.filtrar();
	}

	@Override
	protected IClassificacaoAutomaticaService getService() {
		return this.classificacaoAutomaticaService;
	}

	public Assunto getAssuntoSelecionado() {
		return assuntoSelecionado;
	}

	public void setAssuntoSelecionado(Assunto assuntoSelecionado) {
		this.assuntoSelecionado = assuntoSelecionado;
	}

	public List<SelectItem> getAssuntos() {

		try {
			if (this.assuntos == null || this.assuntos.isEmpty()) {
				this.assuntos = assuntoService.findAtivos("Assunto.NOME");
			}
		} catch (ServiceException e) {
			error(e);
		}
		return JSFUtil.toSelectItemConsulta(this.assuntos);
	}

	public void setAssuntos(List<Assunto> assuntos) {
		this.assuntos = assuntos;
	}

	public List<SelectItem> getEventos() {
		return JSFUtil.toSelectItemConsulta(this.eventos);
	}

	public void setEventos(List<Evento> eventos) {
		this.eventos = eventos;
	}

}
