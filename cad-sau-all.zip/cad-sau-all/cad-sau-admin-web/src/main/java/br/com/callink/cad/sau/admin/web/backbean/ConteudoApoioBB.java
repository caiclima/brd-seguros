package br.com.callink.cad.sau.admin.web.backbean;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.model.SelectItem;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.pojo.Anexo;
import br.com.callink.cad.pojo.GrupoAnexo;
import br.com.callink.cad.sau.pojo.AssociaConteudoApoio;
import br.com.callink.cad.sau.pojo.Assunto;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.pojo.ConteudoApoio;
import br.com.callink.cad.sau.pojo.ConteudoApoioCasoSau;
import br.com.callink.cad.sau.pojo.Evento;
import br.com.callink.cad.sau.service.IAssuntoService;
import br.com.callink.cad.sau.service.ICasoSauService;
import br.com.callink.cad.sau.service.IConteudoApoioService;
import br.com.callink.cad.sau.service.IEventoService;
import br.com.callink.cad.service.IAnexoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.util.Constantes;
import br.com.callink.cad.util.JSFUtil;

/**
 *
 * @author Ednaldo Caic [ednaldo@swb.com.br]
 * @since 19/01/2012
 */
@ManagedBean
@ViewScoped
public class ConteudoApoioBB extends GboSauAdminGenericCrud<ConteudoApoio, IConteudoApoioService> {

    private static final long serialVersionUID = 1L;
    private String manifestacaoBusca;
    private List<CasoSau> casoSauList;
    private CasoSau casoSauSelecionado;
    private List<String> eventoNomeSelecionadoList;
    private List<Evento> listEvento;
    private List<Evento> listEventosSelecionados;
    private boolean selecionaTodosEvento;
    private Assunto assuntoSelecionadoModal;
    private String nomeEvento;
    private List<Assunto> listAssunto;
    
    
    private String flagAtivo;
    
    @EJB
    private IConteudoApoioService conteudoApoioService;
    @EJB
    private IAssuntoService assuntoService;
    @EJB
    private IEventoService eventoService;
    @EJB
    private IAnexoService anexoService;
    @EJB
    private ICasoSauService casoSauService;
    
    protected IConteudoApoioService getService() {
    	return conteudoApoioService;
    }
    
    @PostConstruct
    public void init() {
    	setPojo(new ConteudoApoio());
    	atualiza();
    }

    @Override
    public void novo() {
        try {
        	setPojo(new ConteudoApoio());
            setPojos(getService().findAtivos("ConteudoApoio.NOME"));
            setGrupoAnexo(new GrupoAnexo());
            getGrupoAnexo().setAnexoList(new ArrayList<Anexo>());
            setMostraPanelAnexo(Boolean.FALSE);
            setManifestacaoBusca("");
            setCasoSauList(new ArrayList<CasoSau>());
            setCasoSauSelecionado(null);
            if (eventoNomeSelecionadoList == null) {
                setEventoNomeSelecionadoList(new ArrayList<String>());
            }
            eventoNomeSelecionadoList.clear();

            try {
                if (listAssunto == null || listAssunto.isEmpty()) {
                    listAssunto = assuntoService.findAtivos("Assunto.NOME");
                }
            } catch (ServiceException ex) {
                error(ex);
            }

            
            setFlagAtivo(Boolean.TRUE.toString());
        } catch (ServiceException e) {
            error(e);
        }
    }

    @Override
    public String filtrar() {
        try {
            setPojos(getService().findByExample(getPojo(), "ConteudoApoio.NOME"));
        } catch (ServiceException ex) {
            error(ex);
        }
        return null;
    }

    public void filtrarEvento() {
        try {
            Evento eventoModal = new Evento();

            if (StringUtils.isNotBlank(nomeEvento)) {
                eventoModal.setNome(nomeEvento);
            }
            if (assuntoSelecionadoModal != null && assuntoSelecionadoModal.getPK() != null) {
                eventoModal.setAssunto(assuntoSelecionadoModal);
            }
            listEvento = eventoService.findByExample(eventoModal, "Evento.NOME");

            if (listEventosSelecionados == null) {
                setListEventosSelecionados(new ArrayList<Evento>());
            }
            if (eventoNomeSelecionadoList == null) {
                setEventoNomeSelecionadoList(new ArrayList<String>());
            }
            
            if (getPojo().getPK() != null) {
                listEventosSelecionados.clear();
                eventoNomeSelecionadoList.clear();

                marcarEventosSelecionadosGrid();
            } else {
                marcarEventosSelecionadosGridCadastro();
            }




        } catch (ServiceException ex) {
            error(ex);
        }
    }

    public void marcaEventosSelecionadosInputCadastro() {
        if (listEventosSelecionados == null) {
            listEventosSelecionados = new ArrayList<Evento>();
        }

        if (eventoNomeSelecionadoList == null) {
            setEventoNomeSelecionadoList(new ArrayList<String>());
        }

        if (listEvento != null) {
            for (Evento eventoSelecionado : listEventosSelecionados) {
                for (Evento item : listEvento) {
                    if (eventoSelecionado.equals(item)) {
                        item.setSelecionado(Boolean.TRUE);
                    }
                }
            }
        }
    }

    public void marcaEventosSelecionadosInputUpdate() {

        if (listEventosSelecionados == null) {
            listEventosSelecionados = new ArrayList<Evento>();
        }

        if (eventoNomeSelecionadoList == null) {
            setEventoNomeSelecionadoList(new ArrayList<String>());
        }
        listEventosSelecionados.clear();
        eventoNomeSelecionadoList.clear();
        if (getPojo().getAssociaConteudoApoioList() != null && !getPojo().getAssociaConteudoApoioList().isEmpty()) {
            for (AssociaConteudoApoio aca : getPojo().getAssociaConteudoApoioList()) {
                listEventosSelecionados.add(aca.getEvento());
                eventoNomeSelecionadoList.add(aca.getEvento().getNome());
            }
        }


        if (listEvento != null) {

            for (Evento item : listEvento) {
                if (item.getSelecionado() && !listEventosSelecionados.contains(item)) {
                    listEventosSelecionados.add(item);
                }
            }
        }

    }

    public void selecionaTodosEventos() {

        for (Evento item : getListEvento()) {
            if (selecionaTodosEvento) {
                item.setSelecionado(Boolean.TRUE);
            } else {
                item.setSelecionado(Boolean.FALSE);
            }
            marcaDesmarcaEvento(item);
        }
    }

    public void limparEventosSelecionados() {

        if (eventoNomeSelecionadoList == null) {
            setEventoNomeSelecionadoList(new ArrayList<String>());
        }

        if (listEventosSelecionados == null) {
            setListEventosSelecionados(new ArrayList<Evento>());
        }
        listEventosSelecionados.clear();
        eventoNomeSelecionadoList.clear();

    }

    public void marcaDesmarcaEvento(Evento evento) {
        if (evento != null && evento.getSelecionado() != null) {
            if (listEventosSelecionados == null) {
                listEventosSelecionados = new ArrayList<Evento>();
            }
            if (eventoNomeSelecionadoList == null) {
                eventoNomeSelecionadoList = new ArrayList<String>();
            }

            if (evento.getSelecionado()) {
                if (!listEventosSelecionados.contains(evento)) {
                    boolean adicionado = Boolean.FALSE;
                    for (Evento item : listEventosSelecionados) {
                        if(item.getAssunto().equals(evento.getAssunto())){
                            
                            int posicaoInsereEventoSelecionado = listEventosSelecionados.indexOf(item) + 1;
                            listEventosSelecionados.add(posicaoInsereEventoSelecionado,evento);
                            
                            int posicaoInsereNomeSelecionado = eventoNomeSelecionadoList.indexOf(item.getNome()) + 1;
                            eventoNomeSelecionadoList.add(posicaoInsereNomeSelecionado,evento.getNome());
                            
                            adicionado = Boolean.TRUE;
                            break;
                        }
                    }
                    if(!adicionado){
                        listEventosSelecionados.add(evento);
                        eventoNomeSelecionadoList.add("<" + evento.getAssunto().getNome() + ">");
                        eventoNomeSelecionadoList.add(evento.getNome());
                    }
                }

            } else {
                if (eventoNomeSelecionadoList.contains(evento.getNome())) {
                    eventoNomeSelecionadoList.remove(evento.getNome());
                    listEventosSelecionados.remove(evento);
                    boolean existeEventoComAssunto = Boolean.FALSE;
                    for (Evento item : listEventosSelecionados) {
                        if(item.getAssunto().equals(evento.getAssunto())){
                            existeEventoComAssunto = Boolean.TRUE;
                            break;
                        }
                    }
                    if(!existeEventoComAssunto){
                        eventoNomeSelecionadoList.remove("<" + evento.getAssunto() + ">");
                    }
                }
            }
        }
    }

    public void removeEvento(Evento evento) {
        if (listEventosSelecionados != null) {
            listEventosSelecionados.remove(evento);
        }
    }

    @Override
    public String salvar() {

        if (getPojo().getGrupoAnexo() == null) {
            getPojo().setGrupoAnexo(getGrupoAnexo());
        } else {
            getPojo().getGrupoAnexo().setAnexoList(getGrupoAnexo().getAnexoList());
        }
        if (getPojo().getAssociaConteudoApoioList() == null) {
            getPojo().setAssociaConteudoApoioList(new ArrayList<AssociaConteudoApoio>());
        }
        getPojo().getAssociaConteudoApoioList().clear();


        if (listEventosSelecionados != null && !listEventosSelecionados.isEmpty()) {
            for (Evento evento : listEventosSelecionados) {
                AssociaConteudoApoio associaConteudoApoio = new AssociaConteudoApoio();
                associaConteudoApoio.setEvento(evento);
                associaConteudoApoio.setConteudoApoio(getPojo());
                getPojo().getAssociaConteudoApoioList().add(associaConteudoApoio);
            }
        }

        String ret = super.salvar();
        if (getPojo().getPK() != null) {
            novo();
            atualiza();
        }
        return ret;
    }

    public String excluir(ConteudoApoio conteudoApoio) {
        try {
            conteudoApoioService.delete(conteudoApoio);
            atualiza();

        } catch (Exception ex) {
            error("Conteudo Apoio n\u00E3o pode ser removido.");
        }
        return null;
    }

    public void excluir(Anexo anexo) {
        try {
        	anexoService.delete(anexo);
            buscaAnexos(getPojo().getGrupoAnexo().getPK());
            getPojo().getGrupoAnexo().setAnexoList(getGrupoAnexo().getAnexoList());
            atualiza();


        } catch (ServiceException | ValidationException ex) {
            error("Conteudo Apoio n\u00E3o pode ser removido.");
        }
    }

    public void alterar(ConteudoApoio conteudoApoio) {
        try {
            conteudoApoio = getService().load(conteudoApoio);
        } catch (ServiceException ex) {
            error("Erro ao carregar Conteudo apoio selecionado!");
        }
        setPojo(conteudoApoio);
        marcaEventosSelecionadosInputUpdate();


    }

    public void buscaCasoSauList() {
        try {

            if (StringUtils.isBlank(manifestacaoBusca)) {
                error("Campos Obrigat\u00F3rio : Caso");
                return;
            }
            CasoSau sau = new CasoSau();
            sau.setManifestacao(manifestacaoBusca);

            List<CasoSau> casoSaus = casoSauService.findByExample(sau);

            if (casoSaus != null && !casoSaus.isEmpty()) {
                getCasoSauList().clear();
                for (CasoSau sau2 : casoSaus) {
                    sau2 = casoSauService.load(sau2);
                    getCasoSauList().add(sau2);
                }
            }
        } catch (ServiceException e) {
            error("Erro ao buscar casos");
        }
    }

    public void removeDaLista(CasoSau sau) {
        sau.setSelecionado(Boolean.FALSE);
        selecionaCasoSau(sau);
    }

    public void selecionaCasoSau(CasoSau casoSau) {

        if (casoSau != null && casoSau.getSelecionado() != null) {
            ConteudoApoioCasoSau conteudoApoioCasoSau = new ConteudoApoioCasoSau();
            conteudoApoioCasoSau.getConteudoApoioCasoSauId().setConteudoApoio(getPojo());
            conteudoApoioCasoSau.getConteudoApoioCasoSauId().setCasoSau(casoSau);
            if (casoSau.getSelecionado()) {
                if (getPojo().getConteudoApoioCasoSauList() == null) {
                    getPojo().setConteudoApoioCasoSauList(new ArrayList<ConteudoApoioCasoSau>());
                }
                if (!getPojo().getConteudoApoioCasoSauList().contains(conteudoApoioCasoSau)) {
                    getPojo().getConteudoApoioCasoSauList().add(conteudoApoioCasoSau);
                } else {
                    error("Caso selecionado já está adicionado.");
                }
            } else {
                if (getPojo().getConteudoApoioCasoSauList().contains(conteudoApoioCasoSau)) {
                    getPojo().getConteudoApoioCasoSauList().remove(conteudoApoioCasoSau);
                } else {
                    error("Caso não pode ser removido.");
                }
            }
        }
    }

    public void buscaAssuntos() {
        try {
            setListAssunto(assuntoService.findAtivos("Assunto.NOME"));
            filtrarEvento();
            if (getPojo().getPK() != null) {
                marcaEventosSelecionadosInputUpdate();
            } else {
                marcaEventosSelecionadosInputCadastro();
            }


        } catch (ServiceException ex) {
            error(ex);
        }
    }

    private void marcarEventosSelecionadosGridCadastro() {

        for (Evento eventoSelecionado : getListEventosSelecionados()) {
            for (Evento evento : getListEvento()) {
                if (evento.equals(eventoSelecionado)) {
                    evento.setSelecionado(Boolean.TRUE);
                }
            }
        }
    }

    private void marcarEventosSelecionadosGrid() {
        if (getPojo().getAssociaConteudoApoioList() == null) {
            getPojo().setAssociaConteudoApoioList(new ArrayList<AssociaConteudoApoio>());
        }
        for (AssociaConteudoApoio associaConteudoApoio : getPojo().getAssociaConteudoApoioList()) {
            getListEventosSelecionados().add(associaConteudoApoio.getEvento());
            eventoNomeSelecionadoList.add(associaConteudoApoio.getEvento().getNome());
            for (Evento evento : getListEvento()) {
                if (evento.equals(associaConteudoApoio.getEvento())) {
                    evento.setSelecionado(Boolean.TRUE);
                }
            }
        }
    }

    public void associaConteudoApoioCaso(CasoSau casoSau) {
        ConteudoApoioCasoSau conteudoApoioCasoSau = new ConteudoApoioCasoSau();
        conteudoApoioCasoSau.getConteudoApoioCasoSauId().setConteudoApoio(getPojo());
        conteudoApoioCasoSau.getConteudoApoioCasoSauId().setCasoSau(casoSau);

        boolean contemNaLista = Boolean.FALSE;
        for (Iterator<ConteudoApoioCasoSau> item = getPojo().getConteudoApoioCasoSauList().iterator(); item.hasNext();) {
            ConteudoApoioCasoSau apoioCasoSau = item.next();
            if (apoioCasoSau.getConteudoApoioCasoSauId().getCasoSau().equals(casoSau)) {
                contemNaLista = Boolean.TRUE;
                break;
            }
        }
        if (!contemNaLista) {
            getPojo().getConteudoApoioCasoSauList().add(conteudoApoioCasoSau);
        }
    }

    public void desassociaConteudoApoioCaso(CasoSau casoSau) {
        ConteudoApoioCasoSau conteudoApoioCasoSau = new ConteudoApoioCasoSau();
        conteudoApoioCasoSau.getConteudoApoioCasoSauId().setConteudoApoio(getPojo());
        conteudoApoioCasoSau.getConteudoApoioCasoSauId().setCasoSau(casoSau);

        try {
            for (Iterator<ConteudoApoioCasoSau> item = getPojo().getConteudoApoioCasoSauList().iterator(); item.hasNext();) {
                ConteudoApoioCasoSau apoioCasoSau = item.next();
                if (apoioCasoSau.getConteudoApoioCasoSauId().getCasoSau().equals(casoSau)) {
                    conteudoApoioService.deleteAssociacao(conteudoApoioCasoSau);
                    item.remove();
                }
            }
        } catch (ServiceException ex) {
            error("Erro ao remover associação Conteudo Apoio Caso");
        }
    }

    private void atualiza() {
        try {
            getPojo().setFlagAtivo(Boolean.TRUE);

            setPojos(conteudoApoioService.findAtivos(null));
        } catch (ServiceException ex) {
            error(ex);
        }
    }

    public void limpaEvento() {
        if (getPojo().getAssociaConteudoApoioList() == null) {
            getPojo().setAssociaConteudoApoioList(new ArrayList<AssociaConteudoApoio>());
        }
        getPojo().getAssociaConteudoApoioList().clear();
    }

    public final String getManifestacaoBusca() {
        return manifestacaoBusca;
    }

    public final void setManifestacaoBusca(String manifestacaoBusca) {
        this.manifestacaoBusca = manifestacaoBusca;
    }

    public final List<CasoSau> getCasoSauList() {
        if(casoSauList == null){
        	casoSauList = new ArrayList<CasoSau>();
        }
    	
    	return casoSauList;
    }

    public final void setCasoSauList(List<CasoSau> casoSauList) {
        this.casoSauList = casoSauList;
    }

    public final CasoSau getCasoSauSelecionado() {
        return casoSauSelecionado;
    }

    @SuppressWarnings("unchecked")
    public final void setCasoSauSelecionado(CasoSau casoSauSelecionado) {
        this.casoSauSelecionado = casoSauSelecionado;
        getSessionMap().put("casoSelecionado", casoSauSelecionado);
    }

    public String getEventoNomeSelecionadoList() {
        if (eventoNomeSelecionadoList == null || eventoNomeSelecionadoList.toString().equals(Constantes.LISTA_STRING_VAZIA)) {
            return "";
        }
        return eventoNomeSelecionadoList.toString().replaceAll(">,", ">");
    }

    public void setEventoNomeSelecionadoList(List<String> eventoNomeSelecionadoList) {
        this.eventoNomeSelecionadoList = eventoNomeSelecionadoList;
    }

    public final List<Evento> getListEvento() {
        
    	if(listEvento==null){
    		listEvento = new ArrayList<Evento>();
    	}
    	
    	return listEvento;
    }

    public final void setListEvento(List<Evento> listEvento) {
        this.listEvento = listEvento;
    }

    public final List<Evento> getListEventosSelecionados() {
        return listEventosSelecionados;
    }

    public final void setListEventosSelecionados(
            List<Evento> listEventosSelecionados) {
        this.listEventosSelecionados = listEventosSelecionados;
    }

    public List<SelectItem> getListAssunto() {
        return JSFUtil.toSelectItemConsulta(listAssunto);
    }

    public void setListAssunto(List<Assunto> listAssunto) {
        this.listAssunto = listAssunto;
    }

    public final boolean isSelecionaTodosEvento() {
        return selecionaTodosEvento;
    }

    public final void setSelecionaTodosEvento(boolean selecionaTodosEvento) {
        this.selecionaTodosEvento = selecionaTodosEvento;
    }

    public final String getNomeEvento() {
        return nomeEvento;
    }

    public final void setNomeEvento(String nomeEvento) {
        this.nomeEvento = nomeEvento;
    }

    public final Assunto getAssuntoSelecionadoModal() {
        return assuntoSelecionadoModal;
    }

    public final void setAssuntoSelecionadoModal(Assunto assuntoSelecionadoModal) {
        this.assuntoSelecionadoModal = assuntoSelecionadoModal;
    }
    
    public String getFlagAtivo() {
		return flagAtivo;
	}

	public void setFlagAtivo(String flagAtivo) {
		this.flagAtivo = flagAtivo;
		
		if(StringUtils.isBlank(flagAtivo)){
			getPojo().setFlagAtivo(null);
		}else{
			getPojo().setFlagAtivo(Boolean.valueOf(flagAtivo));
		}
	}
}
