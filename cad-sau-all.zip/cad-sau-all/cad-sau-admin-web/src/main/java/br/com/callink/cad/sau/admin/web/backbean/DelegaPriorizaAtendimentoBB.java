package br.com.callink.cad.sau.admin.web.backbean;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.model.SelectItem;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.backbean.CadGenericCrud;
import br.com.callink.cad.pojo.Agendamento;
import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.service.ICasoSauService;
import br.com.callink.cad.service.IAgendamentoService;
import br.com.callink.cad.service.IAtendenteService;
import br.com.callink.cad.service.ICasoService;
import br.com.callink.cad.service.IConfiguracaoFilaService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.util.JSFUtil;

/**
 *
 * @author Ednaldo Caic [ednaldo@swb.com.br]
 * @since 19/01/2012
 */
@ManagedBean
@ViewScoped
public class DelegaPriorizaAtendimentoBB extends CadGenericCrud<Caso, ICasoService> {

    private static final long serialVersionUID = -5108766865627640925L;
    private List<Atendente> atendenteOrigemList;
    private List<Atendente> atendenteDestinoList;
    private List<ConfiguracaoFila> configuracaoFilaList;
    private List<Caso> casoList;
    private List<CasoSau> casoSauList;
    private List<Agendamento> agendamentoList;
    private Agendamento agendamento;
    private CasoSau casoSauAtual;
    private ConfiguracaoFila configuracaoFilaSelecionado;
    private Atendente atendenteOrigemSelecionado;
    private Atendente atendenteDestinoSelecionado;
    private String manifestacao;
    private boolean selecionaTodos;
    private boolean buscaSoPorManifestacao;
    
    
    @EJB
    private ICasoService casoService;
    @EJB
    private IConfiguracaoFilaService configuracaoFilaService;
    @EJB
    private IAtendenteService atendenteService;
    @EJB
    private ICasoSauService casoSauService;
    @EJB
    private IAgendamentoService agendamentoService;
    
    
    public ICasoService getService() {
    	return casoService;
    }
    
    @PostConstruct
    public void init(){
    	atualiza();
    }

    @Override
    public String salvar() {
        String ret = "";
        
        try {

            if (getAtendenteDestinoSelecionado() == null) {
                error("Campo Enviar caso para atendente obrigat\u00F3rio!");
                return "";
            }

            for (CasoSau casoSau : getCasoSauList()) {
                if (casoSau != null && casoSau.getSelecionado() != null && casoSau.getSelecionado()) {
                	if (getService().casoEstaEmAtendimento(casoSau.getCaso())) {
                		error("Caso de c\u00F3digo de manifesta\u00E7\u00E3o " + casoSau.getManifestacao() + " em atendimento.");
                	} else {
	                    try {
	                        getService().delegaCasoAtendente(casoSau.getCaso() ,getAtendenteDestinoSelecionado() ,getUserInfo().getUserLogin() );
	                    } catch (Exception ex) {
	                        error(ex);
	                        return null;
	                    }
                	}

                    ret = null;
                }
            }
            //TODO
            //info(getBundleCrud().getString("MSG_Save_Success"));
            novo();
            atualiza();
        } catch (Exception ex) {
            error(ex);
        }
        return ret;
    }

    public void alterar(Caso caso) {
        setPojo(caso);
    }

    public void marcaOuDesmarca() {
    }

    private void atualiza() {
        try {
            setConfiguracaoFilaList(configuracaoFilaService.findAtivos("ConfiguracaoFila.NOME"));
            setAtendenteOrigemSelecionado(new Atendente());
            setAtendenteDestinoSelecionado(new Atendente());

            setCasoSauList(new ArrayList<CasoSau>());
            setConfiguracaoFilaSelecionado(new ConfiguracaoFila());
            setAgendamento(new Agendamento());
            setSelecionaTodos(Boolean.FALSE);

        } catch (ServiceException e) {
            error(e);
        }
    }

    public void buscaAtendentesByFila() {
        try {

            casoSauList.clear();

            if (getConfiguracaoFilaSelecionado() == null) {
                setAtendenteOrigemList(new ArrayList<Atendente>());
                setAtendenteDestinoList(new ArrayList<Atendente>());
            } else {
                setAtendenteOrigemList(atendenteService.buscaPorFila(configuracaoFilaSelecionado));
                setAtendenteDestinoList(atendenteOrigemList);
            }
            setCasoList(new ArrayList<Caso>());
        } catch (ServiceException e) {
            error(e);
        }
    }

    public void buscaCasos() {

        try {
            String manifestacaoParam = null;
            if (StringUtils.isNotBlank(manifestacao) && configuracaoFilaSelecionado == null && atendenteOrigemSelecionado == null) {
                setBuscaSoPorManifestacao(Boolean.TRUE);
                manifestacaoParam = manifestacao;

            }

            if (getConfiguracaoFilaSelecionado() == null && StringUtils.isBlank(manifestacao)) {
                error("Favor selecionar uma fila ou informar manifesta\u00E7\u00E3o para realizar a pesquisa.");
            } else {
                List<CasoSau> casoSaus = casoSauService.buscaPorFilaOrAtendenteOrManifestacao(configuracaoFilaSelecionado, atendenteOrigemSelecionado, manifestacao);
                if (casoSaus != null) {

                    if (StringUtils.isNotBlank(manifestacao) && !casoSaus.isEmpty() && getConfiguracaoFilaSelecionado() == null) {
                        setConfiguracaoFilaSelecionado(casoSaus.get(0).getCaso().getConfiguracaoFila());
                        buscaAtendentesByFila();
                    }
                    if (manifestacaoParam != null) {
                        manifestacao = manifestacaoParam;
                    }
                    casoSauList = casoSaus;

                } else {
                    casoSauList = new ArrayList<CasoSau>();
                }
            }
            setBuscaSoPorManifestacao(Boolean.FALSE);

        } catch (ServiceException e) {
            error(e);
        }
    }

    public void buscaAgendamentosByCaso(CasoSau casoSau) {

        try {
            setAgendamentoList(agendamentoService.buscaPeloCaso(casoSau.getCaso()));
            setCasoSauAtual(casoSau);
            setAgendamento(new Agendamento());
        } catch (ServiceException e) {
            error(e);
        }

    }

    public void selecionaTodosCasos() {
        for (CasoSau sau : casoSauList) {
            sau.setSelecionado(selecionaTodos);
        }
    }

    public void setAtendentes() {
        if (atendenteOrigemSelecionado == null) {
            setAtendenteDestinoList(atendenteOrigemList);
        } else {
            setAtendenteDestinoSelecionado(null);
            atendenteDestinoList = new ArrayList<Atendente>();
            for (Iterator<Atendente> iterator = atendenteOrigemList.iterator(); iterator.hasNext();) {
                Atendente atendente = iterator.next();
                if (!atendente.equals(atendenteOrigemSelecionado)) {
                    atendenteDestinoList.add(atendente);
                }
            }
        }
    }

    public void salvarAgendamento() {
        try {
            getAgendamento().setLoginUsuario(getLoginUsuario());
            getAgendamento().setCaso(getCasoSauAtual().getCaso());

            agendamentoService.save(getAgendamento());

            buscaAgendamentosByCaso(getCasoSauAtual());
            setAgendamento(new Agendamento());

        } catch (ServiceException e) {
            error(e);
        } catch (ValidationException e) {
        	error(e.getMessage());
		}
    }

    public final List<SelectItem> getConfiguracaoFilaList() {
        return JSFUtil.toSelectItemConsulta(configuracaoFilaList);
    }

    public final void setConfiguracaoFilaList(
            List<ConfiguracaoFila> configuracaoFilaList) {
        this.configuracaoFilaList = configuracaoFilaList;
    }

    public final ConfiguracaoFila getConfiguracaoFilaSelecionado() {
        return configuracaoFilaSelecionado;
    }

    public final void setConfiguracaoFilaSelecionado(
            ConfiguracaoFila configuracaoFilaSelecionado) {
        this.configuracaoFilaSelecionado = configuracaoFilaSelecionado;
    }

    public final Atendente getAtendenteOrigemSelecionado() {
        return atendenteOrigemSelecionado;
    }

    public final void setAtendenteOrigemSelecionado(
            Atendente atendenteOrigemSelecionado) {
        this.atendenteOrigemSelecionado = atendenteOrigemSelecionado;
    }

    public final Atendente getAtendenteDestinoSelecionado() {
        return atendenteDestinoSelecionado;
    }

    public final void setAtendenteDestinoSelecionado(
            Atendente atendenteDestinoSelecionado) {
        this.atendenteDestinoSelecionado = atendenteDestinoSelecionado;
    }

    public final List<Caso> getCasoList() {
        return casoList;
    }

    public final void setCasoList(List<Caso> casoList) {
        this.casoList = casoList;
    }

    public final List<CasoSau> getCasoSauList() {
        return casoSauList;
    }

    public final void setCasoSauList(List<CasoSau> casoSauList) {
        this.casoSauList = casoSauList;
    }

    public final List<Agendamento> getAgendamentoList() {
        return agendamentoList;
    }

    public final void setAgendamentoList(List<Agendamento> agendamentoList) {
        this.agendamentoList = agendamentoList;
    }

    public final Agendamento getAgendamento() {
        return agendamento;
    }

    public final void setAgendamento(Agendamento agendamento) {
        this.agendamento = agendamento;
    }

    public final CasoSau getCasoSauAtual() {
        return casoSauAtual;
    }

    public final void setCasoSauAtual(CasoSau casoSauAtual) {
        this.casoSauAtual = casoSauAtual;
    }

    public final boolean isSelecionaTodos() {
        return selecionaTodos;
    }

    public final void setSelecionaTodos(boolean selecionaTodos) {
        this.selecionaTodos = selecionaTodos;
    }

    public final List<SelectItem> getAtendenteOrigemList() {
        return JSFUtil.toSelectItemConsulta(atendenteOrigemList);
    }

    public final void setAtendenteOrigemList(List<Atendente> atendenteOrigemList) {
        this.atendenteOrigemList = atendenteOrigemList;
    }

    public final List<SelectItem> getAtendenteDestinoList() {
        return JSFUtil.toSelectItemConsulta(atendenteDestinoList);
    }

    public final void setAtendenteDestinoList(List<Atendente> atendenteDestinoList) {
        this.atendenteDestinoList = atendenteDestinoList;
    }

    public final String getManifestacao() {
        return manifestacao;
    }

    public final void setManifestacao(String manifestacao) {
        this.manifestacao = manifestacao;
    }

    public boolean isBuscaSoPorManifestacao() {
        return buscaSoPorManifestacao;
    }

    public void setBuscaSoPorManifestacao(boolean buscaSoPorManifestacao) {
        this.buscaSoPorManifestacao = buscaSoPorManifestacao;
    }


	@Override
	public void novo() {
		// TODO Auto-generated method stub
	}
}
