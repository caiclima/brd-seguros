/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.sau.admin.web.backbean;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.sau.pojo.Assunto;
import br.com.callink.cad.sau.pojo.Causa;
import br.com.callink.cad.sau.pojo.Evento;
import br.com.callink.cad.sau.pojo.EventoCausa;
import br.com.callink.cad.sau.service.IAssuntoService;
import br.com.callink.cad.sau.service.ICausaService;
import br.com.callink.cad.sau.service.IEventoCausaService;
import br.com.callink.cad.sau.service.IEventoService;
import br.com.callink.cad.sau.util.CsvUtils;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.util.JSFUtil;

/**
 * 
 * @author Rogerio
 */
@ManagedBean
@ViewScoped
public class EventoBB extends GboSauAdminGenericCrud<Evento, IEventoService> {

	private static final long serialVersionUID = 1L;
	private List<Assunto> assuntoList;
	
	private List<Causa> causaList;
	private List<Causa> causaSelecionadaList;
	private Causa causa;
	private boolean selecionaTodasCausas;
	private String contextPath;
	private boolean geraRelatorio;
	
	private String flagAtivo;
	
	private String flagFinalizacaoAutomatica;
	
	@EJB
	private IEventoService eventoService;
	@EJB
	private ICausaService causaService;
	@EJB
	private IEventoCausaService eventoCausaService;
	@EJB
	private IAssuntoService assuntoService;
	
	@PostConstruct
    public void init() {
		setPojo(new Evento());
		causaSelecionadaList = new ArrayList<Causa>();
		causa = new Causa();
		geraRelatorio = true;
		atualiza();
		
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        setContextPath(request.getContextPath() + "/exportarCsv");
	}
	
	public void salva() {
		try {
			getService().save(getPojo());
			atualiza();
			info("Registro salvo com sucesso.");
		} catch (ValidationException ex) {
			error(ex);
		} catch (ServiceException ex) {
			error(ex);
		}
	}

	public void update() {
		try {
			getService().update(getPojo());
			atualiza();
			info("Registro atualizado com sucesso.");
		} catch (ValidationException ex) {
			error(ex);
		} catch (ServiceException ex) {
			error(ex);
		}
	}

	@Override
	public void novo() {
		try {
			setPojo(new Evento());
			setPojos(getService().findByExample(getPojo(), "Evento.NOME"));
			geraRelatorio = true;
		} catch (ServiceException e) {
			error(e);
		}
	}

	public String excluir(Evento status) {
		try {
			getService().delete(status);
			atualiza();
			info("Registro excluido com sucesso.");
		} catch (ValidationException ex) {
			error(ex);
		} catch (ServiceException ex) {
			error(ex);
		}
		return null;
	}

	private void atualiza() {
		try {
			setPojos(getService().findByExample(new Evento(), "Evento.NOME"));
			assuntoList = assuntoService.findAtivos("Assunto.NOME");
			getPojo().setFlagAtivo(Boolean.TRUE);
			
			setFlagAtivo(Boolean.TRUE.toString());
		} catch (ServiceException ex) {
			error(ex);
		}
	}

	public void alterar(Evento evento) {
		try {
			setPojo(evento);
			assuntoList = assuntoService.findAtivos("Assunto.NOME");
		} catch (ServiceException ex) {
			error(ex);
		}
	}

	@Override
	public String filtrar() {
		try {
			setPojos(getService().findByExample(getPojo(), "Evento.NOME"));
		} catch (ServiceException ex) {
			error(ex);
		}
		return null;
	}

	public void verificaEventoCausa(Evento evento) {
		try {
			if (causaList == null || causaList.isEmpty()) {
				causaList = causaService.findAtivos("Causa.NOME");
			}
			causaSelecionadaList = new ArrayList<Causa>();
			causa = new Causa();
			selecionaTodasCausas = Boolean.FALSE;
			EventoCausa eventoCausa = new EventoCausa();
			eventoCausa.setEvento(evento);
			List<EventoCausa> eventoCausaList = eventoCausaService
					.findByExample(eventoCausa);

			for (EventoCausa item : eventoCausaList) {
				Causa causaItem = causaService.findByPk(item.getCausa());
				causaItem.setFlagFinalizaAutomatico(item.getFinalizaCaso());
				causaSelecionadaList.add(causaItem);
			}

			filtrarCausas();
			setPojo(evento);
		} catch (ServiceException ex) {
			error(ex);
		}
	}

	public void filtrarCausas() {
		try {
			causaList = causaService.findByExample(causa, "Causa.NOME");

			for (Causa item : causaList) {
				if (causaSelecionadaList.contains(item)) {
					item.setSelecionado(Boolean.TRUE);
				}
			}

		} catch (ServiceException ex) {
			error(ex);
		}
	}

	public void salvarCausaEvento() {
		try {
			if (causaSelecionadaList != null && !causaSelecionadaList.isEmpty()) {
				eventoCausaService.saveEventoCausas(getPojo(),
						causaSelecionadaList);
				info("Registro salvo com sucesso.");
			} else {
				info("Nenhuma causa selecionada.");
			}
		} catch (ValidationException ex) {
			error(ex);
		} catch (ServiceException ex) {
			error(ex);
		}
	}

	public void selecionaTodasCausas() {
		if (selecionaTodasCausas) {
			for (Causa item : causaList) {
				if (!causaSelecionadaList.contains(item)) {
					item.setSelecionado(Boolean.TRUE);
					causaSelecionadaList.add(item);
				}
			}
		} else {
			for (Causa item : causaList) {
				if (causaSelecionadaList.contains(item)) {
					item.setSelecionado(Boolean.FALSE);
					causaSelecionadaList.remove(item);
				}
			}
		}
	}

	public void selecionaCausas() {
		if (causaSelecionadaList == null) {
			causaSelecionadaList = new ArrayList<Causa>();
		}
		for (Causa item : causaList) {
			if (item.isSelecionado() && !causaSelecionadaList.contains(item)) {
				causaSelecionadaList.add(item);
			} else {
				if (!item.isSelecionado()
						&& causaSelecionadaList.contains(item)) {
					causaSelecionadaList.remove(item);
				}
			}
		}
	}

	public void excluir(Causa causa) {
		if (causaSelecionadaList != null) {
			causaSelecionadaList.remove(causa);
			if (causaList != null && causaList.contains(causa)) {
				Integer index = causaList.indexOf(causa);
				if (index >= 0) {
					Causa item = causaList.get(index);
					item.setSelecionado(Boolean.FALSE);
				}
			}
		}
	}

	public void validaFlagFinalizaAutomatico(Causa causaAssocia) {
		Integer contador = 0;
		if (causaSelecionadaList != null) {
			for (Causa item : causaSelecionadaList) {
				if (item.isFlagFinalizaAutomatico()) {
					contador++;
					if (contador > 1) {
						break;
					}
				}
			}

			if (contador > 1) {
				causaAssocia.setFlagFinalizaAutomatico(Boolean.FALSE);
				info("Já existe uma associação com finalização automatica. Remover a mesma e adicionar esta novamente.");
			}

		}
	}

	public void gerarCSV() throws ServiceException {

		CsvUtils csv = new CsvUtils("evento_causa.csv", null);

		List<Object> tabela = new ArrayList<Object>();
		List<Object> linhaAtual = new ArrayList<Object>();
		linhaAtual.add("ID_EVENTO");
		linhaAtual.add("ASSUNTO");
		linhaAtual.add("EVENTO");
		linhaAtual.add("DATA_CRIACAO");
		linhaAtual.add("FLAG_ATIVO");
		linhaAtual.add("FLAG_FINALIZACAO_AUTOMATICO");
		linhaAtual.add("CAUSA");
		linhaAtual.add("FLAG_FINALIZACAO_AUTOMATICO");
		tabela.add(linhaAtual.toArray());

		if (getPojos() != null) {
			for (Evento item : getPojos()) {
				linhaAtual = new ArrayList<Object>();
				List<EventoCausa> eventoCausaList = eventoCausaService.findByEventoCausa(item, null);
				
				if (eventoCausaList != null && eventoCausaList.size() > 0) {
					for (EventoCausa eventoCausa : eventoCausaList) {
						linhaAtual = new ArrayList<Object>();
						linhaAtual.add(item.getIdEvento());
						linhaAtual.add(item.getAssunto() != null ? item.getAssunto().getNome() : "");
						linhaAtual.add(item.getNome());
						linhaAtual.add(item.getDataCriacao());
						linhaAtual.add(item.getFlagAtivo() != null && item.getFlagAtivo() ? "SIM" : "NAO");
						linhaAtual.add(item.getFlagFinalizacaoAutomatica()!= null && item.getFlagFinalizacaoAutomatica() ? "SIM" : "NAO");
						
						linhaAtual.add(eventoCausa.getCausa().getNome());
						linhaAtual.add(eventoCausa.getFinalizaCaso()!= null && eventoCausa.getFinalizaCaso() ? "SIM" : "NAO");
						
						tabela.add(linhaAtual.toArray());
					}
				} else {
					linhaAtual.add(item.getIdEvento());
					linhaAtual.add(item.getAssunto() != null ? item.getAssunto().getNome() : "");
					linhaAtual.add(item.getNome());
					linhaAtual.add(item.getDataCriacao());
					linhaAtual.add(item.getFlagAtivo() != null && item.getFlagAtivo() ? "SIM" : "NAO");
					linhaAtual.add(item.getFlagFinalizacaoAutomatica()!= null && item.getFlagFinalizacaoAutomatica() ? "SIM" : "NAO");
					linhaAtual.add("");
					linhaAtual.add("");
					
					tabela.add(linhaAtual.toArray());
				}
				
			}
		}
		
		geraRelatorio = false;
		
		HttpServletRequest request = (HttpServletRequest) FacesContext
				.getCurrentInstance().getExternalContext().getRequest();

		// COLOCA O OBJETO DO RELATORIO NA SESSAO
		if (request.getSession(false) != null) {
			request.getSession().setAttribute("arquivo",
					csv.createContents(tabela.toArray()));
		} else {
			error("Sess\u00E3o expirada!");
		}
	}

	public List<Assunto> getListaAssunto() {
		return assuntoList;
	}

	public void setListaAssunto(List<Assunto> listaAssunto) {
		this.assuntoList = listaAssunto;
	}

	public final List<SelectItem> getAssuntoList() {
		return JSFUtil.toSelectItemConsulta(assuntoList);
	}

	public final void setAssuntoList(List<Assunto> assuntoList) {
		this.assuntoList = assuntoList;
	}

	public Causa getCausa() {
		return causa;
	}

	public void setCausa(Causa causa) {
		this.causa = causa;
	}

	public List<Causa> getCausaList() {
		return causaList;
	}

	public void setCausaList(List<Causa> causaList) {
		this.causaList = causaList;
	}

	public boolean isSelecionaTodasCausas() {
		return selecionaTodasCausas;
	}

	public void setSelecionaTodasCausas(boolean selecionaTodasCausas) {
		this.selecionaTodasCausas = selecionaTodasCausas;
	}

	public List<Causa> getCausaSelecionadaList() {
		return causaSelecionadaList;
	}

	public void setCausaSelecionadaList(List<Causa> causaSelecionadaList) {
		this.causaSelecionadaList = causaSelecionadaList;
	}

	public String getContextPath() {
		return contextPath;
	}

	public void setContextPath(String contextPath) {
		this.contextPath = contextPath;
	}

	public boolean isGeraRelatorio() {
		return geraRelatorio;
	}

	public void setGeraRelatorio(boolean geraRelatorio) {
		this.geraRelatorio = geraRelatorio;
	}
	
	@Override
	protected IEventoService getService() {
		return eventoService;
	}
	
	public String getFlagAtivo() {
		return flagAtivo;
	}

	public void setFlagAtivo(String flagAtivo) {
		this.flagAtivo = flagAtivo;
		
		if(StringUtils.isBlank(flagAtivo)){
			getPojo().setFlagAtivo(null);
		}else{
			getPojo().setFlagAtivo(Boolean.valueOf(flagAtivo));
		}
	}

	public String getFlagFinalizacaoAutomatica() {
		return flagFinalizacaoAutomatica;
	}

	public void setFlagFinalizacaoAutomatica(String flagFinalizacaoAutomatica) {
		this.flagFinalizacaoAutomatica = flagFinalizacaoAutomatica;
		
		if(StringUtils.isBlank(flagFinalizacaoAutomatica)){
			getPojo().setFlagFinalizacaoAutomatica(null);
		}else{
			getPojo().setFlagFinalizacaoAutomatica(Boolean.valueOf(flagFinalizacaoAutomatica));
		}
	}
	
	

}
