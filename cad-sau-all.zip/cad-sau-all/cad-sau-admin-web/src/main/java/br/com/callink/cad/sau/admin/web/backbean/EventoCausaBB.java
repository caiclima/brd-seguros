/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.sau.admin.web.backbean;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.model.SelectItem;

import br.com.callink.cad.sau.pojo.Assunto;
import br.com.callink.cad.sau.pojo.Causa;
import br.com.callink.cad.sau.pojo.Evento;
import br.com.callink.cad.sau.pojo.EventoCausa;
import br.com.callink.cad.sau.service.IAssuntoService;
import br.com.callink.cad.sau.service.ICausaService;
import br.com.callink.cad.sau.service.IEventoCausaService;
import br.com.callink.cad.sau.service.IEventoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.util.JSFUtil;

/**
 *
 * @author ubuntu
 */
@ManagedBean
@ViewScoped
public class EventoCausaBB extends GboSauAdminGenericCrud<EventoCausa, IEventoCausaService> {

    private static final long serialVersionUID = 7122352540937471690L;
    
    private List<Assunto> assuntoList;
    private List<Causa> listCausa;
    private List<Evento> listEvento;
    private Assunto assuntoSelecionado;
    
    @EJB
    private IEventoCausaService eventoCausaService;
    @EJB
    private ICausaService causaService;
    @EJB
    private IEventoService eventoService;
    @EJB
    private IAssuntoService assuntoService;
    
    @PostConstruct
    public void init() {
    	novo();
        atualiza();
    }

    public Assunto getAssuntoSelecionado() {
        return assuntoSelecionado;
    }

    public void setAssuntoSelecionado(Assunto assuntoSelecionado) {
        this.assuntoSelecionado = assuntoSelecionado;
    }

    private void atualiza() {
        try {
            setPojos(getService().findByEventoCausa(null, null));
            filtrar();
            listCausa = causaService.findAll();
            listEvento = eventoService.findAll();
        } catch (ServiceException ex) {
            error(ex);
        }
    }

    @Override
    public void novo() {
        EventoCausa eventoCausa = new EventoCausa();
        Evento evento = new Evento();
        Causa causa = new Causa();
        eventoCausa.setCausa(causa);
        eventoCausa.setEvento(evento);
        setPojo(eventoCausa);
    }

    public void salva() {
        try {
        	if (getPojo().getEvento() == null || getPojo().getEvento().getNome() == null
        			|| "".equals(getPojo().getEvento().getNome()) || getPojo().getCausa() == null
        			|| getPojo().getCausa().getNome() == null || "".equals(getPojo().getCausa().getNome())) {
        		error(new Exception("Os campos Evento e Causa Erro devem ser preenchidos."));
        	} else {
	            super.salvar();
	            novo();
	            filtrar();
        	}
        } catch (Exception ex) {
            error(ex);
        }
    }

    @Override
    public String filtrar() {
        try {
            setPojos(getService().findByEventoCausa(getPojo().getEvento(), getPojo().getCausa()));
        } catch (ServiceException ex) {
            error(ex);
        }
        return null;
    }

    public void filtrarCausa() {
        try {
            this.listCausa = causaService.findByExample(getPojo().getCausa(), "Causa.NOME");
        } catch (ServiceException ex) {
            error(ex);
        }
    }

    public void filtrarEvento() {
        try {
            listEvento = eventoService.findByAssuntoAndEvento(assuntoSelecionado, getPojo().getEvento());
        } catch (ServiceException ex) {
            error(ex);
        }
    }

    public void setCausa(Causa causa) {
        getPojo().setCausa(causa);
    }

    public void setEvento(Evento evento) {
        getPojo().setEvento(evento);
    }

    public String excluir(EventoCausa eventoCausa) {
        try {
            getService().delete(eventoCausa);
            atualiza();
        } catch (Exception ex) {
            error(ex);
        }
        return null;
    }

    public void alterar(EventoCausa eventoCausa) {

        setPojo(eventoCausa);

    }

    public List<Causa> getListCausa() {
        return listCausa;
    }

    public void setListCausa(List<Causa> listCausa) {
        this.listCausa = listCausa;
    }

    public List<Evento> getListEvento() {
        return listEvento;
    }

    public void setListEvento(List<Evento> listEvento) {
        this.listEvento = listEvento;
    }
    
    public final List<SelectItem> getAssuntoList() {
        if(assuntoList == null){
            try {
                assuntoList = assuntoService.findAtivos("Assunto.NOME");
            } catch (ServiceException ex) {
                Logger.getLogger(EventoCausaBB.class.getName()).log(Level.SEVERE, null, ex);
                error("Não foi possível buscar os assuntos.");
            }
        }
        return JSFUtil.toSelectItemConsulta(assuntoList);
    }

    public final void setAssuntoList(List<Assunto> assuntoList) {
        this.assuntoList = assuntoList;
    }
    
    @Override
	protected IEventoCausaService getService() {
		return eventoCausaService;
	}
}
