/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.sau.admin.web.backbean;

import org.apache.commons.lang.exception.ExceptionUtils;

import br.com.callink.cad.backbean.CadGenericCrud;
import br.com.callink.cad.pojo.entity.IEntity;
import br.com.callink.cad.sau.service.IGenericCadSauService;

/**
 * 
 * @author Ednaldo Caic [ednaldo@swb.com.br]
 * @since 11/01/2012
 */
@SuppressWarnings("rawtypes")
public abstract class GboSauAdminGenericCrud<T extends IEntity<Integer>, SERVICE extends IGenericCadSauService> extends CadGenericCrud<T, SERVICE>{

	private static final long serialVersionUID = -7247355047546922719L;

	@Override
	protected abstract SERVICE getService();
	
	public GboSauAdminGenericCrud() {
	}

	@Override
	protected void error(Exception exception) {
		logger.error(exception);
		if (exception.getCause() != null) {
			super.error(ExceptionUtils.getRootCause(exception).getMessage());
		} else {
			if (exception.getMessage() == null) {
				super.error(exception.toString());
			} else {
				super.error(exception.getMessage());
			}
		}
	}

	public CasoSelecionadoBB getCasoSelecionadoBB() {
		return (CasoSelecionadoBB) getSessionMap().get("casoSelecionadoBB");
	}

	public void mostraPanelAnexo() {
		setMostraPanelAnexo(Boolean.TRUE);
	}

}
