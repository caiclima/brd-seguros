package br.com.callink.cad.sau.admin.web.backbean;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.sau.pojo.Juncao;
import br.com.callink.cad.sau.service.IJuncaoService;
import br.com.callink.cad.service.exception.ServiceException;

/**
 * 
 * @author brunomt [brunoam@swb.com.br]
 * 
 */
@ManagedBean
@ViewScoped
public class JuncaoBB extends GboSauAdminGenericCrud<Juncao, IJuncaoService> {
	
	private static final long serialVersionUID = 1L;
	
	private String flagAtivo;

	@EJB
	private IJuncaoService juncaoService;
	
	@PostConstruct
    public void init() {
		setPojo(new Juncao());
		try {
			setPojos(getService().findByExample(getPojo(), "Juncao.NOME"));
            getPojo().setFlagAtivo(Boolean.TRUE);

		} catch (ServiceException e) {
			error(e);
		}
	}
	
    @Override
    public String filtrar() {
        try {
            setPojos(getService().findByExample(getPojo(), "Juncao.NOME"));
        } catch (ServiceException e) {
            error(e);
        }
        return null;
    }
    
    @Override
    public void novo() {
    	setPojo(new Juncao());
        try {
            setPojos(getService().findByExample(getPojo(), "Juncao.NOME"));
        } catch (ServiceException e) {
            error(e);
        }
    }
    
    @Override
    public String salvar() {
        String ret = super.salvar();
        if (getPojo().getIdJuncao()!= null) {
	        novo();
	        filtrar();
        }
        return ret;
    }

    public void alterar(Juncao juncao) {
    	setPojo(juncao);
    }
    
    public String excluir(Juncao juncao) {
    	try {
    		getService().inativar(juncao);
        	info("Registro Inativado com sucesso.");

		} catch (ServiceException e) {
			error(e);
		}
    	return null;
    }
	
    @Override
	protected IJuncaoService getService() {
		return juncaoService;
	}
    
    public String getFlagAtivo() {
		return flagAtivo;
	}

	public void setFlagAtivo(String flagAtivo) {
		this.flagAtivo = flagAtivo;
		
		if(StringUtils.isBlank(flagAtivo)){
			getPojo().setFlagAtivo(null);
		}else{
			getPojo().setFlagAtivo(Boolean.valueOf(flagAtivo));
		}
	}
	
}
