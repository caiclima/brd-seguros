/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.sau.admin.web.backbean;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.sau.pojo.OutraArea;
import br.com.callink.cad.sau.service.IOutraAreaService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 *
 * @author ubuntu
 */
@ManagedBean
@ViewScoped
public class OutraAreaBB extends GboSauAdminGenericCrud<OutraArea, IOutraAreaService> {

	private static final long serialVersionUID = -6233849844698042264L;
	
	private String flagAtivo;
	
	@EJB
	private IOutraAreaService outraAreaService;
	
    @PostConstruct
    public void init() {
    	novo();
        filtrar();
    }
    
    @Override
    public String salvar() {
        try {
            getService().saveOrUpdate(getPojo());
            if (getPojo().getIdOutraArea() != null) {
                novo();
                filtrar();
            }
        } catch (ValidationException e) {
        	error(e);
        } catch (ServiceException e) {
            error(e);
        }
        return null;
    }
    
    @Override
    public final void novo() {
        OutraArea outraArea = new OutraArea();
        outraArea.setFlagAtivo(Boolean.TRUE);
        setPojo(outraArea);
    }
    
    @Override
    public final String filtrar() {
        try {
            setPojos(getService().findByExample(getPojo(), "OutraArea.NOME"));
        } catch (ServiceException e) {
            error(e);
        }
        return null;
    }
    
    public void alterar(OutraArea outraArea) {
        setPojo(outraArea);
    }
    
    public String excluir(OutraArea outraArea) {
        try {
            getService().delete(outraArea);
        } catch (ValidationException e) {
            error(e);
        } catch (ServiceException e) {
            error(e);
        }
        return null;
    }
    
    @Override
	protected IOutraAreaService getService() {
		return outraAreaService;
	}
    
    public String getFlagAtivo() {
		return flagAtivo;
	}

	public void setFlagAtivo(String flagAtivo) {
		this.flagAtivo = flagAtivo;
		
		if(StringUtils.isBlank(flagAtivo)){
			getPojo().setFlagAtivo(null);
		}else{
			getPojo().setFlagAtivo(Boolean.valueOf(flagAtivo));
		}
	}
}
