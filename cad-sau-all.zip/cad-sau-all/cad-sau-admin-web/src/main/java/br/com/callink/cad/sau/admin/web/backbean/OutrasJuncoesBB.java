package br.com.callink.cad.sau.admin.web.backbean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;

import br.com.callink.cad.backbean.CadGenericCrud;
import br.com.callink.cad.engine.command.executor.IExecutorCommandService;
import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.Log;
import br.com.callink.cad.pojo.Status;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.service.ICasoSauService;
import br.com.callink.cad.service.IAcaoService;
import br.com.callink.cad.service.ICasoService;
import br.com.callink.cad.service.ILogService;
import br.com.callink.cad.service.IStatusService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.util.Constantes;
import br.com.callink.cad.util.PropertieUtils;

/**
 * 
 * @author Ednaldo Caic [ednaldo@swb.com.br]
 * 
 */
@ManagedBean
@ViewScoped
public class OutrasJuncoesBB extends CadGenericCrud<Caso, ICasoService> {

    private static final long serialVersionUID = 1L;
    private String descricaoFinalizar;
    private Caso casoSelecionado;
    private List<Log> historicoCaso;
    
    @EJB
    private ICasoService casoService;
    @EJB
    private ICasoSauService casoSauService;
    @EJB
    private IAcaoService acaoService;
    @EJB(beanName="ExecutorCommandService")
    private IExecutorCommandService executorCommandService;
    @EJB
    private ILogService logService;
    @EJB
    private IStatusService statusService;
    
    @PostConstruct
    public void init() {
    	filtrar();

        HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        setUrlDownload(request.getContextPath() + "/downloadAnexo");
    }

    public void finalizaCaso() {

        try {
            Map<String, Object> casoMap = new HashMap<String, Object>();

            String nomeAcaoFinalizar = PropertieUtils.getPropertieByArquivoAndChave(
                    Constantes.CAMINHO_ARQUIVO_PROPERTIES_CONFIGURACAO_TELA,
                    Constantes.NOME_ARQUIVO_PROPERTIE,
                    Constantes.CHAVE_NOME_ACAO_FINALIZAR);

            Acao acao = new Acao();
            acao.setNome(nomeAcaoFinalizar);
            acao = acaoService.findByNome(acao);

            if (acao == null) {
                error("Erro : N\u00E3o foi poss\u00EDvel finalizar o Caso, pois n\u00E3o foi encontrado uma A\u00E7\u00E3o Finalizar!");
            }
            
            CasoSau casoSau = casoSauService.findCasoSauByCaso(getCasoSelecionado());

            casoMap.put("casoSau", casoSau);
            casoMap.put("caso", getCasoSelecionado());
            casoMap.put("acao", acao);
            casoMap.put("observacao", getDescricaoFinalizar());

            executorCommandService.execute(casoMap);
            filtrar();
        } catch (ValidationException e) {
            error(e.getMessage());
        } catch (ServiceException e) {
            error(e);
        }

    }

    public void teste() {
    }

    public void buscaCasoCompleto(Caso caso) {

        try {
            limpaAnexos();
            
            setCasoSelecionado(getService().load(caso));

            setHistoricoCaso(logService.findHistorico(getCasoSelecionado()));
        } catch (ServiceException e) {
            error("Erro ao buscar dados do Caso selecionado!");
        }
    }

    @Override
    public String filtrar() {

        try {

            String nomeStatusOutraJuncao = PropertieUtils.getPropertieByArquivoAndChave(
                    Constantes.CAMINHO_ARQUIVO_PROPERTIES_CONFIGURACAO_TELA,
                    Constantes.NOME_ARQUIVO_PROPERTIE,
                    Constantes.CHAVE_NOME_STATUS_OUTRA_JUNCAO);

            Status statusOutraJuncao = statusService.findStatusByNomeStatus(nomeStatusOutraJuncao);
            setPojos(getService().buscaPorStatus(statusOutraJuncao));

            setDescricaoFinalizar("");
            setCasoSelecionado(new Caso());
            setHistoricoCaso(new ArrayList<Log>());
        } catch (ServiceException e) {
            error(e.getMessage());
        }

        return "";
    }

    public final String getDescricaoFinalizar() {
        return descricaoFinalizar;
    }

    public final void setDescricaoFinalizar(String descricaoFinalizar) {
        this.descricaoFinalizar = descricaoFinalizar;
    }

    public final Caso getCasoSelecionado() {
        return casoSelecionado;
    }

    public final void setCasoSelecionado(Caso casoSelecionado) {
        this.casoSelecionado = casoSelecionado;
    }

    public final List<Log> getHistoricoCaso() {
        return historicoCaso;
    }

    public final void setHistoricoCaso(List<Log> historicoCaso) {
        this.historicoCaso = historicoCaso;
    }
    
    @Override
	protected ICasoService getService() {
		return casoService;
	}

	@Override
	public void novo() {
		
	}
}
