package br.com.callink.cad.sau.admin.web.backbean;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.model.SelectItem;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.sau.enun.OperadorApresentacao;
import br.com.callink.cad.sau.enun.TipoConteudoResposta;
import br.com.callink.cad.sau.enun.TipoResposta;
import br.com.callink.cad.sau.pojo.Assunto;
import br.com.callink.cad.sau.pojo.Evento;
import br.com.callink.cad.sau.pojo.Questao;
import br.com.callink.cad.sau.pojo.Questionario;
import br.com.callink.cad.sau.service.IAssociaQuestionarioService;
import br.com.callink.cad.sau.service.IAssuntoService;
import br.com.callink.cad.sau.service.IEventoService;
import br.com.callink.cad.sau.service.IQuestionarioService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.util.JSFUtil;

/**
 * 
 * @author Rogério Moreira de Andrade. rogeriom@swb.com.br
 * 
 */
@ManagedBean
@ViewScoped
public class QuestionarioBB extends GboSauAdminGenericCrud<Questionario, IQuestionarioService> {

    private static final long serialVersionUID = -3966504149435484898L;
    private Questao questao;
    private List<TipoResposta> tipoRespostaList = Arrays.asList(TipoResposta.values());
    private List<TipoConteudoResposta> tipoConteudoRespostaList = Arrays.asList(TipoConteudoResposta.values());
    private List<OperadorApresentacao> tipoOperadorList = Arrays.asList(OperadorApresentacao.values());
    private List<Questao> listQuestoes;
    private List<Evento> listEvento;
    private List<Evento> listEventosSelecionados;
    private Evento exemplo;
    private List<Assunto> listAssunto;
    private boolean selecionaTodosEvento;
    private boolean edicaoQuestionario;
    private int tempID;
    private String addRespostas;
    
    private String flagAtivo;
    
    @EJB
    private IQuestionarioService questionarioService;
    @EJB
    private IAssuntoService assuntoService;
    @EJB
    private IEventoService eventoService;
    @EJB
    private IAssociaQuestionarioService associaQuestionarioService;

    @PostConstruct
    public void init() {
    	novo();
        filtrar();
        novaQuestao();
    }

    @Override
    public String salvar() {
        Questionario quest = getPojo();
        if (validaQuestionario(quest)) {
            try {

                listQuestoes.removeAll(getPojo().getQuestaoList());

                for (Questao qst : getPojo().getQuestaoList()) {
                    qst.setIdQuestao(null);
                }

                getPojo().getQuestaoList().addAll(listQuestoes);

                getService().salvaQuestionario(quest, listEventosSelecionados);
                novo();
                filtrar();
                novaQuestao();
                info("Dados salvos com sucesso");
            } catch (ValidationException ex) {
                error(ex);
            } catch (ServiceException ex) {
                error(ex, true);
            }
        }
        return null;
    }

    private boolean validaQuestionario(Questionario questionario) {
        boolean retorno = true;
        if (StringUtils.isEmpty(questionario.getDescricao())) {
            error("O campo Nome \u00E9 Obrigat\u00F3rio");
            retorno = false;
        }
        if (listQuestoes == null || listQuestoes.isEmpty()) {
            error("Question\u00E1rio informado n\u00E3o possui quest\u00F5es");
            retorno = false;
        }
        return retorno;
    }

    @Override
    public final void novo() {
        Questionario quest = new Questionario();
        quest.setFlagAtivo(Boolean.TRUE);
        setPojo(quest);
        edicaoQuestionario = false;
        listQuestoes = new ArrayList<Questao>();
        listEventosSelecionados = new ArrayList<Evento>();
        this.exemplo = new Evento();
        try {
            listAssunto = assuntoService.findAtivos("Assunto.NOME");
        } catch (ServiceException ex) {
            error(ex);
        }
    }

    @Override
    public final String filtrar() {
        try {
            setPojos(getService().findByExample(getPojo(), "Questionario.DESCRICAO"));
            Evento evento = new Evento();
            evento.setFlagAtivo(Boolean.TRUE);
            this.listEvento = eventoService.findByExample(evento, "Evento.NOME");
        } catch (ServiceException ex) {
            error(ex);
        }
        return null;
    }

	public void editarQuestionario(Questionario questionario) {
        try {
            Questionario qest = getService().editQuestionario(questionario);
            setPojo(qest);
            this.listEventosSelecionados = associaQuestionarioService.getEventosByQuestionario(questionario);
            this.listQuestoes = getPojo().getQuestaoList();
            edicaoQuestionario = true;
            getPojo().setQuestaoList(new ArrayList<Questao>());

            info("Question\u00E1 carregado na aba: Novo/Editar Questionario");

        } catch (ServiceException ex) {
            error(ex);
        }
    }

    //Questao
    public void editarQuestao(Questao questao) {
        this.questao = questao;
    }

    public void excluirQuestao(Questao questao) {
        listQuestoes.remove(questao);
    }

    public final void novaQuestao() {
        questao = new Questao();
        questao.setIsEditavel(Boolean.TRUE);
        questao.setFlagAtivo(Boolean.TRUE);
        questao.setIdQuestao(tempID++);
        questao.setRendered(Boolean.TRUE);
    }
    
    public final void ativarQuestao(Questao questao) {
    	questao.setFlagAtivo(Boolean.TRUE);
    }
    
    public final void desativarQuestao(Questao questao) {
    	questao.setFlagAtivo(Boolean.FALSE);
    }

    public void salvarQuestao() {

        questao.setQuestionario(getPojo());

        if (!validaQuestao()) {
            if (listQuestoes.contains(questao)) {
                listQuestoes.remove(questao);
                listQuestoes.add(questao);
            } else {
                listQuestoes.add(questao);
                if (getPojo().getQuestaoList() == null) {
                    getPojo().setQuestaoList(new ArrayList<Questao>());
                }
                getPojo().getQuestaoList().add(questao); 
            }
        }
        novaQuestao();
    }
    
    public void addRespostaQuestao() {
    	if (addRespostas != null && !addRespostas.isEmpty()) {
    		questao.setPossiveisRespostas(questao.getPossiveisRespostas()+";"+addRespostas);
    		salvarQuestao();
    		
    		addRespostas = "";
    	}
    }

    public boolean validaQuestao() {
        boolean erro = false;
        
        if (questao == null) {
            error("Selecione uma quest\u00E3o.");
            return true;
        }
        
        if (StringUtils.isEmpty(questao.getDescricao())) {
            error("O campo Descri\u00E7\u00E3o deve ser preenchido;");
            erro = true;
        }
        if (StringUtils.isEmpty(questao.getPossiveisRespostas())
                && !TipoResposta.DESCRITIVA_MULTLINHA.equals(questao.getTipoRespsta())
                && !TipoResposta.DESCRITIVA_LINHAUNICA.equals(questao.getTipoRespsta())) {

            error("O campo Poss\u00EDveis respostas deve ser preenchido;");
            erro = true;

        }
        if (questao.getOrdem() == null) {
            error("O campo Ordem deve ser preenchido;");
            erro = true;
        }
        if (questao.getTipoConteudoResposta() == null) {
            error("O campo Tipo Conteudo Resposta deve ser preenchido;");
            erro = true;
        }
        if (questao.getTipoRespsta() == null) {
            error("O campo Tipo Resposta deve ser preenchido;");
            erro = true;
        }
        if (questao.getRequerida() && StringUtils.isEmpty(questao.getMensagemRequerida())) {
            error("O campo Mensagem Requerida deve ser preenchido;");
            erro = true;
        }
        return erro;
    }

    public Questao getQuestao() {
        return questao;
    }

    public void setQuestao(Questao questao) {
        this.questao = questao;
    }

    public List<SelectItem> getTipoConteudoRespostaList() {
        return JSFUtil.toSelectItemConsulta(tipoConteudoRespostaList);
    }

    public void setTipoConteudoRespostaList(List<TipoConteudoResposta> tipoConteudoRespostaList) {
        this.tipoConteudoRespostaList = tipoConteudoRespostaList;
    }

    public List<SelectItem> getTipoRespostaList() {
        return JSFUtil.toSelectItemConsulta(tipoRespostaList);
    }

    public List<SelectItem> getRespostaRequerida() {
        List<SelectItem> retorno = new ArrayList<SelectItem>();
        retorno.add(new SelectItem(Boolean.TRUE, "Sim"));
        retorno.add(new SelectItem(Boolean.FALSE, "N\u00E3o"));
        return retorno;
    }

    public void setTipoRespostaList(List<TipoResposta> tipoRespostaList) {
        this.tipoRespostaList = tipoRespostaList;
    }

    public List<SelectItem> getTipoOperadorList() {
        return JSFUtil.toSelectItemConsulta(tipoOperadorList);
    }

    public void setTipoOperadorList(List<OperadorApresentacao> tipoOperadorList) {
        this.tipoOperadorList = tipoOperadorList;
    }

    public List<SelectItem> getSelectListQuestoes() {
        return JSFUtil.toSelectItemConsulta(listQuestoes);
    }

    public List<Questao> getListQuestoes() {
        return odenaListaDeQuestoes(listQuestoes);
    }

    public void setListQuestoes(List<Questao> listQuestoes) {
        this.listQuestoes = listQuestoes;
    }

    public List<Evento> getListEvento() {
        return listEvento;
    }

    public void setListEvento(List<Evento> listEvento) {
        this.listEvento = listEvento;
    }

    public boolean isSelecionaTodosEvento() {
        return selecionaTodosEvento;
    }

    public void setSelecionaTodosEvento(boolean selecionaTodosEvento) {
        this.selecionaTodosEvento = selecionaTodosEvento;
    }

    public List<Evento> getListEventosSelecionados() {
        return listEventosSelecionados;
    }

    public void setListEventosSelecionados(List<Evento> listEventosSelecionados) {
        this.listEventosSelecionados = listEventosSelecionados;
    }

    public Evento getExemplo() {
        return exemplo;
    }

    public void setExemplo(Evento exemplo) {
        this.exemplo = exemplo;
    }

    public void filtrarEvento() {
        try {
            this.listEvento = eventoService.findByExample(exemplo, "Evento.NOME");
            for (Evento evt : listEvento) {
                if (listEventosSelecionados != null && listEventosSelecionados.contains(evt)) {
                    evt.setSelecionado(Boolean.TRUE);
                }
            }
        } catch (ServiceException ex) {
            error(ex);
        }
    }

    public void selecionaTodosEventos() {
        if (listEventosSelecionados == null) {
            listEventosSelecionados = new ArrayList<Evento>();
        }else{
            listEventosSelecionados.clear();
        }

        for (Evento item : listEvento) {
            if (selecionaTodosEvento) {
                item.setSelecionado(Boolean.TRUE);
                listEventosSelecionados.add(item);
            } else {
                item.setSelecionado(Boolean.FALSE);
            }
        }
    }

    public void selecionaEventos() {
        if (listEventosSelecionados == null) {
            listEventosSelecionados = new ArrayList<Evento>();
        }

        for (Evento item : listEvento) {
            if (item.getSelecionado() && !listEventosSelecionados.contains(item)) {
                listEventosSelecionados.add(item);
            }else if (!item.getSelecionado() && listEventosSelecionados.contains(item)){
                listEventosSelecionados.remove(item);
            }
        }
    }

    public List<SelectItem> getListAssunto() {
        return JSFUtil.toSelectItemConsulta(listAssunto);
    }

    public void setListAssunto(List<Assunto> listAssunto) {
        this.listAssunto = listAssunto;
    }

    public void removeEvento(Evento evento) {
        if (listEventosSelecionados != null) {
            listEventosSelecionados.remove(evento);
            if(listEvento.contains(evento)){
                listEvento.get(listEvento.indexOf(evento)).setSelecionado(Boolean.FALSE);
            }
            if (edicaoQuestionario) {
                info("Para concluir a remo\u00E7\u00E3o \u00E9 necess\u00E1rio clicar no bot\u00E3o Salvar");
                edicaoQuestionario = false;
            }
        }
    }

    private List<Questao> odenaListaDeQuestoes(List<Questao> list) {

        List<Questao> listQuestao = new ArrayList<Questao>();

        Collections.sort(list, new Comparator<Questao>() {

            @Override
            public int compare(Questao o1, Questao o2) {
                Integer var1 = o1.getOrdem();
                Integer var2 = o2.getOrdem();

                return var1.compareTo(var2);
            }
        });

        for (Questao q1 : list) {

            if (q1.getQuestaoPai() == null || q1.getQuestaoPai().getIdQuestao() == null) {
                listQuestao.add(q1);
                listQuestao.addAll(hierarquiaDeQuestoes(list, q1));
            }
        }

        return listQuestao;
    }

    private List<Questao> hierarquiaDeQuestoes(List<Questao> list, Questao qst) {
        List<Questao> listReturn = new ArrayList<Questao>();
        for (Questao q2 : list) {

            if (qst.equals(q2.getQuestaoPai())) {
                listReturn.add(q2);
                listReturn.addAll(hierarquiaDeQuestoes(list, q2));
            }
        }
        return listReturn;
    }

	/**
	 * @return the addRespostas
	 */
	public final String getAddRespostas() {
		return addRespostas;
	}

	/**
	 * @param addRespostas the addRespostas to set
	 */
	public final void setAddRespostas(String addRespostas) {
		this.addRespostas = addRespostas;
	}
	
	@Override
	protected IQuestionarioService getService() {
		return questionarioService;
	}
	
	public String getFlagAtivo() {
		return flagAtivo;
	}

	public void setFlagAtivo(String flagAtivo) {
		this.flagAtivo = flagAtivo;
		
		if(StringUtils.isBlank(flagAtivo)){
			getPojo().setFlagAtivo(null);
		}else{
			getPojo().setFlagAtivo(Boolean.valueOf(flagAtivo));
		}
	}
}
