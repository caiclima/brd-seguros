package br.com.callink.cad.sau.admin.web.backbean;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.model.SelectItem;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.sau.pojo.Assunto;
import br.com.callink.cad.sau.pojo.Evento;
import br.com.callink.cad.sau.pojo.TipoManifestacao;
import br.com.callink.cad.sau.service.IAssuntoService;
import br.com.callink.cad.sau.service.IEventoService;
import br.com.callink.cad.sau.service.ITipoManifestacaoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.util.BundleHelper;
import br.com.callink.cad.util.JSFUtil;

/**
 * 
 * @author brunomt [brunoam@swb.com.br]
 * 
 */
@ManagedBean
@ViewScoped
public class TipoManifestacaoBB extends GboSauAdminGenericCrud<TipoManifestacao, ITipoManifestacaoService> {

    private static final long serialVersionUID = 1L;
    
    private List<Evento> listEvento;
    private List<Assunto> listAssunto;
    private String execucaoSelecionada;
    private String renderNovoEdit;
    
    private String flagAtivo;
    private String flagNaoAtende;
    
    @EJB
    private ITipoManifestacaoService tipoManifestacaoService;
    @EJB
    private IAssuntoService assuntoService;
    @EJB
    private IEventoService eventoService;

    @PostConstruct
    public void init() {
    	try {
            setPojos(getService().findAll());
            listEvento = new ArrayList<Evento>();
            listAssunto = assuntoService.findAtivos("Assunto.NOME");
            
            novo();
            setFlagAtivo(Boolean.TRUE.toString());
        } catch (ServiceException e) {
            error(e);
        }
    }
    
    @Override
    public void novo() {
        TipoManifestacao tm = new TipoManifestacao();
        tm.setEvento(new Evento());
        tm.setFlagAtivo(Boolean.TRUE);
        execucaoSelecionada = null;
        setPojo(tm);
        findAll();
        flagAtivo = null;
        flagNaoAtende = null;
    }

    public void filtrarEvento() {
        try {
            if (getPojo().getPK() != null) {
                renderNovoEdit = "inputEditEvento";
            } else {
                renderNovoEdit = "inputNovoEvento";
            }
            this.listEvento = eventoService.findByExample(getPojo().getEvento(), "Evento.NOME");
        } catch (ServiceException ex) {
            error(ex);
        }
    }

    public void limpaEvento() {
        setEvento(new Evento());
    }

    public void setEvento(Evento evento) {
        getPojo().setEvento(evento);
    }

    @Override
    public String filtrar() {
        try {
            if (execucaoSelecionada.equals("1")) {
                getPojo().setFlagClassificaAutomatico(Boolean.TRUE);
                getPojo().setFlagFinalizaAutomatico(Boolean.FALSE);
            } else if (execucaoSelecionada.equals("2")) {
                getPojo().setFlagFinalizaAutomatico(Boolean.TRUE);
                getPojo().setFlagClassificaAutomatico(Boolean.FALSE);
            } else if (execucaoSelecionada.equals("0"))  {
                getPojo().setFlagFinalizaAutomatico(Boolean.FALSE);
                getPojo().setFlagClassificaAutomatico(Boolean.FALSE);
            }
            
            boolean eventoNull = getPojo().getEvento() == null || getPojo().getEvento().getIdEvento() == null;
            
            if (eventoNull) {
                getPojo().setEvento(null);
            }
            
            setPojos(getService().findByExample(getPojo(), "TipoManifestacao.NOME"));
            
            if (eventoNull) {
               limpaEvento();
            }
            
        } catch (ServiceException e) {
            error(e);
        }
        return null;
    }

    public void findAll() {
        try {
            setPojos(getService().findAll());
        } catch (ServiceException e) {
            error(e);
        }
    }

    @Override
    public String salvar() {

        try {
            if (execucaoSelecionada.equals("1")) {
                getPojo().setFlagClassificaAutomatico(Boolean.TRUE);
                getPojo().setFlagFinalizaAutomatico(Boolean.FALSE);
            } else if (execucaoSelecionada.equals("2")) {
                getPojo().setFlagFinalizaAutomatico(Boolean.TRUE);
                getPojo().setFlagClassificaAutomatico(Boolean.FALSE);
            } else {
                getPojo().setFlagFinalizaAutomatico(Boolean.FALSE);
                getPojo().setFlagClassificaAutomatico(Boolean.FALSE);
            }
            validaEvento();
            
            if(getPojo().getEvento()!= null && getPojo().getEvento().getIdEvento()==null){
            	getPojo().setEvento(null);
            }
            
            getService().saveOrUpdate(getPojo());
            novo();
            info(BundleHelper.getMessage("MSG_Save_Success", "bundleGbo"));
            setPojos(getService().findAll());
        } catch (ValidationException e) {
			error(e);
        } catch (ServiceException ex) {
            error(ex);
        }

        return null;
    }

    private void validaEvento() throws ServiceException {
        boolean obrigaEvento = getPojo().getFlagClassificaAutomatico() || getPojo().getFlagFinalizaAutomatico();
        boolean eventoIsNull = getPojo().getEvento() == null || getPojo().getEvento().getIdEvento() == null;
        if (obrigaEvento && eventoIsNull) {
            throw new ServiceException("O campo Evento \u00E9 Obrigat\u00F3rio.");
        }
    }

    public void alterar(TipoManifestacao tipoManifestacao) {
        if (tipoManifestacao.getFlagClassificaAutomatico()) {
            execucaoSelecionada = "1";
        } else if (tipoManifestacao.getFlagFinalizaAutomatico()) {
            execucaoSelecionada = "2";
        } else {
            execucaoSelecionada = "0";
        }
        setPojo(tipoManifestacao);
    }

    public String excluir(TipoManifestacao tipoManifestacao) {
        try {
            getService().inativar(tipoManifestacao);
        } catch (ValidationException e) {
        	error(e);
        } catch (ServiceException e) {
            error(e);
        }
        return null;
    }

    public String getRenderNovoEdit() {
        return renderNovoEdit;
    }

    public void setRenderNovoEdit(String renderNovoEdit) {
        this.renderNovoEdit = renderNovoEdit;
    }

    public String getExecucaoSelecionada() {
        return execucaoSelecionada;
    }

    public void setExecucaoSelecionada(String execucaoSelecionada) {
        this.execucaoSelecionada = execucaoSelecionada;
    }

    public List<Evento> getListEvento() {
        return listEvento;
    }

    public void setListEvento(List<Evento> listEvento) {
        this.listEvento = listEvento;
    }

    public final List<SelectItem> getAssuntoList() {
        return JSFUtil.toSelectItemConsulta(listAssunto);
    }

    public final void setAssuntoList(List<Assunto> listAssunto) {
        this.listAssunto = listAssunto;
    }
    
    @Override
	protected ITipoManifestacaoService getService() {
		return tipoManifestacaoService;
	}
    
    public String getFlagAtivo() {
		return flagAtivo;
	}

	public void setFlagAtivo(String flagAtivo) {
		this.flagAtivo = flagAtivo;
		
		if(StringUtils.isBlank(flagAtivo)){
			getPojo().setFlagAtivo(null);
		}else{
			getPojo().setFlagAtivo(Boolean.valueOf(flagAtivo));
		}
	}

	public String getFlagNaoAtende() {
		return flagNaoAtende;
	}

	public void setFlagNaoAtende(String flagNaoAtende) {
		this.flagNaoAtende = flagNaoAtende;
		
		if (StringUtils.isBlank(flagNaoAtende)) {
			getPojo().setFlagNaoAtende(null);
		} else {
			getPojo().setFlagNaoAtende(Boolean.valueOf(flagNaoAtende));
		}
	}
	
}
