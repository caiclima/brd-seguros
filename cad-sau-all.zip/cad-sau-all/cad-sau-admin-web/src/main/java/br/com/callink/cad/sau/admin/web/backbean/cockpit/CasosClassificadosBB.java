package br.com.callink.cad.sau.admin.web.backbean.cockpit;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;

import br.com.callink.cad.sau.admin.web.backbean.GboSauAdminGenericCrud;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.pojo.TipoManifestacao;
import br.com.callink.cad.sau.repository.CasoClassificadoCockpit;
import br.com.callink.cad.sau.repository.CasoClassificadoCockpitTipoManifestacao;
import br.com.callink.cad.sau.repository.CasosClassificadosCockpit;
import br.com.callink.cad.sau.service.ICasoSauService;
import br.com.callink.cad.sau.service.ITipoManifestacaoService;
import br.com.callink.cad.sau.util.CsvUtils;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.util.Constantes;

/**
 *
 * @author brunomt
 */
@ManagedBean
@SessionScoped
public class CasosClassificadosBB extends GboSauAdminGenericCrud<CasoSau, ICasoSauService> {

	private static final long serialVersionUID = 1L;
    private List<TipoManifestacao> tipoManifestacaoList;
    private List<String> tipoManifestacaoNomeSelecionadoList;
    private boolean selecionaTodosTipoManifestacao;
    private List<TipoManifestacao> tipoManifestacaoSelecionadoList = new ArrayList<TipoManifestacao>();
    private List<CasoClassificadoCockpitTipoManifestacao> casoClassificadoCockpitTipoManifestacaosList;
    private String contextPath;
    private Integer top;
    
    private String divsRender;
    private String valoresDivs;
    
    //Variaveis para renderizar o datagrid dos modais
    private boolean renderGridTipoManifestacao;
    
    @EJB
    private ICasoSauService casoSauService;
    @EJB
    private ITipoManifestacaoService tipoManifestacaoService;
    
    @PostConstruct
    public void init() {
    	try {
            HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
            setContextPath(request.getContextPath() + "/exportarCsv");
            tipoManifestacaoList = tipoManifestacaoService.findAtivos("TipoManifestacao.NOME");
            top = 1;
            renderGridTipoManifestacao = Boolean.FALSE;
        } catch (Exception ex) {
            error(ex);
        }
    }
    
    public void mudaFlagGrid() {
        renderGridTipoManifestacao = Boolean.TRUE;
    }

    public void marcaDesmarcaTipoManifestacao(TipoManifestacao tipoManifestacao) {
        if (tipoManifestacao != null && tipoManifestacao.getSelecionado() != null) {
            if (tipoManifestacaoNomeSelecionadoList == null) {
                tipoManifestacaoNomeSelecionadoList = new ArrayList<String>();
            }
            if (tipoManifestacao.getSelecionado()) {
                if (!tipoManifestacaoNomeSelecionadoList.contains(tipoManifestacao.getNome())) {
                    tipoManifestacaoNomeSelecionadoList.add(tipoManifestacao.getNome());
                }

            } else {
                if (tipoManifestacaoNomeSelecionadoList.contains(tipoManifestacao.getNome())) {
                    tipoManifestacaoNomeSelecionadoList.remove(tipoManifestacao.getNome());
                }
            }
        }
    }

    public void buscaCasosClassificados() {
        try {
            if (tipoManifestacaoList != null) {
                tipoManifestacaoSelecionadoList.clear();
                for (TipoManifestacao item : tipoManifestacaoList) {
                    if (item.getSelecionado() != null && item.getSelecionado()) {
                        tipoManifestacaoSelecionadoList.add(item);
                    }
                }
            }
            
            renderGridTipoManifestacao = Boolean.FALSE;
            
            casoClassificadoCockpitTipoManifestacaosList = CasosClassificadosCockpit.retornaCasoClassificadoCockpit(top, tipoManifestacaoSelecionadoList);
            preparaDivsGraficos();
            gerarCSV();
        } catch (Exception ex) {
            error(ex);
        }
    }
    
    private void preparaDivsGraficos() {
        Boolean proximo = false;
        StringBuilder string = new StringBuilder();
        StringBuilder stringAssuntos = new StringBuilder();
        Boolean proximoTipo = false;
        for (CasoClassificadoCockpitTipoManifestacao casoClassificadoCockpitTipoManifestacao : casoClassificadoCockpitTipoManifestacaosList) {
            if (proximo) {
                string.append(";");
            }
            
            string.append(casoClassificadoCockpitTipoManifestacao.getNomeDiv());
            Boolean proximoAssunto = false;
            proximo = true;
            for (CasoClassificadoCockpit casoClassificadoCockpit : casoClassificadoCockpitTipoManifestacao.getCasoClassificacaoCockpitList()) {
                if (!casoClassificadoCockpit.getAssunto().equals(CasoClassificadoCockpit.OUTROS)) {
                    if (proximoTipo) {
                        stringAssuntos.append("#");
                        proximoTipo = false;
                    }
                    if (proximoAssunto) {
                        stringAssuntos.append(";");
                    }
                    stringAssuntos.append(casoClassificadoCockpit.getAssunto());
                    stringAssuntos.append(",");
                    stringAssuntos.append(casoClassificadoCockpit.getVolumeTotal());

                    proximoAssunto = true;
                }
            }
            proximoTipo = true;
        }
        divsRender = string.toString();
        valoresDivs = stringAssuntos.toString();
    }
    
    private void gerarCSV() {
        CsvUtils csv = new CsvUtils("casos_classificados.csv", null);

        List<Object> tabela = new ArrayList<Object>();
        List<Object> linhaAtual = new ArrayList<Object>();
        linhaAtual.add("TIPO_MANIFESTACAO");
        linhaAtual.add("TOP");
        linhaAtual.add("ASSUNTO");
        linhaAtual.add("DP");
        linhaAtual.add("FP");

        tabela.add(linhaAtual.toArray());
        
        for (CasoClassificadoCockpitTipoManifestacao casoClassificadoCockpitTipoManifestacao : casoClassificadoCockpitTipoManifestacaosList) {
            for (CasoClassificadoCockpit casoClassificadoCockpit : casoClassificadoCockpitTipoManifestacao.getCasoClassificacaoCockpitList()) {
             linhaAtual = new ArrayList<Object>();
             linhaAtual.add(casoClassificadoCockpitTipoManifestacao.getTipoManifestacao());
             linhaAtual.add(casoClassificadoCockpit.getTop());
             linhaAtual.add(casoClassificadoCockpit.getAssunto());
             linhaAtual.add(casoClassificadoCockpit.getVolumeDentroPrazo());
             linhaAtual.add(casoClassificadoCockpit.getVolumeForaPrazo());
             tabela.add(linhaAtual.toArray());
            }
        }
        
        HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();

        // COLOCA O OBJETO DO RELATORIO NA SESSAO
        if (request.getSession(false) != null) {
            request.getSession().setAttribute("arquivo",
                    csv.createContents(tabela.toArray()));
        } else {
            error("Sess\u00E3o expirada!");
        }
    }

    public void selecionaTodosTipoManifestacao() {

        for (TipoManifestacao item : tipoManifestacaoList) {
            if (selecionaTodosTipoManifestacao == Boolean.TRUE) {
                item.setSelecionado(Boolean.TRUE);
            } else {
                item.setSelecionado(Boolean.FALSE);
            }
            marcaDesmarcaTipoManifestacao(item);
        }
        
        buscaCasosClassificados();
    }

    public String getTipoManifestacaoNomeSelecionadoList() {

        if (tipoManifestacaoNomeSelecionadoList == null || tipoManifestacaoNomeSelecionadoList.toString().equals(Constantes.LISTA_STRING_VAZIA)) {
            return "";
        }
        return tipoManifestacaoNomeSelecionadoList.toString();
    }

    public void setTipoManifestacaoNomeSelecionadoList(List<String> tipoManifestacaoNomeSelecionadoList) {
        this.tipoManifestacaoNomeSelecionadoList = tipoManifestacaoNomeSelecionadoList;
    }

    public final boolean isSelecionaTodosTipoManifestacao() {
        return selecionaTodosTipoManifestacao;
    }

    public final void setSelecionaTodosTipoManifestacao(
            boolean selecionaTodosTipoManifestacao) {
        this.selecionaTodosTipoManifestacao = selecionaTodosTipoManifestacao;
    }
    
    public final List<TipoManifestacao> getTipoManifestacaoList() {
        try {
            if (tipoManifestacaoList == null) {
                setTipoManifestacaoList(tipoManifestacaoService.findAll());
            }
            return tipoManifestacaoList;
        } catch (ServiceException e) {
            error(e);
        }
        return null;
    }

    public final void setTipoManifestacaoList(
            List<TipoManifestacao> tipoManifestacaoList) {
        this.tipoManifestacaoList = tipoManifestacaoList;
    }

    public String getContextPath() {
        return contextPath;
    }

    public void setContextPath(String contextPath) {
        this.contextPath = contextPath;
    }

    public Integer getTop() {
        return top;
    }

    public void setTop(Integer top) {
        this.top = top;
    }

    public List<CasoClassificadoCockpitTipoManifestacao> getCasoClassificadoCockpitTipoManifestacaosList() {
        return casoClassificadoCockpitTipoManifestacaosList;
    }

    public void setCasoClassificadoCockpitTipoManifestacaosList(List<CasoClassificadoCockpitTipoManifestacao> casoClassificadoCockpitTipoManifestacaosList) {
        this.casoClassificadoCockpitTipoManifestacaosList = casoClassificadoCockpitTipoManifestacaosList;
    }

    public String getDivsRender() {
        return divsRender;
    }

    public void setDivsRender(String divsRender) {
        this.divsRender = divsRender;
    }

    public String getValoresDivs() {
        return valoresDivs;
    }

    public void setValoresDivs(String valoresDivs) {
        this.valoresDivs = valoresDivs;
    }

    public boolean isRenderGridTipoManifestacao() {
        return renderGridTipoManifestacao;
    }

    public void setRenderGridTipoManifestacao(boolean renderGridTipoManifestacao) {
        this.renderGridTipoManifestacao = renderGridTipoManifestacao;
    }
    
    @Override
	protected ICasoSauService getService() {
		return casoSauService;
	}

	@Override
	public void novo() {
		
	}
    
}
