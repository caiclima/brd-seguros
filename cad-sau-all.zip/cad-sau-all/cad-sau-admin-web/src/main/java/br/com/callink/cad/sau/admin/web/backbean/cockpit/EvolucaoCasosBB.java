package br.com.callink.cad.sau.admin.web.backbean.cockpit;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;

import br.com.callink.cad.sau.admin.web.backbean.GboSauAdminGenericCrud;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.pojo.EvolucaoAtendimento;
import br.com.callink.cad.sau.pojo.TipoManifestacao;
import br.com.callink.cad.sau.pojo.to.EvolucaoAtendimentoTO;
import br.com.callink.cad.sau.service.ICasoSauService;
import br.com.callink.cad.sau.service.IEvolucaoAtendimentoService;
import br.com.callink.cad.sau.service.ITipoManifestacaoService;
import br.com.callink.cad.sau.util.CsvUtils;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.util.Constantes;

/**
 *
 * @author brunomt
 */
@ManagedBean
@SessionScoped
public class EvolucaoCasosBB extends GboSauAdminGenericCrud<CasoSau, ICasoSauService> {
	
	private static final long serialVersionUID = 1L;
	
    private List<TipoManifestacao> tipoManifestacaoList;
    private List<String> tipoManifestacaoNomeSelecionadoList;
    private List<EvolucaoAtendimentoTO> evolucaoAtendimentoTOList;
    private boolean selecionaTodosTipoManifestacao;
    private List<TipoManifestacao> tipoManifestacaoSelecionadoList = new ArrayList<TipoManifestacao>();
    private String contextPath;
    private Integer quantidadeDias;
    
    //Variaveis para renderizar o datagrid dos modais
    private boolean renderGridTipoManifestacao;
    
    @EJB
    private ICasoSauService casoSauService;
    @EJB
    private ITipoManifestacaoService tipoManifestacaoService;
    @EJB
    private IEvolucaoAtendimentoService evolucaoAtendimentoService;
    
    @PostConstruct
    public void init() {
    	try {
            HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
            setContextPath(request.getContextPath() + "/exportarCsv");
            tipoManifestacaoList = tipoManifestacaoService.findAtivos("TipoManifestacao.NOME");
            quantidadeDias = 1;
            findEvolucaoCasos();
        } catch (Exception ex) {
            error(ex);
        }
    }
    
    public void mudaFlagGrid() {
        renderGridTipoManifestacao = Boolean.TRUE;
    }

    public void findEvolucaoCasos() {
        if (tipoManifestacaoList != null) {
            tipoManifestacaoSelecionadoList.clear();
            for (TipoManifestacao item : tipoManifestacaoList) {
                if (item.getSelecionado() != null && item.getSelecionado()) {
                    tipoManifestacaoSelecionadoList.add(item);
                }
            }
        }
        
        renderGridTipoManifestacao = Boolean.FALSE;
        try {
           setEvolucaoAtendimentoTOList(evolucaoAtendimentoService.recuperaEvolucaoAtendimento(tipoManifestacaoSelecionadoList, quantidadeDias));
            gerarCSV();
        } catch (ServiceException ex) {
            Logger.getLogger(EvolucaoCasosBB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void marcaDesmarcaTipoManifestacao(TipoManifestacao tipoManifestacao) {
        if (tipoManifestacao != null && tipoManifestacao.getSelecionado() != null) {
            if (tipoManifestacaoNomeSelecionadoList == null) {
                tipoManifestacaoNomeSelecionadoList = new ArrayList<String>();
            }
            if (tipoManifestacao.getSelecionado()) {
                if (!tipoManifestacaoNomeSelecionadoList.contains(tipoManifestacao.getNome())) {
                    tipoManifestacaoNomeSelecionadoList.add(tipoManifestacao.getNome());
                }

            } else {
                if (tipoManifestacaoNomeSelecionadoList.contains(tipoManifestacao.getNome())) {
                    tipoManifestacaoNomeSelecionadoList.remove(tipoManifestacao.getNome());
                }
            }
        }
    }
    
    private void gerarCSV() {
        CsvUtils csv = new CsvUtils("evolucao_casos.csv", null);

        List<Object> tabela = new ArrayList<Object>();
        List<Object> linhaAtual = new ArrayList<Object>();
        linhaAtual.add("DATA_EVOLUCAO");
        linhaAtual.add("TIPO_MANIFESTACAO");
        linhaAtual.add("TOTAL_ENTRANTES");
        linhaAtual.add("PENDENTE_DP");
        linhaAtual.add("PENDENTE_FP");
        linhaAtual.add("PERCENTUAL_PENDENTE FP%");
        linhaAtual.add("PENDENTE_TOTAL");
        linhaAtual.add("FECHADOS_DP");
        linhaAtual.add("FECHADOS_FP");
        linhaAtual.add("PERCENTUAL_FECHADOS_FP%");
        linhaAtual.add("FECHADOS_TOTAL");

        tabela.add(linhaAtual.toArray());
        DateFormat formatter = new SimpleDateFormat("dd-MM-yyyy hh:mm");
        for (EvolucaoAtendimentoTO evolucaoAtendimento : getEvolucaoAtendimentoTOList()) {
            for (EvolucaoAtendimento evolucaoAtendimentoItem : evolucaoAtendimento.getEvolucaoAtendimento()) {
                 linhaAtual = new ArrayList<Object>();
                 linhaAtual.add(formatter.format(evolucaoAtendimento.getDataRelatorio()));
                 linhaAtual.add(evolucaoAtendimentoItem.getTipoManifestacao());
                 linhaAtual.add(evolucaoAtendimentoItem.getTotalEntrantes());
                 linhaAtual.add(evolucaoAtendimentoItem.getPendenteDentroPrazo());
                 linhaAtual.add(evolucaoAtendimentoItem.getPendenteForaPrazo());
                 linhaAtual.add(evolucaoAtendimentoItem.getPendenteForaPrazoPercentual());
                 linhaAtual.add(evolucaoAtendimentoItem.getPendenteTotal());
                 linhaAtual.add(evolucaoAtendimentoItem.getFechadoDentroPrazo());
                 linhaAtual.add(evolucaoAtendimentoItem.getFechadoForaPrazo());
                 linhaAtual.add(evolucaoAtendimentoItem.getFechadoForaPrazoPercentual());
                 linhaAtual.add(evolucaoAtendimentoItem.getFechadoTotal());
                 tabela.add(linhaAtual.toArray());
            }
        }
        
        HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();

        // COLOCA O OBJETO DO RELATORIO NA SESSAO
        if (request.getSession(false) != null) {
            request.getSession().setAttribute("arquivo",
                    csv.createContents(tabela.toArray()));
        } else {
            error("Sess\u00E3o expirada!");
        }
    }

    public void selecionaTodosTipoManifestacao() {

        for (TipoManifestacao item : tipoManifestacaoList) {
            if (selecionaTodosTipoManifestacao == Boolean.TRUE) {
                item.setSelecionado(Boolean.TRUE);
            } else {
                item.setSelecionado(Boolean.FALSE);
            }
            marcaDesmarcaTipoManifestacao(item);
        }
        
        findEvolucaoCasos();
    }

    public String getTipoManifestacaoNomeSelecionadoList() {

        if (tipoManifestacaoNomeSelecionadoList == null || tipoManifestacaoNomeSelecionadoList.toString().equals(Constantes.LISTA_STRING_VAZIA)) {
            return "";
        }
        return tipoManifestacaoNomeSelecionadoList.toString();
    }

    public void setTipoManifestacaoNomeSelecionadoList(List<String> tipoManifestacaoNomeSelecionadoList) {
        this.tipoManifestacaoNomeSelecionadoList = tipoManifestacaoNomeSelecionadoList;
    }

    public final boolean isSelecionaTodosTipoManifestacao() {
        return selecionaTodosTipoManifestacao;
    }

    public final void setSelecionaTodosTipoManifestacao(
            boolean selecionaTodosTipoManifestacao) {
        this.selecionaTodosTipoManifestacao = selecionaTodosTipoManifestacao;
    }
    
    public final List<TipoManifestacao> getTipoManifestacaoList() {
        try {
            if (tipoManifestacaoList == null) {
                setTipoManifestacaoList(tipoManifestacaoService.findAll());
            }
            return tipoManifestacaoList;
        } catch (ServiceException e) {
            error(e);
        }
        return null;
    }

    public final void setTipoManifestacaoList(
            List<TipoManifestacao> tipoManifestacaoList) {
        this.tipoManifestacaoList = tipoManifestacaoList;
    }

    public String getContextPath() {
        return contextPath;
    }

    public void setContextPath(String contextPath) {
        this.contextPath = contextPath;
    }

    public Integer getQuantidadeDias() {
        return quantidadeDias;
    }

    public void setQuantidadeDias(Integer quantidadeDias) {
        this.quantidadeDias = quantidadeDias;
    }

    public List<EvolucaoAtendimentoTO> getEvolucaoAtendimentoTOList() {
        
    	if(evolucaoAtendimentoTOList== null){
    		evolucaoAtendimentoTOList = new ArrayList<EvolucaoAtendimentoTO>();
    	}
    	
    	return evolucaoAtendimentoTOList;
    }

    public void setEvolucaoAtendimentoTOList(List<EvolucaoAtendimentoTO> evolucaoAtendimentoTOList) {
        this.evolucaoAtendimentoTOList = evolucaoAtendimentoTOList;
    }

    public boolean isRenderGridTipoManifestacao() {
        return renderGridTipoManifestacao;
    }

    public void setRenderGridTipoManifestacao(boolean renderGridTipoManifestacao) {
        this.renderGridTipoManifestacao = renderGridTipoManifestacao;
    }
    
    @Override
	protected ICasoSauService getService() {
		return casoSauService;
	}

	@Override
	public void novo() {
		
	}
    
}
