package br.com.callink.cad.sau.admin.web.backbean.cockpit;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;

import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.sau.admin.web.backbean.GboSauAdminGenericCrud;
import br.com.callink.cad.sau.pojo.CasoAbertoCockpit;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.pojo.TipoManifestacao;
import br.com.callink.cad.sau.service.ICasoAbertoCockpitService;
import br.com.callink.cad.sau.service.ICasoSauService;
import br.com.callink.cad.sau.service.ITipoManifestacaoService;
import br.com.callink.cad.service.IConfiguracaoFilaService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.util.Constantes;
import br.com.callink.coreutils.util.csv.CsvUtils;

/**
 *
 * @author brunomt
 */
@ManagedBean
@SessionScoped
public class SlaCasosAbertosBB extends GboSauAdminGenericCrud<CasoSau, ICasoSauService> {
	
	private static final long serialVersionUID = 1L;
	
	@EJB
    private ITipoManifestacaoService tipoManifestacaoService;
	@EJB
    private IConfiguracaoFilaService configuracaoFilaService;
	@EJB
    private ICasoAbertoCockpitService casoAbertoCockpitService;
    
    private List<TipoManifestacao> tipoManifestacaoList;
    private List<ConfiguracaoFila> configuracaoFilaList;
    
    private List<String> tipoManifestacaoNomeSelecionadoList;
    private List<String> filaAtendimentoNomeSelecionadoList;
    
    private List<CasoAbertoCockpit> casoAbertoCockpitList;
    private List<CasoAbertoCockpit> casoAbertoCockpitPorFilaList;
    
    private boolean selecionaTodosTipoManifestacao;
    private boolean selecionaTodosFilaAtendimento;
    
    private List<TipoManifestacao> tipoManifestacaoSelecionadoList = new ArrayList<TipoManifestacao>();
    private List<ConfiguracaoFila> configuracaoFilaSelecionadoList = new ArrayList<ConfiguracaoFila>();
    private String contextPath;
    
    //Variaveis para renderizar o datagrid dos modais
    private boolean renderGridTipoManifestacao;
    private boolean renderGridFilaAtendimento;
    

    @PostConstruct
    public void init(){
    	try {
            
            HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
            setContextPath(request.getContextPath() + "/exportarCsv");
            
            tipoManifestacaoList = tipoManifestacaoService.findAtivos("TipoManifestacao.NOME");
            configuracaoFilaList = configuracaoFilaService.findAtivos("ConfiguracaoFila.NOME");
            
            casoAbertoCockpitList = casoAbertoCockpitService.getCasoAbertoList(tipoManifestacaoSelecionadoList);
            casoAbertoCockpitPorFilaList = casoAbertoCockpitService.getCasoAbertoListPorFila(configuracaoFilaSelecionadoList);
            
            renderGridTipoManifestacao = false;
            renderGridFilaAtendimento = false;
            
        } catch (Exception ex) {
            error(ex);
        }
    }

    public void findCasosAbertosCockpit() {
        
    	if (tipoManifestacaoList != null) {
            tipoManifestacaoSelecionadoList.clear();
            for (TipoManifestacao item : tipoManifestacaoList) {
                if (item.getSelecionado() != null && item.getSelecionado()) {
                    tipoManifestacaoSelecionadoList.add(item);
                }
            }
        }
        
        renderGridTipoManifestacao = false;
            try {
                casoAbertoCockpitList = casoAbertoCockpitService.getCasoAbertoList(tipoManifestacaoSelecionadoList);
            } catch (ServiceException ex) {
                error(ex);
            }
        //gera csv com tipo de manifestacao
        gerarCSV(true);
    }

    public void findCasosAbertosCockpitPorFila() {
        
    	if ( configuracaoFilaList!= null) {
    		configuracaoFilaSelecionadoList.clear();
            for (ConfiguracaoFila item : configuracaoFilaList) {
                if (item.getSelecionado() != null && item.getSelecionado()) {
                	configuracaoFilaSelecionadoList.add(item);
                }
            }
        }
        
        renderGridFilaAtendimento = false;
            try {
                casoAbertoCockpitPorFilaList = casoAbertoCockpitService.getCasoAbertoListPorFila(configuracaoFilaSelecionadoList);
            } catch (ServiceException ex) {
               error(ex);
            }
        
        //gera csv com fila de atendimento
        gerarCSV(false);
    }
    
    public void marcaDesmarcaTipoManifestacao(TipoManifestacao tipoManifestacao) {
        if (tipoManifestacao != null && tipoManifestacao.getSelecionado() != null) {
            if (tipoManifestacaoNomeSelecionadoList == null) {
                tipoManifestacaoNomeSelecionadoList = new ArrayList<String>();
            }
            if (tipoManifestacao.getSelecionado()) {
                if (!tipoManifestacaoNomeSelecionadoList.contains(tipoManifestacao.getNome())) {
                    tipoManifestacaoNomeSelecionadoList.add(tipoManifestacao.getNome());
                }

            } else {
                if (tipoManifestacaoNomeSelecionadoList.contains(tipoManifestacao.getNome())) {
                    tipoManifestacaoNomeSelecionadoList.remove(tipoManifestacao.getNome());
                }
            }
        }
    }
    
    public void marcaDesmarcaFilaAtendimento(ConfiguracaoFila configuracaoFila) {
        if (configuracaoFila != null && configuracaoFila.getSelecionado() != null) {
            if (filaAtendimentoNomeSelecionadoList == null) {
            	filaAtendimentoNomeSelecionadoList = new ArrayList<String>();
            }
            if (configuracaoFila.getSelecionado()) {
                if (!filaAtendimentoNomeSelecionadoList.contains(configuracaoFila.getNome())) {
                	filaAtendimentoNomeSelecionadoList.add(configuracaoFila.getNome());
                }

            } else {
                if (filaAtendimentoNomeSelecionadoList.contains(configuracaoFila.getNome())) {
                	filaAtendimentoNomeSelecionadoList.remove(configuracaoFila.getNome());
                }
            }
        }
    }
    
    private void gerarCSV(boolean isTipoManifestacao) {
        CsvUtils csv = new CsvUtils("sla_casos_abertos_cockpit.csv", null);

        List<Object> tabela = new ArrayList<Object>();
        List<Object> linhaAtual = new ArrayList<Object>();
        List<CasoAbertoCockpit>  cockpit = null;
        
        if(isTipoManifestacao){
        	 linhaAtual.add("TIPO_MANIFESTACAO");
        	 cockpit = casoAbertoCockpitList;
        }else{
        	 linhaAtual.add("FILA_ATENDIMENTO");
        	 cockpit = casoAbertoCockpitPorFilaList;
        }
       
        linhaAtual.add("DIA_0");
        linhaAtual.add("PERCENTUAL_DIA_0");
        linhaAtual.add("DIA_1");
        linhaAtual.add("PERCENTUAL_DIA_1");
        linhaAtual.add("DIA_2");
        linhaAtual.add("PERCENTUAL_DIA_2");
        linhaAtual.add("DIA_3");
        linhaAtual.add("PERCENTUAL_DIA_3");
        linhaAtual.add("DIA_4");
        linhaAtual.add("PERCENTUAL_DIA_4");
        linhaAtual.add("DIA_5");
        linhaAtual.add("PERCENTUAL_DIA_5");
        linhaAtual.add("DIA_>5");
        linhaAtual.add("PERCENTUAL_DIA_>5");
        linhaAtual.add("TOTAL");
        linhaAtual.add("PERCENTUAL_DIA_TOTAL");
        tabela.add(linhaAtual.toArray());
        
        for (CasoAbertoCockpit casoAbertoCockpit : cockpit) {
             linhaAtual = new ArrayList<Object>();
             
             if(isTipoManifestacao){
            	 linhaAtual.add(casoAbertoCockpit.getTipoManifestacao());
             }else{
            	 linhaAtual.add(casoAbertoCockpit.getNomeFilaAtendimento());
             }
             
             linhaAtual.add(casoAbertoCockpit.getQtdPrimeiroDia());
             linhaAtual.add(casoAbertoCockpit.getPercentualPrimeiroDia());
             linhaAtual.add(casoAbertoCockpit.getQtdSegundoDia());
             linhaAtual.add(casoAbertoCockpit.getPercentualSegundoDia());
             linhaAtual.add(casoAbertoCockpit.getQtdTerceiroDia());
             linhaAtual.add(casoAbertoCockpit.getPercentualTerceiroDia());
             linhaAtual.add(casoAbertoCockpit.getQtdQuartoDia());
             linhaAtual.add(casoAbertoCockpit.getPercentualQuartoDia());
             linhaAtual.add(casoAbertoCockpit.getQtdQuintoDia());
             linhaAtual.add(casoAbertoCockpit.getPercentualQuintoDia());
             linhaAtual.add(casoAbertoCockpit.getQtdSextoDia());
             linhaAtual.add(casoAbertoCockpit.getPercentualSextoDia());
             linhaAtual.add(casoAbertoCockpit.getQtdRestanteDia());
             linhaAtual.add(casoAbertoCockpit.getPercentualRestanteDia());
             linhaAtual.add(casoAbertoCockpit.getQtdTotal());
             linhaAtual.add(casoAbertoCockpit.getPercentualTotal());
             tabela.add(linhaAtual.toArray());
        }
        
        HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();

        // COLOCA O OBJETO DO RELATORIO NA SESSAO
        if (request.getSession(false) != null) {
            request.getSession().setAttribute("arquivo",
                    csv.createContents(tabela.toArray()));
        } else {
            error("Sess\u00E3o expirada!");
        }
    }
    
    public void selecionaTodosFilaAtendimento() {

        for (ConfiguracaoFila item : configuracaoFilaList) {
            if (selecionaTodosFilaAtendimento == Boolean.TRUE) {
                item.setSelecionado(Boolean.TRUE);
            } else {
                item.setSelecionado(Boolean.FALSE);
            }
            marcaDesmarcaFilaAtendimento(item);
        }
    }
    

    public void selecionaTodosTipoManifestacao() {

        for (TipoManifestacao item : tipoManifestacaoList) {
            if (selecionaTodosTipoManifestacao == Boolean.TRUE) {
                item.setSelecionado(Boolean.TRUE);
            } else {
                item.setSelecionado(Boolean.FALSE);
            }
            marcaDesmarcaTipoManifestacao(item);
        }
    }

    public String getTipoManifestacaoNomeSelecionadoList() {

        if (tipoManifestacaoNomeSelecionadoList == null || tipoManifestacaoNomeSelecionadoList.toString().equals(Constantes.LISTA_STRING_VAZIA)) {
            return "";
        }
        return tipoManifestacaoNomeSelecionadoList.toString();
    }
    
    public void mudaFlagGrid() {
        renderGridTipoManifestacao = Boolean.TRUE;
    }

    public void mudaFlagGridFila(){
    	renderGridFilaAtendimento = Boolean.TRUE;
    }
    
    public void setTipoManifestacaoNomeSelecionadoList(List<String> tipoManifestacaoNomeSelecionadoList) {
        this.tipoManifestacaoNomeSelecionadoList = tipoManifestacaoNomeSelecionadoList;
    }

    public List<CasoAbertoCockpit> getCasoAbertoCockpitList() {
        return casoAbertoCockpitList;
    }

    public void setCasoAbertoCockpitList(List<CasoAbertoCockpit> casoAbertoCockpitList) {
        this.casoAbertoCockpitList = casoAbertoCockpitList;
    }

    public final boolean isSelecionaTodosTipoManifestacao() {
        return selecionaTodosTipoManifestacao;
    }

    public final void setSelecionaTodosTipoManifestacao(
            boolean selecionaTodosTipoManifestacao) {
        this.selecionaTodosTipoManifestacao = selecionaTodosTipoManifestacao;
    }
    
    public final List<TipoManifestacao> getTipoManifestacaoList() {
        try {
            if (tipoManifestacaoList == null) {
                setTipoManifestacaoList(tipoManifestacaoService.findAll());
            }
            return tipoManifestacaoList;
        } catch (ServiceException e) {
            error(e);
        }
        return null;
    }
    
    public List<ConfiguracaoFila> getConfiguracaoFilaList() {
		
    	try{
    		if(configuracaoFilaList == null){
    			setConfiguracaoFilaList(configuracaoFilaService.findAll());
    		}
    		return configuracaoFilaList;
    	}catch (ServiceException e) {
			error(e);
		}
    	return null;
	}

	public void setConfiguracaoFilaList(List<ConfiguracaoFila> configuracaoFilaList) {
		this.configuracaoFilaList = configuracaoFilaList;
	}

	public List<ConfiguracaoFila> getConfiguracaoFilaSelecionadoList() {
		return configuracaoFilaSelecionadoList;
	}

	public void setConfiguracaoFilaSelecionadoList(
			List<ConfiguracaoFila> configuracaoFilaSelecionadoList) {
		this.configuracaoFilaSelecionadoList = configuracaoFilaSelecionadoList;
	}

	public final void setTipoManifestacaoList(
            List<TipoManifestacao> tipoManifestacaoList) {
        this.tipoManifestacaoList = tipoManifestacaoList;
    }

    public String getContextPath() {
        return contextPath;
    }

    public void setContextPath(String contextPath) {
        this.contextPath = contextPath;
    }

    public boolean isRenderGridTipoManifestacao() {
        return renderGridTipoManifestacao;
    }

    public void setRenderGridTipoManifestacao(boolean renderGridTipoManifestacao) {
        this.renderGridTipoManifestacao = renderGridTipoManifestacao;
    }

	public List<CasoAbertoCockpit> getCasoAbertoCockpitPorFilaList() {
		return casoAbertoCockpitPorFilaList;
	}

	public void setCasoAbertoCockpitPorFilaList(
			List<CasoAbertoCockpit> casoAbertoCockpitPorFilaList) {
		this.casoAbertoCockpitPorFilaList = casoAbertoCockpitPorFilaList;
	}

	public boolean isSelecionaTodosFilaAtendimento() {
		return selecionaTodosFilaAtendimento;
	}

	public void setSelecionaTodosFilaAtendimento(
			boolean selecionaTodosFilaAtendimento) {
		this.selecionaTodosFilaAtendimento = selecionaTodosFilaAtendimento;
	}

	public List<TipoManifestacao> getTipoManifestacaoSelecionadoList() {
		return tipoManifestacaoSelecionadoList;
	}

	public void setTipoManifestacaoSelecionadoList(
			List<TipoManifestacao> tipoManifestacaoSelecionadoList) {
		this.tipoManifestacaoSelecionadoList = tipoManifestacaoSelecionadoList;
	}

	public boolean isRenderGridFilaAtendimento() {
		return renderGridFilaAtendimento;
	}

	public void setRenderGridFilaAtendimento(boolean renderGridFilaAtendimento) {
		this.renderGridFilaAtendimento = renderGridFilaAtendimento;
	}

	public String getFilaAtendimentoNomeSelecionadoList() {

        if (filaAtendimentoNomeSelecionadoList == null || filaAtendimentoNomeSelecionadoList.toString().equals(Constantes.LISTA_STRING_VAZIA)) {
            return "";
        }
        return filaAtendimentoNomeSelecionadoList.toString();
	}

	public void setFilaAtendimentoNomeSelecionadoList(
			List<String> filaAtendimentoNomeSelecionadoList) {
		this.filaAtendimentoNomeSelecionadoList = filaAtendimentoNomeSelecionadoList;
	}

	@Override
	protected ICasoSauService getService() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void novo() {
		// TODO Auto-generated method stub
		
	}
	
}
