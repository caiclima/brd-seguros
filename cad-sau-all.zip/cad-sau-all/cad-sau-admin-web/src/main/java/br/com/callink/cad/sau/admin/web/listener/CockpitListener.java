/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.sau.admin.web.listener;

import java.util.logging.Logger;

import javax.ejb.EJB;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import br.com.callink.cad.listener.EnfileiramentoListener;
import br.com.callink.cad.sau.cockpit.ThreadCasoAbertoCockpit;
import br.com.callink.cad.sau.cockpit.ThreadCasosClassificadosCockpit;
import br.com.callink.cad.sau.cockpit.ThreadEvolucaoAtendimentoCaso;
import br.com.callink.cad.sau.service.ICasoSauService;
import br.com.callink.cad.sau.service.IEvolucaoAtendimentoService;
import br.com.callink.cad.service.IParametroGBOService;

/**
 *
 * @author brunomt
 */
public class CockpitListener implements ServletContextListener{
    
	private Logger logger = Logger.getLogger(EnfileiramentoListener.class.getName());
	
	@EJB
	private IParametroGBOService parametroGBOService;
	@EJB
    private ICasoSauService casoSauService; 
	@EJB
    private IEvolucaoAtendimentoService evolucaoAtendimentoService;
	
	@Override
    public void contextInitialized(ServletContextEvent arg0) {
        logger.info("Inicia CockpitListener...");
        
        ThreadEvolucaoAtendimentoCaso threadEvolucaoAtendimentoCaso = new ThreadEvolucaoAtendimentoCaso(parametroGBOService, evolucaoAtendimentoService);
        threadEvolucaoAtendimentoCaso.setName("ThreadEvolucaoAtendimentoCaso");
        threadEvolucaoAtendimentoCaso.start();
        
        ThreadCasoAbertoCockpit threadCasoAbertoCockpit = new ThreadCasoAbertoCockpit(parametroGBOService, casoSauService);
        threadCasoAbertoCockpit.setName("ThreadCasoAbertoCockpit");
        threadCasoAbertoCockpit.start();
        
        ThreadCasosClassificadosCockpit threadCasosClassificadosCockpit = new ThreadCasosClassificadosCockpit(parametroGBOService, casoSauService);
        threadCasosClassificadosCockpit.setName("ThreadCasosClassificadosCockpit");
        threadCasosClassificadosCockpit.start();
        
        logger.info("CockpitListener iniciado com sucesso...");
    }

	@Override
    public void contextDestroyed(ServletContextEvent arg0) {
        ThreadEvolucaoAtendimentoCaso.setExecuta(Boolean.FALSE);
        ThreadCasoAbertoCockpit.setExecuta(Boolean.FALSE);
        ThreadCasosClassificadosCockpit.setExecuta(Boolean.FALSE);
    }
    
}
