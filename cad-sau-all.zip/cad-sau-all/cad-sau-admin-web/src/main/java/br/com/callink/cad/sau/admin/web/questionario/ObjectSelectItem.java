package br.com.callink.cad.sau.admin.web.questionario;

import java.util.ArrayList;
import javax.faces.model.SelectItem;

/**
 * @author fabio
 */
public class ObjectSelectItem extends ArrayList {

	private static final long serialVersionUID = 1L;
	private Boolean optionDefault = Boolean.TRUE;
    private String title = "Selecione...";

    public ObjectSelectItem() {
        setDefault();
    }

    public ObjectSelectItem(Boolean optionDefault) {
        this.optionDefault = optionDefault;

        if (optionDefault) {
            setDefault();
        }

    }

    private void setDefault() {
        add(new SelectItem(null, title));
    }

    public void setList(Object[] objects) {

        clear();

        if (optionDefault) {
            setDefault();
        }

        for (Object object : objects) {
            add(new SelectItem(object));
        }
    }
}
