package br.com.callink.cad.sau.admin.web.util;

import java.util.HashMap;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.apache.commons.lang.StringUtils;
import org.richfaces.component.SortOrder;

/**
 * @author rafael peres dos santos rafaelp@swb.com.br Classe criada para
 *         abstrair o mecanismo de ordenação server side no richfaces 4.x já que
 *         a ordenação client side até o presente momento não funciona. Evitando
 *         a criação de varias propriedades e metodos que representam cada
 *         coluna da grid em um managed bean.. facilitando o desenvolvimento da
 *         ordenação
 * 
 *         <rich:dataTable value="#{usuarioMB.pojos}" var="usuario" rows="10"
 *         id="tabelaUsuario" noDataLabel="Nenhum registro encontrado."
 *         styleClass="width99" rowClasses="linhaPar, linhaImpar">
 * 
 * 
 *         <rich:column styleClass="left" sortBy="#{usuario.nome}"
 *         sortOrder="#{sortOrderMB.getSortOrder('NOME')}">
 * 
 *         <f:facet name="header"> <a4j:commandLink value="#{bundle.LBL_nome}"
 *         render="tabelaUsuario statusRequest"
 *         action="#{sortOrderMB.sortBy('NOME')}" /> </f:facet>
 * 
 *         <h:outputText value="#{usuario.nome}" /> </rich:column>
 * 
 *         <rich:column styleClass="left" sortBy="#{usuario.equipe.nome}"
 *         sortOrder="#{sortOrderMB.getSortOrder('EQUIPE')}">
 * 
 *         <f:facet name="header"> <a4j:commandLink value="#{bundle.LBL_equipe}"
 *         render="tabelaUsuario statusRequest"
 *         action="#{sortOrderMB.sortBy('EQUIPE')}" /> </f:facet>
 * 
 *         <h:outputText value="#{usuario.equipe.nome}" /> </rich:column>
 * 
 * 
 * 
 *         </rich:dataTable>
 **/
@ViewScoped
@ManagedBean(name = "sortOrderMB")
public class SortOrderBB {

	private Map<String, SortOrder> sortOrderMap = null;

	public SortOrderBB() {
		this.sortOrderMap = new HashMap<String, SortOrder>();
	}

	public SortOrder getSortOrder(String columnName) {
		if (!sortOrderMap.containsKey(columnName)) {
			return sortOrderMap.put(columnName, SortOrder.unsorted);
		}

		return sortOrderMap.get(columnName);
	}

	public void sortBy(String columnName) {
		if (StringUtils.isEmpty(columnName)) {
			throw new IllegalArgumentException("columnName can't be null");
		} else if (!sortOrderMap.containsKey(columnName)) {
			throw new IllegalArgumentException("invalid columnName, sortOrderMap don't contain a key named with that text!");
		}

		for (String columnNameKey : sortOrderMap.keySet()) {
			SortOrder sortOrder = sortOrderMap.get(columnNameKey);

			if (!columnNameKey.equals(columnName)) {
				sortOrder = SortOrder.unsorted;
			} else {
				sortOrder = sortOrder.equals(SortOrder.ascending) ? SortOrder.descending : SortOrder.ascending;
			}

			sortOrderMap.put(columnNameKey, sortOrder);
		}
	}
}
