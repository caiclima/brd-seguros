package br.com.callink.cad.sau.servlet;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 
 * @author ednaldo
 * @since 27/01/2012
 * 
 */
@WebServlet(name = "ExportarCsv", asyncSupported = false, urlPatterns = "/exportarCsv")
public class ExportCsvServlet extends HttpServlet {

	private static final long serialVersionUID = 8257986392458351401L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse response)
			throws ServletException, IOException {

		StringBuffer csv = (StringBuffer) req.getSession().getAttribute(
				"arquivo");
		if (csv != null) {
			response.setContentType("application/octet-stream");
			response.setCharacterEncoding("UTF-8");
			response.setHeader("Content-Disposition", "inline; filename="
					+ "tabela_de_casos.csv");

			try {

				BufferedInputStream in = new BufferedInputStream(
						new ByteArrayInputStream(csv.toString()
								.getBytes()));
				ServletOutputStream out = response.getOutputStream();

				int i = in.read();
				do {
					out.write(i);
					i = in.read();
				} while (i != -1);

				in.close();
				out.flush();
				out.close();
			} catch (IOException e) {

			}
		}

	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doGet(req, resp);
	}
}
