package br.com.callink.cad.sau.dao;

import java.util.List;

import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.AssociaChecklist;
import br.com.callink.cad.sau.pojo.Checklist;
import br.com.callink.cad.sau.pojo.Evento;


public interface IAssociaChecklistDAO extends IGenericCadSauDAO<AssociaChecklist> {

    Checklist getChecklist(Evento evento, Acao acao) throws DataException;

    List<Evento> getEventosByChecklist(Checklist checklist) throws DataException;

    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    void deletaAssociacoes(Checklist checklist) throws DataException;

    List<AssociaChecklist> buscaAssociacaoByListEvento(List<Evento> eventos) throws DataException;

    /**
     * busca {@link AssociaChecklist} pelo {@link Evento} e pela {@link Acao}
     * @param evento
     * @param acao
     * @return
     * @throws DataException
     */
	List<AssociaChecklist> buscaAssociacaoPorEventoAcao(Evento evento, Acao acao, Checklist checklist)
			throws DataException;

	/**
	 * busca a acao na tabela {@link AssociaChecklist} associado ao {@link Checklist} em parametro
	 * @param checklist
	 * @return
	 * @throws DataException
	 */
	Acao findAcaoByChecklist(Checklist checklist) throws DataException;
	
}
