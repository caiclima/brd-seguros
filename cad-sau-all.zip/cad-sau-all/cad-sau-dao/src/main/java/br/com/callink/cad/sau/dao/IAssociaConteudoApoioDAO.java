/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.sau.dao;

import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.AssociaConteudoApoio;

import java.util.List;

/**
 *
 * @author Luiz Gustavo F. (luizgf@swb.com.br)
 */
public interface IAssociaConteudoApoioDAO extends IGenericCadSauDAO<AssociaConteudoApoio> {

    /**
     * Busca todos as associacoes dos conteudos de apoio e tras objetos preenchidos
     * @return
     * @throws DataException 
     */
    List<AssociaConteudoApoio> buscaTodosComObjetosPreenchidos(AssociaConteudoApoio associaConteudoApoio) throws DataException;
}
