package br.com.callink.cad.sau.dao;

import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.AssociaQuestionario;
import br.com.callink.cad.sau.pojo.Evento;
import br.com.callink.cad.sau.pojo.Questionario;

import java.util.List;

import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

/**
 * 
 * @author ednaldo [ednaldo@swb.com.br]
 *
 */
public interface IAssociaQuestionarioDAO extends IGenericCadSauDAO<AssociaQuestionario> {

    Questionario getQuestionario(Evento evento) throws DataException;

    List<Evento> getEventosByQuestionario(Questionario questionario) throws DataException;

    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    void deletaAssociacoes(Questionario questionario) throws DataException;

    List<AssociaQuestionario> buscaAssociacaoByListEvento(List<Evento> eventos) throws DataException;
}
