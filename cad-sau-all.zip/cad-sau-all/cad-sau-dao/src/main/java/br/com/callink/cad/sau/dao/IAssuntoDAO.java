package br.com.callink.cad.sau.dao;

import br.com.callink.cad.sau.pojo.Assunto;

/**
 * DAO para um {@link Assunto}
 * @author brunomt [brunoam@swb.com.br]
 *
 */
public interface IAssuntoDAO extends IGenericCadSauDAO<Assunto> {

}
