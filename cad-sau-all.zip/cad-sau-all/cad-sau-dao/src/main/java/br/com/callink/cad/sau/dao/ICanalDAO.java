package br.com.callink.cad.sau.dao;

import br.com.callink.cad.sau.pojo.Canal;

/**
 * 
 * @author ednaldo [ednaldo@swb.com.br]
 *
 */
public interface ICanalDAO extends IGenericCadSauDAO<Canal>{

}
