/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.sau.dao;

import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.CasoAbertoCockpit;

import java.util.Date;
import java.util.List;

/**
 *
 * @author Rogerio
 */
public interface ICasoAbertoCockpitDAO extends IGenericCadSauDAO<CasoAbertoCockpit> {

    void delete(Date data) throws DataException;

    List<CasoAbertoCockpit> casosAbertos() throws DataException;

    List<CasoAbertoCockpit> casosAbertosFila() throws DataException;
}
