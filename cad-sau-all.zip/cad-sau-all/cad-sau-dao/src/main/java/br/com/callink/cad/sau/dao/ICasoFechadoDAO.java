package br.com.callink.cad.sau.dao;


import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.CasoFechado;

import java.util.List;

/**
 * 
 * @author ednaldo [ednaldo@swb.com.br]
 * @since 19/03/2012
 *
 */
public interface ICasoFechadoDAO extends IGenericCadSauDAO<CasoFechado> {

    /**
     * Busca o CasoFechado pela manifestacao
     * @param manifestacao
     * @return
     * @throws DataException 
     */
    CasoFechado buscaPorManifestacao(String manifestacao) throws DataException;
    
    /**
     * Busca todos os casos que estao abertos no gbo e foi importado como fechado no caso spa
     * @return
     * @throws DataException 
     */
    List<CasoFechado> buscaCasosFechadosSpaAbertosGbo() throws DataException;
}
