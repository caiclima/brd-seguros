package br.com.callink.cad.sau.dao;

import java.util.Date;
import java.util.List;

import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.pojo.Status;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.pojo.to.AcompanhamentoCasoFind;

/**
 *
 * @author ednaldo [ednaldo@swb.com.br]
 * @since 16/01/2012
 *
 */
public interface ICasoSauDAO extends IGenericCadSauDAO<CasoSau> {

    /**
     * Retorna true caso o numero da {@link manifestacao} exista na base de
     * dados
     *
     * @param manifestacao
     * @return
     * @throws DataException
     */
    boolean existeManifestacao(String manifestacao) throws DataException;

    /**
     * Retorna true caso o ID do {@link caso} exista na base de dados
     *
     * @param idCaso
     * @return
     * @throws DataException
     */
    boolean existeCasoGbo(Caso caso) throws DataException;

    /**
     * Retorna CasoSau associado ao caso;
     *
     * @param caso
     * @return CasoSau
     * @throws DataException
     */
    CasoSau findCasoSauByCaso(Caso caso) throws DataException;

    /**
     * Busca um List de CasoSau pela {@link ConfiguracaoFila} e pelo {@link Atendente}
     *
     * @param configuracaoFila
     * @param atendente
     * @return List<CasoSau>
     * @throws DataException
     */
    List<CasoSau> buscaPorConfiguracaoFilaEAtendente(ConfiguracaoFila configuracaoFila, Atendente atendente)
            throws DataException;

    /**
     * Pesquisa pelo ID e retorna os objetos Evento, Canal, Causa, Caso,
     * TipoManifestacao e Estado populados se existir associação
     *
     * @param casoSau
     * @return CasoSau
     * @throws DataException
     */
    CasoSau load(CasoSau casoSau) throws DataException;

    /**
     *
     * @param configuracaoFila
     * @param atendente
     * @return List<CasoSau>
     * @throws DataException
     */
    List<CasoSau> buscaPorFilaOrAtendenteOrManifestacao(ConfiguracaoFila configuracaoFila,
            Atendente atendente, String manifestacao) throws DataException;

    /**
     * Busca CasoSau por filtros
     *
     * @param casoSau
     * @param dataInicio
     * @param dataFim
     * @return List<CasoSau>
     * @throws DataException
     */
    List<CasoSau> buscaPorFiltroSQL(AcompanhamentoCasoFind acompanhamentoCasoFind) throws DataException;

    /**
     * Busca todos CasoSau abertos ou que foram alterados desde uma certa data.
     * Esta consulta é utilizada para a geração de uma tabela para o QlikView
     *
     * @param dataUltimaAlteracao
     * @return List<CasoSau>
     */
    List<CasoSau> buscaCasosAbertosOuComAtividadeRecente(Date dataUltimaAlteracao) throws DataException;

    /**
     * Busca todos os casos que ainda não foram classificados.
     *
     * @param statusList
     * @return
     * @throws DataException
     */
    List<CasoSau> buscaCasosAtivosPorStatus(List<Status> statusList) throws DataException;

    /**
     * Busca os casos que estão fechados no dia.
     *
     * @return
     * @throws DataException
     */
    List<CasoSau> buscaCasosFechadosNoDia() throws DataException;

    /**
     * Busca tocos os casos abertos no GBO. Ou seja que o flag_finalizado é
     * FALSE
     *
     * @return
     * @throws ServiceException
     */
    List<CasoSau> buscaCasoAberto() throws DataException;

    /**
     * Busca todos os casos abertos por assunto.
     *
     * @return
     * @throws DataException
     */
    List<CasoSau> buscaCasoAbertoAssunto() throws DataException;

    /**
     * Busca todos os casos importados para o GBO no dia Atual.
     *
     * @return
     * @throws DataException
     */
    List<CasoSau> buscaCasoEntranteDia() throws DataException;

    /**
     * Busca todos os casos que foram reabertos.
     *
     * @return
     * @throws ServiceException
     */
    List<CasoSau> buscaCasoReabertoDia() throws DataException;
    
    /**
     * Buscar todos os casos por um determinado número de CPF ou CNPJ.
     * 
     * @param cpfCnpj
     * @return List<CasoSau>
     * @throws DataException
     */
    List<CasoSau> buscarCasoSauPorCpfCnpj(String cpfCnpj) throws DataException;

    /**
     * 
     * @param status
     * @return
     * @throws DataException
     */
	List<CasoSau> buscaCasoAbertoSemPendencia(Integer statusPendente)
			throws DataException;


	List<CasoSau> buscaCasosFechadosChecagemNoDia(Status id)
			throws DataException;

	/**
	 * busca a quantidade de casos abertos por cpf/cnpj
	 * @param cpfCnpj
	 * @return
	 * @throws DataException
	 */
	Integer buscarQtdCasoAbertoPorCpfCnpj(String cpfCnpj) throws DataException;

	void flush();
}
