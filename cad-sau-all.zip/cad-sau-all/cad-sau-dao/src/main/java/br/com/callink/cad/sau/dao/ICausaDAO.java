package br.com.callink.cad.sau.dao;

import br.com.callink.cad.sau.pojo.Causa;

/**
 * 
 * @author ednaldo [ednaldo@swb.com.br]
 *
 */
public interface ICausaDAO extends IGenericCadSauDAO<Causa>{

}
