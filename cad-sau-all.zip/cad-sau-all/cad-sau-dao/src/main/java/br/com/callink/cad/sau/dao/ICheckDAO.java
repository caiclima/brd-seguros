package br.com.callink.cad.sau.dao;

import java.util.List;

import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.Check;
import br.com.callink.cad.sau.pojo.Checklist;

public interface ICheckDAO extends IGenericCadSauDAO<Check> {

	List<Check> findAllCheckByChecklist(Checklist checklist)
			throws DataException;

}
