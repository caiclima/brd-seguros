package br.com.callink.cad.sau.dao;

import br.com.callink.cad.sau.pojo.Checklist;

public interface IChecklistDAO extends IGenericCadSauDAO<Checklist> {
	

}
