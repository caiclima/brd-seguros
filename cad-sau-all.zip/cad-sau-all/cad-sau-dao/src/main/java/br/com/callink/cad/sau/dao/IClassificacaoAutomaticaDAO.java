package br.com.callink.cad.sau.dao;

import br.com.callink.cad.sau.pojo.ClassificacaoAutomatica;

public interface IClassificacaoAutomaticaDAO extends
		IGenericCadSauDAO<ClassificacaoAutomatica> {

}
