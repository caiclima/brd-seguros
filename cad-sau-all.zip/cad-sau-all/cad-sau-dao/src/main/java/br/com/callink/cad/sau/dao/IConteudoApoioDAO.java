package br.com.callink.cad.sau.dao;



import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.pojo.ConteudoApoio;
import br.com.callink.cad.sau.pojo.ConteudoApoioCasoSau;

import java.util.List;

/**
 * 
 * @author ednaldo [ednaldo@swb.com.br]
 *
 */
public interface IConteudoApoioDAO extends IGenericCadSauDAO<ConteudoApoio>{

    /**
     * Persiste a associacao Conteudo Apoio a um CasoSau informada
     * @param conteudoApoioCasoSau
     * @throws DataException 
     */
    void associa(ConteudoApoioCasoSau conteudoApoioCasoSau) throws DataException;
    
    /**
     * Persiste a lista de ConteudoApoioCasoSau informada
     * @param conteudoApoioCasoSauList
     * @throws DataException 
     */
    void associa(List<ConteudoApoioCasoSau> conteudoApoioCasoSauList) throws DataException;
    
    /**
     * Remove associacao de ContedoApoio com Caso
     * @param conteudoApoioCasoSau
     * @throws DataException 
     */
    void desassocia(ConteudoApoioCasoSau conteudoApoioCasoSau ) throws DataException;
    
    /**
     * Remove associacao de uma lista de ContedoApoio com Caso
     * @param conteudoApoioCasoSauList
     * @throws DataException 
     */
    void desassocia(List<ConteudoApoioCasoSau> conteudoApoioCasoSauList) throws DataException;
    
    /**
     * Busca 
     * @param conteudoApoio
     * @return
     * @throws DataException 
     */
    List<ConteudoApoio> buscaConteudoApoio(ConteudoApoio conteudoApoio) throws DataException ;

    
    /**
     * Busca todas as associacoes por ConteudoApoio ou CasoSau
     * @param conteudoApoio
     * @param casoSau
     * @return
     * @throws DataException 
     */
    List<ConteudoApoioCasoSau> buscaAssociacaoByConteudoApoioOuCasoSau(ConteudoApoio conteudoApoio, CasoSau casoSau) throws DataException;
}
