package br.com.callink.cad.sau.dao;

import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.Causa;
import br.com.callink.cad.sau.pojo.Evento;
import br.com.callink.cad.sau.pojo.EventoCausa;

import java.util.List;

/**
 * 
 * @author Rogério Moreira [rogeriom@swb.com.br]
 *
 */
public interface IEventoCausaDAO extends IGenericCadSauDAO<EventoCausa> {

    /**
     * 
     * @param evento
     * @return
     * @throws DataException 
     */
    Causa findCausaFinalizaAutomaticaByEvento(Evento evento) throws DataException;
    
    /**
     * 
     * @param evento
     * @param causa
     * @return
     * @throws DataException 
     */
    List<EventoCausa> findByEventoCausa(Evento evento, Causa causa) throws DataException;
    
    /**
     * 
     * @param evento
     * @return
     * @throws DataException 
     */
    List<EventoCausa> findFinalizacaoAutomaticaByEvento(Evento evento) throws DataException;

    /**
     * 
     * @param evento
     * @throws ServiceException 
     */
    void removeEvento(Evento evento) throws DataException;
}
