package br.com.callink.cad.sau.dao;

import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.Assunto;
import br.com.callink.cad.sau.pojo.Evento;

import java.util.List;

/**
 * 
 * @author ednaldo [ednaldo@swb.com.br]
 *
 */
public interface IEventoDAO extends IGenericCadSauDAO<Evento> {

    /**
     * Busca eventos pelo Assunto
     * @param assunto
     * @return
     * @throws DataException
     */
    List<Evento> findByAssunto(Assunto assunto) throws DataException;

    /**
     * Busca Eventos vincalados aos Assuntos informados
     * @param assuntolist
     * @return
     * @throws DataException
     */
    List<Evento> findByAssuntoList(List<Assunto> assuntolist)
            throws DataException;

    /**
     * Busca todos os Eventos pelo Assunto e pelo nome do Evento
     * @param assunto
     * @param evento
     * @return
     * @throws DataException 
     */
    List<Evento> findByAssuntoAndEvento(Assunto assunto, Evento evento) throws DataException;
}
