package br.com.callink.cad.sau.dao;

import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.EvolucaoAtendimento;

import java.util.Date;
import java.util.List;

/**
 *
 * @author brunomt
 */
public interface IEvolucaoAtendimentoDAO extends IGenericCadSauDAO<EvolucaoAtendimento> {
    /**
     * Remove tudo que foi gerado para o dia corrente.
     * @throws DataException 
     */
    void removeEvolucaoAtendimento() throws DataException;
    
    /**
     * Busca todas as evoluçõesAtendimento para o período informado.
     * @param dataInicio
     * @param dataFinal
     * @return
     * @throws DataException 
     */
    List<EvolucaoAtendimento> buscaEvolucaoAtendimento(Date dataInicio, Date dataFinal) throws DataException;
}
