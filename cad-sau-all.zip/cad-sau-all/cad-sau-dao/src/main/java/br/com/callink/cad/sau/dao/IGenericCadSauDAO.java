
package br.com.callink.cad.sau.dao;

import java.util.Date;
import java.util.List;

import br.com.callink.cad.dao.IGenericCadDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.pojo.entity.IEntity;


/**
 * 
 * @author ednaldo [ednaldo@swb.com.br]
 *
 * @param <T>
 */
@SuppressWarnings("rawtypes")
public interface IGenericCadSauDAO <T extends IEntity> extends IGenericCadDAO<T> {
	
	/**
	 * Retorna a data atual do banco de dados.
	 * @return @link{Date}
	 * @throws DataException
	 */
    Date getDataBanco() throws DataException;

    /**
     * Retorna todos os registros ativos na base de dados.
     * @param order
     * @return
     * @throws DataException 
     */
    List<T> findAtivos(String order) throws DataException;
    
    /**
     * Retorna todos os registros ativos na base de dados.
     * @param order
     * @return
     * @throws DataException 
     */
    List<T> findAtivos() throws DataException;
    
     /**
     * Busca por exemplo e ordena pelo campo enviado.
     * @param t
     * @param order
     * @return
     * @throws DataException 
     */
    List<T> findByExample(T t, String order) throws DataException;

    /**
     * Busca todos os dados ordenando pelo campo
     * @param order
     * @return
     * @throws DataException
     */
	List<T> findAll(String order) throws DataException;

	/**
	 * busca o objeto pelo Id em parametro
	 */
	T findByPk(Object id) throws DataException;
	
}
