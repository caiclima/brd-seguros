package br.com.callink.cad.sau.dao;

import br.com.callink.cad.sau.pojo.Juncao;

public interface IJuncaoDAO extends IGenericCadSauDAO<Juncao>  {

}
