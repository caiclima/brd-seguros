package br.com.callink.cad.sau.dao;

import java.util.List;

import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.Questao;
import br.com.callink.cad.sau.pojo.Questionario;

/**
 * 
 * @author ednaldo [ednaldo@swb.com.br]
 *
 */
public interface IQuestaoDAO extends IGenericCadSauDAO<Questao> {

    /**
     * Busca todas as questos de um Formulario
     * @param questionario
     * @return
     * @throws DataException
     */
    List<Questao> findAllQuestaoByQuestionario(Questionario questionario)
            throws DataException;
}
