package br.com.callink.cad.sau.dao;

import br.com.callink.cad.sau.pojo.Questionario;

/**
 * 
 * @author ednaldo [ednaldo@swb.com.br]
 *
 */
public interface IQuestionarioDAO extends IGenericCadSauDAO<Questionario>{

}
