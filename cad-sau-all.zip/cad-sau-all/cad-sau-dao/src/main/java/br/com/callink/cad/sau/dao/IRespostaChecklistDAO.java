package br.com.callink.cad.sau.dao;

import java.util.List;

import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.RespostaChecklist;
import br.com.callink.cad.sau.pojo.ResultadoChecklist;

public interface IRespostaChecklistDAO extends IGenericCadSauDAO<RespostaChecklist>{
    
    List<RespostaChecklist> respostasByResultadoChecklist(ResultadoChecklist resultadoChecklist) throws DataException;
}
