package br.com.callink.cad.sau.dao;

import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.Questao;
import br.com.callink.cad.sau.pojo.Resposta;
import br.com.callink.cad.sau.pojo.ResultadoQuestionario;

import java.util.List;

/**
 * 
 * @author ednaldo [ednaldo@swb.com.br]
 *
 */
public interface IRespostaDAO extends IGenericCadSauDAO<Resposta>{

    
    boolean questaoEditavel(Questao questao) throws DataException;
    
    List<Resposta> respostasByResultadoQuestionario(ResultadoQuestionario resultadoQuestionario) throws DataException;
}
