package br.com.callink.cad.sau.dao;

import java.util.List;

import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.pojo.Evento;
import br.com.callink.cad.sau.pojo.ResultadoChecklist;

public interface IResultadoChecklistDAO extends IGenericCadSauDAO<ResultadoChecklist> {

	List<ResultadoChecklist> buscaResultadoPorAgenteCasoSau(CasoSau casoSau,Evento evento, Acao acao) throws DataException;

}
