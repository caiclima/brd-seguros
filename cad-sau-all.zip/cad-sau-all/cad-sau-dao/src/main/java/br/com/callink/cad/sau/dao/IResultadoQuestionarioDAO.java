package br.com.callink.cad.sau.dao;

import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.ResultadoQuestionario;

import java.util.List;

/**
 * 
 * @author ednaldo [ednaldo@swb.com.br]
 *
 */
public interface IResultadoQuestionarioDAO extends IGenericCadSauDAO<ResultadoQuestionario> {

    List<Object[]> questionariosRespondidos(Integer idExterno) throws DataException;
}
