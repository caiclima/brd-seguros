package br.com.callink.cad.sau.dao;

import br.com.callink.cad.sau.pojo.TipoManifestacao;

/**
 * 
 * @author ednaldo [ednaldo@swb.com.br]
 *
 */
public interface ITipoManifestacaoDAO extends IGenericCadSauDAO<TipoManifestacao>{

}
