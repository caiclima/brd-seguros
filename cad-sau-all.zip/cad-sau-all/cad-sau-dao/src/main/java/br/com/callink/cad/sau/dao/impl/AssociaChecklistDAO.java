package br.com.callink.cad.sau.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.Query;

import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.sau.dao.IAssociaChecklistDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.AssociaChecklist;
import br.com.callink.cad.sau.pojo.Assunto;
import br.com.callink.cad.sau.pojo.Checklist;
import br.com.callink.cad.sau.pojo.Evento;

public class AssociaChecklistDAO extends GenericCadSauDAO<AssociaChecklist> implements IAssociaChecklistDAO {

	private static final long serialVersionUID = 4848294757430232970L;

	public AssociaChecklistDAO() {
		super(AssociaChecklist.class);
	}
	
    @Override
    public Checklist getChecklist(Evento evento, Acao acao) throws DataException {
    	Checklist result = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		int index = 0;
		
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Checklist.getSqlCamposChecklist())
				.append(FROM)
				.append(AssociaChecklist.getSqlFromAssociaChecklist())
				.append(LEFT_JOIN).append(Checklist.getSqlFromChecklist())
				.append(" ON AssociaChecklist.ID_CHECKLIST = Checklist.ID_CHECKLIST ")
				.append(WHERE);
			
				if(evento == null || evento.getIdEvento()==null){
					select.append(" AssociaChecklist.ID_EVENTO is null ");
				}else{
					select.append(" AssociaChecklist.ID_EVENTO = ? ");
				}
				select.append(" AND AssociaChecklist.ID_ACAO = ? AND Checklist.FLAG_ENABLED = 1 ");
			
			stmt = getPreparedStatement(select.toString());
			
			if(evento!= null && evento.getIdEvento()!= null){
				stmt.setInt(++index, evento.getIdEvento());
			}
			stmt.setInt(++index, acao.getIdAcao());
			stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null && resultSet.next()) {
				result = Checklist.getChecklistByResultSet(resultSet);
			}
		} catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		return result;
    }

    @Override
    public List<Evento> getEventosByChecklist(Checklist checklist) throws DataException {
    	List<Evento> eventos = new ArrayList<Evento>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Evento.getSqlEvento())
				.append(", ")
				.append(Assunto.getSqlAssunto())
				.append(FROM)
				.append(AssociaChecklist.getSqlFromAssociaChecklist())
				.append(LEFT_JOIN).append(Evento.getSqlFromEvento())
				.append(" ON AssociaChecklist.ID_EVENTO = Evento.ID_EVENTO ")
				.append(INNER_JOIN).append(Assunto.getSqlFromAssunto())
				.append(" ON Evento.ID_ASSUNTO = Assunto.ID_ASSUNTO ")
				.append(WHERE)
				.append(" AssociaChecklist.ID_CHECKLIST = ? ");

			stmt = getPreparedStatement(select.toString());
			
			stmt.setInt(1, checklist.getIdChecklist());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					Evento evento = Evento.getEventoByResultSet(resultSet);
					evento.setAssunto(Assunto.getAssuntoByResultSet(resultSet));
					eventos.add(evento);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return eventos;
    }

    @Override
    public List<AssociaChecklist> buscaAssociacaoByListEvento(List<Evento> eventos) throws DataException {
    	List<AssociaChecklist> associaChecklists = new ArrayList<AssociaChecklist>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(AssociaChecklist.getSqlCamposAssociaChecklist())
				.append(", ")
				.append(Checklist.getSqlCamposChecklist())
				.append(", ")
				.append(Evento.getSqlEvento())
				.append(FROM)
				.append(AssociaChecklist.getSqlFromAssociaChecklist())
				.append(LEFT_JOIN).append(Checklist.getSqlFromChecklist())
          	  	.append(" ON AssociaChecklist.ID_CHECKLIST = Checklist.ID_CHECKLIST ")
          	  	.append(LEFT_JOIN).append(Evento.getSqlFromEvento())
          	  	.append(" ON AssociaChecklist.ID_EVENTO = Evento.ID_EVENTO ")
          	  	.append(WHERE);
			
			StringBuilder eventoIn = new StringBuilder();
            for (int i = 0; i < eventos.size(); i++) {
            	if (i != 0) {
            		eventoIn.append(", ");
            	}
            	eventoIn.append(eventos.get(i).getIdEvento());
            }
            
            select.append(String.format(" AssociaChecklist.ID_EVENTO in (%s) ", eventoIn.toString()));
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					AssociaChecklist associaChecklist = AssociaChecklist.getAssociaChecklistByResultSet(resultSet);
					associaChecklist.setChecklist(Checklist.getChecklistByResultSet(resultSet));
					associaChecklist.setEvento(Evento.getEventoByResultSet(resultSet));
					associaChecklists.add(associaChecklist);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return associaChecklists;
    }

    @Override
    public List<AssociaChecklist> buscaAssociacaoPorEventoAcao(Evento evento , Acao acao, Checklist checklist) throws DataException {
    	List<AssociaChecklist> associaChecklists = new ArrayList<AssociaChecklist>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		
    	try {
    		StringBuilder sql = new StringBuilder()
			.append(SELECT)
			.append(AssociaChecklist.getSqlCamposAssociaChecklist())
			.append(FROM)
			.append(AssociaChecklist.getSqlFromAssociaChecklist())
			.append(WHERE)
	 		.append(" AssociaChecklist.ID_ACAO = ? ");
		
			if(checklist != null && checklist.getIdChecklist() != null) {
				sql.append(" and AssociaChecklist.ID_CHECKLIST <> ? ");
			}
		 
			if(evento != null && evento.getIdEvento()!= null){
				sql.append(" AND AssociaChecklist.ID_EVENTO = ? ");
			}else{
				sql.append(" AND AssociaChecklist.ID_EVENTO is null ");
			}
			
			stmt = getPreparedStatement(sql.toString());
			
			int cont = 1;
			
			stmt.setInt(cont, acao.getIdAcao());
			
			if(checklist != null && checklist.getIdChecklist() != null) {
				cont++;
				stmt.setInt(cont, checklist.getIdChecklist());
			}
			
			if(evento != null && evento.getIdEvento()!= null) {
				cont++;
				stmt.setInt(cont, evento.getIdEvento());
			}
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					AssociaChecklist associaChecklist = AssociaChecklist.getAssociaChecklistByResultSet(resultSet);
					associaChecklists.add(associaChecklist);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return associaChecklists;
    }
    
    @Override
    public Acao findAcaoByChecklist(Checklist checklist) throws DataException{
    	Acao result = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT).append(" TOP 1 ")
				.append(Acao.getSqlCamposAcao())
				.append(FROM)
				.append(AssociaChecklist.getSqlFromAssociaChecklist())
				.append(INNER_JOIN).append(Acao.getSqlFromAcao())
				.append(" ON AssociaChecklist.ID_ACAO = Acao.ID_ACAO ")
				.append(WHERE)
				.append(" AssociaChecklist.ID_CHECKLIST = ? ")
				.append(" ORDER BY AssociaChecklist.ID_ASSOCIA_CHECKLIST DESC ");
			
			stmt = getPreparedStatement(select.toString());
			stmt.setInt(1, checklist.getIdChecklist());
			stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null && resultSet.next()) {
				result = Acao.getAcaoByResultSet(resultSet);
			}
		} catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		return result;
	}
    
    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void deletaAssociacoes(Checklist checklist) throws DataException {
        try {
            Query query = getEntityManager().createNativeQuery(" delete from tb_associa_checklist where id_checklist = :idChecklist ");
            query.setParameter("idChecklist", checklist.getIdChecklist());
            query.executeUpdate();
        } catch (Exception ex) {
            throw new DataException(ex);
        }
    }
    
    @Override
	public AssociaChecklist findByPk(Object id) throws DataException {
    	AssociaChecklist result = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(AssociaChecklist.getSqlCamposAssociaChecklist())
				.append(", ")
				.append(Checklist.getSqlCamposChecklist())
				.append(", ")
				.append(Evento.getSqlEvento())
				.append(", ")
				.append(Acao.getSqlCamposAcao())
				.append(FROM)
				.append(AssociaChecklist.getSqlFromAssociaChecklist())
				.append(INNER_JOIN).append(Checklist.getSqlFromChecklist())
				.append(" ON AssociaChecklist.ID_CHECKLIST = Checklist.ID_CHECKLIST ")
				.append(INNER_JOIN).append(Evento.getSqlFromEvento())
				.append(" ON AssociaChecklist.ID_EVENTO = Evento.ID_EVENTO ")
				.append(INNER_JOIN).append(Acao.getSqlFromAcao())
				.append(" ON AssociaChecklist.ID_ACAO = Acao.ID_ACAO ")
				.append(" WHERE AssociaChecklist.ID_ASSOCIA_CHECKLIST = ? ");
			
			stmt = getPreparedStatement(select.toString());
			
			AssociaChecklist associaChecklist = (AssociaChecklist) id;
			
			stmt.setInt(1, associaChecklist.getIdAssociaChecklist());
			
			stmt.execute();
			
			resultSet = stmt.getResultSet();
			if (resultSet != null && resultSet.next()) {
				result = AssociaChecklist.getAssociaChecklistByResultSet(resultSet);
				result.setChecklist(Checklist.getChecklistByResultSet(resultSet));
				result.setEvento(Evento.getEventoByResultSet(resultSet));
				result.setAcao(Acao.getAcaoByResultSet(resultSet));
			}
		} catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		return result;
	}
	
	@Override
	public List<AssociaChecklist> findByExample(AssociaChecklist example) throws DataException {
		return findByExample(example, null);
	}
	
	@Override
	public List<AssociaChecklist> findByExample(AssociaChecklist example, String order) throws DataException {
		List<AssociaChecklist> associaChecklists = new ArrayList<AssociaChecklist>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		int index =0;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(AssociaChecklist.getSqlCamposAssociaChecklist())
				.append(", ")
				.append(Checklist.getSqlCamposChecklist())
				.append(", ")
				.append(Evento.getSqlEvento())
				.append(FROM)
				.append(AssociaChecklist.getSqlFromAssociaChecklist());
			
			boolean checklistIsNull = example.getChecklist() == null || example.getChecklist().getIdChecklist() == null;
            boolean eventoIsNull = example.getEvento() == null || example.getEvento().getIdEvento() == null;

            if (!checklistIsNull) {
            	select.append(INNER_JOIN);
            } else {
            	select.append(LEFT_JOIN);
            }
            select.append(Checklist.getSqlFromChecklist())
            	  .append(" ON AssociaChecklist.ID_CHECKLIST = Checklist.ID_CHECKLIST ");
            
            if (!eventoIsNull) {
            	select.append(INNER_JOIN);
            } else {
            	select.append(LEFT_JOIN);
            }
            select.append(Evento.getSqlFromEvento())
            	  .append(" ON AssociaChecklist.ID_EVENTO = Evento.ID_EVENTO ");
            
            select.append(WHERE_1_1);
            
            if(example!= null){
            
				if (example.getIdAssociaChecklist() != null) {
					select.append(" AND AssociaChecklist.ID_ASSOCIA_CHECKLIST = ? ");
				}
				if (!checklistIsNull) {
					select.append(" AND AssociaChecklist.ID_CHECKLIST = ? ");
				}
				if (!eventoIsNull) {
					select.append(" AND AssociaChecklist.ID_EVENTO = ? ");
				}
				if (example.getAcao() != null && example.getAcao().getIdAcao() != null) {
					select.append(" AND AssociaChecklist.ID_ACAO = ? ");
				}
				if (example.getFlagEnabled() != null) {
					select.append(" AND AssociaChecklist.FLAG_ENABLED = ? ");
				}
            }
            
			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			if(example!= null){
			
				if (example.getIdAssociaChecklist() != null) {
					stmt.setInt(++index, example.getIdAssociaChecklist());
				}
				if (!checklistIsNull) {
					stmt.setInt(++index,example.getChecklist().getIdChecklist()) ;
				}
				if (!eventoIsNull) {
					stmt.setInt(++index, example.getEvento().getIdEvento());
				}
				if (example.getAcao() != null && example.getAcao().getIdAcao() != null) {
					stmt.setInt(++index, example.getAcao().getIdAcao());
				}
				if (example.getFlagEnabled() != null) {
					stmt.setBoolean(++index, example.getFlagEnabled());
				}
			}
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					AssociaChecklist associaChecklist = AssociaChecklist.getAssociaChecklistByResultSet(resultSet);
					associaChecklist.setChecklist(Checklist.getChecklistByResultSet(resultSet));
					associaChecklist.setEvento(Evento.getEventoByResultSet(resultSet));
					associaChecklists.add(associaChecklist);
				}
			}
		} catch (SQLException ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return associaChecklists;
	}
	
	@Override
	public List<AssociaChecklist> findAll() throws DataException {
		return this.findAll(null);
	}
	
	@Override
	public List<AssociaChecklist> findAll(String order) throws DataException {
		List<AssociaChecklist> associaChecklists = new ArrayList<AssociaChecklist>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(AssociaChecklist.getSqlCamposAssociaChecklist())
				.append(", ")
				.append(Checklist.getSqlCamposChecklist())
				.append(", ")
				.append(Evento.getSqlEvento())
				.append(FROM)
				.append(AssociaChecklist.getSqlFromAssociaChecklist())
				.append(LEFT_JOIN).append(Checklist.getSqlFromChecklist())
          	  	.append(" ON AssociaChecklist.ID_CHECKLIST = Checklist.ID_CHECKLIST ")
          	  	.append(LEFT_JOIN).append(Evento.getSqlFromEvento())
          	  	.append(" ON AssociaChecklist.ID_EVENTO = Evento.ID_EVENTO ");
			
			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					AssociaChecklist associaChecklist = AssociaChecklist.getAssociaChecklistByResultSet(resultSet);
					associaChecklist.setChecklist(Checklist.getChecklistByResultSet(resultSet));
					associaChecklist.setEvento(Evento.getEventoByResultSet(resultSet));
					associaChecklists.add(associaChecklist);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return associaChecklists;
	}
	
	@Override
	public List<AssociaChecklist> findAtivos() throws DataException {
		return this.findAtivos(null);
	}
	
	@Override
	public List<AssociaChecklist> findAtivos(String order) throws DataException {
		List<AssociaChecklist> associaChecklists = new ArrayList<AssociaChecklist>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(AssociaChecklist.getSqlCamposAssociaChecklist())
				.append(", ")
				.append(Checklist.getSqlCamposChecklist())
				.append(", ")
				.append(Evento.getSqlEvento())
				.append(FROM)
				.append(AssociaChecklist.getSqlFromAssociaChecklist())
				.append(LEFT_JOIN).append(Checklist.getSqlFromChecklist())
          	  	.append(" ON AssociaChecklist.ID_CHECKLIST = Checklist.ID_CHECKLIST ")
          	  	.append(LEFT_JOIN).append(Evento.getSqlFromEvento())
          	  	.append(" ON AssociaChecklist.ID_EVENTO = Evento.ID_EVENTO ")
          	  	.append(WHERE)
          	  	.append(" AssociaChecklist.FLAG_ENABLED = 1 ");
			
			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					AssociaChecklist associaChecklist = AssociaChecklist.getAssociaChecklistByResultSet(resultSet);
					associaChecklist.setChecklist(Checklist.getChecklistByResultSet(resultSet));
					associaChecklist.setEvento(Evento.getEventoByResultSet(resultSet));
					associaChecklists.add(associaChecklist);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return associaChecklists;
	}
	
}
