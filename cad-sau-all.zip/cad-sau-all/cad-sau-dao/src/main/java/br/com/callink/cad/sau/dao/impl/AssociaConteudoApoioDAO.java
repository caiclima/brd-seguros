/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.sau.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.com.callink.cad.sau.dao.IAssociaConteudoApoioDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.AssociaConteudoApoio;
import br.com.callink.cad.sau.pojo.ConteudoApoio;
import br.com.callink.cad.sau.pojo.Evento;

/**
 *
 * @author Luiz Gustavo F. (luizgf@swb.com.br)
 */
public class AssociaConteudoApoioDAO extends GenericCadSauDAO<AssociaConteudoApoio> implements IAssociaConteudoApoioDAO {

	private static final long serialVersionUID = -1007122433649917789L;

	public AssociaConteudoApoioDAO() {
		super(AssociaConteudoApoio.class);
	}
	
    @Override
    public List<AssociaConteudoApoio> buscaTodosComObjetosPreenchidos(AssociaConteudoApoio associaConteudoApoio) throws DataException {
    	List<AssociaConteudoApoio> associaConteudosApoio = new ArrayList<AssociaConteudoApoio>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		int index=0;
		
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(AssociaConteudoApoio.getSqlCamposAssociaConteudoApoio())
				.append(", ")
				.append(Evento.getSqlEvento())
				.append(", ")
				.append(ConteudoApoio.getSqlCamposConteudoApoio())
				.append(FROM)
				.append(AssociaConteudoApoio.getSqlFromAssociaConteudoApoio())
				.append(INNER_JOIN).append(Evento.getSqlFromEvento())
				.append(" ON AssociaConteudoApoio.ID_EVENTO = Evento.ID_EVENTO ")
				.append(INNER_JOIN).append(ConteudoApoio.getSqlFromConteudoApoio())
				.append(" ON AssociaConteudoApoio.ID_CONTEUDO_APOIO = ConteudoApoio.ID_CONTEUDO_APOIO ")
				.append(WHERE_1_1);
            
			if (associaConteudoApoio != null) {
				if (associaConteudoApoio.getIdAssociaContApoio() != null) {
					select.append(" AND AssociaConteudoApoio.ID_ASSOCIA_CONT_APOIO = ? ");
				}
				if (associaConteudoApoio.getIdAssociaContApoio() == null && associaConteudoApoio.getEvento() != null && associaConteudoApoio.getEvento().getIdEvento() != null) {
					select.append(" AND AssociaConteudoApoio.ID_EVENTO = ? ");
	            }
	            if (associaConteudoApoio.getIdAssociaContApoio() == null && associaConteudoApoio.getConteudoApoio() != null && associaConteudoApoio.getConteudoApoio().getIdConteudoApoio() != null) {
	            	select.append(" AND AssociaConteudoApoio.ID_CONTEUDO_APOIO = ? ");
	            }
			}
			
			stmt = getPreparedStatement(select.toString());
			
			if (associaConteudoApoio != null) {
				if (associaConteudoApoio.getIdAssociaContApoio() != null) {
					stmt.setInt(++index, associaConteudoApoio.getIdAssociaContApoio());
				}
				if (associaConteudoApoio.getIdAssociaContApoio() == null && associaConteudoApoio.getEvento() != null && associaConteudoApoio.getEvento().getIdEvento() != null) {
					stmt.setInt(++index, associaConteudoApoio.getEvento().getIdEvento());
	            }
	            if (associaConteudoApoio.getIdAssociaContApoio() == null && associaConteudoApoio.getConteudoApoio() != null && associaConteudoApoio.getConteudoApoio().getIdConteudoApoio() != null) {
	            	stmt.setInt(++index, associaConteudoApoio.getConteudoApoio().getIdConteudoApoio());
	            }
			}
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					AssociaConteudoApoio result = AssociaConteudoApoio.getAssociaConteudoApoioByResultSet(resultSet);
					result.setEvento(Evento.getEventoByResultSet(resultSet));
					result.setConteudoApoio(ConteudoApoio.getConteudoApoioByResultSet(resultSet));
					associaConteudosApoio.add(result);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return associaConteudosApoio;
    }
    
    @Override
	public AssociaConteudoApoio findByPk(Object id) throws DataException {
    	AssociaConteudoApoio result = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(AssociaConteudoApoio.getSqlCamposAssociaConteudoApoio())
				.append(", ")
				.append(Evento.getSqlEvento())
				.append(", ")
				.append(ConteudoApoio.getSqlCamposConteudoApoio())
				.append(FROM)
				.append(AssociaConteudoApoio.getSqlFromAssociaConteudoApoio())
				.append(INNER_JOIN).append(Evento.getSqlFromEvento())
				.append(" ON AssociaConteudoApoio.ID_EVENTO = Evento.ID_EVENTO ")
				.append(INNER_JOIN).append(ConteudoApoio.getSqlFromConteudoApoio())
				.append(" ON AssociaConteudoApoio.ID_CONTEUDO_APOIO = ConteudoApoio.ID_CONTEUDO_APOIO ")
				.append(" WHERE AssociaConteudoApoio.ID_ASSOCIA_CONT_APOIO = ? ");
			
			stmt = getPreparedStatement(select.toString());
			
			AssociaConteudoApoio associaConteudoApoio = (AssociaConteudoApoio) id;
			
			stmt.setInt(1, associaConteudoApoio.getIdAssociaContApoio());
			
			stmt.execute();
			
			resultSet = stmt.getResultSet();
			if (resultSet != null && resultSet.next()) {
				result = AssociaConteudoApoio.getAssociaConteudoApoioByResultSet(resultSet);
				result.setEvento(Evento.getEventoByResultSet(resultSet));
				result.setConteudoApoio(ConteudoApoio.getConteudoApoioByResultSet(resultSet));
			}
		} catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		return result;
	}
	
	@Override
	public List<AssociaConteudoApoio> findByExample(AssociaConteudoApoio example) throws DataException {
		return findByExample(example, null);
	}
	
	@Override
	public List<AssociaConteudoApoio> findByExample(AssociaConteudoApoio example, String order) throws DataException {
		List<AssociaConteudoApoio> associaConteudosApoio = new ArrayList<AssociaConteudoApoio>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		int index=0;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(AssociaConteudoApoio.getSqlCamposAssociaConteudoApoio())
				.append(FROM)
				.append(AssociaConteudoApoio.getSqlFromAssociaConteudoApoio())
				.append(WHERE_1_1);
            
			if (example.getIdAssociaContApoio() != null) {
				select.append(" AND AssociaConteudoApoio.ID_ASSOCIA_CONT_APOIO = ? ");
			}
			if (example.getEvento() != null && example.getEvento().getIdEvento() != null) {
				select.append(" AND AssociaConteudoApoio.ID_EVENTO = ? ");
			}
			if (example.getConteudoApoio() != null && example.getConteudoApoio().getIdConteudoApoio() != null) {
				select.append(" AND AssociaConteudoApoio.ID_CONTEUDO_APOIO = ? ");
			}
			
			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());

			if (example.getIdAssociaContApoio() != null) {
				stmt.setInt(++index, example.getIdAssociaContApoio());
			}
			if (example.getEvento() != null && example.getEvento().getIdEvento() != null) {
				stmt.setInt(++index, example.getEvento().getIdEvento());
			}
			if (example.getConteudoApoio() != null && example.getConteudoApoio().getIdConteudoApoio() != null) {
				stmt.setInt(++index, example.getConteudoApoio().getIdConteudoApoio());
			}
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					AssociaConteudoApoio associaConteudoApoio = AssociaConteudoApoio.getAssociaConteudoApoioByResultSet(resultSet);
					associaConteudosApoio.add(associaConteudoApoio);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return associaConteudosApoio;
	}
	
	@Override
	public List<AssociaConteudoApoio> findAll() throws DataException {
		return findAll(null);
	}
	
	@Override
	public List<AssociaConteudoApoio> findAll(String order) throws DataException {
		List<AssociaConteudoApoio> associaConteudosApoio = new ArrayList<AssociaConteudoApoio>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(AssociaConteudoApoio.getSqlCamposAssociaConteudoApoio())
				.append(FROM)
				.append(AssociaConteudoApoio.getSqlFromAssociaConteudoApoio())
				.append(WHERE_1_1);
	        
			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					AssociaConteudoApoio associaConteudoApoio = AssociaConteudoApoio.getAssociaConteudoApoioByResultSet(resultSet);
					associaConteudosApoio.add(associaConteudoApoio);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return associaConteudosApoio;
	}
	
	@Override
	public List<AssociaConteudoApoio> findAtivos() throws DataException {
		return findAtivos(null);
	}
	
	@Override
	public List<AssociaConteudoApoio> findAtivos(String order) throws DataException {
		throw new DataException("Entidade não possui coluna flag_ativo!");
	}
    
}
