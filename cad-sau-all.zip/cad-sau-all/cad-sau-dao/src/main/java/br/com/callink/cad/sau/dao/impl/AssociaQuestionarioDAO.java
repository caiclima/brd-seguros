package br.com.callink.cad.sau.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.Query;

import br.com.callink.cad.sau.dao.IAssociaQuestionarioDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.AssociaQuestionario;
import br.com.callink.cad.sau.pojo.Assunto;
import br.com.callink.cad.sau.pojo.Evento;
import br.com.callink.cad.sau.pojo.Questionario;

public class AssociaQuestionarioDAO extends GenericCadSauDAO<AssociaQuestionario> implements IAssociaQuestionarioDAO {

	private static final long serialVersionUID = -2268092144903044605L;

	public AssociaQuestionarioDAO() {
		super(AssociaQuestionario.class);
	}
	
    @Override
    public Questionario getQuestionario(Evento evento) throws DataException {
    	Questionario result = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Questionario.getSqlCamposQuestionario())
				.append(FROM)
				.append(AssociaQuestionario.getSqlFromAssociaQuestionario())
				.append(LEFT_JOIN).append(Questionario.getSqlFromQuestionario())
				.append(" ON AssociaQuestionario.ID_QUESTIONARIO = Questionario.ID_QUESTIONARIO ")
				.append(WHERE)
				.append(" AssociaQuestionario.ID_EVENTO = ? ")
				.append(" AND Questionario.flag_ativo = 1 ");
			
			stmt = getPreparedStatement(select.toString());
			stmt.setInt(1, evento.getIdEvento());
			stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null && resultSet.next()) {
				result = Questionario.getQuestionarioByResultSet(resultSet);
			}
		} catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		return result;
    }

    @Override
    public List<Evento> getEventosByQuestionario(Questionario questionario) throws DataException {
    	List<Evento> eventos = new ArrayList<Evento>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Evento.getSqlEvento())
				.append(", ")
				.append(Assunto.getSqlAssunto())
				.append(FROM)
				.append(AssociaQuestionario.getSqlFromAssociaQuestionario())
				.append(LEFT_JOIN).append(Evento.getSqlFromEvento())
				.append(" ON AssociaQuestionario.ID_EVENTO = Evento.ID_EVENTO ")
				.append(INNER_JOIN).append(Assunto.getSqlFromAssunto())
				.append(" ON Evento.ID_ASSUNTO = Assunto.ID_ASSUNTO ")
				.append(WHERE)
				.append(" AssociaQuestionario.ID_QUESTIONARIO = ? ");

			stmt = getPreparedStatement(select.toString());
			
			stmt.setInt(1, questionario.getIdQuestionario());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					Evento evento = Evento.getEventoByResultSet(resultSet);
					evento.setAssunto(Assunto.getAssuntoByResultSet(resultSet));
					eventos.add(evento);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return eventos;
    }

    @Override
    public List<AssociaQuestionario> buscaAssociacaoByListEvento(List<Evento> eventos) throws DataException {
    	List<AssociaQuestionario> associaQuestionarios = new ArrayList<AssociaQuestionario>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(AssociaQuestionario.getSqlCamposAssociaQuestionario())
				.append(", ")
				.append(Questionario.getSqlCamposQuestionario())
				.append(", ")
				.append(Evento.getSqlEvento())
				.append(FROM)
				.append(AssociaQuestionario.getSqlFromAssociaQuestionario())
				.append(LEFT_JOIN).append(Questionario.getSqlFromQuestionario())
          	  	.append(" ON AssociaQuestionario.ID_QUESTIONARIO = Questionario.ID_QUESTIONARIO ")
          	  	.append(LEFT_JOIN).append(Evento.getSqlFromEvento())
          	  	.append(" ON AssociaQuestionario.ID_EVENTO = Evento.ID_EVENTO ")
          	  	.append(WHERE);
			
			StringBuilder eventoIn = new StringBuilder();
            for (int i = 0; i < eventos.size(); i++) {
            	if (i != 0) {
            		eventoIn.append(", ");
            	}
            	eventoIn.append(eventos.get(i).getIdEvento());
            }
            
            select.append(String.format(" AssociaQuestionario.ID_EVENTO in (%s) ", eventoIn.toString()));
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					AssociaQuestionario associaQuestionario = AssociaQuestionario.getAssociaQuestionarioByResultSet(resultSet);
					associaQuestionario.setQuestionario(Questionario.getQuestionarioByResultSet(resultSet));
					associaQuestionario.setEvento(Evento.getEventoByResultSet(resultSet));
					associaQuestionarios.add(associaQuestionario);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return associaQuestionarios;
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void deletaAssociacoes(Questionario questionario) throws DataException {
    	try {
            Query query = getEntityManager().createNativeQuery(" delete from tb_associa_questionario where id_questionario = :idQuestionario ");
            query.setParameter("idQuestionario", questionario.getIdQuestionario());
            query.executeUpdate();
        } catch (Exception ex) {
            throw new DataException(ex);
        }
    }
    
    @Override
	public AssociaQuestionario findByPk(Object id) throws DataException {
    	AssociaQuestionario result = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(AssociaQuestionario.getSqlCamposAssociaQuestionario())
				.append(", ")
				.append(Questionario.getSqlCamposQuestionario())
				.append(", ")
				.append(Evento.getSqlEvento())
				.append(FROM)
				.append(AssociaQuestionario.getSqlFromAssociaQuestionario())
				.append(INNER_JOIN).append(Questionario.getSqlFromQuestionario())
				.append(" ON AssociaQuestionario.ID_QUESTIONARIO = Questionario.ID_QUESTIONARIO ")
				.append(INNER_JOIN).append(Evento.getSqlFromEvento())
				.append(" ON AssociaQuestionario.ID_EVENTO = Evento.ID_EVENTO ")
				.append(" WHERE AssociaQuestionario.ID_ASSOCIA_QUESTIONARIO = ? ");
			
			stmt = getPreparedStatement(select.toString());
			
			AssociaQuestionario associaQuestionario = (AssociaQuestionario) id;
			
			stmt.setInt(1, associaQuestionario.getIdAssociaQuestionario());
			
			stmt.execute();
			
			resultSet = stmt.getResultSet();
			if (resultSet != null && resultSet.next()) {
				result = AssociaQuestionario.getAssociaQuestionarioByResultSet(resultSet);
				result.setQuestionario(Questionario.getQuestionarioByResultSet(resultSet));
				result.setEvento(Evento.getEventoByResultSet(resultSet));
			}
		} catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		return result;
	}
	
	@Override
	public List<AssociaQuestionario> findByExample(AssociaQuestionario example) throws DataException {
		return findByExample(example, null);
	}
	
	@Override
	public List<AssociaQuestionario> findByExample(AssociaQuestionario example, String order) throws DataException {
		List<AssociaQuestionario> associaQuestionarios = new ArrayList<AssociaQuestionario>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		int index =0;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(AssociaQuestionario.getSqlCamposAssociaQuestionario())
				.append(", ")
				.append(Questionario.getSqlCamposQuestionario())
				.append(", ")
				.append(Evento.getSqlEvento())
				.append(FROM)
				.append(AssociaQuestionario.getSqlFromAssociaQuestionario());
			
			boolean questionarioIsNull = example.getQuestionario() == null || example.getQuestionario().getIdQuestionario() == null;
            boolean eventoIsNull = example.getEvento() == null || example.getEvento().getIdEvento() == null;

            if (!questionarioIsNull) {
            	select.append(INNER_JOIN);
            } else {
            	select.append(LEFT_JOIN);
            }
            select.append(Questionario.getSqlFromQuestionario())
            	  .append(" ON AssociaQuestionario.ID_QUESTIONARIO = Questionario.ID_QUESTIONARIO ");
            
            if (!eventoIsNull) {
            	select.append(INNER_JOIN);
            } else {
            	select.append(LEFT_JOIN);
            }
            select.append(Evento.getSqlFromEvento())
            	  .append(" ON AssociaQuestionario.ID_EVENTO = Evento.ID_EVENTO ");
            
            select.append(WHERE_1_1);
            
            if(example!= null){
            
				if (example.getIdAssociaQuestionario() != null) {
					select.append(" AND AssociaQuestionario.ID_ASSOCIA_QUESTIONARIO = ? ");
				}
				if (example.getQuestionario() != null && example.getQuestionario().getIdQuestionario() != null) {
					select.append(" AND AssociaQuestionario.ID_QUESTIONARIO = ? ");
				}
				if (example.getEvento() != null && example.getEvento().getIdEvento() != null) {
					select.append(" AND AssociaQuestionario.ID_EVENTO = ? ");
				}
				if (example.getFlagCheckList() != null) {
					select.append(" AND AssociaQuestionario.FLAG_CHECK_LIST = ? ");
				}
            }
            
			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			if(example!= null){
				if (example.getIdAssociaQuestionario() != null) {
					stmt.setInt(++index, example.getIdAssociaQuestionario());
				}
				if (example.getQuestionario() != null && example.getQuestionario().getIdQuestionario() != null) {
					stmt.setInt(++index, example.getQuestionario().getIdQuestionario());
				}
				if (example.getEvento() != null && example.getEvento().getIdEvento() != null) {
					stmt.setInt(++index, example.getEvento().getIdEvento());
				}
				if (example.getFlagCheckList() != null) {
					stmt.setBoolean(++index, example.getFlagCheckList());
				}
			}
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					AssociaQuestionario associaQuestionario = AssociaQuestionario.getAssociaQuestionarioByResultSet(resultSet);
					associaQuestionario.setEvento(Evento.getEventoByResultSet(resultSet));
					associaQuestionario.setQuestionario(Questionario.getQuestionarioByResultSet(resultSet));
					associaQuestionarios.add(associaQuestionario);
				}
			}
		} catch (SQLException ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return associaQuestionarios;
	}
	
	@Override
	public List<AssociaQuestionario> findAll() throws DataException {
		return findAll(null);
	}
	
	@Override
	public List<AssociaQuestionario> findAll(String order) throws DataException {
		List<AssociaQuestionario> associaQuestionarios = new ArrayList<AssociaQuestionario>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(AssociaQuestionario.getSqlCamposAssociaQuestionario())
				.append(", ")
				.append(Evento.getSqlEvento())
				.append(", ")
				.append(Questionario.getSqlCamposQuestionario())
				.append(FROM)
				.append(AssociaQuestionario.getSqlFromAssociaQuestionario())
          	  	.append(LEFT_JOIN).append(Evento.getSqlFromEvento())
          	  	.append(" ON AssociaQuestionario.ID_EVENTO = Evento.ID_EVENTO ")
          	  	.append(LEFT_JOIN).append(Questionario.getSqlFromQuestionario())
          	  	.append(" ON AssociaQuestionario.ID_QUESTIONARIO = Questionario.ID_QUESTIONARIO ");
			
			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					AssociaQuestionario associaQuestionario = AssociaQuestionario.getAssociaQuestionarioByResultSet(resultSet);
					associaQuestionario.setEvento(Evento.getEventoByResultSet(resultSet));
					associaQuestionario.setQuestionario(Questionario.getQuestionarioByResultSet(resultSet));
					associaQuestionarios.add(associaQuestionario);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return associaQuestionarios;
	}
	
	@Override
	public List<AssociaQuestionario> findAtivos() throws DataException {
		return findAtivos(null);
	}
	
	@Override
	public List<AssociaQuestionario> findAtivos(String order) throws DataException {
		throw new DataException("Entidade não possui coluna flag_ativo!");
	}
    
}
