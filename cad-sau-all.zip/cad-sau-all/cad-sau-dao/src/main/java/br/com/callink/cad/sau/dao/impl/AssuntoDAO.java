package br.com.callink.cad.sau.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import br.com.callink.cad.pojo.Util.DateUtil;
import br.com.callink.cad.sau.dao.IAssuntoDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.Assunto;

/**
 * 
 * @author brunomt [brunoam@swb.com.br]
 *
 */
public class AssuntoDAO extends GenericCadSauDAO<Assunto> implements IAssuntoDAO {

	private static final long serialVersionUID = -8354071685473986439L;

	public AssuntoDAO() {
		super(Assunto.class);
	}
	
	@Override
	public void delete(Assunto assunto) throws DataException {
		try {
			super.delete(assunto);
		} catch (DataException e) {
			throw new DataException("Assunto nao pode ser removido. Pode ter dependencia. Tente inativa-lo!", e);
		}
	}
	
	@Override
	public Assunto findByPk(Object id) throws DataException {
		Assunto result = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Assunto.getSqlAssunto())
				.append(FROM)
				.append(Assunto.getSqlFromAssunto())
				.append(" WHERE Assunto.ID_ASSUNTO = ? ");
			
			stmt = getPreparedStatement(select.toString());
			
			Assunto assunto = (Assunto) id;
			
			stmt.setInt(1, assunto.getIdAssunto());
			
			stmt.execute();
			
			resultSet = stmt.getResultSet();
			if (resultSet != null && resultSet.next()) {
				result = Assunto.getAssuntoByResultSet(resultSet);
			}
		} catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		return result;
	}
	
	@Override
	public List<Assunto> findByExample(Assunto example) throws DataException {
		return findByExample(example, null);
	}
	
	@Override
	public List<Assunto> findByExample(Assunto example, String order) throws DataException {
		List<Assunto> assuntos = new ArrayList<Assunto>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		int index = 0;
		
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Assunto.getSqlAssunto())
				.append(FROM)
				.append(Assunto.getSqlFromAssunto())
				.append(WHERE_1_1);
			
			if(example!= null){
			
				if (example.getIdAssunto() != null) {
					select.append(" AND Assunto.ID_ASSUNTO = ? ");
				}
				if (example.getNome() != null && !example.getNome().isEmpty()) {
					select.append(" AND Assunto.NOME like ? ");
				}
				if (example.getDataCriacao() != null) {
					select.append(" AND Assunto.DATA_CRIACAO BETWEEN ? AND ? ");
				}
				if (example.getFlagAtivo() != null) {
					select.append(" AND Assunto.FLAG_ATIVO = ? ");
				}
			}
			
			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			if(example!= null){
			
				if (example.getIdAssunto() != null) {
					stmt.setInt(++index, example.getIdAssunto());
				}
				if (example.getNome() != null && !example.getNome().isEmpty()) {
					stmt.setString(++index, new StringBuilder(example.getNome()).append("%").toString());
				}
				if (example.getDataCriacao() != null) {
					Date dataInicio = DateUtil.dataInicioDia(example.getDataCriacao());
					Date dataFim = DateUtil.dataFimDia(example.getDataCriacao());
					stmt.setDate(++index, new java.sql.Date(dataInicio.getTime()));
					stmt.setDate(++index, new java.sql.Date(dataFim.getTime()));
				}
				if (example.getFlagAtivo() != null) {
					stmt.setBoolean(++index, example.getFlagAtivo());
				}
			}
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					Assunto assunto = Assunto.getAssuntoByResultSet(resultSet);
					assuntos.add(assunto);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return assuntos;
	}
	
	@Override
	public List<Assunto> findAll() throws DataException {
		return findAll(null);
	}
	
	@Override
	public List<Assunto> findAll(String order) throws DataException {
		List<Assunto> assuntos = new ArrayList<Assunto>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Assunto.getSqlAssunto())
				.append(FROM)
				.append(Assunto.getSqlFromAssunto());
			
			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					Assunto assunto = Assunto.getAssuntoByResultSet(resultSet);
					assuntos.add(assunto);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return assuntos;
	}
	
	@Override
	public List<Assunto> findAtivos() throws DataException {
		return findAtivos(null);
	}
	
	@Override
	public List<Assunto> findAtivos(String order) throws DataException {
		List<Assunto> assuntos = new ArrayList<Assunto>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Assunto.getSqlAssunto())
				.append(FROM)
				.append(Assunto.getSqlFromAssunto())
				.append(WHERE)
				.append(" Assunto.FLAG_ATIVO = 1 ");
			
			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					Assunto assunto = Assunto.getAssuntoByResultSet(resultSet);
					assuntos.add(assunto);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return assuntos;
	}
	
}
