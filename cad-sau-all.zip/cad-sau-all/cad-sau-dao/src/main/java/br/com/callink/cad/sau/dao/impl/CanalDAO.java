package br.com.callink.cad.sau.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import br.com.callink.cad.pojo.Util.DateUtil;
import br.com.callink.cad.sau.dao.ICanalDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.Canal;

public class CanalDAO extends GenericCadSauDAO<Canal> implements ICanalDAO {

	private static final long serialVersionUID = 2428423526247369813L;

	public CanalDAO() {
		super(Canal.class);
	}
	
	@Override
	public Canal findByPk(Object id) throws DataException {
		Canal result = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Canal.getSqlCamposCanal())
				.append(FROM)
				.append(Canal.getSqlFromCanal())
				.append(" WHERE Canal.ID_CANAL = ? ");
			
			stmt = getPreparedStatement(select.toString());
			
			Canal canal = (Canal) id;
			
			stmt.setInt(1, canal.getIdCanal());
			
			stmt.execute();
			
			resultSet = stmt.getResultSet();
			if (resultSet != null && resultSet.next()) {
				result = Canal.getCanalByResultSet(resultSet);
			}
		} catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		return result;
	}
	
	@Override
	public List<Canal> findByExample(Canal example) throws DataException {
		return findByExample(example, null);
	}
	
	@Override
	public List<Canal> findByExample(Canal example, String order) throws DataException {
		List<Canal> canais = new ArrayList<Canal>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		int index=0;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Canal.getSqlCamposCanal())
				.append(FROM)
				.append(Canal.getSqlFromCanal())
				.append(WHERE_1_1);
			
			if(example!= null){
			
				if (example.getIdCanal() != null) {
					select.append(" AND Canal.ID_CANAL = ? ");
				}
				if (example.getNome() != null && !example.getNome().isEmpty()) {
					select.append(" AND Canal.NOME like ? ");
				}
				if (example.getDataCriacao() != null) {
					select.append(" AND Canal.DATA_CRIACAO BETWEEN ? AND ? ");
				}
				if (example.getFlagAtivo() != null) {
					select.append(" AND Canal.FLAG_ATIVO = ? ");
				}
				if (example.getFlagCasoManual() != null) {
					select.append(" AND Canal.FLAG_CASO_MANUAL = ? ");
				}
			}
			
			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			if(example!= null){
			
				if (example.getIdCanal() != null) {
					stmt.setInt(++index, example.getIdCanal());
				}
				if (example.getNome() != null && !example.getNome().isEmpty()) {
					stmt.setString(++index, new StringBuilder(example.getNome()).append("%").toString());
				}
				if (example.getDataCriacao() != null) {
					Date dataInicio = DateUtil.dataInicioDia(example.getDataCriacao());
					Date dataFim = DateUtil.dataFimDia(example.getDataCriacao());
					stmt.setDate(++index, new java.sql.Date(dataInicio.getTime()));
					stmt.setDate(++index, new java.sql.Date(dataFim.getTime()));
				}
				if (example.getFlagAtivo() != null) {
					stmt.setBoolean(++index, example.getFlagAtivo());
				}
				if (example.getFlagCasoManual() != null) {
					stmt.setBoolean(++index, example.getFlagCasoManual());
				}
			}
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					Canal canal = Canal.getCanalByResultSet(resultSet);
					canais.add(canal);
				}
			}
		} catch (SQLException ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return canais;
	}
	
	@Override
	public List<Canal> findAll() throws DataException {
		return findAll(null);
	}
	
	@Override
	public List<Canal> findAll(String order) throws DataException {
		List<Canal> canais = new ArrayList<Canal>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Canal.getSqlCamposCanal())
				.append(FROM)
				.append(Canal.getSqlFromCanal());
			
			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					Canal canal = Canal.getCanalByResultSet(resultSet);
					canais.add(canal);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return canais;
	}
	
	@Override
	public List<Canal> findAtivos() throws DataException {
		return findAtivos(null);
	}
	
	@Override
	public List<Canal> findAtivos(String order) throws DataException {
		List<Canal> canais = new ArrayList<Canal>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Canal.getSqlCamposCanal())
				.append(FROM)
				.append(Canal.getSqlFromCanal())
				.append(WHERE)
				.append(" Canal.FLAG_ATIVO = 1 ");
			
			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					Canal canal = Canal.getCanalByResultSet(resultSet);
					canais.add(canal);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return canais;
	}
	
}
