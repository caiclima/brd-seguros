/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.sau.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;

import br.com.callink.cad.pojo.Util.DateUtil;
import br.com.callink.cad.sau.dao.ICasoAbertoCockpitDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.CasoAbertoCockpit;

/**
 *
 * @author Rogerio
 */
public class CasoAbertoCockpitDAO extends GenericCadSauDAO<CasoAbertoCockpit> implements ICasoAbertoCockpitDAO {

	private static final long serialVersionUID = 6361186862962213390L;

	public CasoAbertoCockpitDAO() {
		super(CasoAbertoCockpit.class);
	}
	
    @Override
    public void delete(Date data) throws DataException {
        try {
			Query query = getEntityManager().createNativeQuery(" delete from tb_caso_aberto_cockpit where data_processamento = CAST(:data AS DATE) ");
            query.setParameter("data", data);
            query.executeUpdate();
		} catch (Exception ex) {
			throw new DataException(ex);
		}
    }

    @Override
    public List<CasoAbertoCockpit> casosAbertos() throws DataException {
    	List<CasoAbertoCockpit> casosAbertoCockpit = new ArrayList<CasoAbertoCockpit>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(CasoAbertoCockpit.getSelectSqlCasoAbertoCockpit())
				.append(FROM)
				.append(CasoAbertoCockpit.getSqlFromCasoAbertoCockpit())
				.append(WHERE)
				.append(" CasoAbertoCockpit.DATA_PROCESSAMENTO = CAST( GETDATE() AS DATE) ")
				.append(" AND CasoAbertoCockpit.FLAG_FILA = 0 ");
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					CasoAbertoCockpit casoAbertoCockpit = CasoAbertoCockpit.getCausaByResultSet(resultSet);
					casosAbertoCockpit.add(casoAbertoCockpit);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return casosAbertoCockpit;
    }

    @Override
    public List<CasoAbertoCockpit> casosAbertosFila() throws DataException {
    	List<CasoAbertoCockpit> casosAbertoCockpit = new ArrayList<CasoAbertoCockpit>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(CasoAbertoCockpit.getSelectSqlCasoAbertoCockpit())
				.append(FROM)
				.append(CasoAbertoCockpit.getSqlFromCasoAbertoCockpit())
				.append(WHERE)
				.append(" CasoAbertoCockpit.DATA_PROCESSAMENTO = CAST( GETDATE() AS DATE) ")
				.append(" AND CasoAbertoCockpit.FLAG_FILA = 1 ");
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					CasoAbertoCockpit casoAbertoCockpit = CasoAbertoCockpit.getCausaByResultSet(resultSet);
					casosAbertoCockpit.add(casoAbertoCockpit);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return casosAbertoCockpit;
    }
    
    @Override
	public CasoAbertoCockpit findByPk(Object id) throws DataException {
    	CasoAbertoCockpit result = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(CasoAbertoCockpit.getSelectSqlCasoAbertoCockpit())
				.append(FROM)
				.append(CasoAbertoCockpit.getSqlFromCasoAbertoCockpit())
				.append(" WHERE CasoAbertoCockpit.ID_CASO_ABERTO_COCKPIT = ? ");
			
			stmt = getPreparedStatement(select.toString());
			
			CasoAbertoCockpit casoAbertoCockpit = (CasoAbertoCockpit) id;
			
			stmt.setInt(1, casoAbertoCockpit.getIdCasoAbertoCockpit());
			
			stmt.execute();
			
			resultSet = stmt.getResultSet();
			if (resultSet != null && resultSet.next()) {
				result = CasoAbertoCockpit.getCausaByResultSet(resultSet);
			}
		} catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		return result;
	}
	
	@Override
	public List<CasoAbertoCockpit> findByExample(CasoAbertoCockpit example) throws DataException {
		return findByExample(example, null);
	}
	
	@Override
	public List<CasoAbertoCockpit> findByExample(CasoAbertoCockpit example, String order) throws DataException {
		List<CasoAbertoCockpit> casosAbertoCockpit = new ArrayList<CasoAbertoCockpit>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		int index =0;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(CasoAbertoCockpit.getSelectSqlCasoAbertoCockpit())
				.append(FROM)
				.append(CasoAbertoCockpit.getSqlFromCasoAbertoCockpit())
				.append(WHERE_1_1);
			
			if(example!=null){
			
				if (example.getIdCasoAbertoCockpit() != null) {
					select.append(" AND CasoAbertoCockpit.ID_CASO_ABERTO_COCKPIT = ? ");
				}
				if (example.getFlagFila() != null) {
					select.append(" AND CasoAbertoCockpit.FLAG_FILA = ? ");
				}
				if (example.getDataProcessamento() != null) {
					select.append(" AND CasoAbertoCockpit.DATA_PROCESSAMENTO BETWEEN ? AND ? ");
				}
				if (example.getNomeFilaAtendimento() != null && !example.getNomeFilaAtendimento().isEmpty()) {
					select.append(" AND CasoAbertoCockpit.NOME_FILA_ATENDIMENTO = ? ");
				}
				if (example.getTipoManifestacao() != null && !example.getTipoManifestacao().isEmpty()) {
					select.append(" AND CasoAbertoCockpit.TIPO_MANIFESTACAO = ? ");
				}
				if (example.getQtdPrimeiroDia() != null) {
					select.append(" AND CasoAbertoCockpit.QTD_PRIMEIRO_DIA = ? ");
				}
				if (example.getPercentualPrimeiroDia() != null && !example.getPercentualPrimeiroDia().isEmpty()) {
					select.append(" AND CasoAbertoCockpit.PERCENTUAL_PRIMEIRO_DIA = ? ");
				}
				if (example.getQtdSegundoDia() != null) {
					select.append(" AND CasoAbertoCockpit.QTD_SEGUNDO_DIA = ? ");
				}
				if (example.getPercentualSegundoDia() != null && !example.getPercentualSegundoDia().isEmpty()) {
					select.append(" AND CasoAbertoCockpit.PERCENTUAL_SEGUNDO_DIA = ? ");
				}
				if (example.getQtdTerceiroDia() != null) {
					select.append(" AND CasoAbertoCockpit.QTD_TERCEIRO_DIA = ? ");
				}
				if (example.getPercentualTerceiroDia() != null && !example.getPercentualTerceiroDia().isEmpty()) {
					select.append(" AND CasoAbertoCockpit.PERCENTUAL_TERCEIRO_DIA = ? ");
				}
				if (example.getQtdQuartoDia() != null) {
					select.append(" AND CasoAbertoCockpit.QTD_QUARTO_DIA = ? ");
				}
				if (example.getPercentualQuartoDia() != null && !example.getPercentualQuartoDia().isEmpty()) {
					select.append(" AND CasoAbertoCockpit.PERCENTUAL_QUARTO_DIA = ? ");
				}
				if (example.getQtdQuintoDia() != null) {
					select.append(" AND CasoAbertoCockpit.QTD_QUINTO_DIA = ? ");
				}
				if (example.getPercentualQuintoDia() != null && !example.getPercentualQuintoDia().isEmpty()) {
					select.append(" AND CasoAbertoCockpit.PERCENTUAL_QUINTO_DIA = ? ");
				}
				if (example.getQtdSextoDia() != null) {
					select.append(" AND CasoAbertoCockpit.QTD_SEXTO_DIA = ? ");
				}
				if (example.getPercentualSextoDia() != null && !example.getPercentualSextoDia().isEmpty()) {
					select.append(" AND CasoAbertoCockpit.PERCENTUAL_SEXTO_DIA = ? ");
				}
				if (example.getQtdRestanteDia() != null) {
					select.append(" AND CasoAbertoCockpit.QTD_RESTANTE_DIA = ? ");
				}
				if (example.getPercentualRestanteDia() != null && !example.getPercentualRestanteDia().isEmpty()) {
					select.append(" AND CasoAbertoCockpit.PERCENTUAL_RESTANTE_DIA = ? ");
				}
				if (example.getQtdTotal() != null) {
					select.append(" AND CasoAbertoCockpit.QTD_TOTAL = ? ");
				}
				if (example.getPercentualTotal() != null && !example.getPercentualTotal().isEmpty()) {
					select.append(" AND CasoAbertoCockpit.PERCENTUAL_TOTAL = ? ");
				}
			}
			
			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			if(example!=null){
				
				if (example.getIdCasoAbertoCockpit() != null) {
					stmt.setInt(++index, example.getIdCasoAbertoCockpit());
				}
				if (example.getFlagFila() != null) {
					stmt.setBoolean(++index, example.getFlagFila());
				}
				if (example.getDataProcessamento() != null) {
					Date dataInicio = DateUtil.dataInicioDia(example.getDataProcessamento());
					Date dataFim = DateUtil.dataFimDia(example.getDataProcessamento());
					stmt.setDate(++index, new java.sql.Date (dataInicio.getTime()));
					stmt.setDate(++index, new java.sql.Date(dataFim.getTime()));
				}
				if (example.getNomeFilaAtendimento() != null && !example.getNomeFilaAtendimento().isEmpty()) {
					stmt.setString(++index, example.getNomeFilaAtendimento());
				}
				if (example.getTipoManifestacao() != null && !example.getTipoManifestacao().isEmpty()) {
					stmt.setString(++index, example.getTipoManifestacao());
				}
				if (example.getQtdPrimeiroDia() != null) {
					stmt.setInt(++index, example.getQtdPrimeiroDia());
				}
				if (example.getPercentualPrimeiroDia() != null && !example.getPercentualPrimeiroDia().isEmpty()) {
					stmt.setString(++index, example.getPercentualPrimeiroDia());
				}
				if (example.getQtdSegundoDia() != null) {
					stmt.setInt(++index, example.getQtdSegundoDia());
				}
				if (example.getPercentualSegundoDia() != null && !example.getPercentualSegundoDia().isEmpty()) {
					stmt.setString(++index, example.getPercentualSegundoDia());
				}
				if (example.getQtdTerceiroDia() != null) {
					stmt.setInt(++index, example.getQtdTerceiroDia());
				}
				if (example.getPercentualTerceiroDia() != null && !example.getPercentualTerceiroDia().isEmpty()) {
					stmt.setString(++index, example.getPercentualTerceiroDia());
				}
				if (example.getQtdQuartoDia() != null) {
					stmt.setInt(++index, example.getQtdQuartoDia());
				}
				if (example.getPercentualQuartoDia() != null && !example.getPercentualQuartoDia().isEmpty()) {
					stmt.setString(++index, example.getPercentualQuartoDia());
				}
				if (example.getQtdQuintoDia() != null) {
					stmt.setInt(++index,example.getQtdQuintoDia());
				}
				if (example.getPercentualQuintoDia() != null && !example.getPercentualQuintoDia().isEmpty()) {
					stmt.setString(++index, example.getPercentualQuintoDia());
				}
				if (example.getQtdSextoDia() != null) {
					stmt.setInt(++index, example.getQtdSextoDia());
				}
				if (example.getPercentualSextoDia() != null && !example.getPercentualSextoDia().isEmpty()) {
					stmt.setString(++index, example.getPercentualSextoDia());
				}
				if (example.getQtdRestanteDia() != null) {
					stmt.setInt(++index, example.getQtdRestanteDia());
				}
				if (example.getPercentualRestanteDia() != null && !example.getPercentualRestanteDia().isEmpty()) {
					stmt.setString(++index, example.getPercentualRestanteDia());
				}
				if (example.getQtdTotal() != null) {
					stmt.setInt(++index, example.getQtdTotal());
				}
				if (example.getPercentualTotal() != null && !example.getPercentualTotal().isEmpty()) {
					stmt.setString(++index, example.getPercentualTotal());
				}
			}
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					CasoAbertoCockpit casoAbertoCockpit = CasoAbertoCockpit.getCausaByResultSet(resultSet);
					casosAbertoCockpit.add(casoAbertoCockpit);
				}
			}
		} catch (SQLException ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return casosAbertoCockpit;
	}
	
	@Override
	public List<CasoAbertoCockpit> findAll() throws DataException {
		return findAll(null);
	}
	
	@Override
	public List<CasoAbertoCockpit> findAll(String order) throws DataException {
		List<CasoAbertoCockpit> casosAbertoCockpit = new ArrayList<CasoAbertoCockpit>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(CasoAbertoCockpit.getSelectSqlCasoAbertoCockpit())
				.append(FROM)
				.append(CasoAbertoCockpit.getSqlFromCasoAbertoCockpit());
			
			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					CasoAbertoCockpit casoAbertoCockpit = CasoAbertoCockpit.getCausaByResultSet(resultSet);
					casosAbertoCockpit.add(casoAbertoCockpit);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return casosAbertoCockpit;
	}
	
	@Override
	public List<CasoAbertoCockpit> findAtivos() throws DataException {
		return findAtivos(null);
	}
	
	@Override
	public List<CasoAbertoCockpit> findAtivos(String order) throws DataException {
		throw new DataException("Entidade não possui coluna flag_ativo!");
	}
    
}
