package br.com.callink.cad.sau.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.sau.dao.ICasoFechadoDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.Canal;
import br.com.callink.cad.sau.pojo.CasoFechado;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.pojo.TipoManifestacao;

public class CasoFechadoDAO extends GenericCadSauDAO<CasoFechado> implements
		ICasoFechadoDAO {
    
	private static final long serialVersionUID = -2001763393308425891L;
	
	private static final String VIRGULA = ",";
    
    public CasoFechadoDAO() {
		super(CasoFechado.class);
	}
    
    @Override
    public CasoFechado buscaPorManifestacao(String manifestacao) throws DataException {
    	CasoFechado result = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(CasoFechado.getSqlCamposCasoFechado())
				.append(FROM)
				.append(CasoFechado.getSqlFromCasoFechado())
				.append(" WHERE CasoFechado.MANIFESTACAO = ? ");
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.setString(1, manifestacao);
			
			stmt.execute();
			
			resultSet = stmt.getResultSet();
			if (resultSet != null && resultSet.next()) {
				result = CasoFechado.getCasoFechadoByResultSet(resultSet);
			}
		} catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		return result;
    }
    
    @Override
    public List<CasoFechado> buscaCasosFechadosSpaAbertosGbo() throws DataException {
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
            StringBuilder sql = new StringBuilder()
                    .append(SELECT)
                        .append(CasoFechado.getSqlCamposCasoFechado())
                        .append(VIRGULA).append(Caso.getSqlCamposCaso())
                        .append(VIRGULA).append(CasoSau.getSqlCamposCasoSau())
                        .append(VIRGULA).append(Canal.getSqlCamposCanal())
                        .append(VIRGULA).append(TipoManifestacao.getSqlCamposTipoManifestacao())
                    .append(" \n FROM  ")
                        .append(CasoFechado.getSqlFromCasoFechado())
                        .append(VIRGULA).append(CasoSau.getSqlFromCasoSau())
                        .append(VIRGULA).append(Caso.getSqlFromCaso())
                        .append(VIRGULA).append(Canal.getSqlFromCanal())
                        .append(VIRGULA).append(TipoManifestacao.getSqlFromTipoManifestacao())
                    .append(" \n WHERE  ")
                        .append(" CasoFechado.MANIFESTACAO = CasoSau.MANIFESTACAO ")
                        .append(" \n AND Caso.ID_CASO = CasoSau.ID_CASO ")
                        .append(" \n AND Caso.FLAG_FINALIZADO = 0")
                        .append(" \n AND CasoSau.id_tipo_caso = TipoManifestacao.id_tipo_caso ")
                        .append(" \n AND CasoSau.id_canal = Canal.id_canal");
            
            stmt = getPreparedStatement(sql.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
            
            return getCasoFechadoListByresultSet(resultSet);
		} catch (Exception ex) {
			throw new DataException("Erro ao buscar os casos fechados.", ex);
		} finally {
			super.close(resultSet);
		}
    }
    
    private List<CasoFechado> getCasoFechadoListByresultSet(ResultSet resultSet) throws DataException{
         try {
            List<CasoFechado> casoFechadoList = null;
            if (resultSet != null) {
                casoFechadoList = new ArrayList<CasoFechado> ();
                while (resultSet.next()) {

                    CasoFechado casoFechado = CasoFechado.getCasoFechadoByResultSet(resultSet);
                    CasoSau casoSau = CasoSau.getCasoSauByResultSet(resultSet);
                    Caso caso = Caso.getCasoByResultSet(resultSet);
                    Canal canal = Canal.getCanalByResultSet(resultSet);
                    TipoManifestacao tipoManifestacao = TipoManifestacao.getTipoManifestacaoByResultSet(resultSet);

                    casoFechado.setCasoSau(casoSau);
                    casoFechado.getCasoSau().setTipoManifestacao(tipoManifestacao);
                    casoFechado.getCasoSau().setCanal(canal);
                    casoSau.setCaso(caso);
                    casoFechadoList.add(casoFechado);
                }
            }
            return casoFechadoList;
        } catch (SQLException e) {
            throw new DataException("Erro ao Buscar Casos.", e);
        }
    }
    
    @Override
	public CasoFechado findByPk(Object id) throws DataException {
    	CasoFechado result = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(CasoFechado.getSqlCamposCasoFechado())
				.append(FROM)
				.append(CasoFechado.getSqlFromCasoFechado())
				.append(" WHERE CasoFechado.ID_CASO_FECHADO = ? ");
			
			stmt = getPreparedStatement(select.toString());
			
			CasoFechado casoFechado = (CasoFechado) id;
			
			stmt.setInt(1, casoFechado.getIdCasoFechado());
			
			stmt.execute();
			
			resultSet = stmt.getResultSet();
			if (resultSet != null && resultSet.next()) {
				result = CasoFechado.getCasoFechadoByResultSet(resultSet);
			}
		} catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		return result;
	}
	
	@Override
	public List<CasoFechado> findByExample(CasoFechado example) throws DataException {
		return findByExample(example, null);
	}
	
	@Override
	public List<CasoFechado> findByExample(CasoFechado example, String order) throws DataException {
		List<CasoFechado> casosFechado = new ArrayList<CasoFechado>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		int index = 0;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(CasoFechado.getSqlCamposCasoFechado())
				.append(FROM)
				.append(CasoFechado.getSqlFromCasoFechado())
				.append(WHERE_1_1);
			
			if(example!= null){
			
				if (example.getIdCasoFechado() != null) {
					select.append(" AND CasoFechado.ID_CASO_FECHADO = ? ");
				}
				if (example.getManifestacao() != null && !example.getManifestacao().isEmpty()) {
					select.append(" AND CasoFechado.MANIFESTACAO like ? ");
				}
				if (example.getDataAbertura() != null && !example.getDataAbertura().isEmpty()) {
					select.append(" AND CasoFechado.DATA_ABERTURA = ? ");
				}
				if (example.getDataUltimaAcao() != null && !example.getDataUltimaAcao().isEmpty()) {
					select.append(" AND CasoFechado.DATA_ULTIMA_ACAO = ? ");
				}
				if (example.getNomeEstado() != null && !example.getNomeEstado().isEmpty()) {
					select.append(" AND CasoFechado.NOME_ESTADO like ? ");
				}
				if (example.getNomeCanal() != null && !example.getNomeCanal().isEmpty()) {
					select.append(" AND CasoFechado.NOME_CANAL like ? ");
				}
				if (example.getUltimoAtendente() != null && !example.getUltimoAtendente().isEmpty()) {
					select.append(" AND CasoFechado.ULTIMO_ATENDENTE like ? ");
				}
				if (example.getAtendenteAtual() != null && !example.getAtendenteAtual().isEmpty()) {
					select.append(" AND CasoFechado.ATENDENTE_ATUAL like ? ");
				}
				if (example.getNomeTipoCaso() != null && !example.getNomeTipoCaso().isEmpty()) {
					select.append(" AND CasoFechado.NOME_TIPO_CASO like ? ");
				}
				if (example.getAgenciaDepartamento() != null && !example.getAgenciaDepartamento().isEmpty()) {
					select.append(" AND CasoFechado.AGENCIA_DEPARTAMENTO like ? ");
				}
				if (example.getNomeCliente() != null && !example.getNomeCliente().isEmpty()) {
					select.append(" AND CasoFechado.NOME_CLIENTE like ? ");
				}
				if (example.getAgenciaConta() != null && !example.getAgenciaConta().isEmpty()) {
					select.append(" AND CasoFechado.AGENCIA_CONTA like ? ");
				}
				if (example.getCpfCnpj() != null && !example.getCpfCnpj().isEmpty()) {
					select.append(" AND CasoFechado.CPF_CNPJ like ? ");
				}
				if (example.getEmail() != null && !example.getEmail().isEmpty()) {
					select.append(" AND CasoFechado.EMAIL like ? ");
				}
				if (example.getTelefone() != null && !example.getTelefone().isEmpty()) {
					select.append(" AND CasoFechado.TELEFONE = ");
				}
				if (example.getTelefoneSegundo() != null && !example.getTelefoneSegundo().isEmpty()) {
					select.append(" AND CasoFechado.TELEFONE_SEGUNDO = ? ");
				}
				if (example.getEndereco() != null && !example.getEndereco().isEmpty()) {
					select.append(" AND CasoFechado.ENDERECO like ? ");
				}
				if (example.getCep() != null && !example.getCep().isEmpty()) {
					select.append(" AND CasoFechado.CEP = ? ");
				}
				if (example.getEnvioProtocoloCliente() != null && !example.getEnvioProtocoloCliente().isEmpty()) {
					select.append(" AND CasoFechado.ENVIO_PROTOCOLO_CLIENTE like ? ");
				}
				if (example.getViaEntrada() != null && !example.getViaEntrada().isEmpty()) {
					select.append(" AND CasoFechado.VIA_ENTRADA = ? ");
				}
				if (example.getDescricao() != null && !example.getDescricao().isEmpty()) {
					select.append(" AND CasoFechado.DESCRICAO like ? ");
				}
				if (example.getAssunto() != null && !example.getAssunto().isEmpty()) {
					select.append(" AND CasoFechado.ASSUNTO like ? ");
				}
				if (example.getHoraAbertura() != null && !example.getHoraAbertura().isEmpty()) {
					select.append(" AND CasoFechado.HORA_ABERTURA like ? ");
				}
				if (example.getGrupo() != null && !example.getGrupo().isEmpty()) {
					select.append(" AND CasoFechado.GRUPO like ? ");
				}
				if (example.getSubGrupo() != null && !example.getSubGrupo().isEmpty()) {
					select.append(" AND CasoFechado.SUB_GRUPO like ? ");
				}
				if (example.getNomeCausa() != null && !example.getNomeCausa().isEmpty()) {
					select.append(" AND CasoFechado.NOME_CAUSA like ? ");
				}
			}
			
			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			if(example!= null){
				
				if (example.getIdCasoFechado() != null) {
					stmt.setInt(++index, example.getIdCasoFechado());
				}
				if (example.getManifestacao() != null && !example.getManifestacao().isEmpty()) {
					stmt.setString(++index, new StringBuilder(example.getManifestacao()).append("%").toString());
				}
				if (example.getDataAbertura() != null && !example.getDataAbertura().isEmpty()) {
					stmt.setString(++index, example.getDataAbertura());
				}
				if (example.getDataUltimaAcao() != null && !example.getDataUltimaAcao().isEmpty()) {
					stmt.setString(++index, example.getDataUltimaAcao());
				}
				if (example.getNomeEstado() != null && !example.getNomeEstado().isEmpty()) {
					stmt.setString(++index,new StringBuilder(example.getNomeEstado()).append("%").toString());
				}
				if (example.getNomeCanal() != null && !example.getNomeCanal().isEmpty()) {
					stmt.setString(++index, new StringBuilder(example.getNomeCanal()).append("%").toString());
				}
				if (example.getUltimoAtendente() != null && !example.getUltimoAtendente().isEmpty()) {
					stmt.setString(++index, new StringBuilder(example.getUltimoAtendente()).append("%").toString());
				}
				if (example.getAtendenteAtual() != null && !example.getAtendenteAtual().isEmpty()) {
					stmt.setString(++index, new StringBuilder(example.getAtendenteAtual()).append("%").toString());
				}
				if (example.getNomeTipoCaso() != null && !example.getNomeTipoCaso().isEmpty()) {
					stmt.setString(++index, example.getNomeTipoCaso());
				}
				if (example.getAgenciaDepartamento() != null && !example.getAgenciaDepartamento().isEmpty()) {
					stmt.setString(++index, new StringBuilder(example.getAgenciaDepartamento()).append("%").toString());
				}
				if (example.getNomeCliente() != null && !example.getNomeCliente().isEmpty()) {
					stmt.setString(++index, new StringBuilder(example.getNomeCliente()).append("%").toString());
				}
				if (example.getAgenciaConta() != null && !example.getAgenciaConta().isEmpty()) {
					stmt.setString(++index, example.getAgenciaConta());
				}
				if (example.getCpfCnpj() != null && !example.getCpfCnpj().isEmpty()) {
					stmt.setString(++index, new StringBuilder(example.getCpfCnpj()).append("%").toString());
				}
				if (example.getEmail() != null && !example.getEmail().isEmpty()) {
					stmt.setString(++index,new StringBuilder(example.getEmail()).append("%").toString());
				}
				if (example.getTelefone() != null && !example.getTelefone().isEmpty()) {
					stmt.setString(++index, example.getTelefone());
				}
				if (example.getTelefoneSegundo() != null && !example.getTelefoneSegundo().isEmpty()) {
					stmt.setString(++index, example.getTelefoneSegundo());
				}
				if (example.getEndereco() != null && !example.getEndereco().isEmpty()) {
					stmt.setString(++index, example.getEndereco());
				}
				if (example.getCep() != null && !example.getCep().isEmpty()) {
					stmt.setString(++index, example.getCep());
				}
				if (example.getEnvioProtocoloCliente() != null && !example.getEnvioProtocoloCliente().isEmpty()) {
					stmt.setString(++index, example.getEnvioProtocoloCliente());
				}
				if (example.getViaEntrada() != null && !example.getViaEntrada().isEmpty()) {
					stmt.setString(++index, example.getViaEntrada());
				}
				if (example.getDescricao() != null && !example.getDescricao().isEmpty()) {
					stmt.setString(++index, new StringBuilder(example.getDescricao()).append("%").toString());
				}
				if (example.getAssunto() != null && !example.getAssunto().isEmpty()) {
					stmt.setString(++index, new StringBuilder(example.getAssunto()).append("%").toString());
				}
				if (example.getHoraAbertura() != null && !example.getHoraAbertura().isEmpty()) {
					stmt.setString(++index, example.getHoraAbertura());
				}
				if (example.getGrupo() != null && !example.getGrupo().isEmpty()) {
					stmt.setString(++index, example.getGrupo());
				}
				if (example.getSubGrupo() != null && !example.getSubGrupo().isEmpty()) {
					stmt.setString(++index, new StringBuilder(example.getSubGrupo()).append("%").toString());
				}
				if (example.getNomeCausa() != null && !example.getNomeCausa().isEmpty()) {
					stmt.setString(++index, new StringBuilder(example.getNomeCausa()).append("%").toString());
				}
			}
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					CasoFechado casoFechado = CasoFechado.getCasoFechadoByResultSet(resultSet);
					casosFechado.add(casoFechado);
				}
			}
		} catch (SQLException ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return casosFechado;
	}
	
	@Override
	public List<CasoFechado> findAll() throws DataException {
		return findAll(null);
	}
	
	@Override
	public List<CasoFechado> findAll(String order) throws DataException {
		List<CasoFechado> casosFechado = new ArrayList<CasoFechado>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(CasoFechado.getSqlCamposCasoFechado())
				.append(FROM)
				.append(CasoFechado.getSqlFromCasoFechado());
			
			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					CasoFechado casoFechado = CasoFechado.getCasoFechadoByResultSet(resultSet);
					casosFechado.add(casoFechado);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return casosFechado;
	}
	
	@Override
	public List<CasoFechado> findAtivos() throws DataException {
		return findAtivos(null);
	}
	
	@Override
	public List<CasoFechado> findAtivos(String order) throws DataException {
		throw new DataException("Entidade não possui coluna flag_ativo!");
	}
    
}