package br.com.callink.cad.sau.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import org.apache.commons.lang.StringUtils;
import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.pojo.Equipe;
import br.com.callink.cad.pojo.Status;
import br.com.callink.cad.pojo.Util.DateUtil;
import br.com.callink.cad.sau.dao.ICasoSauDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.Assunto;
import br.com.callink.cad.sau.pojo.Canal;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.pojo.Causa;
import br.com.callink.cad.sau.pojo.Estado;
import br.com.callink.cad.sau.pojo.Evento;
import br.com.callink.cad.sau.pojo.Juncao;
import br.com.callink.cad.sau.pojo.OutraArea;
import br.com.callink.cad.sau.pojo.TipoManifestacao;
import br.com.callink.cad.sau.pojo.to.AcompanhamentoCasoFind;

public class CasoSauDAO extends GenericCadSauDAO<CasoSau> implements ICasoSauDAO {

	private static final long serialVersionUID = -2133203450071185507L;
	
	private static final String VIRGULA = ",";
    
    public CasoSauDAO() {
		super(CasoSau.class);
	}

    @Override
    public boolean existeManifestacao(String manifestacao)
            throws DataException {
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder(SELECT)
				.append(CasoSau.getSqlCamposCasoSau())
				.append(FROM)
				.append(CasoSau.getSqlFromCasoSau())
				.append(WHERE_1_1)
				.append(" AND CasoSau.MANIFESTACAO = ? ");
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.setString(1, manifestacao);
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null && resultSet.next()) {
				return Boolean.TRUE;
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
        return Boolean.FALSE;
    }

    @Override
    public boolean existeCasoGbo(Caso caso) throws DataException {
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(CasoSau.getSqlCamposCasoSau())
				.append(FROM)
				.append(CasoSau.getSqlFromCasoSau())
				.append(WHERE_1_1)
				.append(" AND CasoSau.ID_CASO = ? ");
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.setInt(1, caso.getIdCaso());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null && resultSet.next()) {
				return Boolean.TRUE;
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
        return Boolean.FALSE;
    }

    @Override
    public CasoSau findCasoSauByCaso(Caso caso) throws DataException {
    	CasoSau result = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(CasoSau.getSqlCamposCasoSau())
				.append(VIRGULA)
				.append(Canal.getSqlCamposCanal())
				.append(VIRGULA)
				.append(TipoManifestacao.getSqlCamposTipoManifestacao())
				.append(VIRGULA)
				.append(Causa.getSqlCausa())
				.append(VIRGULA)
				.append(Evento.getSqlEvento())
				.append(VIRGULA)
				.append(Estado.getSqlEstado())
				.append(FROM)
				.append(CasoSau.getSqlFromCasoSau())
				.append(INNER_JOIN).append(Canal.getSqlFromCanal())
				.append(" ON CasoSau.ID_CANAL = Canal.ID_CANAL ")
				.append(INNER_JOIN).append(TipoManifestacao.getSqlFromTipoManifestacao())
				.append(" ON CasoSau.ID_TIPO_CASO = TipoManifestacao.ID_TIPO_CASO ")
				.append(LEFT_JOIN).append(Causa.getSqlFromCausa())
				.append(" ON CasoSau.ID_CAUSA = Causa.ID_CAUSA ")
				.append(LEFT_JOIN).append(Evento.getSqlFromEvento())
				.append(" ON CasoSau.ID_EVENTO = Evento.ID_EVENTO ")
				.append(LEFT_JOIN).append(Estado.getSqlFromEstado())
				.append(" ON CasoSau.ID_ESTADO = Estado.ID_ESTADO ")
				.append(" WHERE CasoSau.ID_CASO = ? ");
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.setInt(1, caso.getIdCaso());
			
			stmt.execute();
			
			resultSet = stmt.getResultSet();
			if (resultSet != null && resultSet.next()) {
				result = CasoSau.getCasoSauByResultSet(resultSet);
				result.setCanal(Canal.getCanalByResultSet(resultSet));
				result.setTipoManifestacao(TipoManifestacao.getTipoManifestacaoByResultSet(resultSet));
				result.setCausa(Causa.getCausaByResultSet(resultSet));
				result.setEvento(Evento.getEventoByResultSet(resultSet));
				result.setEstado(Estado.getEstadoByResultSet(resultSet));
			}
		} catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		return result;
    }

    @Override
    public List<CasoSau> buscaPorConfiguracaoFilaEAtendente(ConfiguracaoFila configuracaoFila, Atendente atendente) throws DataException {
    	List<CasoSau> casosSau = new ArrayList<CasoSau>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(CasoSau.getSqlCamposCasoSau())
				.append(VIRGULA)
				.append(Caso.getSqlCamposCaso())
				.append(VIRGULA)
				.append(Status.getSqlCamposStatus());
			
			if (atendente != null) {
				select.append(VIRGULA)
					  .append(Atendente.getSqlCamposAtendente());
			}
			
			select.append(FROM)
				  .append(CasoSau.getSqlFromCasoSau())
				  .append(INNER_JOIN).append(Caso.getSqlFromCaso())
				  .append(" ON CasoSau.ID_CASO = Caso.ID_CASO ")
				  .append(INNER_JOIN).append(Status.getSqlFromStatus())
				  .append(" ON Caso.ID_STATUS = Status.ID_STATUS ");
			
			if (atendente != null) {
				select.append(INNER_JOIN).append(Atendente.getSqlFromAtendente())
					  .append(" ON Caso.ID_ATENDENTE = Atendente.ID_ATENDENTE ");
			}
			
			select.append(WHERE)
				  .append(" Caso.FLAG_FINALIZADO = 0 ")
				  .append(" AND Caso.ID_CONFIGURACAO_FILA = ? ");
			
			if (atendente != null && atendente.getIdAtendente() != null) {
				select.append(" AND Caso.ID_ATENDENTE = ? ");
			}
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.setInt(1, configuracaoFila.getIdConfiguracaoFila());
			
			if (atendente != null && atendente.getIdAtendente() != null) {
				stmt.setInt(2, atendente.getIdAtendente());
			}
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					CasoSau casoSau = CasoSau.getCasoSauByResultSet(resultSet);
					
					Caso caso = Caso.getCasoByResultSet(resultSet);
					caso.setStatus(Status.getStatusByResultSet(resultSet));
					caso.setAtendente(Atendente.getAtendenteByResultSet(resultSet));
					
					casoSau.setCaso(caso);
					
					casosSau.add(casoSau);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return casosSau;
    }

    @Override
    public CasoSau load(CasoSau casoSau) throws DataException {
    	CasoSau result = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		int index =0;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(CasoSau.getSqlCamposCasoSau())
				.append(VIRGULA)
				.append(Caso.getSqlCamposCaso())
				.append(VIRGULA)
				.append(Status.getSqlCamposStatus())
				.append(VIRGULA)
				.append(ConfiguracaoFila.getSqlCamposConfiguracaoFila())
				.append(VIRGULA)
				.append(Atendente.getSqlCamposAtendente())
				.append(VIRGULA)
				.append(Canal.getSqlCamposCanal())
				.append(VIRGULA)
				.append(TipoManifestacao.getSqlCamposTipoManifestacao())
				.append(VIRGULA)
				.append(Causa.getSqlCausa())
				.append(VIRGULA)
				.append(Evento.getSqlEvento())
				.append(VIRGULA)
				.append(Assunto.getSqlAssunto())
				.append(VIRGULA)
				.append(Estado.getSqlEstado())
				.append(FROM)
				.append(CasoSau.getSqlFromCasoSau())
				.append(INNER_JOIN).append(Caso.getSqlFromCaso())
				.append(" ON CasoSau.ID_CASO = Caso.ID_CASO ")
				.append(INNER_JOIN).append(Status.getSqlFromStatus())
				.append(" ON Caso.ID_STATUS = Status.ID_STATUS ")
				.append(LEFT_JOIN).append(ConfiguracaoFila.getSqlFromConfiguracaoFila())
				.append(" ON Caso.ID_CONFIGURACAO_FILA = ConfiguracaoFila.ID_CONFIGURACAO_FILA ")
				.append(LEFT_JOIN).append(Atendente.getSqlFromAtendente())
				.append(" ON Caso.ID_ATENDENTE = Atendente.ID_ATENDENTE ")
				.append(INNER_JOIN).append(Canal.getSqlFromCanal())
				.append(" ON CasoSau.ID_CANAL = Canal.ID_CANAL ")
				.append(INNER_JOIN).append(TipoManifestacao.getSqlFromTipoManifestacao())
				.append(" ON CasoSau.ID_TIPO_CASO = TipoManifestacao.ID_TIPO_CASO ")
				.append(LEFT_JOIN).append(Causa.getSqlFromCausa())
				.append(" ON CasoSau.ID_CAUSA = Causa.ID_CAUSA ")
				.append(LEFT_JOIN).append(Evento.getSqlFromEvento())
				.append(" ON CasoSau.ID_EVENTO = Evento.ID_EVENTO ")
				.append(LEFT_JOIN).append(Assunto.getSqlFromAssunto())
				.append(" ON Evento.ID_ASSUNTO = Assunto.ID_ASSUNTO ")
				.append(LEFT_JOIN).append(Estado.getSqlFromEstado())
				.append(" ON CasoSau.ID_ESTADO = Estado.ID_ESTADO ")
				.append(WHERE_1_1);
			
			if (casoSau.getIdCasoSau() != null) {
				select.append(" AND CasoSau.ID_CASO_SAU = ? ");
	        }
	        if (casoSau.getIdCasoSau() == null && casoSau.getManifestacao() != null) {
	        	select.append(" AND CasoSau.MANIFESTACAO = ? ");
	        }
			
			stmt = getPreparedStatement(select.toString());
			
			if (casoSau.getIdCasoSau() != null) {
				stmt.setInt(++index, casoSau.getIdCasoSau());
	        }
	        if (casoSau.getIdCasoSau() == null && casoSau.getManifestacao() != null) {
	        	stmt.setString(++index, casoSau.getManifestacao());
	        }
	        stmt.execute();
			resultSet = stmt.getResultSet();
			if (resultSet != null && resultSet.next()) {
				result = CasoSau.getCasoSauByResultSet(resultSet);
				
				Caso caso = Caso.getCasoByResultSet(resultSet);
				if(caso != null) {
					caso.setStatus(Status.getStatusByResultSet(resultSet));
					caso.setConfiguracaoFila(ConfiguracaoFila.getConfiguracaoFilaByResultSet(resultSet));
					caso.setAtendente(Atendente.getAtendenteByResultSet(resultSet));
				}
				result.setCaso(caso);
				
				result.setCanal(Canal.getCanalByResultSet(resultSet));
				result.setTipoManifestacao(TipoManifestacao.getTipoManifestacaoByResultSet(resultSet));
				result.setCausa(Causa.getCausaByResultSet(resultSet));
				
				Evento evento = Evento.getEventoByResultSet(resultSet);
				if(evento != null) {
					evento.setAssunto(Assunto.getAssuntoByResultSet(resultSet));
				}
				result.setEvento(evento);
				
				result.setEstado(Estado.getEstadoByResultSet(resultSet));
			}
		} catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		return result;
    }

    @Override
    public List<CasoSau> buscaPorFilaOrAtendenteOrManifestacao(ConfiguracaoFila configuracaoFila,
            Atendente atendente, String manifestacao) throws DataException {
    	PreparedStatement stmt = null;
    	ResultSet resultSet = null;
    	int index = 0;
        try {
            StringBuilder sql = getSqlBuscaPorFilaAtendente();

            if (configuracaoFila != null && configuracaoFila.getIdConfiguracaoFila() != null) {
                sql.append(" AND Caso.ID_CONFIGURACAO_FILA = ? ");
            }
            if (atendente != null && atendente.getIdAtendente() != null) {
                sql.append(" AND Atendente.ID_ATENDENTE = ? ");
            }
            if (!StringUtils.isBlank(manifestacao)) {
                sql.append(" AND CasoSau.MANIFESTACAO = ? ");
            }

            stmt = getPreparedStatement(sql.toString());
			

            if (configuracaoFila != null && configuracaoFila.getIdConfiguracaoFila() != null) {
                stmt.setInt(++index, configuracaoFila.getIdConfiguracaoFila());
            }
            if (atendente != null && atendente.getIdAtendente() != null) {
                stmt.setInt(++index, atendente.getIdAtendente());
            }
            if (!StringUtils.isBlank(manifestacao)) {
                stmt.setString(++index, manifestacao);
            }
            
			stmt.execute();
			
			resultSet = stmt.getResultSet();
            return getCasoSauPorConfiguracaoFilaEAtendente(resultSet);
        } catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
    }

    @Override
    public List<CasoSau> buscaPorFiltroSQL(AcompanhamentoCasoFind acompanhamentoCasoFind) throws DataException {
    	List<CasoSau> casosSau = new ArrayList<CasoSau>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(CasoSau.getSqlCamposCasoSau())
				.append(VIRGULA)
				.append(Caso.getSqlCamposCaso())
				.append(VIRGULA)
				.append(Status.getSqlCamposStatus())
				.append(VIRGULA)
				.append(Atendente.getSqlCamposAtendente())
				.append(VIRGULA)
				.append(Equipe.getSqlEquipe())
				.append(VIRGULA)
				.append(TipoManifestacao.getSqlCamposTipoManifestacao())
				.append(VIRGULA)
				.append(Canal.getSqlCamposCanal())
				.append(VIRGULA)
				.append(Estado.getSqlEstado())
				.append(VIRGULA)
				.append(OutraArea.getSqlOutraArea())
				.append(FROM)
				.append(CasoSau.getSqlFromCasoSau())
				.append(INNER_JOIN).append(Caso.getSqlFromCaso())
				.append(" ON CasoSau.ID_CASO = Caso.ID_CASO ")
				.append(INNER_JOIN).append(Status.getSqlFromStatus())
				.append(" ON Caso.ID_STATUS = Status.ID_STATUS ")
				.append(LEFT_JOIN).append(Atendente.getSqlFromAtendente())
				.append(" ON Caso.ID_ATENDENTE = Atendente.ID_ATENDENTE ")
				.append(LEFT_JOIN).append(Equipe.getSqlFromEquipe())
				.append(" ON Atendente.ID_EQUIPE = Equipe.ID_EQUIPE ")
				.append(LEFT_JOIN).append(TipoManifestacao.getSqlFromTipoManifestacao())
				.append(" ON CasoSau.ID_TIPO_CASO = TipoManifestacao.ID_TIPO_CASO ")
				.append(LEFT_JOIN).append(Canal.getSqlFromCanal())
				.append(" ON CasoSau.ID_CANAL = Canal.ID_CANAL ")
				.append(LEFT_JOIN).append(Estado.getSqlFromEstado())
				.append(" ON CasoSau.ID_ESTADO = Estado.ID_ESTADO ")
				.append(LEFT_JOIN).append(OutraArea.getSqlFromOutraArea())
				.append(" ON CasoSau.ID_OUTRA_AREA = OutraArea.ID_OUTRA_AREA ")
				.append(WHERE_1_1);
			
			getFiltros(select, acompanhamentoCasoFind);
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					CasoSau casoSau = CasoSau.getCasoSauByResultSet(resultSet);
					
					Caso caso = Caso.getCasoByResultSet(resultSet);
					caso.setStatus(Status.getStatusByResultSet(resultSet));
					Atendente atendente = Atendente.getAtendenteByResultSet(resultSet);
					if(atendente != null){
						atendente.setEquipe(Equipe.getEquipeByResultSet(resultSet));
					}
					caso.setAtendente(atendente);
					casoSau.setCaso(caso);
					
					casoSau.setTipoManifestacao(TipoManifestacao.getTipoManifestacaoByResultSet(resultSet));
					casoSau.setCanal(Canal.getCanalByResultSet(resultSet));
					casoSau.setEstado(Estado.getEstadoByResultSet(resultSet));
					casoSau.setOutraArea(OutraArea.getOutraAreaByResultSet(resultSet));
					casosSau.add(casoSau);
				}
			}
		} catch (SQLException ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return casosSau;
    }

    private StringBuilder getSqlBuscaPorFilaAtendente() {

        StringBuilder sql = new StringBuilder().append("SELECT ")
        		.append(CasoSau.getSqlCamposCasoSau())
        		.append(VIRGULA).append(Caso.getSqlCamposCaso())
        		.append(VIRGULA).append(Atendente.getSqlCamposAtendente())
        		.append(VIRGULA).append(Status.getSqlCamposStatus())
        		.append(" \n FROM  TB_CASO_SAU  AS CasoSau with(nolock),")
        		.append(" \n TB_CASO  AS Caso LEFT JOIN TB_ATENDENTE As Atendente  with(nolock) ON Caso.id_atendente = Atendente.id_atendente, ")
        		.append(" \n TB_STATUS  AS Status  with(nolock) ").append(" \n WHERE Caso.ID_CASO = CasoSau.ID_CASO ")
        		.append(" \n AND Status.ID_STATUS = Caso.ID_STATUS ")
        		.append(" \n AND Caso.FLAG_FINALIZADO = 0");

        return sql;
    }

    private List<CasoSau> getCasoSauPorConfiguracaoFilaEAtendente(
            ResultSet resultSet) throws DataException {
        try {
            List<CasoSau> casoSauList = null;
            if (resultSet != null) {
                casoSauList = new ArrayList<CasoSau>();
                while (resultSet.next()) {

                    CasoSau casoSau = CasoSau.getCasoSauByResultSet(resultSet);
                    Caso caso = Caso.getCasoByResultSet(resultSet);
                    Atendente atendente = Atendente.getAtendenteByResultSet(resultSet);
                    Status status = Status.getStatusByResultSet(resultSet);

                    casoSau.setCaso(caso);
                    caso.setAtendente(atendente);
                    caso.setStatus(status);
                    casoSauList.add(casoSau);
                }
            }
            return casoSauList;
        } catch (SQLException e) {
            throw new DataException("Erro ao Buscar Casos.", e);
        }
    }

    private void getFiltros(StringBuilder select, AcompanhamentoCasoFind acompanhamentoCasoFind) {

        if (!StringUtils.isBlank(acompanhamentoCasoFind.getCasoSau().getManifestacao())) {
            select.append(String.format(" AND CasoSau.MANIFESTACAO = '%s' ", acompanhamentoCasoFind.getCasoSau().getManifestacao()));
        }

        if (acompanhamentoCasoFind.getConfiguracaoFilaSelecionadoList() != null && !acompanhamentoCasoFind.getConfiguracaoFilaSelecionadoList().isEmpty()) {
        	StringBuilder configFilaIn = new StringBuilder();
            for (int i = 0; i < acompanhamentoCasoFind.getConfiguracaoFilaSelecionadoList().size(); i++) {
            	if (i != 0) {
            		configFilaIn.append(VIRGULA);
            	}
            	configFilaIn.append(acompanhamentoCasoFind.getConfiguracaoFilaSelecionadoList().get(i).getIdConfiguracaoFila());
            }
            select.append(String.format(" AND Caso.ID_CONFIGURACAO_FILA in (%s) ", configFilaIn.toString()));
        }
        if (acompanhamentoCasoFind.getCasoSau() != null && acompanhamentoCasoFind.getCasoSau().getCpfCnpj() != null) {
            select.append(String.format(" AND CasoSau.CPF_CNPJ = '%s' ", acompanhamentoCasoFind.getCasoSau().getCpfCnpj()));
        }
        if (acompanhamentoCasoFind.getAtendenteSelecionadoList() != null && !acompanhamentoCasoFind.getAtendenteSelecionadoList().isEmpty()) {
        	StringBuilder atendenteIn = new StringBuilder();
            for (int i = 0; i < acompanhamentoCasoFind.getAtendenteSelecionadoList().size(); i++) {
            	if (i != 0) {
            		atendenteIn.append(VIRGULA);
            	}
            	atendenteIn.append(acompanhamentoCasoFind.getAtendenteSelecionadoList().get(i).getIdAtendente());
            }
            select.append(String.format(" AND Caso.ID_ATENDENTE in (%s) ", atendenteIn.toString()));
        }
        if (acompanhamentoCasoFind.getEquipeSelecionadoList() != null && !acompanhamentoCasoFind.getEquipeSelecionadoList().isEmpty()) {
        	StringBuilder equipeIn = new StringBuilder();
            for (int i = 0; i < acompanhamentoCasoFind.getEquipeSelecionadoList().size(); i++) {
            	if (i != 0) {
            		equipeIn.append(VIRGULA);
            	}
            	equipeIn.append(acompanhamentoCasoFind.getEquipeSelecionadoList().get(i).getIdEquipe());
            }
            select.append(String.format(" AND Atendente.ID_EQUIPE in (%s) ", equipeIn.toString()));
        }
        if (acompanhamentoCasoFind.getStatusSelecionadoList() != null && !acompanhamentoCasoFind.getStatusSelecionadoList().isEmpty()) {
        	StringBuilder statusIn = new StringBuilder();
            for (int i = 0; i < acompanhamentoCasoFind.getStatusSelecionadoList().size(); i++) {
            	if (i != 0) {
            		statusIn.append(VIRGULA);
            	}
            	statusIn.append(acompanhamentoCasoFind.getStatusSelecionadoList().get(i).getIdStatus());
            }
            select.append(String.format(" AND Caso.ID_STATUS in (%s) ", statusIn.toString()));
        }
        if (acompanhamentoCasoFind.getTipoManifestacaoSelecionadoList() != null && !acompanhamentoCasoFind.getTipoManifestacaoSelecionadoList().isEmpty()) {
        	StringBuilder tipoIn = new StringBuilder();
            for (int i = 0; i < acompanhamentoCasoFind.getTipoManifestacaoSelecionadoList().size(); i++) {
            	if (i != 0) {
            		tipoIn.append(VIRGULA);
            	}
            	tipoIn.append(acompanhamentoCasoFind.getTipoManifestacaoSelecionadoList().get(i).getIdTipoCaso());
            }
            select.append(String.format(" AND CasoSau.ID_TIPO_CASO in (%s) ", tipoIn.toString()));
        }
        if (acompanhamentoCasoFind.getEstadoSelecionadoList() != null && !acompanhamentoCasoFind.getEstadoSelecionadoList().isEmpty()) {
        	StringBuilder estadoIn = new StringBuilder();
            for (int i = 0; i < acompanhamentoCasoFind.getEstadoSelecionadoList().size(); i++) {
            	if (i != 0) {
            		estadoIn.append(VIRGULA);
            	}
            	estadoIn.append(acompanhamentoCasoFind.getEstadoSelecionadoList().get(i).getIdEstado());
            }
            select.append(String.format(" AND CasoSau.ID_ESTADO in (%s) ", estadoIn.toString()));
        }
        if (acompanhamentoCasoFind.getOutraAreaSelecionadoList()!= null && !acompanhamentoCasoFind.getOutraAreaSelecionadoList().isEmpty()) {
        	StringBuilder outraAreaIn = new StringBuilder();
            for (int i = 0; i < acompanhamentoCasoFind.getOutraAreaSelecionadoList().size(); i++) {
            	if (i != 0) {
            		outraAreaIn.append(VIRGULA);
            	}
            	outraAreaIn.append(acompanhamentoCasoFind.getOutraAreaSelecionadoList().get(i).getIdOutraArea());
            }
            select.append(String.format(" AND CasoSau.ID_OUTRA_AREA in (%s) ", outraAreaIn.toString()));
        }
        if (acompanhamentoCasoFind.getCasoSau().getAssunto() != null) {
            select.append(String.format(" AND CasoSau.ASSUNTO = '%s' ", acompanhamentoCasoFind.getCasoSau().getAssunto()));
        }
        if (acompanhamentoCasoFind.getEventoSelecionadoList() != null && !acompanhamentoCasoFind.getEventoSelecionadoList().isEmpty()) {
        	StringBuilder eventoIn = new StringBuilder();
            for (int i = 0; i < acompanhamentoCasoFind.getEventoSelecionadoList().size(); i++) {
            	if (i != 0) {
            		eventoIn.append(VIRGULA);
            	}
            	eventoIn.append(acompanhamentoCasoFind.getEventoSelecionadoList().get(i).getIdEvento());
            }
            select.append(String.format(" AND CasoSau.ID_EVENTO in (%s) ", eventoIn.toString()));
        }
        if (acompanhamentoCasoFind.getCanalSelecionadoList() != null && !acompanhamentoCasoFind.getCanalSelecionadoList().isEmpty()) {
        	StringBuilder canalIn = new StringBuilder();
            for (int i = 0; i < acompanhamentoCasoFind.getCanalSelecionadoList().size(); i++) {
            	if (i != 0) {
            		canalIn.append(VIRGULA);
            	}
            	canalIn.append(acompanhamentoCasoFind.getCanalSelecionadoList().get(i).getIdCanal());
            }
            select.append(String.format(" AND CasoSau.ID_CANAL in (%s) ", canalIn.toString()));
        }
        if (acompanhamentoCasoFind.getDataInicio() != null && acompanhamentoCasoFind.getDataFim() != null) {
        	select.append(String.format(" AND Caso.DATA_ABERTURA BETWEEN '%s' AND '%s'",
					DateUtil.convertDateStringWithHour(DateUtil.dataInicioDia(acompanhamentoCasoFind.getDataInicio())),
					DateUtil.convertDateStringWithHour(DateUtil.dataFimDia(acompanhamentoCasoFind.getDataFim()))));
        }
        if (acompanhamentoCasoFind.getDataInicioFechamento() != null && acompanhamentoCasoFind.getDataFimFechamento() != null) {
        	select.append(String.format(" AND Caso.DATA_ENCERRAMENTO BETWEEN '%s' AND '%s'",
					DateUtil.convertDateStringWithHour(DateUtil.dataInicioDia(acompanhamentoCasoFind.getDataInicioFechamento())),
					DateUtil.convertDateStringWithHour(DateUtil.dataFimDia(acompanhamentoCasoFind.getDataFimFechamento()))));
        }
        if (!StringUtils.isBlank(acompanhamentoCasoFind.getViaEntrada())){
        	select.append(String.format(" AND CasoSau.VIA_ENTRADA like '%s%s%s' ", "%",acompanhamentoCasoFind.getViaEntrada(), "%"));
        }
        
        if (acompanhamentoCasoFind.getFlagRechamadoCaso().equals('S')) {
        	select.append(" AND Caso.FLAG_REABERTO = 1 ");
        } else {
	        if (acompanhamentoCasoFind.getFlagRechamadoCaso().equals('N')) {
	        	select.append(" AND (Caso.FLAG_REABERTO = 0 ")
	        		  .append("  OR Caso.FLAG_REABERTO is null ) ");
	        }
        }
        
        if (acompanhamentoCasoFind.getCasoFechado() != null) {
        	select.append(" AND Caso.FLAG_FINALIZADO = ");
        	select.append(acompanhamentoCasoFind.getCasoFechado() ? "1 " : "0 ");
        }
    }

    @Override
    public List<CasoSau> buscaCasosAbertosOuComAtividadeRecente(Date dataUltimaAlteracao)
            throws DataException {
    	List<CasoSau> casoSauList = null;
    	PreparedStatement stmt = null;
        ResultSet resultSet = null;
        try {
            DateFormat formatter = new SimpleDateFormat("yyyy-dd-MM hh:mm:ss");
            String data = formatter.format(dataUltimaAlteracao);

            StringBuilder sql = new StringBuilder().append("SELECT distinct ").append(CasoSau.getSqlCamposCasoSau())
                    .append(VIRGULA).append(Caso.getSqlCamposCaso())
                    .append(FROM).append(CasoSau.getSqlFromCasoSau())
                    .append(" JOIN ").append(Caso.getSqlFromCaso())
                    .append(" ON CasoSau.id_caso = Caso.id_caso ")
                    .append(" JOIN tb_log AS Log with(nolock) on Log.id_caso = CasoSau.id_caso ")
                    .append(" where Log.data_log >= ").append(data).append(" OR Caso.flag_finalizado = 0");

            stmt = getPreparedStatement(sql.toString());
			
			stmt.execute();
			
			resultSet = stmt.getResultSet();

            if (resultSet != null) {
                casoSauList = new ArrayList<CasoSau>();
                while (resultSet.next()) {
                    CasoSau casoSau = CasoSau.getCasoSauByResultSet(resultSet);
                    Caso caso = Caso.getCasoByResultSet(resultSet);

                    casoSau.setCaso(caso);
                    casoSauList.add(casoSau);
                }
            }
            return casoSauList;
        } catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
    }

    @Override
    public List<CasoSau> buscaCasosAtivosPorStatus(List<Status> statusList) throws DataException {
    	List<CasoSau> casoSauList = new ArrayList<CasoSau>();
    	PreparedStatement stmt = null;
        ResultSet resultSet = null;
    	try {
    		StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(CasoSau.getSqlCamposCasoSau())
				.append(VIRGULA)
				.append(Caso.getSqlCamposCaso());
			
    		if (statusList != null) {
    			select.append(VIRGULA)
					  .append(Status.getSqlCamposStatus());
    		}
    		
			select.append(FROM)
				  .append(CasoSau.getSqlFromCasoSau())
				  .append(INNER_JOIN).append(Caso.getSqlFromCaso())
				  .append(" ON CasoSau.ID_CASO = Canal.ID_CASO ");
    		
    		if (statusList != null) {
    			select.append(INNER_JOIN).append(Status.getSqlFromStatus())
    				  .append(" ON Caso.ID_STATUS = Status.ID_STATUS ");
    		}
    		
    		select.append(WHERE)
    			  .append(" Caso.FLAG_FINALIZADO = 0 ");
    		
    		if (statusList != null) {
    			StringBuilder statusIn = new StringBuilder();
                for (int i = 0; i < statusList.size(); i++) {
                	if (i != 0) {
                		statusIn.append(VIRGULA);
                	}
                	statusIn.append(statusList.get(i).getIdStatus());
                }
                
                select.append(String.format(" AND Caso.ID_STATUS in (%s) ", statusIn.toString()));
    		}

            stmt = getPreparedStatement(select.toString());
			
			stmt.execute();
			
			resultSet = stmt.getResultSet();

            if (resultSet != null) {
                casoSauList = new ArrayList<CasoSau>();
                while (resultSet.next()) {
                    CasoSau casoSau = CasoSau.getCasoSauByResultSet(resultSet);
                    
                    Caso caso = Caso.getCasoByResultSet(resultSet);
                    caso.setStatus(Status.getStatusByResultSet(resultSet));
                    casoSau.setCaso(caso);
                    
                    casoSauList.add(casoSau);
                }
            }
            return casoSauList;
        } catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
    }

    @Override
    public List<CasoSau> buscaCasosFechadosNoDia() throws DataException {
    	List<CasoSau> casosSau = new ArrayList<CasoSau>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(CasoSau.getSqlCamposCasoSau())
				.append(VIRGULA)
				.append(Caso.getSqlCamposCaso())
				.append(FROM)
				.append(CasoSau.getSqlFromCasoSau())
				.append(INNER_JOIN).append(Caso.getSqlFromCaso())
				.append(" ON CasoSau.ID_CASO = Caso.ID_CASO ")
				.append(WHERE)
				.append(" Caso.FLAG_FINALIZADO = 1 ");
			
			Calendar dataInicio = new GregorianCalendar(Calendar.getInstance().get(Calendar.YEAR),
					Calendar.getInstance().get(Calendar.MONTH), Calendar.getInstance().get(Calendar.DAY_OF_MONTH), Integer.valueOf(0), Integer.valueOf(1));
	        Calendar dataFim = new GregorianCalendar(Calendar.getInstance().get(Calendar.YEAR),
	        		Calendar.getInstance().get(Calendar.MONTH), Calendar.getInstance().get(Calendar.DAY_OF_MONTH), Integer.valueOf(23), Integer.valueOf(59));
			
			select.append(" AND Caso.DATA_ENCERRAMENTO BETWEEN ? AND ? ");
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.setString(1, DateUtil.convertDateStringWithHour(DateUtil.dataInicioDia(dataInicio.getTime())));
			stmt.setString(2, DateUtil.convertDateStringWithHour(DateUtil.dataFimDia(dataFim.getTime())));
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					CasoSau casoSau = CasoSau.getCasoSauByResultSet(resultSet);
					casoSau.setCaso(Caso.getCasoByResultSet(resultSet));
					casosSau.add(casoSau);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return casosSau;
    }
    
    @Override
    public List<CasoSau> buscaCasosFechadosChecagemNoDia(Status id) throws DataException {
    	List<CasoSau> casosSau = new ArrayList<CasoSau>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(CasoSau.getSqlCamposCasoSau())
				.append(VIRGULA)
				.append(Caso.getSqlCamposCaso())
				.append(FROM)
				.append(CasoSau.getSqlFromCasoSau())
				.append(INNER_JOIN).append(Caso.getSqlFromCaso())
				.append(" ON CasoSau.ID_CASO = Caso.ID_CASO ")
				.append(WHERE)
				.append(" Caso.ID_STATUS = ? ");
			
			Calendar dataInicio = new GregorianCalendar(Calendar.getInstance().get(Calendar.YEAR),
					Calendar.getInstance().get(Calendar.MONTH), Calendar.getInstance().get(Calendar.DAY_OF_MONTH), Integer.valueOf(0), Integer.valueOf(1));
	        Calendar dataFim = new GregorianCalendar(Calendar.getInstance().get(Calendar.YEAR),
	        		Calendar.getInstance().get(Calendar.MONTH), Calendar.getInstance().get(Calendar.DAY_OF_MONTH), Integer.valueOf(23), Integer.valueOf(59));
	        
			select.append(" AND Caso.DATA_FIM_SLA BETWEEN ? AND ? ");
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.setInt(1, id.getIdStatus());
			stmt.setDate(2, new java.sql.Date(dataInicio.getTime().getTime()));
			stmt.setDate(3, new java.sql.Date(dataFim.getTime().getTime()));
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					CasoSau casoSau = CasoSau.getCasoSauByResultSet(resultSet);
					casoSau.setCaso(Caso.getCasoByResultSet(resultSet));
					casosSau.add(casoSau);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return casosSau;
    }

    @Override
    public List<CasoSau> buscaCasoAberto() throws DataException {
    	List<CasoSau> casosSau = new ArrayList<CasoSau>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(CasoSau.getSqlCamposCasoSau())
				.append(VIRGULA)
				.append(TipoManifestacao.getSqlCamposTipoManifestacao())
				.append(VIRGULA)
				.append(Caso.getSqlCamposCaso())
				.append(FROM)
				.append(CasoSau.getSqlFromCasoSau())
				.append(INNER_JOIN).append(TipoManifestacao.getSqlFromTipoManifestacao())
				.append(" ON CasoSau.ID_TIPO_CASO = TipoManifestacao.ID_TIPO_CASO ")
				.append(INNER_JOIN).append(Caso.getSqlFromCaso())
				.append(" ON CasoSau.ID_CASO = Caso.ID_CASO ")
				.append(WHERE)
				.append(" Caso.FLAG_FINALIZADO = 0 ")
				.append(" ORDER BY CasoSau.DATA_ABERTURA ");
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					CasoSau casoSau = CasoSau.getCasoSauByResultSet(resultSet);
					casoSau.setTipoManifestacao(TipoManifestacao.getTipoManifestacaoByResultSet(resultSet));
					casoSau.setCaso(Caso.getCasoByResultSet(resultSet));
					casosSau.add(casoSau);
				}
			}
		} catch (Exception ex) {
			throw new DataException("Erro ao buscar casos abertos.", ex);
		} finally {
			super.close(resultSet);
		}
		return casosSau;
    }
    

	@Override
    public List<CasoSau> buscaCasoAbertoSemPendencia(Integer statusPendente) throws DataException {
    	List<CasoSau> casosSau = new ArrayList<CasoSau>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(CasoSau.getSqlCamposCasoSau())
				.append(VIRGULA)
				.append(TipoManifestacao.getSqlCamposTipoManifestacao())
				.append(VIRGULA)
				.append(Caso.getSqlCamposCaso())
				.append(VIRGULA)
				.append(ConfiguracaoFila.getSqlCamposConfiguracaoFila())
				.append(FROM)
				.append(CasoSau.getSqlFromCasoSau())
				.append(INNER_JOIN).append(TipoManifestacao.getSqlFromTipoManifestacao())
				.append(" ON CasoSau.ID_TIPO_CASO = TipoManifestacao.ID_TIPO_CASO ")
				.append(INNER_JOIN).append(Caso.getSqlFromCaso())
				.append(" ON CasoSau.ID_CASO = Caso.ID_CASO ")
				.append(INNER_JOIN).append(ConfiguracaoFila.getSqlFromConfiguracaoFila())
				.append(" ON Caso.ID_CONFIGURACAO_FILA = ConfiguracaoFila.ID_CONFIGURACAO_FILA ")
				.append(WHERE)
				.append(" Caso.ID_STATUS <> ? ")
				.append(" AND Caso.FLAG_FINALIZADO = 0 ")
				.append(" AND Caso.DATA_FIM_SLA is null ")
				.append(" ORDER BY CasoSau.DATA_ABERTURA ");
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.setInt(1, statusPendente);
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					CasoSau casoSau = CasoSau.getCasoSauByResultSet(resultSet);
					casoSau.setTipoManifestacao(TipoManifestacao.getTipoManifestacaoByResultSet(resultSet));
					
					Caso caso = Caso.getCasoByResultSet(resultSet);
					caso.setConfiguracaoFila(ConfiguracaoFila.getConfiguracaoFilaByResultSet(resultSet));
					casoSau.setCaso(caso);
					
					casosSau.add(casoSau);
				}
			}
		} catch (Exception ex) {
			throw new DataException("Erro ao buscar casos abertos.", ex);
		} finally {
			super.close(resultSet);
		}
		return casosSau;
    }


    @Override
    public List<CasoSau> buscaCasoAbertoAssunto() throws DataException {
    	List<CasoSau> casosSau = new ArrayList<CasoSau>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(CasoSau.getSqlCamposCasoSau())
				.append(VIRGULA)
				.append(TipoManifestacao.getSqlCamposTipoManifestacao())
				.append(VIRGULA)
				.append(Evento.getSqlEvento())
				.append(VIRGULA)
				.append(Assunto.getSqlAssunto())
				.append(VIRGULA)
				.append(Caso.getSqlCamposCaso())
				.append(FROM)
				.append(CasoSau.getSqlFromCasoSau())
				.append(INNER_JOIN).append(TipoManifestacao.getSqlFromTipoManifestacao())
				.append(" ON CasoSau.ID_TIPO_CASO = TipoManifestacao.ID_TIPO_CASO ")
				.append(INNER_JOIN).append(Evento.getSqlFromEvento())
				.append(" ON CasoSau.ID_EVENTO = Evento.ID_EVENTO ")
				.append(INNER_JOIN).append(Assunto.getSqlFromAssunto())
				.append(" ON Evento.ID_ASSUNTO = Assunto.ID_ASSUNTO ")
				.append(INNER_JOIN).append(Caso.getSqlFromCaso())
				.append(" ON CasoSau.ID_CASO = Caso.ID_CASO ")
				.append(WHERE)
				.append(" Caso.FLAG_FINALIZADO = 0 ")
				.append(" ORDER BY CasoSau.ID_TIPO_CASO ");
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					CasoSau casoSau = CasoSau.getCasoSauByResultSet(resultSet);
					casoSau.setTipoManifestacao(TipoManifestacao.getTipoManifestacaoByResultSet(resultSet));
					
					Evento evento = Evento.getEventoByResultSet(resultSet);
					evento.setAssunto(Assunto.getAssuntoByResultSet(resultSet));
					casoSau.setEvento(evento);
					
					casoSau.setCaso(Caso.getCasoByResultSet(resultSet));
					
					casosSau.add(casoSau);
				}
			}
		} catch (Exception ex) {
			throw new DataException("Erro ao buscar casos abertos.", ex);
		} finally {
			super.close(resultSet);
		}
		return casosSau;
    }

    @Override
    public List<CasoSau> buscaCasoEntranteDia() throws DataException {
    	List<CasoSau> casosSau = new ArrayList<CasoSau>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(CasoSau.getSqlCamposCasoSau())
				.append(VIRGULA)
				.append(Caso.getSqlCamposCaso())
				.append(FROM)
				.append(CasoSau.getSqlFromCasoSau())
				.append(INNER_JOIN).append(Caso.getSqlFromCaso())
				.append(" ON CasoSau.ID_CASO = Caso.ID_CASO ")
				.append(WHERE_1_1);
				//.append(" Caso.FLAG_FINALIZADO = 0 ");
			
			Calendar dataInicio = new GregorianCalendar(Calendar.getInstance().get(Calendar.YEAR),
					Calendar.getInstance().get(Calendar.MONTH), Calendar.getInstance().get(Calendar.DAY_OF_MONTH), Integer.valueOf(0), Integer.valueOf(0));
            Calendar dataFim = new GregorianCalendar(Calendar.getInstance().get(Calendar.YEAR),
            		Calendar.getInstance().get(Calendar.MONTH), Calendar.getInstance().get(Calendar.DAY_OF_MONTH), Integer.valueOf(23), Integer.valueOf(59));
			
			select.append(" AND Caso.DATA_CADASTRO BETWEEN ? AND ? ");
			select.append(" ORDER BY CasoSau.DATA_ABERTURA ");
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.setString(1, DateUtil.convertDateStringWithHour(DateUtil.dataInicioDia(dataInicio.getTime())));
			stmt.setString(2, DateUtil.convertDateStringWithHour(DateUtil.dataFimDia(dataFim.getTime())));
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					CasoSau casoSau = CasoSau.getCasoSauByResultSet(resultSet);
					casoSau.setCaso(Caso.getCasoByResultSet(resultSet));
					casosSau.add(casoSau);
				}
			}
		} catch (Exception ex) {
			throw new DataException("Erro ao buscar casos abertos.", ex);
		} finally {
			super.close(resultSet);
		}
		return casosSau;
    }

    @Override
    public List<CasoSau> buscaCasoReabertoDia() throws DataException {
    	List<CasoSau> casosSau = new ArrayList<CasoSau>();
		PreparedStatement stmt = null;
        ResultSet resultSet = null;
        try {
            Calendar dataInicio = new GregorianCalendar(Calendar.getInstance().get(Calendar.YEAR), Calendar.getInstance().get(Calendar.MONTH), Calendar.getInstance().get(Calendar.DAY_OF_MONTH), Integer.valueOf(0), Integer.valueOf(0));
            Calendar dataFim = new GregorianCalendar(Calendar.getInstance().get(Calendar.YEAR), Calendar.getInstance().get(Calendar.MONTH), Calendar.getInstance().get(Calendar.DAY_OF_MONTH), Integer.valueOf(23), Integer.valueOf(59));
                    
            StringBuilder sql = new StringBuilder().append("SELECT ")
                    .append(CasoSau.getSqlCamposCasoSau()).append(VIRGULA).append(Caso.getSqlCamposCaso())
                    .append(FROM).append(CasoSau.getSqlFromCasoSau()).append(VIRGULA)
                    .append(Caso.getSqlFromCaso()).append(VIRGULA)
                    .append(" tb_reabertura_caso Reabertura with(nolock) ").append(WHERE)
                    .append(" Reabertura.data_reabertura BETWEEN ? AND ? ")
                    .append(" and Reabertura.id_caso = Caso.id_caso and Caso.id_caso = CasoSau.id_caso ");

            stmt = getPreparedStatement(sql.toString());
			
			stmt.setString(1, DateUtil.convertDateStringWithHour(DateUtil.dataInicioDia(dataInicio.getTime())));
			stmt.setString(2, DateUtil.convertDateStringWithHour(DateUtil.dataFimDia(dataFim.getTime())));
            
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					CasoSau casoSau = CasoSau.getCasoSauByResultSet(resultSet);
					casoSau.setCaso(Caso.getCasoByResultSet(resultSet));
					casosSau.add(casoSau);
				}
			}
		} catch (Exception ex) {
			throw new DataException("Erro ao buscar casos abertos.", ex);
		} finally {
			super.close(resultSet);
		}
		return casosSau;
    }
    
    /**
     * Buscar todos os casos por um determinado numero de CPF ou CNPJ.
     * 
     * @param cpfCnpj
     * @return casoSauList
     * @throws DataException
     */
    @Override
    public List<CasoSau> buscarCasoSauPorCpfCnpj(String cpfCnpj) throws DataException {
    	List<CasoSau> casosSau = new ArrayList<CasoSau>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(CasoSau.getSqlCamposCasoSau())
				.append(VIRGULA)
				.append(Canal.getSqlCamposCanal())
				.append(VIRGULA)
				.append(TipoManifestacao.getSqlCamposTipoManifestacao())
				.append(VIRGULA)
				.append(Evento.getSqlEvento())
				.append(VIRGULA)
				.append(Assunto.getSqlAssunto())
				.append(VIRGULA)
				.append(Caso.getSqlCamposCaso())
				.append(VIRGULA)
				.append(Status.getSqlCamposStatus())
				.append(VIRGULA)
				.append(Atendente.getSqlCamposAtendente())
				.append(FROM)
				.append(CasoSau.getSqlFromCasoSau())
				.append(INNER_JOIN).append(Canal.getSqlFromCanal())
				.append(" ON CasoSau.ID_CANAL = Canal.ID_CANAL")
				.append(INNER_JOIN).append(TipoManifestacao.getSqlFromTipoManifestacao())
				.append(" ON CasoSau.ID_TIPO_CASO = TipoManifestacao.ID_TIPO_CASO ")
				.append(LEFT_JOIN).append(Evento.getSqlFromEvento())
				.append(" ON CasoSau.ID_EVENTO = Evento.ID_EVENTO ")
				.append(LEFT_JOIN).append(Assunto.getSqlFromAssunto())
				.append(" ON Evento.ID_ASSUNTO = Assunto.ID_ASSUNTO ")
				.append(INNER_JOIN).append(Caso.getSqlFromCaso())
				.append(" ON CasoSau.ID_CASO = Caso.ID_CASO ")
				.append(INNER_JOIN).append(Status.getSqlFromStatus())
				.append(" ON Caso.ID_STATUS = Status.ID_STATUS ")
				.append(LEFT_JOIN).append(Atendente.getSqlFromAtendente())
				.append(" ON Caso.ID_ATENDENTE = Atendente.ID_ATENDENTE ")
				.append(WHERE)
				.append(" CasoSau.CPF_CNPJ = ? ");
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.setString(1, cpfCnpj);
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					CasoSau casoSau = CasoSau.getCasoSauByResultSet(resultSet);
					casoSau.setCanal(Canal.getCanalByResultSet(resultSet));
					casoSau.setTipoManifestacao(TipoManifestacao.getTipoManifestacaoByResultSet(resultSet));
					
					Evento evento = Evento.getEventoByResultSet(resultSet);
					evento.setAssunto(Assunto.getAssuntoByResultSet(resultSet));
					casoSau.setEvento(evento);
					
					Caso caso = Caso.getCasoByResultSet(resultSet);
					caso.setStatus(Status.getStatusByResultSet(resultSet));
					caso.setAtendente(Atendente.getAtendenteByResultSet(resultSet));
					casoSau.setCaso(caso);
					
					casosSau.add(casoSau);
				}
			}
		} catch (SQLException ex) {
			throw new DataException("Erro ao buscar casos por cpf ou cnpj.", ex);
		} finally {
			super.close(resultSet);
		}
		return casosSau;
    }
   
    @Override
	public Integer buscarQtdCasoAbertoPorCpfCnpj(String cpfCnpj) throws DataException {
    	PreparedStatement stmt = null;
		ResultSet resultSet = null;
		Integer casos = 0;
    	try {
    		StringBuilder string = new StringBuilder();
    		string.append("select count(*) qtdCasos FROM TB_CASO_SAU  AS CasoSau  with(nolock) ")
    				.append("INNER JOIN TB_CASO AS Caso with(nolock) ON Caso.ID_CASO = CasoSau.ID_CASO ")
    				.append("WHERE CasoSau.CPF_CNPJ = ? AND Caso.flag_finalizado = 0 ");
    		
    		stmt = getPreparedStatement(string.toString());
			
			stmt.setString(1, cpfCnpj);
			
			stmt.execute();
			resultSet = stmt.getResultSet();
    		
    		if(resultSet != null) {
             	while(resultSet.next()) {
             		casos = resultSet.getInt("qtdCasos");
             	}
             }
    		 return casos;
    	} catch (SQLException e) {
    		throw new DataException("Erro ao buscar quantidade de casos por cpf ou cnpj", e);
    	} finally {
			super.close(resultSet);
		}
    }
    
    @Override
	public CasoSau findByPk(Object id) throws DataException {
    	CasoSau result = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(CasoSau.getSqlCamposCasoSau())
				.append(VIRGULA)
				.append(Caso.getSqlCamposCaso())
				.append(VIRGULA)
				.append(Causa.getSqlCausa())
				.append(VIRGULA)
				.append(Evento.getSqlEvento())
				.append(VIRGULA)
				.append(Canal.getSqlCamposCanal())
				.append(VIRGULA)
				.append(TipoManifestacao.getSqlCamposTipoManifestacao())
				.append(VIRGULA)
				.append(Estado.getSqlEstado())
				.append(VIRGULA)
				.append(Juncao.getSqlCamposJuncao())
				.append(VIRGULA)
				.append(OutraArea.getSqlOutraArea())
				.append(VIRGULA)
				.append(" \nJuncaoAtraso.ID_JUNCAO AS 'JuncaoAtraso.ID_JUNCAO', ")
                .append(" \nJuncaoAtraso.NOME AS 'JuncaoAtraso.NOME', ")
                .append(" \nJuncaoAtraso.DATA_CRIACAO AS 'JuncaoAtraso.DATA_CRIACAO', ")
                .append(" \nJuncaoAtraso.FLAG_ATIVO AS 'JuncaoAtraso.FLAG_ATIVO' ")
				.append(FROM)
				.append(CasoSau.getSqlFromCasoSau())
				.append(INNER_JOIN).append(Caso.getSqlFromCaso())
				.append(" ON CasoSau.ID_CASO = Caso.ID_CASO ")
				.append(LEFT_JOIN).append(Causa.getSqlFromCausa())
				.append(" ON CasoSau.ID_CAUSA = Causa.ID_CAUSA ")
				.append(LEFT_JOIN).append(Evento.getSqlFromEvento())
				.append(" ON CasoSau.ID_EVENTO = Evento.ID_EVENTO ")
				.append(INNER_JOIN).append(Canal.getSqlFromCanal())
				.append(" ON CasoSau.ID_CANAL = Canal.ID_CANAL ")
				.append(INNER_JOIN).append(TipoManifestacao.getSqlFromTipoManifestacao())
				.append(" ON CasoSau.ID_TIPO_CASO = TipoManifestacao.ID_TIPO_CASO ")
				.append(LEFT_JOIN).append(Estado.getSqlFromEstado())
				.append(" ON CasoSau.ID_ESTADO = Estado.ID_ESTADO ")
				.append(LEFT_JOIN).append(Juncao.getSqlFromJuncao())
				.append(" ON CasoSau.ID_JUNCAO = Juncao.ID_JUNCAO ")
				.append(LEFT_JOIN).append(OutraArea.getSqlFromOutraArea())
				.append(" ON CasoSau.ID_OUTRA_AREA = OutraArea.ID_OUTRA_AREA ")
				.append(LEFT_JOIN).append(" TB_JUNCAO AS JuncaoAtraso with(nolock) ")
				.append(" ON CasoSau.ID_JUNCAO_ATRAZO = JuncaoAtraso.ID_JUNCAO ")
				.append(" WHERE CasoSau.ID_CASO_SAU = ? ");
			
			stmt = getPreparedStatement(select.toString());
			
			CasoSau casoSau = (CasoSau) id;
			
			stmt.setInt(1, casoSau.getIdCasoSau());
			
			stmt.execute();
			
			resultSet = stmt.getResultSet();
			if (resultSet != null && resultSet.next()) {
				result = CasoSau.getCasoSauByResultSet(resultSet);
				result.setCaso(Caso.getCasoByResultSet(resultSet));
				result.setCausa(Causa.getCausaByResultSet(resultSet));
				result.setEvento(Evento.getEventoByResultSet(resultSet));
				result.setCanal(Canal.getCanalByResultSet(resultSet));
				result.setTipoManifestacao(TipoManifestacao.getTipoManifestacaoByResultSet(resultSet));
				result.setEstado(Estado.getEstadoByResultSet(resultSet));
				result.setJuncao(Juncao.getJuncaoByResultSet(resultSet));
				result.setOutraArea(OutraArea.getOutraAreaByResultSet(resultSet));
				
				Juncao juncaoAtraso = new Juncao();
				juncaoAtraso.setIdJuncao(resultSet.getInt("JuncaoAtraso.ID_JUNCAO"));
				juncaoAtraso.setNome(resultSet.getString("JuncaoAtraso.NOME"));
				juncaoAtraso.setDataCriacao(resultSet.getTimestamp("JuncaoAtraso.DATA_CRIACAO"));
				juncaoAtraso.setFlagAtivo(resultSet.getBoolean("JuncaoAtraso.FLAG_ATIVO"));
				result.setJuncaoAtrazo(juncaoAtraso);
			}
		} catch (SQLException e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		return result;
	}
	
	@Override
	public List<CasoSau> findByExample(CasoSau example) throws DataException {
		return findByExample(example, null);
	}
	
	@Override
	public List<CasoSau> findByExample(CasoSau example, String order) throws DataException {
		List<CasoSau> casosSau = new ArrayList<CasoSau>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		int index = 0;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(CasoSau.getSqlCamposCasoSau())
				.append(FROM)
				.append(CasoSau.getSqlFromCasoSau())
				.append(WHERE_1_1);
			
			if (example.getIdCasoSau() != null) {
				select.append(" AND CasoSau.ID_CASO_SAU = ? ");
			}
			if (example.getManifestacao() != null && !example.getManifestacao().isEmpty()) {
				select.append(" AND CasoSau.MANIFESTACAO = ? ");
			}
			if (example.getDataAbertura() != null) {
				select.append(" AND CasoSau.DATA_ABERTURA BETWEEN ? AND ? ");
			}
			if (example.getDataUltimaAcao() != null) {
				select.append(" AND CasoSau.DATA_ULTIMA_ACAO BETWEEN ? AND ? ");
			}
			if (example.getUltimoAtendente() != null && !example.getUltimoAtendente().isEmpty()) {
				select.append(" AND CasoSau.ULTIMO_ATENDENTE = ? ");
			}
			if (example.getAtendenteAtual() != null && !example.getAtendenteAtual().isEmpty()) {
				select.append(" AND CasoSau.ATENDENTE_ATUAL = ? ");
			}
			if (example.getAgenciaDepartamento() != null && !example.getAgenciaDepartamento().isEmpty()) {
				select.append(" AND CasoSau.AGENCIA_DEPARTAMENTO = ? ");
			}
			if (example.getNomeCliente() != null && !example.getNomeCliente().isEmpty()) {
				select.append(" AND CasoSau.NOME_CLIENTE = ? ");
			}
			if (example.getAgenciaConta() != null && !example.getAgenciaConta().isEmpty()) {
				select.append(" AND CasoSau.AGENCIA_CONTA = ? ");
			}
			if (example.getCpfCnpj() != null && !example.getCpfCnpj().isEmpty()) {
				select.append(" AND CasoSau.CPF_CNPJ = ? ");
			}
			if (example.getEmail() != null && !example.getEmail().isEmpty()) {
				select.append(" AND CasoSau.EMAIL = ? ");
			}
			if (example.getTelefone() != null && !example.getTelefone().isEmpty()) {
				select.append(" AND CasoSau.TELEFONE = ? ");
			}
			if (example.getTelefoneSegundo() != null && !example.getTelefoneSegundo().isEmpty()) {
				select.append(" AND CasoSau.TELEFONE_SEGUNDO = ? ");
			}
			if (example.getEndereco() != null && !example.getEndereco().isEmpty()) {
				select.append(" AND CasoSau.ENDERECO = ? ");
			}
			if (example.getCep() != null && !example.getCep().isEmpty()) {
				select.append(" AND CasoSau.CEP = ? ");
			}
			if (example.getFlagManual() != null) {
				select.append(" AND CasoSau.FLAG_MANUAL = ? ");
			}
			if (example.getEnvioProtocoloCliente() != null && !example.getEnvioProtocoloCliente().isEmpty()) {
				select.append(" AND CasoSau.ENVIO_PROTOCOLO_CLIENTE = ? ");
			}
			if (example.getViaEntrada() != null && !example.getViaEntrada().isEmpty()) {
				select.append(" AND CasoSau.VIA_ENTRADA = ? ");
			}
			if (example.getDescricao() != null && !example.getDescricao().isEmpty()) {
				select.append(" AND CasoSau.DESCRICAO = ? ");
			}
			if (example.getAssunto() != null && !example.getAssunto().isEmpty()) {
				select.append(" AND CasoSau.ASSUNTO = ? ");
			}
			if (example.getGrupo() != null && !example.getGrupo().isEmpty()) {
				select.append(" AND CasoSau.GRUPO = ? ");
			}
			if (example.getSubGrupo() != null && !example.getSubGrupo().isEmpty()) {
				select.append(" AND CasoSau.SUB_GRUPO = ? ");
			}
			if (example.getNomeCausa() != null && !example.getNomeCausa().isEmpty()) {
				select.append(" AND CasoSau.NOME_CAUSA = ? ");
			}
			if (example.getCartao() != null && !example.getCartao().isEmpty()) {
				select.append(" AND CasoSau.CARTAO = ? ");
			}
			if (example.getTipoCartao() != null && !example.getTipoCartao().isEmpty()) {
				select.append(" AND CasoSau.TIPO_CARTAO = ? ");
			}
			if (example.getTipoManifestacaoSTGM() != null && !example.getTipoManifestacaoSTGM().isEmpty()) {
				select.append(" AND CasoSau.TIPO_MANIFESTACAO = ? ");
			}
			if (example.getCaso() != null && example.getCaso().getIdCaso() != null) {
				select.append(" AND CasoSau.ID_CASO = ? ");
			}
			if (example.getCausa() != null && example.getCausa().getIdCausa() != null) {
				select.append(" AND CasoSau.ID_CAUSA = ? ");
			}
			if (example.getEvento() != null && example.getEvento().getIdEvento() != null) {
				select.append(" AND CasoSau.ID_EVENTO = ? ");
			}
			if (example.getCanal() != null && example.getCanal().getIdCanal() != null) {
				select.append(" AND CasoSau.ID_CANAL = ? ");
			}
			if (example.getTipoManifestacao() != null && example.getTipoManifestacao().getIdTipoCaso() != null) {
				select.append(" AND CasoSau.ID_TIPO_CASO = ? ");
			}
			if (example.getEstado() != null && example.getEstado().getIdEstado() != null) {
				select.append(" AND CasoSau.ID_ESTADO = ? ");
			}
			if (example.getJuncao() != null && example.getJuncao().getIdJuncao() != null) {
				select.append(" AND CasoSau.ID_JUNCAO = ? ");
			}
			if (example.getOutraArea() != null && example.getOutraArea().getIdOutraArea() != null) {
				select.append(" AND CasoSau.ID_OUTRA_AREA = ? ");
			}
			if (example.getJuncaoAtrazo() != null && example.getJuncaoAtrazo().getIdJuncao() != null) {
				select.append(" AND CasoSau.ID_CASO = ? ");
			}
			
			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());

			if (example.getIdCasoSau() != null) {
				stmt.setInt(++index, example.getIdCasoSau());
			}
			if (example.getManifestacao() != null && !example.getManifestacao().isEmpty()) {
				stmt.setString(++index, example.getManifestacao());
			}
			if (example.getDataAbertura() != null) {
				Date dataInicio = DateUtil.dataInicioDia(example.getDataAbertura());
				Date dataFim = DateUtil.dataFimDia(example.getDataAbertura());
				
				stmt.setString(++index, DateUtil.convertDateStringWithHour(DateUtil.dataInicioDia(dataInicio)));
				stmt.setString(++index, DateUtil.convertDateStringWithHour(DateUtil.dataFimDia(dataFim)));
				
			}
			if (example.getDataUltimaAcao() != null) {
				Date dataInicio = DateUtil.dataInicioDia(example.getDataUltimaAcao());
				Date dataFim = DateUtil.dataFimDia(example.getDataUltimaAcao());
				
				stmt.setString(++index, DateUtil.convertDateStringWithHour(DateUtil.dataInicioDia(dataInicio)));
				stmt.setString(++index, DateUtil.convertDateStringWithHour(DateUtil.dataFimDia(dataFim)));
				
			}
			if (example.getUltimoAtendente() != null && !example.getUltimoAtendente().isEmpty()) {
				stmt.setString(++index, example.getUltimoAtendente());
			}
			if (example.getAtendenteAtual() != null && !example.getAtendenteAtual().isEmpty()) {
				stmt.setString(++index, example.getAtendenteAtual());
			}
			if (example.getAgenciaDepartamento() != null && !example.getAgenciaDepartamento().isEmpty()) {
				stmt.setString(++index, example.getAgenciaDepartamento());
			}
			if (example.getNomeCliente() != null && !example.getNomeCliente().isEmpty()) {
				stmt.setString(++index, example.getNomeCliente());
			}
			if (example.getAgenciaConta() != null && !example.getAgenciaConta().isEmpty()) {
				stmt.setString(++index, example.getAgenciaConta());
			}
			if (example.getCpfCnpj() != null && !example.getCpfCnpj().isEmpty()) {
				stmt.setString(++index, example.getCpfCnpj());
			}
			if (example.getEmail() != null && !example.getEmail().isEmpty()) {
				stmt.setString(++index, example.getEmail());
			}
			if (example.getTelefone() != null && !example.getTelefone().isEmpty()) {
				stmt.setString(++index, example.getTelefone());
			}
			if (example.getTelefoneSegundo() != null && !example.getTelefoneSegundo().isEmpty()) {
				stmt.setString(++index, example.getTelefoneSegundo());
			}
			if (example.getEndereco() != null && !example.getEndereco().isEmpty()) {
				stmt.setString(++index, example.getEndereco());
			}
			if (example.getCep() != null && !example.getCep().isEmpty()) {
				stmt.setString(++index, example.getCep());
			}
			if (example.getFlagManual() != null) {
				stmt.setBoolean(++index, example.getFlagManual());
			}
			if (example.getEnvioProtocoloCliente() != null && !example.getEnvioProtocoloCliente().isEmpty()) {
				stmt.setString(++index,example.getEnvioProtocoloCliente() );
			}
			if (example.getViaEntrada() != null && !example.getViaEntrada().isEmpty()) {
				stmt.setString(++index, example.getViaEntrada());
			}
			if (example.getDescricao() != null && !example.getDescricao().isEmpty()) {
				stmt.setString(++index, example.getDescricao());
			}
			if (example.getAssunto() != null && !example.getAssunto().isEmpty()) {
				stmt.setString(++index, example.getAssunto());
			}
			if (example.getGrupo() != null && !example.getGrupo().isEmpty()) {
				stmt.setString(++index, example.getGrupo());
			}
			if (example.getSubGrupo() != null && !example.getSubGrupo().isEmpty()) {
				stmt.setString(++index, example.getSubGrupo());
			}
			if (example.getNomeCausa() != null && !example.getNomeCausa().isEmpty()) {
				stmt.setString(++index, example.getNomeCausa());
			}
			if (example.getCartao() != null && !example.getCartao().isEmpty()) {
				stmt.setString(++index, example.getCartao());
			}
			if (example.getTipoCartao() != null && !example.getTipoCartao().isEmpty()) {
				stmt.setString(++index, example.getTipoCartao());
			}
			if (example.getTipoManifestacaoSTGM() != null && !example.getTipoManifestacaoSTGM().isEmpty()) {
				stmt.setString(++index, example.getTipoManifestacaoSTGM());
			}
			if (example.getCaso() != null && example.getCaso().getIdCaso() != null) {
				stmt.setInt(++index, example.getCaso().getIdCaso());
			}
			if (example.getCausa() != null && example.getCausa().getIdCausa() != null) {
				stmt.setInt(++index, example.getCausa().getIdCausa());
			}
			if (example.getEvento() != null && example.getEvento().getIdEvento() != null) {
				stmt.setInt(++index, example.getEvento().getIdEvento());
			}
			if (example.getCanal() != null && example.getCanal().getIdCanal() != null) {
				stmt.setInt(++index, example.getCanal().getIdCanal());
			}
			if (example.getTipoManifestacao() != null && example.getTipoManifestacao().getIdTipoCaso() != null) {
				stmt.setInt(++index, example.getTipoManifestacao().getIdTipoCaso());
			}
			if (example.getEstado() != null && example.getEstado().getIdEstado() != null) {
				stmt.setInt(++index, example.getEstado().getIdEstado());
			}
			if (example.getJuncao() != null && example.getJuncao().getIdJuncao() != null) {
				stmt.setInt(++index, example.getJuncao().getIdJuncao());
			}
			if (example.getOutraArea() != null && example.getOutraArea().getIdOutraArea() != null) {
				stmt.setInt(++index, example.getOutraArea().getIdOutraArea());
			}
			if (example.getJuncaoAtrazo() != null && example.getJuncaoAtrazo().getIdJuncao() != null) {
				stmt.setInt(++index, example.getJuncaoAtrazo().getIdJuncao());
			}
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					CasoSau casoSau = CasoSau.getCasoSauByResultSet(resultSet);
					casosSau.add(casoSau);
				}
			}
		} catch (SQLException ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return casosSau;
	}
	
	@Override
	public List<CasoSau> findAll() throws DataException {
		return findAll(null);
	}
	
	@Override
	public List<CasoSau> findAll(String order) throws DataException {
		List<CasoSau> casosSau = new ArrayList<CasoSau>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(CasoSau.getSqlCamposCasoSau())
				.append(FROM)
				.append(CasoSau.getSqlFromCasoSau());
			
			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					CasoSau casoSau = CasoSau.getCasoSauByResultSet(resultSet);
					casosSau.add(casoSau);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return casosSau;
	}
	
	@Override
	public List<CasoSau> findAtivos() throws DataException {
		return findAtivos(null);
	}
	
	@Override
	public List<CasoSau> findAtivos(String order) throws DataException {
		throw new DataException("Entidade não possui coluna flag_ativo!");
	}

	@Override
	public void flush() {
		getEntityManager().flush();
	}
    
}
