package br.com.callink.cad.sau.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import br.com.callink.cad.pojo.Util.DateUtil;
import br.com.callink.cad.sau.dao.ICausaDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.Causa;

public class CausaDAO extends GenericCadSauDAO<Causa> implements ICausaDAO{
    
	private static final long serialVersionUID = -6017120739929359494L;

	public CausaDAO() {
		super(Causa.class);
	}
	
	@Override
	public Causa findByPk(Object id) throws DataException {
		Causa result = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Causa.getSqlCausa())
				.append(FROM)
				.append(Causa.getSqlFromCausa())
				.append(" WHERE Causa.ID_CAUSA = ? ");
			
			stmt = getPreparedStatement(select.toString());
			
			Causa causa = (Causa) id;
			
			stmt.setInt(1, causa.getIdCausa());
			
			stmt.execute();
			
			resultSet = stmt.getResultSet();
			if (resultSet != null && resultSet.next()) {
				result = Causa.getCausaByResultSet(resultSet);
			}
		} catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		return result;
	}
	
	@Override
	public List<Causa> findByExample(Causa example) throws DataException {
		return findByExample(example, null);
	}
	
	@Override
	public List<Causa> findByExample(Causa example, String order) throws DataException {
		List<Causa> causas = new ArrayList<Causa>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		int index = 0;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Causa.getSqlCausa())
				.append(FROM)
				.append(Causa.getSqlFromCausa())
				.append(WHERE_1_1);
			
			if (example.getIdCausa() != null) {
				select.append(" AND Causa.ID_CAUSA = ? ");
			}
			if (example.getNome() != null && !example.getNome().isEmpty()) {
				select.append(" AND Causa.NOME like ? ");
			}
			if (example.getDataCriacao() != null) {
				select.append(" AND Causa.DATA_CRIACAO BETWEEN ? AND ? ");
			}
			if (example.getFlagAtivo() != null) {
				select.append(" AND Causa.FLAG_ATIVO = ? ");
			}
			
			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			if (example.getIdCausa() != null) {
				stmt.setInt(++index, example.getIdCausa());
			}
			if (example.getNome() != null && !example.getNome().isEmpty()) {
				stmt.setString(++index, new StringBuilder(example.getNome()).append("%").toString());
			}
			if (example.getDataCriacao() != null) {
				Date dataInicio = DateUtil.dataInicioDia(example.getDataCriacao());
				Date dataFim = DateUtil.dataFimDia(example.getDataCriacao());
				stmt.setDate(++index, new java.sql.Date(dataInicio.getTime()));
				stmt.setDate(++index, new java.sql.Date(dataFim.getTime()));
			}
			if (example.getFlagAtivo() != null) {
				stmt.setBoolean(++index, example.getFlagAtivo());
			}
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					Causa causa = Causa.getCausaByResultSet(resultSet);
					causas.add(causa);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return causas;
	}
	
	@Override
	public List<Causa> findAll() throws DataException {
		return findAll(null);
	}
	
	@Override
	public List<Causa> findAll(String order) throws DataException {
		List<Causa> causas = new ArrayList<Causa>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Causa.getSqlCausa())
				.append(FROM)
				.append(Causa.getSqlFromCausa());
			
			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					Causa causa = Causa.getCausaByResultSet(resultSet);
					causas.add(causa);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return causas;
	}
	
	@Override
	public List<Causa> findAtivos() throws DataException {
		return findAtivos(null);
	}
	
	@Override
	public List<Causa> findAtivos(String order) throws DataException {
		List<Causa> causas = new ArrayList<Causa>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Causa.getSqlCausa())
				.append(FROM)
				.append(Causa.getSqlFromCausa())
				.append(WHERE)
				.append(" Causa.FLAG_ATIVO = 1 ");
			
			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					Causa causa = Causa.getCausaByResultSet(resultSet);
					causas.add(causa);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return causas;
	}
	
}
