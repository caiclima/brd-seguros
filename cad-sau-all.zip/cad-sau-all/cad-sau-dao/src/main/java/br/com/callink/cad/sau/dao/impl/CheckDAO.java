package br.com.callink.cad.sau.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.callink.cad.sau.dao.ICheckDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.Check;
import br.com.callink.cad.sau.pojo.Checklist;

public class CheckDAO extends GenericCadSauDAO<Check> implements ICheckDAO {

	private static final long serialVersionUID = -6433854015469751309L;

	public CheckDAO() {
		super(Check.class);
	}
	
    @Override
    public List<Check> findAllCheckByChecklist(Checklist checklist) throws DataException {
    	List<Check> checks = new ArrayList<Check>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Check.getSqlCamposCheck())
				.append(FROM)
				.append(Check.getSqlFromCheck())
				.append(WHERE)
				.append(" Chec.ID_CHECKLIST = ? ")
				.append(" ORDER BY Chec.ORDEM ");
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.setInt(1, checklist.getIdChecklist());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					Check check = Check.getCheckByResultSet(resultSet);
					checks.add(check);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return checks;
    }
    
    @Override
	public Check findByPk(Object id) throws DataException {
    	Check result = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Check.getSqlCamposCheck())
				.append(", ")
				.append(Checklist.getSqlCamposChecklist())
				.append(", ")
				.append(" \nCheckPai.ID_CHECK AS 'CheckPai.ID_CHECK', ")
                .append(" \nCheckPai.ID_CHECK_PAI AS 'CheckPai.ID_CHECK_PAI', ")
                .append(" \nCheckPai.ID_CHECKLIST AS 'CheckPai.ID_CHECKLIST', ")
                .append(" \nCheckPai.DESCRICAO AS 'CheckPai.DESCRICAO', ")
                .append(" \nCheckPai.RESPOSTAS_POSSIVEIS AS 'CheckPai.RESPOSTAS_POSSIVEIS', ")
                .append(" \nCheckPai.RESPOSTA_PADRAO AS 'CheckPai.RESPOSTA_PADRAO', ")
                .append(" \nCheckPai.FLAG_ENABLED AS 'CheckPai.FLAG_ENABLED', ")
                .append(" \nCheckPai.ORDEM AS 'CheckPai.ORDEM', ")
                .append(" \nCheckPai.OPERADOR_APRESENTACAO AS 'CheckPai.OPERADOR_APRESENTACAO', ")
                .append(" \nCheckPai.RESPOSTA_APRESENTACAO AS 'CheckPai.RESPOSTA_APRESENTACAO' ")
				.append(FROM)
				.append(Check.getSqlFromCheck())
				.append(INNER_JOIN).append(Checklist.getSqlFromChecklist())
				.append(" ON Chec.ID_CHECKLIST = Checklist.ID_CHECKLIST ")
				.append(LEFT_JOIN).append(" TB_CHECK  AS CheckPai with(nolock) ")
				.append(" ON Chec.ID_CHECK_PAI = CheckPai.ID_CHECK ")
				.append(" WHERE Chec.ID_CHECK = ? ");
			
			stmt = getPreparedStatement(select.toString());
			
			Check check = (Check) id;
			
			stmt.setInt(1, check.getIdCheck());
			
			stmt.execute();
			
			resultSet = stmt.getResultSet();
			if (resultSet != null && resultSet.next()) {
				result = Check.getCheckByResultSet(resultSet);
				result.setChecklist(Checklist.getChecklistByResultSet(resultSet));
				
				Check checkPai = new Check();
				checkPai.setIdCheck(resultSet.getInt("CheckPai.ID_CHECK"));
				checkPai.setCheckPai(new Check(resultSet.getInt("CheckPai.ID_CHECK_PAI")));
				checkPai.setChecklist(new Checklist(resultSet.getInt("CheckPai.ID_CHECKLIST")));
				checkPai.setDescricao(resultSet.getString("CheckPai.DESCRICAO"));
				checkPai.setRespostasPossiveis(resultSet.getString("CheckPai.RESPOSTAS_POSSIVEIS"));
				checkPai.setRespostaPadrao(resultSet.getString("CheckPai.RESPOSTA_PADRAO"));
				checkPai.setFlagEnabled(resultSet.getBoolean("CheckPai.FLAG_ENABLED"));
				checkPai.setOrdem(resultSet.getInt("CheckPai.ORDEM"));
				checkPai.setOperadorApresentacao(resultSet.getString("CheckPai.OPERADOR_APRESENTACAO"));
				checkPai.setRespostaApresentacao(resultSet.getString("CheckPai.RESPOSTA_APRESENTACAO"));
				result.setCheckPai(checkPai);
			}
		} catch (SQLException e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		return result;
	}
	
	@Override
	public List<Check> findByExample(Check example) throws DataException {
		return findByExample(example, null);
	}
	
	@Override
	public List<Check> findByExample(Check example, String order) throws DataException {
		List<Check> checks = new ArrayList<Check>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		int index = 0;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Check.getSqlCamposCheck())
				.append(FROM)
				.append(Check.getSqlFromCheck())
				.append(WHERE_1_1);
			
			if (example.getIdCheck() != null) {
				select.append(" AND Chec.ID_CHECK = ? ");
			}
			if (example.getCheckPai() != null && example.getCheckPai().getIdCheck() != null) {
				select.append(" AND Chec.ID_CHECK_PAI = ? ");
			}
			if (example.getChecklist() != null && example.getChecklist().getIdChecklist() != null) {
				select.append(" AND Chec.ID_CHECKLIST = ? ");
			}
			if (example.getDescricao() != null && !example.getDescricao().isEmpty()) {
				select.append(" AND Chec.DESCRICAO = ? ");
			}
			if (example.getRespostasPossiveis() != null && !example.getRespostasPossiveis().isEmpty()) {
				select.append(" AND Chec.RESPOSTAS_POSSIVEIS = ? ");
			}
			if (example.getRespostaPadrao() != null && !example.getRespostaPadrao().isEmpty()) {
				select.append(" AND Chec.RESPOSTA_PADRAO = ? ");
			}
			if (example.getOrdem() != null) {
				select.append(" AND Chec.ORDEM = ? ");
			}
			if (example.getOperadorApresentacao() != null && !example.getOperadorApresentacao().isEmpty()) {
				select.append(" AND Chec.OPERADOR_APRESENTACAO = ? ");
			}
			if (example.getRespostaApresentacao() != null && !example.getRespostaApresentacao().isEmpty()) {
				select.append(" AND Chec.RESPOSTA_APRESENTACAO = ? ");
			}
			if (example.getFlagEnabled() != null) {
				select.append(" AND Chec.FLAG_ENABLED = ? ");
			}
			
			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			if (example.getIdCheck() != null) {
				stmt.setInt(++index, example.getIdCheck());
			}
			if (example.getCheckPai() != null && example.getCheckPai().getIdCheck() != null) {
				stmt.setInt(++index, example.getCheckPai().getIdCheck());
			}
			if (example.getChecklist() != null && example.getChecklist().getIdChecklist() != null) {
				stmt.setInt(++index, example.getChecklist().getIdChecklist());
			}
			if (example.getDescricao() != null && !example.getDescricao().isEmpty()) {
				stmt.setString(++index, example.getDescricao());
			}
			if (example.getRespostasPossiveis() != null && !example.getRespostasPossiveis().isEmpty()) {
				stmt.setString(++index, example.getRespostasPossiveis());
			}
			if (example.getRespostaPadrao() != null && !example.getRespostaPadrao().isEmpty()) {
				stmt.setString(++index, example.getRespostaPadrao());
			}
			if (example.getOrdem() != null) {
				stmt.setInt(++index, example.getOrdem());
			}
			if (example.getOperadorApresentacao() != null && !example.getOperadorApresentacao().isEmpty()) {
				stmt.setString(++index, example.getOperadorApresentacao());
			}
			if (example.getRespostaApresentacao() != null && !example.getRespostaApresentacao().isEmpty()) {
				stmt.setString(++index, example.getRespostaApresentacao());
			}
			if (example.getFlagEnabled() != null) {
				stmt.setBoolean(++index, example.getFlagEnabled());
			}
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					Check check = Check.getCheckByResultSet(resultSet);
					checks.add(check);
				}
			}
		} catch (SQLException ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return checks;
	}
	
	@Override
	public List<Check> findAll() throws DataException {
		return findAll(null);
	}
	
	@Override
	public List<Check> findAll(String order) throws DataException {
		List<Check> checks = new ArrayList<Check>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Check.getSqlCamposCheck())
				.append(FROM)
				.append(Check.getSqlFromCheck());
			
			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					Check check = Check.getCheckByResultSet(resultSet);
					checks.add(check);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return checks;
	}
	
	@Override
	public List<Check> findAtivos() throws DataException {
		return findAtivos(null);
	}
	
	@Override
	public List<Check> findAtivos(String order) throws DataException {
		List<Check> checks = new ArrayList<Check>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(Check.getSqlCamposCheck())
				.append(FROM)
				.append(Check.getSqlFromCheck())
				.append(WHERE)
				.append(" Chec.FLAG_ENABLED = 1 ");
			
			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					Check check = Check.getCheckByResultSet(resultSet);
					checks.add(check);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return checks;
	}
	
}
