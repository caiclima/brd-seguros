package br.com.callink.cad.sau.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.sau.dao.IChecklistDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.Checklist;

public class ChecklistDAO extends GenericCadSauDAO<Checklist> implements IChecklistDAO {

	private static final long serialVersionUID = -7134077291733862929L;
	
	public ChecklistDAO() {
		super(Checklist.class);
	}

	@Override
	public List<Checklist> findByExample(Checklist checklist, String order) throws DataException {
		List<Checklist> checklists = new ArrayList<Checklist>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		int index = 0;
		
		try {
			
			StringBuilder select = new StringBuilder()
			.append(SELECT)
			.append(Checklist.getSqlCamposChecklist())
			.append(FROM)
			.append(Checklist.getSqlFromChecklist())
			.append(WHERE_1_1);
			
			if(checklist!= null){
				if(checklist.getIdChecklist() != null) {
					select.append(" AND Checklist.ID_CHECKLIST = ? ");
				}
				if(StringUtils.isNotBlank(checklist.getDescricao())) {
					select.append(" AND Checklist.DESCRICAO like ? ");
				}
				if(checklist.getFlagEnabled() != null) {
					select.append(" AND Checklist.FLAG_ENABLED = ? ");
				}
			}
			
			if (StringUtils.isNotBlank(order)) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			if(checklist!= null){
				if(checklist.getIdChecklist() != null) {
					stmt.setInt(++index, checklist.getIdChecklist());
				}
				if(StringUtils.isNotBlank(checklist.getDescricao())) {
					stmt.setString(++index, new StringBuilder(checklist.getDescricao()).append("%").toString());
				}
				if(checklist.getFlagEnabled() != null) {
					stmt.setBoolean(++index, checklist.getFlagEnabled());
				}
			}
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					Checklist checklistTmp = Checklist.getChecklistByResultSet(resultSet);
					checklists.add(checklistTmp);
				}
			}
			
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return checklists;
	}
	
	@Override
	public List<Checklist> findByExample(Checklist checklist) throws DataException {
		return findByExample(checklist, null);
	}
	
	@Override
	public Checklist findByPk(Object id) throws DataException {
		Checklist result = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			
			StringBuilder select = new StringBuilder()
			.append(SELECT)
			.append(Checklist.getSqlCamposChecklist())
			.append(FROM)
			.append(Checklist.getSqlFromChecklist())
			.append(WHERE_1_1)
			.append(" AND Checklist.ID_CHECKLIST = ? ");
			
			stmt = getPreparedStatement(select.toString());
			
			Checklist checklist = (Checklist) id;
			
			stmt.setInt(1, checklist.getIdChecklist());
			
			stmt.execute();
			
			resultSet = stmt.getResultSet();
			if (resultSet != null && resultSet.next()) {
				result = Checklist.getChecklistByResultSet(resultSet);
			}
			
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		
		return result;
	}
	
	@Override
	public List<Checklist> findAll(String order) throws DataException {
		List<Checklist> checklists = new ArrayList<Checklist>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			
			StringBuilder select = new StringBuilder()
			.append(SELECT)
			.append(Checklist.getSqlCamposChecklist())
			.append(FROM)
			.append(Checklist.getSqlFromChecklist())
			.append(WHERE_1_1);
			
			if (StringUtils.isNotBlank(order)) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					Checklist checklistTmp = Checklist.getChecklistByResultSet(resultSet);
					checklists.add(checklistTmp);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		
		return checklists;
	}
	
	@Override
	public List<Checklist> findAll() throws DataException {
		return findAll(null);
	}
	
	@Override
	public List<Checklist> findAtivos() throws DataException {
		return findAtivos(null);
	}
	
	@Override
	public List<Checklist> findAtivos(String order) throws DataException {
		List<Checklist> checklists = new ArrayList<Checklist>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			
			StringBuilder select = new StringBuilder()
			.append(SELECT)
			.append(Checklist.getSqlCamposChecklist())
			.append(FROM)
			.append(Checklist.getSqlFromChecklist())
			.append(WHERE)
			.append(" Checklist.FLAG_ENABLED = 1 ");
			
			if (StringUtils.isNotBlank(order)) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					Checklist checklistTmp = Checklist.getChecklistByResultSet(resultSet);
					checklists.add(checklistTmp);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		
		return checklists;
	}
	
}
