package br.com.callink.cad.sau.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.pojo.Util.DateUtil;
import br.com.callink.cad.sau.dao.IClassificacaoAutomaticaDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.ClassificacaoAutomatica;
import br.com.callink.cad.sau.pojo.Evento;

public class ClassificacaoAutomaticaDAO extends
		GenericCadSauDAO<ClassificacaoAutomatica> implements
		IClassificacaoAutomaticaDAO {

	public ClassificacaoAutomaticaDAO() {
		super(ClassificacaoAutomatica.class);
	}

	private static final long serialVersionUID = 3963329302223307103L;

	@Override
	public List<ClassificacaoAutomatica> findByExample(
			ClassificacaoAutomatica classificacaoAutomatica)
			throws DataException {
		return this.findByExample(classificacaoAutomatica, null);
	}

	@Override
	public List<ClassificacaoAutomatica> findByExample(
			ClassificacaoAutomatica classificacaoAutomatica, String order)
			throws DataException {

		if (classificacaoAutomatica == null) {
			return null;
		}

		ResultSet result = null;
		PreparedStatement stmt = null;
		List<ClassificacaoAutomatica> list = new ArrayList<ClassificacaoAutomatica>();
		int index = 0;

		try {

			StringBuilder select = new StringBuilder(SELECT)
					.append(ClassificacaoAutomatica
							.getSqlClassificacaoAutomatica())
					.append(", ")
					.append(Evento.getSqlEvento())
					.append(FROM)
					.append(ClassificacaoAutomatica
							.getSqlFromClassificacaoAutomatica());

			boolean eventoIsNull = classificacaoAutomatica.getEvento() == null
					|| classificacaoAutomatica.getEvento().getIdEvento() == null;
			if (!eventoIsNull) {
				select.append(INNER_JOIN);
			} else {
				select.append(LEFT_JOIN);
			}
			select.append(Evento.getSqlFromEvento())
					.append(" ON ClassificacaoAutomatica.ID_EVENTO = Evento.ID_EVENTO ");

			select.append(WHERE_1_1);

			if (classificacaoAutomatica.getPK() != null) {
				select.append(" AND ClassificacaoAutomatica.ID_CLASSIFICACAO_AUTOMATICA = ? ");
			}
			if (StringUtils
					.isNotBlank(classificacaoAutomatica.getTextoPadrao())) {
				select.append(" AND ClassificacaoAutomatica.TEXTO_PADRAO like ? ");
			}
			if (StringUtils.isNotBlank(classificacaoAutomatica.getAssunto())) {
				select.append(" AND ClassificacaoAutomatica.ASSUNTO like ? ");
			}
			if (!eventoIsNull) {
				select.append(" AND ClassificacaoAutomatica.ID_EVENTO = ? ");
			}
			if (classificacaoAutomatica.getDataCriacao() != null) {
				select.append(" AND ClassificacaoAutomatica.DATA_CRIACAO BETWEEN ? AND ? ");
			}
			if (StringUtils.isNotBlank(classificacaoAutomatica
					.getLoginUsuario())) {
				select.append(" AND ClassificacaoAutomatica.LOGIN_USUARIO like ? ");
			}
			if (StringUtils.isNotBlank(order)) {
				select.append(String.format(" ORDER BY %s ", order));
			}

			stmt = getPreparedStatement(select.toString());

			if (classificacaoAutomatica.getPK() != null) {
				stmt.setInt(++index, classificacaoAutomatica.getPK());
			}
			if (StringUtils
					.isNotBlank(classificacaoAutomatica.getTextoPadrao())) {
				stmt.setString(++index, new StringBuilder(
						classificacaoAutomatica.getTextoPadrao()).append("%")
						.toString());
			}
			if (StringUtils.isNotBlank(classificacaoAutomatica.getAssunto())) {
				stmt.setString(++index, new StringBuilder(
						classificacaoAutomatica.getAssunto()).append("%")
						.toString());
			}
			if (!eventoIsNull) {
				stmt.setInt(++index, classificacaoAutomatica.getEvento()
						.getIdEvento());
			}
			if (classificacaoAutomatica.getDataCriacao() != null) {
				Date dataInicio = DateUtil
						.dataInicioDia(classificacaoAutomatica.getDataCriacao());
				Date dataFinal = DateUtil.dataFimDia(classificacaoAutomatica
						.getDataCriacao());
				stmt.setDate(++index, new java.sql.Date(dataInicio.getTime()));
				stmt.setDate(++index, new java.sql.Date(dataFinal.getTime()));
			}

			stmt.execute();
			result = stmt.getResultSet();

			if (result != null) {
				while (result.next()) {
					ClassificacaoAutomatica classificacaoAutomaticaResult = ClassificacaoAutomatica
							.getClassificacaoAutomaticaByResultSet(result);
					classificacaoAutomaticaResult.setEvento(Evento
							.getEventoByResultSet(result));
					list.add(classificacaoAutomaticaResult);
				}
			}

			return list;
		} catch (SQLException ex) {
			throw new DataException(ex);
		} finally {
			super.close(result);
		}
	}

	@Override
	public List<ClassificacaoAutomatica> findAll() throws DataException {
		return this.findAll(null);
	}

	@Override
	public List<ClassificacaoAutomatica> findAll(String order)
			throws DataException {

		ResultSet result = null;
		PreparedStatement stmt = null;
		List<ClassificacaoAutomatica> list = new ArrayList<ClassificacaoAutomatica>();

		try {

			StringBuilder select = new StringBuilder(SELECT)
					.append(ClassificacaoAutomatica
							.getSqlClassificacaoAutomatica())
					.append(",")
					.append(Evento.getSqlEvento())
					.append(FROM)
					.append(ClassificacaoAutomatica
							.getSqlFromClassificacaoAutomatica())
					.append(LEFT_JOIN)
					.append(Evento.getSqlFromEvento())
					.append(" ON ClassificacaoAutomatica.ID_EVENTO = Evento.ID_EVENTO ");

			if (StringUtils.isNotBlank(order)) {
				select.append(String.format(" ORDER BY %s ", order));
			}

			stmt = getPreparedStatement(select.toString());
			stmt.execute();
			result = stmt.getResultSet();

			if (result != null) {
				while (result.next()) {
					ClassificacaoAutomatica classificacaoAutomaticaResult = ClassificacaoAutomatica
							.getClassificacaoAutomaticaByResultSet(result);
					classificacaoAutomaticaResult.setEvento(Evento
							.getEventoByResultSet(result));
					list.add(classificacaoAutomaticaResult);
				}
			}

			return list;
		} catch (SQLException ex) {
			throw new DataException(ex);
		} finally {
			super.close(result);
		}
	}

	@Override
	public ClassificacaoAutomatica findByPk(Object id) throws DataException {

		ResultSet result = null;
		PreparedStatement stmt = null;

		try {

			StringBuilder select = new StringBuilder(SELECT)
					.append(ClassificacaoAutomatica
							.getSqlClassificacaoAutomatica())
					.append(FROM)
					.append(ClassificacaoAutomatica
							.getSqlFromClassificacaoAutomatica())
					.append(INNER_JOIN)
					.append(Evento.getSqlFromEvento())
					.append(" ON ClassificacaoAutomatica.ID_EVENTO = Evento.ID_EVENTO ")
					.append(WHERE)
					.append(" ClassificacaoAutomatica.ID_CLASSIFICACAO_AUTOMATICA = ? ");

			stmt = getPreparedStatement(select.toString());
			ClassificacaoAutomatica classificacaoAutomatica = (ClassificacaoAutomatica) id;
			stmt.setInt(1, classificacaoAutomatica.getPK());
			stmt.execute();
			result = stmt.getResultSet();

			if (result != null) {
				while (result.next()) {
					classificacaoAutomatica = ClassificacaoAutomatica
							.getClassificacaoAutomaticaByResultSet(result);
					classificacaoAutomatica.setEvento(Evento
							.getEventoByResultSet(result));
				}
			}

			return classificacaoAutomatica;
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(result);
		}
	}

	@Override
	public List<ClassificacaoAutomatica> findAtivos(String order)
			throws DataException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<ClassificacaoAutomatica> findAtivos() throws DataException {
		// TODO Auto-generated method stub
		return null;
	}

}
