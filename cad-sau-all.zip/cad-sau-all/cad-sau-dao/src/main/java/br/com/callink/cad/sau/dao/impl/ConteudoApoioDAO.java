package br.com.callink.cad.sau.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.pojo.GrupoAnexo;
import br.com.callink.cad.pojo.Util.DateUtil;
import br.com.callink.cad.sau.dao.IConteudoApoioDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.pojo.ConteudoApoio;
import br.com.callink.cad.sau.pojo.ConteudoApoioCasoSau;

public class ConteudoApoioDAO extends GenericCadSauDAO<ConteudoApoio> implements IConteudoApoioDAO {

	private static final long serialVersionUID = 4790231732763809685L;

	public ConteudoApoioDAO() {
		super(ConteudoApoio.class);
	}

	@Override
    public void associa(ConteudoApoioCasoSau conteudoApoioCasoSau) throws DataException {
        try {
        	StringBuilder sql = new StringBuilder();
        	sql.append(" INSERT INTO TB_CONTEUDOAPOIO_CASOSAU ");
        	sql.append(" (ID_CONTEUDO_APOIO, ID_CASO_SAU) ");
        	sql.append(" VALUES ");
        	sql.append(" :ID_CONTEUDO_APOIO, :ID_CASO_SAU ");
        	
        	Query query = getEntityManager().createNativeQuery(sql.toString());
        	
            query.setParameter("ID_CONTEUDO_APOIO", conteudoApoioCasoSau.getConteudoApoioCasoSauId().getConteudoApoio().getIdConteudoApoio());
            query.setParameter("ID_CASO_SAU", conteudoApoioCasoSau.getConteudoApoioCasoSauId().getCasoSau().getIdCasoSau());
            
            query.executeUpdate();
        } catch (Exception ex) {
            throw new DataException(ex);
        }

    }

    @Override
    public void associa(List<ConteudoApoioCasoSau> conteudoApoioCasoSauList) throws DataException {
        for (ConteudoApoioCasoSau conteudoApoioCasoSau : conteudoApoioCasoSauList) {
            associa(conteudoApoioCasoSau);
        }
    }

    @Override
    public void desassocia(ConteudoApoioCasoSau conteudoApoioCasoSau) throws DataException {
    	
    	try {
    		StringBuilder sql = new StringBuilder();
        	sql.append(" DELETE FROM TB_CONTEUDOAPOIO_CASOSAU ");
        	sql.append(" WHERE ");
        	sql.append(" ID_CONTEUDO_APOIO = :ID_CONTEUDO_APOIO AND ID_CASO_SAU = :ID_CASO_SAU ");
        	
        	Query query = getEntityManager().createNativeQuery(sql.toString());
        	
        	query.setParameter("ID_CONTEUDO_APOIO", conteudoApoioCasoSau.getConteudoApoioCasoSauId().getConteudoApoio().getPK());
            query.setParameter("ID_CASO_SAU", conteudoApoioCasoSau.getConteudoApoioCasoSauId().getCasoSau().getPK());

            
            query.executeUpdate();
    	} catch (Exception e) {
			throw new DataException(e);
		}
    }

    @Override
    public void desassocia(List<ConteudoApoioCasoSau> conteudoApoioCasoSauList) throws DataException {
        if (conteudoApoioCasoSauList != null) {
            for (ConteudoApoioCasoSau conteudoApoioCasoSau : conteudoApoioCasoSauList) {
                desassocia(conteudoApoioCasoSau);
            }
        }
    }

    @Override
    public List<ConteudoApoio> buscaConteudoApoio(ConteudoApoio conteudoApoio) throws DataException {
    	List<ConteudoApoio> conteudoApoios = new ArrayList<ConteudoApoio>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		int index =0;
        try {
        	
        	StringBuilder select = new StringBuilder()
			.append(SELECT)
			.append(ConteudoApoio.getSqlCamposConteudoApoio())
			.append(FROM)
			.append(ConteudoApoio.getSqlFromConteudoApoio())
			.append(WHERE_1_1);
        	
        	if (conteudoApoio.getPK() != null) {
				select.append(" AND ConteudoApoio.ID_CONTEUDO_APOIO = ? ");
			}
        	if(StringUtils.isNotBlank(conteudoApoio.getNome())) {
				select.append(" AND ConteudoApoio.NOME = ? ");
			}
        	if(StringUtils.isNotBlank(conteudoApoio.getDescricao())) {
        		select.append(" AND ConteudoApoio.DESCRICAO = ? ");
        	}
        	if (conteudoApoio.getDataCriacao() != null) {
				select.append(" AND ConteudoApoio.DATA_CRIACAO = ? ");
			}
        	if(conteudoApoio.getFlagAtivo() != null) {
        		select.append(" AND ConteudoApoio.FLAG_ATIVO = ? ");
        	}
        	if(conteudoApoio.getGrupoAnexo() != null && conteudoApoio.getGrupoAnexo().getIdGrupoAnexo() != null){
        		select.append(" AND ConteudoApoio.ID_GRUPO_ANEXO = ? ");
        	}
        	
        	stmt = getPreparedStatement(select.toString());
			
        	if (conteudoApoio.getPK() != null) {
				stmt.setInt(++index, conteudoApoio.getPK());
			}
        	if(StringUtils.isNotBlank(conteudoApoio.getNome())) {
				stmt.setString(++index, conteudoApoio.getNome());
			}
        	if(StringUtils.isNotBlank(conteudoApoio.getDescricao())) {
        		stmt.setString(++index, conteudoApoio.getDescricao());
        	}
        	if (conteudoApoio.getDataCriacao() != null) {
				stmt.setDate(++index, new java.sql.Date(conteudoApoio.getDataCriacao().getTime()));
			}
        	if(conteudoApoio.getFlagAtivo() != null) {
        		stmt.setBoolean(++index, conteudoApoio.getFlagAtivo());
        	}
        	if(conteudoApoio.getGrupoAnexo() != null && conteudoApoio.getGrupoAnexo().getIdGrupoAnexo() != null){
        		stmt.setInt(++index, conteudoApoio.getGrupoAnexo().getIdGrupoAnexo());
        	}
        	
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					ConteudoApoio conteudoApoioTmp = ConteudoApoio.getConteudoApoioByResultSet(resultSet);
					conteudoApoios.add(conteudoApoioTmp);
				}
			}
        } catch (SQLException e) {
            throw new DataException(e);
        } finally {
			super.close(resultSet);
		}
        return conteudoApoios;
    }

    @Override
    public List<ConteudoApoioCasoSau> buscaAssociacaoByConteudoApoioOuCasoSau(ConteudoApoio conteudoApoio, CasoSau casoSau) throws DataException {
    	List<ConteudoApoioCasoSau> conteudoApoioCasoSaus = new ArrayList<ConteudoApoioCasoSau>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
        try {
        	
        	StringBuilder select = new StringBuilder()
			.append(SELECT)
			.append(ConteudoApoioCasoSau.getSqlCamposConteudoApoioCasoSau())
			.append(FROM)
			.append(ConteudoApoioCasoSau.getSqlFromConteudoApoioCasoSau())
			.append(WHERE_1_1);
        	
        	if (conteudoApoio != null && conteudoApoio.getPK() != null) {
        		select.append(" AND ConteudoApoioCasoSau.ID_CONTEUDO_APOIO = ? ");
            } else if (casoSau != null && casoSau.getPK() != null) {
            	select.append(" AND ConteudoApoioCasoSau.ID_CASO_SAU = ? ");
            }

        	stmt = getPreparedStatement(select.toString());
        	
        	if (conteudoApoio != null && conteudoApoio.getPK() != null) {
        		stmt.setInt(1, conteudoApoio.getPK());
            } else if (casoSau != null && casoSau.getPK() != null) {
            	stmt.setInt(1, casoSau.getPK());
            }
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					ConteudoApoioCasoSau conteudoApoioCasoSau = ConteudoApoioCasoSau.getConteudoApoioCasoSauByResultSet(resultSet);
					conteudoApoioCasoSaus.add(conteudoApoioCasoSau);
				}
			}

        } catch (Exception ex) {
            throw new DataException(ex);
        } finally {
			super.close(resultSet);
		}
        return conteudoApoioCasoSaus;
    }
    
    @Override
	public ConteudoApoio findByPk(Object id) throws DataException {
    	ConteudoApoio result = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(ConteudoApoio.getSqlCamposConteudoApoio())
				.append(", ")
				.append(GrupoAnexo.getSqlCamposGrupoAnexo())
				.append(FROM)
				.append(ConteudoApoio.getSqlFromConteudoApoio())
				.append(LEFT_JOIN).append(GrupoAnexo.getSqlFromGrupoAnexo())
				.append(" ON ConteudoApoio.ID_GRUPO_ANEXO = GrupoAnexo.ID_GRUPO_ANEXO ")
				.append(" WHERE ConteudoApoio.ID_CONTEUDO_APOIO = ? ");
			
			stmt = getPreparedStatement(select.toString());
			
			ConteudoApoio conteudoApoio = (ConteudoApoio) id;
			
			stmt.setInt(1, conteudoApoio.getIdConteudoApoio());
			
			stmt.execute();
			
			resultSet = stmt.getResultSet();
			if (resultSet != null && resultSet.next()) {
				result = ConteudoApoio.getConteudoApoioByResultSet(resultSet);
				result.setGrupoAnexo(GrupoAnexo.getGrupoAnexoByResultSet(resultSet));
			}
		} catch (Exception e) {
			throw new DataException(e);
		} finally {
			super.close(resultSet);
		}
		return result;
	}
	
	@Override
	public List<ConteudoApoio> findByExample(ConteudoApoio example) throws DataException {
		return findByExample(example, null);
	}
	
	@Override
	public List<ConteudoApoio> findByExample(ConteudoApoio example, String order) throws DataException {
		List<ConteudoApoio> conteudosApoio = new ArrayList<ConteudoApoio>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		int index =0;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(ConteudoApoio.getSqlCamposConteudoApoio())
				.append(FROM)
				.append(ConteudoApoio.getSqlFromConteudoApoio())
				.append(WHERE_1_1);
			
			if (example.getIdConteudoApoio() != null) {
				select.append(" AND ConteudoApoio.ID_CONTEUDO_APOIO = ? ");
			}
			if (StringUtils.isNotBlank(example.getNome())) {
				select.append(" AND ConteudoApoio.NOME like ? ");
			}
			if (example.getDescricao() != null && !example.getDescricao().isEmpty()) {
				select.append(" AND ConteudoApoio.DESCRICAO = ? ");
			}
			if (example.getDataCriacao() != null) {
				select.append(" AND ConteudoApoio.DATA_CRIACAO BETWEEN ? AND ? ");
			}
			if (example.getFlagAtivo() != null) {
				select.append(" AND ConteudoApoio.FLAG_ATIVO = ? ");
			}
			if (example.getGrupoAnexo() != null && example.getGrupoAnexo().getIdGrupoAnexo() != null) {
				select.append(" AND ConteudoApoio.ID_GRUPO_ANEXO = ? ");
			}
			
			if (StringUtils.isNotBlank(order)) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			if (example.getIdConteudoApoio() != null) {
				stmt.setInt(++index, example.getIdConteudoApoio());
			}
			if (StringUtils.isNotBlank(example.getNome())) {
				stmt.setString(++index, new StringBuilder(example.getNome()).append("%").toString());
			}
			if (example.getDescricao() != null && !example.getDescricao().isEmpty()) {
				stmt.setString(++index, example.getDescricao());
			}
			if (example.getDataCriacao() != null) {
				Date dataInicio = DateUtil.dataInicioDia(example.getDataCriacao());
				Date dataFim = DateUtil.dataFimDia(example.getDataCriacao());
				stmt.setDate(++index, new java.sql.Date(dataInicio.getTime()));
				stmt.setDate(++index, new java.sql.Date(dataFim.getTime()));
			}
			if (example.getFlagAtivo() != null) {
				stmt.setBoolean(++index, example.getFlagAtivo());
			}
			if (example.getGrupoAnexo() != null && example.getGrupoAnexo().getIdGrupoAnexo() != null) {
				stmt.setInt(++index, example.getGrupoAnexo().getIdGrupoAnexo());
			}
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					ConteudoApoio conteudoApoio = ConteudoApoio.getConteudoApoioByResultSet(resultSet);
					conteudosApoio.add(conteudoApoio);
				}
			}
		} catch (SQLException ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return conteudosApoio;
	}
	
	@Override
	public List<ConteudoApoio> findAll() throws DataException {
		return findAll(null);
	}
	
	@Override
	public List<ConteudoApoio> findAll(String order) throws DataException {
		List<ConteudoApoio> conteudosApoio = new ArrayList<ConteudoApoio>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(ConteudoApoio.getSqlCamposConteudoApoio())
				.append(FROM)
				.append(ConteudoApoio.getSqlFromConteudoApoio());
			
			if (StringUtils.isNotBlank(order)) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					ConteudoApoio conteudoApoio = ConteudoApoio.getConteudoApoioByResultSet(resultSet);
					conteudosApoio.add(conteudoApoio);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return conteudosApoio;
	}
	
	@Override
	public List<ConteudoApoio> findAtivos() throws DataException {
		return findAtivos(null);
	}
	
	@Override
	public List<ConteudoApoio> findAtivos(String order) throws DataException {
		List<ConteudoApoio> conteudosApoio = new ArrayList<ConteudoApoio>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(ConteudoApoio.getSqlCamposConteudoApoio())
				.append(FROM)
				.append(ConteudoApoio.getSqlFromConteudoApoio())
				.append(WHERE)
				.append(" ConteudoApoio.FLAG_ATIVO = 1 ");
			
			if (StringUtils.isNotBlank(order)) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					ConteudoApoio conteudoApoio = ConteudoApoio.getConteudoApoioByResultSet(resultSet);
					conteudosApoio.add(conteudoApoio);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return conteudosApoio;
	}
    
}
