package br.com.callink.cad.sau.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.sau.dao.IEstadoDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.Estado;

public class EstadoDAO extends GenericCadSauDAO<Estado> implements IEstadoDAO{

	private static final long serialVersionUID = 7420004276261385586L;
	
	public EstadoDAO() {
		super(Estado.class);
	}

	@Override
	public List<Estado> findByExample(Estado estado, String order) throws DataException {
		List<Estado> estados = new ArrayList<Estado>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		int index =0;
		try {
			
			StringBuilder select = new StringBuilder()
			.append(SELECT)
			.append(Estado.getSqlEstado())
			.append(FROM)
			.append(Estado.getSqlFromEstado())
			.append(WHERE_1_1);
			
			if (estado.getIdEstado() != null) {
				select.append(" AND Estado.ID_ESTADO = ? ");
			}
			if(StringUtils.isNotBlank(estado.getNome())) {
				select.append(" AND Estado.NOME like ? ");
			}
			if (estado.getDataCriacao() != null) {
				select.append(" AND Estado.DATA_CRIACAO = ? ");
			}
			if(estado.getFlagAtivo() != null) {
				select.append(" AND Estado.FLAG_ATIVO = ? ");
				
			}
			if (StringUtils.isNotBlank(order)) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			if (estado.getIdEstado() != null) {
				stmt.setInt(++index, estado.getIdEstado());
			}
			if(StringUtils.isNotBlank(estado.getNome())) {
				stmt.setString(++index, new StringBuilder(estado.getNome()).append("%").toString() );
			}
			if (estado.getDataCriacao() != null) {
				stmt.setDate(++index, new java.sql.Date(estado.getDataCriacao().getTime()));
			}
			if(estado.getFlagAtivo() != null) {
				stmt.setBoolean(++index, estado.getFlagAtivo());
			}
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					Estado estadoTmp = Estado.getEstadoByResultSet(resultSet);
					estados.add(estadoTmp);
				}
			}
			
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return estados;
	}
	
	public List<Estado> findByExample(Estado estado) throws DataException {
		return findByExample(estado, null);
	}
	
	@Override
	public Estado findByPk(Object id) throws DataException {
		Estado result = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			
			StringBuilder select = new StringBuilder()
			.append(SELECT)
			.append(Estado.getSqlEstado())
			.append(FROM)
			.append(Estado.getSqlFromEstado())
			.append(WHERE_1_1)
			.append(" AND Estado.ID_ESTADO = ? ");
			
			stmt = getPreparedStatement(select.toString());
			
			Estado estado = (Estado) id;
			
			stmt.setInt(1, estado.getIdEstado());
			
			stmt.execute();
			
			resultSet = stmt.getResultSet();
			if (resultSet != null && resultSet.next()) {
				result = Estado.getEstadoByResultSet(resultSet);
			}
			
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		
		return result;
		
	}
	
	@Override
	public List<Estado> findAll(String order) throws DataException {
		List<Estado> estados = new ArrayList<Estado>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			
			StringBuilder select = new StringBuilder()
			.append(SELECT)
			.append(Estado.getSqlEstado())
			.append(FROM)
			.append(Estado.getSqlFromEstado())
			.append(WHERE_1_1);
			
			if (StringUtils.isNotBlank(order)) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					Estado estadoTmp = Estado.getEstadoByResultSet(resultSet);
					estados.add(estadoTmp);
				}
			}
			
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		
		return estados;
	}
	
	public List<Estado> findAll() throws DataException {
		return findAll(null);
	}
	
	public List<Estado> findAtivos() throws DataException {
		return findAtivos(null);
	}
	
	@Override
	public List<Estado> findAtivos(String order) throws DataException {
		List<Estado> estados = new ArrayList<Estado>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			
			StringBuilder select = new StringBuilder()
			.append(SELECT)
			.append(Estado.getSqlEstado())
			.append(FROM)
			.append(Estado.getSqlFromEstado())
			.append(WHERE)
			.append(" Estado.FLAG_ATIVO = 1 ");
			
			if (StringUtils.isNotBlank(order)) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					Estado estadoTmp = Estado.getEstadoByResultSet(resultSet);
					estados.add(estadoTmp);
				}
			}
			
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		
		return estados;
	}
	
}
