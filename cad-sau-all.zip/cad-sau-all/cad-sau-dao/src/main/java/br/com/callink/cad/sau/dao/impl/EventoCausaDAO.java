package br.com.callink.cad.sau.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.sau.dao.IEventoCausaDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.Assunto;
import br.com.callink.cad.sau.pojo.Causa;
import br.com.callink.cad.sau.pojo.Evento;
import br.com.callink.cad.sau.pojo.EventoCausa;

/**
 * 
 * @author Rogério Moreira [rogeriom@swb.com.br]
 *
 */
public class EventoCausaDAO extends GenericCadSauDAO<EventoCausa> implements IEventoCausaDAO {

	private static final long serialVersionUID = 6194932052715247001L;

	public EventoCausaDAO() {
		super(EventoCausa.class);
	}

	private static final String VIRGULA = ",";

    @Override
    public List<EventoCausa> findByEventoCausa(Evento evento, Causa causa) throws DataException {
       
    	List<EventoCausa> list = new ArrayList<EventoCausa>();
        PreparedStatement stmt = null;
        ResultSet result = null;
        int index = 0;
        try {
            boolean isEvento = evento != null && evento.getPK() != null;
            boolean isCausa = causa != null && causa.getPK() != null;
            StringBuilder sql = new StringBuilder()
                    .append(SELECT).append(EventoCausa.getSqlEventoCausa()).append(VIRGULA)
                    .append(Evento.getSqlEvento()).append(VIRGULA)
                    .append(Causa.getSqlCausa()).append(VIRGULA)
                    .append(Assunto.getSqlAssunto())
                    .append(FROM)
                    .append(EventoCausa.getSqlFromEventoCausa())
                    .append(INNER_JOIN).append(Evento.getSqlFromEvento())
                    .append("ON EventoCausa.ID_EVENTO = Evento.ID_EVENTO ")
                    .append(INNER_JOIN).append(Causa.getSqlFromCausa())
                    .append(" ON EventoCausa.ID_CAUSA = Causa.ID_CAUSA ")
                    .append(INNER_JOIN).append(Assunto.getSqlFromAssunto())
                    .append("ON Assunto.ID_ASSUNTO = Evento.ID_ASSUNTO ");
            if (isEvento || isCausa) {
                sql.append(WHERE);
            }
            if (isEvento) {
                sql.append(" EventoCausa.ID_EVENTO = ? ");
            }
            if (isEvento && isCausa) {
                sql.append(" AND ");
            }
            if (isCausa) {
                sql.append(" EventoCausa.ID_CAUSA = ? ");
            }

        	stmt = getPreparedStatement(sql.toString());
        	
        	if (isEvento) {
                stmt.setInt(++index, evento.getPK());
            }
            if (isCausa) {
                stmt.setInt(++index, causa.getPK());
            }
        	
        	stmt.execute();
            result = stmt.getResultSet();
            
            if(result!= null){		
				while (result.next()) {
					EventoCausa eventoCausa = EventoCausa.getEventoCausaByResultSet(result);
					eventoCausa.setCausa(Causa.getCausaByResultSet(result));
					
					Evento eventoResult = Evento.getEventoByResultSet(result);
					eventoResult.setAssunto(Assunto.getAssuntoByResultSet(result));
					eventoCausa.setEvento(eventoResult);
					
					list.add(eventoCausa);
				}
			}
            
        	return list;
    	} catch (SQLException ex) {
            throw new DataException(ex);
        } finally {
        	super.close(result);
        }
    }

    @Override
    public Causa findCausaFinalizaAutomaticaByEvento(Evento evento) throws DataException {
        
    	PreparedStatement stmt = null;
        ResultSet result = null;
        
        try {
            
            StringBuilder sql = new StringBuilder(SELECT)
             .append(Causa.getSqlCausa())
             .append(FROM).append(EventoCausa.getSqlFromEventoCausa())
             .append(INNER_JOIN).append(Causa.getSqlFromCausa())
             .append(" ON (EventoCausa.ID_CAUSA = Causa.ID_CAUSA) ")
             .append(WHERE).append(" EventoCausa.ID_EVENTO = ? ")
             .append(" AND EventoCausa.FINALIZA_CASO = 1 ");

        	stmt = getPreparedStatement(sql.toString());
        	stmt.setInt(1, evento.getIdEvento());
        	stmt.execute();
            result = stmt.getResultSet();
            Causa causa = null;
           
            if(result!= null){		
				while (result.next()) {
					causa = Causa.getCausaByResultSet(result);
				}
			}
        	return causa;
        	
    	} catch (Exception ex) {
            throw new DataException(ex);
        } finally {
        	super.close(result);
        }
    	
    }

    @Override
    public List<EventoCausa> findFinalizacaoAutomaticaByEvento(Evento evento) throws DataException {
        try {
            EventoCausa exemplo = new EventoCausa();
            exemplo.setEvento(evento);
            exemplo.setFinalizaCaso(Boolean.TRUE);
            return this.findByExample(exemplo);
        } catch (Exception ex) {
            throw new DataException(ex);
        }
    }

    @Override
    public void removeEvento(Evento evento) throws DataException {
        try {
        	
        	Query query = getEntityManager().createNativeQuery("delete from TB_EVENTO_CAUSA where ID_EVENTO = :idEvento ");
            query.setParameter("idEvento", evento.getIdEvento());
            query.executeUpdate();

        } catch (Exception ex) {
            throw new DataException(ex);
        }
    }
    
    @Override
    public List<EventoCausa> findAll() throws DataException {
    	return this.findAll(null);
    }
    
    @Override
	public List<EventoCausa> findAll(String order) throws DataException {

		List<EventoCausa> list = new ArrayList<EventoCausa>();
		PreparedStatement stmt = null;
		ResultSet result = null;

		try {

			StringBuilder select = new StringBuilder(SELECT)
					.append(EventoCausa.getSqlEventoCausa()).append(FROM)
					.append(EventoCausa.getSqlFromEventoCausa());

			if (StringUtils.isNotBlank(order)) {
				select.append(String.format(" ORDER BY %s ", order));
			}

			stmt = getPreparedStatement(select.toString());
			stmt.execute();
			result = stmt.getResultSet();

			if (result != null) {
				while (result.next()) {
					EventoCausa eventoCausa = EventoCausa.getEventoCausaByResultSet(result);
					list.add(eventoCausa);
				}
			}

			return list;
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(result);
		}
	}
    
    @Override
   	public EventoCausa findByPk(Object id) throws DataException {

   		PreparedStatement stmt = null;
   		ResultSet result = null;

   		try {

   			StringBuilder select = new StringBuilder(SELECT)
   					.append(EventoCausa.getSqlEventoCausa())
   					.append(VIRGULA).append(Evento.getSqlEvento())
   					.append(VIRGULA).append(Causa.getSqlCausa())
   					.append(FROM)
   					.append(EventoCausa.getSqlFromEventoCausa())
   					.append(INNER_JOIN).append(Evento.getSqlFromEvento())
   					.append(" ON (EventoCausa.ID_EVENTO = Evento.ID_EVENTO) ")
   					.append(INNER_JOIN).append(Causa.getSqlFromCausa())
   					.append(" ON (EventoCausa.ID_CAUSA = Causa.ID_CAUSA) ")
   					.append(WHERE).append(" EventoCausa.ID_ENTO_CAUSA = ? ");
   			
   			EventoCausa eventoCausa = (EventoCausa) id;
   			stmt = getPreparedStatement(select.toString());
   			stmt.setInt(1, eventoCausa.getIdEventoCausa());
   			stmt.execute();
   			result = stmt.getResultSet();

   			if (result != null) {
   				while (result.next()) {
   					eventoCausa = EventoCausa.getEventoCausaByResultSet(result);
   					eventoCausa.setEvento(Evento.getEventoByResultSet(result));
   					eventoCausa.setCausa(Causa.getCausaByResultSet(result));
   				}
   			}

   			return eventoCausa;
   			
   		} catch (Exception ex) {
   			throw new DataException(ex);
   		} finally {
   			super.close(result);
   		}
   	}
    
    @Override
	public List<EventoCausa> findByExample(EventoCausa example) throws DataException {
    	return this.findByExample(example, null);
    }
    
    @Override
	public List<EventoCausa> findByExample(EventoCausa example, String order) throws DataException {

		List<EventoCausa> list = new ArrayList<EventoCausa>();
		PreparedStatement stmt = null;
		ResultSet result = null;
		int index =0;

		try {

			StringBuilder select = new StringBuilder(SELECT)
					.append(EventoCausa.getSqlEventoCausa()).append(FROM)
					.append(EventoCausa.getSqlFromEventoCausa())
					.append(WHERE_1_1);
			
			if(example!= null){
				
				if(example.getIdEventoCausa()!=null){
					select.append(" AND EventoCausa.ID_ENTO_CAUSA = ? ");
				}
				if(example.getCausa()!=null && example.getCausa().getIdCausa()!= null){
					select.append(" AND EventoCausa.ID_CAUSA = ? ");
				}
				if(example.getEvento()!= null && example.getEvento().getIdEvento() != null){
					select.append(" AND EventoCausa.ID_EVENTO = ? ");
				}
				if(example.getFinalizaCaso()!= null){
					select.append(" AND EventoCausa.FINALIZA_CASO = ? ");
				}
			}

			if (StringUtils.isNotBlank(order)) {
				select.append(String.format(" ORDER BY %s ", order));
			}

			stmt = getPreparedStatement(select.toString());
			
			if(example!= null){
				
				if(example.getIdEventoCausa()!=null){
					stmt.setInt(++index, example.getIdEventoCausa());
				}
				if(example.getCausa()!=null && example.getCausa().getIdCausa()!= null){
					stmt.setInt(++index, example.getCausa().getIdCausa());
				}
				if(example.getEvento()!= null && example.getEvento().getIdEvento() != null){
					stmt.setInt(++index, example.getEvento().getIdEvento());
				}
				if(example.getFinalizaCaso()!= null){
					stmt.setBoolean(++index, example.getFinalizaCaso());
				}
			}
			
			stmt.execute();
			result = stmt.getResultSet();

			if (result != null) {
				while (result.next()) {
					EventoCausa eventoCausa = EventoCausa.getEventoCausaByResultSet(result);
					list.add(eventoCausa);
				}
			}

			return list;
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(result);
		}
	}
    
    @Override
	public List<EventoCausa> findAtivos() throws DataException {
		return findAtivos(null);
	}
	
	@Override
	public List<EventoCausa> findAtivos(String order) throws DataException {
		throw new DataException("Entidade não possui coluna flag_ativo!");
	}
    
}
