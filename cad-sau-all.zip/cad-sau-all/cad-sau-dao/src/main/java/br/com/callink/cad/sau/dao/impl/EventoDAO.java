package br.com.callink.cad.sau.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.pojo.Util.DateUtil;
import br.com.callink.cad.sau.dao.IEventoDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.Assunto;
import br.com.callink.cad.sau.pojo.Evento;

public class EventoDAO extends GenericCadSauDAO<Evento> implements IEventoDAO {

	private static final long serialVersionUID = -467633090256331877L;

	public EventoDAO() {
		super(Evento.class);
	}

	public List<Evento> findAll() throws DataException {
		return this.findAll(null);
	}
	
    @Override
    public List<Evento> findAll(String order) throws DataException {
       
    	ResultSet result = null;
        PreparedStatement stmt = null;
    	List<Evento> list = new ArrayList<Evento>();
    	
    	try {
        	
        	StringBuilder select = new StringBuilder(SELECT)
        	.append(Evento.getSqlEvento())
        	.append(",").append(Assunto.getSqlAssunto())
        	.append(FROM).append(Evento.getSqlFromEvento())
        	.append(INNER_JOIN).append(Assunto.getSqlFromAssunto())
        	.append(" ON (Evento.ID_ASSUNTO = Assunto.ID_ASSUNTO) ");
        	
        	if(StringUtils.isNotBlank(order)){
        		select.append(String.format(" ORDER BY %s ", order));
        	}
        	
        	stmt = getPreparedStatement(select.toString());
        	stmt.execute();
            result = stmt.getResultSet();
            
            if(result!= null){		
				while (result.next()) {
					Evento evento = Evento.getEventoByResultSet(result);
					evento.setAssunto(Assunto.getAssuntoByResultSet(result));
					list.add(evento);
				}
			}
            
        	return list;
    	} catch (Exception ex) {
            throw new DataException(ex);
        } finally {
        	super.close(result);
        }
    }

    public List<Evento> findByExample(Evento example) throws DataException {
    	return this.findByExample(example, null);
    }
    
    @Override
    public List<Evento> findByExample(Evento example, String order) throws DataException {
        
    	if (example == null) {
            return null;
        }

    	ResultSet result = null;
        PreparedStatement stmt = null;
    	List<Evento> list = new ArrayList<Evento>();
    	int index =0;
    	
    	try {
        	
        	StringBuilder select = new StringBuilder(SELECT)
        	.append(Evento.getSqlEvento())
        	.append(",").append(Assunto.getSqlAssunto())
        	.append(FROM).append(Evento.getSqlFromEvento());
        	
        	if (example.getAssunto() != null && example.getAssunto().getIdAssunto() != null) {
        		select.append(INNER_JOIN).append(Assunto.getSqlFromAssunto());
        	} else {
        		select.append(LEFT_JOIN).append(Assunto.getSqlFromAssunto());
        	}
        	select.append(" ON (Evento.ID_ASSUNTO = Assunto.ID_ASSUNTO) ").append(WHERE_1_1);
    		
    		if(example.getIdEvento()!= null){
    			select.append(" AND Evento.ID_EVENTO = ? ");
    		}
    		if(StringUtils.isNotBlank(example.getNome())){
    			select.append(" AND Evento.NOME like ? ");
    		}
    		if(example.getDataCriacao()!= null){
    			select.append(" AND Evento.DATA_CRIACAO BETWEEN ? AND ? ");
    		}
    		if(example.getFlagAtivo()!= null){
    			select.append(" AND Evento.FLAG_ATIVO = ? ");
    		}
    		if(example.getAssunto()!= null && example.getAssunto().getIdAssunto()!= null){
    			select.append(" AND Evento.ID_ASSUNTO = ? ");
    		}
    		if(example.getFlagFinalizacaoAutomatica()!= null){
    			select.append(" AND Evento.FLAG_FINALIZACAO_AUTOMATICA = ? ");
    		}
    		if(StringUtils.isNotBlank(example.getEmail())){
    			select.append(" AND Evento.EMAIL LIKE ? ");
    		}
        	if(StringUtils.isNotBlank(order)){
        		select.append(String.format(" ORDER BY %s ", order));
        	}
        	
        	stmt = getPreparedStatement(select.toString());
        	
        	if(example.getIdEvento()!= null){
    			stmt.setInt(++index, example.getIdEvento());
    		}
    		if(StringUtils.isNotBlank(example.getNome())){
    			stmt.setString(++index, new StringBuilder(example.getNome()).append("%").toString());
    		}
    		if(example.getDataCriacao()!= null){
    			Date dataInicio = DateUtil.dataInicioDia(example.getDataCriacao());
				Date dataFinal =  DateUtil.dataFimDia(example.getDataCriacao());	
    			stmt.setDate(++index, new java.sql.Date(dataInicio.getTime()));
    			stmt.setDate(++index, new java.sql.Date(dataFinal.getTime()));
    		}
    		if(example.getFlagAtivo()!= null){
    			stmt.setBoolean(++index, example.getFlagAtivo());
    		}
    		if(example.getAssunto()!= null && example.getAssunto().getIdAssunto()!= null){
    			stmt.setInt(++index, example.getAssunto().getIdAssunto());
    		}
    		if(example.getFlagFinalizacaoAutomatica()!= null){
    			stmt.setBoolean(++index, example.getFlagFinalizacaoAutomatica());
    		}
    		if(StringUtils.isNotBlank(example.getEmail())){
    			stmt.setString(++index, new StringBuilder(example.getEmail()).append("%").toString());
    		}
        	
        	stmt.execute();
            result = stmt.getResultSet();
            
            if(result!= null){		
				while (result.next()) {
					Evento evento = Evento.getEventoByResultSet(result);
					evento.setAssunto(Assunto.getAssuntoByResultSet(result));
					list.add(evento);
				}
			}
            
        	return list;
    	} catch (SQLException ex) {
            throw new DataException(ex);
        } finally {
        	super.close(result);
        }
    }

    @Override
    public List<Evento> findByAssunto(Assunto assunto) throws DataException {
    	
    	if (assunto == null) {
            return null;
        }

    	ResultSet result = null;
        PreparedStatement stmt = null;
    	List<Evento> list = new ArrayList<Evento>();
    	
    	try {
        	
        	StringBuilder select = new StringBuilder(SELECT)
        	.append(Evento.getSqlEvento())
        	.append(FROM).append(Evento.getSqlFromEvento())
        	.append(WHERE).append(" Evento.ID_ASSUNTO = ? ")
        	.append(" AND Evento.FLAG_ATIVO = 1 ");
        	
        	stmt = getPreparedStatement(select.toString());
        	stmt.setInt(1,assunto.getIdAssunto());
        	stmt.execute();
            result = stmt.getResultSet();
            
            if(result!= null){		
				while (result.next()) {
					Evento evento = Evento.getEventoByResultSet(result);
					list.add(evento);
				}
			}
            
        	return list;
    	} catch (Exception ex) {
            throw new DataException(ex);
        } finally {
        	super.close(result);
        }
    	
    }

    @Override
    public List<Evento> findByAssuntoList(List<Assunto> assuntolist) throws DataException {
    	
    	ResultSet result = null;
        PreparedStatement stmt = null;
    	List<Evento> list = new ArrayList<Evento>();
    	
    	try {
        	
        	StringBuilder select = new StringBuilder(SELECT)
        	.append(Evento.getSqlEvento())
        	.append(FROM).append(Evento.getSqlFromEvento())
        	.append(WHERE).append(" Evento.FLAG_ATIVO = 1 ");
        	
        	if(assuntolist!= null && !assuntolist.isEmpty()){
        		select.append(String.format(" AND  Evento.ID_ASSUNTO IN (%s) ",inIdAssunto(assuntolist)));
        	}
        	
        	stmt = getPreparedStatement(select.toString());
        	stmt.execute();
            result = stmt.getResultSet();
            
            if(result!= null){		
				while (result.next()) {
					Evento evento = Evento.getEventoByResultSet(result);
					list.add(evento);
				}
			}
            
        	return list;
    	} catch (Exception ex) {
            throw new DataException(ex);
        } finally {
        	super.close(result);
        }
    	
    }

    @Override
    public List<Evento> findByAssuntoAndEvento(Assunto assunto, Evento evento) throws DataException {

    	ResultSet result = null;
        PreparedStatement stmt = null;
    	List<Evento> list = new ArrayList<Evento>();
    	int index =0;
    	
    	try {
        	
        	StringBuilder select = new StringBuilder(SELECT)
        	.append(Evento.getSqlEvento())
        	.append(FROM).append(Evento.getSqlFromEvento())
        	.append(WHERE).append(" Evento.FLAG_ATIVO = 1 ");
        	
        	if(assunto!= null && assunto.getIdAssunto()!= null){
        		select.append(" AND  Evento.ID_ASSUNTO = ? ");
        	}
        	
        	if(evento!= null && StringUtils.isNotBlank(evento.getNome())){
        		select.append(" AND  Evento.NOME like ? ");
        	}
        	
        	stmt = getPreparedStatement(select.toString());
        	
        	if(assunto!= null && assunto.getIdAssunto()!= null){
        		stmt.setInt(++index, assunto.getIdAssunto());
        	}
        	
        	if(evento!= null && StringUtils.isNotBlank(evento.getNome())){
        		stmt.setString(++index, new StringBuilder(evento.getNome()).append("%").toString());
        	}
        	
        	stmt.execute();
            result = stmt.getResultSet();
            
            if(result!= null){		
				while (result.next()) {
					Evento ev = Evento.getEventoByResultSet(result);
					list.add(ev);
				}
			}
            
        	return list;
    	} catch (Exception ex) {
            throw new DataException(ex);
        } finally {
        	super.close(result);
        }
    	
    }
    
    @Override
    public Evento findByPk(Object id) throws DataException {
       
    	ResultSet result = null;
        PreparedStatement stmt = null;
    	
    	try {
        	
        	StringBuilder select = new StringBuilder(SELECT)
        	.append(Evento.getSqlEvento())
        	.append(",").append(Assunto.getSqlAssunto())
        	.append(FROM).append(Evento.getSqlFromEvento())
        	.append(INNER_JOIN).append(Assunto.getSqlFromAssunto())
        	.append(" ON (Evento.ID_ASSUNTO = Assunto.ID_ASSUNTO) ")
        	.append(WHERE).append(" Evento.ID_EVENTO = ? ");

        	stmt = getPreparedStatement(select.toString());
        	Evento evento = (Evento) id;
        	stmt.setInt(1,evento.getIdEvento());
        	stmt.execute();
            result = stmt.getResultSet();
            
            if(result!= null){		
				while (result.next()) {
					evento = Evento.getEventoByResultSet(result);
					evento.setAssunto(Assunto.getAssuntoByResultSet(result));
				}
			}
            
        	return evento;
    	} catch (Exception ex) {
            throw new DataException(ex);
        } finally {
        	super.close(result);
        }
    }
    
    private static String inIdAssunto(List<Assunto> assuntoList) {
		
		StringBuilder idAssuntos = new StringBuilder();
		for (Assunto assunto : assuntoList) {
			idAssuntos.append(assunto.getIdAssunto()).append(",");
		}
		
		return idAssuntos.toString().substring(0, idAssuntos.length() - 1);
	}
    
    public List<Evento> findAtivos() throws DataException {
		return this.findAtivos(null);
	}
	
    @Override
    public List<Evento> findAtivos(String order) throws DataException {
       
    	ResultSet result = null;
        PreparedStatement stmt = null;
    	List<Evento> list = new ArrayList<Evento>();
    	
    	try {
        	
        	StringBuilder select = new StringBuilder(SELECT)
        	.append(Evento.getSqlEvento())
        	.append(",").append(Assunto.getSqlAssunto())
        	.append(FROM).append(Evento.getSqlFromEvento())
        	.append(INNER_JOIN).append(Assunto.getSqlFromAssunto())
        	.append(" ON (Evento.ID_ASSUNTO = Assunto.ID_ASSUNTO) ")
        	.append(WHERE)
        	.append(" Evento.FLAG_ATIVO = 1 ");
        	
        	if(StringUtils.isNotBlank(order)){
        		select.append(String.format(" ORDER BY %s ", order));
        	}
        	
        	stmt = getPreparedStatement(select.toString());
        	stmt.execute();
            result = stmt.getResultSet();
            
            if(result!= null){		
				while (result.next()) {
					Evento evento = Evento.getEventoByResultSet(result);
					evento.setAssunto(Assunto.getAssuntoByResultSet(result));
					list.add(evento);
				}
			}
            
        	return list;
    	} catch (Exception ex) {
            throw new DataException(ex);
        } finally {
        	super.close(result);
        }
    }
    
}
