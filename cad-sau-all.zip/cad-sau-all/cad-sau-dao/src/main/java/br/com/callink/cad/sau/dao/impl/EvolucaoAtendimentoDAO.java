/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.sau.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.persistence.Query;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.pojo.Util.DateUtil;
import br.com.callink.cad.sau.dao.IEvolucaoAtendimentoDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.EvolucaoAtendimento;

/**
 *
 * @author brunomt
 */
public class EvolucaoAtendimentoDAO extends GenericCadSauDAO<EvolucaoAtendimento> implements IEvolucaoAtendimentoDAO {

	private static final long serialVersionUID = -7853145219207420886L;

	public EvolucaoAtendimentoDAO() {
		super(EvolucaoAtendimento.class);
	}

	@Override
    public void removeEvolucaoAtendimento() throws DataException {
        try {
            
        	Calendar calendar = new GregorianCalendar(Calendar.getInstance().get(Calendar.YEAR),Calendar.getInstance().get(Calendar.MONTH),Calendar.getInstance().get(Calendar.DAY_OF_MONTH));
        	Query query = getEntityManager().createNativeQuery("delete from tb_evolucao_atendimento where data_relatorio = :data ");
        	query.setParameter("data", calendar.getTime());
        	query.executeUpdate();
        	
        } catch (Exception ex) {
            throw new DataException("Erro ao deletar a EvolucaoAtendimento.",ex);
        }
        
    }

    @Override
    public List<EvolucaoAtendimento> buscaEvolucaoAtendimento(Date dataInicio, Date dataFinal) throws DataException {
    	
    	ResultSet result = null;
        PreparedStatement stmt = null;
    	List<EvolucaoAtendimento> list = new ArrayList<EvolucaoAtendimento>();
    	String dtInicio = DateUtil.convertDateString(dataInicio);
    	String dtFinal = DateUtil.convertDateString(dataFinal);
    	
    	try {
        	
    		StringBuilder select = new StringBuilder(SELECT)
    		.append(EvolucaoAtendimento.getSqlCamposEvolucaoAtendimento())
    		.append(FROM).append(EvolucaoAtendimento.getSqlFromEvolucaoAtendimento())
    		.append(WHERE).append(String.format(" EvolucaoAtendimento.data_relatorio BETWEEN ? AND ? ",dtInicio,dtFinal))
    		.append(" ORDER BY EvolucaoAtendimento.data_relatorio ");
        	
    		stmt = getPreparedStatement(select.toString());
    		stmt.setString(1, dtInicio);
    		stmt.setString(2, dtFinal);
    		
        	stmt.execute();
            result = stmt.getResultSet();
            
            if(result!= null){		
				while (result.next()) {
					EvolucaoAtendimento evolucao = EvolucaoAtendimento.getEvolucaoAtendimentoByResultSet(result);
					list.add(evolucao);
				}
			}
        	return list;
        	
    	} catch (Exception ex) {
            throw new DataException(ex);
        } finally {
        	super.close(result);
        }
    }
    
    public List<EvolucaoAtendimento> findAll() throws DataException {
    	return this.findAll(null);
    }
    
    @Override
    public List<EvolucaoAtendimento> findAll(String order) throws DataException {
    	
    	ResultSet result = null;
        PreparedStatement stmt = null;
    	List<EvolucaoAtendimento> list = new ArrayList<EvolucaoAtendimento>();
    	
    	try {
        	
        	StringBuilder select = new StringBuilder(SELECT)
        	.append(EvolucaoAtendimento.getSqlCamposEvolucaoAtendimento())
        	.append(FROM).append(EvolucaoAtendimento.getSqlFromEvolucaoAtendimento());
        	
        	if(StringUtils.isNotBlank(order)){
        		select.append(String.format(" ORDER BY %s ", order));
        	}
        	
        	stmt = getPreparedStatement(select.toString());
        	stmt.execute();
            result = stmt.getResultSet();
            
            if(result!= null){		
				while (result.next()) {
					EvolucaoAtendimento evolucao = EvolucaoAtendimento.getEvolucaoAtendimentoByResultSet(result);
					list.add(evolucao);
				}
			}
            
        	return list;
    	} catch (Exception ex) {
            throw new DataException(ex);
        } finally {
        	super.close(result);
        }
    }
    
    @Override
    public List<EvolucaoAtendimento> findByExample( EvolucaoAtendimento example) throws DataException {
    	return this.findByExample(example, null);
    }
    
    @Override
    public List<EvolucaoAtendimento> findByExample( EvolucaoAtendimento example,  String order) throws DataException {
    	
    	ResultSet result = null;
        PreparedStatement stmt = null;
    	List<EvolucaoAtendimento> list = new ArrayList<EvolucaoAtendimento>();
    	int index =0;
    	
    	try {
        	
        	StringBuilder select = new StringBuilder(SELECT)
        	.append(EvolucaoAtendimento.getSqlCamposEvolucaoAtendimento())
        	.append(FROM).append(EvolucaoAtendimento.getSqlFromEvolucaoAtendimento())
        	.append(WHERE_1_1);
        	
        	if(example != null){
        		
        		if(example.getIdEvolucaoAtendimento()!= null){
        			select.append(" AND EvolucaoAtendimento.id_evolucao_atendimento = ? ");
        		}
        		if(example.getDataRelatorio() != null){
        			select.append(" AND EvolucaoAtendimento.data_relatorio BETWEEN ? AND ? ");
        		}
        		if(StringUtils.isNotBlank(example.getTipoManifestacao())){
        			select.append(" AND EvolucaoAtendimento.tipo_maifestacao like ? ");
        		}
        		if(example.getTotalEntrantes()!= null){
        			select.append(" AND EvolucaoAtendimento.total_entrantes = ? ");
        		}
        		if(example.getTotalReabertos() != null){
        			select.append(" AND EvolucaoAtendimento.total_reabertos = ? ");
        		}
        		if(example.getTotalReabertosEntrantes() != null){
        			select.append(" AND EvolucaoAtendimento.total_reabertos_entrantes = ? ");
        		}
        		if(example.getPendenteDentroPrazo() != null){
        			select.append(" AND EvolucaoAtendimento.pendente_dentro_prazo = ? ");
        		}
        		if(example.getPendenteForaPrazo()!= null){
        			select.append(" AND EvolucaoAtendimento.pendente_fora_prazo = ? ");
        		}
        		if(example.getPendenteForaPrazoPercentual() != null){
        			select.append(" AND EvolucaoAtendimento.pendente_fora_prazo_percentual = ? ");
        		}
        		if(example.getPendenteTotal() != null){
        			select.append(" AND EvolucaoAtendimento.pendente_total = ? ");
        		}
        		if(example.getFechadoDentroPrazo() != null){
        			select.append(" AND EvolucaoAtendimento.fechado_dentro_prazo = ? ");
        		}
        		if(example.getFechadoForaPrazo() != null){
        			select.append(" AND EvolucaoAtendimento.fechado_fora_prazo = ? ");
        		}
        		if(example.getFechadoForaPrazoPercentual() != null){
        			select.append(" AND EvolucaoAtendimento.fechado_fora_prazo_percentual = ? ");
        		}
        		if(example.getFechadoTotal() != null){
        			select.append(" AND EvolucaoAtendimento.fechado_total = ? ");
        		}
        		if(example.getSaldoPercentual() != null){
        			select.append(" AND EvolucaoAtendimento.saldo_percentual = ? ");
        		}
        		if(example.getSaldoQuantidade() != null){
        			select.append(" AND EvolucaoAtendimento.saldo_quantidade = ? ");
        		}
        	}
        	
        	if(StringUtils.isNotBlank(order)){
        		select.append(String.format(" ORDER BY %s ", order));
        	}
        	
        	stmt = getPreparedStatement(select.toString());
        	
        	if(example != null){
        		
        		if(example.getIdEvolucaoAtendimento()!= null){
        			stmt.setInt(++index, example.getIdEvolucaoAtendimento());
        		}
        		if(example.getDataRelatorio() != null){
        			Date dataInicio = DateUtil.dataInicioDia(example.getDataRelatorio());
					Date dataFinal =  DateUtil.dataFimDia(example.getDataRelatorio());
        			stmt.setDate(++index, new java.sql.Date(dataInicio.getTime()));
        			stmt.setDate(++index, new java.sql.Date(dataFinal.getTime()));
        		}
        		if(StringUtils.isNotBlank(example.getTipoManifestacao())){
        			stmt.setString(++index, example.getTipoManifestacao());
        		}
        		if(example.getTotalEntrantes()!= null){
        			stmt.setInt(++index, example.getTotalEntrantes());
        		}
        		if(example.getTotalReabertos() != null){
        			stmt.setInt(++index, example.getTotalReabertos());
        		}
        		if(example.getTotalReabertosEntrantes() != null){
        			stmt.setInt(++index, example.getTotalReabertosEntrantes());
        		}
        		if(example.getPendenteDentroPrazo() != null){
        			stmt.setInt(++index, example.getPendenteDentroPrazo());
        		}
        		if(example.getPendenteForaPrazo()!= null){
        			stmt.setInt(++index, example.getPendenteForaPrazo());
        		}
        		if(example.getPendenteForaPrazoPercentual() != null){
        			stmt.setDouble(++index, example.getPendenteForaPrazoPercentual());
        		}
        		if(example.getPendenteTotal() != null){
        			stmt.setInt(++index, example.getPendenteTotal());
        		}
        		if(example.getFechadoDentroPrazo() != null){
        			stmt.setInt(++index, example.getFechadoDentroPrazo());
        		}
        		if(example.getFechadoForaPrazo() != null){
        			stmt.setInt(++index, example.getFechadoForaPrazo());
        		}
        		if(example.getFechadoForaPrazoPercentual() != null){
        			stmt.setDouble(++index, example.getFechadoForaPrazoPercentual());
        		}
        		if(example.getFechadoTotal() != null){
        			stmt.setInt(++index, example.getFechadoTotal());
        		}
        		if(example.getSaldoPercentual() != null){
        			stmt.setDouble(++index, example.getSaldoPercentual());
        		}
        		if(example.getSaldoQuantidade() != null){
        			stmt.setInt(++index, example.getSaldoQuantidade());
        		}
        	}
        	
        	stmt.execute();
            result = stmt.getResultSet();
            
            if(result!= null){		
				while (result.next()) {
					EvolucaoAtendimento evolucao = EvolucaoAtendimento.getEvolucaoAtendimentoByResultSet(result);
					list.add(evolucao);
				}
			}
            
        	return list;
    	} catch (SQLException ex) {
            throw new DataException(ex);
        } finally {
        	super.close(result);
        }
    }
    
    @Override
    public EvolucaoAtendimento findByPk(Object id) throws DataException {
    	
    	ResultSet result = null;
        PreparedStatement stmt = null;

        try {
        	
        	StringBuilder select = new StringBuilder(SELECT)
        	.append(EvolucaoAtendimento.getSqlCamposEvolucaoAtendimento())
        	.append(FROM).append(EvolucaoAtendimento.getSqlFromEvolucaoAtendimento())
        	.append(WHERE).append(" EvolucaoAtendimento.id_evolucao_atendimento = ? ");
        	
        	EvolucaoAtendimento evolucaoAtendimento = (EvolucaoAtendimento) id;
        	
        	stmt = getPreparedStatement(select.toString());
        	stmt.setInt(1, evolucaoAtendimento.getIdEvolucaoAtendimento());
        	stmt.execute();
            result = stmt.getResultSet();
            
            if(result!= null){		
				while (result.next()) {
					evolucaoAtendimento = EvolucaoAtendimento.getEvolucaoAtendimentoByResultSet(result);
				}
			}
            
        	return evolucaoAtendimento;
    	} catch (Exception ex) {
            throw new DataException(ex);
        } finally {
        	super.close(result);
        }
    }

	@Override
	public List<EvolucaoAtendimento> findAtivos(String order)
			throws DataException {
		throw new DataException("Entidade nao possui coluna flag_ativo!");
	}

	@Override
	public List<EvolucaoAtendimento> findAtivos() throws DataException {
		return findAtivos(null);
	}
    
}
