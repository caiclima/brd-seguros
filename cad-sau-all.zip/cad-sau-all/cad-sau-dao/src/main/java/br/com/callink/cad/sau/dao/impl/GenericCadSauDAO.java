package br.com.callink.cad.sau.dao.impl;

import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import br.com.callink.cad.dao.impl.GenericCadDAO;
import br.com.callink.cad.pojo.entity.IEntity;
import br.com.callink.cad.sau.dao.IGenericCadSauDAO;
import br.com.callink.cad.sau.exception.DataException;

public abstract class GenericCadSauDAO<T extends IEntity<Integer>> extends GenericCadDAO<T> implements
        IGenericCadSauDAO<T> {

	private static final long serialVersionUID = 7876992070108071871L;

	public GenericCadSauDAO(Class<T> entityClass) {
		super(entityClass);
	}
	
	@PersistenceContext(unitName = "CAD_PU")
	private EntityManager entityManager;
	
	@Resource(lookup = "java:jboss/datasources/CAD_DS")
	private DataSource dataSource; 
	
	@Override
	public EntityManager getEntityManager(){
		return entityManager;
	}
	
	@Override
	public DataSource getDataSource(){
		return dataSource;
	}
	
	@Override
	public abstract List<T> findByExample(T t) throws DataException;
	
	@Override
	public abstract List<T> findByExample(T t, String order) throws DataException;

	@Override
	public abstract List<T> findAll(String order) throws DataException;
	
	@Override
	public abstract List<T> findAll() throws DataException;

	@Override
	public abstract T findByPk(Object id) throws DataException;
	
	@Override
	public abstract List<T> findAtivos(String order) throws DataException;
	
	@Override
	public abstract List<T> findAtivos() throws DataException;
	
}
