package br.com.callink.cad.sau.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.pojo.Util.DateUtil;
import br.com.callink.cad.sau.dao.IJuncaoDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.Juncao;

public class JuncaoDAO extends GenericCadSauDAO<Juncao> implements IJuncaoDAO {

	private static final long serialVersionUID = -6008946612819538896L;

	public JuncaoDAO() {
		super(Juncao.class);
	}
	
	@Override
    public List<Juncao> findAll() throws DataException {
		return this.findAll(null);
	}
	
	@Override
    public List<Juncao> findAll(String order) throws DataException {
    	
    	ResultSet result = null;
        PreparedStatement stmt = null;
    	List<Juncao> list = new ArrayList<Juncao>();
    	
    	try {
        	
        	StringBuilder select = new StringBuilder(SELECT)
        	.append(Juncao.getSqlCamposJuncao())
        	.append(FROM).append(Juncao.getSqlFromJuncao());
        	
        	if(StringUtils.isNotBlank(order)){
        		select.append(String.format(" ORDER BY %s ", order));
        	}
        	
        	stmt = getPreparedStatement(select.toString());
        	stmt.execute();
            result = stmt.getResultSet();
            
            if(result!= null){		
				while (result.next()) {
					Juncao juncao = Juncao.getJuncaoByResultSet(result);
					list.add(juncao);
				}
			}
            
        	return list;
    	} catch (Exception ex) {
            throw new DataException(ex);
        } finally {
        	super.close(result);
        }
    }
	
	public List<Juncao> findByExample(Juncao example) throws DataException {
		return this.findByExample(example, null);
	}
	
	@Override
    public List<Juncao> findByExample(Juncao example,  String order) throws DataException {
    	
    	ResultSet result = null;
        PreparedStatement stmt = null;
    	List<Juncao> list = new ArrayList<Juncao>();
    	int index =0;
    	
    	try {
        	
        	StringBuilder select = new StringBuilder(SELECT)
        	.append(Juncao.getSqlCamposJuncao())
        	.append(FROM).append(Juncao.getSqlFromJuncao())
        	.append(WHERE_1_1);
        	
        	if(example!= null){
        		
        		if(example.getIdJuncao()!= null){
        			select.append(" AND Juncao.ID_JUNCAO = ? ");
        		}
        		if(StringUtils.isNotBlank(example.getNome())){
        			select.append(" AND Juncao.NOME like ? ");
        		}
        		if(example.getDataCriacao()!= null){
        			select.append(" AND Juncao.DATA_CRIACAO BETWEEN ? AND ? ");
        		}
        		if(example.getFlagAtivo()!= null){
        			select.append(" AND Juncao.FLAG_ATIVO = ? ");
        		}
        		
        	}
        	
        	if(StringUtils.isNotBlank(order)){
        		select.append(String.format(" ORDER BY %s ", order));
        	}
        	
        	stmt = getPreparedStatement(select.toString());
        	
        	if(example!= null){
        		
        		if(example.getIdJuncao()!= null){
        			stmt.setInt(++index, example.getIdJuncao());
        		}
        		if(StringUtils.isNotBlank(example.getNome())){
        			stmt.setString(++index, new StringBuilder(example.getNome()).append("%").toString());
        		}
        		if(example.getDataCriacao()!= null){
        			Date dataInicio = DateUtil.dataInicioDia(example.getDataCriacao());
					Date dataFinal =  DateUtil.dataFimDia(example.getDataCriacao());	
        			stmt.setDate(++index, new java.sql.Date(dataInicio.getTime()));
        			stmt.setDate(++index, new java.sql.Date(dataFinal.getTime()));
        		}
        		if(example.getFlagAtivo()!= null){
        			stmt.setBoolean(++index, example.getFlagAtivo());
        		}
        	}
        	
        	
        	stmt.execute();
            result = stmt.getResultSet();
            
            if(result!= null){		
				while (result.next()) {
					Juncao juncao = Juncao.getJuncaoByResultSet(result);
					list.add(juncao);
				}
			}
            
        	return list;
    	} catch (Exception ex) {
            throw new DataException(ex);
        } finally {
        	super.close(result);
        }
    }
	
	@Override
    public Juncao findByPk(Object id) throws DataException {
    	
    	ResultSet result = null;
        PreparedStatement stmt = null;
    	
    	try {
        	
        	StringBuilder select = new StringBuilder(SELECT)
        	.append(Juncao.getSqlCamposJuncao())
        	.append(FROM).append(Juncao.getSqlFromJuncao())
        	.append(WHERE).append(" Juncao.ID_JUNCAO = ? ");
        	
        	Juncao juncao = (Juncao) id;
        	stmt = getPreparedStatement(select.toString());
        	stmt.setInt(1, juncao.getIdJuncao());
        	stmt.execute();
            result = stmt.getResultSet();
            
            if(result!= null){		
				while (result.next()) {
					juncao = Juncao.getJuncaoByResultSet(result);
				}
			}
            
        	return juncao;
    	} catch (Exception ex) {
            throw new DataException(ex);
        } finally {
        	super.close(result);
        }
    }

	@Override
	public List<Juncao> findAtivos(String order) throws DataException {
		
		ResultSet result = null;
        PreparedStatement stmt = null;
    	List<Juncao> list = new ArrayList<Juncao>();
    	
    	try {
        	
        	StringBuilder select = new StringBuilder(SELECT)
        	.append(Juncao.getSqlCamposJuncao())
        	.append(FROM).append(Juncao.getSqlFromJuncao())
        	.append(WHERE).append(" Juncao.FLAG_ATIVO = 1 ");
        	
        	if(StringUtils.isNotBlank(order)){
        		select.append(String.format(" ORDER BY %s ", order));
        	}
        	
        	stmt = getPreparedStatement(select.toString());
        	stmt.execute();
            result = stmt.getResultSet();
            
            if(result!= null){		
				while (result.next()) {
					Juncao juncao = Juncao.getJuncaoByResultSet(result);
					list.add(juncao);
				}
			}
            
        	return list;
    	} catch (Exception ex) {
            throw new DataException(ex);
        } finally {
        	super.close(result);
        }
	}

	@Override
	public List<Juncao> findAtivos() throws DataException {
		return this.findAtivos(null);
	}
	
}
