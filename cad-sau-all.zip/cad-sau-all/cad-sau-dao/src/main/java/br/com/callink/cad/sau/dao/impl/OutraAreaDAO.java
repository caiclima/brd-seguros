/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.sau.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.pojo.Util.DateUtil;
import br.com.callink.cad.sau.dao.IOutraAreaDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.OutraArea;

/**
 *
 * @author ubuntu
 */
public class OutraAreaDAO extends GenericCadSauDAO<OutraArea> implements IOutraAreaDAO{

	private static final long serialVersionUID = -6295881134929288850L;

	public OutraAreaDAO() {
		super(OutraArea.class);
	}
    
	@Override
	public List<OutraArea> findAll() throws DataException {
		return this.findAll(null);
	}
	
	@Override
	public List<OutraArea> findAll(String order) throws DataException {

		ResultSet result = null;
		PreparedStatement stmt = null;
		List<OutraArea> list = new ArrayList<OutraArea>();

		try {

			StringBuilder select = new StringBuilder(SELECT)
					.append(OutraArea.getSqlOutraArea()).append(FROM)
					.append(OutraArea.getSqlFromOutraArea());

			if (StringUtils.isNotBlank(order)) {
				select.append(String.format(" ORDER BY %s ", order));
			}

			stmt = getPreparedStatement(select.toString());
			stmt.execute();
			result = stmt.getResultSet();

			if (result != null) {
				while (result.next()) {
					OutraArea outra = OutraArea.getOutraAreaByResultSet(result);
					list.add(outra);
				}
			}

			return list;
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(result);
		}
	}
	
	@Override
	public List<OutraArea> findByExample(OutraArea example) throws DataException {
		return this.findByExample(example, null);
	}
	
	@Override
	public List<OutraArea> findByExample(OutraArea example, String order) throws DataException {

		ResultSet result = null;
		PreparedStatement stmt = null;
		List<OutraArea> list = new ArrayList<OutraArea>();
		int index = 0;
		
		try {

			StringBuilder select = new StringBuilder(SELECT)
					.append(OutraArea.getSqlOutraArea()).append(FROM)
					.append(OutraArea.getSqlFromOutraArea())
					.append(WHERE_1_1);
			
			if(example!= null){
				
				if(example.getIdOutraArea()!= null){
					select.append(" AND OutraArea.ID_OUTRA_AREA = ? ");
				}
				if(StringUtils.isNotBlank(example.getNome())){
					select.append(" AND OutraArea.NOME like ? ");
				}
				if(example.getDataCriacao()!= null){
					select.append(" AND OutraArea.DATA_CRIACAO BETWEEN ? AND ? ");
				}
				if(example.getFlagAtivo()!= null){
					select.append(" AND OutraArea.FLAG_ATIVO = ? ");
				}
			}

			if (StringUtils.isNotBlank(order)) {
				select.append(String.format(" ORDER BY %s ", order));
			}

			stmt = getPreparedStatement(select.toString());
			
			if(example!= null){
				
				if(example.getIdOutraArea()!= null){
					stmt.setInt(++index, example.getIdOutraArea());
				}
				if(StringUtils.isNotBlank(example.getNome())){
					stmt.setString(++index, new StringBuilder(example.getNome()).append("%").toString());
				}
				if(example.getDataCriacao()!= null){
					Date dataInicio = DateUtil.dataInicioDia(example.getDataCriacao());
					Date dataFinal =  DateUtil.dataFimDia(example.getDataCriacao());	
					stmt.setDate(++index, new java.sql.Date(dataInicio.getTime()));
					stmt.setDate(++index, new java.sql.Date(dataFinal.getTime()));
				}
				if(example.getFlagAtivo()!= null){
					stmt.setBoolean(++index, example.getFlagAtivo());
				}
			}
			
			stmt.execute();
			result = stmt.getResultSet();

			if (result != null) {
				while (result.next()) {
					OutraArea outra = OutraArea.getOutraAreaByResultSet(result);
					list.add(outra);
				}
			}

			return list;
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(result);
		}
	}
	
	@Override
	public OutraArea findByPk(Object id) throws DataException {

		ResultSet result = null;
		PreparedStatement stmt = null;
		
		try {

			StringBuilder select = new StringBuilder(SELECT)
					.append(OutraArea.getSqlOutraArea()).append(FROM)
					.append(OutraArea.getSqlFromOutraArea())
					.append(WHERE).append(" OutraArea.ID_OUTRA_AREA = ? ");
					
			OutraArea outra = (OutraArea) id;
			
			stmt = getPreparedStatement(select.toString());
			stmt.setInt(1, outra.getIdOutraArea());
			stmt.execute();
			result = stmt.getResultSet();

			if (result != null) {
				while (result.next()) {
					outra = OutraArea.getOutraAreaByResultSet(result);
				}
			}

			return outra;
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(result);
		}
	}

	@Override
	public List<OutraArea> findAtivos(String order) throws DataException {
		
		ResultSet result = null;
		PreparedStatement stmt = null;
		List<OutraArea> list = new ArrayList<OutraArea>();

		try {

			StringBuilder select = new StringBuilder(SELECT)
					.append(OutraArea.getSqlOutraArea()).append(FROM)
					.append(OutraArea.getSqlFromOutraArea())
					.append(WHERE).append(" OutraArea.FLAG_ATIVO = 1 ");

			if (StringUtils.isNotBlank(order)) {
				select.append(String.format(" ORDER BY %s ", order));
			}

			stmt = getPreparedStatement(select.toString());
			stmt.execute();
			result = stmt.getResultSet();

			if (result != null) {
				while (result.next()) {
					OutraArea outra = OutraArea.getOutraAreaByResultSet(result);
					list.add(outra);
				}
			}

			return list;
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(result);
		}
	}

	@Override
	public List<OutraArea> findAtivos() throws DataException {
		return this.findAtivos(null);
	}
	
}
