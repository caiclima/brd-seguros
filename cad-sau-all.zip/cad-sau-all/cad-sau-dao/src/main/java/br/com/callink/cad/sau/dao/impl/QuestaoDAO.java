package br.com.callink.cad.sau.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.sau.dao.IQuestaoDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.Questao;
import br.com.callink.cad.sau.pojo.Questionario;

public class QuestaoDAO extends GenericCadSauDAO<Questao> implements IQuestaoDAO {

	private static final long serialVersionUID = 6441859626391860619L;

	public QuestaoDAO() {
		super(Questao.class);
	}

    @Override
    public List<Questao> findAllQuestaoByQuestionario(Questionario questionario) throws DataException {
    	
    	ResultSet result = null;
        PreparedStatement stmt = null;
    	List<Questao> list = new ArrayList<Questao>();
    	
    	try {
        	
        	StringBuilder select = new StringBuilder(SELECT)
        	.append(Questao.getSqlCamposQuestao())
        	.append(FROM).append(Questao.getSqlFromQuestao())
        	.append(WHERE).append(" Questao.id_questionario = ? ");
        	
        	stmt = getPreparedStatement(select.toString());
        	stmt.setInt(1, questionario.getIdQuestionario());
        	stmt.execute();
            result = stmt.getResultSet();
            
            if(result!= null){		
				while (result.next()) {
					Questao questao = Questao.getQuestaoByResultSet(result);
					list.add(questao);
				}
			}
            
        	return list;
    	} catch (Exception ex) {
            throw new DataException(ex);
        } finally {
        	super.close(result);
        }
    }
    
    @Override
    public List<Questao> findAll() throws DataException {
    	return this.findAll(null);
    }
    
    @Override
    public List<Questao> findAll(String order) throws DataException {
    	
    	ResultSet result = null;
        PreparedStatement stmt = null;
    	List<Questao> list = new ArrayList<Questao>();
    	
    	try {
        	
        	StringBuilder select = new StringBuilder(SELECT)
        	.append(Questao.getSqlCamposQuestao())
        	.append(FROM).append(Questao.getSqlFromQuestao());
        	
        	if(StringUtils.isNotBlank(order)){
        		select.append(String.format(" ORDER BY %s ", order));
        	}
        	
        	stmt = getPreparedStatement(select.toString());
        	stmt.execute();
            result = stmt.getResultSet();
            
            if(result!= null){		
				while (result.next()) {
					Questao questao = Questao.getQuestaoByResultSet(result);
					list.add(questao);
				}
			}
            
        	return list;
    	} catch (Exception ex) {
            throw new DataException(ex);
        } finally {
        	super.close(result);
        }
    }
    
    @Override
    public List<Questao> findByExample(Questao example) throws DataException {
    	return this.findByExample(example, null);
    }
    
    @Override
    public List<Questao> findByExample(Questao example, String order) throws DataException {
    	
    	ResultSet result = null;
        PreparedStatement stmt = null;
    	List<Questao> list = new ArrayList<Questao>();
    	int index = 0;
    	
    	try {
        	
        	StringBuilder select = new StringBuilder(SELECT)
        	.append(Questao.getSqlCamposQuestao())
        	.append(FROM).append(Questao.getSqlFromQuestao())
        	.append(WHERE_1_1);
        	
        	if(example!=null){
        		
        		if(example.getIdQuestao()!= null){
        			select.append(" AND Questao.id_questao = ? ");
        		}
        		if(example.getQuestaoPai() != null && example.getQuestaoPai().getIdQuestao()!= null){
        			select.append(" AND Questao.id_questao_pai = ? ");
        		}
        		if(example.getQuestionario()!= null && example.getQuestionario().getIdQuestionario()!= null){
        			select.append(" AND Questao.id_questionario = ? ");
        		}
        		if(StringUtils.isNotBlank(example.getDescricao())){
        			select.append(" AND Questao.descricao like ? ");
        		}
        		if(StringUtils.isNotBlank(example.getTipoResposta())){
        			select.append(" AND Questao.tipo_resposta like ? ");
        		}
        		if(StringUtils.isNotBlank(example.getTipoConteudo())){
        			select.append(" AND Questao.tipo_conteudo like ? ");
        		}
        		if(StringUtils.isNotBlank(example.getPossiveisRespostas())){
        			select.append(" AND Questao.possiveis_respostas like ? ");
        		}
        		if(StringUtils.isNotBlank(example.getRespostaPadrao())){
        			select.append(" AND Questao.resposta_padrao like ? ");
        		}
        		if(example.getOrdem()!= null){
        			select.append(" AND Questao.ordem = ? ");
        		}
        		if(example.getRequerida()!= null){
        			select.append(" AND Questao.requerida = ? ");
        		}
        		if(StringUtils.isNotBlank(example.getMensagemRequerida())){
        			select.append(" AND Questao.mensagem_requerida = ? ");
        		}
        		if(StringUtils.isNotBlank(example.getRespostaApresentacao())){
        			select.append(" AND Questao.resposta_apresentacao = ? ");
        		}
        		if(StringUtils.isNotBlank(example.getOperadorApresentacao())){
        			select.append(" AND Questao.operador_apresentacao = ? ");
        		}
        		if(example.getFlagAtivo()!= null){
        			select.append(" AND Questao.flag_ativo = ? ");
        		}
        		
        	}
        	
        	if(StringUtils.isNotBlank(order)){
        		select.append(String.format(" ORDER BY %s ", order));
        	}
        	
        	stmt = getPreparedStatement(select.toString());
        	
        	if(example!=null){
        		
        		if(example.getIdQuestao()!= null){
        			stmt.setInt(++index, example.getIdQuestao());
        		}
        		if(example.getQuestaoPai() != null && example.getQuestaoPai().getIdQuestao()!= null){
        			stmt.setInt(++index, example.getQuestaoPai().getIdQuestao());
        		}
        		if(example.getQuestionario()!= null && example.getQuestionario().getIdQuestionario()!= null){
        			stmt.setInt(++index, example.getQuestionario().getIdQuestionario());
        		}
        		if(StringUtils.isNotBlank(example.getDescricao())){
        			stmt.setString(++index, new StringBuilder(example.getDescricao()).append("%").toString());
        		}
        		if(StringUtils.isNotBlank(example.getTipoResposta())){
        			stmt.setString(++index, new StringBuilder(example.getTipoResposta()).append("%").toString());
        		}
        		if(StringUtils.isNotBlank(example.getTipoConteudo())){
        			stmt.setString(++index, new StringBuilder(example.getTipoConteudo()).append("%").toString());
        		}
        		if(StringUtils.isNotBlank(example.getPossiveisRespostas())){
        			stmt.setString(++index, new StringBuilder(example.getPossiveisRespostas()).append("%").toString());
        		}
        		if(StringUtils.isNotBlank(example.getRespostaPadrao())){
        			stmt.setString(++index, new StringBuilder(example.getRespostaPadrao()).append("%").toString());
        		}
        		if(example.getOrdem()!= null){
        			stmt.setString(++index, new StringBuilder(example.getOrdem()).append("%").toString());
        		}
        		if(example.getRequerida()!= null){
        			stmt.setBoolean(++index, example.getRequerida());
        		}
        		if(StringUtils.isNotBlank(example.getMensagemRequerida())){
        			stmt.setString(++index, new StringBuilder(example.getMensagemRequerida()).append("%").toString());
        		}
        		if(StringUtils.isNotBlank(example.getRespostaApresentacao())){
        			stmt.setString(++index, new StringBuilder(example.getRespostaApresentacao()).append("%").toString());
        		}
        		if(StringUtils.isNotBlank(example.getOperadorApresentacao())){
        			stmt.setString(++index,new StringBuilder(example.getOperadorApresentacao()).append("%").toString());
        		}
        		if(example.getFlagAtivo()!= null){
        			stmt.setBoolean(++index,example.getFlagAtivo());
        		}
        	}
        	
        	stmt.execute();
            result = stmt.getResultSet();
            
            if(result!= null){		
				while (result.next()) {
					Questao questao = Questao.getQuestaoByResultSet(result);
					list.add(questao);
				}
			}
            
        	return list;
    	} catch (SQLException ex) {
            throw new DataException(ex);
        } finally {
        	super.close(result);
        }
    }
    
    @Override
    public Questao findByPk(Object id) throws DataException {
    	
    	ResultSet result = null;
        PreparedStatement stmt = null;
    	
    	try {
        	
        	StringBuilder select = new StringBuilder(SELECT)
        	.append(Questao.getSqlCamposQuestao())
        	.append(",").append(Questionario.getSqlCamposQuestionario())
        	.append(FROM).append(Questao.getSqlFromQuestao())
        	.append(INNER_JOIN).append(Questionario.getSqlFromQuestionario())
        	.append(" ON (Questao.id_questionario = Questionario.id_questionario) ")
        	.append(WHERE).append(" Questao.id_questao = ? ");
        	
        	Questao questao = (Questao) id;
        	
        	stmt = getPreparedStatement(select.toString());
        	stmt.setInt(1, questao.getIdQuestao());
        	stmt.execute();
            result = stmt.getResultSet();
            
            if(result!= null){		
				while (result.next()) {
					questao = Questao.getQuestaoByResultSet(result);
					questao.setQuestionario(Questionario.getQuestionarioByResultSet(result));
				}
			}
            
        	return questao;
    	} catch (Exception ex) {
            throw new DataException(ex);
        } finally {
        	super.close(result);
        }
    }

	@Override
	public List<Questao> findAtivos(String order) throws DataException {
		
		ResultSet result = null;
        PreparedStatement stmt = null;
    	List<Questao> list = new ArrayList<Questao>();
    	
    	try {
        	
        	StringBuilder select = new StringBuilder(SELECT)
        	.append(Questao.getSqlCamposQuestao())
        	.append(FROM).append(Questao.getSqlFromQuestao())
        	.append(WHERE).append("Questao.flag_ativo = 1 ");
        	
        	if(StringUtils.isNotBlank(order)){
        		select.append(String.format(" ORDER BY %s ", order));
        	}
        	
        	stmt = getPreparedStatement(select.toString());
        	stmt.execute();
            result = stmt.getResultSet();
            
            if(result!= null){		
				while (result.next()) {
					Questao questao = Questao.getQuestaoByResultSet(result);
					list.add(questao);
				}
			}
            
        	return list;
    	} catch (Exception ex) {
            throw new DataException(ex);
        } finally {
        	super.close(result);
        }
	}

	@Override
	public List<Questao> findAtivos() throws DataException {
		return this.findAtivos(null);
	}
    
}
