package br.com.callink.cad.sau.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.sau.dao.IQuestionarioDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.Questao;
import br.com.callink.cad.sau.pojo.Questionario;

public class QuestionarioDAO extends GenericCadSauDAO<Questionario> implements IQuestionarioDAO {

	private static final long serialVersionUID = 1167376052893990985L;

	public QuestionarioDAO() {
		super(Questionario.class);
	}

	@Override
    public Questionario findByPk(Object id) throws DataException {
       
		ResultSet result = null;
        PreparedStatement stmt = null;
		
		try {
        	
        	StringBuilder select = new StringBuilder(SELECT)
        	.append(Questionario.getSqlCamposQuestionario())
        	.append(FROM).append(Questionario.getSqlFromQuestionario())
        	.append(WHERE).append(" Questionario.id_questionario = ? ");
        	
        	Questionario questionario = (Questionario) id;
        	
        	stmt = getPreparedStatement(select.toString());
            stmt.setInt(1,questionario.getIdQuestionario());
        	stmt.execute();
            result = stmt.getResultSet();
        	
            if(result!= null){		
				while (result.next()) {
					questionario = Questionario.getQuestionarioByResultSet(result);
					//TODO preencher a lista no service.
					questionario.setQuestaoList(new ArrayList<Questao>());
				}
			}
            return questionario;
		} catch (Exception ex) {
            throw new DataException(ex);
        } finally {
        	super.close(result);
        }
    }
	
	@Override
    public List<Questionario> findAll() throws DataException {
		return this.findAll(null);
	}
	
	@Override
    public List<Questionario> findAll(String order) throws DataException {
       
		ResultSet result = null;
        PreparedStatement stmt = null;
        List<Questionario> list = new ArrayList<Questionario>();
		
		try {
        	
        	StringBuilder select = new StringBuilder(SELECT)
        	.append(Questionario.getSqlCamposQuestionario())
        	.append(FROM).append(Questionario.getSqlFromQuestionario());
        	
        	if(StringUtils.isNotBlank(order)){
        		select.append(String.format(" ORDER BY %s ", order));
        	}
        	
        	stmt = getPreparedStatement(select.toString());
        	stmt.execute();
            result = stmt.getResultSet();
        	
            if(result!= null){		
				while (result.next()) {
					Questionario questionario = Questionario.getQuestionarioByResultSet(result);
					list.add(questionario);
				}
			}
            return list;
		} catch (Exception ex) {
            throw new DataException(ex);
        } finally {
        	super.close(result);
        }
    }
	
	public List<Questionario> findByExample(Questionario example) throws DataException {
		return this.findByExample(example, null);
	}
	
	@Override
    public List<Questionario> findByExample(Questionario example, String order) throws DataException {
       
		ResultSet result = null;
        PreparedStatement stmt = null;
        List<Questionario> list = new ArrayList<Questionario>();
        int index=0;
		
		try {
        	
        	StringBuilder select = new StringBuilder(SELECT)
        	.append(Questionario.getSqlCamposQuestionario())
        	.append(FROM).append(Questionario.getSqlFromQuestionario())
        	.append(WHERE_1_1);
        	
        	if(example!= null){
        		
        		if(example.getIdQuestionario()!= null){
        			select.append(" AND Questionario.id_questionario = ? ");
        		}
        		if(StringUtils.isNotBlank(example.getDescricao())){
        			select.append(" AND Questionario.descricao like ? ");
        		}
        		if(example.getFlagAtivo() != null){
        			select.append(" AND Questionario.flag_ativo = ? ");
        		}
        	}
        	
        	if(StringUtils.isNotBlank(order)){
        		select.append(String.format(" ORDER BY %s ", order));
        	}
        	
        	stmt = getPreparedStatement(select.toString());
        	
        	if(example!= null){
        		
        		if(example.getIdQuestionario()!= null){
        			stmt.setInt(++index, example.getIdQuestionario());
        		}
        		if(StringUtils.isNotBlank(example.getDescricao())){
        			stmt.setString(++index, new StringBuilder(example.getDescricao()).append("%").toString());
        		}
        		if(example.getFlagAtivo() != null){
        			stmt.setBoolean(++index, example.getFlagAtivo());
        		}
        	}
        	
        	stmt.execute();
            result = stmt.getResultSet();
        	
            if(result!= null){		
				while (result.next()) {
					Questionario questionario = Questionario.getQuestionarioByResultSet(result);
					list.add(questionario);
				}
			}
            return list;
		} catch (Exception ex) {
            throw new DataException(ex);
        } finally {
        	super.close(result);
        }
    }

	@Override
	public List<Questionario> findAtivos(String order) throws DataException {
		
		ResultSet result = null;
        PreparedStatement stmt = null;
        List<Questionario> list = new ArrayList<Questionario>();
		
		try {
        	
        	StringBuilder select = new StringBuilder(SELECT)
        	.append(Questionario.getSqlCamposQuestionario())
        	.append(FROM).append(Questionario.getSqlFromQuestionario())
        	.append(WHERE).append(" Questionario.flag_ativo = 1 ");
        	
        	if(StringUtils.isNotBlank(order)){
        		select.append(String.format(" ORDER BY %s ", order));
        	}
        	
        	stmt = getPreparedStatement(select.toString());
        	stmt.execute();
            result = stmt.getResultSet();
        	
            if(result!= null){		
				while (result.next()) {
					Questionario questionario = Questionario.getQuestionarioByResultSet(result);
					list.add(questionario);
				}
			}
            return list;
		} catch (Exception ex) {
            throw new DataException(ex);
        } finally {
        	super.close(result);
        }
	}

	@Override
	public List<Questionario> findAtivos() throws DataException {
		return this.findAtivos(null);
	}
	
	
}
