package br.com.callink.cad.sau.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.sau.dao.IRespostaChecklistDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.Check;
import br.com.callink.cad.sau.pojo.RespostaChecklist;
import br.com.callink.cad.sau.pojo.ResultadoChecklist;

public class RespostaChecklistDAO extends GenericCadSauDAO<RespostaChecklist> implements IRespostaChecklistDAO {

	private static final long serialVersionUID = -1340788001107881164L;

	public RespostaChecklistDAO() {
		super(RespostaChecklist.class);
	}

	@Override
    public List<RespostaChecklist> respostasByResultadoChecklist(ResultadoChecklist resultadoChecklist) throws DataException {
        
		ResultSet result = null;
        PreparedStatement stmt = null;
        List<RespostaChecklist> list = new ArrayList<RespostaChecklist>();
		
		try {
        	
        	StringBuilder select = new StringBuilder(SELECT)
        		.append(RespostaChecklist.getSqlCamposRespostaChecklist())
        		.append(",").append(Check.getSqlCamposCheck())
        		.append(",").append(ResultadoChecklist.getSqlCamposResultadoChecklist())
        		.append(FROM).append(RespostaChecklist.getSqlFromRespostaChecklist())
        		.append(INNER_JOIN).append(Check.getSqlFromCheck())
        		.append(" ON (RespostaChecklist.id_check = Check.ID_CHECK)  ")
        		.append(INNER_JOIN).append(ResultadoChecklist.getSqlFromResultadoChecklist())
        		.append(" ON (RespostaChecklist.id_resultado_checklist = ResultadoChecklist.id_resultado_checklist) ")
        		.append(WHERE).append(" ResultadoChecklist.id_resultado_checklist = ? ");
        	
        	stmt = getPreparedStatement(select.toString());
            stmt.setInt(1,resultadoChecklist.getIdResultadoChecklist());
        	stmt.execute();
            result = stmt.getResultSet();
            
            if(result!= null){		
				while (result.next()) {
					RespostaChecklist resposta = RespostaChecklist.getRespostaChecklistByResultSet(result);
					resposta.setCheck(Check.getCheckByResultSet(result));
					resposta.setResultadoChecklist(ResultadoChecklist.getResultadoChecklistByResultSet(result));
					list.add(resposta);
				}
			}
            
		} catch (Exception ex) {
            throw new DataException(ex);
        } finally {
        	super.close(result);
        }
         return list;
    }
	
	@Override
	public List<RespostaChecklist> findAll() throws DataException {
		return this.findAll(null);
	}
	
	@Override
    public RespostaChecklist findByPk(Object id) throws DataException {
        
		ResultSet result = null;
        PreparedStatement stmt = null;
		
		try {
        	
			StringBuilder select = new StringBuilder(SELECT)
    		.append(RespostaChecklist.getSqlCamposRespostaChecklist())
    		.append(",").append(Check.getSqlCamposCheck())
    		.append(",").append(ResultadoChecklist.getSqlCamposResultadoChecklist())
    		.append(FROM).append(RespostaChecklist.getSqlFromRespostaChecklist())
    		.append(INNER_JOIN).append(Check.getSqlFromCheck())
    		.append(" ON (RespostaChecklist.id_check = Check.ID_CHECK)  ")
    		.append(INNER_JOIN).append(ResultadoChecklist.getSqlFromResultadoChecklist())
    		.append(" ON (RespostaChecklist.id_resultado_checklist = ResultadoChecklist.id_resultado_checklist) ")
    		.append(WHERE).append(" RespostaChecklist.id_resposta_checklist = ? ");
        	
			RespostaChecklist resposta = (RespostaChecklist) id;
			
        	stmt = getPreparedStatement(select.toString());
        	stmt.setInt(1, resposta.getIdRespostaChecklist());
        	stmt.execute();
            result = stmt.getResultSet();
            
            if(result!= null){		
				while (result.next()) {
					resposta = RespostaChecklist.getRespostaChecklistByResultSet(result);
					resposta.setCheck(Check.getCheckByResultSet(result));
					resposta.setResultadoChecklist(ResultadoChecklist.getResultadoChecklistByResultSet(result));
				}
			}
            return resposta;
		} catch (Exception ex) {
            throw new DataException(ex);
        } finally {
        	super.close(result);
        }
    }
	
	
	@Override
    public List<RespostaChecklist> findAll(String order) throws DataException {
        
		ResultSet result = null;
        PreparedStatement stmt = null;
        List<RespostaChecklist> list = new ArrayList<RespostaChecklist>();
		
		try {
        	
        	StringBuilder select = new StringBuilder(SELECT)
        		.append(RespostaChecklist.getSqlCamposRespostaChecklist())
        		.append(FROM).append(RespostaChecklist.getSqlFromRespostaChecklist());
        	
        	if(StringUtils.isNotBlank(order)){
        		select.append(String.format(" ORDER BY %s ", order));
        	}
        	
        	stmt = getPreparedStatement(select.toString());
        	stmt.execute();
            result = stmt.getResultSet();
            
            if(result!= null){		
				while (result.next()) {
					RespostaChecklist resposta = RespostaChecklist.getRespostaChecklistByResultSet(result);
					list.add(resposta);
				}
			}
            
		} catch (Exception ex) {
            throw new DataException(ex);
        } finally {
        	super.close(result);
        }
         return list;
    }
	
	
	
	@Override
    public List<RespostaChecklist> findByExample(RespostaChecklist example) throws DataException {
    	return this.findByExample(example, null);
    }
	
	@Override
    public List<RespostaChecklist> findByExample(RespostaChecklist example, String order) throws DataException {
        
		ResultSet result = null;
        PreparedStatement stmt = null;
        List<RespostaChecklist> list = new ArrayList<RespostaChecklist>();
        int index =0;
		
		try {
        	
        	StringBuilder select = new StringBuilder(SELECT)
        		.append(RespostaChecklist.getSqlCamposRespostaChecklist())
        		.append(FROM).append(RespostaChecklist.getSqlFromRespostaChecklist());
        	
        	if(example!= null){
        		
        		if(example.getIdRespostaChecklist()!= null){
        			select.append(" AND RespostaChecklist.id_resposta_checklist = ? ");
        		}
        		if(example.getCheck()!= null && example.getCheck().getIdCheck()!= null){
        			select.append(" AND RespostaChecklist.id_check = ? ");
        		}
        		if(example.getResultadoChecklist() != null && example.getResultadoChecklist().getIdResultadoChecklist()!= null){
        			select.append(" AND RespostaChecklist.id_resultado_checklist = ? ");
        		}
        		if(StringUtils.isNotBlank(example.getResposta())){
        			select.append(" AND RespostaChecklist.resposta like ? ");
        		}
        	}
        	
        	if(StringUtils.isNotBlank(order)){
        		select.append(String.format(" ORDER BY %s ", order));
        	}
        	
        	stmt = getPreparedStatement(select.toString());
        	
        	if(example!= null){
        		
        		if(example.getIdRespostaChecklist()!= null){
        			stmt.setInt(++index, example.getIdRespostaChecklist());
        		}
        		if(example.getCheck()!= null && example.getCheck().getIdCheck()!= null){
        			stmt.setInt(++index, example.getCheck().getIdCheck());
        		}
        		if(example.getResultadoChecklist() != null && example.getResultadoChecklist().getIdResultadoChecklist()!= null){
        			stmt.setInt(++index, example.getResultadoChecklist().getIdResultadoChecklist());
        		}
        		if(StringUtils.isNotBlank(example.getResposta())){
        			stmt.setString(++index, new StringBuilder(example.getResposta()).append("%").toString());
        		}
        	}
        	
        	stmt.execute();
            result = stmt.getResultSet();
            
            if(result!= null){		
				while (result.next()) {
					RespostaChecklist resposta = RespostaChecklist.getRespostaChecklistByResultSet(result);
					list.add(resposta);
				}
			}
            
		} catch (Exception ex) {
            throw new DataException(ex);
        } finally {
        	super.close(result);
        }
         return list;
    }
	
	
	@Override
	public List<RespostaChecklist> findAtivos(String order)
			throws DataException {
		throw new DataException("Essa entidade nao possui flag_ativo!");
	}

	@Override
	public List<RespostaChecklist> findAtivos() throws DataException {
		return this.findAtivos(null);
	}
    
}
