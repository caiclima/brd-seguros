package br.com.callink.cad.sau.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.sau.dao.IRespostaDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.Questao;
import br.com.callink.cad.sau.pojo.Resposta;
import br.com.callink.cad.sau.pojo.ResultadoQuestionario;

public class RespostaDAO extends GenericCadSauDAO<Resposta> implements IRespostaDAO {

	private static final long serialVersionUID = -3040787865263266499L;

	public RespostaDAO() {
		super(Resposta.class);
	}

	@Override
    public boolean questaoEditavel(Questao questao) throws DataException {
        ResultSet result = null;
        PreparedStatement stmt = null;
       
        try {
            
        	StringBuilder query = new StringBuilder("select count(tr.id_resposta) as QTDE from tb_resposta tr with(nolock) where tr.id_questao = ");
            query.append(questao.getIdQuestao());

            stmt = getPreparedStatement(query.toString());
            stmt.execute();
            result = stmt.getResultSet();

            if (result.next()) {
                return result.getInt("QTDE") == 0;
            } else {
                return false;
            }
        } catch (Exception ex) {
            throw new DataException("Erro ao buscar se a questão é editavel.",ex);
        } finally {
        	super.close(result);
        }
    }

    @Override
    public List<Resposta> respostasByResultadoQuestionario(ResultadoQuestionario resultadoQuestionario) throws DataException {
       
    	 ResultSet result = null;
         PreparedStatement stmt = null;
         List<Resposta> list = new ArrayList<Resposta>();
    	
         try {
            
        	StringBuilder select = new StringBuilder(SELECT)
        		.append(Resposta.getSqlCamposResposta())
        		.append(",").append(Questao.getSqlCamposQuestao())
        		.append(",").append(ResultadoQuestionario.getSqlCamposResultadoQuestionario())
        	    .append(FROM).append(Resposta.getSqlFromResposta())
        	    .append(INNER_JOIN).append(Questao.getSqlFromQuestao())
        	    .append(" ON ( Resposta.id_questao = Questao.id_questao ) ")
        	    .append(INNER_JOIN).append(ResultadoQuestionario.getSqlFromResultadoQuestionario())
        	    .append(" ON ( ResultadoQuestionario.id_resultado_questionario = Resposta.id_resultado_questionario ) ")
        		.append(WHERE).append(" ResultadoQuestionario.id_resultado_questionario = ? ");        	
        	
        	stmt = getPreparedStatement(select.toString());
        	stmt.setInt(1, resultadoQuestionario.getIdResultadoQuestionario());
            stmt.execute();
            result = stmt.getResultSet();
            
            if(result!= null){		
				while (result.next()) {
					Resposta resposta = Resposta.getRespostaByResultSet(result);
					resposta.setQuestao(Questao.getQuestaoByResultSet(result));
					resposta.setResultadoQuestionario(ResultadoQuestionario.getResultadoQuestionarioByResultSet(result));
					list.add(resposta);
				}
			}
            
         } catch (Exception ex) {
            throw new DataException("Erro ao buscar se a questão é editavel.",ex);
        } finally {
        	super.close(result);
        }
         return list;
    }
    
    @Override
    public List<Resposta> findAll() throws DataException {
    	return this.findAll(null);
    }
    
    @Override
    public List<Resposta> findAll(String order) throws DataException {
       
    	 ResultSet result = null;
         PreparedStatement stmt = null;
         List<Resposta> list = new ArrayList<Resposta>();
    	
         try {
            
        	StringBuilder select = new StringBuilder(SELECT)
        		.append(Resposta.getSqlCamposResposta())
        	    .append(FROM).append(Resposta.getSqlFromResposta());
        	
        	if(StringUtils.isNotBlank(order)){
        		select.append(String.format(" ORDER BY %s ", order));
        	}
        	
        	stmt = getPreparedStatement(select.toString());
            stmt.execute();
            result = stmt.getResultSet();
            
            if(result!= null){		
				while (result.next()) {
					Resposta resposta = Resposta.getRespostaByResultSet(result);
					list.add(resposta);
				}
			}
            
         } catch (Exception ex) {
            throw new DataException("Erro ao buscar se a questão é editavel.",ex);
        } finally {
        	super.close(result);
        }
         return list;
    }
    
    @Override
    public Resposta findByPk(Object id) throws DataException {
       
    	 ResultSet result = null;
         PreparedStatement stmt = null;
    	
         try {
            
        	StringBuilder select = new StringBuilder(SELECT)
        		.append(Resposta.getSqlCamposResposta())
        		.append(",").append(Questao.getSqlCamposQuestao())
        		.append(",").append(ResultadoQuestionario.getSqlCamposResultadoQuestionario())
        	    .append(FROM).append(Resposta.getSqlFromResposta())
        	    .append(INNER_JOIN).append(Questao.getSqlFromQuestao())
        	    .append(" ON ( Resposta.id_questao = Questao.id_questao ) ")
        	    .append(INNER_JOIN).append(ResultadoQuestionario.getSqlFromResultadoQuestionario())
        	    .append(" ON ( ResultadoQuestionario.id_resultado_questionario = Resposta.id_resultado_questionario ) ")
        		.append(WHERE).append(" Resposta.id_resposta = ? ");        	
        	
        	Resposta resposta = (Resposta) id;
        	
        	stmt = getPreparedStatement(select.toString());
        	stmt.setInt(1, resposta.getIdResposta());
            stmt.execute();
            result = stmt.getResultSet();
            
            if(result!= null){		
				while (result.next()) {
					resposta = Resposta.getRespostaByResultSet(result);
				}
			}
            return resposta;
         } catch (Exception ex) {
            throw new DataException("Erro ao buscar resposta por id",ex);
        } finally {
        	super.close(result);
        }
    }
    
    @Override
    public List<Resposta> findByExample(Resposta example) throws DataException {
    	return this.findByExample(example, null);
    }
    
    @Override
    public List<Resposta> findByExample(Resposta example, String order) throws DataException {
       
    	 ResultSet result = null;
         PreparedStatement stmt = null;
         List<Resposta> list = new ArrayList<Resposta>();
         int index = 0;
    	
         try {
            
        	StringBuilder select = new StringBuilder(SELECT)
        		.append(Resposta.getSqlCamposResposta())
        	    .append(FROM).append(Resposta.getSqlFromResposta())
        		.append(WHERE_1_1);  
        	
        	if(example!= null){
        		
        		if(example.getIdResposta()!= null){
        			select.append(" AND Resposta.id_resposta = ? ");
        		}
        		if(example.getQuestao() != null && example.getQuestao().getIdQuestao()!= null){
        			select.append(" AND Resposta.id_questao = ? ");
        		}
        		if(example.getResultadoQuestionario()!= null && example.getResultadoQuestionario().getIdResultadoQuestionario()!= null){
        			select.append(" AND Resposta.id_resultado_questionario = ? ");
        		}
        		if(StringUtils.isNotBlank(example.getResposta())){
        			select.append(" AND Resposta.resposta like ? ");
        		}
        	}
        	
        	if(StringUtils.isNotBlank(order)){
        		select.append(String.format(" ORDER BY  %s ", order));
        	}
        	
        	stmt = getPreparedStatement(select.toString());
        	
        	if(example!= null){
        		
        		if(example.getIdResposta()!= null){
        			stmt.setInt(++index, example.getIdResposta());
        		}
        		if(example.getQuestao() != null && example.getQuestao().getIdQuestao()!= null){
        			stmt.setInt(++index, example.getQuestao().getIdQuestao());
        		}
        		if(example.getResultadoQuestionario()!= null && example.getResultadoQuestionario().getIdResultadoQuestionario()!= null){
        			stmt.setInt(++index, example.getResultadoQuestionario().getIdResultadoQuestionario());
        		}
        		if(StringUtils.isNotBlank(example.getResposta())){
        			stmt.setString(++index, new StringBuffer(example.getResposta()).append("%").toString());
        		}
        	}
        	
            stmt.execute();
            result = stmt.getResultSet();
            
            if(result!= null){		
				while (result.next()) {
					Resposta resposta = Resposta.getRespostaByResultSet(result);
					list.add(resposta);
				}
			}
            
         } catch (Exception ex) {
            throw new DataException("Erro ao buscar se a questão é editavel.",ex);
        } finally {
        	super.close(result);
        }
         return list;
    }
    
    @Override
	public List<Resposta> findAtivos(String order)
			throws DataException {
		throw new DataException("Essa entidade nao possui flag_ativo!");
	}

	@Override
	public List<Resposta> findAtivos() throws DataException {
		return this.findAtivos(null);
	}
    
    
}
