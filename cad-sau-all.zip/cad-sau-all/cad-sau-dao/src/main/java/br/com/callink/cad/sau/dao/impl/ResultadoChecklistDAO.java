package br.com.callink.cad.sau.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.pojo.Util.DateUtil;
import br.com.callink.cad.sau.dao.IResultadoChecklistDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.pojo.Evento;
import br.com.callink.cad.sau.pojo.ResultadoChecklist;

public class ResultadoChecklistDAO extends GenericCadSauDAO<ResultadoChecklist> implements IResultadoChecklistDAO {

	private static final long serialVersionUID = 23037287326265635L;

	public ResultadoChecklistDAO() {
		super(ResultadoChecklist.class);
	}

	@Override
	public List<ResultadoChecklist> buscaResultadoPorAgenteCasoSau(
			CasoSau casoSau, Evento evento, Acao acao) throws DataException {

		PreparedStatement stmt = null;
		ResultSet result = null;
		
		try {

			StringBuilder sql = new StringBuilder("SELECT id_resultado_checklist, login, tipo_atendimento, ")
					.append("id_externo, data_resposta, id_caso_sau ")
					.append("from tb_resultado_checklist with (nolock) ")
					.append("where id_caso_sau = ? and id_acao = ? ");
			
			if(evento!= null && (evento.getIdEvento()!= null || evento.getIdEvento()!=0)){
				sql.append(String.format(" and id_evento = %d ",evento.getIdEvento()));
			}else{
				sql.append(" and id_evento is null ");
			}

			stmt = getPreparedStatement(sql.toString());
			stmt.setInt(1, casoSau.getIdCasoSau());
			stmt.setInt(2, acao.getIdAcao());
			
			stmt.execute();
			List<ResultadoChecklist> resultados = new ArrayList<ResultadoChecklist>();
			result = stmt.getResultSet();
			
			if(result!= null){		
				while (result.next()) {
	
					ResultadoChecklist resultado = new ResultadoChecklist();
					resultado.setIdResultadoChecklist(result.getInt("id_resultado_checklist"));
					resultado.setLogin(result.getString("login"));
					resultado.setTipoAtendimento(result.getString("tipo_atendimento"));
					resultado.setIdExterno(result.getInt("id_externo"));
					resultado.setDataResposta(result.getDate("data_resposta"));
					resultado.setCasoSau(casoSau);
					resultado.setEvento(evento);
					resultado.setAcao(acao);
					resultados.add(resultado);
				}
			}
			return resultados;

		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(result);
		}
	}
	
	 @Override
	 public ResultadoChecklist findByPk(Object id) throws DataException {
	    	
			PreparedStatement stmt = null;
			ResultSet resultSet = null;
			
			try {
				
				StringBuilder select = new StringBuilder()
					.append(SELECT)
					.append(ResultadoChecklist.getSqlCamposResultadoChecklist())
					.append(",").append(CasoSau.getSqlCamposCasoSau())
					.append(",").append(Evento.getSqlEvento())
					.append(",").append(Acao.getSqlCamposAcao())
					.append(FROM)
					.append(ResultadoChecklist.getSqlFromResultadoChecklist())
					.append(INNER_JOIN).append(CasoSau.getSqlFromCasoSau())
					.append(" ON (ResultadoChecklist.id_caso_sau = CasoSau.ID_CASO_SAU) ")
					.append(INNER_JOIN).append(Evento.getSqlFromEvento())
					.append(" ON (ResultadoChecklist.id_evento = Evento.ID_EVENTO) ")
					.append(INNER_JOIN).append(Acao.getSqlFromAcao())
					.append(" ON (ResultadoChecklist.id_acao = Acao.ID_ACAO) ")
					.append(WHERE).append(" TipoManifestacao.ID_TIPO_CASO = ? ");
				
				ResultadoChecklist resultado = (ResultadoChecklist) id;
				stmt = getPreparedStatement(select.toString());
				stmt.setInt(1, resultado.getIdResultadoChecklist());
				stmt.execute();
				resultSet = stmt.getResultSet();
				
				if (resultSet != null) {
					while (resultSet.next()) {
						resultado = ResultadoChecklist.getResultadoChecklistByResultSet(resultSet);
						resultado.setCasoSau(CasoSau.getCasoSauByResultSet(resultSet));
						resultado.setEvento(Evento.getEventoByResultSet(resultSet));
						resultado.setAcao(Acao.getAcaoByResultSet(resultSet));
					}
				}
				return resultado;
			} catch (Exception ex) {
				throw new DataException(ex);
			} finally {
				super.close(resultSet);
			}
		}

	 @Override
	 public List<ResultadoChecklist> findAll() throws DataException{
		 return this.findAll(null);
	 } 
	 
	 @Override
	 public List<ResultadoChecklist> findAll(String order) throws DataException {
	    	
			PreparedStatement stmt = null;
			ResultSet resultSet = null;
			List<ResultadoChecklist> list = new ArrayList<ResultadoChecklist>();
			
			try {
				
				StringBuilder select = new StringBuilder()
					.append(SELECT)
					.append(ResultadoChecklist.getSqlCamposResultadoChecklist())
					.append(FROM)
					.append(ResultadoChecklist.getSqlFromResultadoChecklist());
				
				if(StringUtils.isNotBlank(order)){
					select.append(String.format(" ORDER BY  %s ", order));
				}
				
				stmt = getPreparedStatement(select.toString());
				stmt.execute();
				resultSet = stmt.getResultSet();
				
				if (resultSet != null) {
					while (resultSet.next()) {
						list.add(ResultadoChecklist.getResultadoChecklistByResultSet(resultSet));
					}
				}
				return list;
			} catch (Exception ex) {
				throw new DataException(ex);
			} finally {
				super.close(resultSet);
			}
	}
	 @Override
	 public List<ResultadoChecklist> findByExample(ResultadoChecklist example) throws DataException {
		 return this.findByExample(example, null);
	 }
	 
	 @Override
	 public List<ResultadoChecklist> findByExample(ResultadoChecklist example, String order) throws DataException {
	    	
			PreparedStatement stmt = null;
			ResultSet resultSet = null;
			List<ResultadoChecklist> list = new ArrayList<ResultadoChecklist>();
			int index =0;
			
			try {
				
				StringBuilder select = new StringBuilder()
					.append(SELECT)
					.append(ResultadoChecklist.getSqlCamposResultadoChecklist())
					.append(FROM)
					.append(ResultadoChecklist.getSqlFromResultadoChecklist())
					.append(WHERE_1_1);
				
				if(example != null){
					
					if(example.getIdResultadoChecklist()!= null){
						select.append(" AND ResultadoChecklist.id_resultado_checklist = ? ");
					}
					if(StringUtils.isNotBlank(example.getLogin())){
						select.append(" AND ResultadoChecklist.login = ? ");
					}
					if(StringUtils.isNotBlank(example.getTipoAtendimento())){
						select.append(" AND ResultadoChecklist.tipo_atendimento = ? ");
					}
					if(example.getIdExterno()!= null){
						select.append(" AND ResultadoChecklist.id_externo = ? ");
					}
					if(example.getDataResposta()!= null){
						select.append(" AND ResultadoChecklist.data_resposta BETWEEN ? AND ? ");
					}
					if(example.getCasoSau()!= null && example.getCasoSau().getIdCasoSau()!= null){
						select.append(" AND ResultadoChecklist.id_caso_sau = ? ");
					}
					if(example.getEvento() != null && example.getEvento().getIdEvento()!= null){
						select.append(" AND ResultadoChecklist.id_evento = ? ");
					}
					if(example.getAcao() != null && example.getAcao().getIdAcao()!= null){
						select.append(" AND ResultadoChecklist.id_acao = ? ");
					}
				}
				
				if(StringUtils.isNotBlank(order)){
					select.append(String.format(" ORDER BY  %s ", order));
				}
				
				stmt = getPreparedStatement(select.toString());
				
				if(example != null){
					
					if(example.getIdResultadoChecklist()!= null){
						stmt.setInt(++index, example.getIdResultadoChecklist());
					}
					if(StringUtils.isNotBlank(example.getLogin())){
						stmt.setString(++index, example.getLogin());
					}
					if(StringUtils.isNotBlank(example.getTipoAtendimento())){
						stmt.setString(++index, example.getTipoAtendimento());
					}
					if(example.getIdExterno()!= null){
						stmt.setInt(++index, example.getIdExterno());
					}
					if(example.getDataResposta()!= null){
						Date dataInicio = DateUtil.dataInicioDia(example.getDataResposta());
						Date dataFim = DateUtil.dataFimDia(example.getDataResposta());
						stmt.setDate(++index, new java.sql.Date(dataInicio.getTime()));
						stmt.setDate(++index, new java.sql.Date(dataFim.getTime()));
					}
					if(example.getCasoSau()!= null && example.getCasoSau().getIdCasoSau()!= null){
						stmt.setInt(++index, example.getCasoSau().getIdCasoSau());
					}
					if(example.getEvento() != null && example.getEvento().getIdEvento()!= null){
						stmt.setInt(++index, example.getEvento().getIdEvento());
					}
					if(example.getAcao() != null && example.getAcao().getIdAcao()!= null){
						stmt.setInt(++index, example.getAcao().getIdAcao());
					}
				}
				
				stmt.execute();
				resultSet = stmt.getResultSet();
				
				if (resultSet != null) {
					while (resultSet.next()) {
						list.add(ResultadoChecklist.getResultadoChecklistByResultSet(resultSet));
					}
				}
				return list;
			} catch (SQLException ex) {
				throw new DataException(ex);
			} finally {
				super.close(resultSet);
			}
	} 
	 
	@Override
	public List<ResultadoChecklist> findAtivos(String order)
			throws DataException {
		throw new DataException("Essa entidade nao possui flag_ativo!");
	}

	@Override
	public List<ResultadoChecklist> findAtivos() throws DataException {
		return this.findAtivos(null);
	}

}
