package br.com.callink.cad.sau.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.pojo.Util.DateUtil;
import br.com.callink.cad.sau.dao.IResultadoQuestionarioDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.ResultadoQuestionario;

public class ResultadoQuestionarioDAO extends GenericCadSauDAO<ResultadoQuestionario> implements IResultadoQuestionarioDAO {

	private static final long serialVersionUID = 2769463496708669567L;

	public ResultadoQuestionarioDAO() {
		super(ResultadoQuestionario.class);
	}

	@Override
    public List<Object[]> questionariosRespondidos(Integer idExterno) throws DataException {
       
    	List<Object[]> retorno = new ArrayList<Object[]>();

        if (idExterno == null) {
            return retorno;
        }
    	
    	ResultSet result = null;
        PreparedStatement stmt = null;
        try {
            StringBuilder select = new StringBuilder();
            select.append("select trq.id_resultado_questionario as ID_RESULTADO_QUESTIONARIO, tqs.descricao AS DESCRICAO_QUESTIONARIO, trq.data_resposta AS DATA_RESPOSTA, trq.login AS LOGIN_USUARIO");
            select.append(" from tb_resultado_questionario trq with(nolock) ,");
            select.append("	 tb_resposta trs with(nolock),");
            select.append("	 tb_questionario tqs with(nolock),");
            select.append("	 tb_questao tq with(nolock) ");
            select.append("where trq.id_resultado_questionario = trs.id_resultado_questionario and ");
            select.append("      trs.id_questao = tq.id_questao and ");
            select.append("      tq.id_questionario = tqs.id_questionario and ");
            select.append("      trq.id_externo = ").append(idExterno).append(" ");
            select.append("group by trq.id_resultado_questionario, tqs.descricao, trq.data_resposta, trq.login");
            
            stmt = getPreparedStatement(select.toString());
			stmt.execute();
            result = stmt.getResultSet();

            if(result!= null){
	            while (result.next()) {
	                Object[] obj = new Object[4];
	                obj[0] = result.getInt("ID_RESULTADO_QUESTIONARIO");
	                obj[1] = result.getString("DESCRICAO_QUESTIONARIO");
	                obj[2] = result.getTimestamp("DATA_RESPOSTA");
	                obj[3] = result.getString("LOGIN_USUARIO");
	                retorno.add(obj);
	            }
            }
            return retorno;
        } catch (SQLException ex) {
            throw new DataException(ex);
        } finally {
        	super.close(result);
        }
    }
    
    public List<ResultadoQuestionario> findAll() throws DataException{
    	return this.findAll(null);
    }
    
    @Override
    public List<ResultadoQuestionario> findAll(String order) throws DataException {
    	
    	List<ResultadoQuestionario> resultado = new ArrayList<ResultadoQuestionario>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		
		try {
			
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(ResultadoQuestionario.getSqlCamposResultadoQuestionario())
				.append(FROM)
				.append(ResultadoQuestionario.getSqlFromResultadoQuestionario());
			
			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					ResultadoQuestionario quest = ResultadoQuestionario.getResultadoQuestionarioByResultSet(resultSet);
					resultado.add(quest);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return resultado;
	}
    
    public List<ResultadoQuestionario> findByExample(ResultadoQuestionario example) throws DataException {
    	return this.findByExample(example, null);
    }
    
    @Override
    public List<ResultadoQuestionario> findByExample(ResultadoQuestionario example,  String order) throws DataException {
    	
    	List<ResultadoQuestionario> resultado = new ArrayList<ResultadoQuestionario>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		int index =0;
		
		try {
			
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(ResultadoQuestionario.getSqlCamposResultadoQuestionario())
				.append(FROM)
				.append(ResultadoQuestionario.getSqlFromResultadoQuestionario())
				.append(WHERE_1_1);
			
			if(example!= null){
				
				if(example.getIdResultadoQuestionario()!= null){
					select.append(" AND ResultadoQuestionario.id_resultado_questionario = ? ");
				}
				if(StringUtils.isNotBlank(example.getLogin())){
					select.append(" AND ResultadoQuestionario.login = ? ");
				}
				if(StringUtils.isNotBlank(example.getTipoAtendimento())){
					select.append(" AND ResultadoQuestionario.tipo_atendimento = ? ");
				}
				if(example.getIdExterno()!= null){
					select.append(" AND ResultadoQuestionario.id_externo = ? ");
				}
				if(example.getDataResposta()!= null){
					select.append(" AND ResultadoQuestionario.data_resposta BETWEEN ? AND ? ");
				}
				
			}
			
			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			if(example!= null){
				
				if(example.getIdResultadoQuestionario()!= null){
					stmt.setInt(++index, example.getIdResultadoQuestionario());
				}
				if(StringUtils.isNotBlank(example.getLogin())){
					stmt.setString(++index,example.getLogin());
				}
				if(StringUtils.isNotBlank(example.getTipoAtendimento())){
					stmt.setString(++index,example.getTipoAtendimento());
				}
				if(example.getIdExterno()!= null){
					stmt.setInt(++index, example.getIdExterno());
				}
				if(example.getDataResposta()!= null){
					Date dataInicio = DateUtil.dataInicioDia(example.getDataResposta());
					Date dataFim = DateUtil.dataFimDia(example.getDataResposta());
					stmt.setDate(++index, new java.sql.Date(dataInicio.getTime()));
					stmt.setDate(++index, new java.sql.Date(dataFim.getTime()));
				}
				
			}
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					ResultadoQuestionario quest = ResultadoQuestionario.getResultadoQuestionarioByResultSet(resultSet);
					resultado.add(quest);
				}
			}
		} catch (SQLException ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return resultado;
	}
    
    @Override
    public ResultadoQuestionario findByPk(Object id) throws DataException {
    	
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		
		try {
			
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(ResultadoQuestionario.getSqlCamposResultadoQuestionario())
				.append(FROM)
				.append(ResultadoQuestionario.getSqlFromResultadoQuestionario())
				.append(WHERE).append(" ResultadoQuestionario.id_resultado_questionario = ? ");
				
			ResultadoQuestionario resultadoQuestionario = (ResultadoQuestionario) id;
			stmt = getPreparedStatement(select.toString());
			stmt.setInt(1, resultadoQuestionario.getIdResultadoQuestionario());
			stmt.execute();
			resultSet = stmt.getResultSet();
			ResultadoQuestionario resultado = new ResultadoQuestionario();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					resultado = ResultadoQuestionario.getResultadoQuestionarioByResultSet(resultSet);
				}
			}
			return resultado;
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
	}

	@Override
	public List<ResultadoQuestionario> findAtivos(String order)
			throws DataException {
		throw new DataException("Essa entidade nao possui flag_ativo!");
	}

	@Override
	public List<ResultadoQuestionario> findAtivos() throws DataException {
		return this.findAtivos(null);
	}
    
    
}
