package br.com.callink.cad.sau.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import br.com.callink.cad.pojo.Util.DateUtil;
import br.com.callink.cad.sau.dao.ITipoManifestacaoDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.Evento;
import br.com.callink.cad.sau.pojo.TipoManifestacao;

public class TipoManifestacaoDAO extends GenericCadSauDAO<TipoManifestacao> implements ITipoManifestacaoDAO {

	private static final long serialVersionUID = -8975814037075106399L;

	public TipoManifestacaoDAO() {
		super(TipoManifestacao.class);
	}
	
	@Override
	public List<TipoManifestacao> findAll() throws DataException{
		return this.findAll(null);
	}
	
    @Override
    public List<TipoManifestacao> findAll(String order) throws DataException {
    	
    	List<TipoManifestacao> tipos = new ArrayList<TipoManifestacao>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(TipoManifestacao.getSqlCamposTipoManifestacao())
				.append(", ")
				.append(Evento.getSqlEvento())
				.append(FROM)
				.append(TipoManifestacao.getSqlFromTipoManifestacao())
				.append(LEFT_JOIN).append(Evento.getSqlFromEvento())
				.append(" ON TipoManifestacao.ID_EVENTO = Evento.ID_EVENTO ");
			
			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					TipoManifestacao tipo = TipoManifestacao.getTipoManifestacaoByResultSet(resultSet);
					tipo.setEvento(Evento.getEventoByResultSet(resultSet));
					tipos.add(tipo);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return tipos;
	}
    
    @Override
    public TipoManifestacao findByPk(Object id) throws DataException {
    	
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(TipoManifestacao.getSqlCamposTipoManifestacao())
				.append(",").append(Evento.getSqlEvento())
				.append(FROM)
				.append(TipoManifestacao.getSqlFromTipoManifestacao())
				.append(INNER_JOIN).append(Evento.getSqlFromEvento())
				.append(" ON (TipoManifestacao.ID_EVENTO = Evento.ID_EVENTO) ")
				.append(WHERE).append(" TipoManifestacao.ID_TIPO_CASO = ? ");
			
			TipoManifestacao tipo = (TipoManifestacao) id;
			stmt = getPreparedStatement(select.toString());
			stmt.setInt(1, tipo.getIdTipoCaso());
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					tipo = TipoManifestacao.getTipoManifestacaoByResultSet(resultSet);
					tipo.setEvento(Evento.getEventoByResultSet(resultSet));
				}
			}
			return tipo;
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
	}
    
    @Override
    public List<TipoManifestacao> findByExample(TipoManifestacao example) throws DataException {
    	return this.findByExample(example, null);
    }
    
    @Override
    public List<TipoManifestacao> findByExample(TipoManifestacao example, String order) throws DataException {
    	
    	List<TipoManifestacao> tipos = new ArrayList<TipoManifestacao>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		int index =0;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(TipoManifestacao.getSqlCamposTipoManifestacao())
				.append(FROM)
				.append(TipoManifestacao.getSqlFromTipoManifestacao())
				.append(WHERE_1_1);
			
			if(example != null){
				
				if (example.getIdTipoCaso() != null) {
					select.append(" AND TipoManifestacao.ID_TIPO_CASO = ? ");
				}
				if (example.getNome() != null && !example.getNome().isEmpty()) {
					select.append(" AND TipoManifestacao.NOME like ? ");
				}
				if (example.getDataCriacao() != null) {
					select.append(" AND TipoManifestacao.DATA_CRIACAO BETWEEN ? AND ? ");
				}
				if (example.getFlagAtivo() != null) {
					select.append(" AND TipoManifestacao.FLAG_ATIVO = ? ");
				}
				if(example.getFlagClassificaAutomatico()!= null){
					select.append(" AND TipoManifestacao.FLAG_CLASSIFICA_AUTOMATICO = ? ");
				}
				if(example.getFlagFinalizaAutomatico() != null){
					select.append(" AND TipoManifestacao.FLAG_FINALIZA_AUTOMATICO = ? ");
				}
				if(example.getEvento()!= null && example.getEvento().getIdEvento()!= null){
					select.append(" AND TipoManifestacao.ID_EVENTO = ? ");
				}
				if(example.getFlagNaoAtende() != null){
					select.append(" AND TipoManifestacao.FLAG_NAO_ATENDE = ? ");
				}
			}
			
			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			if(example != null){
				
				if (example.getIdTipoCaso() != null) {
					stmt.setInt(++index, example.getIdTipoCaso());
				}
				if (example.getNome() != null && !example.getNome().isEmpty()) {
					stmt.setString(++index,  new StringBuilder(example.getNome()).append("%").toString() );
				}
				if (example.getDataCriacao() != null) {
					Date dataInicio = DateUtil.dataInicioDia(example.getDataCriacao());
					Date dataFim = DateUtil.dataFimDia(example.getDataCriacao());
					stmt.setDate(++index, new java.sql.Date(dataInicio.getTime()));
					stmt.setDate(++index, new java.sql.Date(dataFim.getTime()));
				}
				if (example.getFlagAtivo() != null) {
					stmt.setBoolean(++index, example.getFlagAtivo());
				}
				if(example.getFlagClassificaAutomatico()!= null){
					stmt.setBoolean(++index, example.getFlagClassificaAutomatico());
				}
				if(example.getFlagFinalizaAutomatico() != null){
					stmt.setBoolean(++index, example.getFlagFinalizaAutomatico());
				}
				if(example.getEvento()!= null && example.getEvento().getIdEvento()!= null){
					stmt.setInt(++index, example.getEvento().getIdEvento());
				}
				if(example.getFlagNaoAtende() != null){
					stmt.setBoolean(++index, example.getFlagNaoAtende());
				}
			}
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					TipoManifestacao tipo = TipoManifestacao.getTipoManifestacaoByResultSet(resultSet);
					tipos.add(tipo);
				}
			}
		} catch (SQLException ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return tipos;
	}

	@Override
	public List<TipoManifestacao> findAtivos(String order) throws DataException {
		
		List<TipoManifestacao> tipos = new ArrayList<TipoManifestacao>();
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			StringBuilder select = new StringBuilder()
				.append(SELECT)
				.append(TipoManifestacao.getSqlCamposTipoManifestacao())
				.append(", ")
				.append(Evento.getSqlEvento())
				.append(FROM)
				.append(TipoManifestacao.getSqlFromTipoManifestacao())
				.append(LEFT_JOIN).append(Evento.getSqlFromEvento())
				.append(" ON TipoManifestacao.ID_EVENTO = Evento.ID_EVENTO ")
				.append(WHERE).append(" TipoManifestacao.FLAG_ATIVO = 1 ");
			
			if (order != null && !order.isEmpty()) {
				select.append(String.format(" ORDER BY %s ", order));
			}
			
			stmt = getPreparedStatement(select.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
			
			if (resultSet != null) {
				while (resultSet.next()) {
					TipoManifestacao tipo = TipoManifestacao.getTipoManifestacaoByResultSet(resultSet);
					tipo.setEvento(Evento.getEventoByResultSet(resultSet));
					tipos.add(tipo);
				}
			}
		} catch (Exception ex) {
			throw new DataException(ex);
		} finally {
			super.close(resultSet);
		}
		return tipos;
	}

	@Override
	public List<TipoManifestacao> findAtivos() throws DataException {
		return this.findAtivos(null);
	}
    
    
}
