/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.sau.dao.qlikview;

import java.util.Date;
import java.util.List;

import br.com.callink.cad.dao.IGenericCadDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.qlikview.pojo.QlikViewEnquete;

/**
 *
 * @author ubuntu
 */
public interface IQlikViewEnqueteDAO extends IGenericCadDAO<QlikViewEnquete> {

    /**
     * 
     * @param data1
     * @param data2
     * @return
     * @throws DataException 
     */
    List<QlikViewEnquete> geraNuvemEnquetesBetweenDatas(Date data1, Date data2) throws DataException;

    /**
     * 
     * @throws DataException 
     */
    void lipaDadosQlikViewEnquete() throws DataException;
}
