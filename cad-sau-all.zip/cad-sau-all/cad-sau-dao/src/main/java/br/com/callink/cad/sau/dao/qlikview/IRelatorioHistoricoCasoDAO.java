package br.com.callink.cad.sau.dao.qlikview;

import java.util.Date;
import java.util.List;

import br.com.callink.cad.dao.IGenericCadDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.qlikview.pojo.RelatorioHistoricoCaso;

public interface IRelatorioHistoricoCasoDAO extends IGenericCadDAO<RelatorioHistoricoCaso> {

        List<RelatorioHistoricoCaso> getCasosRelatorio(Date inicio, Date fim) throws DataException;
        void deleteAll() throws DataException;
		
        void apagarPorIdLog(Integer idLog) throws DataException;
	
}
