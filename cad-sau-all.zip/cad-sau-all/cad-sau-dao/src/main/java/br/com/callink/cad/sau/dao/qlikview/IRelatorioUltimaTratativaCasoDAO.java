package br.com.callink.cad.sau.dao.qlikview;

import java.util.Date;
import java.util.List;

import br.com.callink.cad.sau.dao.IGenericCadSauDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.qlikview.pojo.RelatorioUltimaTratativaCaso;

public interface IRelatorioUltimaTratativaCasoDAO extends
		IGenericCadSauDAO<RelatorioUltimaTratativaCaso> {

	/**
	 * Retorna ultima tratativa do atendimento do casos pela data que foi gerado o ultimo relatorio
	 * @param inicio
	 * @return
	 * @throws DataException
	 */
    List<RelatorioUltimaTratativaCaso> getCasosRelatorio(Date inicio) throws DataException;

	/**
	 * Remove todos os registros do relatorio 
	 * @throws DataException
	 */
    void deleteAll() throws DataException;

	void deleteByCaso(Integer idCaso) throws DataException;

}
