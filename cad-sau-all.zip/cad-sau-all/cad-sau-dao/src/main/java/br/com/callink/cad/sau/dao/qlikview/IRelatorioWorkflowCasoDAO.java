/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.sau.dao.qlikview;

import java.util.Date;

import br.com.callink.cad.sau.exception.DataException;

/**
 *
 * @author Luiz Gustavo F. (luizgf@swb.com.br)
 */
public interface IRelatorioWorkflowCasoDAO {
    void deleteAll() throws DataException;
    void geraRelatorio(Date dataInicio) throws DataException;
}
