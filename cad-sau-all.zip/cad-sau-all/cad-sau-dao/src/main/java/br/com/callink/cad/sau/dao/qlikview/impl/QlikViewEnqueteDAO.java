/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.sau.dao.qlikview.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;

import br.com.callink.cad.dao.impl.GenericCadDAO;
import br.com.callink.cad.sau.dao.qlikview.IQlikViewEnqueteDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.qlikview.pojo.QlikViewEnquete;

/**
 *
 * @author ubuntu
 */
public class QlikViewEnqueteDAO extends GenericCadDAO<QlikViewEnquete> implements IQlikViewEnqueteDAO {

	private static final long serialVersionUID = -620169413291350378L;

	public QlikViewEnqueteDAO() {
		super(QlikViewEnquete.class);
	}
	
    @Override
    public List<QlikViewEnquete> geraNuvemEnquetesBetweenDatas(Date data1, Date data2) throws DataException {
    	List<QlikViewEnquete> result = null;
    	PreparedStatement stmt = null;
    	ResultSet resultSet = null;
    	
    	StringBuilder sbr = new StringBuilder();
        sbr.append("select ");
        sbr.append("sau.manifestacao as MANIFESTACAO,");
        sbr.append("tc.id_tipo_caso as ID_TIPO_MANIFESTACAO,");
        sbr.append("tc.nome AS NOME_MANIFESTACAO,");
        sbr.append("tcf.id_configuracao_fila AS ID_FILA,");
        sbr.append("tcf.descricao AS DESCRICAO_FILA,");
        sbr.append("trq.data_resposta AS DATA_RESPOSTA,");
        sbr.append("trq.login AS ATENDENTE,");
        sbr.append("tqs.id_questionario AS ID_QUESTIONARIO, ");
        sbr.append("tqs.descricao AS DESCRICAO_QUESTIONARIO,");
        sbr.append("qq.id_questao AS ID_QUESTAO,");
        sbr.append("qq.descricao AS DESCRICAO_QUESTAO, ");
        sbr.append("tr.id_resposta AS ID_RESPOSTA, ");
        sbr.append("tr.resposta AS RESPOSTA,");
        sbr.append("ta.nome AS NOME");
        sbr.append(" from 	    tb_caso_sau sau with(nolock), ");
        sbr.append("		    tb_resultado_questionario trq with(nolock),");
        sbr.append("		    tb_resposta tr with(nolock), ");
        sbr.append("		    tb_tipo_caso tc with(nolock),");
        sbr.append("		    tb_questao qq with(nolock),");
        sbr.append("		    tb_questionario tqs with(nolock),");
        sbr.append("		    tb_caso cso with(nolock),");
        sbr.append("		    tb_configuracao_fila tcf with(nolock),");
        sbr.append("		    tb_atendente ta with(nolock)");
        sbr.append(" where sau.id_caso_sau = trq.id_externo and");
        sbr.append(" 	  sau.manifestacao = cso.id_externo and");
        sbr.append("	  cso.id_configuracao_fila =  tcf.id_configuracao_fila	and");
        sbr.append(" 	  sau.id_tipo_caso = tc.id_tipo_caso and");
        sbr.append("       tr.id_resultado_questionario = trq.id_resultado_questionario and");
        sbr.append("       trq.login = ta.login and");
        sbr.append("       tr.id_questao = qq.id_questao and");
        sbr.append("       qq.id_questionario = tqs.id_questionario and");
        sbr.append("       trq.data_resposta BETWEEN '").append(stringData(data1)).append("' AND '").append(stringData(data2)).append("'");
        try {
        	stmt = getPreparedStatement(sbr.toString());
			
			stmt.execute();
			resultSet = stmt.getResultSet();
            result = processaResultSet(resultSet);
        } catch (SQLException e) {
            throw new DataException(e);
        } finally {
			super.close(resultSet);
		}
        return result;
    }

    private List<QlikViewEnquete> processaResultSet(ResultSet resultSet) throws SQLException {
        List<QlikViewEnquete> ret = new ArrayList<QlikViewEnquete>();
        if (resultSet != null) {
            while (resultSet.next()) {
                QlikViewEnquete enquete = new QlikViewEnquete();
                enquete.setDataRegistroEnquete(resultSet.getTimestamp("DATA_RESPOSTA"));
                enquete.setDescricaoEnquete(resultSet.getString("DESCRICAO_QUESTIONARIO"));
                enquete.setDescricaoQestao(resultSet.getString("DESCRICAO_QUESTAO"));
                enquete.setIdResposta(resultSet.getInt("ID_RESPOSTA"));
                enquete.setDescricaoResposta(resultSet.getString("RESPOSTA"));
                enquete.setFilaTratamento(resultSet.getString("DESCRICAO_FILA"));
                enquete.setIdEnquete(resultSet.getInt("ID_QUESTIONARIO"));
                enquete.setIdFilaTratamento(resultSet.getInt("ID_FILA"));
                enquete.setIdQestao(resultSet.getInt("ID_QUESTAO"));
//              enquete.setIdTelefonia(resultSet.getInt(""));
                enquete.setIdTipoManifestacao(resultSet.getInt("ID_TIPO_MANIFESTACAO"));
                enquete.setLoginAtendente(resultSet.getString("ATENDENTE"));
                enquete.setManifestacao(resultSet.getString("MANIFESTACAO"));
                enquete.setTipoManifestacao(resultSet.getString("NOME_MANIFESTACAO"));
                enquete.setNomeAtendente(resultSet.getString("NOME"));
                ret.add(enquete);
            }
        }
        return ret;
    }

    private String stringData(Date data) {
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return df.format(data);
    }

    @Override
    public void lipaDadosQlikViewEnquete() throws DataException {
        try {
            StringBuilder sql = new StringBuilder().append(" truncate table tb_qlikview_enquete ");
        	
        	Query query = getEntityManager().createNativeQuery(sql.toString());
        	
            query.executeUpdate();
        } catch (Exception ex) {
            throw new DataException(ex);
        }
    }

}
