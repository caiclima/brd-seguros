package br.com.callink.cad.sau.dao.qlikview.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;

import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.pojo.Equipe;
import br.com.callink.cad.pojo.Log;
import br.com.callink.cad.pojo.SlaFila;
import br.com.callink.cad.pojo.Status;
import br.com.callink.cad.pojo.TempoAtendimentoCaso;
import br.com.callink.cad.sau.dao.impl.GenericCadSauDAO;
import br.com.callink.cad.sau.dao.qlikview.IRelatorioUltimaTratativaCasoDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.Assunto;
import br.com.callink.cad.sau.pojo.Canal;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.pojo.Causa;
import br.com.callink.cad.sau.pojo.Estado;
import br.com.callink.cad.sau.pojo.Evento;
import br.com.callink.cad.sau.pojo.TipoManifestacao;
import br.com.callink.cad.sau.qlikview.pojo.RelatorioUltimaTratativaCaso;
import br.com.callink.cad.util.Constantes;

public class RelatorioUltimaTratativaCasoDAO extends GenericCadSauDAO<RelatorioUltimaTratativaCaso> implements IRelatorioUltimaTratativaCasoDAO {

	private static final long serialVersionUID = -8012170239573098348L;

	public RelatorioUltimaTratativaCasoDAO() {
		super(RelatorioUltimaTratativaCaso.class);
	}

	private static final double UM_SEGUNDO_E_SETENTA_CENTESIMOS = 0.00002;
    
    @Override
    public List<RelatorioUltimaTratativaCaso> getCasosRelatorio(Date inicio) throws DataException {
        
    	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
        String dataInicio = dateFormat.format(inicio);
        ResultSet resultSetRelatorio = null;
        PreparedStatement stmtRelatorio = null;
        
        try {
			StringBuilder sql = getSqlRelatorio(dataInicio);

            stmtRelatorio = getPreparedStatement(sql.toString());
            stmtRelatorio.execute();
			resultSetRelatorio = stmtRelatorio.getResultSet();
			
			return buildRelatorios(resultSetRelatorio);
		} catch (Exception ex) {
            throw new DataException("Erro ao buscar dados para relatorio qlikview.", ex);
        } finally {
        	super.close(resultSetRelatorio);
        }
            
    }

	@Override
	public void deleteAll() throws DataException {
		try {
			Query query = getEntityManager().createNativeQuery(" truncate table TB_QLIKVIEW_ULTIMA_TRATATIVA_CASO ");
			query.executeUpdate();
		} catch (Exception ex) {
			throw new DataException("Erro ao limpar tabela do qlikview.", ex);
		}
	}
    
    
    private StringBuilder getSqlRelatorio(String dataInicio){
    	
    	StringBuilder query = new StringBuilder();
    	//select...
        query.append("select ")
                .append(Caso.getSqlCamposCaso()).append(Constantes.VIRGULA)
                .append(CasoSau.getSqlCamposCasoSau()).append(Constantes.VIRGULA)
                .append(Atendente.getSqlCamposAtendente()).append(Constantes.VIRGULA)
                .append(Assunto.getSqlAssunto()).append(Constantes.VIRGULA)
                .append(Evento.getSqlEvento()).append(Constantes.VIRGULA)
                .append(Canal.getSqlCamposCanal()).append(Constantes.VIRGULA)
                .append(TipoManifestacao.getSqlCamposTipoManifestacao()).append(Constantes.VIRGULA)
                .append(Causa.getSqlCausa()).append(Constantes.VIRGULA)
                .append(Status.getSqlCamposStatus()).append(Constantes.VIRGULA)
                .append(Log.getSqlCamposLog()).append(Constantes.VIRGULA)
                .append(Acao.getSqlCamposAcao()).append(Constantes.VIRGULA)
                .append(Equipe.getSqlEquipe()).append(Constantes.VIRGULA)
                .append(Estado.getSqlEstado()).append(Constantes.VIRGULA)
                .append(ConfiguracaoFila.getSqlCamposConfiguracaoFila()).append(Constantes.VIRGULA)
                .append(TempoAtendimentoCaso.getSqlCamposTempoAtendimentoCaso()).append(Constantes.VIRGULA)
                .append(SlaFila.getSqlCamposSlaFila());
        //from....
        query.append(" from ")
                .append(CasoSau.getSqlFromCasoSau())
                .append(" \n inner join ").append(Caso.getSqlFromCaso()).append(" on Caso.ID_CASO = CasoSau.ID_CASO ")
                .append(" \n left join ").append(SlaFila.getSqlFromSlaFila()).append(" on Caso.ID_SLA_FILA = SlaFila.ID_SLA_FILA ")
                .append(" \n left join ").append(Log.getSqlFromLog()).append(" on Log.ID_CASO = Caso.ID_CASO ")
                .append(" \n left join ").append(Status.getSqlFromStatus()).append(" on Status.ID_STATUS = Log.ID_STATUS ")
                .append(" \n left join ").append(Acao.getSqlFromAcao()).append(" on Acao.ID_ACAO = Log.ID_ACAO ")
                .append(" \n left join ").append(Evento.getSqlFromEvento()).append(" on CasoSau.ID_EVENTO = Evento.ID_EVENTO ")
                .append(" \n left join ").append(Causa.getSqlFromCausa()).append(" on Causa.ID_CAUSA = CasoSau.ID_CAUSA ")
                .append(" \n left join ").append(TipoManifestacao.getSqlFromTipoManifestacao()).append(" on TipoManifestacao.ID_TIPO_CASO = CasoSau.ID_TIPO_CASO")
                .append(" \n left join ").append(Canal.getSqlFromCanal()).append(" on Canal.ID_CANAL = CasoSau.ID_CANAL ")
                .append(" \n left join ").append(Assunto.getSqlFromAssunto()).append(" on Assunto.ID_ASSUNTO = Evento.ID_ASSUNTO ")
                .append(" \n left join ").append(Atendente.getSqlFromAtendente()).append(" on Log.ID_ATENDENTE = Atendente.ID_ATENDENTE ")
                .append(" \n left join ").append(Equipe.getSqlFromEquipe()).append(" on Atendente.ID_EQUIPE = Equipe.ID_EQUIPE ")
                .append(" \n left join ").append(Estado.getSqlFromEstado()).append(" on Estado.ID_ESTADO = CasoSau.ID_ESTADO ")
                .append(" \n left join ").append(ConfiguracaoFila.getSqlFromConfiguracaoFila()).append(" on ConfiguracaoFila.ID_CONFIGURACAO_FILA = Log.ID_CONFIGURACAO_FILA ")
                .append(" \n left join ").append(TempoAtendimentoCaso.getSqlFromTempoAtendimentoCaso())
                .append(" on (	TempoAtendimentoCaso.DATA_FIM BETWEEN Log.data_log  - ").append(UM_SEGUNDO_E_SETENTA_CENTESIMOS)
                .append("               and Log.DATA_LOG  + ").append(UM_SEGUNDO_E_SETENTA_CENTESIMOS)
                .append("               AND TempoAtendimentoCaso.ID_CASO = Caso.ID_CASO AND TempoAtendimentoCaso.ID_ACAO = Log.ID_ACAO ")
                .append("       ) ");
                
        query.append(" inner join (select id_caso AS ID_CASO, max(data_log) AS DATA_LOG, max(id_log) AS ID_LOG FROM tb_log with(nolock) WHERE data_log > '").
        append(dataInicio).append("' group by id_caso) as iCaso").append(" on iCaso.id_log = Log.id_log and iCaso.id_caso = Log.id_caso ");	
        
        return query;
    }

    private List<RelatorioUltimaTratativaCaso> buildRelatorios(ResultSet rs) throws DataException {
    	
    	List<RelatorioUltimaTratativaCaso> relatorioList = new ArrayList<RelatorioUltimaTratativaCaso>();
    	
        try {
            if (rs != null) {
                try {
                    while (rs.next()) {

                    	RelatorioUltimaTratativaCaso rel = new RelatorioUltimaTratativaCaso();
                        rel.setIdLog(rs.getInt("Log.ID_LOG"));
                        rel.setDataFimSla(rs.getTimestamp("Caso.DATA_FIM_SLA"));
                        rel.setIdCasoSau(rs.getInt("CasoSau.ID_CASO_SAU"));
                        rel.setIdAtendente(rs.getInt("Atendente.Id_Atendente"));
                        rel.setIdCaso(rs.getInt("CasoSau.ID_CASO"));
                        rel.setAgenciaConta(rs.getString("CasoSau.Agencia_Conta"));
                        rel.setAgenciaDepartamento(rs.getString("CasoSau.Agencia_Departamento"));
                        rel.setAssuntoSTGM(rs.getString("CasoSau.Assunto"));
                        rel.setCartao(rs.getString("CasoSau.Cartao"));
                        rel.setCep(rs.getString("CasoSau.Cep"));
                        rel.setCpfCnpj(rs.getString("CasoSau.Cpf_Cnpj"));
                        rel.setDataAbertura(rs.getTimestamp("CasoSau.Data_Abertura"));
                        rel.setDataCadastro(rs.getTimestamp("Caso.Data_Cadastro"));
                        rel.setDataEncerramento(rs.getTimestamp("Caso.Data_Encerramento"));
                        rel.setDataLog(rs.getTimestamp("Log.Data_Log"));
                        rel.setDataUltimaAcao(rs.getTimestamp("CasoSau.Data_Ultima_Acao"));
                        rel.setDescricao(rs.getString("CasoSau.Descricao"));
                        rel.setDescricaoAndamento(rs.getString("Log.Descricao"));
                        rel.setEmail(rs.getString("CasoSau.Email"));
                        rel.setEndereco(rs.getString("CasoSau.Endereco"));
                        rel.setEnvioProtocoloCliente(rs.getString("CasoSau.Envio_Protocolo_Cliente"));
                        rel.setGrupo(rs.getString("CasoSau.Grupo"));
                        rel.setIdAcao(rs.getInt("Acao.Id_Acao"));
                        rel.setIdAssunto(rs.getInt("Assunto.Id_Assunto"));
                        rel.setIdCanal(rs.getInt("Canal.Id_Canal"));
                        rel.setIdCausaErro(rs.getInt("Causa.Id_Causa"));
                        rel.setIdEquipe(rs.getInt("Equipe.Id_Equipe"));
                        rel.setIdEstado(rs.getInt("Estado.Id_Estado"));
                        rel.setIdEvento(rs.getInt("Evento.Id_Evento"));
                        rel.setIdFila(rs.getInt("ConfiguracaoFila.Id_Configuracao_Fila"));
                        rel.setIdStatus(rs.getInt("Status.Id_Status"));
                        rel.setIdTipoCaso(rs.getInt("TipoManifestacao.Id_Tipo_Caso"));
                        rel.setLoginAtendente(rs.getString("Atendente.Login"));
                        rel.setManifestacao(rs.getString("CasoSau.Manifestacao"));
                        rel.setNomeAcao(rs.getString("Acao.Nome"));
                        rel.setNomeAssunto(rs.getString("Assunto.Nome"));
                        rel.setNomeCanal(rs.getString("Canal.Nome"));
                        rel.setNomeCausa(rs.getString("CasoSau.Nome_Causa"));
                        rel.setNomeCausaErro(rs.getString("Causa.Nome"));
                        rel.setNomeCliente(rs.getString("CasoSau.Nome_Cliente"));
                        rel.setNomeEquipe(rs.getString("Equipe.Nome"));
                        rel.setNomeEstado(rs.getString("Estado.Nome"));
                        rel.setNomeEvento(rs.getString("Evento.Nome"));
                        rel.setNomeFila(rs.getString("ConfiguracaoFila.Nome"));
                        rel.setNomeStatus(rs.getString("Status.Nome"));
                        rel.setNomeTipoCaso(rs.getString("TipoManifestacao.Nome"));
                        rel.setSubGrupo(rs.getString("CasoSau.Sub_Grupo"));
                        rel.setTelefone(rs.getString("CasoSau.Telefone"));
                        rel.setTelefoneSegundo(rs.getString("CasoSau.Telefone_Segundo"));
                        rel.setTipoCartao(rs.getString("CasoSau.Tipo_Cartao"));
                        rel.setTipoManifestacao(rs.getString("CasoSau.Tipo_Manifestacao"));
                        rel.setUltimoAtendente(rs.getString("CasoSau.Ultimo_Atendente"));
                        rel.setViaEntrada(rs.getString("CasoSau.Via_Entrada"));
                        rel.setDataLogInicio(rs.getTimestamp("TempoAtendimentoCaso.DATA_INICIO")==null?rs.getTimestamp("Log.Data_Log"):rs.getTimestamp("TempoAtendimentoCaso.DATA_INICIO"));
                        rel.setDataLogFim(rs.getTimestamp("TempoAtendimentoCaso.DATA_FIM")==null?rs.getTimestamp("Log.Data_Log"):rs.getTimestamp("TempoAtendimentoCaso.DATA_FIM"));
                        rel.setIdTelefonia(rs.getString("Atendente.ID_TELEFONIA")==null? "0":rs.getString("Atendente.ID_TELEFONIA"));
                        rel.setDetalhe(rs.getString("Log.DETALHE"));
                        rel.setNomeAtendente(rs.getString("Atendente.NOME"));
                        rel.setFlagManual(rs.getBoolean("CasoSau.FLAG_MANUAL"));
                        rel.setFlagReaberto(rs.getBoolean("Caso.FLAG_REABERTO"));
                        rel.setSla(rs.getInt("SlaFila.SLA"));
                        
                        relatorioList.add(rel);
                    }
                } finally {
                    rs.close();
                }
            }

        } catch (SQLException e) {
            throw new DataException(e);
        } catch (Exception e) {
            throw new DataException(e);
        }
        return relatorioList;
    }
    
    @Override
    public void deleteByCaso(Integer idCaso) throws DataException {
    	
    	StringBuilder delete = new StringBuilder();
    	delete.append("delete from tb_qlikview_ultima_tratativa_caso where id_caso = ?");
    	PreparedStatement ps = getPreparedStatement(delete.toString());
    	
    	try {
    		ps.setInt(1, idCaso);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DataException(e);
		}
    	
    }
    
	@Override
	public List<RelatorioUltimaTratativaCaso> findByExample(
			RelatorioUltimaTratativaCaso t) throws DataException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<RelatorioUltimaTratativaCaso> findByExample(
			RelatorioUltimaTratativaCaso t, String order) throws DataException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<RelatorioUltimaTratativaCaso> findAll(String order)
			throws DataException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<RelatorioUltimaTratativaCaso> findAll() throws DataException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public RelatorioUltimaTratativaCaso findByPk(Object id)
			throws DataException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<RelatorioUltimaTratativaCaso> findAtivos(String order)
			throws DataException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<RelatorioUltimaTratativaCaso> findAtivos() throws DataException {
		// TODO Auto-generated method stub
		return null;
	}
}
