/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.sau.dao.qlikview.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.annotation.Resource;
import javax.sql.DataSource;

import br.com.callink.cad.sau.dao.qlikview.IRelatorioWorkflowCasoDAO;
import br.com.callink.cad.sau.exception.DataException;

/**
 *
 * @author Luiz Gustavo F. (luizgf@swb.com.br)
 */
public class RelatorioWorkflowCasoDAO implements IRelatorioWorkflowCasoDAO {

	@Resource(lookup = "java:jboss/datasources/CAD_DS")
	private DataSource dataSource; 
	
	private Connection connection;
	
	private PreparedStatement preparedStatement;
	
	public Connection getConnection() throws DataException{
		try {
			if(connection==null || connection.isClosed()){
				connection = dataSource.getConnection();
			}
			return connection;
		} catch (SQLException e) {
			throw new DataException(e);
		}
	}
	
	public PreparedStatement getPreparedStatement(String sql)throws DataException {
		try {
			preparedStatement = getConnection().prepareStatement(sql);
			return preparedStatement;
		} catch (SQLException e) {
			throw new DataException(e);
		}
	}
	
    @Override
    public void deleteAll() throws DataException {
    	PreparedStatement statement = null;
        try {
            String sql = "delete from tb_qlikview_workflow_caso";
            statement = getPreparedStatement(sql);
            statement.execute();
        } catch (SQLException e) {
            throw new DataException("Erro ao limpar tabela", e);
        } finally {
        	close();
        }
    }

    @Override
    public void geraRelatorio(Date dataInicio) throws DataException {
    	PreparedStatement statement = null;
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
            String dataInicioString = dateFormat.format(dataInicio);
            String relatorioSQL = 
                    "insert into tb_qlikview_workflow_caso "
                    + "select "
                    + "caso.id_caso,  "
                    + "caso.id_externo as manifestacao,  "
                    + "caso.data_abertura,  "
                    + "caso.data_cadastro,  "
                    + "a_caso.id_atendimento_caso as id_tratativa_fila,  "
                    + "fila.id_configuracao_fila,  "
                    + "fila.nome as nome_fila,  "
                    + "a_caso.data_inicio as data_chegada_fila,  "
                    + "a_caso.data_fim as data_saida_fila, "
                    + "case when a_caso.data_fim is null "
                    + "then datediff(minute,a_caso.data_inicio,current_timestamp) "
                    + "else datediff(minute,a_caso.data_inicio,a_caso.data_fim) "
                    + "end as tempo_decorrido_minutos_fila, "
                    + "atendente.id_atendente, atendente.login as login_atendente "
                    + "from "
                    + "tb_caso as caso inner join tb_atendimento_caso as a_caso on caso.id_caso = a_caso.id_caso  "
                    + "left join tb_configuracao_fila as fila on fila.id_configuracao_fila = a_caso.id_configuracao_fila "
                    + "left join tb_atendente atendente on atendente.id_atendente = a_caso.id_atendente "
                    + "where caso.id_caso in (select distinct tb_caso.id_caso from tb_caso "
                    + "inner join tb_log on tb_caso.id_caso = tb_log.id_caso  "
                    + "where tb_log.data_log >= '"+ dataInicioString +"' OR tb_caso.flag_finalizado = 0); ";
            statement = getPreparedStatement(relatorioSQL);
            statement.execute();
            
        } catch (SQLException e) {
            throw new DataException("Erro ao executar geraçao de relatorio de workflow de casos.", e);
        } finally {
        	close();
        }
    }
    
    private void close() throws DataException {

		try {

			if (preparedStatement != null) {
				preparedStatement.getConnection().close();
				preparedStatement.close();
			}
			if (connection != null && !connection.isClosed()) {
				connection.close();
			}

		} catch (SQLException e) {
			throw new DataException(e);
		}

	}
}