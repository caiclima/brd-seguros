package br.com.callink.cad.sau.enun;

/**
 *
 * @author Ricardo Teixeira Junior (ricardo.junior@callink.com.br)
 */
public enum OperadorApresentacao {
    IGUAL,
    DIFERENTE,
    CONTEM,
    NAO_CONTEM,
    MAIOR_QUE,
    MAIOR_IGUAL,
    MENOR_QUE,
    MENOR_IGUAL
}
