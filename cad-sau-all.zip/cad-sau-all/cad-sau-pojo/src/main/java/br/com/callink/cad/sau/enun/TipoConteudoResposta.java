package br.com.callink.cad.sau.enun;

/**
 *
 * @author Ricardo Teixeira Junior (ricardo.junior@callink.com.br)
 */
public enum TipoConteudoResposta {

    INTEIRO,
    TEXTO,
    DECIMAL,
    DATA
}
