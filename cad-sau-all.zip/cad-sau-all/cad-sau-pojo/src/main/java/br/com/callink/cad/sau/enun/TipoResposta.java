package br.com.callink.cad.sau.enun;

/**
 *
 * @author Ricardo Teixeira Junior (ricardo.junior@callink.com.br)
 */
public enum TipoResposta {

    MULTIPLA_ESCOLHA,
    UNICA_ESCOLHA,
    DESCRITIVA_MULTLINHA,
    DESCRITIVA_LINHAUNICA
}
