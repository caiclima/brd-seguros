package br.com.callink.cad.sau.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.pojo.entity.IEntity;

@Entity
@Table(name = "TB_ASSOCIA_CHECKLIST")
public class AssociaChecklist implements IEntity<Integer> {
	
	private static final long serialVersionUID = 1001341971636504854L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_associa_checklist", unique = true, nullable = false)
	private Integer idAssociaChecklist;
        
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_checklist", referencedColumnName = "id_checklist", nullable = false)
	private Checklist checklist;
        
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_evento", referencedColumnName = "id_evento", nullable = false)
	private Evento evento;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_acao", referencedColumnName = "id_acao", nullable = false)
	private Acao acao;
               
	@Column(name="flag_enabled", nullable = false)
	private Boolean flagEnabled;
	
	public Integer getPK() {
		return idAssociaChecklist;
	}

	public void setPK(Integer pK) {
		this.idAssociaChecklist = pK;
	}

	/**
	 * @return the evento
	 */
	public final Evento getEvento() {
		return evento;
	}

	/**
	 * @param evento the evento to set
	 */
	public final void setEvento(Evento evento) {
		this.evento = evento;
	}
	
	public Integer getIdAssociaChecklist() {
		return idAssociaChecklist;
	}

	public void setIdAssociaChecklist(Integer idAssociaChecklist) {
		this.idAssociaChecklist = idAssociaChecklist;
	}

	public Checklist getChecklist() {
		return checklist;
	}

	public void setChecklist(Checklist checklist) {
		this.checklist = checklist;
	}

	public Acao getAcao() {
		return acao;
	}

	public void setAcao(Acao acao) {
		this.acao = acao;
	}

	public Boolean getFlagEnabled() {
		return flagEnabled;
	}

	public void setFlagEnabled(Boolean flagEnabled) {
		this.flagEnabled = flagEnabled;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((idAssociaChecklist == null) ? 0 : idAssociaChecklist
						.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj){
			return true;
		}
		if (obj == null){
			return false;
		}
		if (getClass() != obj.getClass()){
			return false;
		}
		AssociaChecklist other = (AssociaChecklist) obj;
		if (idAssociaChecklist == null) {
			if (other.idAssociaChecklist != null){
				return false;
			}
		} else if (!idAssociaChecklist.equals(other.idAssociaChecklist)){
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "AssociaChecklist [idAssociaChecklist="
				+ idAssociaChecklist + "]";
	}
	
	public static String getSqlCamposAssociaChecklist() {
        return new StringBuilder()
                .append(" \nAssociaChecklist.ID_ASSOCIA_CHECKLIST AS 'AssociaChecklist.ID_ASSOCIA_CHECKLIST', ")
                .append(" \nAssociaChecklist.ID_CHECKLIST AS 'AssociaChecklist.ID_CHECKLIST', ")
                .append(" \nAssociaChecklist.ID_EVENTO AS 'AssociaChecklist.ID_EVENTO', ")
                .append(" \nAssociaChecklist.ID_ACAO AS 'AssociaChecklist.ID_ACAO', ")
                .append(" \nAssociaChecklist.FLAG_ENABLED AS 'AssociaChecklist.FLAG_ENABLED' ").toString();
    }

    public static String getSqlFromAssociaChecklist() {
        return " TB_ASSOCIA_CHECKLIST  AS AssociaChecklist with(nolock) ";
    }
    
    public static AssociaChecklist getAssociaChecklistByResultSet(ResultSet rs) {
        try {
        	
        	if(rs.getInt("AssociaChecklist.ID_ASSOCIA_CHECKLIST") == 0){
        		return null;
        	}
            AssociaChecklist associaChecklist = new AssociaChecklist();
            associaChecklist.setIdAssociaChecklist(rs.getInt("AssociaChecklist.ID_ASSOCIA_CHECKLIST"));
            associaChecklist.setChecklist(rs.getInt("AssociaChecklist.ID_CHECKLIST") == 0 ? null : new Checklist(rs.getInt("AssociaChecklist.ID_CHECKLIST")));
            associaChecklist.setEvento(rs.getInt("AssociaChecklist.ID_EVENTO") == 0 ? null : new Evento(rs.getInt("AssociaChecklist.ID_EVENTO")));
            associaChecklist.setAcao(rs.getInt("AssociaChecklist.ID_ACAO") == 0 ? null : new Acao(rs.getInt("AssociaChecklist.ID_ACAO")));
            associaChecklist.setFlagEnabled(rs.getBoolean("AssociaChecklist.FLAG_ENABLED"));
            return associaChecklist;
        } catch (SQLException ex) {
            throw new IllegalArgumentException(
                    "Erro ao montar objeto a partir do ResultSet", ex);
        }
    }
	
}
