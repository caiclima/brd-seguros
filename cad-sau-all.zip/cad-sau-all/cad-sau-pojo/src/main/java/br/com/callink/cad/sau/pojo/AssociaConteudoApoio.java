package br.com.callink.cad.sau.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import br.com.callink.cad.pojo.entity.IEntity;

@Entity
@Table(name = "TB_ASSOCIA_CONT_APOIO")
public class AssociaConteudoApoio implements IEntity<Integer> {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_associa_cont_apoio", unique = true, nullable = false)
	private Integer idAssociaContApoio;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_evento", referencedColumnName = "id_evento", nullable = false)
	private Evento evento;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_conteudo_apoio", referencedColumnName = "id_conteudo_apoio", nullable = false)
	private ConteudoApoio conteudoApoio;
	
	public Integer getPK() {
		return idAssociaContApoio;
	}

	public void setPK(Integer pK) {
		this.idAssociaContApoio = pK;
	}

	/**
	 * @return the idAssociaContApoio
	 */
	public final Integer getIdAssociaContApoio() {
		return idAssociaContApoio;
	}

	/**
	 * @param idAssociaContApoio the idAssociaContApoio to set
	 */
	public final void setIdAssociaContApoio(Integer idAssociaContApoio) {
		this.idAssociaContApoio = idAssociaContApoio;
	}

	/**
	 * @return the evento
	 */
	public final Evento getEvento() {
		return evento;
	}

	/**
	 * @param evento the evento to set
	 */
	public final void setEvento(Evento evento) {
		this.evento = evento;
	}

	/**
	 * @return the conteudoApoio
	 */
	public final ConteudoApoio getConteudoApoio() {
		return conteudoApoio;
	}

	/**
	 * @param conteudoApoio the conteudoApoio to set
	 */
	public final void setConteudoApoio(ConteudoApoio conteudoApoio) {
		this.conteudoApoio = conteudoApoio;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((idAssociaContApoio == null) ? 0 : idAssociaContApoio
						.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof AssociaConteudoApoio)) {
			return false;
		}
		AssociaConteudoApoio other = (AssociaConteudoApoio) obj;
		if (idAssociaContApoio == null) {
			if (other.idAssociaContApoio != null) {
				return false;
			}
		} else if (!idAssociaContApoio.equals(other.idAssociaContApoio)) {
			return false;
		}
		return true;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return idAssociaContApoio.toString();
	}
	
	public static String getSqlCamposAssociaConteudoApoio() {
        return new StringBuilder()
                .append(" \nAssociaConteudoApoio.ID_ASSOCIA_CONT_APOIO AS 'AssociaConteudoApoio.ID_ASSOCIA_CONT_APOIO', ")
                .append(" \nAssociaConteudoApoio.ID_EVENTO AS 'AssociaConteudoApoio.ID_EVENTO', ")
                .append(" \nAssociaConteudoApoio.ID_CONTEUDO_APOIO AS 'AssociaConteudoApoio.ID_CONTEUDO_APOIO' ").toString();
    }

    public static String getSqlFromAssociaConteudoApoio() {
        return " TB_ASSOCIA_CONT_APOIO  AS AssociaConteudoApoio with(nolock) ";
    }
    
    public static AssociaConteudoApoio getAssociaConteudoApoioByResultSet(ResultSet rs) {
        try {
        	
        	if(rs.getInt("AssociaConteudoApoio.ID_ASSOCIA_CONT_APOIO") == 0){
        		return null;
        	}
        	
            AssociaConteudoApoio associaConteudoApoio = new AssociaConteudoApoio();
            associaConteudoApoio.setIdAssociaContApoio(rs.getInt("AssociaConteudoApoio.ID_ASSOCIA_CONT_APOIO"));
            associaConteudoApoio.setEvento(rs.getInt("AssociaConteudoApoio.ID_EVENTO") == 0 ? null : new Evento(rs.getInt("AssociaConteudoApoio.ID_EVENTO")));
            associaConteudoApoio.setConteudoApoio(rs.getInt("AssociaConteudoApoio.ID_CONTEUDO_APOIO") ==0 ? null : new ConteudoApoio(rs.getInt("AssociaConteudoApoio.ID_CONTEUDO_APOIO")));
            return associaConteudoApoio;
        } catch (SQLException ex) {
            throw new IllegalArgumentException(
                    "Erro ao montar objeto a partir do ResultSet", ex);
        }
    }
	
}
