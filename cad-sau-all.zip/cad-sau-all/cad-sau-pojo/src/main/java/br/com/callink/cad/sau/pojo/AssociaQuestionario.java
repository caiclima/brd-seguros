package br.com.callink.cad.sau.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import br.com.callink.cad.pojo.entity.IEntity;

@Entity
@Table(name = "TB_ASSOCIA_QUESTIONARIO")
public class AssociaQuestionario implements IEntity<Integer> {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_associa_questionario", unique = true, nullable = false)
	private Integer idAssociaQuestionario;
        
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_questionario", referencedColumnName = "id_questionario", nullable = false)
	private Questionario questionario;
        
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_evento", referencedColumnName = "id_evento", nullable = false)
	private Evento evento;
               
	@Column(name="flag_check_list", nullable = false)
	private Boolean flagCheckList;
	
	public Integer getPK() {
		return idAssociaQuestionario;
	}

	public void setPK(Integer pk) {
		this.idAssociaQuestionario = pk;
	}

	/**
	 * @return the idAssociaQuestionario
	 */
	public final Integer getIdAssociaQuestionario() {
		return idAssociaQuestionario;
	}

	/**
	 * @param idAssociaQuestionario the idAssociaQuestionario to set
	 */
	public final void setIdAssociaQuestionario(Integer idAssociaQuestionario) {
		this.idAssociaQuestionario = idAssociaQuestionario;
	}

	/**
	 * @return the questionario
	 */
	public final Questionario getQuestionario() {
		return questionario;
	}

	/**
	 * @param questionario the questionario to set
	 */
	public final void setQuestionario(Questionario questionario) {
		this.questionario = questionario;
	}

	/**
	 * @return the evento
	 */
	public final Evento getEvento() {
		return evento;
	}

	/**
	 * @param evento the evento to set
	 */
	public final void setEvento(Evento evento) {
		this.evento = evento;
	}

	/**
	 * @return the flagCheckList
	 */
	public final Boolean getFlagCheckList() {
		return flagCheckList;
	}

	/**
	 * @param flagCheckList the flagCheckList to set
	 */
	public final void setFlagCheckList(Boolean flagCheckList) {
		this.flagCheckList = flagCheckList;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((idAssociaQuestionario == null) ? 0 : idAssociaQuestionario
						.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof AssociaQuestionario)) {
			return false;
		}
		AssociaQuestionario other = (AssociaQuestionario) obj;
		if (idAssociaQuestionario == null) {
			if (other.idAssociaQuestionario != null) {
				return false;
			}
		} else if (!idAssociaQuestionario.equals(other.idAssociaQuestionario)) {
			return false;
		}
		return true;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "AssociaQuestionario [idAssociaQuestionario="
				+ idAssociaQuestionario + "]";
	}

	public static String getSqlCamposAssociaQuestionario() {
        return new StringBuilder()
                .append(" \nAssociaQuestionario.ID_ASSOCIA_QUESTIONARIO AS 'AssociaQuestionario.ID_ASSOCIA_QUESTIONARIO', ")
                .append(" \nAssociaQuestionario.ID_QUESTIONARIO AS 'AssociaQuestionario.ID_QUESTIONARIO', ")
                .append(" \nAssociaQuestionario.ID_EVENTO AS 'AssociaQuestionario.ID_EVENTO', ")
                .append(" \nAssociaQuestionario.FLAG_CHECK_LIST AS 'AssociaQuestionario.FLAG_CHECK_LIST' ").toString();
    }

    public static String getSqlFromAssociaQuestionario() {
        return " TB_ASSOCIA_QUESTIONARIO  AS AssociaQuestionario with(nolock) ";
    }
    
    public static AssociaQuestionario getAssociaQuestionarioByResultSet(ResultSet rs) {
        try {
        	
        	if(rs.getInt("AssociaQuestionario.ID_ASSOCIA_QUESTIONARIO") == 0){
        		return null;
        	}
        	
            AssociaQuestionario associaQuestionario = new AssociaQuestionario();
            associaQuestionario.setIdAssociaQuestionario(rs.getInt("AssociaQuestionario.ID_ASSOCIA_QUESTIONARIO"));
            associaQuestionario.setQuestionario(rs.getInt("AssociaQuestionario.ID_QUESTIONARIO") == 0 ? null : new Questionario(rs.getInt("AssociaQuestionario.ID_QUESTIONARIO")));
            associaQuestionario.setEvento(rs.getInt("AssociaQuestionario.ID_EVENTO") == 0 ? null : new Evento(rs.getInt("AssociaQuestionario.ID_EVENTO")));
            associaQuestionario.setFlagCheckList(rs.getBoolean("AssociaQuestionario.FLAG_CHECK_LIST"));
            return associaQuestionario;
        } catch (SQLException ex) {
            throw new IllegalArgumentException(
                    "Erro ao montar objeto a partir do ResultSet", ex);
        }
    }
	
}
