package br.com.callink.cad.sau.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;

@Entity
@Table(name = "TB_ASSUNTO")
public class Assunto implements IEntity<Integer> {

    private static final long serialVersionUID = -7391040999389819108L;
    
    @Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID_ASSUNTO", unique = true, nullable = false)
    private Integer idAssunto;
    
    @Column(name = "NOME", length = 500)
    private String nome;
    
    @Column(name = "DATA_CRIACAO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataCriacao;
    
    @Column(name = "FLAG_ATIVO")
    private Boolean flagAtivo;
    
    private transient Boolean selecionado;

    public Integer getPK() {
        return idAssunto;
    }

    public void setPK(Integer pk) {
        this.idAssunto = pk;
    }

    /**
     * @return the idAssunto
     */
    public final Integer getIdAssunto() {
        return idAssunto;
    }

    /**
     * @param idAssunto the idAssunto to set
     */
    public final void setIdAssunto(Integer idAssunto) {
        this.idAssunto = idAssunto;
    }

    /**
     * @return the nome
     */
    public final String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public final void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the dataCriacao
     */
    public final Date getDataCriacao() {
        return dataCriacao == null ? null : new Date(dataCriacao.getTime());
    }

    /**
     * @param dataCriacao the dataCriacao to set
     */
    public final void setDataCriacao(Date dataCriacao) {
        this.dataCriacao = dataCriacao == null ? null : new Date(dataCriacao.getTime());
    }

    /**
     * @return the flagAtivo
     */
    public final Boolean getFlagAtivo() {
        return flagAtivo;
    }

    /**
     * @param flagAtivo the flagAtivo to set
     */
    public final void setFlagAtivo(Boolean flagAtivo) {
        this.flagAtivo = flagAtivo;
    }

    @Override
    public String toString() {
        return this.getNome();
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 41 * hash + (this.idAssunto != null ? this.idAssunto.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Assunto other = (Assunto) obj;
        if (this.idAssunto == null || !this.idAssunto.equals(other.idAssunto)) {
            return false;
        }
        return true;
    }

    public final Boolean getSelecionado() {
        return selecionado;
    }

    public final void setSelecionado(Boolean selecionado) {
        this.selecionado = selecionado;
    }
    
    public static String getSqlAssunto() {
        return new StringBuilder()
            .append(" \nAssunto.ID_ASSUNTO AS 'Assunto.ID_ASSUNTO', ")
            .append(" \nAssunto.NOME AS 'Assunto.NOME', ")
            .append(" \nAssunto.DATA_CRIACAO AS 'Assunto.DATA_CRIACAO', ")
            .append(" \nAssunto.FLAG_ATIVO AS 'Assunto.FLAG_ATIVO' ").toString();
    }
   
    public static String getSqlFromAssunto() {
        return " TB_ASSUNTO AS Assunto with(nolock) ";
    }
    
    public static Assunto getAssuntoByResultSet(ResultSet rs) {
        try {
        	
        	if(rs.getInt("Assunto.ID_ASSUNTO") == 0){
        		return null;
        	}

        	
            Assunto assunto = new Assunto();
            assunto.setIdAssunto(rs.getInt("Assunto.ID_ASSUNTO"));
            assunto.setFlagAtivo(rs.getBoolean("Assunto.FLAG_ATIVO"));
            assunto.setDataCriacao(rs.getTimestamp("Assunto.DATA_CRIACAO"));
            assunto.setNome(rs.getString("Assunto.NOME"));
            return assunto;
        } catch (SQLException ex) {
            throw new IllegalArgumentException(
                    "Erro ao montar objeto a partir do ResultSet", ex);
        }
    }
    
}
