package br.com.callink.cad.sau.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;

@Entity
@Table(name = "TB_CANAL")
public class Canal implements IEntity<Integer> {
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID_CANAL", unique = true, nullable = false)
	private Integer idCanal;
	
	@Column(name = "NOME", length = 500)
	private String nome;
	
	@Column(name = "DATA_CRIACAO")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataCriacao;
	
	@Column(name = "FLAG_ATIVO")
	private Boolean flagAtivo;
	
	@Column(name="flag_caso_manual")
    private Boolean flagCasoManual;
        
	private transient Boolean selecionado;
	
	public Canal() {

	}

	public Canal(Integer idCanal) {
		this.idCanal = idCanal;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((idCanal == null) ? 0 : idCanal.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof Canal)) {
			return false;
		}
		Canal other = (Canal) obj;
		if (idCanal == null) {
			if (other.idCanal != null) {
				return false;
			}
		} else if (!idCanal.equals(other.idCanal)) {
			return false;
		}
		return true;
	}

	public Integer getPK() {
		return idCanal;
	}

	public void setPK(Integer pk) {
		idCanal = pk;
	}

	public final Integer getIdCanal() {
		return idCanal;
	}

	public final void setIdCanal(Integer idCanal) {
		this.idCanal = idCanal;
	}

	public final String getNome() {
		return nome;
	}

	public final void setNome(String nome) {
		this.nome = nome;
	}

	public final Date getDataCriacao() {
		return dataCriacao == null ? null : new Date(dataCriacao.getTime());
	}

	public final void setDataCriacao(Date dataCriacao) {
		this.dataCriacao = dataCriacao == null ? null: new Date(dataCriacao.getTime());
	}

	public final Boolean getFlagAtivo() {
		return flagAtivo;
	}

	public final void setFlagAtivo(Boolean flagAtivo) {
		this.flagAtivo = flagAtivo;
	}

	@Override
	public String toString() {
		return this.getNome();
	}

	public static String getSqlCamposCanal() {

		return new StringBuilder()

		.append(" \nCanal.ID_CANAL AS 'Canal.ID_CANAL', ")
				.append(" \nCanal.NOME AS 'Canal.NOME', ")
				.append(" \nCanal.DATA_CRIACAO AS 'Canal.DATA_CRIACAO', ")
				.append(" \nCanal.FLAG_ATIVO AS 'Canal.FLAG_ATIVO', ")
				.append(" \nCanal.FLAG_CASO_MANUAL AS 'Canal.FLAG_CASO_MANUAL' ")
				.toString();
	}

	public static String getSqlFromCanal() {
		return " TB_CANAL  AS Canal with(nolock) ";
	}

	public static Canal getCanalByResultSet(ResultSet resultSet) {
		try {
			
			if(resultSet.getInt("Canal.ID_CANAL") == 0){
        		return null;
        	}
			
			Canal canal = new Canal();
			canal.setIdCanal(resultSet.getInt("Canal.ID_CANAL"));
			canal.setNome(resultSet.getString("Canal.NOME"));
			canal.setDataCriacao(resultSet.getTimestamp("Canal.DATA_CRIACAO"));
			canal.setFlagAtivo(resultSet.getBoolean("Canal.FLAG_ATIVO"));
			canal.setFlagCasoManual(resultSet.getBoolean("Canal.FLAG_CASO_MANUAL"));
			
			return canal;
		} catch (SQLException e) {
			throw new IllegalArgumentException(
					"Erro ao montar objeto a partir do ResultSet", e);
		}
	}

	public final Boolean getSelecionado() {
		return selecionado;
	}

	public final void setSelecionado(Boolean selecionado) {
		this.selecionado = selecionado;
	}

    public final Boolean getFlagCasoManual() {
        return flagCasoManual;
    }

    public final void setFlagCasoManual(Boolean flagCasoManual) {
        this.flagCasoManual = flagCasoManual;
    }
        
        
}
