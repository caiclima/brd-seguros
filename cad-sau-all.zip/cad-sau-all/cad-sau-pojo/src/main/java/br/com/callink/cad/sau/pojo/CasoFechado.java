package br.com.callink.cad.sau.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import br.com.callink.cad.pojo.entity.IEntity;

@Entity
@Table(name = "TB_CASO_FECHADO")
public class CasoFechado implements IEntity<Integer> {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID_CASO_FECHADO", unique = true, nullable = false)
    private Integer idCasoFechado;
    
    @Column(name = "MANIFESTACAO")
    private String manifestacao;
    
    @Column(name = "DATA_ABERTURA")
    private String dataAbertura;
    
    @Column(name = "DATA_ULTIMA_ACAO")
    private String dataUltimaAcao;
    
    @Column(name = "NOME_ESTADO")
    private String nomeEstado;
    
    @Column(name = "NOME_CANAL")
    private String nomeCanal;
    
    @Column(name = "ULTIMO_ATENDENTE")
    private String ultimoAtendente;
    
    @Column(name = "ATENDENTE_ATUAL")
    private String atendenteAtual;
    
    @Column(name = "NOME_TIPO_CASO")
    private String nomeTipoCaso;
    
    @Column(name = "AGENCIA_DEPARTAMENTO")
    private String agenciaDepartamento;
    
    @Column(name = "NOME_CLIENTE")
    private String nomeCliente;
    
    @Column(name = "AGENCIA_CONTA")
    private String agenciaConta;
    
    @Column(name = "CPF_CNPJ")
    private String cpfCnpj;
    
    @Column(name = "EMAIL")
    private String email;
    
    @Column(name = "TELEFONE")
    private String telefone;
    
    @Column(name = "TELEFONE_SEGUNDO")
    private String telefoneSegundo;
    
    @Column(name = "ENDERECO")
    private String endereco;
    
    @Column(name = "CEP")
    private String cep;
    
    @Column(name = "ENVIO_PROTOCOLO_CLIENTE")
    private String envioProtocoloCliente;
    
    @Column(name = "VIA_ENTRADA")
    private String viaEntrada;
    
    @Column(name = "DESCRICAO")
    private String descricao;
    
    @Column(name = "ASSUNTO")
    private String assunto;
    
    @Column(name = "HORA_ABERTURA")
    private String horaAbertura;
    
    @Column(name = "GRUPO")
    private String grupo;
    
    @Column(name = "SUB_GRUPO")
    private String subGrupo;
    
    @Column(name = "NOME_CAUSA")
    private String nomeCausa;
    
    private transient CasoSau casoSau;

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result
                + ((idCasoFechado == null) ? 0 : idCasoFechado.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof CasoFechado)) {
            return false;
        }
        CasoFechado other = (CasoFechado) obj;
        if (idCasoFechado == null) {
            if (other.idCasoFechado != null) {
                return false;
            }
        } else if (!idCasoFechado.equals(other.idCasoFechado)) {
            return false;
        }
        return true;
    }

    public Integer getPK() {
        return idCasoFechado;
    }

    public void setPK(Integer pk) {
        idCasoFechado = pk;
    }

    public final Integer getIdCasoFechado() {
        return idCasoFechado;
    }

    public final void setIdCasoFechado(Integer idCasoFechado) {
        this.idCasoFechado = idCasoFechado;
    }

    public final String getManifestacao() {
        return manifestacao;
    }

    public final void setManifestacao(String manifestacao) {
        this.manifestacao = manifestacao;
    }

    public final String getDataAbertura() {
        return dataAbertura;
    }

    public final void setDataAbertura(String dataAbertura) {
        this.dataAbertura = dataAbertura;
    }

    public final String getDataUltimaAcao() {
        return dataUltimaAcao;
    }

    public final void setDataUltimaAcao(String dataUltimaAcao) {
        this.dataUltimaAcao = dataUltimaAcao;
    }

    public final String getNomeEstado() {
        return nomeEstado;
    }

    public final void setNomeEstado(String nomeEstado) {
        this.nomeEstado = nomeEstado;
    }

    public final String getNomeCanal() {
        return nomeCanal;
    }

    public final void setNomeCanal(String nomeCanal) {
        this.nomeCanal = nomeCanal;
    }

    public final String getUltimoAtendente() {
        return ultimoAtendente;
    }

    public final void setUltimoAtendente(String ultimoAtendente) {
        this.ultimoAtendente = ultimoAtendente;
    }

    public final String getAtendenteAtual() {
        return atendenteAtual;
    }

    public final void setAtendenteAtual(String atendenteAtual) {
        this.atendenteAtual = atendenteAtual;
    }

    public final String getNomeTipoCaso() {
        return nomeTipoCaso;
    }

    public final void setNomeTipoCaso(String nomeTipoCaso) {
        this.nomeTipoCaso = nomeTipoCaso;
    }

    public final String getAgenciaDepartamento() {
        return agenciaDepartamento;
    }

    public final void setAgenciaDepartamento(String agenciaDepartamento) {
        this.agenciaDepartamento = agenciaDepartamento;
    }

    public final String getNomeCliente() {
        return nomeCliente;
    }

    public final void setNomeCliente(String nomeCliente) {
        this.nomeCliente = nomeCliente;
    }

    public final String getAgenciaConta() {
        return agenciaConta;
    }

    public final void setAgenciaConta(String agenciaConta) {
        this.agenciaConta = agenciaConta;
    }

    public final String getCpfCnpj() {
        return cpfCnpj;
    }

    public final void setCpfCnpj(String cpfCnpj) {
        this.cpfCnpj = cpfCnpj;
    }

    public final String getEmail() {
        return email;
    }

    public final void setEmail(String email) {
        this.email = email;
    }

    public final String getTelefone() {
        return telefone;
    }

    public final void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public final String getTelefoneSegundo() {
        return telefoneSegundo;
    }

    public final void setTelefoneSegundo(String telefoneSegundo) {
        this.telefoneSegundo = telefoneSegundo;
    }

    public final String getEndereco() {
        return endereco;
    }

    public final void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public final String getCep() {
        return cep;
    }

    public final void setCep(String cep) {
        this.cep = cep;
    }

    public final String getEnvioProtocoloCliente() {
        return envioProtocoloCliente;
    }

    public final void setEnvioProtocoloCliente(String envioProtocoloCliente) {
        this.envioProtocoloCliente = envioProtocoloCliente;
    }

    public final String getViaEntrada() {
        return viaEntrada;
    }

    public final void setViaEntrada(String viaEntrada) {
        this.viaEntrada = viaEntrada;
    }

    public final String getDescricao() {
        return descricao;
    }

    public final void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public final String getAssunto() {
        return assunto;
    }

    public final void setAssunto(String assunto) {
        this.assunto = assunto;
    }

    public final String getHoraAbertura() {
        return horaAbertura;
    }

    public final void setHoraAbertura(String horaAbertura) {
        this.horaAbertura = horaAbertura;
    }

    public final String getGrupo() {
        return grupo;
    }

    public final void setGrupo(String grupo) {
        this.grupo = grupo;
    }

    public final String getSubGrupo() {
        return subGrupo;
    }

    public final void setSubGrupo(String subGrupo) {
        this.subGrupo = subGrupo;
    }

    public final String getNomeCausa() {
        return nomeCausa;
    }

    public final void setNomeCausa(String nomeCausa) {
        this.nomeCausa = nomeCausa;
    }
    
    public final CasoSau getCasoSau() {
        return casoSau;
    }

    public final void setCasoSau(CasoSau casoSau) {
        this.casoSau = casoSau;
    }
    
    public static String getSqlFromCasoFechado() {
		return " TB_CASO_FECHADO  AS CasoFechado with(nolock) ";
	}
    
    public static String getSqlCamposCasoFechado(){
        
        return new StringBuilder()
        .append(" \nCasoFechado.ID_CASO_FECHADO AS 'CasoFechado.ID_CASO_FECHADO', ") 
	.append(" \nCasoFechado.MANIFESTACAO AS 'CasoFechado.MANIFESTACAO', ") 
	.append(" \nCasoFechado.DATA_ABERTURA AS 'CasoFechado.DATA_ABERTURA', ") 
	.append(" \nCasoFechado.DATA_ULTIMA_ACAO AS 'CasoFechado.DATA_ULTIMA_ACAO', ") 
	.append(" \nCasoFechado.NOME_ESTADO AS 'CasoFechado.NOME_ESTADO', ") 
	.append(" \nCasoFechado.NOME_CANAL AS 'CasoFechado.NOME_CANAL', ") 
	.append(" \nCasoFechado.ULTIMO_ATENDENTE AS 'CasoFechado.ULTIMO_ATENDENTE', ") 
	.append(" \nCasoFechado.ATENDENTE_ATUAL AS 'CasoFechado.ATENDENTE_ATUAL', ") 
	.append(" \nCasoFechado.NOME_TIPO_CASO AS 'CasoFechado.NOME_TIPO_CASO', ") 
	.append(" \nCasoFechado.AGENCIA_DEPARTAMENTO AS 'CasoFechado.AGENCIA_DEPARTAMENTO', ") 
	.append(" \nCasoFechado.NOME_CLIENTE AS 'CasoFechado.NOME_CLIENTE', ") 
	.append(" \nCasoFechado.AGENCIA_CONTA AS 'CasoFechado.AGENCIA_CONTA', ") 
	.append(" \nCasoFechado.CPF_CNPJ AS 'CasoFechado.CPF_CNPJ', ") 
	.append(" \nCasoFechado.EMAIL AS 'CasoFechado.EMAIL', ") 
	.append(" \nCasoFechado.TELEFONE AS 'CasoFechado.TELEFONE', ") 
	.append(" \nCasoFechado.TELEFONE_SEGUNDO AS 'CasoFechado.TELEFONE_SEGUNDO', ") 
	.append(" \nCasoFechado.ENDERECO AS 'CasoFechado.ENDERECO', ") 
	.append(" \nCasoFechado.CEP AS 'CasoFechado.CEP', ") 
	.append(" \nCasoFechado.ENVIO_PROTOCOLO_CLIENTE AS 'CasoFechado.ENVIO_PROTOCOLO_CLIENTE', ") 
	.append(" \nCasoFechado.VIA_ENTRADA AS 'CasoFechado.VIA_ENTRADA', ") 
	.append(" \nCasoFechado.DESCRICAO AS 'CasoFechado.DESCRICAO', ") 
	.append(" \nCasoFechado.ASSUNTO AS 'CasoFechado.ASSUNTO', ") 
	.append(" \nCasoFechado.HORA_ABERTURA AS 'CasoFechado.HORA_ABERTURA', ") 
	.append(" \nCasoFechado.GRUPO AS 'CasoFechado.GRUPO', ") 
	.append(" \nCasoFechado.SUB_GRUPO AS 'CasoFechado.SUB_GRUPO', ") 
	.append(" \nCasoFechado.NOME_CAUSA AS 'CasoFechado.NOME_CAUSA' ").toString();
        
    }
    
    public static CasoFechado getCasoFechadoByResultSet(ResultSet resultSet) {
        try {
        	
        	if(resultSet.getInt("CasoFechado.ID_CASO_FECHADO") == 0){
        		return null;
        	}
        	
            CasoFechado casoFechado = new CasoFechado();
            casoFechado.setIdCasoFechado(resultSet.getInt("CasoFechado.ID_CASO_FECHADO"));
            casoFechado.setManifestacao(resultSet.getString("CasoFechado.MANIFESTACAO"));
            casoFechado.setDataAbertura(resultSet.getString("CasoFechado.DATA_ABERTURA"));
            casoFechado.setDataUltimaAcao(resultSet.getString("CasoFechado.DATA_ULTIMA_ACAO"));
            casoFechado.setNomeEstado(resultSet.getString("CasoFechado.NOME_ESTADO"));
            casoFechado.setNomeCanal(resultSet.getString("CasoFechado.NOME_CANAL"));
            casoFechado.setUltimoAtendente(resultSet.getString("CasoFechado.ULTIMO_ATENDENTE"));
            casoFechado.setAtendenteAtual(resultSet.getString("CasoFechado.ATENDENTE_ATUAL"));
            casoFechado.setNomeTipoCaso(resultSet.getString("CasoFechado.NOME_TIPO_CASO"));
            casoFechado.setAgenciaDepartamento(resultSet.getString("CasoFechado.AGENCIA_DEPARTAMENTO"));
            casoFechado.setNomeCliente(resultSet.getString("CasoFechado.NOME_CLIENTE"));
            casoFechado.setAgenciaConta(resultSet.getString("CasoFechado.AGENCIA_CONTA"));
            casoFechado.setCpfCnpj(resultSet.getString("CasoFechado.CPF_CNPJ"));
            casoFechado.setEmail(resultSet.getString("CasoFechado.EMAIL"));
            casoFechado.setTelefone(resultSet.getString("CasoFechado.TELEFONE"));
            casoFechado.setTelefoneSegundo(resultSet.getString("CasoFechado.TELEFONE_SEGUNDO"));
            casoFechado.setEndereco(resultSet.getString("CasoFechado.ENDERECO"));
            casoFechado.setCep(resultSet.getString("CasoFechado.CEP"));
            casoFechado.setEnvioProtocoloCliente(resultSet.getString("CasoFechado.ENVIO_PROTOCOLO_CLIENTE"));
            casoFechado.setViaEntrada(resultSet.getString("CasoFechado.VIA_ENTRADA"));
            casoFechado.setDescricao(resultSet.getString("CasoFechado.DESCRICAO"));
            casoFechado.setAssunto(resultSet.getString("CasoFechado.ASSUNTO"));
            casoFechado.setHoraAbertura(resultSet.getString("CasoFechado.HORA_ABERTURA"));
            casoFechado.setGrupo(resultSet.getString("CasoFechado.GRUPO"));
            casoFechado.setSubGrupo(resultSet.getString("CasoFechado.SUB_GRUPO"));
            casoFechado.setNomeCausa(resultSet.getString("CasoFechado.NOME_CAUSA"));
            
            return casoFechado;
        } catch (SQLException e) {
            throw new IllegalArgumentException(
                    "Erro ao montar objeto a partir do ResultSet", e);
        }
    }
}
