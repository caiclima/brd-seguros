package br.com.callink.cad.sau.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.entity.IEntity;

@Entity
@Table(name = "TB_CASO_SAU")
public class CasoSau implements IEntity<Integer> {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID_CASO_SAU", unique = true, nullable = false)
	private Integer idCasoSau;

	@Column(name = "MANIFESTACAO", length = 20)
	private String manifestacao;

	@Column(name = "DATA_ABERTURA")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataAbertura;

	@Column(name = "DATA_ULTIMA_ACAO")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataUltimaAcao;

	@Column(name = "ULTIMO_ATENDENTE", length = 200)
	private String ultimoAtendente;

	@Column(name = "ATENDENTE_ATUAL", length = 200)
	private String atendenteAtual;

	@Column(name = "AGENCIA_DEPARTAMENTO", length = 200)
	private String agenciaDepartamento;

	@Column(name = "NOME_CLIENTE", length = 500)
	private String nomeCliente;

	@Column(name = "AGENCIA_CONTA", length = 200)
	private String agenciaConta;

	@Column(name = "CPF_CNPJ", length = 50)
	private String cpfCnpj;

	@Column(name = "EMAIL", length = 500)
	private String email;

	@Column(name = "TELEFONE", length = 50)
	private String telefone;

	@Column(name = "TELEFONE_SEGUNDO", length = 50)
	private String telefoneSegundo;

	@Column(name = "ENDERECO")
	private String endereco;

	@Column(name = "CEP", length = 50)
	private String cep;

    @Column(name = "FLAG_MANUAL")
    private Boolean flagManual;
        
	@Column(name = "ENVIO_PROTOCOLO_CLIENTE", length = 100)
	private String envioProtocoloCliente;

	@Column(name = "VIA_ENTRADA", length = 500)
	private String viaEntrada;

	@Column(name = "DESCRICAO")
	private String descricao;

	@Column(name = "ASSUNTO", length = 500)
	private String assunto;

	@Column(name = "GRUPO", length = 500)
	private String grupo;

	@Column(name = "SUB_GRUPO", length = 500)
	private String subGrupo;
	
	@Column(name="NOME_CAUSA", length = 200)
	private String nomeCausa;
        
    @Column(name="CARTAO", length = 50)
	private String cartao;
                
    @Column(name="TIPO_CARTAO", length = 50)
	private String tipoCartao;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_CASO", referencedColumnName = "ID_CASO", nullable = false)
	private Caso caso;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_CAUSA", referencedColumnName = "ID_CAUSA")
	private Causa causa;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_EVENTO", referencedColumnName = "ID_EVENTO")
	private Evento evento;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_CANAL", referencedColumnName = "ID_CANAL", nullable = false)
	private Canal canal;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_TIPO_CASO", referencedColumnName = "ID_TIPO_CASO", nullable = false)
	private TipoManifestacao tipoManifestacao;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_ESTADO", referencedColumnName = "ID_ESTADO")
	private Estado estado;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_JUNCAO", referencedColumnName = "ID_JUNCAO")
	private Juncao juncao;
        
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_OUTRA_AREA", referencedColumnName = "ID_OUTRA_AREA")
	private OutraArea outraArea;
        
    @ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_JUNCAO_ATRAZO", referencedColumnName = "ID_JUNCAO")
	private Juncao juncaoAtrazo;
        
    @Column(name="TIPO_MANIFESTACAO", length = 200)
    private String tipoManifestacaoSTGM;
    
    @Column(name="origem_protocolo", length = 50)
    private String origemProtocolo;
        
    private transient String motivo;
    
	private transient Boolean selecionado;
        
    private transient Boolean flagRechamado;
    
    private transient String atendenteAtualGBO;
        
    private transient Boolean flagCasoAssociar;
    
    private transient Integer tipoAssociacaoCaso;
        
    public CasoSau() {
    	
    }
    
    public CasoSau(Integer idCasoSau) {
    	this.idCasoSau = idCasoSau;
    }
    
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((idCasoSau == null) ? 0 : idCasoSau.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof CasoSau)) {
			return false;
		}
		CasoSau other = (CasoSau) obj;
		if (idCasoSau == null) {
			if (other.idCasoSau != null) {
				return false;
			}
		} else if (!idCasoSau.equals(other.idCasoSau)) {
			return false;
		}
		return true;
	}

	public Integer getPK() {
		return idCasoSau;
	}

	public void setPK(Integer pk) {
		this.idCasoSau = pk;
	}

	public final Integer getIdCasoSau() {
		return idCasoSau;
	}

	public final void setIdCasoSau(Integer idCasoSau) {
		this.idCasoSau = idCasoSau;
	}

	public final Date getDataAbertura() {
		return dataAbertura == null ? null : new Date(dataAbertura.getTime());
	}

	public final void setDataAbertura(Date dataAbertura) {
		this.dataAbertura = dataAbertura == null ? null : new Date(dataAbertura.getTime());
	}

	public final String getUltimoAtendente() {
		return ultimoAtendente;
	}

	public final void setUltimoAtendente(String ultimoAtendente) {
		this.ultimoAtendente = ultimoAtendente;
	}

	public final String getAtendenteAtual() {
		return atendenteAtual;
	}

	public final void setAtendenteAtual(String atendenteAtual) {
		this.atendenteAtual = atendenteAtual;
	}

	public final String getAgenciaDepartamento() {
		return agenciaDepartamento;
	}

	public final void setAgenciaDepartamento(String agenciaDepartamento) {
		this.agenciaDepartamento = agenciaDepartamento;
	}

	public final String getNomeCliente() {
		return nomeCliente;
	}

	public final void setNomeCliente(String nomeCliente) {
		this.nomeCliente = nomeCliente;
	}

	public final String getAgenciaConta() {
		return agenciaConta;
	}

	public final void setAgenciaConta(String agenciaConta) {
		this.agenciaConta = agenciaConta;
	}

	public final String getCpfCnpj() {
		return cpfCnpj;
	}

	public final void setCpfCnpj(String cpfCnpj) {
		this.cpfCnpj = cpfCnpj;
	}

	public final String getEmail() {
		return email;
	}

	public final void setEmail(String email) {
		this.email = email;
	}

	public final String getTelefone() {
		return telefone;
	}

	public final void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public final String getTelefoneSegundo() {
		return telefoneSegundo;
	}

	public final void setTelefoneSegundo(String telefoneSegundo) {
		this.telefoneSegundo = telefoneSegundo;
	}

	public final String getEndereco() {
		return endereco;
	}

	public final void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public final String getCep() {
		return cep;
	}

	public final void setCep(String cep) {
		this.cep = cep;
	}

	public final String getViaEntrada() {
		return viaEntrada;
	}

	public final void setViaEntrada(String viaEntrada) {
		this.viaEntrada = viaEntrada;
	}

	public final String getDescricao() {
		return descricao;
	}

	public final void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public final String getAssunto() {
		return assunto;
	}

	public final void setAssunto(String assunto) {
		this.assunto = assunto;
	}

	public final String getGrupo() {
		return grupo;
	}

	public final void setGrupo(String grupo) {
		this.grupo = grupo;
	}

	public final String getSubGrupo() {
		return subGrupo;
	}

	public final void setSubGrupo(String subGrupo) {
		this.subGrupo = subGrupo;
	}

	public final Caso getCaso() {
		return caso;
	}

	public final void setCaso(Caso caso) {
		this.caso = caso;
	}

	public final Causa getCausa() {
		return causa;
	}

	public final void setCausa(Causa causa) {
		this.causa = causa;
	}

	public final Evento getEvento() {
		return evento;
	}

	public final void setEvento(Evento evento) {
		this.evento = evento;
	}

	public final Canal getCanal() {
		return canal;
	}

	public final void setCanal(Canal canal) {
		this.canal = canal;
	}

	public final TipoManifestacao getTipoManifestacao() {
		return tipoManifestacao;
	}

	public final void setTipoManifestacao(TipoManifestacao tipoManifestacao) {
		this.tipoManifestacao = tipoManifestacao;
	}

	public final Estado getEstado() {
		return estado;
	}

	public final void setEstado(Estado estado) {
		this.estado = estado;
	}

	public final String getManifestacao() {
		return manifestacao;
	}

	public final void setManifestacao(String manifestacao) {
		this.manifestacao = manifestacao;
	}

	public final Date getDataUltimaAcao() {
		return dataUltimaAcao == null ? null : new Date(dataUltimaAcao.getTime());
	}

	public final void setDataUltimaAcao(Date dataUltimaAcao) {
		this.dataUltimaAcao = dataUltimaAcao == null ? null : new Date(dataUltimaAcao.getTime());
	}

	public final String getEnvioProtocoloCliente() {
		return envioProtocoloCliente;
	}

	public final void setEnvioProtocoloCliente(String envioProtocoloCliente) {
		this.envioProtocoloCliente = envioProtocoloCliente;
	}
	
	public String getMotivo() {
		return motivo;
	}

	public void setMotivo(String motivo) {
		this.motivo = motivo;
	}

	public final Boolean getSelecionado() {
		return selecionado;
	}

	public final void setSelecionado(Boolean selecionado) {
		this.selecionado = selecionado;
	}

        public Boolean getFlagManual() {
            return flagManual;
        }

        public void setFlagManual(Boolean flagManual) {
            this.flagManual = flagManual;
        }

        public String getCartao() {
            return cartao;
        }

        public void setCartao(String cartao) {
            this.cartao = cartao;
        }

        public String getTipoCartao() {
            return tipoCartao;
        }

        public void setTipoCartao(String tipoCartao) {
            this.tipoCartao = tipoCartao;
        }

	public final Juncao getJuncao() {
		return juncao;
	}

	public final void setJuncao(Juncao juncao) {
		this.juncao = juncao;
	}

        public Boolean getFlagRechamado() {
            return flagRechamado;
        }

        public void setFlagRechamado(Boolean flagRechamado) {
            this.flagRechamado = flagRechamado;
        }

        public OutraArea getOutraArea() {
            return outraArea;
        }

        public void setOutraArea(OutraArea outraArea) {
            this.outraArea = outraArea;
        }

        public Juncao getJuncaoAtrazo() {
            return juncaoAtrazo;
        }

        public void setJuncaoAtrazo(Juncao juncaoAtrazo) {
            this.juncaoAtrazo = juncaoAtrazo;
        }
        
	public static String getSqlCamposCasoSau() {

		return new StringBuilder()
				.append(" \nCasoSau.ID_CASO_SAU AS 'CasoSau.ID_CASO_SAU',")
				.append(" \nCasoSau.MANIFESTACAO AS 'CasoSau.MANIFESTACAO',")
				.append(" \nCasoSau.DATA_ABERTURA AS 'CasoSau.DATA_ABERTURA',")
				.append(" \nCasoSau.DATA_ULTIMA_ACAO AS 'CasoSau.DATA_ULTIMA_ACAO',")
				.append(" \nCasoSau.ULTIMO_ATENDENTE AS 'CasoSau.ULTIMO_ATENDENTE',")
				.append(" \nCasoSau.ATENDENTE_ATUAL AS 'CasoSau.ATENDENTE_ATUAL',")
				.append(" \nCasoSau.AGENCIA_DEPARTAMENTO AS 'CasoSau.AGENCIA_DEPARTAMENTO',")
				.append(" \nCasoSau.NOME_CLIENTE AS 'CasoSau.NOME_CLIENTE',")
				.append(" \nCasoSau.AGENCIA_CONTA AS 'CasoSau.AGENCIA_CONTA',")
				.append(" \nCasoSau.CPF_CNPJ AS 'CasoSau.CPF_CNPJ',")
				.append(" \nCasoSau.EMAIL AS 'CasoSau.EMAIL',")
				.append(" \nCasoSau.TELEFONE AS 'CasoSau.TELEFONE',")
                .append(" \nCasoSau.FLAG_MANUAL AS 'CasoSau.FLAG_MANUAL',")
				.append(" \nCasoSau.CARTAO AS 'CasoSau.CARTAO',")
                .append(" \nCasoSau.TIPO_CARTAO AS 'CasoSau.TIPO_CARTAO',")                                
				.append(" \nCasoSau.TELEFONE_SEGUNDO AS 'CasoSau.TELEFONE_SEGUNDO',")
				.append(" \nCasoSau.ENDERECO AS 'CasoSau.ENDERECO',")
				.append(" \nCasoSau.CEP AS 'CasoSau.CEP',")
				.append(" \nCasoSau.ENVIO_PROTOCOLO_CLIENTE AS 'CasoSau.ENVIO_PROTOCOLO_CLIENTE',")
				.append(" \nCasoSau.VIA_ENTRADA AS 'CasoSau.VIA_ENTRADA',")
				.append(" \nCasoSau.DESCRICAO AS 'CasoSau.DESCRICAO',")
				.append(" \nCasoSau.ASSUNTO AS 'CasoSau.ASSUNTO',")
				.append(" \nCasoSau.GRUPO AS 'CasoSau.GRUPO',")
				.append(" \nCasoSau.SUB_GRUPO AS 'CasoSau.SUB_GRUPO',")
				.append(" \nCasoSau.ID_CASO AS 'CasoSau.ID_CASO',")
				.append(" \nCasoSau.ID_CAUSA AS 'CasoSau.ID_CAUSA',")
				.append(" \nCasoSau.ID_EVENTO AS 'CasoSau.ID_EVENTO',")
				.append(" \nCasoSau.ID_CANAL AS 'CasoSau.ID_CANAL',")
				.append(" \nCasoSau.ID_TIPO_CASO AS 'CasoSau.ID_TIPO_CASO',")
				.append(" \nCasoSau.ID_ESTADO AS 'CasoSau.ID_ESTADO',")
				.append(" \nCasoSau.ID_JUNCAO AS 'CasoSau.ID_JUNCAO',")
            	.append(" \nCasoSau.ID_JUNCAO_ATRAZO AS 'CasoSau.ID_JUNCAO_ATRAZO',")
				.append(" \nCasoSau.NOME_CAUSA AS 'CasoSau.NOME_CAUSA',")
            	.append(" \nCasoSau.ID_OUTRA_AREA AS 'CasoSau.ID_OUTRA_AREA',")
                .append(" \nCasoSau.TIPO_MANIFESTACAO AS 'CasoSau.TIPO_MANIFESTACAO', ")
                .append(" \nCasoSau.ORIGEM_PROTOCOLO AS 'CasoSau.ORIGEM_PROTOCOLO' ")
				.toString();

	}

	public static String getSqlFromCasoSau() {
		return " TB_CASO_SAU  AS CasoSau with(nolock) ";
	}

	   public static CasoSau getCasoSauByResultSet(ResultSet resultSet) {

        try {
        	
        	if(resultSet.getInt("CasoSau.ID_CASO_SAU") == 0){
           		return null;
           	}
        	
        	CasoSau casoSau = new CasoSau();
            casoSau.setIdCasoSau(resultSet.getInt("CasoSau.ID_CASO_SAU"));
            casoSau.setNomeCliente(resultSet.getString("CasoSau.NOME_CLIENTE"));
            casoSau.setManifestacao(resultSet.getString("CasoSau.MANIFESTACAO"));
            casoSau.setDataAbertura(resultSet.getTimestamp("CasoSau.DATA_ABERTURA"));
            casoSau.setDataUltimaAcao(resultSet.getTimestamp("CasoSau.DATA_ULTIMA_ACAO"));
            casoSau.setUltimoAtendente(resultSet.getString("CasoSau.ULTIMO_ATENDENTE"));
            casoSau.setAtendenteAtual(resultSet.getString("CasoSau.ATENDENTE_ATUAL"));
            casoSau.setAgenciaDepartamento(resultSet.getString("CasoSau.AGENCIA_DEPARTAMENTO"));
            casoSau.setAgenciaConta(resultSet.getString("CasoSau.AGENCIA_CONTA"));
            casoSau.setCpfCnpj(resultSet.getString("CasoSau.CPF_CNPJ"));
            casoSau.setEmail(resultSet.getString("CasoSau.EMAIL"));
            casoSau.setTelefone(resultSet.getString("CasoSau.TELEFONE"));
            casoSau.setFlagManual(resultSet.getBoolean("CasoSau.FLAG_MANUAL"));
            casoSau.setCartao(resultSet.getString("CasoSau.CARTAO"));
            casoSau.setTipoCartao(resultSet.getString("CasoSau.TIPO_CARTAO"));
            casoSau.setTelefoneSegundo(resultSet.getString("CasoSau.TELEFONE_SEGUNDO"));
            casoSau.setEndereco(resultSet.getString("CasoSau.ENDERECO"));
            casoSau.setCep(resultSet.getString("CasoSau.CEP"));
            casoSau.setEnvioProtocoloCliente(resultSet.getString("CasoSau.ENVIO_PROTOCOLO_CLIENTE"));
            casoSau.setViaEntrada(resultSet.getString("CasoSau.VIA_ENTRADA"));
            casoSau.setDescricao(resultSet.getString("CasoSau.DESCRICAO"));
            casoSau.setAssunto(resultSet.getString("CasoSau.ASSUNTO"));
            casoSau.setGrupo(resultSet.getString("CasoSau.GRUPO"));
            casoSau.setSubGrupo(resultSet.getString("CasoSau.SUB_GRUPO"));
            casoSau.setCaso(resultSet.getInt("CasoSau.ID_CASO") == 0 ? null : new Caso(resultSet.getInt("CasoSau.ID_CASO")));
            casoSau.setCausa(resultSet.getInt("CasoSau.ID_CAUSA") == 0 ? null : new Causa(resultSet.getInt("CasoSau.ID_CAUSA")));
            casoSau.setEvento(resultSet.getInt("CasoSau.ID_EVENTO") == 0 ? null : new Evento(resultSet.getInt("CasoSau.ID_EVENTO")));
            casoSau.setCanal(resultSet.getInt("CasoSau.ID_CANAL") == 0 ? null : new Canal(resultSet.getInt("CasoSau.ID_CANAL")));
            casoSau.setTipoManifestacao(resultSet.getInt("CasoSau.ID_TIPO_CASO") == 0 ? null : new TipoManifestacao(resultSet.getInt("CasoSau.ID_TIPO_CASO")));
            casoSau.setEstado(resultSet.getInt("CasoSau.ID_ESTADO") == 0 ? null : new Estado(resultSet.getInt("CasoSau.ID_ESTADO")));
            casoSau.setJuncao(resultSet.getInt("CasoSau.ID_JUNCAO") == 0 ? null : new Juncao(resultSet.getInt("CasoSau.ID_JUNCAO")));
            casoSau.setJuncaoAtrazo(resultSet.getInt("CasoSau.ID_JUNCAO_ATRAZO") == 0 ? null : new Juncao(resultSet.getInt("CasoSau.ID_JUNCAO_ATRAZO")));
            casoSau.setOutraArea(resultSet.getInt("CasoSau.ID_OUTRA_AREA") == 0 ? null : new OutraArea(resultSet.getInt("CasoSau.ID_OUTRA_AREA")));
            casoSau.setNomeCausa(resultSet.getString("CasoSau.NOME_CAUSA"));
            casoSau.setTipoManifestacaoSTGM(resultSet.getString("CasoSau.TIPO_MANIFESTACAO"));
            casoSau.setOrigemProtocolo(resultSet.getString("CasoSau.ORIGEM_PROTOCOLO"));

            return casoSau;
        } catch (SQLException e) {
            throw new IllegalArgumentException("Erro ao montar objeto ", e);
        }

    }

	public final String getNomeCausa() {
		return nomeCausa;
	}

	public final void setNomeCausa(String nomeCausa) {
		this.nomeCausa = nomeCausa;
	}

    public String getTipoManifestacaoSTGM() {
        return tipoManifestacaoSTGM;
    }

    public void setTipoManifestacaoSTGM(String tipoManifestacaoSTGM) {
        this.tipoManifestacaoSTGM = tipoManifestacaoSTGM;
    }

    public String getAtendenteAtualGBO() {
        return atendenteAtualGBO;
    }

    public void setAtendenteAtualGBO(String atendenteAtualGBO) {
        this.atendenteAtualGBO = atendenteAtualGBO;
    }

	public Boolean getFlagCasoAssociar() {
		return flagCasoAssociar;
	}

	public void setFlagCasoAssociar(Boolean flagCasoAssociar) {
		this.flagCasoAssociar = flagCasoAssociar;
	}

	public Integer getTipoAssociacaoCaso() {
		return tipoAssociacaoCaso;
	}

	public void setTipoAssociacaoCaso(Integer tipoAssociacaoCaso) {
		this.tipoAssociacaoCaso = tipoAssociacaoCaso;
	}

	public String getOrigemProtocolo() {
		return origemProtocolo;
	}

	public void setOrigemProtocolo(String origemProtocolo) {
		this.origemProtocolo = origemProtocolo;
	}
	
}
