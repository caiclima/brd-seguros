package br.com.callink.cad.sau.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;

@Entity
@Table(name = "TB_CAUSA")
public class Causa implements IEntity<Integer> {

	private static final long serialVersionUID = 1L;

	public Causa() {
    }

    public Causa(Integer idCausa) {
        this.idCausa = idCausa;
    }
    
    @Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID_CAUSA", unique = true, nullable = false)
    private Integer idCausa;
    
    @Column(name = "NOME", length = 200)
    private String nome;
    
    @Column(name = "DATA_CRIACAO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataCriacao;
    
    @Column(name = "FLAG_ATIVO")
    private Boolean flagAtivo;

    private transient boolean selecionado;
    private transient boolean flagFinalizaAutomatico;
    
    public Integer getPK() {
        return idCausa;
    }

    public void setPK(Integer pk) {
        this.idCausa = pk;
    }

    /**
     * @return the idCausa
     */
    public final Integer getIdCausa() {
        return idCausa;
    }

    /**
     * @param idCausa the idCausa to set
     */
    public final void setIdCausa(Integer idCausa) {
        this.idCausa = idCausa;
    }

    /**
     * @return the nome
     */
    public final String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public final void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the dataCriacao
     */
    public final Date getDataCriacao() {
        return dataCriacao == null ? null : new Date(dataCriacao.getTime());
    }

    /**
     * @param dataCriacao the dataCriacao to set
     */
    public final void setDataCriacao(Date dataCriacao) {
        this.dataCriacao = dataCriacao == null ? null : new Date(dataCriacao.getTime());
    }

    /**
     * @return the flagAtivo
     */
    public final Boolean getFlagAtivo() {
        return flagAtivo;
    }

    /**
     * @param flagAtivo the flagAtivo to set
     */
    public final void setFlagAtivo(Boolean flagAtivo) {
        this.flagAtivo = flagAtivo;
    }

    @Override
    public String toString() {
        return this.getNome();
    }

    public boolean isSelecionado() {
        return selecionado;
    }

    public void setSelecionado(boolean selecionado) {
        this.selecionado = selecionado;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Causa other = (Causa) obj;
        if (this.idCausa == null || !this.idCausa.equals(other.idCausa)) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 79 * hash + (this.idCausa != null ? this.idCausa.hashCode() : 0);
        return hash;
    }

    public boolean isFlagFinalizaAutomatico() {
        return flagFinalizaAutomatico;
    }

    public void setFlagFinalizaAutomatico(boolean flagFinalizaAutomatico) {
        this.flagFinalizaAutomatico = flagFinalizaAutomatico;
    }
    
    public static String getSqlCausa() {
        return new StringBuilder()
                .append(" \nCausa.ID_CAUSA AS 'Causa.ID_CAUSA', ")
                .append(" \nCausa.NOME AS 'Causa.NOME',")
                .append(" \nCausa.DATA_CRIACAO AS 'Causa.DATA_CRIACAO', ")
                .append(" \nCausa.FLAG_ATIVO AS 'Causa.FLAG_ATIVO' ").toString();
    }

    public static String getSqlFromCausa() {
        return " TB_CAUSA AS Causa with(nolock) ";
    }

    public static Causa getCausaByResultSet(ResultSet rs) {
    	try {
    		
    		if(rs.getInt("Causa.ID_CAUSA") == 0){
           		return null;
           	}
    		
    		Causa causa = new Causa();
    		causa.setIdCausa(rs.getInt("Causa.ID_CAUSA"));
    		causa.setFlagAtivo(rs.getBoolean("Causa.FLAG_ATIVO"));
    		causa.setDataCriacao(rs.getTimestamp("Causa.DATA_CRIACAO"));
    		causa.setNome(rs.getString("Causa.NOME"));
    		return causa;
    	} catch (SQLException ex) {
    		throw new IllegalArgumentException(
    				"Erro ao montar objeto a partir do ResultSet", ex);
    	}
    }
    
}
