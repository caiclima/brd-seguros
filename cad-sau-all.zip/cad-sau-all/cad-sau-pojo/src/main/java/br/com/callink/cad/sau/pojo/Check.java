package br.com.callink.cad.sau.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import br.com.callink.cad.pojo.entity.IEntity;

@Entity
@Table(name = "TB_CHECK")
public class Check implements IEntity<Integer> {
    
	private static final long serialVersionUID = 5232077167223579752L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_check", unique = true, nullable = false)
    private Integer idCheck;
    
    @ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_check_pai", referencedColumnName = "id_check")
    private Check checkPai;
    
    @ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_checklist", referencedColumnName = "id_checklist", nullable = false)
    private Checklist checklist;
    
    @Column(name = "descricao", length = 200)
    private String descricao;
    
    @Column(name = "respostas_possiveis", length = 200, nullable = false)
    private String respostasPossiveis;
    
    @Column(name = "resposta_padrao", length = 100)
    private String respostaPadrao;
    
    @Column(name = "flag_enabled", nullable = false)
    private Boolean flagEnabled;
    
    @Column(name = "ordem", length = 10, nullable = false)
    private Integer ordem;
    
    @Column(name = "operador_apresentacao", length = 50)
    private String operadorApresentacao;
    
    @Column(name = "resposta_apresentacao", length = 100)
    private String respostaApresentacao;
    
    private transient List<String> respostas;
    private transient Boolean rendered = Boolean.FALSE;
    
    public Check() {
	}
    
    public Check(Integer idCheck){
    	this.idCheck = idCheck;
    }
    
    
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((idCheck == null) ? 0 : idCheck.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj){
			return true;
		}
		if (obj == null){
			return false;
		}
		if (getClass() != obj.getClass()){
			return false;
		}
		Check other = (Check) obj;
		if (idCheck == null) {
			if (other.idCheck != null){
				return false;
			}
		} else if (!idCheck.equals(other.idCheck)){
			return false;
		}
		return true;
	}

	//GETTERS AND SETTERS
    public Integer getPK() {
        return idCheck;
    }
    
    public void setPK(Integer pk) {
        this.idCheck = pk;
    }

	public Integer getIdCheck() {
		return idCheck;
	}

	public void setIdCheck(Integer idCheck) {
		this.idCheck = idCheck;
	}

	public Check getCheckPai() {
		return checkPai;
	}

	public void setCheckPai(Check checkPai) {
		this.checkPai = checkPai;
	}

	public Checklist getChecklist() {
		return checklist;
	}

	public void setChecklist(Checklist checklist) {
		this.checklist = checklist;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public String getRespostasPossiveis() {
		return respostasPossiveis;
	}

	public void setRespostasPossiveis(String respostasPossiveis) {
		this.respostasPossiveis = respostasPossiveis;
	}

	public Boolean getFlagEnabled() {
		return flagEnabled;
	}

	public void setFlagEnabled(Boolean flagEnabled) {
		this.flagEnabled = flagEnabled;
	}

	public String getRespostaPadrao() {
		return respostaPadrao;
	}

	public void setRespostaPadrao(String respostaPadrao) {
		this.respostaPadrao = respostaPadrao;
	}

	public Integer getOrdem() {
		return ordem;
	}

	public void setOrdem(Integer ordem) {
		this.ordem = ordem;
	}
	
	public String getOperadorApresentacao() {
		return operadorApresentacao;
	}

	public void setOperadorApresentacao(String operadorApresentacao) {
		this.operadorApresentacao = operadorApresentacao;
	}

	public String getRespostaApresentacao() {
		return respostaApresentacao;
	}

	public void setRespostaApresentacao(String respostaApresentacao) {
		this.respostaApresentacao = respostaApresentacao;
	}

	public List<String> getRespostas() {
        if (respostas == null && respostasPossiveis != null) {
            respostas = new ArrayList<String>();
            respostas.addAll(Arrays.asList(respostasPossiveis.split(";")));
        }
        return respostas;
    }
	
	@Override
	public String toString() {
		return descricao;
	}
	
	public Boolean getRendered() {
        if(checkPai == null || (checkPai.getIdCheck() == null || checkPai.getIdCheck() == 0 )){
            rendered = Boolean.TRUE;
        }
        return rendered;
    }

    public void setRendered(Boolean rendered) {
        this.rendered = rendered;
    }
    
    public static String getSqlCamposCheck() {
        return new StringBuilder()
                .append(" \nChec.ID_CHECK AS 'Check.ID_CHECK', ")
                .append(" \nChec.ID_CHECK_PAI AS 'Check.ID_CHECK_PAI', ")
                .append(" \nChec.ID_CHECKLIST AS 'Check.ID_CHECKLIST', ")
                .append(" \nChec.DESCRICAO AS 'Check.DESCRICAO', ")
                .append(" \nChec.RESPOSTAS_POSSIVEIS AS 'Check.RESPOSTAS_POSSIVEIS', ")
                .append(" \nChec.RESPOSTA_PADRAO AS 'Check.RESPOSTA_PADRAO', ")
                .append(" \nChec.FLAG_ENABLED AS 'Check.FLAG_ENABLED', ")
                .append(" \nChec.ORDEM AS 'Check.ORDEM', ")
                .append(" \nChec.OPERADOR_APRESENTACAO AS 'Check.OPERADOR_APRESENTACAO', ")
                .append(" \nChec.RESPOSTA_APRESENTACAO AS 'Check.RESPOSTA_APRESENTACAO' ").toString();
    }

    public static String getSqlFromCheck() {
        return " TB_CHECK  AS Chec with(nolock) ";
    }
    
    public static Check getCheckByResultSet(ResultSet rs) {
        try {
        	
        	if(rs.getInt("Check.ID_CHECK") == 0){
        		return null;
        	}
        	
            Check check = new Check();
            check.setIdCheck(rs.getInt("Check.ID_CHECK"));
            check.setCheckPai(rs.getInt("Check.ID_CHECK_PAI") == 0 ? null : new Check(rs.getInt("Check.ID_CHECK_PAI")));
            check.setChecklist(rs.getInt("Check.ID_CHECKLIST") == 0 ? null : new Checklist(rs.getInt("Check.ID_CHECKLIST")));
            check.setDescricao(rs.getString("Check.DESCRICAO"));
            check.setRespostasPossiveis(rs.getString("Check.RESPOSTAS_POSSIVEIS"));
            check.setRespostaPadrao(rs.getString("Check.RESPOSTA_PADRAO"));
            check.setFlagEnabled(rs.getBoolean("Check.FLAG_ENABLED"));
            check.setOrdem(rs.getInt("Check.ORDEM"));
            check.setOperadorApresentacao(rs.getString("Check.OPERADOR_APRESENTACAO"));
            check.setRespostaApresentacao(rs.getString("Check.RESPOSTA_APRESENTACAO"));
            return check;
        } catch (SQLException ex) {
            throw new IllegalArgumentException(
                    "Erro ao montar objeto a partir do ResultSet", ex);
        }
    }
	
}
