package br.com.callink.cad.sau.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import br.com.callink.cad.pojo.entity.IEntity;

@Entity
@Table(name = "TB_CHECKLIST")
public class Checklist implements IEntity<Integer> {
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_checklist", unique = true, nullable = false)
	private Integer idChecklist;
        
	@Column(name="descricao", length = 200)
	private String descricao;
        
	@Column(name="flag_enabled", nullable = false)
	private Boolean flagEnabled;
               
	@OneToMany(cascade = {CascadeType.REFRESH, CascadeType.REMOVE}, mappedBy = "checklist", fetch = FetchType.LAZY)
	private List<Check> checks;
	
	public Checklist(){
		
	}
	
	public Checklist(Integer id){
		this.idChecklist = id;
	}
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((idChecklist == null) ? 0 : idChecklist.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj){
			return true;
		}
		if (obj == null){
			return false;
		}
		if (getClass() != obj.getClass()){
			return false;
		}
		Checklist other = (Checklist) obj;
		if (idChecklist == null) {
			if (other.idChecklist != null){
				return false;
			}
		} else if (!idChecklist.equals(other.idChecklist)){
			return false;
		}
		return true;
	}

	//GETTERS AND SETTERS
	public Integer getPK() {
		return idChecklist;
	}
	
	public void setPK(Integer pk) {
		this.idChecklist = pk;
	}

	public final String getDescricao() {
		return descricao;
	}
	
	public final void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public Boolean getFlagEnabled() {
		return flagEnabled;
	}

	public void setFlagEnabled(Boolean flagEnabled) {
		this.flagEnabled = flagEnabled;
	}

	@Override
	public String toString() {
		return descricao;
	}

	public Integer getIdChecklist() {
		return idChecklist;
	}

	public void setIdChecklist(Integer idChecklist) {
		this.idChecklist = idChecklist;
	}

	public List<Check> getChecks() {
		return checks;
	}

	public void setChecks(List<Check> checks) {
		this.checks = checks;
	}
	
	public static String getSqlCamposChecklist() {
        return new StringBuilder()
                .append(" \nChecklist.ID_CHECKLIST AS 'Checklist.ID_CHECKLIST', ")
                .append(" \nChecklist.DESCRICAO AS 'Checklist.DESCRICAO', ")
                .append(" \nChecklist.FLAG_ENABLED AS 'Checklist.FLAG_ENABLED' ").toString();
    }

    public static String getSqlFromChecklist() {
        return " TB_CHECKLIST  AS Checklist with(nolock) ";
    }
    
    public static Checklist getChecklistByResultSet(ResultSet rs) {
        try {
        	
        	if(rs.getInt("Checklist.ID_CHECKLIST") == 0){
        		return null;
        	}
        	
            Checklist checklist = new Checklist();
            checklist.setIdChecklist(rs.getInt("Checklist.ID_CHECKLIST"));
            checklist.setDescricao(rs.getString("Checklist.DESCRICAO"));
            checklist.setFlagEnabled(rs.getBoolean("Checklist.FLAG_ENABLED"));
            return checklist;
        } catch (SQLException ex) {
            throw new IllegalArgumentException(
                    "Erro ao montar objeto a partir do ResultSet", ex);
        }
    }
	
}
