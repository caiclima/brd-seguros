package br.com.callink.cad.sau.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;

@Entity
@Table(name = "TB_CLASSIFICACAO_AUTOMATICA")
public class ClassificacaoAutomatica implements IEntity<Integer> {

	private static final long serialVersionUID = -3291853967845034174L;

	@Id
	@Column(name = "ID_CLASSIFICACAO_AUTOMATICA")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "TEXTO_PADRAO")
	private String textoPadrao;

	@Column(name = "ASSUNTO")
	private String assunto;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_EVENTO", referencedColumnName = "ID_EVENTO", nullable = false)
	private Evento evento;

	@Column(name = "DATA_CRIACAO")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataCriacao;

	@Column(name = "LOGIN_USUARIO")
	private String loginUsuario;

	public ClassificacaoAutomatica() {
	}

	public static String getSqlClassificacaoAutomatica() {

		return new StringBuilder()
				.append(" \nClassificacaoAutomatica.ID_CLASSIFICACAO_AUTOMATICA AS 'ClassificacaoAutomatica.ID_CLASSIFICACAO_AUTOMATICA',")
				.append(" \nClassificacaoAutomatica.TEXTO_PADRAO AS 'ClassificacaoAutomatica.TEXTO_PADRAO',")
				.append(" \nClassificacaoAutomatica.ASSUNTO AS 'ClassificacaoAutomatica.ASSUNTO',")
				.append(" \nClassificacaoAutomatica.ID_EVENTO AS 'ClassificacaoAutomatica.ID_EVENTO',")
				.append(" \nClassificacaoAutomatica.DATA_CRIACAO AS 'ClassificacaoAutomatica.DATA_CRIACAO',")
				.append(" \nClassificacaoAutomatica.LOGIN_USUARIO AS 'ClassificacaoAutomatica.LOGIN_USUARIO'")
				.toString();
	}

	public static String getSqlFromClassificacaoAutomatica() {
		return " TB_CLASSIFICACAO_AUTOMATICA AS ClassificacaoAutomatica with(nolock) ";
	}

	public static ClassificacaoAutomatica getClassificacaoAutomaticaByResultSet(
			ResultSet rs) {

		try {

			if (rs.getInt("ClassificacaoAutomatica.ID_CLASSIFICACAO_AUTOMATICA") == 0) {
				return null;
			}

			ClassificacaoAutomatica classificacaoAutomatica = new ClassificacaoAutomatica();
			classificacaoAutomatica
					.setPK(rs
							.getInt("ClassificacaoAutomatica.ID_CLASSIFICACAO_AUTOMATICA"));
			classificacaoAutomatica.setTextoPadrao(rs
					.getString("ClassificacaoAutomatica.TEXTO_PADRAO"));
			classificacaoAutomatica.setAssunto(rs
					.getString("ClassificacaoAutomatica.ASSUNTO"));
			classificacaoAutomatica.setEvento(rs
					.getInt("ClassificacaoAutomatica.ID_EVENTO") == 0 ? null
					: new Evento(rs.getInt("ClassificacaoAutomatica.ID_EVENTO")));
			classificacaoAutomatica.setDataCriacao(rs
					.getTimestamp("ClassificacaoAutomatica.DATA_CRIACAO"));
			classificacaoAutomatica.setLoginUsuario(rs
					.getString("ClassificacaoAutomatica.LOGIN_USUARIO"));
			return classificacaoAutomatica;
		} catch (SQLException ex) {
			throw new IllegalArgumentException(
					"Erro ao montar objeto a partir do ResultSet", ex);
		}
	}

	@Override
	public Integer getPK() {
		return this.id;
	}

	@Override
	public void setPK(Integer pk) {
		this.id = pk;
	}

	public String getTextoPadrao() {
		return textoPadrao;
	}

	public void setTextoPadrao(String textopadrao) {
		this.textoPadrao = textopadrao;
	}

	public String getAssunto() {
		return assunto;
	}

	public void setAssunto(String assunto) {
		this.assunto = assunto;
	}

	public Evento getEvento() {
		return evento;
	}

	public void setEvento(Evento evento) {
		this.evento = evento;
	}

	public Date getDataCriacao() {
		return dataCriacao;
	}

	public void setDataCriacao(Date dataCriacao) {
		this.dataCriacao = dataCriacao;
	}

	public String getLoginUsuario() {
		return loginUsuario;
	}

	public void setLoginUsuario(String loginUsuario) {
		this.loginUsuario = loginUsuario;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof ClassificacaoAutomatica)) {
			return false;
		}
		ClassificacaoAutomatica other = (ClassificacaoAutomatica) obj;
		if (id == null) {
			if (other.id != null) {
				return false;
			}
		} else if (!id.equals(other.id)) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "ClassificacaoAutomatica [id=" + id + "]";
	}

}
