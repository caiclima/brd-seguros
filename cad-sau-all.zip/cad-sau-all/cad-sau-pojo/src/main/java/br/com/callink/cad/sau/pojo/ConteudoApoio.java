package br.com.callink.cad.sau.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.GrupoAnexo;
import br.com.callink.cad.pojo.entity.IEntity;

@Entity
@Table(name = "TB_CONTEUDO_APOIO")
public class ConteudoApoio implements IEntity<Integer> {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_conteudo_apoio", unique = true, nullable = false)
    private Integer idConteudoApoio;
    
    @Column(name = "nome", length = 200)
    private String nome;
    
    @Column(name = "descricao")
    private String descricao;
    
    @Column(name = "data_criacao")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataCriacao;
    
    @Column(name = "flag_ativo")
    private Boolean flagAtivo;
    
    @ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_grupo_anexo", referencedColumnName = "id_grupo_anexo")
    private GrupoAnexo grupoAnexo;
    
    @OneToMany(cascade = {CascadeType.REFRESH, CascadeType.REMOVE}, mappedBy = "conteudoApoioCasoSauId.conteudoApoio", fetch = FetchType.LAZY)
    private List<ConteudoApoioCasoSau> conteudoApoioCasoSauList;
    
    @OneToMany(cascade = {CascadeType.REFRESH, CascadeType.REMOVE}, mappedBy = "conteudoApoio", fetch = FetchType.LAZY)
    private List<AssociaConteudoApoio> associaConteudoApoioList;
    
    public ConteudoApoio() {
    	
    }
    
    public ConteudoApoio(Integer idConteudoApoio) {
    	this.idConteudoApoio = idConteudoApoio;
    }
    
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result
                + ((idConteudoApoio == null) ? 0 : idConteudoApoio.hashCode());
        return result;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        ConteudoApoio other = (ConteudoApoio) obj;
        if (idConteudoApoio == null) {
            if (other.idConteudoApoio != null) {
                return false;
            }
        } else if (!idConteudoApoio.equals(other.idConteudoApoio)) {
            return false;
        }
        return true;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return nome;
    }
    
    public List<ConteudoApoioCasoSau> getConteudoApoioCasoSauList() {
        return conteudoApoioCasoSauList;
    }

    public void setConteudoApoioCasoSauList(List<ConteudoApoioCasoSau> conteudoApoioCasoSauList) {
        this.conteudoApoioCasoSauList = conteudoApoioCasoSauList;
    }

    public Integer getPK() {
        return idConteudoApoio;
    }

    public void setPK(Integer pk) {
        this.idConteudoApoio = pk;
    }

    /**
     * @return the idConteudoApoio
     */
    public final Integer getIdConteudoApoio() {
        return idConteudoApoio;
    }

    /**
     * @param idConteudoApoio the idConteudoApoio to set
     */
    public final void setIdConteudoApoio(Integer idConteudoApoio) {
        this.idConteudoApoio = idConteudoApoio;
    }

    /**
     * @return the grupoAnexo
     */
    public final GrupoAnexo getGrupoAnexo() {
        return grupoAnexo;
    }

    /**
     * @param grupoAnexo the grupoAnexo to set
     */
    public final void setGrupoAnexo(GrupoAnexo grupoAnexo) {
        this.grupoAnexo = grupoAnexo;
    }

    /**
     * @return the nome
     */
    public final String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public final void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the descricao
     */
    public final String getDescricao() {
        return descricao;
    }

    /**
     * @param descricao the descricao to set
     */
    public final void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    /**
     * @return the dataCriacao
     */
    public final Date getDataCriacao() {
        return dataCriacao == null ? null : new Date(dataCriacao.getTime());
    }

    /**
     * @param dataCriacao the dataCriacao to set
     */
    public final void setDataCriacao(Date dataCriacao) {
        this.dataCriacao = dataCriacao == null ? null : new Date(dataCriacao.getTime());
    }

    /**
     * @return the flagAtivo
     */
    public final Boolean getFlagAtivo() {
        return flagAtivo;
    }

    /**
     * @param flagAtivo the flagAtivo to set
     */
    public final void setFlagAtivo(Boolean flagAtivo) {
        this.flagAtivo = flagAtivo;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */

    public final List<AssociaConteudoApoio> getAssociaConteudoApoioList() {
        return associaConteudoApoioList;
    }

    public final void setAssociaConteudoApoioList(List<AssociaConteudoApoio> associaConteudoApoioList) {
        this.associaConteudoApoioList = associaConteudoApoioList;
    }
    
    public static String getSqlCamposConteudoApoio() {
        return new StringBuilder()
                .append(" \nConteudoApoio.ID_CONTEUDO_APOIO AS 'ConteudoApoio.ID_CONTEUDO_APOIO', ")
                .append(" \nConteudoApoio.NOME AS 'ConteudoApoio.NOME', ")
                .append(" \nConteudoApoio.DESCRICAO AS 'ConteudoApoio.DESCRICAO', ")
                .append(" \nConteudoApoio.DATA_CRIACAO AS 'ConteudoApoio.DATA_CRIACAO', ")
                .append(" \nConteudoApoio.FLAG_ATIVO AS 'ConteudoApoio.FLAG_ATIVO', ")
                .append(" \nConteudoApoio.ID_GRUPO_ANEXO AS 'ConteudoApoio.ID_GRUPO_ANEXO' ").toString();
    }

    public static String getSqlFromConteudoApoio() {
        return " TB_CONTEUDO_APOIO  AS ConteudoApoio with(nolock) ";
    }
    
    public static ConteudoApoio getConteudoApoioByResultSet(ResultSet rs) {
        try {
        	
        	if(rs.getInt("ConteudoApoio.ID_CONTEUDO_APOIO") == 0){
        		return null;
        	}
        	
            ConteudoApoio conteudoApoio = new ConteudoApoio();
            conteudoApoio.setIdConteudoApoio(rs.getInt("ConteudoApoio.ID_CONTEUDO_APOIO"));
            conteudoApoio.setNome(rs.getString("ConteudoApoio.NOME"));
            conteudoApoio.setDescricao(rs.getString("ConteudoApoio.DESCRICAO"));
            conteudoApoio.setDataCriacao(rs.getTimestamp("ConteudoApoio.DATA_CRIACAO"));
            conteudoApoio.setFlagAtivo(rs.getBoolean("ConteudoApoio.FLAG_ATIVO"));
            conteudoApoio.setGrupoAnexo(rs.getInt("ConteudoApoio.ID_GRUPO_ANEXO") == 0 ? null : new GrupoAnexo(rs.getInt("ConteudoApoio.ID_GRUPO_ANEXO")));
            return conteudoApoio;
        } catch (SQLException ex) {
            throw new IllegalArgumentException(
                    "Erro ao montar objeto a partir do ResultSet", ex);
        }
    }
    
}
