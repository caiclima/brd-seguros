package br.com.callink.cad.sau.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import br.com.callink.cad.pojo.entity.IEntity;

@Entity
@Table(name = "TB_CONTEUDOAPOIO_CASOSAU")
public class ConteudoApoioCasoSau implements IEntity<Integer> {
	
	private static final long serialVersionUID = 1L;
	
	@EmbeddedId
	private ConteudoApoioCasoSauId conteudoApoioCasoSauId;

    public ConteudoApoioCasoSau() {
    }
    
    public ConteudoApoioCasoSauId getConteudoApoioCasoSauId() {
    	
    	if(conteudoApoioCasoSauId==null){
    		conteudoApoioCasoSauId = new ConteudoApoioCasoSauId();
    	}
		return conteudoApoioCasoSauId;
	}

	public void setConteudoApoioCasoSauId(
			ConteudoApoioCasoSauId conteudoApoioCasoSauId) {
		this.conteudoApoioCasoSauId = conteudoApoioCasoSauId;
	}

	public Integer getPK() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void setPK(Integer t) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public static String getSqlCamposConteudoApoioCasoSau() {
        return new StringBuilder()
                .append(" \nConteudoApoioCasoSau.ID_CONTEUDO_APOIO AS 'ConteudoApoioCasoSau.ID_CONTEUDO_APOIO', ")
                .append(" \nConteudoApoioCasoSau.ID_CASO_SAU AS 'ConteudoApoioCasoSau.ID_CASO_SAU' ").toString();
    }

    public static String getSqlFromConteudoApoioCasoSau() {
        return " TB_CONTEUDOAPOIO_CASOSAU  AS ConteudoApoioCasoSau with(nolock) ";
    }
    
    public static ConteudoApoioCasoSau getConteudoApoioCasoSauByResultSet(ResultSet rs) {
        try {
        	
        	if(rs.getInt("ConteudoApoioCasoSau.ID_CONTEUDO_APOIO") == 0 || rs.getInt("ConteudoApoioCasoSau.ID_CASO_SAU") == 0 ){
        		return null;
        	}
        	
            ConteudoApoioCasoSau conteudoApoioCasoSau = new ConteudoApoioCasoSau();
            conteudoApoioCasoSau.setConteudoApoioCasoSauId(new ConteudoApoioCasoSauId());
            conteudoApoioCasoSau.getConteudoApoioCasoSauId().setConteudoApoio(new ConteudoApoio(rs.getInt("ConteudoApoioCasoSau.ID_CONTEUDO_APOIO") == 0 ? null : rs.getInt("ConteudoApoioCasoSau.ID_CONTEUDO_APOIO")));
            conteudoApoioCasoSau.getConteudoApoioCasoSauId().setCasoSau(new CasoSau(rs.getInt("ConteudoApoioCasoSau.ID_CASO_SAU") == 0 ? null : rs.getInt("ConteudoApoioCasoSau.ID_CASO_SAU")));
            return conteudoApoioCasoSau;
        } catch (SQLException ex) {
            throw new IllegalArgumentException(
                    "Erro ao montar objeto a partir do ResultSet", ex);
        }
    }

}