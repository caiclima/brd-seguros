package br.com.callink.cad.sau.pojo;

import javax.persistence.Embeddable;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import br.com.callink.cad.pojo.entity.IEntity;

@Embeddable
public class ConteudoApoioCasoSauId implements IEntity<Integer> {
	
	private static final long serialVersionUID = 1L;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_CONTEUDO_APOIO", referencedColumnName = "ID_CONTEUDO_APOIO", nullable = false)
    private ConteudoApoio conteudoApoio;
    
    @ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_CASO_SAU", referencedColumnName = "ID_CASO_SAU", nullable = false)
    private CasoSau casoSau;

    public ConteudoApoioCasoSauId() {
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ConteudoApoioCasoSauId other = (ConteudoApoioCasoSauId) obj;
        if (this.conteudoApoio != other.conteudoApoio && (this.conteudoApoio == null || !this.conteudoApoio.equals(other.conteudoApoio))) {
            return false;
        }
        if (this.casoSau != other.casoSau && (this.casoSau == null || !this.casoSau.equals(other.casoSau))) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 53 * hash + (this.conteudoApoio != null ? this.conteudoApoio.hashCode() : 0);
        hash = 53 * hash + (this.casoSau != null ? this.casoSau.hashCode() : 0);
        return hash;
    }
    

    public Integer getPK() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void setPK(Integer t) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public CasoSau getCasoSau() {
        return casoSau;
    }

    public void setCasoSau(CasoSau casoSau) {
        this.casoSau = casoSau;
    }

    public ConteudoApoio getConteudoApoio() {
        return conteudoApoio;
    }

    public void setConteudoApoio(ConteudoApoio conteudoApoio) {
        this.conteudoApoio = conteudoApoio;
    }
       

}