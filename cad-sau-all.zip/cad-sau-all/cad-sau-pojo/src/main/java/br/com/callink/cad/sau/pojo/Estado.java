package br.com.callink.cad.sau.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;

@Entity
@Table(name = "TB_ESTADO")
public class Estado implements IEntity<Integer> {
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID_ESTADO", unique = true, nullable = false)
	private Integer idEstado;
	
	@Column(name = "NOME", length = 500)
	private String nome;
	
	@Column(name = "DATA_CRIACAO")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataCriacao;
	
	@Column(name = "FLAG_ATIVO")
	private Boolean flagAtivo;
	
	private transient Boolean selecionado;

	public Estado() {

	}

	public Estado(Integer idEstado) {
		this.idEstado = idEstado;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((idEstado == null) ? 0 : idEstado.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof Estado)) {
			return false;
		}
		Estado other = (Estado) obj;
		if (idEstado == null) {
			if (other.idEstado != null) {
				return false;
			}
		} else if (!idEstado.equals(other.idEstado)) {
			return false;
		}
		return true;
	}

	public Integer getPK() {
		return idEstado;
	}

	public void setPK(Integer pk) {
		idEstado = pk;
	}

	public final Integer getIdEstado() {
		return idEstado;
	}

	public final void setIdEstado(Integer idEstado) {
		this.idEstado = idEstado;
	}

	public final String getNome() {
		return nome;
	}

	public final void setNome(String nome) {
		this.nome = nome;
	}

	public final Date getDataCriacao() {
		return dataCriacao == null ? null : new Date(dataCriacao.getTime());
	}

	public final void setDataCriacao(Date dataCriacao) {
		this.dataCriacao = dataCriacao == null ? null : new Date(dataCriacao.getTime());
	}

	public final Boolean getFlagAtivo() {
		return flagAtivo;
	}

	public final void setFlagAtivo(Boolean flagAtivo) {
		this.flagAtivo = flagAtivo;
	}

    @Override
    public String toString() {
        return getNome();
    }
        
    public static String getSqlEstado() {
        return new StringBuilder()
            .append(" \nEstado.ID_ESTADO AS 'Estado.ID_ESTADO',")
            .append(" \nEstado.NOME AS 'Estado.NOME',")
            .append(" \nEstado.DATA_CRIACAO AS 'Estado.DATA_CRIACAO',")
            .append(" \nEstado.FLAG_ATIVO AS 'Estado.FLAG_ATIVO'").toString();
    }
   
    public static Estado getEstadoByResultSet(ResultSet rs) {
        try {
        	
        	if(rs.getInt("Estado.ID_ESTADO") == 0){
        		return null;
        	}
        	
        	Estado estado = new Estado();
        	estado.setIdEstado(rs.getInt("Estado.ID_ESTADO"));
        	estado.setNome(rs.getString("Estado.NOME"));
        	estado.setDataCriacao(rs.getTimestamp("Estado.DATA_CRIACAO"));
        	estado.setFlagAtivo(rs.getBoolean("Estado.FLAG_ATIVO"));
            return estado;
        } catch (SQLException ex) {
            throw new IllegalArgumentException("Erro ao montar objeto a partir do ResultSet", ex);
        }
    }
    
    public static String getSqlFromEstado() {
        return " TB_ESTADO AS Estado with(nolock) ";
    }

	public Boolean getSelecionado() {
		return selecionado;
	}

	public void setSelecionado(Boolean selecionado) {
		this.selecionado = selecionado;
	}
    
}
