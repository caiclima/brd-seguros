package br.com.callink.cad.sau.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;

@Entity
@Table(name = "TB_EVENTO")
public class Evento implements IEntity<Integer> {

	private static final long serialVersionUID = -7123115231908454923L;

	@Id
	@Column(name = "ID_EVENTO")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idEvento;
    
    @Column(name = "NOME" , length = 500)
    private String nome;
    
    @Column(name = "DATA_CRIACAO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataCriacao;
    
    @Column(name = "FLAG_ATIVO")
    private Boolean flagAtivo;
    
    @ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_ASSUNTO", referencedColumnName = "ID_ASSUNTO" , nullable = false)
    private Assunto assunto;
    
    @Column(name = "FLAG_FINALIZACAO_AUTOMATICA")
    private Boolean flagFinalizacaoAutomatica;
    
    @Column(name = "EMAIL" , length = 500)
    private String email;
	
    private transient boolean selecionado;

    public Evento() {
    }

    public Evento(Integer idEvento) {
        this.idEvento = idEvento;
    }

    public Integer getPK() {
        return idEvento;
    }

    public void setPK(Integer pk) {
        this.idEvento = pk;
    }

    /**
     * @return the idEvento
     */
    public final Integer getIdEvento() {
        return idEvento;
    }

    /**
     * @param idEvento
     *            the idEvento to set
     */
    public final void setIdEvento(Integer idEvento) {
        this.idEvento = idEvento;
    }

    /**
     * @return the nome
     */
    public final String getNome() {
        return nome;
    }

    /**
     * @param nome
     *            the nome to set
     */
    public final void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the dataCriacao
     */
    public final Date getDataCriacao() {
        return dataCriacao == null ? null : new Date(dataCriacao.getTime());
    }

    /**
     * @param dataCriacao
     *            the dataCriacao to set
     */
    public final void setDataCriacao(Date dataCriacao) {
        this.dataCriacao = dataCriacao == null ? null : new Date(dataCriacao.getTime());
    }

    /**
     * @return the flagAtivo
     */
    public final Boolean getFlagAtivo() {
        return flagAtivo;
    }

    /**
     * @param flagAtivo
     *            the flagAtivo to set
     */
    public final void setFlagAtivo(Boolean flagAtivo) {
        this.flagAtivo = flagAtivo;
    }

    public void setAssunto(Assunto assunto) {
        this.assunto = assunto;
    }

    public Assunto getAssunto() {
        return assunto;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Boolean getFlagFinalizacaoAutomatica() {
        return flagFinalizacaoAutomatica;
    }

    public void setFlagFinalizacaoAutomatica(Boolean flagFinalizacaoAutomatica) {
        this.flagFinalizacaoAutomatica = flagFinalizacaoAutomatica;
    }

    @Override
    public String toString() {
        return this.getNome();
    }

    public final Boolean getSelecionado() {
        return selecionado;
    }

    public final void setSelecionado(Boolean selecionado) {
        this.selecionado = selecionado;
    }

    public static String getSqlEvento() {

        return new StringBuilder().append(" \nEvento.ID_EVENTO AS 'Evento.ID_EVENTO',")
                .append(" \nEvento.ID_ASSUNTO AS 'Evento.ID_ASSUNTO',")
                .append(" \nEvento.NOME AS 'Evento.NOME',")
                .append(" \nEvento.DATA_CRIACAO AS 'Evento.DATA_CRIACAO',")
                .append(" \nEvento.FLAG_ATIVO AS 'Evento.FLAG_ATIVO',")
                .append(" \nEvento.FLAG_FINALIZACAO_AUTOMATICA AS 'Evento.FLAG_FINALIZACAO_AUTOMATICA',")
                .append(" \nEvento.EMAIL AS 'Evento.EMAIL'").toString();
   }
   
   public static String getSqlFromEvento() {
       return " TB_EVENTO AS Evento with(nolock) ";
   }

   public static Evento getEventoByResultSet(ResultSet rs) {
        try {
        	
        	if(rs.getInt("Evento.ID_EVENTO") == 0){
        		return null;
        	}
        	
            Evento evento = new Evento();
            evento.setIdEvento(rs.getInt("Evento.ID_EVENTO"));
            evento.setFlagAtivo(rs.getBoolean("Evento.FLAG_ATIVO"));
            evento.setDataCriacao(rs.getTimestamp("Evento.DATA_CRIACAO"));
            evento.setNome(rs.getString("Evento.NOME"));
            evento.setEmail(rs.getString("Evento.EMAIL"));
            evento.setFlagFinalizacaoAutomatica(rs.getBoolean("Evento.FLAG_FINALIZACAO_AUTOMATICA"));
            if(rs.getInt("Evento.ID_ASSUNTO") != 0){
            	 Assunto assunto = new Assunto();
                 assunto.setIdAssunto(rs.getInt("Evento.ID_ASSUNTO"));
                 evento.setAssunto(assunto);
            }
            return evento;
        } catch (SQLException ex) {
            throw new IllegalArgumentException(
                    "Erro ao montar objeto a partir do ResultSet", ex);
        }
    }
   

    @Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((idEvento == null) ? 0 : idEvento.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof Evento)) {
			return false;
		}
		Evento other = (Evento) obj;
		if (idEvento == null) {
			if (other.idEvento != null) {
				return false;
			}
		} else if (!idEvento.equals(other.idEvento)) {
			return false;
		}
		return true;
	}
    
   
}
