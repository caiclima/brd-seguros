package br.com.callink.cad.sau.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import br.com.callink.cad.pojo.entity.IEntity;


@Entity
@Table(name = "TB_EVENTO_CAUSA")
public class EventoCausa implements IEntity<Integer> {

	private static final long serialVersionUID = 4567288166259466151L;

	@Id
	@Column(name = "ID_ENTO_CAUSA")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idEventoCausa;
    
    @Column(name = "FINALIZA_CASO")
    private Boolean finalizaCaso;
    
    @ManyToOne(fetch = FetchType.LAZY)
   	@JoinColumn(name = "ID_EVENTO", referencedColumnName = "ID_EVENTO" , nullable = false)
    private Evento evento;
    
    @ManyToOne(fetch = FetchType.LAZY)
   	@JoinColumn(name = "ID_CAUSA", referencedColumnName = "ID_CAUSA" , nullable = false)
    private Causa causa;

    public Integer getPK() {
        return idEventoCausa;
    }

    public void setPK(Integer pk) {
        this.idEventoCausa = pk;
    }

    public Boolean getFinalizaCaso() {
        return finalizaCaso;
    }

    public void setFinalizaCaso(Boolean finalizaCaso) {
        this.finalizaCaso = finalizaCaso;
    }

    public Causa getCausa() {
        return causa;
    }

    public void setCausa(Causa causa) {
        this.causa = causa;
    }

    public Evento getEvento() {
        return evento;
    }

    public void setEvento(Evento evento) {
        this.evento = evento;
    }

    public Integer getIdEventoCausa() {
        return idEventoCausa;
    }

    public void setIdEventoCausa(Integer idEventoCausa) {
        this.idEventoCausa = idEventoCausa;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final EventoCausa other = (EventoCausa) obj;
        if (this.idEventoCausa == null || !this.idEventoCausa.equals(other.idEventoCausa)) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 23 * hash + (this.idEventoCausa != null ? this.idEventoCausa.hashCode() : 0);
        return hash;
    }
    
    public static String getSqlEventoCausa() {

        return new StringBuilder()
        	.append(" \nEventoCausa.ID_EVENTO AS 'EventoCausa.ID_EVENTO',")
		    .append(" \nEventoCausa.ID_CAUSA AS 'EventoCausa.ID_CAUSA',")
		    .append(" \nEventoCausa.ID_ENTO_CAUSA AS 'EventoCausa.ID_ENTO_CAUSA',")
		    .append(" \nEventoCausa.FINALIZA_CASO AS 'EventoCausa.FINALIZA_CASO'")
		    .toString();
    }

    public static String getSqlFromEventoCausa() {
        return " TB_EVENTO_CAUSA AS EventoCausa with(nolock) ";
    }
    
    
    public static EventoCausa getEventoCausaByResultSet(
            ResultSet resultSet) {
        try {
        	
        	if(resultSet.getInt("EventoCausa.ID_ENTO_CAUSA") == 0){
        		return null;
        	}
        	
        	EventoCausa eventoCausa = new EventoCausa();
        	eventoCausa.setIdEventoCausa(resultSet.getInt("EventoCausa.ID_ENTO_CAUSA"));
        	eventoCausa.setCausa(resultSet.getInt("EventoCausa.ID_CAUSA") == 0 ? null : new Causa(resultSet.getInt("EventoCausa.ID_CAUSA")));
        	eventoCausa.setEvento(resultSet.getInt("EventoCausa.ID_EVENTO") == 0 ? null : new Evento(resultSet.getInt("EventoCausa.ID_EVENTO")));
        	eventoCausa.setFinalizaCaso(resultSet.getBoolean("EventoCausa.FINALIZA_CASO"));
        	
        	return eventoCausa;
        } catch (SQLException e) {
            throw new IllegalArgumentException(
                    "Erro ao montar objeto a partir do ResultSet", e);
        }
    }
    
}
