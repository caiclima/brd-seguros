package br.com.callink.cad.sau.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;


/**
 *
 * @author brunomt
 */
@Entity
@Table(name = "TB_EVOLUCAO_ATENDIMENTO")
public class EvolucaoAtendimento implements IEntity<Integer> {
    
	private static final long serialVersionUID = 4832873955587468873L;

	@Id
	@Column(name = "id_evolucao_atendimento")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idEvolucaoAtendimento;
    
	@Column(name = "data_relatorio")
	@Temporal(TemporalType.TIMESTAMP)
    private Date dataRelatorio;
    
	@Column(name = "tipo_maifestacao" , length = 200)
    private String tipoManifestacao;
    
	@Column(name = "total_entrantes")
    private Integer totalEntrantes;
    
	@Column(name = "total_reabertos")
    private Integer totalReabertos;
    
	@Column(name = "total_reabertos_entrantes")
    private Integer totalReabertosEntrantes;
    
	@Column(name = "pendente_dentro_prazo")
    private Integer pendenteDentroPrazo;
    
	@Column(name = "pendente_fora_prazo")
    private Integer pendenteForaPrazo;
    
	@Column(name = "pendente_fora_prazo_percentual")
    private Double pendenteForaPrazoPercentual;
    
	@Column(name = "pendente_total")
    private Integer pendenteTotal;
    
	@Column(name = "fechado_dentro_prazo")
    private Integer fechadoDentroPrazo;
    
	@Column(name = "fechado_fora_prazo")
    private Integer fechadoForaPrazo;
    
	@Column(name = "fechado_fora_prazo_percentual")
    private Double fechadoForaPrazoPercentual;
    
	@Column(name = "fechado_total")
    private Integer fechadoTotal;
    
	@Column(name = "saldo_percentual")
    private Double saldoPercentual;
    
	@Column(name = "saldo_quantidade")
    private Integer saldoQuantidade;

    public EvolucaoAtendimento() {
        totalEntrantes = 0;
        totalReabertos = 0;
        totalReabertosEntrantes = 0;
        pendenteDentroPrazo = 0;
        pendenteForaPrazo = 0;
        pendenteForaPrazoPercentual = 0d;
        pendenteTotal = 0;
        fechadoDentroPrazo = 0;
        fechadoForaPrazo = 0;
        fechadoForaPrazoPercentual = 0d;
        fechadoTotal = 0;
        saldoPercentual = 0d;
        saldoQuantidade = 0;
    }
    
    
    public Date getDataRelatorio() {
        return dataRelatorio == null ? null : new Date(dataRelatorio.getTime());
    }

    public void setDataRelatorio(Date dataRelatorio) {
        this.dataRelatorio = dataRelatorio == null ? null : new Date(dataRelatorio.getTime());
    }

    public Integer getFechadoDentroPrazo() {
        return fechadoDentroPrazo;
    }

    public void setFechadoDentroPrazo(Integer fechadoDentroPrazo) {
        this.fechadoDentroPrazo = fechadoDentroPrazo;
    }

    public Integer getFechadoForaPrazo() {
        return fechadoForaPrazo;
    }

    public void setFechadoForaPrazo(Integer fechadoForaPrazo) {
        this.fechadoForaPrazo = fechadoForaPrazo;
    }

    public Integer getIdEvolucaoAtendimento() {
        return idEvolucaoAtendimento;
    }

    public void setIdEvolucaoAtendimento(Integer idEvolucaoAtendimento) {
        this.idEvolucaoAtendimento = idEvolucaoAtendimento;
    }

    public Integer getPendenteDentroPrazo() {
        return pendenteDentroPrazo;
    }

    public void setPendenteDentroPrazo(Integer pendenteDentroPrazo) {
        this.pendenteDentroPrazo = pendenteDentroPrazo;
    }

    public Integer getPendenteForaPrazo() {
        return pendenteForaPrazo;
    }

    public void setPendenteForaPrazo(Integer pendenteForaPrazo) {
        this.pendenteForaPrazo = pendenteForaPrazo;
    }

    public Integer getPendenteTotal() {
        return pendenteTotal;
    }

    public void setPendenteTotal(Integer pendenteTotal) {
        this.pendenteTotal = pendenteTotal;
    }

    public Double getSaldoPercentual() {
        return saldoPercentual;
    }

    public void setSaldoPercentual(Double saldoPercentual) {
        this.saldoPercentual = saldoPercentual;
    }

    public Integer getSaldoQuantidade() {
        return saldoQuantidade;
    }

    public void setSaldoQuantidade(Integer saldoQuantidade) {
        this.saldoQuantidade = saldoQuantidade;
    }

    public String getTipoManifestacao() {
        return tipoManifestacao;
    }

    public void setTipoManifestacao(String tipoManifestacao) {
        this.tipoManifestacao = tipoManifestacao;
    }

    public Integer getTotalEntrantes() {
        return totalEntrantes;
    }

    public void setTotalEntrantes(Integer totalEntrantes) {
        this.totalEntrantes = totalEntrantes;
    }
    
    public Double getPendenteForaPrazoPercentual() {
        return pendenteForaPrazoPercentual;
    }

    public void setPendenteForaPrazoPercentual(Double pendenteForaPrazoPercentual) {
        this.pendenteForaPrazoPercentual = pendenteForaPrazoPercentual;
    }

    public Integer getFechadoTotal() {
        return fechadoTotal;
    }

    public void setFechadoTotal(Integer fechadoTotal) {
        this.fechadoTotal = fechadoTotal;
    }

    public Integer getTotalReabertos() {
        return totalReabertos;
    }

    public void setTotalReabertos(Integer totalReabertos) {
        this.totalReabertos = totalReabertos;
    }

    public Integer getTotalReabertosEntrantes() {
        return totalReabertosEntrantes;
    }

    public void setTotalReabertosEntrantes(Integer totalReabertosEntrantes) {
        this.totalReabertosEntrantes = totalReabertosEntrantes;
    }
    
    public Integer getPK() {
        return idEvolucaoAtendimento;
    }

    public void setPK(Integer pk) {
        this.idEvolucaoAtendimento = pk;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final EvolucaoAtendimento other = (EvolucaoAtendimento) obj;
        if (this.idEvolucaoAtendimento == null || !this.idEvolucaoAtendimento.equals(other.idEvolucaoAtendimento)) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        return 5;
    }

    @Override
    public String toString() {
        return "EvolucaoAtendimento{" + "dataRelatorio=" + dataRelatorio + '}';
    }

    public void addTotalEntrantes() {
        if (totalEntrantes == null) {
            totalEntrantes = 1;
        } else {
            totalEntrantes++;
            totalReabertosEntrantes++;
        }
    }
    
    public void addTotalReabertos() {
        if (totalReabertos == null) {
            totalReabertos = 1;
        } else {
            totalReabertos++;
            totalReabertosEntrantes++;
        }
    }

    public void addPendenteForaPrazo() {
        if (pendenteForaPrazo == null) {
            pendenteForaPrazo = 1;
        } else {
            pendenteForaPrazo++;
        }
        addPendenteTotal();
    }

    public void addPendenteDentroPrazo() {
        if (pendenteDentroPrazo == null) {
            pendenteDentroPrazo = 1;
        } else {
            pendenteDentroPrazo++;
            calculaPercentualForaPrazo();
        }
        addPendenteTotal();
    }

    private void addPendenteTotal() {
        if (pendenteTotal == null) {
            pendenteTotal = 1;
        } else {
            pendenteTotal++;
        }
        calculaPercentualForaPrazo();
    }

    private void calculaPercentualForaPrazo() {
        if (pendenteForaPrazo == null) {
            pendenteForaPrazo = 0;
        }
        if (pendenteDentroPrazo == null) {
            pendenteDentroPrazo = 0;
        }
        if (pendenteTotal == null || pendenteTotal.equals(Integer.valueOf(0))) {
            pendenteTotal = 0;
            pendenteForaPrazoPercentual = 0d;
            return;
        }
//        DecimalFormat df = new DecimalFormat("###.##");
//        String valorPercentual = df.format((pendenteForaPrazo.doubleValue() * 100) / pendenteTotal);
        pendenteForaPrazoPercentual = (pendenteForaPrazo.doubleValue() * 100) / pendenteTotal;
    }

    public void addFechadoForaPrazo() {
        if (fechadoForaPrazo == null) {
            fechadoForaPrazo = 1;
        } else {
            fechadoForaPrazo++;
        }
        addFechadoTotal();
    }

    public void addFechadoDentroPrazo() {
        if (fechadoDentroPrazo == null) {
            fechadoDentroPrazo = 1;
        } else {
            fechadoDentroPrazo++;
            calculaFechadoPercentualForaPrazo();
        }
        addFechadoTotal();
    }

    private void addFechadoTotal() {
        if (fechadoTotal == null) {
            fechadoTotal = 1;
        } else {
            fechadoTotal++;
        }
        calculaFechadoPercentualForaPrazo();
    }
    
    private void calculaFechadoPercentualForaPrazo() {
        if (fechadoForaPrazo == null) {
        	fechadoForaPrazo = 0;
        }
        if (fechadoDentroPrazo == null) {
        	fechadoDentroPrazo = 0;
        }
        if (fechadoTotal == null || fechadoTotal.equals(Integer.valueOf(0))) {
        	fechadoTotal = 0;
            fechadoForaPrazoPercentual = (0d);
            return;
        }
//        DecimalFormat df = new DecimalFormat("###.##");
//        String valorPercentual = df.format((pendenteForaPrazo.doubleValue() * 100) / pendenteTotal);
        fechadoForaPrazoPercentual = (fechadoForaPrazo.doubleValue() * 100) / fechadoTotal;
    }

    public void calculaSaldo() {
        if (fechadoTotal == null) {
            fechadoTotal = 0;
        }
        if (totalEntrantes == null) {
            totalEntrantes = 0;
        }
        
        saldoQuantidade = fechadoTotal - totalEntrantes;
        if (totalEntrantes.equals(Integer.valueOf(0))) {
            saldoPercentual = 0d;
        } else {
//            DecimalFormat df = new DecimalFormat("###.##");
//            String valorPercentual = df.format((saldoQuantidade.doubleValue() * 100) / totalEntrantes);
            saldoPercentual = (saldoQuantidade.doubleValue() * 100) / totalEntrantes;
        }
        
    }
    
    public void preencheEvolucaoAtendimentoTotal(EvolucaoAtendimento evoAtendimento) {
        this.fechadoDentroPrazo = this.fechadoDentroPrazo + evoAtendimento.getFechadoDentroPrazo();
        this.fechadoForaPrazo = this.fechadoForaPrazo + evoAtendimento.getFechadoForaPrazo();
        this.fechadoTotal = this.fechadoTotal + evoAtendimento.getFechadoTotal();
        this.pendenteDentroPrazo = this.pendenteDentroPrazo + evoAtendimento.getPendenteDentroPrazo();
        this.pendenteForaPrazo = this.pendenteForaPrazo + evoAtendimento.getPendenteForaPrazo();
        this.pendenteTotal = this.pendenteTotal + evoAtendimento.getPendenteTotal();
        this.totalReabertos = this.totalReabertos + (evoAtendimento.getTotalReabertos() != null ? evoAtendimento.getTotalReabertos() : 0) ;
        this.totalReabertosEntrantes = this.totalReabertosEntrantes + (evoAtendimento.getTotalReabertosEntrantes() != null ? evoAtendimento.getTotalReabertosEntrantes() : 0);
        calculaPercentualForaPrazo();
        calculaFechadoPercentualForaPrazo();
        this.totalEntrantes = this.totalEntrantes + evoAtendimento.getTotalEntrantes();
        calculaSaldo();
    }


	public Double getFechadoForaPrazoPercentual() {
		return fechadoForaPrazoPercentual;
	}


	public void setFechadoForaPrazoPercentual(Double fechadoForaPrazoPercentual) {
		this.fechadoForaPrazoPercentual = fechadoForaPrazoPercentual;
	}
	
	
	public static String getSqlCamposEvolucaoAtendimento() {

        return new StringBuilder()
                
        		.append(" \nEvolucaoAtendimento.id_evolucao_atendimento AS 'EvolucaoAtendimento.id_evolucao_atendimento', ")
                .append(" \nEvolucaoAtendimento.data_relatorio AS 'EvolucaoAtendimento.data_relatorio', ")
                .append(" \nEvolucaoAtendimento.tipo_maifestacao AS 'EvolucaoAtendimento.tipo_maifestacao', ")
                .append(" \nEvolucaoAtendimento.total_entrantes AS 'EvolucaoAtendimento.total_entrantes', ")
                .append(" \nEvolucaoAtendimento.total_reabertos AS 'EvolucaoAtendimento.total_reabertos', ")
                .append(" \nEvolucaoAtendimento.total_reabertos_entrantes AS 'EvolucaoAtendimento.total_reabertos_entrantes', ")
                .append(" \nEvolucaoAtendimento.pendente_dentro_prazo AS 'EvolucaoAtendimento.pendente_dentro_prazo', ")
                .append(" \nEvolucaoAtendimento.pendente_fora_prazo AS 'EvolucaoAtendimento.pendente_fora_prazo', ")
                .append(" \nEvolucaoAtendimento.pendente_fora_prazo_percentual AS 'EvolucaoAtendimento.pendente_fora_prazo_percentual', ")
                .append(" \nEvolucaoAtendimento.pendente_total AS 'EvolucaoAtendimento.pendente_total', ")
                .append(" \nEvolucaoAtendimento.fechado_dentro_prazo AS 'EvolucaoAtendimento.fechado_dentro_prazo', ")
                .append(" \nEvolucaoAtendimento.fechado_fora_prazo AS 'EvolucaoAtendimento.fechado_fora_prazo', ")
                .append(" \nEvolucaoAtendimento.fechado_fora_prazo_percentual AS 'EvolucaoAtendimento.fechado_fora_prazo_percentual', ")
                .append(" \nEvolucaoAtendimento.fechado_total AS 'EvolucaoAtendimento.fechado_total', ")
                .append(" \nEvolucaoAtendimento.saldo_percentual AS 'EvolucaoAtendimento.saldo_percentual', ")
                .append(" \nEvolucaoAtendimento.saldo_quantidade AS 'EvolucaoAtendimento.saldo_quantidade' ")
                .toString();
    }

    public static String getSqlFromEvolucaoAtendimento() {
        return " TB_EVOLUCAO_ATENDIMENTO  AS EvolucaoAtendimento with(nolock) ";
    }

    public static EvolucaoAtendimento getEvolucaoAtendimentoByResultSet(
            ResultSet resultSet) {
        try {
        	
        	if(resultSet.getInt("EvolucaoAtendimento.id_evolucao_atendimento") == 0){
        		return null;
        	}
        	
        	EvolucaoAtendimento evolucaoAtendimento = new EvolucaoAtendimento();
        	evolucaoAtendimento.setIdEvolucaoAtendimento(resultSet.getInt("EvolucaoAtendimento.id_evolucao_atendimento"));
        	evolucaoAtendimento.setDataRelatorio(resultSet.getTimestamp("EvolucaoAtendimento.data_relatorio"));
        	evolucaoAtendimento.setTipoManifestacao(resultSet.getString("EvolucaoAtendimento.tipo_maifestacao"));
        	evolucaoAtendimento.setTotalEntrantes(resultSet.getInt("EvolucaoAtendimento.total_entrantes"));
        	evolucaoAtendimento.setTotalReabertos(resultSet.getInt("EvolucaoAtendimento.total_reabertos"));
        	evolucaoAtendimento.setTotalReabertosEntrantes(resultSet.getInt("EvolucaoAtendimento.total_reabertos_entrantes"));
        	evolucaoAtendimento.setPendenteDentroPrazo(resultSet.getInt("EvolucaoAtendimento.pendente_dentro_prazo"));
        	evolucaoAtendimento.setPendenteForaPrazo(resultSet.getInt("EvolucaoAtendimento.pendente_fora_prazo"));
        	evolucaoAtendimento.setPendenteForaPrazoPercentual(resultSet.getDouble("EvolucaoAtendimento.pendente_fora_prazo_percentual"));
        	evolucaoAtendimento.setPendenteTotal(resultSet.getInt("EvolucaoAtendimento.pendente_total"));
        	evolucaoAtendimento.setFechadoDentroPrazo(resultSet.getInt("EvolucaoAtendimento.fechado_dentro_prazo"));
        	evolucaoAtendimento.setFechadoForaPrazo(resultSet.getInt("EvolucaoAtendimento.fechado_fora_prazo"));
        	evolucaoAtendimento.setFechadoForaPrazoPercentual(resultSet.getDouble("EvolucaoAtendimento.fechado_fora_prazo_percentual"));
        	evolucaoAtendimento.setFechadoTotal(resultSet.getInt("EvolucaoAtendimento.fechado_total"));
        	evolucaoAtendimento.setSaldoPercentual(resultSet.getDouble("EvolucaoAtendimento.saldo_percentual"));
        	evolucaoAtendimento.setSaldoQuantidade(resultSet.getInt("EvolucaoAtendimento.saldo_quantidade"));
        	
        	return evolucaoAtendimento;
        	
        } catch (SQLException e) {
            throw new IllegalArgumentException(
                    "Erro ao montar objeto a partir do ResultSet", e);
        }
    }
	
	

}
