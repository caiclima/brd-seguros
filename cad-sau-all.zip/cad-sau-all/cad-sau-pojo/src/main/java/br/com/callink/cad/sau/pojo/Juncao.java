package br.com.callink.cad.sau.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;


@Entity
@Table(name = "TB_JUNCAO")
public class Juncao implements IEntity<Integer> {
	
	private static final long serialVersionUID = -4765754624683794896L;
	
	@Id
	@Column(name = "ID_JUNCAO")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer idJuncao;
	
	@Column(name = "NOME", length = 500)
	private String nome;
	
	@Column(name = "DATA_CRIACAO")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataCriacao;
	
	@Column(name = "FLAG_ATIVO")
	private Boolean flagAtivo;

	public Juncao() {

	}

	public Juncao(Integer idJuncao) {
		this.idJuncao = idJuncao;
	}

	public Integer getPK() {
		return idJuncao;
	}

	public void setPK(Integer pk) {
		idJuncao = pk;
	}

	public final String getNome() {
		return nome;
	}

	public final void setNome(String nome) {
		this.nome = nome;
	}

	public final Date getDataCriacao() {
		return dataCriacao == null ? null : new Date(dataCriacao.getTime());
	}

	public final void setDataCriacao(Date dataCriacao) {
		this.dataCriacao = dataCriacao == null ? null : new Date(dataCriacao.getTime());
	}

	public final Boolean getFlagAtivo() {
		return flagAtivo;
	}

	public final void setFlagAtivo(Boolean flagAtivo) {
		this.flagAtivo = flagAtivo;
	}

	@Override
	public String toString() {
		return this.getNome();
	}

	/**
	 * @return the idJuncao
	 */
	public final Integer getIdJuncao() {
		return idJuncao;
	}

	/**
	 * @param idJuncao
	 *            the idJuncao to set
	 */
	public final void setIdJuncao(Integer idJuncao) {
		this.idJuncao = idJuncao;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((idJuncao == null) ? 0 : idJuncao.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof Juncao)) {
			return false;
		}
		Juncao other = (Juncao) obj;
		if (idJuncao == null) {
			if (other.idJuncao != null) {
				return false;
			}
		} else if (!idJuncao.equals(other.idJuncao)) {
			return false;
		}
		return true;
	}
	
	public static String getSqlCamposJuncao() {

        return new StringBuilder()
                .append(" \nJuncao.ID_JUNCAO AS 'Juncao.ID_JUNCAO', ")
                .append(" \nJuncao.NOME AS 'Juncao.NOME', ")
                .append(" \nJuncao.DATA_CRIACAO AS 'Juncao.DATA_CRIACAO', ")
                .append(" \nJuncao.FLAG_ATIVO AS 'Juncao.FLAG_ATIVO' ")
                .toString();
    }

    public static String getSqlFromJuncao() {
        return " TB_JUNCAO  AS Juncao with(nolock) ";
    }

    public static Juncao getJuncaoByResultSet(
            ResultSet resultSet) {
        try {
        	
        	if(resultSet.getInt("Juncao.ID_JUNCAO") == 0){
        		return null;
        	}
        	
        	Juncao juncao = new Juncao();
        	juncao.setIdJuncao(resultSet.getInt("Juncao.ID_JUNCAO"));
        	juncao.setNome(resultSet.getString("Juncao.NOME"));
        	juncao.setDataCriacao(resultSet.getTimestamp("Juncao.DATA_CRIACAO"));
        	juncao.setFlagAtivo(resultSet.getBoolean("Juncao.FLAG_ATIVO"));
        	
        	return juncao;
        } catch (SQLException e) {
            throw new IllegalArgumentException(
                    "Erro ao montar objeto a partir do ResultSet", e);
        }
    }
	

}
