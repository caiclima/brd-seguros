/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.sau.pojo;



import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;

/**
 * 
 * @author ubuntu
 */
@Entity
@Table(name = "TB_OUTRA_AREA")
public class OutraArea implements IEntity<Integer> {

	private static final long serialVersionUID = 753300827077970219L;

	@Id
	@Column(name = "ID_OUTRA_AREA")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer idOutraArea;
	
	@Column(name = "NOME" , length = 200)
	private String nome; 
	
	@Column(name = "DATA_CRIACAO")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataCriacao;
	
	@Column(name = "FLAG_ATIVO")
	private Boolean flagAtivo;

	private transient Boolean selecionado;
		
	public OutraArea() {
	}

	public OutraArea(Integer idOutraArea) {
		this.idOutraArea = idOutraArea;
	}
	
	public Integer getPK() {
		return this.idOutraArea;
	}

	public void setPK(Integer pk) {
		this.idOutraArea = pk;
	}

	public Date getDataCriacao() {
		return dataCriacao == null ? null : new Date(dataCriacao.getTime());
	}

	public void setDataCriacao(Date dataCriacao) {
		this.dataCriacao = dataCriacao == null ? null : new Date(dataCriacao.getTime());
	}

	public Boolean getFlagAtivo() {
		return flagAtivo;
	}

	public void setFlagAtivo(Boolean flagAtivo) {
		this.flagAtivo = flagAtivo;
	}

	public Integer getIdOutraArea() {
		return idOutraArea;
	}

	public void setIdOutraArea(Integer idOutraArea) {
		this.idOutraArea = idOutraArea;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	@Override
	public String toString() {
		return this.getNome();
	}
	
	public Boolean getSelecionado() {
		return selecionado;
	}

	public void setSelecionado(Boolean selecionado) {
		this.selecionado = selecionado;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((idOutraArea == null) ? 0 : idOutraArea.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof OutraArea)) {
			return false;
		}
		OutraArea other = (OutraArea) obj;
		if (idOutraArea == null) {
			if (other.idOutraArea != null) {
				return false;
			}
		} else if (!idOutraArea.equals(other.idOutraArea)) {
			return false;
		}
		return true;
	}

	public static String getSqlOutraArea() {
        return new StringBuilder()
            .append(" \nOutraArea.ID_OUTRA_AREA AS 'OutraArea.ID_OUTRA_AREA', ")
            .append(" \nOutraArea.NOME AS 'OutraArea.NOME', ")
            .append(" \nOutraArea.DATA_CRIACAO AS 'OutraArea.DATA_CRIACAO', ")
            .append(" \nOutraArea.FLAG_ATIVO AS 'OutraArea.FLAG_ATIVO' ").toString();
    }
   
    public static String getSqlFromOutraArea() {
        return " TB_OUTRA_AREA AS OutraArea with(nolock) ";
    }
    
    public static OutraArea getOutraAreaByResultSet(ResultSet rs) {
        try {
        	
        	if(rs.getInt("OutraArea.ID_OUTRA_AREA") == 0){
        		return null;
        	}
        	
        	OutraArea outraArea = new OutraArea();
        	outraArea.setIdOutraArea(rs.getInt("OutraArea.ID_OUTRA_AREA"));
        	outraArea.setFlagAtivo(rs.getBoolean("OutraArea.FLAG_ATIVO"));
        	outraArea.setDataCriacao(rs.getTimestamp("OutraArea.DATA_CRIACAO"));
        	outraArea.setNome(rs.getString("OutraArea.NOME"));
            return outraArea;
        } catch (SQLException ex) {
            throw new IllegalArgumentException("Erro ao montar objeto a partir do ResultSet", ex);
        }
    }
	
}
