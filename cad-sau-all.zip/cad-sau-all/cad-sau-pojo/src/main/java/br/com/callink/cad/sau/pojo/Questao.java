package br.com.callink.cad.sau.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import br.com.callink.cad.pojo.entity.IEntity;
import br.com.callink.cad.sau.enun.OperadorApresentacao;
import br.com.callink.cad.sau.enun.TipoConteudoResposta;
import br.com.callink.cad.sau.enun.TipoResposta;

@Entity
@Table(name = "TB_QUESTAO")
public class Questao implements IEntity<Integer> {
    
    
	private static final long serialVersionUID = -981747041135618599L;

	@Id
	@Column(name = "id_questao")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idQuestao;
    
    @ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_questao_pai", referencedColumnName = "id_questao")
    private Questao questaoPai;
    
    @ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_questionario", referencedColumnName = "id_questionario" , nullable = false)
    private Questionario questionario;
    
    @Column(name = "descricao" , length = 1000)
    private String descricao;
    
    @Column(name = "tipo_resposta" , length = 200)
    private String tipoResposta;
    
    @Column(name = "tipo_conteudo" , length = 200)
    private String tipoConteudo;
    
    @Column(name = "possiveis_respostas" , length = 2000)
    private String possiveisRespostas;
    
    @Column(name = "resposta_padrao", length = 500)
    private String respostaPadrao;
    
    @Column(name = "ordem")
    private Integer ordem;
    
    @Column(name = "requerida")
    private Boolean requerida;
    
    @Column(name = "mensagem_requerida" , length = 500)
    private String mensagemRequerida;
    
    @Column(name = "resposta_apresentacao" , length = 500)
    private String respostaApresentacao;
    
    @Column(name = "operador_apresentacao" , length = 200)
    private String operadorApresentacao;
    
    @Column(name = "flag_ativo")
    private Boolean flagAtivo;
    
    private transient TipoResposta tipoRespsta;
    private transient OperadorApresentacao operadorAprsentacao;
    private transient TipoConteudoResposta tipoConteudoResposta;
    private transient Boolean isEditavel;
    private transient boolean inserirResposta;
    private transient Boolean rendered = Boolean.FALSE;
    private transient List<String> respostas;
    
    public Questao() {
	}
    
    public Questao(Integer idQuestao) {
    	this.idQuestao = idQuestao;
	}
    
    public Integer getPK() {
        return idQuestao;
    }
    
    public void setPK(Integer pk) {
        this.idQuestao = pk;
    }
    
    public TipoConteudoResposta getTipoConteudoResposta() {
        return tipoConteudoResposta;
    }
    
    public void setTipoConteudoResposta(TipoConteudoResposta tipoConteudoResposta) {
        this.tipoConteudo = tipoConteudoResposta != null ? tipoConteudoResposta.name() : null;
        this.tipoConteudoResposta = tipoConteudoResposta;
    }
    
    public TipoResposta getTipoRespsta() {
        return tipoRespsta;
    }
    
    public void setTipoRespsta(TipoResposta tipoRespsta) {
        this.tipoResposta = tipoRespsta != null ? tipoRespsta.name() : null;
        this.tipoRespsta = tipoRespsta;
    }
    
    public OperadorApresentacao getOperadorAprsentacao() {
        return operadorAprsentacao;
    }
    
    public void setOperadorAprsentacao(OperadorApresentacao operadorAprsentacao) {
        this.operadorApresentacao = operadorAprsentacao != null ? operadorAprsentacao.name() : null;
        this.operadorAprsentacao = operadorAprsentacao;
    }
    
    public List<String> getRespostas() {
        if (respostas == null && possiveisRespostas != null) {
            respostas = new ArrayList<String>();
            respostas.addAll(Arrays.asList(possiveisRespostas.split(";")));
        }
        return respostas;
    }
    
    public void setRespostas(List<String> respostas) {
        this.respostas = respostas;
    }
    
    public boolean isCheckbox() {
        return this.tipoRespsta.equals(TipoResposta.MULTIPLA_ESCOLHA) && getRendered();
    }
    
    public boolean isOneRadio() {
        return this.tipoRespsta.equals(TipoResposta.UNICA_ESCOLHA) && getRendered() && getRespostas().size() < 4;
    }
    
    public boolean isOneMenu() {
        return this.tipoRespsta.equals(TipoResposta.UNICA_ESCOLHA) && getRendered() && getRespostas().size() > 3;
    }
    
    public boolean isTextarea() {
        return this.tipoRespsta.equals(TipoResposta.DESCRITIVA_MULTLINHA) && getRendered();
    }
    
    public boolean isCalendar() {
        return this.tipoRespsta.equals(TipoResposta.DESCRITIVA_LINHAUNICA) && getRendered() && this.tipoConteudoResposta.equals(TipoConteudoResposta.DATA);
    }
    
    public boolean isText() {
        return this.tipoRespsta.equals(TipoResposta.DESCRITIVA_LINHAUNICA) && getRendered() && !isCalendar();
    }
    
    public Boolean getIsEditavel() {
        return isEditavel;
    }
    
    public void setIsEditavel(Boolean isEditavel) {
        this.isEditavel = isEditavel;
    }

    /**
     * @return the idQuestao
     */
    public final Integer getIdQuestao() {
        return idQuestao;
    }

    /**
     * @param idQuestao the idQuestao to set
     */
    public final void setIdQuestao(Integer idQuestao) {
        this.idQuestao = idQuestao;
    }

    /**
     * @return the questaoPai
     */
    public final Questao getQuestaoPai() {
        return questaoPai;
    }

    /**
     * @param questaoPai the questaoPai to set
     */
    public final void setQuestaoPai(Questao questaoPai) {
        this.questaoPai = questaoPai;
    }

    /**
     * @return the questionario
     */
    public final Questionario getQuestionario() {
        return questionario;
    }

    /**
     * @param questionario the questionario to set
     */
    public final void setQuestionario(Questionario questionario) {
        this.questionario = questionario;
    }

    /**
     * @return the descricao
     */
    public final String getDescricao() {
        return descricao;
    }

    /**
     * @param descricao the descricao to set
     */
    public final void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    /**
     * @return the tipoResposta
     */
    public final String getTipoResposta() {
        return tipoResposta;
    }

    /**
     * @param tipoResposta the tipoResposta to set
     */
    public final void setTipoResposta(String tipoResposta) {
        this.tipoResposta = tipoResposta;
    }

    /**
     * @return the tipoConteudo
     */
    public final String getTipoConteudo() {
        return tipoConteudo;
    }

    /**
     * @param tipoConteudo the tipoConteudo to set
     */
    public final void setTipoConteudo(String tipoConteudo) {
        this.tipoConteudo = tipoConteudo;
    }

    /**
     * @return the possiveisRespostas
     */
    public final String getPossiveisRespostas() {
        return possiveisRespostas;
    }

    /**
     * @param possiveisRespostas the possiveisRespostas to set
     */
    public final void setPossiveisRespostas(String possiveisRespostas) {
        this.possiveisRespostas = possiveisRespostas;
    }

    /**
     * @return the respostaPadrao
     */
    public final String getRespostaPadrao() {
        return respostaPadrao;
    }

    /**
     * @param respostaPadrao the respostaPadrao to set
     */
    public final void setRespostaPadrao(String respostaPadrao) {
        this.respostaPadrao = respostaPadrao;
    }

    /**
     * @return the ordem
     */
    public final Integer getOrdem() {
        return ordem;
    }

    /**
     * @param ordem the ordem to set
     */
    public final void setOrdem(Integer ordem) {
        this.ordem = ordem;
    }

    /**
     * @return the requerida
     */
    public final Boolean getRequerida() {
        return requerida;
    }

    /**
     * @param requerida the requerida to set
     */
    public final void setRequerida(Boolean requerida) {
        this.requerida = requerida;
    }

    /**
     * @return the mensagemRequerida
     */
    public final String getMensagemRequerida() {
        return mensagemRequerida;
    }

    /**
     * @param mensagemRequerida the mensagemRequerida to set
     */
    public final void setMensagemRequerida(String mensagemRequerida) {
        this.mensagemRequerida = mensagemRequerida;
    }

    /**
     * @return the respostaApresentacao
     */
    public final String getRespostaApresentacao() {
        return respostaApresentacao;
    }

    /**
     * @param respostaApresentacao the respostaApresentacao to set
     */
    public final void setRespostaApresentacao(String respostaApresentacao) {
        this.respostaApresentacao = respostaApresentacao;
    }

    /**
     * @return the operadorApresentacao
     */
    public final String getOperadorApresentacao() {
        return operadorApresentacao;
    }

    /**
     * @param operadorApresentacao the operadorApresentacao to set
     */
    public final void setOperadorApresentacao(String operadorApresentacao) {
        this.operadorApresentacao = operadorApresentacao;
    }

    /**
	 * @return the inserirResposta
	 */
	public final boolean isInserirResposta() {
		return inserirResposta;
	}

	/**
	 * @param inserirResposta the inserirResposta to set
	 */
	public final void setInserirResposta(boolean inserirResposta) {
		this.inserirResposta = inserirResposta;
	}

	public Boolean getRendered() {
        if(questaoPai == null || questaoPai.getIdQuestao() == null){
            rendered = Boolean.TRUE;
        }
        return rendered;
    }

    public void setRendered(Boolean rendered) {
        this.rendered = rendered;
    }
    
    /**
	 * @return the flagAtivo
	 */
	public final Boolean getFlagAtivo() {
		return flagAtivo;
	}

	/**
	 * @param flagAtivo the flagAtivo to set
	 */
	public final void setFlagAtivo(Boolean flagAtivo) {
		this.flagAtivo = flagAtivo;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((idQuestao == null) ? 0 : idQuestao.hashCode());
		return result;
	}
    
    @Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof Questao)) {
			return false;
		}
		Questao other = (Questao) obj;
		if (idQuestao == null) {
			if (other.idQuestao != null) {
				return false;
			}
		} else if (!idQuestao.equals(other.idQuestao)) {
			return false;
		}
		return true;
	}

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return descricao;
    }
    
    
    public static String getSqlCamposQuestao() {

        return new StringBuilder()
                .append(" \nQuestao.id_questao AS 'Questao.id_questao', ")
                .append(" \nQuestao.id_questao_pai AS 'Questao.id_questao_pai', ")
                .append(" \nQuestao.id_questionario AS 'Questao.id_questionario', ")
                .append(" \nQuestao.descricao AS 'Questao.descricao', ")
                .append(" \nQuestao.tipo_resposta AS 'Questao.tipo_resposta', ")
                .append(" \nQuestao.tipo_conteudo AS 'Questao.tipo_conteudo', ")
                .append(" \nQuestao.possiveis_respostas AS 'Questao.possiveis_respostas', ")
                .append(" \nQuestao.resposta_padrao AS 'Questao.resposta_padrao', ")
                .append(" \nQuestao.ordem AS 'Questao.ordem', ")
                .append(" \nQuestao.requerida AS 'Questao.requerida', ")
                .append(" \nQuestao.mensagem_requerida AS 'Questao.mensagem_requerida', ")
                .append(" \nQuestao.resposta_apresentacao AS 'Questao.resposta_apresentacao', ")
                .append(" \nQuestao.operador_apresentacao AS 'Questao.operador_apresentacao', ")
                .append(" \nQuestao.flag_ativo AS 'Questao.flag_ativo' ")
                
                .toString();
    }

    public static String getSqlFromQuestao() {
        return " TB_QUESTAO  AS Questao with(nolock) ";
    }

    public static Questao getQuestaoByResultSet(
            ResultSet resultSet) {
        try {
        	
        	if(resultSet.getInt("Questao.id_questao") == 0){
        		return null;
        	}
        	
        	Questao questao = new Questao();
        	
        	questao.setIdQuestao(resultSet.getInt("Questao.id_questao"));
        	questao.setQuestaoPai(resultSet.getInt("Questao.id_questao_pai") == 0 ? null : new Questao(resultSet.getInt("Questao.id_questao_pai")));
        	questao.setQuestionario(resultSet.getInt("Questao.id_questionario") == 0 ? null : new Questionario(resultSet.getInt("Questao.id_questionario")));
        	questao.setDescricao(resultSet.getString("Questao.descricao"));
        	questao.setTipoResposta(resultSet.getString("Questao.tipo_resposta"));
        	questao.setTipoConteudo(resultSet.getString("Questao.tipo_conteudo"));
        	questao.setPossiveisRespostas(resultSet.getString("Questao.possiveis_respostas"));
        	questao.setRespostaPadrao(resultSet.getString("Questao.resposta_padrao"));
        	questao.setOrdem(resultSet.getInt("Questao.ordem"));
        	questao.setRequerida(resultSet.getBoolean("Questao.requerida"));
        	questao.setMensagemRequerida(resultSet.getString("Questao.mensagem_requerida"));
        	questao.setRespostaApresentacao(resultSet.getString("Questao.resposta_apresentacao"));
        	questao.setOperadorApresentacao(resultSet.getString("Questao.operador_apresentacao"));
        	questao.setFlagAtivo(resultSet.getBoolean("Questao.flag_ativo"));
        	
            return questao;
        } catch (SQLException e) {
            throw new IllegalArgumentException(
                    "Erro ao montar objeto a partir do ResultSet", e);
        }
    }
    
    

}
