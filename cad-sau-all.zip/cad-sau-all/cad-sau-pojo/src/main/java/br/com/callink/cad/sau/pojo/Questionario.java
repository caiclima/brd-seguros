package br.com.callink.cad.sau.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import br.com.callink.cad.pojo.entity.IEntity;


@Entity
@Table(name = "TB_QUESTIONARIO")
public class Questionario implements IEntity<Integer> {
	
	private static final long serialVersionUID = 53525261330185922L;

	@Id
	@Column(name = "id_questionario")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer idQuestionario;
        
	@Column(name="descricao" , length = 2000)
	private String descricao;
        
	@Column(name="flag_ativo")
	private Boolean flagAtivo;
               
	@OneToMany(cascade = {CascadeType.REFRESH, CascadeType.REMOVE}, mappedBy = "questionario", fetch = FetchType.LAZY)
	private List<Questao> questaoList;
	
	public Questionario() {
		// TODO Auto-generated constructor stub
	}
	
	public Questionario(Integer idQuestionario){
		this.idQuestionario = idQuestionario;
	}
	
	
	public Integer getPK() {
		return idQuestionario;
	}
	
	public void setPK(Integer pk) {
		this.idQuestionario = pk;
	}

	/**
	 * @return the idQuestionario
	 */
	public final Integer getIdQuestionario() {
		return idQuestionario;
	}

	/**
	 * @param idQuestionario the idQuestionario to set
	 */
	public final void setIdQuestionario(Integer idQuestionario) {
		this.idQuestionario = idQuestionario;
	}

	/**
	 * @return the descricao
	 */
	public final String getDescricao() {
		return descricao;
	}

	/**
	 * @param descricao the descricao to set
	 */
	public final void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	/**
	 * @return the flagAtivo
	 */
	public final Boolean getFlagAtivo() {
		return flagAtivo;
	}

	/**
	 * @param flagAtivo the flagAtivo to set
	 */
	public final void setFlagAtivo(Boolean flagAtivo) {
		this.flagAtivo = flagAtivo;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((idQuestionario == null) ? 0 : idQuestionario.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj){
			return true;
		}
		if (obj == null){
			return false;
		}
		if (getClass() != obj.getClass()){
			return false;
		}
		Questionario other = (Questionario) obj;
		if (idQuestionario == null) {
			if (other.idQuestionario != null){
				return false;
			}
		} else if (!idQuestionario.equals(other.idQuestionario)){
			return false;
		}
		return true;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return descricao;
	}

	public final List<Questao> getQuestaoList() {
		return questaoList;
	}

	public final void setQuestaoList(List<Questao> questaoList) {
		this.questaoList = questaoList;
	}

	public static String getSqlCamposQuestionario() {

        return new StringBuilder()
                .append(" \nQuestionario.id_questionario AS 'Questionario.id_questionario', ")
                .append(" \nQuestionario.descricao AS 'Questionario.descricao', ")
                .append(" \nQuestionario.flag_ativo AS 'Questionario.flag_ativo' ")
                .toString();
    }

    public static String getSqlFromQuestionario() {
        return " TB_QUESTIONARIO  AS Questionario with(nolock) ";
    }

    public static Questionario getQuestionarioByResultSet(
            ResultSet resultSet) {
        try {
        	
        	if(resultSet.getInt("Questionario.id_questionario") == 0){
        		return null;
        	}
        	
        	Questionario questionario = new Questionario();
        	questionario.setIdQuestionario(resultSet.getInt("Questionario.id_questionario"));
        	questionario.setDescricao(resultSet.getString("Questionario.descricao"));
        	questionario.setFlagAtivo(resultSet.getBoolean("Questionario.flag_ativo"));
        	
            return questionario;
        } catch (SQLException e) {
            throw new IllegalArgumentException(
                    "Erro ao montar objeto a partir do ResultSet", e);
        }
    }
	
	
}
