package br.com.callink.cad.sau.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import br.com.callink.cad.pojo.entity.IEntity;

@Entity
@Table(name = "TB_RESPOSTA")
public class Resposta implements IEntity<Integer> {

	private static final long serialVersionUID = 8187890595973928687L;
        
	@Id
	@Column(name = "id_resposta")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer idResposta;

    @ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_questao", referencedColumnName = "id_questao" , nullable = false)
	private Questao questao;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_resultado_questionario", referencedColumnName = "id_resultado_questionario" , nullable = false)
	private ResultadoQuestionario resultadoQuestionario;
        
	@Column(name = "resposta" , length = 4000)
	private String resposta;
        
	private transient List<String> respostas;

	private transient Date dataResposta;
        
	public Resposta() {
	}

	public Resposta(Integer idResposta) {
		this.idResposta = idResposta;
	} 
        
	public Integer getPK() {
		return idResposta;
	}
	public void setPK(Integer pk) {
		this.idResposta = pk;
	}
	/**
	 * @return the idResposta
	 */
	public final Integer getIdResposta() {
		return idResposta;
	}
	/**
	 * @param idResposta the idResposta to set
	 */
	public final void setIdResposta(Integer idResposta) {
		this.idResposta = idResposta;
	}
	/**
	 * @return the questao
	 */
	public final Questao getQuestao() {
		return questao;
	}
	/**
	 * @param questao the questao to set
	 */
	public final void setQuestao(Questao questao) {
		this.questao = questao;
	}
	/**
	 * @return the resultadoQuestionario
	 */
	public final ResultadoQuestionario getResultadoQuestionario() {
		return resultadoQuestionario;
	}
	/**
	 * @param resultadoQuestionario the resultadoQuestionario to set
	 */
	public final void setResultadoQuestionario(
			ResultadoQuestionario resultadoQuestionario) {
		this.resultadoQuestionario = resultadoQuestionario;
	}
	/**
	 * @return the resposta
	 */
	public final String getResposta() {
		return resposta;
	}
	/**
	 * @param resposta the resposta to set
	 */
	public final void setResposta(String resposta) {
		this.resposta = resposta;
	}

        public List<String> getRespostas() {
            return respostas;
        }

        public void setRespostas(List<String> respostas) {
            this.respostas = respostas;
        }

        public Date getDataResposta() {
            return dataResposta == null ? null : new Date(dataResposta.getTime());
        }

        public void setDataResposta(Date dataResposta) {
            this.dataResposta = dataResposta == null ? null : new Date(dataResposta.getTime());
        }
        
    @Override
    public int hashCode() {
        int hash = 3;
        hash = 13 * hash + (this.idResposta != null ? this.idResposta.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Resposta other = (Resposta) obj;
        if (this.idResposta == null || !this.idResposta.equals(other.idResposta)) {
            return false;
        }
        return true;
    }
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Resposta [resposta=" + resposta + "]";
	}
	
	
	public static String getSqlCamposResposta() {

        return new StringBuilder()
                .append(" \nResposta.id_resposta AS 'Resposta.id_resposta', ")
                .append(" \nResposta.id_questao AS 'Resposta.id_questao', ")
                .append(" \nResposta.id_resultado_questionario AS 'Resposta.id_resultado_questionario', ")
                .append(" \nResposta.resposta AS 'Resposta.resposta' ")
                .toString();
    }

    public static String getSqlFromResposta() {
        return " TB_RESPOSTA  AS Resposta with(nolock) ";
    }

    public static Resposta getRespostaByResultSet(
            ResultSet resultSet) {
        try {
        	
        	if(resultSet.getInt("Resposta.id_resposta") == 0){
        		return null;
        	}
        	
        	Resposta resposta = new Resposta();
        	
        	resposta.setIdResposta(resultSet.getInt("Resposta.id_resposta"));
        	resposta.setQuestao(resultSet.getInt("Resposta.id_questao") == 0 ? null : new Questao(resultSet.getInt("Resposta.id_questao")));
        	resposta.setResultadoQuestionario(resultSet.getInt("Resposta.id_resultado_questionario") == 0 ? null : new ResultadoQuestionario(resultSet.getInt("Resposta.id_resultado_questionario")));
        	resposta.setResposta(resultSet.getString("Resposta.resposta"));
        	
            return resposta;
        } catch (SQLException e) {
            throw new IllegalArgumentException(
                    "Erro ao montar objeto a partir do ResultSet", e);
        }
    }
	

}
