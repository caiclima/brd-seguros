package br.com.callink.cad.sau.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import br.com.callink.cad.pojo.entity.IEntity;

@Entity
@Table(name = "TB_RESPOSTA_CHECKLIST")
public class RespostaChecklist implements IEntity<Integer> {

	private static final long serialVersionUID = 7965773861713652405L;
	        
	@Id
	@Column(name = "id_resposta_checklist")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer idRespostaChecklist;
        
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_check", referencedColumnName = "id_check" , nullable = false)
	private Check check;
        
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_resultado_checklist", referencedColumnName = "id_resultado_checklist" , nullable = false)
	private ResultadoChecklist resultadoChecklist;
        
	@Column(name = "resposta" , length = 50)
	private String resposta;
        
    private transient List<String> respostas;
        
    private transient Date dataResposta;
    
    public RespostaChecklist() {
	}
    
    public RespostaChecklist(Integer idRespostaChecklist){
    	this.idRespostaChecklist = idRespostaChecklist;
    }
    
	public Integer getPK() {
		return idRespostaChecklist;
	}
	public void setPK(Integer pk) {
		this.idRespostaChecklist = pk;
	}
	/**
	 * @return the idResposta
	 */
	public final Integer getIdRespostaChecklist() {
		return idRespostaChecklist;
	}
	/**
	 * @param idResposta the idResposta to set
	 */
	public final void setIdRespostaChecklist(Integer idRespostaChecklist) {
		this.idRespostaChecklist = idRespostaChecklist;
	}
	
	public Check getCheck() {
		return check;
	}
	public void setCheck(Check check) {
		this.check = check;
	}
	public ResultadoChecklist getResultadoChecklist() {
		return resultadoChecklist;
	}
	public void setResultadoChecklist(ResultadoChecklist resultadoChecklist) {
		this.resultadoChecklist = resultadoChecklist;
	}
	/**
	 * @return the resposta
	 */
	public final String getResposta() {
		return resposta;
	}
	/**
	 * @param resposta the resposta to set
	 */
	public final void setResposta(String resposta) {
		this.resposta = resposta;
	}

    public List<String> getRespostas() {
        return respostas;
    }

    public void setRespostas(List<String> respostas) {
        this.respostas = respostas;
    }

    public Date getDataResposta() {
        return dataResposta == null ? null : new Date(dataResposta.getTime());
    }

    public void setDataResposta(Date dataResposta) {
        this.dataResposta = dataResposta == null ? null : new Date(dataResposta.getTime());
    }
        
    @Override
    public int hashCode() {
        int hash = 3;
        hash = 13 * hash + (this.idRespostaChecklist != null ? this.idRespostaChecklist.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final RespostaChecklist other = (RespostaChecklist) obj;
        if (this.idRespostaChecklist == null || !this.idRespostaChecklist.equals(other.idRespostaChecklist)) {
            return false;
        }
        return true;
    }
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Resposta [resposta=" + resposta + "]";
	}
	
	public static String getSqlCamposRespostaChecklist() {

        return new StringBuilder()
                .append(" \nRespostaChecklist.id_resposta_checklist AS 'RespostaChecklist.id_resposta_checklist', ")
                .append(" \nRespostaChecklist.id_check AS 'RespostaChecklist.id_check', ")
                .append(" \nRespostaChecklist.resultadoChecklist AS 'RespostaChecklist.id_resultado_checklist', ")
                .append(" \nRespostaChecklist.resposta AS 'RespostaChecklist.resposta' ")
                .toString();
    }

    public static String getSqlFromRespostaChecklist() {
        return " TB_RESPOSTA_CHECKLIST  AS RespostaChecklist with(nolock) ";
    }

    public static RespostaChecklist getRespostaChecklistByResultSet(
            ResultSet resultSet) {
        try {
        	
        	if(resultSet.getInt("RespostaChecklist.id_resposta_checklist") == 0){
        		return null;
        	}
        	
        	RespostaChecklist respostaChecklist = new RespostaChecklist();
        	
        	respostaChecklist.setIdRespostaChecklist(resultSet.getInt("RespostaChecklist.id_resposta_checklist"));
        	respostaChecklist.setCheck(resultSet.getInt("RespostaChecklist.id_check") == 0 ? null : new Check(resultSet.getInt("RespostaChecklist.id_check")));
        	respostaChecklist.setResultadoChecklist(resultSet.getInt("RespostaChecklist.id_resultado_checklist") == 0 ? null : new ResultadoChecklist(resultSet.getInt("RespostaChecklist.id_resultado_checklist")));
        	respostaChecklist.setResposta(resultSet.getString("RespostaChecklist.resposta"));
            
            return respostaChecklist;
        } catch (SQLException e) {
            throw new IllegalArgumentException(
                    "Erro ao montar objeto a partir do ResultSet", e);
        }
    }

}
