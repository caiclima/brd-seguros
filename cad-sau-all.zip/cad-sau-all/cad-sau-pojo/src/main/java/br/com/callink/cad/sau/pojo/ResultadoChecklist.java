package br.com.callink.cad.sau.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.pojo.entity.IEntity;



@Entity
@Table(name = "TB_RESULTADO_CHECKLIST")
public class ResultadoChecklist implements IEntity<Integer> {
	
	private static final long serialVersionUID = -4343649982272675226L;

	@Id
	@Column(name = "id_resultado_checklist")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer idResultadoChecklist;
	
	@Column(name = "login", nullable = false, length = 50)
	private String login;
	
	@Column(name = "tipo_atendimento", length = 100)
	private String tipoAtendimento;
	
	@Column(name = "id_externo")
	private Integer idExterno;
	
	@Column(name = "data_resposta")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataResposta;
	
	@OneToMany(cascade = {CascadeType.REFRESH, CascadeType.REMOVE}, mappedBy = "resultadoChecklist", fetch = FetchType.LAZY)
	private List<RespostaChecklist> respostaList;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_caso_sau", referencedColumnName = "id_caso_sau" , nullable = false)
    private CasoSau casoSau;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_evento", referencedColumnName = "id_evento" , nullable = false)
    private Evento evento;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_acao", referencedColumnName = "id_acao" , nullable = false)
    private Acao acao;

	public ResultadoChecklist(){
		
	}
	
	public ResultadoChecklist(Integer idResultadoChecklist){
		this.idResultadoChecklist = idResultadoChecklist;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((idResultadoChecklist == null) ? 0
						: idResultadoChecklist.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof ResultadoChecklist)) {
			return false;
		}
		ResultadoChecklist other = (ResultadoChecklist) obj;
		if (idResultadoChecklist == null) {
			if (other.idResultadoChecklist != null) {
				return false;
			}
		} else if (!idResultadoChecklist
				.equals(other.idResultadoChecklist)) {
			return false;
		}
		return true;
	}
	
	@Override
	public String toString() {
		return idResultadoChecklist.toString();
	}

	
	//GETTERS AND SETTERS
	public Integer getPK() {
		return idResultadoChecklist;
	}

	public void setPK(Integer pk) {
		this.idResultadoChecklist = pk;
	}

	public Integer getIdResultadoChecklist() {
		return idResultadoChecklist;
	}

	public void setIdResultadoChecklist(Integer idResultadoChecklist) {
		this.idResultadoChecklist = idResultadoChecklist;
	}

	/**
	 * @return the login
	 */
	public final String getLogin() {
		return login;
	}

	/**
	 * @param login
	 *            the login to set
	 */
	public final void setLogin(String login) {
		this.login = login;
	}

	/**
	 * @return the tipoAtendimento
	 */
	public final String getTipoAtendimento() {
		return tipoAtendimento;
	}

	/**
	 * @param tipoAtendimento
	 *            the tipoAtendimento to set
	 */
	public final void setTipoAtendimento(String tipoAtendimento) {
		this.tipoAtendimento = tipoAtendimento;
	}

	/**
	 * @return the idExterno
	 */
	public final Integer getIdExterno() {
		return idExterno;
	}

	/**
	 * @param idExterno
	 *            the idExterno to set
	 */
	public final void setIdExterno(Integer idExterno) {
		this.idExterno = idExterno;
	}

	/**
	 * @return the dataResposta
	 */
	public final Date getDataResposta() {
		return dataResposta == null ? null : new Date(dataResposta.getTime());
	}

	/**
	 * @param dataResposta
	 *            the dataResposta to set
	 */
	public final void setDataResposta(Date dataResposta) {
		this.dataResposta = dataResposta == null ? null : new Date(dataResposta.getTime());
	}

	public final List<RespostaChecklist> getRespostaList() {
		return respostaList;
	}

	public final void setRespostaList(List<RespostaChecklist> respostaList) {
		this.respostaList = respostaList;
	}

	public CasoSau getCasoSau() {
		return casoSau;
	}

	public void setCasoSau(CasoSau casoSau) {
		this.casoSau = casoSau;
	}

	public Evento getEvento() {
		return evento;
	}

	public void setEvento(Evento evento) {
		this.evento = evento;
	}

	public Acao getAcao() {
		return acao;
	}

	public void setAcao(Acao acao) {
		this.acao = acao;
	}
	
	
	public static String getSqlCamposResultadoChecklist() {

        return new StringBuilder()
                .append(" \nResultadoChecklist.id_resultado_checklist AS 'ResultadoChecklist.id_resultado_checklist', ")
                .append(" \nResultadoChecklist.login AS 'ResultadoChecklist.login', ")
                .append(" \nResultadoChecklist.tipo_atendimento AS 'ResultadoChecklist.tipo_atendimento', ")
                .append(" \nResultadoChecklist.id_externo AS 'ResultadoChecklist.id_externo', ")
                .append(" \nResultadoChecklist.data_resposta AS 'ResultadoChecklist.data_resposta', ")
                .append(" \nResultadoChecklist.id_caso_sau AS 'ResultadoChecklist.id_caso_sau', ")
                .append(" \nResultadoChecklist.id_evento AS 'ResultadoChecklist.id_evento', ")
                .append(" \nResultadoChecklist.id_acao AS 'ResultadoChecklist.id_acao' ")
                .toString();
    }

    public static String getSqlFromResultadoChecklist() {
        return " TB_RESULTADO_CHECKLIST  AS ResultadoChecklist with(nolock) ";
    }

    public static ResultadoChecklist getResultadoChecklistByResultSet(
            ResultSet resultSet) {
        try {
        	
        	if(resultSet.getInt("ResultadoChecklist.id_resultado_checklist") == 0){
        		return null;
        	}
        	
        	ResultadoChecklist resultadoChecklist = new ResultadoChecklist();
        	
        	resultadoChecklist.setIdResultadoChecklist(resultSet.getInt("ResultadoChecklist.id_resultado_checklist"));
        	resultadoChecklist.setLogin(resultSet.getString("ResultadoChecklist.login"));
        	resultadoChecklist.setTipoAtendimento(resultSet.getString("ResultadoChecklist.tipo_atendimento"));
        	resultadoChecklist.setIdExterno(resultSet.getInt("ResultadoChecklist.id_externo"));
        	resultadoChecklist.setDataResposta(resultSet.getTimestamp("ResultadoChecklist.data_resposta"));
        	resultadoChecklist.setCasoSau(resultSet.getInt("ResultadoChecklist.id_caso_sau") == 0 ? null : new CasoSau(resultSet.getInt("ResultadoChecklist.id_caso_sau")));
        	resultadoChecklist.setEvento(resultSet.getInt("ResultadoChecklist.id_evento") == 0 ? null : new Evento(resultSet.getInt("ResultadoChecklist.id_evento")));
        	resultadoChecklist.setAcao(resultSet.getInt("ResultadoChecklist.id_acao") == 0 ? null : new Acao(resultSet.getInt("ResultadoChecklist.id_acao")));
            
            return resultadoChecklist;
        } catch (SQLException e) {
            throw new IllegalArgumentException(
                    "Erro ao montar objeto a partir do ResultSet", e);
        }
    }
	
	
}
