package br.com.callink.cad.sau.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;



@Entity
@Table(name = "TB_RESULTADO_QUESTIONARIO")
public class ResultadoQuestionario implements IEntity<Integer> {

	private static final long serialVersionUID = 4381095151872277141L;
	
	@Id
	@Column(name = "id_resultado_questionario")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer idResultadoQuestionario;
	
	@Column(name = "login" , length = 200)
	private String login;
	
	@Column(name = "tipo_atendimento" , length = 200)
	private String tipoAtendimento;
	
	@Column(name = "id_externo")
	private Integer idExterno;
	
	@Column(name = "data_resposta")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataResposta;
	
	@OneToMany(cascade = {CascadeType.REFRESH, CascadeType.REMOVE}, mappedBy = "resultadoQuestionario", fetch = FetchType.LAZY)
	private List<Resposta> respostaList;
	
	public ResultadoQuestionario() {
    }

    public ResultadoQuestionario(Integer idResultadoQuestionario) {
        this.idResultadoQuestionario = idResultadoQuestionario;
    }

	public Integer getPK() {
		return idResultadoQuestionario;
	}

	public void setPK(Integer pk) {
		this.idResultadoQuestionario = pk;
	}

	/**
	 * @return the idResultadoQuestionario
	 */
	public final Integer getIdResultadoQuestionario() {
		return idResultadoQuestionario;
	}

	/**
	 * @param idResultadoQuestionario
	 *            the idResultadoQuestionario to set
	 */
	public final void setIdResultadoQuestionario(Integer idResultadoQuestionario) {
		this.idResultadoQuestionario = idResultadoQuestionario;
	}

	/**
	 * @return the login
	 */
	public final String getLogin() {
		return login;
	}

	/**
	 * @param login
	 *            the login to set
	 */
	public final void setLogin(String login) {
		this.login = login;
	}

	/**
	 * @return the tipoAtendimento
	 */
	public final String getTipoAtendimento() {
		return tipoAtendimento;
	}

	/**
	 * @param tipoAtendimento
	 *            the tipoAtendimento to set
	 */
	public final void setTipoAtendimento(String tipoAtendimento) {
		this.tipoAtendimento = tipoAtendimento;
	}

	/**
	 * @return the idExterno
	 */
	public final Integer getIdExterno() {
		return idExterno;
	}

	/**
	 * @param idExterno
	 *            the idExterno to set
	 */
	public final void setIdExterno(Integer idExterno) {
		this.idExterno = idExterno;
	}

	/**
	 * @return the dataResposta
	 */
	public final Date getDataResposta() {
		return dataResposta == null ? null : new Date(dataResposta.getTime());
	}

	/**
	 * @param dataResposta
	 *            the dataResposta to set
	 */
	public final void setDataResposta(Date dataResposta) {
		this.dataResposta = dataResposta == null ? null : new Date(dataResposta.getTime());
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((idResultadoQuestionario == null) ? 0
						: idResultadoQuestionario.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof ResultadoQuestionario)) {
			return false;
		}
		ResultadoQuestionario other = (ResultadoQuestionario) obj;
		if (idResultadoQuestionario == null) {
			if (other.idResultadoQuestionario != null) {
				return false;
			}
		} else if (!idResultadoQuestionario
				.equals(other.idResultadoQuestionario)) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return idResultadoQuestionario.toString();
	}

	public final List<Resposta> getRespostaList() {
		return respostaList;
	}

	public final void setRespostaList(List<Resposta> respostaList) {
		this.respostaList = respostaList;
	}
	
	public static String getSqlCamposResultadoQuestionario() {

        return new StringBuilder()
                .append(" \nResultadoQuestionario.id_resultado_questionario AS 'ResultadoQuestionario.id_resultado_questionario', ")
                .append(" \nResultadoQuestionario.login AS 'ResultadoQuestionario.login', ")
                .append(" \nResultadoQuestionario.tipo_atendimento AS 'ResultadoQuestionario.tipo_atendimento', ")
                .append(" \nResultadoQuestionario.id_externo AS 'ResultadoQuestionario.id_externo', ")
                .append(" \nResultadoQuestionario.data_resposta AS 'ResultadoQuestionario.data_resposta' ")
                .toString();
    }

    public static String getSqlFromResultadoQuestionario() {
        return " TB_RESULTADO_QUESTIONARIO  AS ResultadoQuestionario with(nolock) ";
    }

    public static ResultadoQuestionario getResultadoQuestionarioByResultSet(
            ResultSet resultSet) {
        try {
        	
        	if(resultSet.getInt("ResultadoQuestionario.id_resultado_questionario") == 0){
        		return null;
        	}
        	
        	ResultadoQuestionario resultadoQuestionario = new ResultadoQuestionario();
        	
        	resultadoQuestionario.setIdResultadoQuestionario(resultSet.getInt("ResultadoQuestionario.id_resultado_questionario"));
        	resultadoQuestionario.setLogin(resultSet.getString("ResultadoQuestionario.login"));
        	resultadoQuestionario.setTipoAtendimento(resultSet.getString("ResultadoQuestionario.tipo_atendimento"));
        	resultadoQuestionario.setIdExterno(resultSet.getInt("ResultadoQuestionario.id_externo"));
        	resultadoQuestionario.setDataResposta(resultSet.getTimestamp("ResultadoQuestionario.data_resposta"));
            
            return resultadoQuestionario;
        } catch (SQLException e) {
            throw new IllegalArgumentException(
                    "Erro ao montar objeto a partir do ResultSet", e);
        }
    }
	
}
