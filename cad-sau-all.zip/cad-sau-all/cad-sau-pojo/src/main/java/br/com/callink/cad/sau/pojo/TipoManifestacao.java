package br.com.callink.cad.sau.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;


@Entity
@Table(name = "TB_TIPO_CASO")
public class TipoManifestacao implements IEntity<Integer>{

    
	private static final long serialVersionUID = 4358699090407821130L;
	
	@Id
	@Column(name = "ID_TIPO_CASO")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idTipoCaso;
    
	@Column(name = "NOME", length = 500)
    private String nome;
    
	@Column(name = "DATA_CRIACAO")
	@Temporal(TemporalType.TIMESTAMP)
    private Date dataCriacao;
    
	@Column(name = "FLAG_ATIVO")
    private Boolean flagAtivo;
    
	@Column(name = "FLAG_CLASSIFICA_AUTOMATICO")
    private Boolean flagClassificaAutomatico;
    
	@Column(name = "FLAG_FINALIZA_AUTOMATICO")
    private Boolean flagFinalizaAutomatico;
    
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_EVENTO", referencedColumnName = "ID_EVENTO")
    private Evento evento;
	
	@Column(name = "FLAG_NAO_ATENDE")
    private Boolean flagNaoAtende;
    
    private transient Boolean selecionado;

	public TipoManifestacao() {
    }

    public TipoManifestacao(Integer idTipoCaso) {
        this.idTipoCaso = idTipoCaso;
    }

    public Integer getPK() {
        return idTipoCaso;
    }

    public void setPK(Integer pk) {
        this.idTipoCaso = pk;
    }

    /**
     * @return the idTipoCaso
     */
    public final Integer getIdTipoCaso() {
        return idTipoCaso;
    }

    /**
     * @param idTipoCaso
     *            the idTipoCaso to set
     */
    public final void setIdTipoCaso(Integer idTipoCaso) {
        this.idTipoCaso = idTipoCaso;
    }

    /**
     * @return the nome
     */
    public final String getNome() {
        return nome;
    }

    /**
     * @param nome
     *            the nome to set
     */
    public final void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the dataCriacao
     */
    public final Date getDataCriacao() {
        return dataCriacao == null ? null : new Date(dataCriacao.getTime());
    }

    /**
     * @param dataCriacao
     *            the dataCriacao to set
     */
    public final void setDataCriacao(Date dataCriacao) {
        this.dataCriacao = dataCriacao == null ? null : new Date(dataCriacao.getTime());
    }

    /**
     * @return the flagAtivo
     */
    public final Boolean getFlagAtivo() {
        return flagAtivo;
    }

    /**
     * @param flagAtivo
     *            the flagAtivo to set
     */
    public final void setFlagAtivo(Boolean flagAtivo) {
        this.flagAtivo = flagAtivo;
    }

    /**
     * @return the evento
     */
    public final Evento getEvento() {
        return evento;
    }

    /**
     * @param evento
     *            the evento to set
     */
    public final void setEvento(Evento evento) {
        this.evento = evento;
    }

    public Boolean getFlagClassificaAutomatico() {
        return flagClassificaAutomatico;
    }

    public void setFlagClassificaAutomatico(Boolean flagClassificaAutomatico) {
        this.flagClassificaAutomatico = flagClassificaAutomatico;
    }

    public Boolean getFlagFinalizaAutomatico() {
        return flagFinalizaAutomatico;
    }

    public void setFlagFinalizaAutomatico(Boolean flagFinalizaAutomatico) {
        this.flagFinalizaAutomatico = flagFinalizaAutomatico;
    }

    public Boolean getFlagNaoAtende() {
		return flagNaoAtende;
	}

	public void setFlagNaoAtende(Boolean flagNaoAtende) {
		this.flagNaoAtende = flagNaoAtende;
	}

	@Override
    public String toString() {
        return this.getNome();
    }

    public static String getSqlCamposTipoManifestacao() {

        return new StringBuilder()
                .append(" \nTipoManifestacao.ID_TIPO_CASO AS 'TipoManifestacao.ID_TIPO_CASO', ")
                .append(" \nTipoManifestacao.NOME AS 'TipoManifestacao.NOME', ")
                .append(" \nTipoManifestacao.DATA_CRIACAO AS 'TipoManifestacao.DATA_CRIACAO', ")
                .append(" \nTipoManifestacao.FLAG_ATIVO AS 'TipoManifestacao.FLAG_ATIVO', ")
                .append(" \nTipoManifestacao.ID_EVENTO AS 'TipoManifestacao.ID_EVENTO', ")
                .append(" \nTipoManifestacao.FLAG_CLASSIFICA_AUTOMATICO AS 'TipoManifestacao.FLAG_CLASSIFICA_AUTOMATICO', ")
                .append(" \nTipoManifestacao.FLAG_FINALIZA_AUTOMATICO AS 'TipoManifestacao.FLAG_FINALIZA_AUTOMATICO', ")
                .append(" \nTipoManifestacao.FLAG_NAO_ATENDE AS 'TipoManifestacao.FLAG_NAO_ATENDE' ")
                .toString();
    }

    public static String getSqlFromTipoManifestacao() {
        return " TB_TIPO_CASO  AS TipoManifestacao with(nolock) ";
    }

    public static TipoManifestacao getTipoManifestacaoByResultSet(
            ResultSet resultSet) {
        try {
        	
        	if(resultSet.getInt("TipoManifestacao.ID_TIPO_CASO") == 0){
        		return null;
        	}
        	
            TipoManifestacao tipoManifestacao = new TipoManifestacao();

            tipoManifestacao.setIdTipoCaso(resultSet.getInt("TipoManifestacao.ID_TIPO_CASO"));
            tipoManifestacao.setNome(resultSet.getString("TipoManifestacao.NOME"));
            tipoManifestacao.setDataCriacao(resultSet.getTimestamp("TipoManifestacao.DATA_CRIACAO"));
            tipoManifestacao.setFlagAtivo(resultSet.getBoolean("TipoManifestacao.FLAG_ATIVO"));
            tipoManifestacao.setEvento(resultSet.getInt("TipoManifestacao.ID_EVENTO") == 0 ? null : new Evento(resultSet.getInt("TipoManifestacao.ID_EVENTO")));
            tipoManifestacao.setFlagClassificaAutomatico(resultSet.getBoolean("TipoManifestacao.FLAG_CLASSIFICA_AUTOMATICO"));
            tipoManifestacao.setFlagFinalizaAutomatico(resultSet.getBoolean("TipoManifestacao.FLAG_FINALIZA_AUTOMATICO"));
            tipoManifestacao.setFlagNaoAtende(resultSet.getBoolean("TipoManifestacao.FLAG_NAO_ATENDE"));
            
            return tipoManifestacao;
        } catch (SQLException e) {
            throw new IllegalArgumentException(
                    "Erro ao montar objeto a partir do ResultSet", e);
        }
    }

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((idTipoCaso == null) ? 0 : idTipoCaso.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof TipoManifestacao)) {
			return false;
		}
		TipoManifestacao other = (TipoManifestacao) obj;
		if (idTipoCaso == null) {
			if (other.idTipoCaso != null) {
				return false;
			}
		} else if (!idTipoCaso.equals(other.idTipoCaso)) {
			return false;
		}
		return true;
	}

	public final Boolean getSelecionado() {
		return selecionado;
	}

	public final void setSelecionado(Boolean selecionado) {
		this.selecionado = selecionado;
	}

}
