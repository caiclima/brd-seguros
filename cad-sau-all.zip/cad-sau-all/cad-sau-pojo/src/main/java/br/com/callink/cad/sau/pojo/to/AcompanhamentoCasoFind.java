package br.com.callink.cad.sau.pojo.to;

import java.util.Date;
import java.util.List;

import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.pojo.Equipe;
import br.com.callink.cad.pojo.Status;
import br.com.callink.cad.sau.pojo.Assunto;
import br.com.callink.cad.sau.pojo.Canal;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.pojo.Estado;
import br.com.callink.cad.sau.pojo.Evento;
import br.com.callink.cad.sau.pojo.OutraArea;
import br.com.callink.cad.sau.pojo.TipoManifestacao;

public class AcompanhamentoCasoFind {
	private CasoSau casoSau;
    private Date dataInicio;
    private Date dataFim; 
    private Long slaEmMinutos;
    private List<Canal> canalSelecionadoList;
    private List<Evento> eventoSelecionadoList;
    private List<TipoManifestacao> tipoManifestacaoSelecionadoList;
    private List<ConfiguracaoFila> configuracaoFilaSelecionadoList; 
    private List<Status> statusSelecionadoList;
    private List<OutraArea> outraAreaSelecionadoList;
    private List<Estado> estadoSelecionadoList;
    private List<Atendente> atendenteSelecionadoList; 
    private List<Assunto> assuntoSelecionadoList; 
    private List<Equipe> equipeSelecionadoList;
    private Date dataInicioFechamento;
    private Date dataFimFechamento;
    private Long slaEmMinutosMaior;
    private Character flagRechamadoCaso;
    private String viaEntrada;
    private Boolean casoFechado;
    
	public CasoSau getCasoSau() {
		return casoSau;
	}
	public void setCasoSau(CasoSau casoSau) {
		this.casoSau = casoSau;
	}
	public Date getDataInicio() {
		return dataInicio == null ? null : new Date(dataInicio.getTime());
	}
	public void setDataInicio(Date dataInicio) {
		this.dataInicio = dataInicio == null ? null : new Date(dataInicio.getTime());
	}
	public Date getDataFim() {
		return dataFim == null ? null : new Date(dataFim.getTime());
	}
	public void setDataFim(Date dataFim) {
		this.dataFim = dataFim == null ? null : new Date(dataFim.getTime());
	}
	public Long getSlaEmMinutos() {
		return slaEmMinutos;
	}
	public void setSlaEmMinutos(Long slaEmMinutos) {
		this.slaEmMinutos = slaEmMinutos;
	}
	public List<Canal> getCanalSelecionadoList() {
		return canalSelecionadoList;
	}
	public void setCanalSelecionadoList(List<Canal> canalSelecionadoList) {
		this.canalSelecionadoList = canalSelecionadoList;
	}
	public List<Evento> getEventoSelecionadoList() {
		return eventoSelecionadoList;
	}
	public void setEventoSelecionadoList(List<Evento> eventoSelecionadoList) {
		this.eventoSelecionadoList = eventoSelecionadoList;
	}
	public List<TipoManifestacao> getTipoManifestacaoSelecionadoList() {
		return tipoManifestacaoSelecionadoList;
	}
	public void setTipoManifestacaoSelecionadoList(
			List<TipoManifestacao> tipoManifestacaoSelecionadoList) {
		this.tipoManifestacaoSelecionadoList = tipoManifestacaoSelecionadoList;
	}
	public List<ConfiguracaoFila> getConfiguracaoFilaSelecionadoList() {
		return configuracaoFilaSelecionadoList;
	}
	public void setConfiguracaoFilaSelecionadoList(
			List<ConfiguracaoFila> configuracaoFilaSelecionadoList) {
		this.configuracaoFilaSelecionadoList = configuracaoFilaSelecionadoList;
	}
	public List<Status> getStatusSelecionadoList() {
		return statusSelecionadoList;
	}
	public void setStatusSelecionadoList(List<Status> statusSelecionadoList) {
		this.statusSelecionadoList = statusSelecionadoList;
	}
	public List<Atendente> getAtendenteSelecionadoList() {
		return atendenteSelecionadoList;
	}
	public void setAtendenteSelecionadoList(List<Atendente> atendenteSelecionadoList) {
		this.atendenteSelecionadoList = atendenteSelecionadoList;
	}
	public List<Assunto> getAssuntoSelecionadoList() {
		return assuntoSelecionadoList;
	}
	public void setAssuntoSelecionadoList(List<Assunto> assuntoSelecionadoList) {
		this.assuntoSelecionadoList = assuntoSelecionadoList;
	}
	public List<Equipe> getEquipeSelecionadoList() {
		return equipeSelecionadoList;
	}
	public void setEquipeSelecionadoList(List<Equipe> equipeSelecionadoList) {
		this.equipeSelecionadoList = equipeSelecionadoList;
	}
	public Date getDataInicioFechamento() {
		return dataInicioFechamento == null ? null: new Date(dataInicioFechamento.getTime());
	}
	public void setDataInicioFechamento(Date dataInicioFechamento) {
		this.dataInicioFechamento = dataInicioFechamento == null ? null: new Date(dataInicioFechamento.getTime());
	}
	public Date getDataFimFechamento() {
		return dataFimFechamento == null ? null: new Date(dataFimFechamento.getTime());
	}
	public void setDataFimFechamento(Date dataFimFechamento) {
		this.dataFimFechamento = dataFimFechamento == null ? null: new Date(dataFimFechamento.getTime());
	}
	public Long getSlaEmMinutosMaior() {
		return slaEmMinutosMaior;
	}
	public void setSlaEmMinutosMaior(Long slaEmMinutosMaior) {
		this.slaEmMinutosMaior = slaEmMinutosMaior;
	}
	public Character getFlagRechamadoCaso() {
		return flagRechamadoCaso;
	}
	public void setFlagRechamadoCaso(Character flagRechamadoCaso) {
		this.flagRechamadoCaso = flagRechamadoCaso;
	}
	public String getViaEntrada() {
		return viaEntrada;
	}
	public void setViaEntrada(String viaEntrada) {
		this.viaEntrada = viaEntrada;
	}
	public List<OutraArea> getOutraAreaSelecionadoList() {
		return outraAreaSelecionadoList;
	}
	public void setOutraAreaSelecionadoList(List<OutraArea> outraAreaSelecionadoList) {
		this.outraAreaSelecionadoList = outraAreaSelecionadoList;
	}
	public List<Estado> getEstadoSelecionadoList() {
		return estadoSelecionadoList;
	}
	public void setEstadoSelecionadoList(List<Estado> estadoSelecionadoList) {
		this.estadoSelecionadoList = estadoSelecionadoList;
	}
	public Boolean getCasoFechado() {
		return casoFechado;
	}
	public void setCasoFechado(Boolean casoFechado) {
		this.casoFechado = casoFechado;
	}
}
