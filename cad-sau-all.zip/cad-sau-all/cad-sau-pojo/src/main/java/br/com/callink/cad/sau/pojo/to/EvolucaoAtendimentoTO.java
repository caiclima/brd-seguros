package br.com.callink.cad.sau.pojo.to;

import br.com.callink.cad.sau.pojo.EvolucaoAtendimento;

import java.util.Date;
import java.util.List;

/**
 *
 * @author brunomt
 */
public class EvolucaoAtendimentoTO {
    private Date dataRelatorio;
    private List<EvolucaoAtendimento> evolucaoAtendimento;

    public Date getDataRelatorio() {
        return dataRelatorio == null ? null : new Date(dataRelatorio.getTime());
    }

    public void setDataRelatorio(Date dataRelatorio) {
        this.dataRelatorio = dataRelatorio == null ? null : new Date(dataRelatorio.getTime());
    }

    public List<EvolucaoAtendimento> getEvolucaoAtendimento() {
        return evolucaoAtendimento;
    }

    public void setEvolucaoAtendimento(List<EvolucaoAtendimento> evolucaoAtendimento) {
        this.evolucaoAtendimento = evolucaoAtendimento;
    }
            
}
