/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.sau.qlikview.pojo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;


/**
 *
 * @author Rogério Moreira de Andrade
 */
@Entity
@Table(name = "TB_QLIKVIEW_ENQUETE")
public class QlikViewEnquete implements IEntity<Integer> {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID_QLIKVIEW_ENQUETE", unique = true, nullable = false)
    private Integer idQlikViewEnquete;
    
    @Column(name="MANIFESTACAO", length = 20)
    private String manifestacao;
    
    @Column(name="ID_TIPO_MANIFESTACAO", length = 10)
    private Integer idTipoManifestacao;
    
    @Column(name="TIPO_MANIFESTACAO", length = 500)
    private String tipoManifestacao;
    
    @Column(name="ID_FILA_TRATAMENTO", length = 10)
    private Integer idFilaTratamento;
    
    @Column(name="FILA_TRATAMENTO", length = 500)
    private String filaTratamento;
    
    @Column(name="DATA_REGISTRO_ENQUETE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataRegistroEnquete;
    
    @Column(name="LOGIN_ATENDENTE", length = 200)
    private String loginAtendente;
    
    @Column(name="ID_TELEFONIA", length = 10)
    private Integer idTelefonia;
    
    @Column(name="ID_ENQUETE", length = 10)
    private Integer idEnquete;
    
    @Column(name="DESCRICAO_ENQUETE")
    private String descricaoEnquete;
    
    @Column(name="ID_QUESTAO", length = 10)
    private Integer idQestao;
    
    @Column(name="DESCRICAO_QUESTAO")
    private String descricaoQestao;
    
    @Column(name="ID_RESPOSTA", length = 10)
    private Integer idResposta;
    
    @Column(name="DESCRICAO_RESPOSTA")
    private String descricaoResposta;
    
    @Column(name="NOME_ATENDENTE", length = 50)
    private String nomeAtendente;
    

    public Date getDataRegistroEnquete() {
        return dataRegistroEnquete == null ? null : new Date(dataRegistroEnquete.getTime());
    }

    public void setDataRegistroEnquete(Date dataRegistroEnquete) {
        this.dataRegistroEnquete = dataRegistroEnquete == null ? null : new Date(dataRegistroEnquete.getTime());
    }

    public String getDescricaoEnquete() {
        return descricaoEnquete;
    }

    public void setDescricaoEnquete(String descricaoEnquete) {
        this.descricaoEnquete = descricaoEnquete;
    }

    public String getDescricaoQestao() {
        return descricaoQestao;
    }

    public void setDescricaoQestao(String descricaoQestao) {
        this.descricaoQestao = descricaoQestao;
    }

    public String getDescricaoResposta() {
        return descricaoResposta;
    }

    public void setDescricaoResposta(String descricaoResposta) {
        this.descricaoResposta = descricaoResposta;
    }

    public String getFilaTratamento() {
        return filaTratamento;
    }

    public void setFilaTratamento(String filaTratamento) {
        this.filaTratamento = filaTratamento;
    }

    public Integer getIdEnquete() {
        return idEnquete;
    }

    public void setIdEnquete(Integer idEnquete) {
        this.idEnquete = idEnquete;
    }

    public Integer getIdFilaTratamento() {
        return idFilaTratamento;
    }

    public void setIdFilaTratamento(Integer idFilaTratamento) {
        this.idFilaTratamento = idFilaTratamento;
    }

    public Integer getIdQestao() {
        return idQestao;
    }

    public void setIdQestao(Integer idQestao) {
        this.idQestao = idQestao;
    }

    public Integer getIdQlikViewEnquete() {
        return idQlikViewEnquete;
    }

    public void setIdQlikViewEnquete(Integer idQlikViewEnquete) {
        this.idQlikViewEnquete = idQlikViewEnquete;
    }

    public Integer getIdTelefonia() {
        return idTelefonia;
    }

    public void setIdTelefonia(Integer idTelefonia) {
        this.idTelefonia = idTelefonia;
    }

    public Integer getIdTipoManifestacao() {
        return idTipoManifestacao;
    }

    public void setIdTipoManifestacao(Integer idTipoManifestacao) {
        this.idTipoManifestacao = idTipoManifestacao;
    }

    public String getLoginAtendente() {
        return loginAtendente;
    }

    public void setLoginAtendente(String loginAtendente) {
        this.loginAtendente = loginAtendente;
    }

    public String getManifestacao() {
        return manifestacao;
    }

    public void setManifestacao(String manifestacao) {
        this.manifestacao = manifestacao;
    }

    public String getTipoManifestacao() {
        return tipoManifestacao;
    }

    public void setTipoManifestacao(String tipoManifestacao) {
        this.tipoManifestacao = tipoManifestacao;
    }

    public Integer getIdResposta() {
        return idResposta;
    }

    public void setIdResposta(Integer idResposta) {
        this.idResposta = idResposta;
    }

    public String getNomeAtendente() {
        return nomeAtendente;
    }

    public void setNomeAtendente(String nomeAtendente) {
        this.nomeAtendente = nomeAtendente;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 43 * hash + (this.idQlikViewEnquete != null ? this.idQlikViewEnquete.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final QlikViewEnquete other = (QlikViewEnquete) obj;
        if (this.idQlikViewEnquete == null || !this.idQlikViewEnquete.equals(other.idQlikViewEnquete)) {
            return false;
        }
        return true;
    }

    @Override
    public Integer getPK() {
        return this.idQlikViewEnquete;
    }

    @Override
    public void setPK(Integer pk) {
        this.idQlikViewEnquete = pk;
    }
    
    public static String getSqlCamposQlikViewEnquete() {
        return new StringBuilder()
                .append(" \nQlikViewEnquete.ID_QLIKVIEW_ENQUETE AS 'QlikViewEnquete.ID_QLIKVIEW_ENQUETE', ")
                .append(" \nQlikViewEnquete.MANIFESTACAO AS 'QlikViewEnquete.MANIFESTACAO', ")
                .append(" \nQlikViewEnquete.ID_TIPO_MANIFESTACAO AS 'QlikViewEnquete.ID_TIPO_MANIFESTACAO', ")
                .append(" \nQlikViewEnquete.TIPO_MANIFESTACAO AS 'QlikViewEnquete.TIPO_MANIFESTACAO', ")
                .append(" \nQlikViewEnquete.ID_FILA_TRATAMENTO AS 'QlikViewEnquete.ID_FILA_TRATAMENTO', ")
                .append(" \nQlikViewEnquete.FILA_TRATAMENTO AS 'QlikViewEnquete.FILA_TRATAMENTO', ")
                .append(" \nQlikViewEnquete.DATA_REGISTRO_ENQUETE AS 'QlikViewEnquete.DATA_REGISTRO_ENQUETE', ")
                .append(" \nQlikViewEnquete.LOGIN_ATENDENTE AS 'QlikViewEnquete.LOGIN_ATENDENTE', ")
                .append(" \nQlikViewEnquete.ID_TELEFONIA AS 'QlikViewEnquete.ID_TELEFONIA', ")
                .append(" \nQlikViewEnquete.ID_ENQUETE AS 'QlikViewEnquete.ID_ENQUETE', ")
                .append(" \nQlikViewEnquete.DESCRICAO_ENQUETE AS 'QlikViewEnquete.DESCRICAO_ENQUETE', ")
                .append(" \nQlikViewEnquete.ID_QUESTAO AS 'QlikViewEnquete.ID_QUESTAO', ")
                .append(" \nQlikViewEnquete.DESCRICAO_QUESTAO AS 'QlikViewEnquete.DESCRICAO_QUESTAO', ")
                .append(" \nQlikViewEnquete.DESCRICAO_RESPOSTA AS 'QlikViewEnquete.DESCRICAO_RESPOSTA', ")
                .append(" \nQlikViewEnquete.ID_RESPOSTA AS 'QlikViewEnquete.ID_RESPOSTA', ")
                .append(" \nQlikViewEnquete.NOME_ATENDENTE AS 'QlikViewEnquete.NOME_ATENDENTE' ").toString();
    }

    public static String getSqlFromQlikViewEnquete() {
        return " TB_QLIKVIEW_ENQUETE AS QlikViewEnquete with(nolock) ";
    }
    
    public static QlikViewEnquete getQlikViewEnqueteByResultSet(ResultSet rs) {
        try {
        	QlikViewEnquete qlikViewEnquete = new QlikViewEnquete();
            qlikViewEnquete.setIdQlikViewEnquete(rs.getInt("QlikViewEnquete.ID_QLIKVIEW_ENQUETE"));
            qlikViewEnquete.setManifestacao(rs.getString("QlikViewEnquete.MANIFESTACAO"));
            qlikViewEnquete.setIdTipoManifestacao(rs.getInt("QlikViewEnquete.ID_TIPO_MANIFESTACAO"));
            qlikViewEnquete.setTipoManifestacao(rs.getString("QlikViewEnquete.TIPO_MANIFESTACAO"));
            qlikViewEnquete.setIdFilaTratamento(rs.getInt("QlikViewEnquete.ID_FILA_TRATAMENTO"));
            qlikViewEnquete.setFilaTratamento(rs.getString("QlikViewEnquete.FILA_TRATAMENTO"));
            qlikViewEnquete.setDataRegistroEnquete(rs.getTimestamp("QlikViewEnquete.DATA_REGISTRO_ENQUETE"));
            qlikViewEnquete.setLoginAtendente(rs.getString("QlikViewEnquete.LOGIN_ATENDENTE"));
            qlikViewEnquete.setIdTelefonia(rs.getInt("QlikViewEnquete.ID_TELEFONIA"));
            qlikViewEnquete.setIdEnquete(rs.getInt("QlikViewEnquete.ID_ENQUETE"));
            qlikViewEnquete.setDescricaoEnquete(rs.getString("QlikViewEnquete.DESCRICAO_ENQUETE"));
            qlikViewEnquete.setIdQestao(rs.getInt("QlikViewEnquete.ID_QUESTAO"));
            qlikViewEnquete.setDescricaoQestao(rs.getString("QlikViewEnquete.DESCRICAO_QUESTAO"));
            qlikViewEnquete.setDescricaoResposta(rs.getString("QlikViewEnquete.DESCRICAO_RESPOSTA"));
            qlikViewEnquete.setIdResposta(rs.getInt("QlikViewEnquete.ID_RESPOSTA"));
            qlikViewEnquete.setNomeAtendente(rs.getString("QlikViewEnquete.NOME_ATENDENTE"));
            return qlikViewEnquete;
        } catch (SQLException ex) {
            throw new IllegalArgumentException(
                    "Erro ao montar objeto a partir do ResultSet", ex);
        }
    }
    
}
