package br.com.callink.cad.sau.qlikview.pojo;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.callink.cad.pojo.entity.IEntity;

@Entity
@Table(name = "TB_QLIKVIEW_HISTORICO_CASO")
public class RelatorioHistoricoCaso implements IEntity<Integer> {

	private static final long serialVersionUID = 1L;

	public RelatorioHistoricoCaso() {
    }
    
    @Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_historico_qlikview", unique = true, nullable = false)
    private Integer idHistoricoCaso;
    
    //CAMPOS STGM
    @Column(name="MANIFESTACAO", length = 20)
    private String manifestacao;
    
    @Column(name="ID_CASO", length = 10)
    private Integer idCaso;
    
    @Column(name="ID_CASO_SAU", length = 10)
    private Integer idCasoSau;

    @Column(name="CARTAO", length = 50)
    private String cartao;
    
    @Column(name="TIPO_CARTAO", length = 50)
    private String tipoCartao;
    
    @Column(name="DATA_ABERTURA")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataAbertura;

    @Column(name="DATA_ULTIMA_ACAO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataUltimaAcao;
    
    @Column(name="ID_ESTADO", length = 10)
    private Integer idEstado;
    
    @Column(name="NOME_ESTADO", length = 500)
    private String nomeEstado;
    
    @Column(name="ID_CANAL", length = 10)
    private Integer idCanal;
    
    @Column(name="NOME_CANAL", length = 500)
    private String nomeCanal;
    
    @Column(name="ULTIMO_ATENDENTE", length = 200)
    private String ultimoAtendente;
    
    @Column(name="TIPO_MANIFESTACAO", length = 200)
    private String tipoManifestacao;
    
    @Column(name="AGENCIA_DEPARTAMENTO", length = 200)
    private String agenciaDepartamento;
    
    @Column(name="NOME_CLIENTE", length = 500)
    private String nomeCliente;
    
    @Column(name="AGENCIA_CONTA", length = 200)
    private String agenciaConta;
    
    @Column(name="CPF_CNPJ", length = 50)
    private String cpfCnpj;
    
    @Column(name="EMAIL", length = 500)
    private String email;
    
    @Column(name="TELEFONE", length = 50)
    private String telefone;

    @Column(name="TELEFONE_SEGUNDO", length = 50)
    private String telefoneSegundo;
    
    @Column(name="ENDERECO")
    private String endereco;

    @Column(name="CEP", length = 50)
    private String cep;

    @Column(name="ENVIO_PROTOCOLO_CLIENTE", length = 100)
    private String envioProtocoloCliente;
    
    @Column(name="VIA_ENTRADA", length = 500)
    private String viaEntrada;

    @Column(name="DESCRICAO")
    private String descricao;

    @Column(name="ASSUNTO_STGM", length = 500)
    private String assuntoSTGM;
    
    @Column(name="GRUPO", length = 500)
    private String grupo;
    
    @Column(name="SUB_GRUPO", length = 500)
    private String subGrupo;
    
    @Column(name="NOME_CAUSA", length = 200)
    private String nomeCausa;
    
    //CAMPOS GBO
    @Column(name="ID_LOG", length = 10)
    private Integer idLog;
    
    @Column(name="DATA_FIM_SLA")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataFimSla;
    
    @Column(name="DATA_CADASTRO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataCadastro;
    
    @Column(name="DATA_ENCERRAMENTO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataEncerramento;
    
    @Column(name="ID_ATENDENTE", length = 10)
    private Integer idAtendente;
    
    @Column(name="LOGIN_ATENDENTE", length = 200)
    private String loginAtendente;
    
    @Column(name="ID_TELEFONIA", length = 20)
    private String idTelefonia;
    
    @Column(name="ID_EQUIPE", length = 10)
    private Integer idEquipe;
    
    @Column(name="NOME_EQUIPE", length = 200)
    private String nomeEquipe;
    
    @Column(name="ID_CONFIGURACAO_FILA", length = 10)
    private Integer idFila;
    
    @Column(name="NOME_FILA", length = 50)
    private String nomeFila;
    
    @Column(name="ID_ACAO", length = 10)
    private Integer idAcao;
    
    @Column(name="NOME_ACAO", length = 200)
    private String nomeAcao;
    
    @Column(name="SLA_MINUTOS", length = 19)
    private Long slaMinutos;
    
    @Column(name="ID_TIPO_CASO", length = 10)
    private Integer idTipoCaso;
    
    @Column(name="NOME_TIPO_CASO", length = 500)
    private String nomeTipoCaso;
    
    @Column(name="ID_ASSUNTO", length = 10)
    private Integer idAssunto;

    @Column(name="NOME_ASSUNTO", length = 500)
    private String nomeAssunto;

    @Column(name="ID_EVENTO", length = 10)
    private Integer idEvento;
    
    @Column(name="NOME_EVENTO", length = 500)
    private String nomeEvento;
    
    @Column(name="ID_CAUSA", length = 10)
    private Integer idCausaErro;
    
    @Column(name="NOME_CAUSA_ERRO", length = 200)
    private String nomeCausaErro;
    
    @Column(name="DATA_LOG")
    private Date dataLog;
    
    @Column(name="DATA_LOG_INICIO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataLogInicio;
    
    @Column(name="DATA_LOG_FIM")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataLogFim;
    
    /*@Column(columnName = "DATA_FIM_STATUS")
    private Date dataFimStatus;*/
    
    @Column(name="ID_STATUS", length = 10)
    private Integer idStatus;
    
    @Column(name="NOME_STATUS", length = 200)
    private String nomeStatus;
    
    @Column(name="DESCRICAO_ANDAMENTO")
    private String descricaoAndamento;
    
    @Column(name="NOME_ATENDENTE", length = 50)
    private String nomeAtendente;    
    
    @Column(name="FLAG_MANUAL")
    private boolean flagManual;
    
    @Column(name="FLAG_REABERTO")
    private boolean flagReaberto;
    
    @Column(name="DETALHE")
    private String detalhe;
    
    /**Sla definido na tabela TB_SLA_FILA*/
    @Column(name="SLA", length = 10)
    private Integer sla;
    
    @Column(name="SLA_PORCENTAGEM")
    private Double slaPorcentagem;
    
    @Override
    public Integer getPK() {
        return idHistoricoCaso;
    }

    @Override
    public final void setPK(Integer t) {
        this.idHistoricoCaso = t;
    }

    public final Integer getIdAtendente() {
        return idAtendente;
    }

    public final String getAgenciaConta() {
        return agenciaConta;
    }

    public final String getAgenciaDepartamento() {
        return agenciaDepartamento;
    }

    public final String getAssuntoSTGM() {
        return assuntoSTGM;
    }

    public final String getCartao() {
        return cartao;
    }

    public final String getCep() {
        return cep;
    }

    public final String getCpfCnpj() {
        return cpfCnpj;
    }

    public final Date getDataAbertura() {
        return dataAbertura == null ? null : new Date(dataAbertura.getTime());
    }

    public final Date getDataCadastro() {
        return dataCadastro == null ? null : new Date(dataCadastro.getTime());
    }

    public final Date getDataEncerramento() {
        return dataEncerramento == null ? null : new Date(dataEncerramento.getTime());
    }

    /*public final Date getDataFimStatus() {
        return dataFimStatus;
    }*/

    public final Date getDataInicioStatus() {
        return dataLog == null ? null : new Date(dataLog.getTime());
    }

    public final Date getDataUltimaAcao() {
        return dataUltimaAcao == null ? null : new Date(dataUltimaAcao.getTime());
    }

    public final String getDescricao() {
        return descricao;
    }

    public final String getDescricaoAndamento() {
        return descricaoAndamento;
    }

    public final String getEmail() {
        return email;
    }

    public final String getEndereco() {
        return endereco;
    }

    public final String getEnvioProtocoloCliente() {
        return envioProtocoloCliente;
    }

    public final String getGrupo() {
        return grupo;
    }

    public final Integer getIdAcao() {
        return idAcao;
    }

    public final Integer getIdAssunto() {
        return idAssunto;
    }

    public final Integer getIdCanal() {
        return idCanal;
    }

    public final Integer getIdCausaErro() {
        return idCausaErro;
    }

    public final Integer getIdEquipe() {
        return idEquipe;
    }

    public final Integer getIdEstado() {
        return idEstado;
    }

    public final Integer getIdEvento() {
        return idEvento;
    }

    public final Integer getIdFila() {
        return idFila;
    }

    public final Integer getIdHistoricoCaso() {
        return idHistoricoCaso;
    }

    public final Integer getIdStatus() {
        return idStatus;
    }

    public final String getIdTelefonia() {
        return idTelefonia;
    }

    public final Integer getIdTipoCaso() {
        return idTipoCaso;
    }

    public final String getLoginAtendente() {
        return loginAtendente;
    }

    public final String getManifestacao() {
        return manifestacao;
    }

    public final String getNomeAcao() {
        return nomeAcao;
    }

    public final String getNomeAssunto() {
        return nomeAssunto;
    }

    public final String getNomeCanal() {
        return nomeCanal;
    }

    public final String getNomeCausa() {
        return nomeCausa;
    }

    public final String getNomeCausaErro() {
        return nomeCausaErro;
    }

    public final String getNomeCliente() {
        return nomeCliente;
    }

    public final String getNomeEquipe() {
        return nomeEquipe;
    }

    public final String getNomeEstado() {
        return nomeEstado;
    }

    public final String getNomeEvento() {
        return nomeEvento;
    }

    public final String getNomeFila() {
        return nomeFila;
    }

    public final String getNomeStatus() {
        return nomeStatus;
    }

    public final String getNomeTipoCaso() {
        return nomeTipoCaso;
    }

    public final Long getSlaMinutos() {
        return slaMinutos;
    }

    public final String getSubGrupo() {
        return subGrupo;
    }

    public final String getTelefone() {
        return telefone;
    }

    public final String getTelefoneSegundo() {
        return telefoneSegundo;
    }

    public final String getTipoCartao() {
        return tipoCartao;
    }

    public final String getTipoManifestacao() {
        return tipoManifestacao;
    }

    public final String getUltimoAtendente() {
        return ultimoAtendente;
    }

    public final String getViaEntrada() {
        return viaEntrada;
    }

    public final void setIdAtendente(Integer idAtendente) {
        this.idAtendente = idAtendente;
    }

    public final void setAgenciaConta(String agenciaConta) {
        this.agenciaConta = agenciaConta;
    }

    public final void setAgenciaDepartamento(String agenciaDepartamento) {
        this.agenciaDepartamento = agenciaDepartamento;
    }

    public final void setAssuntoSTGM(String assuntoSTGM) {
        this.assuntoSTGM = assuntoSTGM;
    }

    public final void setCartao(String cartao) {
        this.cartao = cartao;
    }

    public final void setCep(String cep) {
        this.cep = cep;
    }

    public final void setCpfCnpj(String cpfCnpj) {
        this.cpfCnpj = cpfCnpj;
    }

    public final void setDataAbertura(Date dataAbertura) {
        this.dataAbertura = dataAbertura == null ? null : new Date(dataAbertura.getTime());
    }

    public final void setDataCadastro(Date dataCadastro) {
        this.dataCadastro = dataCadastro == null ? null : new Date(dataCadastro.getTime());
    }

    public final void setDataEncerramento(Date dataEncerramento) {
        this.dataEncerramento = dataEncerramento == null ? null : new Date(dataEncerramento.getTime());
    }

    public final void setDataLog(Date dataLog) {
        this.dataLog = dataLog == null ? null : new Date(dataLog.getTime());
    }

    public final void setDataUltimaAcao(Date dataUltimaAcao) {
        this.dataUltimaAcao = dataUltimaAcao == null ? null : new Date(dataUltimaAcao.getTime());
    }

    public final void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public final void setDescricaoAndamento(String descricaoAndamento) {
        this.descricaoAndamento = descricaoAndamento;
    }

    public final void setEmail(String email) {
        this.email = email;
    }

    public final void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public final void setEnvioProtocoloCliente(String envioProtocoloCliente) {
        this.envioProtocoloCliente = envioProtocoloCliente;
    }

    public final void setGrupo(String grupo) {
        this.grupo = grupo;
    }

    public final void setIdAcao(Integer idAcao) {
        this.idAcao = idAcao;
    }

    public final void setIdAssunto(Integer idAssunto) {
        this.idAssunto = idAssunto;
    }

    public final void setIdCanal(Integer idCanal) {
        this.idCanal = idCanal;
    }

    public final void setIdCausaErro(Integer idCausaErro) {
        this.idCausaErro = idCausaErro;
    }

    public final void setIdEquipe(Integer idEquipe) {
        this.idEquipe = idEquipe;
    }

    public final void setIdEstado(Integer idEstado) {
        this.idEstado = idEstado;
    }

    public final void setIdEvento(Integer idEvento) {
        this.idEvento = idEvento;
    }

    public final void setIdFila(Integer idFila) {
        this.idFila = idFila;
    }

    public final void setIdHistoricoCaso(Integer idHistoricoCaso) {
        this.idHistoricoCaso = idHistoricoCaso;
    }

    public final void setIdStatus(Integer idStatus) {
        this.idStatus = idStatus;
    }

    public final void setIdTelefonia(String idTelefonia) {
        this.idTelefonia = idTelefonia;
    }

    public final void setIdTipoCaso(Integer idTipoCaso) {
        this.idTipoCaso = idTipoCaso;
    }

    public final void setLoginAtendente(String loginAtendente) {
        this.loginAtendente = loginAtendente;
    }

    public final void setManifestacao(String manifestacao) {
        this.manifestacao = manifestacao;
    }

    public final void setNomeAcao(String nomeAcao) {
        this.nomeAcao = nomeAcao;
    }

    public final void setNomeAssunto(String nomeAssunto) {
        this.nomeAssunto = nomeAssunto;
    }

    public final void setNomeCanal(String nomeCanal) {
        this.nomeCanal = nomeCanal;
    }

    public final void setNomeCausa(String nomeCausa) {
        this.nomeCausa = nomeCausa;
    }

    public final void setNomeCausaErro(String nomeCausaErro) {
        this.nomeCausaErro = nomeCausaErro;
    }

    public final void setNomeCliente(String nomeCliente) {
        this.nomeCliente = nomeCliente;
    }

    public final void setNomeEquipe(String nomeEquipe) {
        this.nomeEquipe = nomeEquipe;
    }

    public final void setNomeEstado(String nomeEstado) {
        this.nomeEstado = nomeEstado;
    }

    public final void setNomeEvento(String nomeEvento) {
        this.nomeEvento = nomeEvento;
    }

    public final void setNomeFila(String nomeFila) {
        this.nomeFila = nomeFila;
    }

    public final void setNomeStatus(String nomeStatus) {
        this.nomeStatus = nomeStatus;
    }

    public final void setNomeTipoCaso(String nomeTipoCaso) {
        this.nomeTipoCaso = nomeTipoCaso;
    }

    public final void setSlaMinutos(Long slaMinutos) {
        this.slaMinutos = slaMinutos;
    }

    public final void setSubGrupo(String subGrupo) {
        this.subGrupo = subGrupo;
    }

    public final void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public final void setTelefoneSegundo(String telefoneSegundo) {
        this.telefoneSegundo = telefoneSegundo;
    }

    public final void setTipoCartao(String tipoCartao) {
        this.tipoCartao = tipoCartao;
    }

    public final void setTipoManifestacao(String tipoManifestacao) {
        this.tipoManifestacao = tipoManifestacao;
    }

    public final void setUltimoAtendente(String ultimoAtendente) {
        this.ultimoAtendente = ultimoAtendente;
    }

    public final void setViaEntrada(String viaEntrada) {
        this.viaEntrada = viaEntrada;
    }

    public final Integer getIdCaso() {
        return idCaso;
    }

    public final void setIdCaso(Integer idCaso) {
        this.idCaso = idCaso;
    }

    public final Date getDataFimSla() {
        return dataFimSla == null ? null : new Date(dataFimSla.getTime());
    }

    public final void setDataFimSla(Date dataFimSla) {
        this.dataFimSla = dataFimSla == null ? null : new Date(dataFimSla.getTime());
    }

    public final Integer getIdCasoSau() {
        return idCasoSau;
    }

    public final void setIdCasoSau(Integer idCasoSau) {
        this.idCasoSau = idCasoSau;
    }

    public final Integer getIdLog() {
        return idLog;
    }

    public final void setIdLog(Integer idLog) {
        this.idLog = idLog;
    }

    public final Date getDataLogFim() {
        return dataLogFim == null ? null : new Date(dataLogFim.getTime());
    }

    public final void setDataLogFim(Date dataLogFim) {
        this.dataLogFim = dataLogFim == null ? null : new Date(dataLogFim.getTime());
    }

    public final Date getDataLogInicio() {
        return dataLogInicio == null ? null : new Date(dataLogInicio.getTime());
    }

    public final void setDataLogInicio(Date dataLogInicio) {
        this.dataLogInicio = dataLogInicio == null ? null : new Date(dataLogInicio.getTime());
    }

    public String getNomeAtendente() {
        return nomeAtendente;
    }

    public void setNomeAtendente(String nomeAtendente) {
        this.nomeAtendente = nomeAtendente;
    }

    public Boolean getFlagManual() {
        return flagManual;
    }

    public void setFlagManual(Boolean flagManual) {
        this.flagManual = flagManual;
    }

    public boolean getFlagReaberto() {
        return flagReaberto;
    }

    public void setFlagReaberto(boolean flagReaberto) {
        this.flagReaberto = flagReaberto;
    }

    public String getDetalhe() {
        return detalhe;
    }

    public void setDetalhe(String detalhe) {
        this.detalhe = detalhe;
    }

	public Integer getSla() {
		return sla;
	}

	public void setSla(Integer sla) {
		this.sla = sla;
	}

	public Double getSlaPorcentagem() {
		return slaPorcentagem;
	}

	public void setSlaPorcentagem(Double slaPorcentagem) {
		this.slaPorcentagem = slaPorcentagem;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((idHistoricoCaso == null) ? 0 : idHistoricoCaso.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj){
			return true;
		}
		if (obj == null){
			return false;
		}
		if (getClass() != obj.getClass()){
			return false;
		}
		RelatorioHistoricoCaso other = (RelatorioHistoricoCaso) obj;
		if (idHistoricoCaso == null) {
			if (other.idHistoricoCaso != null){
				return false;
			}
		} else if (!idHistoricoCaso.equals(other.idHistoricoCaso)){
			return false;
		}
		return true;
	}

}
