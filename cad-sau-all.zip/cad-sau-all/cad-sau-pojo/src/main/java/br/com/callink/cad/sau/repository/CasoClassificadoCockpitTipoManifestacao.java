package br.com.callink.cad.sau.repository;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 *
 * @author brunomt
 */
public class CasoClassificadoCockpitTipoManifestacao {
    
    private String tipoManifestacao;
    private String nomeDiv;
    private List<CasoClassificadoCockpit> casoClassificacaoCockpitList;
    private Integer totalDentroPrazo;
    private Integer totalForaPrazo;
    private Double percentualTotalDentroPrazo;
    private Double percentualTotalForaPrazo;

    public CasoClassificadoCockpitTipoManifestacao() {
        totalDentroPrazo = 0;
        totalForaPrazo = 0;
        casoClassificacaoCockpitList = new ArrayList<CasoClassificadoCockpit>();
    }
    
    public List<CasoClassificadoCockpit> getCasoClassificacaoCockpitList() {
        return casoClassificacaoCockpitList;
    }

    private void setCasoClassificacaoCockpitList(List<CasoClassificadoCockpit> casoClassificacaoCockpitList) {
        this.casoClassificacaoCockpitList = casoClassificacaoCockpitList;
    }

    private void setPercentualTotalDentroPrazo(Double percentualTotalDentroPrazo) {
        this.percentualTotalDentroPrazo = percentualTotalDentroPrazo;
    }

    private void setPercentualTotalForaPrazo(Double percentualTotalForaPrazo) {
        this.percentualTotalForaPrazo = percentualTotalForaPrazo;
    }

    private void setTotalDentroPrazo(Integer totalDentroPrazo) {
        this.totalDentroPrazo = totalDentroPrazo;
    }

    private void setTotalForaPrazo(Integer totalForaPrazo) {
        this.totalForaPrazo = totalForaPrazo;
    }

    
    
    public Double getPercentualTotalDentroPrazo() {
        return percentualTotalDentroPrazo;
    }

    public Double getPercentualTotalForaPrazo() {
        return percentualTotalForaPrazo;
    }

    public String getTipoManifestacao() {
        return tipoManifestacao;
    }

    public Integer getTotalDentroPrazo() {
        return totalDentroPrazo;
    }

    public Integer getTotalForaPrazo() {
        return totalForaPrazo;
    }

    public void setTipoManifestacao(String tipoManifestacao) {
        this.tipoManifestacao = tipoManifestacao;
    }
    
    public void addCasoClassificaDentroPrazo(String assunto) {
        CasoClassificadoCockpit casoClassificadoCockpit = new CasoClassificadoCockpit();
        casoClassificadoCockpit.setAssunto(assunto);
        
        Integer index = casoClassificacaoCockpitList.indexOf(casoClassificadoCockpit);
        if (index >= 0) {
            casoClassificadoCockpit = casoClassificacaoCockpitList.get(index);
        } else {
            casoClassificacaoCockpitList.add(casoClassificadoCockpit);
        }
        
        casoClassificadoCockpit.addVolumeDentroPrazo();
        
        totalDentroPrazo++;
        calculaPercentual();
        
        ordenaList();
    }
    
    public void addCasoClassificaForaPrazo(String assunto) {
        CasoClassificadoCockpit casoClassificadoCockpit = new CasoClassificadoCockpit();
        casoClassificadoCockpit.setAssunto(assunto);
        
        Integer index = casoClassificacaoCockpitList.indexOf(casoClassificadoCockpit);
        if (index >= 0) {
            casoClassificadoCockpit = casoClassificacaoCockpitList.get(index);
        } else {
            casoClassificacaoCockpitList.add(casoClassificadoCockpit);
        }
        
        casoClassificadoCockpit.addVolumeForaPrazo();
        
        totalForaPrazo++;
        calculaPercentual();
        
        ordenaList();
    }
    
    public CasoClassificadoCockpitTipoManifestacao retornaObjetoTOP(Integer top) {
        CasoClassificadoCockpitTipoManifestacao casoClassificadoTOP = new CasoClassificadoCockpitTipoManifestacao(); 
        casoClassificadoTOP.setCasoClassificacaoCockpitList(new ArrayList<CasoClassificadoCockpit>());
        casoClassificadoTOP.setNomeDiv(this.nomeDiv);
        casoClassificadoTOP.setPercentualTotalDentroPrazo(this.percentualTotalDentroPrazo);
        casoClassificadoTOP.setPercentualTotalForaPrazo(this.percentualTotalForaPrazo);
        casoClassificadoTOP.setTipoManifestacao(this.tipoManifestacao);
        casoClassificadoTOP.setTotalDentroPrazo(this.totalDentroPrazo);
        casoClassificadoTOP.setTotalForaPrazo(this.totalForaPrazo);
        
        CasoClassificadoCockpit casoClassificadoCockpitOutros = null;
        
        Integer contadorTop = 0;
        for (CasoClassificadoCockpit casoClassificadoCockpit : this.getCasoClassificacaoCockpitList()) {
            if (contadorTop < top) {
                casoClassificadoTOP.getCasoClassificacaoCockpitList().add(casoClassificadoCockpit);
                contadorTop++;
            } else {
                if (casoClassificadoCockpitOutros == null) {
                    casoClassificadoCockpitOutros = new CasoClassificadoCockpit();
                    casoClassificadoCockpitOutros.setAssunto(CasoClassificadoCockpit.OUTROS);
                }
                casoClassificadoCockpitOutros.addCasoClassificaCockpit(casoClassificadoCockpit);
            }
        }
        
        if (casoClassificadoCockpitOutros != null) {
            casoClassificadoTOP.getCasoClassificacaoCockpitList().add(casoClassificadoCockpitOutros);
        }
        
        return casoClassificadoTOP;
    }
    
    public void calculaPercentual() {
        Integer total = totalDentroPrazo + totalForaPrazo;
        if (total != 0) {
            percentualTotalDentroPrazo = ((totalDentroPrazo.doubleValue() * Double.valueOf(100)) / total);
        } 
        if (total != 0) {
            percentualTotalForaPrazo = ((totalForaPrazo.doubleValue() * Double.valueOf(100)) / total);
        } 
    }

    private void ordenaList() {
        //ordenando a lista
        Collections.sort(casoClassificacaoCockpitList, new Comparator() {  
            public int compare(Object o1, Object o2) {  
                CasoClassificadoCockpit e1 = (CasoClassificadoCockpit) o1;  
                CasoClassificadoCockpit e2 = (CasoClassificadoCockpit) o2;  
                return e2.getVolumeTotal().compareTo(e1.getVolumeTotal());
//                return e1.getDataRelatorio().compareTo(e2.getDataRelatorio());  
            }  
        });
        Integer contador = 1;
        for(CasoClassificadoCockpit casoClassificadoCockpit : casoClassificacaoCockpitList) {
            casoClassificadoCockpit.setTop(contador);
            contador++;
        }
        
    }

    public String getNomeDiv() {
        return nomeDiv;
    }

    public void setNomeDiv(String nomeDiv) {
        this.nomeDiv = nomeDiv;
    }
     
    
}
