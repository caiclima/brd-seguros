package br.com.callink.cad.sau.repository;

import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.pojo.TipoManifestacao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

/**
 *
 * @author brunomt
 */
public final class CasosClassificadosCockpit {

	private CasosClassificadosCockpit(){
		
	}
	
    private static Map<String, CasoClassificadoCockpitTipoManifestacao> mapCasoClassificado;

    public static synchronized Map<String, CasoClassificadoCockpitTipoManifestacao> getMapCasoClassificado() {
        return mapCasoClassificado;
    }

    /**
     * Procedimento que gera os dados computados para o relatório Casos
     * Classificados O SLA deve ser enviado em MINUTOS
     *
     * @param casoSau
     * @param sla
     */
    public static synchronized void addRelatorioList(List<CasoSau> casoSauList, Integer sla) {
        mapCasoClassificado = new ConcurrentHashMap<String, CasoClassificadoCockpitTipoManifestacao>();

        if (casoSauList == null || casoSauList.isEmpty()) {
            return;
        }
        Integer contadorDiv = 0;
        for (CasoSau casoSau : casoSauList) {
            CasoClassificadoCockpitTipoManifestacao casoClassificadoCockpitTipoManifestacao = mapCasoClassificado.get(casoSau.getTipoManifestacao().getNome());
            if (casoClassificadoCockpitTipoManifestacao == null) {
                casoClassificadoCockpitTipoManifestacao = new CasoClassificadoCockpitTipoManifestacao();
                casoClassificadoCockpitTipoManifestacao.setTipoManifestacao(casoSau.getTipoManifestacao().getNome());
                casoClassificadoCockpitTipoManifestacao.setNomeDiv("divClassificaCasoGrafico" + contadorDiv);
                contadorDiv++;
            }

            if (casoSau.getCaso().getPorcentagemSla().compareTo(100d) > 0) {
                casoClassificadoCockpitTipoManifestacao.addCasoClassificaForaPrazo(casoSau.getEvento().getAssunto().getNome());
            } else {
                casoClassificadoCockpitTipoManifestacao.addCasoClassificaDentroPrazo(casoSau.getEvento().getAssunto().getNome());
            }

            getMapCasoClassificado().put(casoSau.getTipoManifestacao().getNome(), casoClassificadoCockpitTipoManifestacao);
        }

    }

    /**
     * Retorna o relatório computado por TOP (representa a quantidade de
     * assuntos ordenados pela quantidade de casos), e tipo de manifestação
     *
     * @param top
     * @param tipoManifestacaoList
     * @return
     */
    public static synchronized List<CasoClassificadoCockpitTipoManifestacao> retornaCasoClassificadoCockpit(Integer top, List<TipoManifestacao> tipoManifestacaoList) {
        if (top == null) {
            top = 1;
        }

        List<CasoClassificadoCockpitTipoManifestacao> casoClassificadoCockpitTipoManifestacaoList = new ArrayList<CasoClassificadoCockpitTipoManifestacao>();
        if (getMapCasoClassificado() != null) {
            for (Entry thisEntry : getMapCasoClassificado().entrySet()) {
                CasoClassificadoCockpitTipoManifestacao value = (CasoClassificadoCockpitTipoManifestacao) thisEntry.getValue();
                if (tipoManifestacaoList != null && !tipoManifestacaoList.isEmpty()) {
                    for (TipoManifestacao tipoManifestacao : tipoManifestacaoList) {
                        if (tipoManifestacao.getNome().equals(value.getTipoManifestacao())) {
                            casoClassificadoCockpitTipoManifestacaoList.add(value.retornaObjetoTOP(top));
                        }
                    }
                } else {
                    casoClassificadoCockpitTipoManifestacaoList.add(value.retornaObjetoTOP(top));
                }
            }
        }

        return casoClassificadoCockpitTipoManifestacaoList;
    }
}
