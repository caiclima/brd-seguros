package br.com.callink.cad.sau.command.caso;

import java.util.Map;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.pojo.Evento;
import br.com.callink.cad.sau.pojo.TipoManifestacao;
import br.com.callink.cad.sau.service.ICasoSauService;
import br.com.callink.cad.service.command.ICommand;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

@Stateless
public class ClassificaCasoSauCommand extends GenericSauCommand implements ICommand{

    private static final long serialVersionUID = -168488619009379821L;
    
    @EJB
    private ICasoSauService casoSauService;

    @Override
    public void execute(Map<String, Object> parametros) throws ServiceException, ValidationException {
        Evento evento = (Evento) parametros.get("evento");
        
        if (evento == null || evento.getIdEvento() == null) {
        	throw new ValidationException("Para classificar um caso o evento n\u00E3o pode ser nulo.");
        }
        
        TipoManifestacao tipoManifestacao = (TipoManifestacao) parametros.get("tipoManifestacao");
        CasoSau casoSau = (CasoSau) parametros.get("casoSau");
        
        casoSau.setEvento(evento);
        casoSau.setTipoManifestacao(tipoManifestacao);
        casoSauService.update(casoSau);
        casoSauService.flush();

    }

}
