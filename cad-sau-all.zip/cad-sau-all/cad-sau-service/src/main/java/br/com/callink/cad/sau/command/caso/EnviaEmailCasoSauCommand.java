/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.sau.command.caso;

import java.util.Map;
import java.util.Properties;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import org.apache.commons.lang.StringUtils;
import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.Email;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.pojo.Evento;
import br.com.callink.cad.sau.service.ICasoSauService;
import br.com.callink.cad.sau.util.EmailCasoSauUtil;
import br.com.callink.cad.service.IAssociaGrupoEmailService;
import br.com.callink.cad.service.ICasoService;
import br.com.callink.cad.service.IEmailService;
import br.com.callink.cad.service.IParametroGBOService;
import br.com.callink.cad.service.command.ICommand;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.util.Constantes;
import br.com.callink.cad.util.EmailUtils;
import br.com.callink.cad.util.PropertieUtils;

/**
 *
 * @author Luiz Gustavo Faria (luizgf@swb.com.br)
 */
@Stateless
public class EnviaEmailCasoSauCommand extends GenericSauCommand implements ICommand{

    private static final long serialVersionUID = 1L;
    
    @EJB
    private ICasoSauService casoSauService;
    @EJB
    private ICasoService casoService;
    @EJB
    private IAssociaGrupoEmailService associaGrupoEmailService;
    @EJB
    private IParametroGBOService parametroGBOService;
    @EJB
    private IEmailService emailService;
    
    @Override
    public void execute(Map<String, Object> parametros) throws ServiceException, ValidationException{
        
        Caso caso = (Caso) parametros.get("caso");
        Acao acao = (Acao) parametros.get("acao");
        Email email = (Email) parametros.get("email");
        Evento evento = (Evento) parametros.get("evento");
        
        /*
		 * Obtém os dados do atendente para montar a assinatura do email antes de fazer o load do caso.
		 * Pois se o caso estiver sendo classificado não há dados do atendente no banco, apenas na tela.
		 */
        Atendente atendente = caso.getAtendente();
        
        String assinatura = parametroGBOService.findByParam(Constantes.PARAMETRO_ASSINATURA_EMAIL).getValor();
        
        CasoSau casoSau = casoSauService.findCasoSauByCaso(caso);
        casoSau = casoSauService.load(casoSau);
        caso = casoService.load(caso);
        
        if (evento == null) {
        	evento = casoSau.getEvento();
        	
        	if (evento == null) {
        		throw new ValidationException("Não foi possível identificar um evento para o caso selecionado. Procure um supervisor.");
        	}
        	
        }
        
        if (atendente == null || StringUtils.isBlank(atendente.getNome())) {
            throw new ValidationException("É necessário cadastrar suas informações de contato para poder enviar emails. Procure um supervisor.");
        }
        
        email.setAssunto(EmailCasoSauUtil.getAssuntoEmail(casoSau.getManifestacao(), casoSau.getTipoManifestacao().getNome(), evento.getAssunto().getNome()));
        
        //se não for Email de Resposta, define o conteudo de acordo com o layout
        if (email.getPai() == null || email.getPai().getIdEmail() == null) {
            email.setConteudo(EmailCasoSauUtil.getCorpoEmail(email.getConteudo(), casoSau.getManifestacao(), casoSau.getDataAbertura(), evento.getAssunto().getNome(), evento.getNome()));
        } //se for email de resposta, não alterar conteudo e incluir RE: ao assunto
        else {
            email.setAssunto(EmailUtils.PREFIXO_ASSUNTO_EMAIL_RESPOSTA + email.getAssunto());
        }
        
        email.setConteudo(email.getConteudo() + EmailCasoSauUtil.getAssinatura(atendente.getNome(), atendente.getTelefone(), atendente.getRamal(), atendente.getFax(), assinatura));
        
        Properties props = PropertieUtils.getPropertieByNomeArquivo(Constantes.CAMINHO_ARQUIVO_PROPERTIES_CONFIGURACAO_TELA + Constantes.NOME_ARQUIVO_PROPERTIE);
        
        email.setRemetente(props.getProperty(Constantes.PARAMETRO_EMAIL_USUARIO));
        
        if (email.getListaDestinatarios() != null && !email.getListaDestinatarios().isEmpty()) {
            
            String destinatariosDosGrupos = associaGrupoEmailService.getDestinatariosFromListaGrupoEmail(email.getListaDestinatarios(), Boolean.FALSE);
            
            //ja possui destinario separado além da lista de grupos?
            if (!StringUtils.isBlank(email.getDestinatario())) {
                email.setDestinatario(email.getDestinatario() + Constantes.VIRGULA + Constantes.ESPACO + destinatariosDosGrupos);
            } else {
                email.setDestinatario(destinatariosDosGrupos);
            }
        }
        
        if (StringUtils.isBlank(email.getDestinatario())) {
            throw new ValidationException("Não há emails selecionado como destinatários.");
        }
        email.setFlagLido(Boolean.TRUE);
        emailService.envia(email, caso, acao);

        salvaMarcacaoAtendimento(parametros);
    }
}
