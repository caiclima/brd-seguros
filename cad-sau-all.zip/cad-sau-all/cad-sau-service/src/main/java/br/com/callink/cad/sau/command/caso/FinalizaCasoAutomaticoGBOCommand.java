package br.com.callink.cad.sau.command.caso;

import java.util.Map;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.pojo.Email;
import br.com.callink.cad.pojo.ParametroGBO;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.pojo.Causa;
import br.com.callink.cad.sau.pojo.Evento;
import br.com.callink.cad.sau.pojo.TipoManifestacao;
import br.com.callink.cad.sau.service.ICasoSauService;
import br.com.callink.cad.sau.service.IEventoCausaService;
import br.com.callink.cad.service.IParametroGBOService;
import br.com.callink.cad.service.command.ICommand;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.util.Constantes;

/**
 *
 * @author brunomt
 */
@Stateless
public class FinalizaCasoAutomaticoGBOCommand extends GenericSauCommand implements ICommand{

	private static final long serialVersionUID = 4285114667819670705L;
	
	@EJB
	private ICasoSauService casoSauService;
	
	@EJB
	private IEventoCausaService eventoCausaService;
	
	@EJB
	private IParametroGBOService parametroGBOService;
	
	@EJB(beanName="EnviaEmailCasoSauCommand")
	private ICommand enviaEmailCasoSauCommand;
	
	@EJB(beanName="FinalizaCasoGboCommand")
	private ICommand finalizaCasoGboCommand;

	@Override
    public void execute(Map<String, Object> parametros) throws ServiceException,ValidationException {
        Evento evento = (Evento) parametros.get("evento");
        CasoSau casoSau = (CasoSau) parametros.get("casoSau");
        
        if (evento == null || evento.getIdEvento() == null) {
        	throw new ValidationException("Para classificar um caso o evento n\u00E3o pode ser nulo.");
        }
        
        TipoManifestacao tipoManifestacao = (TipoManifestacao) parametros.get("tipoManifestacao");
        Boolean finalizaAutomatico = tipoManifestacao.getFlagFinalizaAutomatico() == null ? Boolean.FALSE : tipoManifestacao.getFlagFinalizaAutomatico();
        
        if (!finalizaAutomatico) {
        	finalizaAutomatico = evento.getFlagFinalizacaoAutomatica() == null ? Boolean.FALSE : evento.getFlagFinalizacaoAutomatica();
        }
        
        if (finalizaAutomatico) {
            if (StringUtils.isBlank(evento.getEmail())) {
                throw new ValidationException("O Evento n\u00E3o possui um e-mail cadastrado para finalização automatica. Favor solicitar a configura\u00E7\u00E3o.");
            }
            
            Causa causa = eventoCausaService.findCausaFinalizaAutomaticaByEvento(evento);
            if (causa == null) {
            	throw new ValidationException("Caso configurado para Finaliza\u00E7\u00E3o Autom\u00E1tia, mas n\u00E3o possui nenhuma causa vinculada. Favor solicitar configura\u00E7\u00E3o do sistema.");
            }
            ParametroGBO parametroGBO = parametroGBOService.findByParam(Constantes.PARAMETRO_CONTEUDO_EMAIL_FECHADO);
            
            if (parametroGBO == null || StringUtils.isBlank(parametroGBO.getValor())) {
                throw  new ValidationException("O parametro com o conteúdo do e-mail fechado automaticamente n\u00E3o está configurado. Favor solicitar a configura\u00E7\u00E3o.");
            }
            casoSau.setEvento(evento);
            casoSau.setCausa(causa);
            casoSauService.update(casoSau);
            
            Email email = new Email();
            email.setConteudo(parametroGBO.getValor());
            email.setDestinatario(evento.getEmail());
            email.setDestinatarioParaExibicao(evento.getEmail());
            email.setEmailSistema(Boolean.TRUE);
            parametros.put("email", email);
            enviaEmailCasoSauCommand.execute(parametros);
            
            parametros.put(Constantes.FINALIZAAUTOMATICO, Boolean.TRUE);
            finalizaCasoGboCommand.execute(parametros);
        }
        
    }
    
}
