package br.com.callink.cad.sau.command.caso;

import java.util.Map;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.inject.Inject;

import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.sau.dao.ICasoSauDAO;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.service.impl.GenericCadSauService;
import br.com.callink.cad.service.ITempoAtendimentoCasoService;
import br.com.callink.cad.service.command.ICommand;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 * Serviço generico para comandos herdarem, o comando obrigatoriamente deve
 * implementar a interface ICommand
 * 
 * @author rafaelps
 * 
 */
@Stateless
public abstract class GenericSauCommand extends GenericCadSauService<CasoSau, ICasoSauDAO> implements ICommand {
	
	private static final long serialVersionUID = 2329155923153559435L;
	
	@Inject
    private ICasoSauDAO casoSauDAO;
	
	@EJB
	private ITempoAtendimentoCasoService tempoAtendimentoCasoService;

	protected void salvaMarcacaoAtendimento(Map<String, Object> parametros)
			throws ServiceException {
		Caso caso = (Caso) parametros.get("caso");
		Acao acao = (Acao) parametros.get("acao");
		if (caso.getAtendente() != null
				&& caso.getAtendente().getIdAtendente() != null) {
			tempoAtendimentoCasoService.salvaMarcacaoAtendimento(caso, acao,
					caso.getAtendente(), Boolean.FALSE);
		}
	}
	
	@Inject
	protected ICasoSauDAO getDAO() {
		return casoSauDAO;
	}

	@Override
	protected void validarSave(CasoSau object) throws ValidationException {
	}

	@Override
	protected void validarUpdate(CasoSau object) throws ValidationException {
	}

	@Override
	protected void validarDelete(CasoSau object) throws ValidationException {
	}
}
