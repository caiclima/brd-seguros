package br.com.callink.cad.sau.command.caso;

import java.util.Map;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.service.ICasoSauService;
import br.com.callink.cad.service.command.ICommand;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

@Stateless
public class UpdateCasoSauCommand extends GenericSauCommand implements ICommand{

    private static final long serialVersionUID = -168488619009379821L;

    @EJB
    private ICasoSauService casoSauService; 
    
    @Override
    public void execute(Map<String, Object> parametros) throws ServiceException, ValidationException {
        CasoSau casoSau = (CasoSau) parametros.get("casoSau");
        casoSauService.update(casoSau);
    }
}
