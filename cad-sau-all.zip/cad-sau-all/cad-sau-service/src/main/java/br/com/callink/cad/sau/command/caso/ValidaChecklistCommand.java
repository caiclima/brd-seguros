package br.com.callink.cad.sau.command.caso;

import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.pojo.Checklist;
import br.com.callink.cad.sau.pojo.ResultadoChecklist;
import br.com.callink.cad.sau.service.IAssociaChecklistService;
import br.com.callink.cad.sau.service.ICasoSauService;
import br.com.callink.cad.sau.service.IResultadoChecklistService;
import br.com.callink.cad.service.command.ICommand;
import br.com.callink.cad.service.exception.ServiceException;

@Stateless
public class ValidaChecklistCommand extends GenericSauCommand implements ICommand{

	private static final long serialVersionUID = 7110429511824481845L;

	@EJB
	private ICasoSauService casoSauService;
	@EJB
	private IAssociaChecklistService associaChecklistService;
	@EJB
	private IResultadoChecklistService resultadoChecklistService;
	
	
	@Override
    public void execute(Map<String, Object> parametros) throws ServiceException {
        
        Acao acao = (Acao) parametros.get("acao");
        Caso caso = (Caso) parametros.get("caso");
        
        CasoSau casoSau = casoSauService.findCasoSauByCaso(caso);
        
        if(casoSau != null && casoSau.getIdCasoSau() != null && acao!= null && acao.getIdAcao()!= null ){
        	
             Checklist checklist =  associaChecklistService.getChecklist(casoSau.getEvento(),acao);
             
             if(checklist!= null && checklist.getIdChecklist()!= null){
            	 
            	 List<ResultadoChecklist>  resultados = resultadoChecklistService.buscaResultadoPorAgenteCasoSau(casoSau, casoSau.getEvento(), acao);
            	 
            	 if(resultados == null || resultados.isEmpty()){
            		 throw new ServiceException("Necess\u00E1rio preencher o checklist da a\u00E7\u00E3o selecionada!");
            	 }
             }
        }else{
        	throw new ServiceException("Necess\u00E1rio recarregar o chamado clicando em atender caso!");
        }
    }
}
