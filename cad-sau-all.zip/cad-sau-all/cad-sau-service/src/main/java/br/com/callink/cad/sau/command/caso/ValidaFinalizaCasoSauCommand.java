package br.com.callink.cad.sau.command.caso;

import java.util.Map;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.pojo.ParametroGBO;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.service.IResultadoQuestionarioService;
import br.com.callink.cad.service.IParametroGBOService;
import br.com.callink.cad.service.command.ICommand;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.util.Constantes;
import br.com.callink.cad.util.CpfCnpj;

/**
 * Valida se o CPF ou CNPJ do caso são válidos. Se não for válido o processo
 * retorna um exception.
 * 
 * @author brunomt
 * 
 */
@Stateless
public class ValidaFinalizaCasoSauCommand extends GenericSauCommand implements ICommand{
	private static final long serialVersionUID = 1L;

	@EJB
	private IParametroGBOService parametroGBOService;
	@EJB
	private IResultadoQuestionarioService resultadoQuestionarioService;
	
	@Override
	public void execute(Map<String, Object> parametros) throws ServiceException, ValidationException {
		CasoSau casoSau = (CasoSau) parametros.get("casoSau");

		Boolean cpfValido = CpfCnpj.isValidCPF(casoSau.getCpfCnpj());
		Boolean cnpjValido = CpfCnpj.isValidCNPJ(casoSau.getCpfCnpj());

		if (!cpfValido && !cnpjValido) {
			// Validar se o Evento permite finalizar com dados inválidos.

			ParametroGBO parametroGBO = parametroGBOService.findByParam(Constantes.ID_EVENTO_FINALIZA_CPF_CNPJ_INVALIDO);

			if (!(casoSau.getEvento() != null
					&& casoSau.getEvento().getIdEvento() != null && casoSau
					.getEvento().getIdEvento()
					.equals(Integer.valueOf(parametroGBO.getValor())))) {
				throw new ValidationException("O CPF/CNPJ do cliente est\u00E1 inv\u00E1lido. Favor corrigir o CPF/CNPJ para finalizar o caso.");
			}
		}

		if (StringUtils.isBlank(casoSau.getCartao())) {
			throw new ValidationException("O dado Cart\u00E3o do cliente n\u00E3o foi preenchido.");
		}

		resultadoQuestionarioService.validaPreenchimentoQuestionario(casoSau);
	}

}
