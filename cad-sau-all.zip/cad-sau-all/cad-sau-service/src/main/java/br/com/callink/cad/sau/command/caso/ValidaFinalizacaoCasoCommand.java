package br.com.callink.cad.sau.command.caso;

import java.util.Date;
import java.util.Map;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import org.apache.commons.lang.math.NumberUtils;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.service.ICasoSauService;
import br.com.callink.cad.service.ICasoService;
import br.com.callink.cad.service.ILogLigacoesService;
import br.com.callink.cad.service.ITelefoneService;
import br.com.callink.cad.service.command.GenericCommandService;
import br.com.callink.cad.service.command.ICommand;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

@Stateless
public class ValidaFinalizacaoCasoCommand extends GenericCommandService implements ICommand {

	private static final long serialVersionUID = -4694480624617832426L;

	@EJB
	private ICasoService casoService;
	@EJB
	private ICasoSauService casoSauService;
	@EJB
	private ILogLigacoesService logLigacoesService;
	@EJB
	private ITelefoneService telefoneService;

	@Override
	public void execute(Map<String, Object> parametros) throws ServiceException, ValidationException {
		try {
			Caso caso = (Caso) parametros.get("caso");
			
			if (caso == null || caso.getIdCaso() == null) {
				throw new IllegalArgumentException("Parametro 'Caso' obrigat\u00F3rio!");
			}
			
			if (! parametros.containsKey("tipoManifestacaoExigeContato")) {
				throw new IllegalArgumentException("Parametro 'tipoManifestacaoExigeContato' obrigat\u00F3rio!");
			}
			
			if (! parametros.containsKey("exigeContatoComSucesso")) {
				throw new IllegalArgumentException("Parametro 'exigeContatoComSucesso' obrigat\u00F3rio!");
			}
			
			if (! parametros.containsKey("percentualMinimoSla")) {
				throw new IllegalArgumentException("Parametro 'percentualMinimoSla' obrigat\u00F3rio!");
			}
			
			String tipoManifestacaoExigeContato = (String) parametros.get("tipoManifestacaoExigeContato");
			Boolean exigeContatoComSucesso = Boolean.valueOf((String) parametros.get("exigeContatoComSucesso"));
			Double percentualMinimoSla = Double.valueOf((String) parametros.get("percentualMinimoSla"));

			/*
			 * Busca caso
			 */
			Caso casoFound = casoService.findByPk(caso);
			casoFound.setPorcentagemSla(casoFound.getPorcentagemSla() == null ? 0d : casoFound.getPorcentagemSla());
			
			/*
			 * Busca caso sau
			 */
			CasoSau casoSau = casoSauService.findCasoSauByCaso(casoFound);
			final Integer idTipoCaso = casoSau.getTipoManifestacao().getIdTipoCaso();
			boolean tipoExigeContato = false;
			
			String[] tiposCaso = tipoManifestacaoExigeContato.split(",");
			
			for (String id : tiposCaso) {
				if(! NumberUtils.isNumber(id.trim())){
					throw new IllegalArgumentException("Parametro 'tipoManifestacaoExigeContato' deve ser uma sequência de ID's separados por vírgula!");
				}
				
				if(idTipoCaso.equals(Integer.valueOf(id.trim()))){
					tipoExigeContato = true;
					break;
				}
			}
			
			/*
			 * Se o tipo de caso NÃO exige contato
			 */
			if(! tipoExigeContato){
				return;
			}
			
			boolean houveContato = logLigacoesService.existeTentativaDeContatoPorCaso(casoFound);

			/*
			 * Se NÃO houve tentativas de contato
			 */
			if (! houveContato) {
				throw new ValidationException("Não é possível finalizar o caso, pois não houve nenhuma tentativa de contato!");
			}
			
			houveContato = telefoneService.existeContatoNaoTabulado(casoFound);
			
			/*
			 * Se há algum contato não tabulado
			 */
			if(houveContato){
				throw new ValidationException("Não é possível finalizar o caso, pois há um contato não tabulado!");
			}

			final boolean alcancouSlaMinimo = casoFound.getPorcentagemSla() >= percentualMinimoSla;

			/*
			 * Se o caso NÃO alcançou o percentual minimo do SLA
			 */
			if (! alcancouSlaMinimo) {
				throw new ValidationException("Não é possível finalizar o caso, pois o SLA mínimo exigido não foi atingido!");
			}

			/*
			 * Se a ação exige contato com sucesso para finalizar
			 */
			if (exigeContatoComSucesso) {
				houveContato = logLigacoesService.existeContatoComSucessoPorCaso(casoFound);
				
				/*
				 * Se a ação exige contato com sucesso para finalizar MAS NÃO houve contato com sucesso
				 */
				if (! houveContato) {
					throw new ValidationException("Não é possível finalizar o caso, pois não houve nenhum contato com sucesso!");
				}
				
			}else{
				
				houveContato = logLigacoesService.existeTentativaDeContatoParaTodosTelefonesPorCasoEData(casoFound, new Date());

				/*
				 * Se NÃO houve tentativa de contato para todos os telefones na data atual 
				 */
				if (! houveContato) {
					throw new ValidationException("Não é possível finalizar o caso, pois não houve tentativas de contato para todos telefones no dia atual!");
				}
			}

		} catch (ServiceException e) {
			throw new ServiceException(e);
		}
	}
}
