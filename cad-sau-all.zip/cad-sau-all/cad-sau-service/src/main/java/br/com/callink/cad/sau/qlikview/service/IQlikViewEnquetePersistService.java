package br.com.callink.cad.sau.qlikview.service;

import java.util.List;

import br.com.callink.cad.sau.dao.qlikview.IQlikViewEnqueteDAO;
import br.com.callink.cad.sau.qlikview.pojo.QlikViewEnquete;
import br.com.callink.cad.service.IGenericGboService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

public interface IQlikViewEnquetePersistService extends IGenericGboService<QlikViewEnquete, IQlikViewEnqueteDAO>{
    
    /**
     * Persist dados relatorio
     * 
     * @param relatorioList
     * @throws ServiceException
     * @throws ValidationException
     */
	void persistDadosRelatorio(List<QlikViewEnquete> relatorioList) throws ServiceException, ValidationException;
	
	
	/**
	 * Limpa todos os dados
	 * 
	 * @throws ServiceException
	 * @throws ValidationException
	 */
	void lipaDadosQlikViewEnquete() throws ServiceException, ValidationException;
}