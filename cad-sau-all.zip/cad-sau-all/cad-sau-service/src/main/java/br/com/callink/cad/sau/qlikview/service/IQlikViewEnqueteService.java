/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.sau.qlikview.service;

import java.util.Date;

import br.com.callink.cad.sau.dao.qlikview.IQlikViewEnqueteDAO;
import br.com.callink.cad.sau.qlikview.pojo.QlikViewEnquete;
import br.com.callink.cad.service.IGenericGboService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 *
 * @author ubuntu
 */
public interface IQlikViewEnqueteService extends IGenericGboService<QlikViewEnquete, IQlikViewEnqueteDAO> {
    /**
     * 
     * @param data1
     * @param data2
     * @throws ServiceException 
     * @throws ValidationException 
     */
    void geraNuvemEnquetesBetweenDatas(Date data1, Date data2) throws ServiceException, ValidationException;

    /**
     * 
     * @throws ServiceException 
     * @throws ValidationException 
     */
    void geraNuvemPeloParametro() throws ServiceException, ValidationException;
    
    void geraNuvemEnquetesOntem() throws ServiceException, ValidationException;

    void lipaDadosQlikViewEnquete() throws ServiceException;
    
        /**
     * busca quando foi a ultima vez que o relatorio rodou
     * @return
     * @throws ServiceException 
     */
    Date getDataUltimoRelatorio() throws ServiceException;
    
    /**
     * atualiza a data da ultima geraçao do relatorio para a data atual (tabela parametros gbo)
     * @throws ServiceException 
     * @throws ValidationException 
     */
    void atualizaDataUltimoRelatorio() throws ServiceException, ValidationException;
}
