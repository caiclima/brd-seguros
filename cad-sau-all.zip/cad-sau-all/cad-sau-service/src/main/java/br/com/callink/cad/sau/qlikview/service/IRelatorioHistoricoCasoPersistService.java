package br.com.callink.cad.sau.qlikview.service;

import java.util.List;

import br.com.callink.cad.sau.dao.qlikview.IRelatorioHistoricoCasoDAO;
import br.com.callink.cad.sau.qlikview.pojo.RelatorioHistoricoCaso;
import br.com.callink.cad.service.IGenericGboService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

public interface IRelatorioHistoricoCasoPersistService extends IGenericGboService<RelatorioHistoricoCaso, IRelatorioHistoricoCasoDAO>{
    
    /**
     * Persist dados relatorio
     * 
     * @param relatorioList
     * @throws ServiceException
     * @throws ValidationException
     */
	void persistDadosRelatorio(List<RelatorioHistoricoCaso> relatorioList) throws ServiceException, ValidationException;
	
	
	/**
	 * Limpa todos os dados
	 * 
	 * @throws ServiceException
	 * @throws ValidationException
	 */
	void deleteAll() throws ServiceException, ValidationException;
}