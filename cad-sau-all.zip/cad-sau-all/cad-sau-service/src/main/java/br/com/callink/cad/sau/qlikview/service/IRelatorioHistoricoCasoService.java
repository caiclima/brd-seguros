package br.com.callink.cad.sau.qlikview.service;

import java.util.Date;

import br.com.callink.cad.sau.dao.qlikview.IRelatorioHistoricoCasoDAO;
import br.com.callink.cad.sau.qlikview.pojo.RelatorioHistoricoCaso;
import br.com.callink.cad.service.IGenericGboService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

public interface IRelatorioHistoricoCasoService extends IGenericGboService<RelatorioHistoricoCaso, IRelatorioHistoricoCasoDAO>{
    
    /**
     *gera o relatorio dos historicos dos casos que sofreram alteraçao desde certa data
     * @throws ServiceException 
     * @throws ValidationException 
     */
    int gerarHistoricos(Date dataUltimaAlteracao, Date dataFim) throws ServiceException, ValidationException;
    
    /**
     * busca quando foi a ultima vez que o relatorio rodou
     * @return
     * @throws ServiceException 
     */
    Date getDataUltimoRelatorio() throws ServiceException;
    
    /**
     * atualiza a data da ultima geraçao do relatorio para a data atual (tabela parametros gbo)
     * @throws ServiceException 
     * @throws ValidationException 
     */
    void atualizaDataUltimoRelatorio() throws ServiceException, ValidationException;
}