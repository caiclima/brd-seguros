package br.com.callink.cad.sau.qlikview.service;

import java.util.List;

import br.com.callink.cad.sau.dao.qlikview.IRelatorioUltimaTratativaCasoDAO;
import br.com.callink.cad.sau.qlikview.pojo.RelatorioUltimaTratativaCaso;
import br.com.callink.cad.service.IGenericGboService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

public interface IRelatorioUltimaTratativaCasoPersistService extends IGenericGboService<RelatorioUltimaTratativaCaso, IRelatorioUltimaTratativaCasoDAO>{
    
    /**
     * Persist dados relatorio
     * 
     * @param relatorioList
     * @throws ServiceException
     * @throws ValidationException
     */
	void persistDadosRelatorio(List<RelatorioUltimaTratativaCaso> relatorioList) throws ServiceException, ValidationException;
	
	
	/**
	 * Limpa todos os dados
	 * 
	 * @throws ServiceException
	 * @throws ValidationException
	 */
	void deleteAll() throws ServiceException, ValidationException;
}