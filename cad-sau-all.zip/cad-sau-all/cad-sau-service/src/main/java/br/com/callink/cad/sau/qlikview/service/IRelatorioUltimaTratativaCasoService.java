package br.com.callink.cad.sau.qlikview.service;

import java.util.Date;

import br.com.callink.cad.sau.dao.qlikview.IRelatorioUltimaTratativaCasoDAO;
import br.com.callink.cad.sau.qlikview.pojo.RelatorioUltimaTratativaCaso;
import br.com.callink.cad.sau.service.IGenericCadSauService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

public interface IRelatorioUltimaTratativaCasoService extends IGenericCadSauService<RelatorioUltimaTratativaCaso, IRelatorioUltimaTratativaCasoDAO>{
    
    /**
     *gera o relatorio dos historicos dos casos que sofreram alteraçao desde certa data
     * @throws ServiceException 
     * @throws ValidationException 
     */
    void gerarHistoricos(Date dataUltimaAlteracao) throws ServiceException, ValidationException;
    
    /**
     * busca quando foi a ultima vez que o relatorio rodou
     * @return
     * @throws ServiceException 
     */
    Date getDataUltimoRelatorio() throws ServiceException;
    
    /**
     * atualiza a data da ultima geraçao do relatorio para a data atual (tabela parametros gbo)
     * @throws ServiceException 
     * @throws ValidationException 
     */
    void atualizaDataUltimoRelatorio() throws ServiceException, ValidationException;
}