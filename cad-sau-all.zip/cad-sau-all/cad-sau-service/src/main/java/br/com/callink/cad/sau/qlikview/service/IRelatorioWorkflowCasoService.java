/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.sau.qlikview.service;

import java.util.Date;

import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 *
 * @author Luiz Gustavo F. (luizgf@swb.com.br)
 */
public interface IRelatorioWorkflowCasoService {
    
    void dropTable() throws ServiceException;
    void geraRelatorio(Date data) throws ServiceException;
    Date getDataUltimoRelatorio() throws ServiceException;
    void atualizaDataUltimoRelatorio() throws ServiceException, ValidationException;
    
}
