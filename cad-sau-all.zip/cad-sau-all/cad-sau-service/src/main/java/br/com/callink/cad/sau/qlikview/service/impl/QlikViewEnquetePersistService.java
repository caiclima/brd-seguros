package br.com.callink.cad.sau.qlikview.service.impl;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ejb.EJB;
import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.inject.Inject;

import br.com.callink.cad.sau.dao.qlikview.IQlikViewEnqueteDAO;
import br.com.callink.cad.sau.qlikview.pojo.QlikViewEnquete;
import br.com.callink.cad.sau.qlikview.service.IQlikViewEnquetePersistService;
import br.com.callink.cad.service.ISlaService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.service.impl.GenericGboService;

@Stateless
@Local(IQlikViewEnquetePersistService.class)
public class QlikViewEnquetePersistService extends GenericGboService<QlikViewEnquete, IQlikViewEnqueteDAO> implements IQlikViewEnquetePersistService {

    private static final long serialVersionUID = 5794476028670209602L;
    
    private Logger logger = Logger.getLogger(QlikViewEnquetePersistService.class.getName());
    
    @EJB(beanName="SlaTipoFilaService")
    private ISlaService slaService;
    
    @Inject
    private IQlikViewEnqueteDAO qlikViewEnqueteDAO;
    
    
    @Override
	protected IQlikViewEnqueteDAO getDAO() {
		return qlikViewEnqueteDAO;
	}
    
    public void lipaDadosQlikViewEnquete() throws ServiceException, ValidationException {
    	try {
    		getDAO().lipaDadosQlikViewEnquete();
    	} catch (Exception e) {
    		logger.log(Level.SEVERE, "Erro ao limpar tabela de historico dos casos.", e);
		}
    }
        
    public void persistDadosRelatorio(List<QlikViewEnquete> relatorioList) throws ServiceException, ValidationException {
    	
    	for(QlikViewEnquete registro : relatorioList) {
	    	try {
	    		
        	    getDAO().save(registro);
	        	    
	    	} catch (Exception e) {
	    		logger.log(Level.SEVERE, "Erro ao limpar tabela de historico dos casos.", e);
			}
    	}
    }
}
