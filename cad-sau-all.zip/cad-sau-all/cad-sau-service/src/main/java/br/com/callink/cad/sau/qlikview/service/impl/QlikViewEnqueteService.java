/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.sau.qlikview.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import br.com.callink.cad.pojo.LogTask;
import br.com.callink.cad.pojo.ParametroGBO;
import br.com.callink.cad.sau.dao.qlikview.IQlikViewEnqueteDAO;
import br.com.callink.cad.sau.qlikview.pojo.QlikViewEnquete;
import br.com.callink.cad.sau.qlikview.service.IQlikViewEnquetePersistService;
import br.com.callink.cad.sau.qlikview.service.IQlikViewEnqueteService;
import br.com.callink.cad.sau.util.ConstantesSau;
import br.com.callink.cad.service.ILogTaskService;
import br.com.callink.cad.service.IParametroGBOService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.service.impl.GenericGboService;
import br.com.callink.cad.util.Constantes;

/**
 *
 * @author ubuntu
 */
@Stateless
public class QlikViewEnqueteService extends GenericGboService<QlikViewEnquete, IQlikViewEnqueteDAO> implements IQlikViewEnqueteService {

	private static final long serialVersionUID = -6785950710228664482L;
	private Logger logger = Logger.getLogger(QlikViewEnqueteService.class.getName());
	@Inject
	private IQlikViewEnqueteDAO qlikViewEnqueteDAO;
	
	@EJB
	private IParametroGBOService parametroGBOService;
	
	@EJB
	private ILogTaskService logTaskService;
	
	@EJB
	private IQlikViewEnquetePersistService qlikViewEnquetePersistService;
	
	@Override
	protected IQlikViewEnqueteDAO getDAO() {
		return qlikViewEnqueteDAO;
	}
	
    @Override
    @TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
    public void geraNuvemEnquetesBetweenDatas(Date data1, Date data2) throws ServiceException, ValidationException {
		ParametroGBO parametroGBO = null;
    	
        try {
        	LogTask logTask = new LogTask();
        	logTask.setDataInicial(getDataBanco());
        	logTask.setMnmExecutor(ConstantesSau.PARAM_SEMAFORO_ENQUETE);
        	
			parametroGBO = parametroGBOService.findByParam(ConstantesSau.PARAM_SEMAFORO_ENQUETE);
			
			if (parametroGBO == null || parametroGBO.getIdParametroGBO() == null) {
				throw new ValidationException("Não foi possível identificar o parametro GBO ULTIMA_TRATATIVA. Favor cadastrar o mesmo.");
			}
			
			if (!Boolean.valueOf(parametroGBO.getValor())) {
				throw new ValidationException("O sinalizador de execução está informando que já existe um processo sendo executado. Aguarde o processo ou mude o parametro semaforoEnquete para true.");
			}
			
			atualizaDataUltimoRelatorio();
			
			parametroGBO.setValor(Constantes.FALSE);
			parametroGBOService.update(parametroGBO);
			
        	lipaDadosQlikViewEnquete();
        	
            List<QlikViewEnquete> dados =  getRelatorio(data1, data2);
            
            if (dados != null && !dados.isEmpty()) {
            	logTask.setTotalRegistros(dados.size());

            	int contPersistDadosRelatorio = 1;
            	List<QlikViewEnquete> relatorioListPersist = new ArrayList<QlikViewEnquete>();
            	
                for (QlikViewEnquete salv : dados) {
                    
                	relatorioListPersist.add(salv);
                	if(contPersistDadosRelatorio >= 500) {
                		qlikViewEnquetePersistService.persistDadosRelatorio(relatorioListPersist);
                		
                		contPersistDadosRelatorio = 1;
                		relatorioListPersist = new ArrayList<QlikViewEnquete>();
                	} else {
                		contPersistDadosRelatorio ++;
                	}
                	
                }
                
                if(relatorioListPersist != null && !relatorioListPersist.isEmpty() ) {
                	qlikViewEnquetePersistService.persistDadosRelatorio(relatorioListPersist);
                }
                
            } else {
            	logTask.setTotalRegistros(Integer.valueOf(0));
            }
            
            
            logTask.setDataFinal(getDataBanco());
            logTaskService.save(logTask);

			parametroGBO.setValor(Constantes.TRUE);
			parametroGBOService.update(parametroGBO);
        } catch (Exception ex) {
            throw new ServiceException("Erro ao gerar nuvem",ex);
        }
    }
    
    private List<QlikViewEnquete> getRelatorio(Date data1, Date data2) throws ServiceException {
    	try {
    	return getDAO().geraNuvemEnquetesBetweenDatas(data1, data2);
    	} catch (Exception e) {
    		throw new ServiceException("Erro ao buscar nuvem Enquete",e);
    	}
        
    }
    
    @Override
    @TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
    public void geraNuvemPeloParametro() throws ServiceException, ValidationException {
    	logger.info("QlikViewEnqueteService - INICIO Executa relatorio enquete.");
        Date dataUltimo = getDataUltimoRelatorio();
        
    	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    	
    	try {
    		if (!dateFormat.parse(dateFormat.format(dataUltimo))
    				.before(dateFormat.parse(dateFormat.format(getDataBanco())))) {
    			dataUltimo = dateFormat.parse(dateFormat.format(getDataBanco()));
    		}
        } catch (ParseException ex) {
        	throw new ServiceException("Erro ao fazer parse da data ", ex);
        }
        
        
        
        geraNuvemEnquetesBetweenDatas(dataUltimo, getDataBanco());
        logger.info("QlikViewEnqueteService - FIM Executa relatorio enquete.");
    }
    
    private ParametroGBO getParametroGBOUltimaExecucao() throws ServiceException {
        try {
            return parametroGBOService.findByParam("executourelatorioenquete");
        } catch (ServiceException e) {
            throw new ServiceException("Erro ao buscar data da ultima execucao do relatorio Qlikview", e);
        }
    }
    
    @Override
    public void atualizaDataUltimoRelatorio() throws ServiceException, ValidationException {
        ParametroGBO ultimaExecucao = getParametroGBOUltimaExecucao();
        ultimaExecucao.setValor("OK");
        parametroGBOService.update(ultimaExecucao);
    }

    @Override
    public Date getDataUltimoRelatorio() throws ServiceException {
        return getParametroGBOUltimaExecucao().getDataAlteracao();
    }
    
    @Override
    @TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
    public void geraNuvemEnquetesOntem() throws ServiceException, ValidationException {
        Date dataFim = getDataBanco();
        Calendar cal = Calendar.getInstance();
        cal.setTime(dataFim);
        cal.add(Calendar.DAY_OF_MONTH, -1);
        Date dataInicio = cal.getTime();
        geraNuvemEnquetesBetweenDatas(dataInicio, dataFim);
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
    public void lipaDadosQlikViewEnquete() throws ServiceException {
        try {
        	qlikViewEnquetePersistService.lipaDadosQlikViewEnquete();
        } catch (Exception ex) {
            throw new ServiceException(ex);
        }
    }

}
