package br.com.callink.cad.sau.qlikview.service.impl;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.inject.Inject;
import javax.transaction.UserTransaction;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.pojo.LogTask;
import br.com.callink.cad.pojo.ParametroGBO;
import br.com.callink.cad.sau.dao.qlikview.IRelatorioHistoricoCasoDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.qlikview.pojo.RelatorioHistoricoCaso;
import br.com.callink.cad.sau.qlikview.service.IRelatorioHistoricoCasoPersistService;
import br.com.callink.cad.sau.qlikview.service.IRelatorioHistoricoCasoService;
import br.com.callink.cad.sau.util.ConstantesSau;
import br.com.callink.cad.service.ILogTaskService;
import br.com.callink.cad.service.IParametroGBOService;
import br.com.callink.cad.service.ISlaService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.service.impl.GenericGboService;

@Stateless
@TransactionManagement(TransactionManagementType.BEAN)
public class RelatorioHistoricoCasoService extends GenericGboService<RelatorioHistoricoCaso, IRelatorioHistoricoCasoDAO> implements IRelatorioHistoricoCasoService {

    private static final long serialVersionUID = 5794476028670209602L;
    private Logger logger = Logger.getLogger(RelatorioHistoricoCasoService.class.getName());
    
    @Inject
    private IRelatorioHistoricoCasoDAO relatorioHistoricoCasoDAO;
    
    @EJB
    private IParametroGBOService parametroGBOService;
    
    @EJB(beanName="SlaTipoFilaService")
    private ISlaService slaService;
    
    @EJB
    private IRelatorioHistoricoCasoPersistService relatorioHistoricoCasoPersistService;
    
    @EJB
    private ILogTaskService logTaskService;
    
    @Resource
    private UserTransaction tx;
    
    @Override
	protected IRelatorioHistoricoCasoDAO getDAO() {
		return relatorioHistoricoCasoDAO;
	}
    
    @Override
    public int gerarHistoricos(Date dataUltimaAlteracao, Date dataFim) throws ServiceException, ValidationException {
    	return verificaDataHoje(dataUltimaAlteracao, dataFim);
    }

    public int verificaDataHoje(Date dataUltimaAlteracao, Date dataFim) throws ServiceException, ValidationException {
    	Date dataHoje = new Date();
    	
		if (!dataUltimaAlteracao.before(dataHoje)) {
        	dataUltimaAlteracao = dataHoje;
		}
    	
        return gerarRelatorio(dataUltimaAlteracao, dataFim);
    }
    
	private int gerarRelatorio(Date dataUltimaAlteracao, Date dataFim) throws ServiceException, ValidationException {
		ParametroGBO parametroGBO = null;

		LogTask logTask = new LogTask();
		logTask.setDataInicial(getDataBanco());
		logTask.setMnmExecutor(ConstantesSau.PARAM_SEMAFORO_HISTORICO_CASO);

		begin();

		try {
			parametroGBO = parametroGBOService.findByParam(ConstantesSau.PARAM_SEMAFORO_HISTORICO_CASO);

			verificarAtualizarSemaforo(parametroGBO);
			//relatorioHistoricoCasoPersistService.deleteAll();
			atualizaDataUltimoRelatorio();
		} catch (Exception e) {
			rollback();
			throw new ServiceException("Erro ao efetuar operacao.", e);
		}

		commit();

		Date dataInicioIntervalo = new Date();
		dataInicioIntervalo.setTime(dataUltimaAlteracao.getTime());
		Date dataFimIntervalo = addHour(dataUltimaAlteracao, 1);
		
		int total = 0;
		Date dataInicioTemp = new Date();
		
		while(true){
			List<RelatorioHistoricoCaso> relatorioList = getRelatorios(dataInicioIntervalo, dataFimIntervalo);
			
			if (relatorioList != null) {
				total = relatorioList.size();
				
				begin();
				salvarRelatorio(relatorioList);
				commit();
			}
			
			dataInicioIntervalo.setTime(dataFimIntervalo.getTime());
			dataInicioTemp.setTime(dataFimIntervalo.getTime());
			dataFimIntervalo = addHour(dataFimIntervalo, 1);
			
			if(dataFimIntervalo.getTime() >= dataFim.getTime()){
				relatorioList = getRelatorios(dataInicioTemp, dataFim);
				
				if (relatorioList != null) {
					total = relatorioList.size();
					
					begin();
					salvarRelatorio(relatorioList);
					commit();
				}
				
				break;
			}
			
		}

		try {
			begin();
			logTask.setTotalRegistros(total);
			logTask.setDataFinal(getDataBanco());

			logTaskService.save(logTask);
			parametroGBO.setValor(ConstantesSau.TRUE);
			parametroGBOService.update(parametroGBO);
			commit();
		} catch (Exception e) {
			rollback();
			throw new ServiceException(
					"Erro ao alterar o semaforo ULTIMA_TRATATIVA", e);
		}

		return total;

	}

    private void salvarRelatorio(List<RelatorioHistoricoCaso> relatorioList){
    	int count = 1;
		Long slaRegistro = null;

		for (RelatorioHistoricoCaso registro : relatorioList) {
			try {

				if (slaRegistro == null	|| (!relatorioList.get(relatorioList.indexOf(registro) - 1).getManifestacao().equals(registro.getManifestacao()))) {
					slaRegistro = slaService.calculaSlaInterValo(registro.getDataAbertura(),registro.getDataEncerramento() != null ?
																					registro.getDataEncerramento()	: getDataBanco());
				}

				registro.setSlaMinutos(slaRegistro);

				if (slaRegistro != null) {
					registro.setSlaPorcentagem(slaService.calcularPorcentagem(Double.valueOf(registro.getSla() * 60), slaRegistro));
				}

				if (StringUtils.isBlank(registro.getLoginAtendente())) {
					registro.setDataLogFim(registro.getDataLogInicio());
				}
				
				getDAO().apagarPorIdLog(registro.getIdLog());
				getDAO().save(registro);

				if (count % 500 == 0) {
					commit();
					begin();
				}

				count++;
			}catch (Exception e) {
				logger.log(Level.SEVERE, "Erro ao salvar registro relatório historico caso.", e);
			}
		}
		
		relatorioList.clear();
		
	}

	private void verificarAtualizarSemaforo(ParametroGBO parametroGBO) throws ServiceException, ValidationException{
    	if (parametroGBO == null || parametroGBO.getIdParametroGBO() == null) {
			throw new ServiceException("Não foi possível identificar o parametro GBO HISTORICO_CASO. Favor cadastrar o mesmo.");
		}
		
		if (!Boolean.valueOf(parametroGBO.getValor())) {
			throw new ValidationException("O sinalizador de execução está informando que já existe um processo sendo executado. Aguarde o processo ou mude o parametro semaforoHistoricoCaso para true.");
		}
		
		parametroGBO.setValor(ConstantesSau.FALSE);
		parametroGBOService.update(parametroGBO);
		
	}

	private ParametroGBO getParametroGBOUltimaExecucao() throws ServiceException {
        try {
            return parametroGBOService.findByParam("executourelatoriohistoricocaso");
        } catch (ServiceException e) {
            throw new ServiceException("Erro ao buscar data da ultima execucao do relatorio Qlikview", e);
        }
    }

    @Override
    public Date getDataUltimoRelatorio() throws ServiceException {
        return getParametroGBOUltimaExecucao().getDataAlteracao();
    }

    @Override
    public void atualizaDataUltimoRelatorio() throws ServiceException, ValidationException {
        ParametroGBO ultimaExecucao = getParametroGBOUltimaExecucao();
        ultimaExecucao.setValor("OK");
        parametroGBOService.update(ultimaExecucao);
    }

    private List<RelatorioHistoricoCaso> getRelatorios(Date ultimaAlteracao, Date dataFim) throws ServiceException {
        try {
            return getDAO().getCasosRelatorio(ultimaAlteracao, dataFim);
        } catch (DataException e) {
            throw new ServiceException("Erro ao buscar relatorios", e);
        }
    }
    
    private Date addHour(Date date, int amount){
    	Calendar c = new GregorianCalendar();
    	c.setTime(date);
    	c.add(Calendar.HOUR, amount);
    	
    	return c.getTime();
    }
    
    private void begin() throws ServiceException{
    	try {
			tx.begin();
		} catch (Exception e) {
			e.printStackTrace();
			throw new ServiceException(e);
		}
    }
    
    private void commit() throws ServiceException{
    	try {
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
			throw new ServiceException(e);
		}
    }
    
    private void rollback() throws ServiceException{
    	try {
			tx.rollback();
		} catch (Exception e) {
			e.printStackTrace();
			throw new ServiceException(e);
		}
    }

}
