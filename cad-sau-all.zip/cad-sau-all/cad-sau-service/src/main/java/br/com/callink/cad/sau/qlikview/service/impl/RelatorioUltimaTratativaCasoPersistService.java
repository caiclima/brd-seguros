package br.com.callink.cad.sau.qlikview.service.impl;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ejb.EJB;
import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.sau.dao.qlikview.IRelatorioUltimaTratativaCasoDAO;
import br.com.callink.cad.sau.qlikview.pojo.RelatorioUltimaTratativaCaso;
import br.com.callink.cad.sau.qlikview.service.IRelatorioUltimaTratativaCasoPersistService;
import br.com.callink.cad.service.ISlaService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.service.impl.GenericGboService;

@Stateless
@Local(IRelatorioUltimaTratativaCasoPersistService.class)
public class RelatorioUltimaTratativaCasoPersistService extends GenericGboService<RelatorioUltimaTratativaCaso, IRelatorioUltimaTratativaCasoDAO> implements IRelatorioUltimaTratativaCasoPersistService {

    private static final long serialVersionUID = 5794476028670209602L;
    
    private Logger logger = Logger.getLogger(RelatorioUltimaTratativaCasoPersistService.class.getName());
    
    @EJB(beanName="SlaTipoFilaService")
    private ISlaService slaService;
    
    @Inject
    private IRelatorioUltimaTratativaCasoDAO relatorioUltimaTratativaCasoDAO;
    
    
    @Override
	protected IRelatorioUltimaTratativaCasoDAO getDAO() {
		return relatorioUltimaTratativaCasoDAO;
	}
    
    public void deleteAll() throws ServiceException, ValidationException {
    	try {
    		getDAO().deleteAll();
    	} catch (Exception e) {
    		logger.log(Level.SEVERE, "Erro ao limpar tabela de historico dos casos.", e);
		}
    }
        
    public void persistDadosRelatorio(List<RelatorioUltimaTratativaCaso> relatorioList) throws ServiceException, ValidationException {
    	
    	Long slaRegistro = null;
    	for(RelatorioUltimaTratativaCaso registro : relatorioList) {
	    	try {
	    		
        		if (slaRegistro == null || (!relatorioList.get(relatorioList.indexOf(registro) - 1).getManifestacao().equals(registro.getManifestacao()))) {
        	        slaRegistro = slaService.calculaSlaInterValo(registro.getDataAbertura(), registro.getDataEncerramento() != null ? registro.getDataEncerramento() : getDataBanco());
        	    }
        	    
        	    registro.setSlaMinutos(slaRegistro);
        	    registro.setSlaPorcentagem(slaService.calcularPorcentagem(Double.valueOf(registro.getSla() * 60), slaRegistro));
        	    
        	    if (StringUtils.isBlank(registro.getLoginAtendente())) {
        	        registro.setDataLogFim(registro.getDataLogInicio());
        	    }
        	    getDAO().save(registro);
	        	    
	    	} catch (Exception e) {
	    		logger.log(Level.SEVERE, "Erro ao limpar tabela de historico dos casos.", e);
			}
    	}
    }
}
