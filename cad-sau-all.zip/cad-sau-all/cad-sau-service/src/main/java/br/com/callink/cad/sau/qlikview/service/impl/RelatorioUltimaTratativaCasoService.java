package br.com.callink.cad.sau.qlikview.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.inject.Inject;
import javax.transaction.UserTransaction;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.pojo.LogTask;
import br.com.callink.cad.pojo.ParametroGBO;
import br.com.callink.cad.sau.dao.qlikview.IRelatorioUltimaTratativaCasoDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.qlikview.pojo.RelatorioUltimaTratativaCaso;
import br.com.callink.cad.sau.qlikview.service.IRelatorioUltimaTratativaCasoPersistService;
import br.com.callink.cad.sau.qlikview.service.IRelatorioUltimaTratativaCasoService;
import br.com.callink.cad.sau.service.impl.GenericCadSauService;
import br.com.callink.cad.sau.util.ConstantesSau;
import br.com.callink.cad.service.ILogTaskService;
import br.com.callink.cad.service.IParametroGBOService;
import br.com.callink.cad.service.ISlaService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

@Stateless
@TransactionManagement(TransactionManagementType.BEAN)
public class RelatorioUltimaTratativaCasoService extends GenericCadSauService<RelatorioUltimaTratativaCaso, IRelatorioUltimaTratativaCasoDAO> implements IRelatorioUltimaTratativaCasoService {

    private static final long serialVersionUID = 5794476028670209602L;
    private Logger logger = Logger.getLogger(RelatorioUltimaTratativaCasoService.class.getName());
    @Inject
    private IRelatorioUltimaTratativaCasoDAO relatorioUltimaTratativaCasoDAO;
    @EJB
    private IParametroGBOService parametroGBOService;
    
    @EJB
    private IRelatorioUltimaTratativaCasoPersistService relatorioUltimaTratativaCasoPersistService;
    
    @EJB
    private ILogTaskService logTaskService;
    
    @EJB(beanName="SlaTipoFilaService")
    private ISlaService slaService;
    
    @Resource
    private UserTransaction tx;

    @Override
	protected IRelatorioUltimaTratativaCasoDAO getDAO() {
		return relatorioUltimaTratativaCasoDAO;
	}
    
    @Override
    public void gerarHistoricos(Date dataUltimaAlteracao) throws ServiceException, ValidationException {
    	verificaDataHoje(dataUltimaAlteracao);
    }

    public void verificaDataHoje(Date dataUltimaAlteracao) throws ServiceException, ValidationException {
    	logger.info("RelatorioUltimaTratativaCasoService - INICIO relatorio QlikView");
    	Date dataHoje = new Date();
    	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    	
    	try {
    		if (!dateFormat.parse(dateFormat.format(dataUltimaAlteracao))
    				.before(dateFormat.parse(dateFormat.format(dataHoje)))) {
            	dataUltimaAlteracao = dateFormat.parse(dateFormat.format(dataHoje));
    		}
        } catch (ParseException ex) {
        	throw new ServiceException("Erro ao fazer parse da data ", ex);
        }
    	
        gerarRelatorio(dataUltimaAlteracao);
        logger.info("RelatorioUltimaTratativaCasoService - FIM relatorio QlikView");
    }

	private void gerarRelatorio(Date dataUltimaAlteracao) throws ServiceException, ValidationException {
		ParametroGBO parametroGBO = null;
		
		LogTask logTask = new LogTask();
    	logTask.setDataInicial(getDataBanco());
    	logTask.setMnmExecutor(ConstantesSau.PARAM_SEMAFORO_ULTIMA_TRATATIVA);
		
    	begin();
    	
		try {
			parametroGBO = parametroGBOService.findByParam(ConstantesSau.PARAM_SEMAFORO_ULTIMA_TRATATIVA);
			
			verificarAtualizarSemaforo(parametroGBO);
			//relatorioUltimaTratativaCasoPersistService.deleteAll();
			atualizaDataUltimoRelatorio();
        } catch (Exception e) {
        	rollback();
            throw new ServiceException("Erro ao efetuar operacao.", e);
        }
        
		commit();
		
        List<RelatorioUltimaTratativaCaso> relatorioList = getRelatorios(dataUltimaAlteracao);
        if (relatorioList != null) {
        	logTask.setTotalRegistros(Integer.valueOf(relatorioList.size()));
            
        	begin();
        	salvarRelatorio(relatorioList);
        	commit();
            
        } else {
        	logTask.setTotalRegistros(Integer.valueOf(0));
        }
        
        begin();
        logTask.setDataFinal(getDataBanco());
        logTaskService.save(logTask);
        
        try {
			parametroGBO.setValor(ConstantesSau.TRUE);
			parametroGBOService.update(parametroGBO);
			commit();
        } catch (Exception e) {
        	rollback();
			throw new ServiceException("Erro ao alterar o semaforo ULTIMA_TRATATIVA",e);
		}
        
	}

    private void salvarRelatorio(List<RelatorioUltimaTratativaCaso> relatorioList) throws ServiceException{
    	int count = 1;
    	Long slaRegistro = null;
    	
    	for(RelatorioUltimaTratativaCaso registro : relatorioList) {
	    	try {
	    		
        		if (slaRegistro == null || (!relatorioList.get(relatorioList.indexOf(registro) - 1).getManifestacao().equals(registro.getManifestacao()))) {
        	        slaRegistro = slaService.calculaSlaInterValo(registro.getDataAbertura(), registro.getDataEncerramento() != null ? registro.getDataEncerramento() : getDataBanco());
        	    }
        	    
        	    registro.setSlaMinutos(slaRegistro);
        	    
        	    if(slaRegistro != null){
        	    	registro.setSlaPorcentagem(slaService.calcularPorcentagem(Double.valueOf(registro.getSla() * 60), slaRegistro));
        	    }
        	    
        	    if (StringUtils.isBlank(registro.getLoginAtendente())) {
        	        registro.setDataLogFim(registro.getDataLogInicio());
        	    }
        	    
        	    getDAO().deleteByCaso(registro.getIdCaso());
        	    
        	    getDAO().save(registro);
	        	
        	    if (count % 500 == 0) {
					commit();
					begin();
				}

				count++;
				
	    	} catch (Exception e) {
	    		logger.log(Level.SEVERE, "Erro ao salvar registro relatório ultima tratativa.", e);
			}
    	}
    	
    	relatorioList.clear();
	}

	private void verificarAtualizarSemaforo(ParametroGBO parametroGBO) throws ValidationException, ServiceException {
    	if (parametroGBO == null || parametroGBO.getIdParametroGBO() == null) {
			throw new ValidationException("Não foi possível identificar o parametro GBO ULTIMA_TRATATIVA. Favor cadastrar o mesmo.");
		}
		
		if (!Boolean.valueOf(parametroGBO.getValor())) {
			throw new ValidationException("O sinalizador de execução está informando que já existe um processo sendo executado. Aguarde o processo ou mude o parametro semaforoUltimaTratativa para true.");
		}
		
		parametroGBO.setValor(ConstantesSau.FALSE);
		parametroGBOService.update(parametroGBO);
		
	}

	private ParametroGBO getParametroGBOUltimaExecucao() throws ServiceException {
        try {
            return parametroGBOService.findByParam("executouRelatorioUltimaTratativaCaso");
        } catch (ServiceException e) {
            throw new ServiceException("Erro ao buscar data da ultima execucao do relatorio Qlikview", e);
        }
    }

    @Override
    public Date getDataUltimoRelatorio() throws ServiceException {
        return getParametroGBOUltimaExecucao().getDataAlteracao();
    }

    @Override
    public void atualizaDataUltimoRelatorio() throws ServiceException, ValidationException {
        ParametroGBO ultimaExecucao = getParametroGBOUltimaExecucao();
        ultimaExecucao.setValor("OK");
        parametroGBOService.update(ultimaExecucao);
    }

    private List<RelatorioUltimaTratativaCaso> getRelatorios(Date ultimaAlteracao) throws ServiceException {
        try {
            return getDAO().getCasosRelatorio(ultimaAlteracao);
        } catch (DataException e) {
            throw new ServiceException("Erro ao buscar relatorios", e);
        }
    }

	@Override
	protected void validarSave(RelatorioUltimaTratativaCaso object)
			throws ValidationException {
		
	}

	@Override
	protected void validarUpdate(RelatorioUltimaTratativaCaso object)
			throws ValidationException {
		
	}

	@Override
	protected void validarDelete(RelatorioUltimaTratativaCaso object)
			throws ValidationException {
		
	}
	
	private void begin() throws ServiceException{
    	try {
			tx.begin();
		} catch (Exception e) {
			e.printStackTrace();
			throw new ServiceException(e);
		}
    }
    
    private void commit() throws ServiceException{
    	try {
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
			throw new ServiceException(e);
		}
    }
    
    private void rollback() throws ServiceException{
    	try {
			tx.rollback();
		} catch (Exception e) {
			e.printStackTrace();
			throw new ServiceException(e);
		}
    }
}
