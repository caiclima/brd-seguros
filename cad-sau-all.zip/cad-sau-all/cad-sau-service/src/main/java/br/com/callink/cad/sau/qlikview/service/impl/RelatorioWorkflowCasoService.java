/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.sau.qlikview.service.impl;

import java.util.Date;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.inject.Inject;

import br.com.callink.cad.pojo.ParametroGBO;
import br.com.callink.cad.sau.dao.qlikview.IRelatorioWorkflowCasoDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.qlikview.service.IRelatorioWorkflowCasoService;
import br.com.callink.cad.service.IParametroGBOService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 *
 * @author Luiz Gustavo F. (luizgf@swb.com.br)
 */
@Stateless
public class RelatorioWorkflowCasoService implements IRelatorioWorkflowCasoService {

	@Inject
	private IRelatorioWorkflowCasoDAO relatorioWorkflowCasoDAO;
	
	@EJB
	private IParametroGBOService parametroGBOService;
	
    @Override
    public void dropTable() throws ServiceException {
        try {
        	relatorioWorkflowCasoDAO.deleteAll();
        } catch (DataException ex) {
            throw new ServiceException("Erro ao limpar tabela Qlikview Workflow Caso.",ex);
        }
    }

    @Override
    public void geraRelatorio(Date data) throws ServiceException {
        try {
            dropTable();
            relatorioWorkflowCasoDAO.geraRelatorio(data);
        } catch (DataException ex) {
            throw new ServiceException("Erro ao gerar relatorio Qlikview Workflow Caso.",ex);
        }
    }
    
    private ParametroGBO getParametroGBOUltimaExecucao() throws ServiceException {
        try {
            return parametroGBOService.findByParam("executourelatorioworkflowcaso");
        }
        catch (ServiceException e) {
            throw new ServiceException("Erro ao buscar data da ultima execucao do relatorio Workflow de Caso do Qlikview", e);
        } 
    }
    
    @Override
    public Date getDataUltimoRelatorio() throws ServiceException {
        return getParametroGBOUltimaExecucao().getDataAlteracao();
    }
    
    @Override
    public void atualizaDataUltimoRelatorio() throws ServiceException, ValidationException {
        ParametroGBO ultimaExecucao = getParametroGBOUltimaExecucao();
        ultimaExecucao.setValor("OK");
        parametroGBOService.update(ultimaExecucao);
    }
    
    
}
