package br.com.callink.cad.sau.service;

import java.util.List;

import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.sau.dao.IAssociaChecklistDAO;
import br.com.callink.cad.sau.pojo.AssociaChecklist;
import br.com.callink.cad.sau.pojo.Checklist;
import br.com.callink.cad.sau.pojo.Evento;
import br.com.callink.cad.service.exception.ServiceException;

public interface IAssociaChecklistService extends IGenericCadSauService<AssociaChecklist, IAssociaChecklistDAO> {

    List<Evento> getEventosByChecklist(Checklist checklist) throws ServiceException;
    
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    void deletaAssociacoes(Checklist checklist) throws ServiceException;
    
    List<AssociaChecklist> buscaAssociacaoByListEvento(List<Evento> eventos) throws ServiceException;

	List<AssociaChecklist> buscaAssociacaoPorEventoAcao(Evento evento, Acao acao,Checklist checklist)
			throws ServiceException;

	Acao findAcaoByChecklist(Checklist checklist) throws ServiceException;

	List<String> existeAcaoEvento(List<Evento> item, Acao acaoSelecionada,Checklist checklist)
			throws ServiceException;

	Checklist getChecklist(Evento evento, Acao acao) throws ServiceException;

	Boolean existeAcao(Acao acaoSelecionada, Checklist checklist)
			throws ServiceException;


}
