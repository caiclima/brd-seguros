/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.sau.service;

import java.util.List;

import br.com.callink.cad.sau.dao.IAssociaConteudoApoioDAO;
import br.com.callink.cad.sau.pojo.AssociaConteudoApoio;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.pojo.ConteudoApoio;
import br.com.callink.cad.service.exception.ServiceException;

/**
 *
 * @author Luiz Gustavo F. (luizgf@swb.com.br)
 */
public interface IAssociaConteudoApoioService extends IGenericCadSauService<AssociaConteudoApoio,IAssociaConteudoApoioDAO> {

    /**
     * * Busca todos as associacoes dos conteudos de apoio e tras objetos preenchidos
     * @return
     * @throws ServiceException 
     */
    List<AssociaConteudoApoio> buscaTodosComObjetosPreenchidos(AssociaConteudoApoio associaConteudoApoio) throws ServiceException ;
    
    /**
     * Retorna TRUE caso exista associacao
     * @param associaConteudoApoio
     * @return
     * @throws ServiceException 
     */
    boolean existeAssociacao(AssociaConteudoApoio associaConteudoApoio) throws ServiceException ;
    
    /**
     * Retorna TRUE se o CasoSau possuir um Conteudo de Apoio
     * @param casoSau
     * @return
     * @throws ServiceException 
     */
    ConteudoApoio getConteudoApoioFromCasoSau(CasoSau casoSau) throws ServiceException;
}
