package br.com.callink.cad.sau.service;

import java.util.List;

import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import br.com.callink.cad.sau.dao.IAssociaQuestionarioDAO;
import br.com.callink.cad.sau.pojo.AssociaQuestionario;
import br.com.callink.cad.sau.pojo.Evento;
import br.com.callink.cad.sau.pojo.Questionario;
import br.com.callink.cad.service.exception.ServiceException;

public interface IAssociaQuestionarioService extends
        IGenericCadSauService<AssociaQuestionario, IAssociaQuestionarioDAO> {

    Questionario getQuestionario(Evento evento) throws ServiceException;
    
    List<Evento> getEventosByQuestionario(Questionario questionario) throws ServiceException;
    
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    void deletaAssociacoes(Questionario questionario) throws ServiceException;
    
     List<AssociaQuestionario> buscaAssociacaoByListEvento(List<Evento> eventos) throws ServiceException;
}
