package br.com.callink.cad.sau.service;

import br.com.callink.cad.sau.dao.IAssuntoDAO;
import br.com.callink.cad.sau.pojo.Assunto;

/**
 * Service para um {@link Assunto}
 * @author brunomt [brunoam@swb.com.br]
 *
 */
public interface IAssuntoService extends IGenericCadSauService<Assunto, IAssuntoDAO> {

}
