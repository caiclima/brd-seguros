package br.com.callink.cad.sau.service;

import java.util.List;

import br.com.callink.cad.sau.dao.ICanalDAO;
import br.com.callink.cad.sau.pojo.Canal;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;


public interface ICanalService extends IGenericCadSauService<Canal, ICanalDAO>{

	/**
	 * Inativar canal.
	 * @param canal
	 * @throws ServiceException
	 */
	void inativar(Canal canal) throws ValidationException, ServiceException;
	
        /**
         * Busca todos os canais com o flag de cadastro caso manaul.
         * @return
         * @throws ServiceException 
         */
        List<Canal> buscaCanalCadastroManualCaso() throws ServiceException;
}
