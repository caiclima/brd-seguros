/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.sau.service;

import java.util.List;
import java.util.Properties;

import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.sau.dao.ICasoAbertoCockpitDAO;
import br.com.callink.cad.sau.pojo.CasoAbertoCockpit;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.pojo.TipoManifestacao;
import br.com.callink.cad.service.exception.ServiceException;

/**
 *
 * @author Rogerio
 */
public interface ICasoAbertoCockpitService extends IGenericCadSauService<CasoAbertoCockpit, ICasoAbertoCockpitDAO> {

    void insert(List<CasoAbertoCockpit> casoAbertoCockpitList) throws ServiceException;

    List<CasoAbertoCockpit> casosAbertos() throws ServiceException;

    List<CasoAbertoCockpit> casosAbertosFila() throws ServiceException;

    void addRelatorioList(List<CasoSau> casoSauList, Properties propertiesApp) throws ServiceException;

    List<CasoAbertoCockpit> getCasoAbertoList(List<TipoManifestacao> tipoManifestacaoList) throws ServiceException;

    List<CasoAbertoCockpit> getCasoAbertoListPorFila(List<ConfiguracaoFila> configuracaoFilaList) throws ServiceException;
}
