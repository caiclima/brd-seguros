package br.com.callink.cad.sau.service;


import java.util.List;

import br.com.callink.cad.sau.dao.ICasoFechadoDAO;
import br.com.callink.cad.sau.pojo.CasoFechado;
import br.com.callink.cad.service.exception.ServiceException;

public interface ICasoFechadoService extends IGenericCadSauService<CasoFechado, ICasoFechadoDAO> {

    /**
     * Busca Caso Fechado pela manifestacao
     * @param manifestacao
     * @return
     * @throws ServiceException 
     */
    CasoFechado buscaPorManifestacao(String manifestacao) throws ServiceException;
    
    /**
     * Busca todos os casos que estao abertos no gbo e foi importado como fechado no caso spa
     * @return
     * @throws ServiceExceptio 
     */
    
    List<CasoFechado> buscaCasosFechadosSpaAbertosGbo() throws ServiceException;
    
}