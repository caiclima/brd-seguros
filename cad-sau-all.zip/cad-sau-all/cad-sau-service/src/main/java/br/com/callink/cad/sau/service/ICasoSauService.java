package br.com.callink.cad.sau.service;

import java.util.Date;
import java.util.List;

import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.sau.dao.ICasoSauDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.pojo.to.AcompanhamentoCasoFind;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

public interface ICasoSauService extends IGenericCadSauService<CasoSau, ICasoSauDAO> {

    /**
     * Salva um casoSau.
     * @param casoSau
     * @param atendente
     * @throws ServiceException 
     */
    void save(CasoSau casoSau, Atendente atendente) throws ValidationException, ServiceException;
    
    /**
     * Busca por uma lista de casos.
     * @param caso
     * @return
     * @throws ServiceException 
     */
    List<CasoSau> findCasoSauByCaso(List<Caso> caso) throws ServiceException;

    /**
     * Busca por um caso
     * @param caso
     * @return
     * @throws ServiceException 
     */
    CasoSau findCasoSauByCaso(Caso caso) throws ServiceException;

    /**
     * Busca um List de CasoSau pela {@link ConfiguracaoFila} e pelo {@link Atendente}
     * @param configuracaoFila
     * @param atendente
     * @return List<CasoSau>
     * @throws ServiceException
     */
    List<CasoSau> buscaPorConfiguracaoFilaEAtendente(
            ConfiguracaoFila configuracaoFila, Atendente atendente)
            throws ServiceException;

    /**
     * Busca um List de CasoSau pelo {@link CasoSau} {@link Date} {@link Date}
     * Verifica campos nao nulos dentro e usa como filtro na consulta
     * @param acompanhamentoCasoFind
     * @return
     * @throws ServiceException
     */
    List<CasoSau> buscaPorFiltros(AcompanhamentoCasoFind acompanhamentoCasoFind) throws ServiceException;

    /**
     * 
     * @param configuracaoFila
     * @param atendente
     * @return
     * @throws ServiceException
     */
	List<CasoSau> buscaPorFilaOrAtendenteOrManifestacao(ConfiguracaoFila configuracaoFila,
			Atendente atendente, String manifestacao) throws ServiceException;
     
     /**
      * Busca casos fechados no dia.
      * @return
      * @throws ServiceException 
      */
     List<CasoSau> buscaCasosFechadosNoDia() throws ServiceException;
     
     /**
      * Busca todos os casos que foram reabertos.
      * @return
      * @throws ServiceException 
      */
     List<CasoSau> buscaCasoReabertoDia() throws ServiceException;
     
     /**
      * Gera o cockpit de casos abertos.
      * @throws ServiceException 
      */
     void geraCockpitCasosAbertos() throws ServiceException;
     
     /**
      * Busca tocos os casos abertos no GBO. Ou seja que o flag_finalizado é FALSE
      * @return
      * @throws ServiceException 
      */
     List<CasoSau> buscaCasoAberto() throws ServiceException;
     
         /**
     * Busca todos os casos abertos por assunto.
     * @return
     * @throws DataException 
     */
    List<CasoSau> buscaCasoAbertoAssunto() throws ServiceException;
    
    /**
     * Gera o Cockpit dos cassos classificados.
     * @throws ServiceException 
     */
    void geraCockpitClassificacaoCasos() throws ServiceException;
    
    /**
     * Busca todos os casos importados ou criados no GBO no dia atual.
     * @return
     * @throws ServiceException 
     */
    List<CasoSau> buscaCasoEntranteDia() throws ServiceException;
    
    /**
     * Buscar todos os casos por um determinado número de CPF ou CNPJ.
     *  
     * @param cpfCnpj
     * @return List<CasoSau>
     * @throws ServiceException
     */
    List<CasoSau> buscarCasoSauPorCpfCnpj(String cpfCnpj) throws ServiceException;
    
    /**
     * Buscar todos os casos por um determinado número de CPF ou CNPJ.
     * Filtra Associar Caso
     *  
     * @param cpfCnpj
     * @return List<CasoSau>
     * @throws ServiceException
     */
    List<CasoSau> buscarCasoSauPorCpfCnpjEFiltraAssociarCaso(String cpfCnpj, Atendente atendente) throws ServiceException;

	List<CasoSau> buscaCasoAbertoSemPendencia() throws ServiceException;

	/**
	 * 
	 * @return
	 * @throws ServiceException
	 */
	List<CasoSau> buscaCasosPendenteChecagem() throws ServiceException;
	
	/**
     * Valida caso para associar Caso atendente
     *  
     * @param cpfCnpj
     * @return List<CasoSau>
     * @throws ServiceException
     */
	List<CasoSau> validaCasoParaAssociarCasoAtendente(List<CasoSau> listCasoSau, Integer idUsuarioLogado) throws ServiceException;
	
	/**
     * confirma Dados caso Sau associacao
     *  
     * @throws ServiceException
     */
	void confirmaDadosCasoSauAssociacao(List<CasoSau> listCasoSau, String loginSupervisor, String senhaSupervisor, Atendente atendente) throws ServiceException;
	
	/**
     * associa caso sau ao atendente 
     *  
     * @param cpfCnpj
     * @return List<CasoSau>
     * @throws ServiceException
     */
	void associarCasoSauAtendente(List<CasoSau> listCasoSauAssociar, Atendente atendente) throws ServiceException;

	/**
	 * Valida se o atendente pode iniciar o atendimento do caso selecionado. Caso não seja possível será retornado erro.
	 * @param casoSau
	 * @param atendente
	 * @throws ServiceException
	 */
	void validaAtendimentoCasoAtendente(CasoSau casoSau, Atendente atendente) throws ValidationException, ServiceException;

	/**
	 * busca quantidade de casos abertos por cpf/cnpj
	 * @param cpfCnpj
	 * @return
	 * @throws ServiceException
	 */
	Integer buscarQtdCasoAbertoPorCpfCnpj(String cpfCnpj) throws ServiceException;
        /**
         * valida se o caso foi entregue a operação com atrazo de sla
         * @param caso
         * @return
         * @throws ServiceException 
         */
        Boolean juncaoForaPrazo(CasoSau caso)throws ServiceException;

		void flush();
}
