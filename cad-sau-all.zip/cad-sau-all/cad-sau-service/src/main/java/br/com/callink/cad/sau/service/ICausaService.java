package br.com.callink.cad.sau.service;

import br.com.callink.cad.sau.dao.ICausaDAO;
import br.com.callink.cad.sau.pojo.Causa;

public interface ICausaService extends IGenericCadSauService<Causa, ICausaDAO> {

}
