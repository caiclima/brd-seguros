package br.com.callink.cad.sau.service;

import java.util.List;

import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import br.com.callink.cad.sau.dao.ICheckDAO;
import br.com.callink.cad.sau.pojo.Check;
import br.com.callink.cad.sau.pojo.Checklist;
import br.com.callink.cad.service.exception.ServiceException;

public interface ICheckService extends  IGenericCadSauService<Check, ICheckDAO> {

    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    void save(List<Check> checks) throws ServiceException;

	List<Check> findAllCheckByChecklist(Checklist checklist)
			throws ServiceException;

}
