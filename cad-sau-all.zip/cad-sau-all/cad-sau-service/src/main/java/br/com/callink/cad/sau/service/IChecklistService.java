package br.com.callink.cad.sau.service;

import java.util.List;

import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.sau.dao.IChecklistDAO;
import br.com.callink.cad.sau.pojo.Checklist;
import br.com.callink.cad.sau.pojo.Evento;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

public interface IChecklistService extends
        IGenericCadSauService<Checklist, IChecklistDAO> {

	void salvaChecklist(Checklist checklist, List<Evento> associa, Acao acao)
			throws ValidationException, ServiceException;

}
