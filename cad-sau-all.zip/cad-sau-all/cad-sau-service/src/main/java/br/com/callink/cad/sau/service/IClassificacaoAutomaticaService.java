package br.com.callink.cad.sau.service;

import br.com.callink.cad.sau.dao.IClassificacaoAutomaticaDAO;
import br.com.callink.cad.sau.pojo.ClassificacaoAutomatica;

public interface IClassificacaoAutomaticaService
		extends
		IGenericCadSauService<ClassificacaoAutomatica, IClassificacaoAutomaticaDAO> {

}
