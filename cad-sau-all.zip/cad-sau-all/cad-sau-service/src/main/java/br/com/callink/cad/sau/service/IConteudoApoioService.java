package br.com.callink.cad.sau.service;

import java.util.List;

import br.com.callink.cad.sau.dao.IConteudoApoioDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.ConteudoApoio;
import br.com.callink.cad.sau.pojo.ConteudoApoioCasoSau;
import br.com.callink.cad.service.exception.ServiceException;

public interface IConteudoApoioService extends
		IGenericCadSauService<ConteudoApoio, IConteudoApoioDAO> {

    /**
     * Remove associacao do ConteudoApoio ao CasoSau
     * @param conteudoApoioCasoSau
     * @throws ServiceException 
     */
    void deleteAssociacao(ConteudoApoioCasoSau conteudoApoioCasoSau) throws ServiceException;
    
    /**
     * Remove uma lista de ConteudoApoio CasoSau
     * @param conteudoApoioCasoSauList
     * @throws ServiceException 
     */
    void deleteAssociacao(List<ConteudoApoioCasoSau> conteudoApoioCasoSauList) throws ServiceException;
    
    /**
     * Persiste a associacao ConteudoApoio ao Caso
     * @param conteudoApoioCasoSau
     * @throws DataException 
     */
    void saveAssociacao(ConteudoApoioCasoSau conteudoApoioCasoSau) throws ServiceException;
    
    /**
     * Persiste uma lista de ConteudoApoio aos Casos
     * @param conteudoApoioCasoSauList
     * @throws ServiceException 
     */
    void saveAssociacao(List<ConteudoApoioCasoSau> conteudoApoioCasoSauList) throws ServiceException;
    
}
