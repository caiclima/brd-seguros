package br.com.callink.cad.sau.service;

import br.com.callink.cad.sau.dao.IEstadoDAO;
import br.com.callink.cad.sau.pojo.Estado;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;


public interface IEstadoService extends IGenericCadSauService<Estado, IEstadoDAO>{

	/**
	 * Inativar o Estado 
	 * @param estado
	 * @throws ServiceException
	 */
	void inativa(Estado estado) throws ValidationException, ServiceException;

}
