/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.sau.service;

import java.util.List;

import br.com.callink.cad.sau.dao.IEventoCausaDAO;
import br.com.callink.cad.sau.pojo.Causa;
import br.com.callink.cad.sau.pojo.Evento;
import br.com.callink.cad.sau.pojo.EventoCausa;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 *
 * @author ubuntu
 */
public interface IEventoCausaService extends IGenericCadSauService<EventoCausa, IEventoCausaDAO>{
    
    /**
     * 
     * @param evento
     * @return
     * @throws ServiceException 
     * @throws ValidationException 
     */
    Causa findCausaFinalizaAutomaticaByEvento(Evento evento) throws ServiceException, ValidationException;
    
    /**
     * 
     * @param evento
     * @param causa
     * @return
     * @throws ServiceException 
     */
    List<EventoCausa> findByEventoCausa(Evento evento, Causa causa) throws ServiceException;
    
    /**
     * 
     * @param evento
     * @return
     * @throws ServiceException 
     */
    List<EventoCausa> findAllFinalizacaoAutomaticaByEvento(Evento evento) throws ServiceException;

    /**
     * Salva todas causas enviadas para um determinado evento.
     * @param evento
     * @param causas
     * @throws ServiceException 
     * @throws ValidationException 
     */
    void saveEventoCausas(Evento evento, List<Causa> causas) throws ServiceException, ValidationException;
    
    /**
     * Remove todas as ocorrencias de evento.
     * @param evento
     * @throws ServiceException 
     */
    void removeEvento(Evento evento) throws ServiceException;
            
}
