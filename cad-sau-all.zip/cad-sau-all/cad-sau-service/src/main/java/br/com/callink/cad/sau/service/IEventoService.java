package br.com.callink.cad.sau.service;

import java.util.List;

import br.com.callink.cad.sau.dao.IEventoDAO;
import br.com.callink.cad.sau.pojo.Assunto;
import br.com.callink.cad.sau.pojo.Evento;
import br.com.callink.cad.service.exception.ServiceException;

/**
 * 
 * @author brunomt [brunoam@swb.com.br]
 *
 */
public interface IEventoService extends IGenericCadSauService<Evento, IEventoDAO> {

    /**
     * Busca eventos pelo Assunto
     * @param assunto
     * @return
     * @throws ServiceException
     */
    List<Evento> findByAssunto(Assunto assunto) throws ServiceException;

    /**
     * Busca Eventos vincalados aos Assuntos informados
     * @param assuntoList
     * @return
     * @throws ServiceException
     */
    List<Evento> findByAssuntoList(List<Assunto> assuntoList)
            throws ServiceException;

    /**
     * Busca pelo assunto e pelo nome do Evento
     * @param assunto
     * @param evento
     * @return
     * @throws ServiceException 
     */
    List<Evento> findByAssuntoAndEvento(Assunto assunto, Evento evento) throws ServiceException ;

}
