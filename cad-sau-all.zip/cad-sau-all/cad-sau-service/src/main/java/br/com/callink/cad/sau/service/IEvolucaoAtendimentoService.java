package br.com.callink.cad.sau.service;

import java.util.List;

import br.com.callink.cad.sau.dao.IEvolucaoAtendimentoDAO;
import br.com.callink.cad.sau.pojo.EvolucaoAtendimento;
import br.com.callink.cad.sau.pojo.TipoManifestacao;
import br.com.callink.cad.sau.pojo.to.EvolucaoAtendimentoTO;
import br.com.callink.cad.service.exception.ServiceException;

/**
 *
 * @author brunomt
 */
public interface IEvolucaoAtendimentoService extends IGenericCadSauService<EvolucaoAtendimento, IEvolucaoAtendimentoDAO> {
    
    /**
     * Gera a evolução de atendimento para o dia corrente.
     * @throws ServiceException 
     */
    void geraEvolucaoAtendimento() throws ServiceException;
    
    /**
     * Remove a evolução de atendimento para o dia corrente.
     * @throws ServiceException 
     */
    void removeEvolucaoAtendimento() throws ServiceException;
    
    /**
     * Busca a EvolucaoAtendimento de acordo com os tipos de manifestações informados. A "quantidadeDias" informa a quantidade de dias
     * úteis que o sistema irá recuperar o relatório.
     * @throws ServiceException 
     */
    List<EvolucaoAtendimentoTO> recuperaEvolucaoAtendimento(List<TipoManifestacao> tipoManifestacaoList, Integer quantidadeDias) throws ServiceException;
}
