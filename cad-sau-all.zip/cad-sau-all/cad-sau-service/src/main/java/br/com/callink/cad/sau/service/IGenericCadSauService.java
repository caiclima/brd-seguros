package br.com.callink.cad.sau.service;

import java.util.Date;
import java.util.List;

import br.com.callink.cad.pojo.entity.IEntity;
import br.com.callink.cad.sau.dao.IGenericCadSauDAO;
import br.com.callink.cad.service.IGenericGboService;
import br.com.callink.cad.service.exception.ServiceException;



@SuppressWarnings("rawtypes")
public interface IGenericCadSauService<T extends IEntity, DAO extends IGenericCadSauDAO<T>> extends IGenericGboService<T, DAO> {

	/**
	 * Retorna todos os registros ativos na base de dados
	 * @param type
	 * @param nomeTabela
	 * @return
	 * @throws ServiceException
	 */
	List<T> findAtivos(String order) throws ServiceException;

	/**
	 * Retorna a data atual do banco de dados.
	 * @return
	 * @throws ServiceException
	 */
	Date getDataBanco() throws ServiceException;
        
    /**
     * 
     * @param object
     * @param order
     * @return
     * @throws ServiceException 
     */
    List<T> findByExample(T object, String order) throws ServiceException;

    /**
     * Busca todos pelo Order
     * @param order
     * @return
     * @throws ServiceException
     */
	List<T> findAll(String order) throws ServiceException;

}
