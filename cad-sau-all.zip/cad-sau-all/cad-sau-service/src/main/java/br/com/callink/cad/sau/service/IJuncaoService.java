package br.com.callink.cad.sau.service;

import br.com.callink.cad.sau.dao.IJuncaoDAO;
import br.com.callink.cad.sau.pojo.Juncao;
import br.com.callink.cad.service.exception.ServiceException;

public interface IJuncaoService extends IGenericCadSauService<Juncao, IJuncaoDAO> {

	/**
	 * Inativar uma juncao
	 * @param juncao
	 * @throws ServiceException 
	 */
	void inativar(Juncao juncao) throws ServiceException;

}
