/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.sau.service;

import br.com.callink.cad.sau.dao.IOutraAreaDAO;
import br.com.callink.cad.sau.pojo.OutraArea;

/**
 *
 * @author ubuntu
 */
public interface IOutraAreaService extends IGenericCadSauService<OutraArea, IOutraAreaDAO> {
}
