package br.com.callink.cad.sau.service;

import java.util.List;

import br.com.callink.cad.sau.dao.IQuestaoDAO;
import br.com.callink.cad.sau.pojo.Questao;
import br.com.callink.cad.sau.pojo.Questionario;
import br.com.callink.cad.service.exception.ServiceException;

public interface IQuestaoService extends  IGenericCadSauService<Questao, IQuestaoDAO> {

    void save(List<Questao> questoes) throws ServiceException;
    
    List<Questao> findAllQuestaoByQuestionario(Questionario questionario) throws ServiceException;
}
