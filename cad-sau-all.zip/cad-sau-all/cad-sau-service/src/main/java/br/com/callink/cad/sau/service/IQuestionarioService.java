package br.com.callink.cad.sau.service;

import java.util.List;

import br.com.callink.cad.sau.dao.IQuestionarioDAO;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.pojo.Evento;
import br.com.callink.cad.sau.pojo.Questionario;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

public interface IQuestionarioService extends
        IGenericCadSauService<Questionario, IQuestionarioDAO> {

    Questionario editQuestionario(Questionario questionario) throws ServiceException;

    Questionario findByCasoSau(CasoSau casoSau) throws ServiceException;

    void salvaQuestionario(Questionario questionario, List<Evento> associa) throws ServiceException, ValidationException;
}
