package br.com.callink.cad.sau.service;

import java.util.List;

import br.com.callink.cad.sau.dao.IRespostaChecklistDAO;
import br.com.callink.cad.sau.pojo.RespostaChecklist;
import br.com.callink.cad.sau.pojo.ResultadoChecklist;
import br.com.callink.cad.service.exception.ServiceException;

public interface IRespostaChecklistService extends IGenericCadSauService<RespostaChecklist, IRespostaChecklistDAO> {

    void save(List<RespostaChecklist> pojos) throws ServiceException;

    List<RespostaChecklist> respostasByResultadoChecklist(ResultadoChecklist resultadoChecklist) throws ServiceException;

	List<RespostaChecklist> validaFilhos(List<RespostaChecklist> respostas);

}
