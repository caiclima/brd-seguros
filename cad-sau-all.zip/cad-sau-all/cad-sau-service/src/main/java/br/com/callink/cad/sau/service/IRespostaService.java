package br.com.callink.cad.sau.service;

import java.util.List;

import br.com.callink.cad.sau.dao.IRespostaDAO;
import br.com.callink.cad.sau.pojo.Questao;
import br.com.callink.cad.sau.pojo.Resposta;
import br.com.callink.cad.sau.pojo.ResultadoQuestionario;
import br.com.callink.cad.service.exception.ServiceException;

public interface IRespostaService extends IGenericCadSauService<Resposta, IRespostaDAO> {

    boolean questaoEditavel(Questao questao) throws ServiceException;

    void save(List<Resposta> pojos) throws ServiceException;

    List<Resposta> respostasByResultadoQuestionario(ResultadoQuestionario resultadoQuestionario) throws ServiceException;

    List<Resposta> validaFilhos(List<Resposta> respostas);
}
