package br.com.callink.cad.sau.service;

import java.util.List;

import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.sau.dao.IResultadoChecklistDAO;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.pojo.Evento;
import br.com.callink.cad.sau.pojo.ResultadoChecklist;
import br.com.callink.cad.service.exception.ServiceException;


public interface IResultadoChecklistService extends IGenericCadSauService<ResultadoChecklist, IResultadoChecklistDAO>{
	
	
	/**
	 * busca um resultado checklist pelo evento, casoSao e acao
	 * @param casoSau
	 * @param evento
	 * @param acao
	 * @return
	 * @throws ServiceException
	 */
	List<ResultadoChecklist> buscaResultadoPorAgenteCasoSau(CasoSau casoSau,
			Evento evento, Acao acao) throws ServiceException;
}
