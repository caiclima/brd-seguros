package br.com.callink.cad.sau.service;

import java.util.List;

import br.com.callink.cad.sau.dao.IResultadoQuestionarioDAO;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.pojo.ResultadoQuestionario;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;


public interface IResultadoQuestionarioService extends IGenericCadSauService<ResultadoQuestionario, IResultadoQuestionarioDAO>{

	void validaPreenchimentoQuestionario(CasoSau casoSau) throws ServiceException, ValidationException;
	
        ResultadoQuestionario findByCasoSau(CasoSau casoSau) throws ServiceException;
        
        List<Object[]> questionariosRespondidos(Integer idExterno) throws ServiceException; 
}
