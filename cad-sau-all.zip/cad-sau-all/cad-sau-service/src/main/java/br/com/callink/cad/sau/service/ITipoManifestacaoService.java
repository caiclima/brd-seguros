package br.com.callink.cad.sau.service;

import br.com.callink.cad.sau.dao.ITipoManifestacaoDAO;
import br.com.callink.cad.sau.pojo.TipoManifestacao;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 * 
 * @author brunomt [brunoam@swb.com.br]
 *
 */
public interface ITipoManifestacaoService extends IGenericCadSauService<TipoManifestacao, ITipoManifestacaoDAO> {
	
	/**
	 * Inativa um tipo de manifestação.
	 * @param tipoManifestacao
	 * @throws ServiceException
	 * @throws ValidationException 
	 */
	void inativar(TipoManifestacao tipoManifestacao) throws ServiceException, ValidationException;
}
