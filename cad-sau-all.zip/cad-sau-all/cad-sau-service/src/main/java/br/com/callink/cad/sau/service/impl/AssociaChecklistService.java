package br.com.callink.cad.sau.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.sau.dao.IAssociaChecklistDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.AssociaChecklist;
import br.com.callink.cad.sau.pojo.Checklist;
import br.com.callink.cad.sau.pojo.Evento;
import br.com.callink.cad.sau.service.IAssociaChecklistService;
import br.com.callink.cad.sau.service.ICheckService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

@Stateless
public class AssociaChecklistService extends GenericCadSauService<AssociaChecklist, IAssociaChecklistDAO>
        implements IAssociaChecklistService {

	private static final long serialVersionUID = -7189219221774179843L;
	
	@Inject
	private IAssociaChecklistDAO associaChecklistDAO;
	
	@EJB
	private ICheckService checkService;
	
	@Override
	protected IAssociaChecklistDAO getDAO() {
		return associaChecklistDAO;
	}

    @Override
    public List<Evento> getEventosByChecklist(Checklist checklist) throws ServiceException {
        try {
            return getDAO().getEventosByChecklist(checklist);
        } catch (DataException ex) {
            throw new ServiceException(ex);
        }
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void deletaAssociacoes(Checklist checklist) throws ServiceException {
        try {
            getDAO().deletaAssociacoes(checklist);
        } catch (DataException ex) {
            throw new ServiceException(ex);
        }
    }

    @Override
    public List<AssociaChecklist> buscaAssociacaoByListEvento(List<Evento> eventos) throws ServiceException {
        try {
            return getDAO().buscaAssociacaoByListEvento(eventos);
        } catch (DataException ex) {
            throw new ServiceException(ex);
        }
    }
    
    @Override
    public List<AssociaChecklist> buscaAssociacaoPorEventoAcao(Evento evento, Acao acao, Checklist checklist) throws ServiceException {
    	try {
    		
    		if(acao ==null || checklist == null){
    			return null;
    		}
    		
            return getDAO().buscaAssociacaoPorEventoAcao(evento, acao, checklist);
        } catch (DataException ex) {
            throw new ServiceException(ex);
        }
    } 
    
    @Override
    public Acao findAcaoByChecklist(Checklist checklist) throws ServiceException {
    	try {
    		
    		if(checklist == null || checklist.getIdChecklist()==null){
    			return null;
    		}
            return getDAO().findAcaoByChecklist(checklist);
        } catch (DataException ex) {
            throw new ServiceException(ex);
        }
    }
    
    @Override
    public List<String> existeAcaoEvento(List<Evento> item, Acao acaoSelecionada, Checklist checklist) throws ServiceException {
		try {
			
			List<AssociaChecklist> associaChecklists;
			List<String> nomeEventosEncontrados = new ArrayList<String>();
			
			for (Evento eve : item) {
				associaChecklists = buscaAssociacaoPorEventoAcao(eve, acaoSelecionada, checklist);
				if(associaChecklists!=null && associaChecklists.size()>0){
					nomeEventosEncontrados.add(eve.getNome());
				}
			}
			return nomeEventosEncontrados;
			
		} catch (ServiceException e) {
			throw new ServiceException(e);
		}
	}
    
    @Override
    public Boolean existeAcao(Acao acaoSelecionada, Checklist checklist) throws ServiceException {
		try {
			
			List<AssociaChecklist> associaChecklists;
			associaChecklists = buscaAssociacaoPorEventoAcao(null, acaoSelecionada, checklist);
			if(associaChecklists!=null && associaChecklists.size()>0){
				return true;
			}
			return false;
			
		} catch (ServiceException e) {
			throw new ServiceException(e);
		}
	}
    
    
    @Override
    public Checklist getChecklist(Evento evento, Acao acao) throws ServiceException {
    	try {
    		
    		if(acao == null || acao.getIdAcao() == null){
    			return null;
    		}
    		
    		Checklist checklist = getDAO().getChecklist(evento, acao);
    		
    		if(checklist!=null && checklist.getIdChecklist()!=null){
    			checklist.setChecks(checkService.findAllCheckByChecklist(checklist));
    		}
    		return checklist;
        } catch (Exception ex) {
            throw new ServiceException(ex);
        }
    }

    private void validarCampos(AssociaChecklist object) throws ValidationException{
    	if(object== null){
			throw new ValidationException(" O objeto nao pode ser nulo!");
		}
		if(object.getChecklist()==null || object.getChecklist().getIdChecklist() == null){
			throw new ValidationException(" O Checklist nao pode ser nulo!");
		}
		if(object.getFlagEnabled()==null){
			throw new ValidationException("O Enabled nao pode ser nulo!");
		}
    }
    
	@Override
	protected void validarSave(AssociaChecklist object)
			throws ValidationException {
		validarCampos(object);
	}

	@Override
	protected void validarUpdate(AssociaChecklist object)
			throws ValidationException {
		validarCampos(object);
	}

	@Override
	protected void validarDelete(AssociaChecklist object)
			throws ValidationException {
		
	}
    
}
