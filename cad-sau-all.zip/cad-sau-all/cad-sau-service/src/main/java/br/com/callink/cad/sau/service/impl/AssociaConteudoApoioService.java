/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.sau.service.impl;

import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import br.com.callink.cad.sau.dao.IAssociaConteudoApoioDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.AssociaConteudoApoio;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.pojo.ConteudoApoio;
import br.com.callink.cad.sau.service.IAssociaConteudoApoioService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 *
 * @author Luiz Gustavo F. (luizgf@swb.com.br)
 */
@Stateless
public class AssociaConteudoApoioService extends GenericCadSauService<AssociaConteudoApoio, IAssociaConteudoApoioDAO>
        implements IAssociaConteudoApoioService {

    private static final long serialVersionUID = 1L;
    
    @Inject
    private IAssociaConteudoApoioDAO associaConteudoApoioDAO;
    
    @Override
	protected IAssociaConteudoApoioDAO getDAO() {
		return associaConteudoApoioDAO;
	}

    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void save(AssociaConteudoApoio associaConteudoApoio) throws ValidationException, ServiceException {

        boolean existeAssociacao = existeAssociacao(associaConteudoApoio);

        try {
            if (!existeAssociacao) {
                super.save(associaConteudoApoio);
            }
        } catch (ServiceException ex) {
            throw new ServiceException("Erro ao associar Conteudo Apoio", ex);
        }
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public List<AssociaConteudoApoio> buscaTodosComObjetosPreenchidos(AssociaConteudoApoio associaConteudoApoio) throws ServiceException {
        try {
            return getDAO().buscaTodosComObjetosPreenchidos(associaConteudoApoio);
        } catch (DataException e) {
            throw new ServiceException("Erro ao buscar Associção do Conteudo de Apoio", e);
        }
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public boolean existeAssociacao(AssociaConteudoApoio associaConteudoApoio) throws ServiceException {

        List<AssociaConteudoApoio> list = null;
        try {
            list = findByExample(associaConteudoApoio);
        } catch (ServiceException ex) {
            throw new ServiceException("Erro ao validar Associação.", ex);
        }
        if (list == null || list.isEmpty()) {
            return Boolean.FALSE;
        }
        return Boolean.TRUE;
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public ConteudoApoio getConteudoApoioFromCasoSau(CasoSau casoSau) throws ServiceException {
        AssociaConteudoApoio associa = new AssociaConteudoApoio();
        associa.setEvento(casoSau.getEvento());
        List<AssociaConteudoApoio> associaList = findByExample(associa);
        if (associaList.isEmpty()) {
            return new ConteudoApoio();
        } else {
            return associaList.get(0).getConteudoApoio();
        }
    }

    private void validaCampos(AssociaConteudoApoio object) throws ValidationException {
		
    	if(object== null){
			throw new ValidationException(" O objeto nao pode ser nulo!");
		}
		if(object.getEvento()==null || object.getEvento().getIdEvento()==null){
			throw new ValidationException("O Evento nao pode ser nulo!");
		}
		if(object.getConteudoApoio()==null || object.getConteudoApoio().getIdConteudoApoio()==null){
			throw new ValidationException("O ConteudoApoio nao pode ser nulo!");
		}
	}
    
	@Override
	protected void validarSave(AssociaConteudoApoio object)
			throws ValidationException {
		validaCampos(object);
		
	}

	@Override
	protected void validarUpdate(AssociaConteudoApoio object)
			throws ValidationException {
		validaCampos(object);
		
	}

	@Override
	protected void validarDelete(AssociaConteudoApoio object)
			throws ValidationException {
		
	}
}
