package br.com.callink.cad.sau.service.impl;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import br.com.callink.cad.sau.dao.IAssociaQuestionarioDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.AssociaQuestionario;
import br.com.callink.cad.sau.pojo.Evento;
import br.com.callink.cad.sau.pojo.Questionario;
import br.com.callink.cad.sau.service.IAssociaQuestionarioService;
import br.com.callink.cad.sau.service.IQuestaoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

@Stateless
public class AssociaQuestionarioService extends GenericCadSauService<AssociaQuestionario, IAssociaQuestionarioDAO>
        implements IAssociaQuestionarioService {

    private static final long serialVersionUID = -1352379707916299377L;

    @Inject
    private IAssociaQuestionarioDAO associaQuestionarioDAO;
    
    @EJB
    private IQuestaoService questaoService;
    
    @Override
	protected IAssociaQuestionarioDAO getDAO() {
		return associaQuestionarioDAO;
	}
    
    @Override
    public Questionario getQuestionario(Evento evento) throws ServiceException {
        try {
        	
        	if (evento == null || evento.getIdEvento() == null) {
        		return null;
        	}
        	
            Questionario questionario = getDAO().getQuestionario(evento);
            if (questionario != null) {
                questionario.setQuestaoList(questaoService.findAllQuestaoByQuestionario(questionario));
            }
            return questionario;
        } catch (Exception ex) {
            throw new ServiceException(ex);
        }
    }

    @Override
    public List<Evento> getEventosByQuestionario(Questionario questionario) throws ServiceException {
        try {
            return getDAO().getEventosByQuestionario(questionario);
        } catch (DataException ex) {
            throw new ServiceException(ex);
        }
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void deletaAssociacoes(Questionario questionario) throws ServiceException {
        try {
            getDAO().deletaAssociacoes(questionario);
        } catch (DataException ex) {
            throw new ServiceException(ex);
        }
    }

    @Override
    public List<AssociaQuestionario> buscaAssociacaoByListEvento(List<Evento> eventos) throws ServiceException {
        try {
            return getDAO().buscaAssociacaoByListEvento(eventos);
        } catch (DataException ex) {
            throw new ServiceException(ex);
        }
    }

    private void validarCampos(AssociaQuestionario object) throws ValidationException{
    	
    	if(object== null){
			throw new ValidationException(" O objeto nao pode ser nulo!");
		}
		if(object.getQuestionario()==null || object.getQuestionario().getIdQuestionario() == null){
			throw new ValidationException(" O Questionario nao pode ser nulo!");
		}
		if(object.getEvento()==null || object.getEvento().getIdEvento()==null){
			throw new ValidationException("O Evento nao pode ser nulo!");
		}
		if(object.getFlagCheckList()==null){
			throw new ValidationException("O FlagChecklist nao pode ser nulo!");
		}
    }
    
	@Override
	protected void validarSave(AssociaQuestionario object)
			throws ValidationException {
		validarCampos(object);
	}

	@Override
	protected void validarUpdate(AssociaQuestionario object)
			throws ValidationException {
		validarCampos(object);
	}

	@Override
	protected void validarDelete(AssociaQuestionario object)
			throws ValidationException {
		
	}
}
