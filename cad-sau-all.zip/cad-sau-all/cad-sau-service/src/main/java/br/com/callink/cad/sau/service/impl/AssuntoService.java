package br.com.callink.cad.sau.service.impl;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import br.com.callink.cad.sau.dao.IAssuntoDAO;
import br.com.callink.cad.sau.pojo.Assunto;
import br.com.callink.cad.sau.service.IAssuntoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 * 
 * @author brunomt [brunoam@swb.com.br]
 *
 */
@Stateless
public class AssuntoService extends GenericCadSauService<Assunto, IAssuntoDAO> implements IAssuntoService {
	
	private static final long serialVersionUID = 1L;
	
	@Inject
	private IAssuntoDAO assuntoDAO;
	
	@Override
	protected IAssuntoDAO getDAO() {
		return assuntoDAO;
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void save(Assunto assunto) throws ValidationException, ServiceException {
		assunto.setDataCriacao(getDataBanco());
		super.save(assunto);
	}
	
	private void validaCampos(Assunto assunto) throws ValidationException {
		if (assunto == null || assunto.getNome() == null || assunto.getNome().isEmpty()) {
			throw new ValidationException("O assunto n\u00E3o pode ser nulo.");
		}
	}

	@Override
	protected void validarSave(Assunto object) throws ValidationException {
		this.validaCampos(object);
	}

	@Override
	protected void validarUpdate(Assunto object) throws ValidationException {
		this.validaCampos(object);
	}

	@Override
	protected void validarDelete(Assunto object) throws ValidationException {
		
	}
	
}
