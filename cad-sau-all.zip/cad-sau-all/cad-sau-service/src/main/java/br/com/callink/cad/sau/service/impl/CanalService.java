package br.com.callink.cad.sau.service.impl;

import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.sau.dao.ICanalDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.Canal;
import br.com.callink.cad.sau.service.ICanalService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

@Stateless
public class CanalService extends GenericCadSauService<Canal, ICanalDAO> implements ICanalService{

    private static final long serialVersionUID = -5718649287686925034L;

    @Inject
    private ICanalDAO canalDAO;
    
    @Override
	protected ICanalDAO getDAO() {
		return canalDAO;
	}
    
    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void save(Canal canal) throws ValidationException, ServiceException{
        canal.setDataCriacao(getDataBanco());
        super.save(canal);
    }
	
    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void update(Canal canal) throws ValidationException, ServiceException {
        canal.setDataCriacao(getDataBanco());
        super.update(canal);
    }

	/**
	 * @param canal
     * @throws ValidationException
     */
    private void validaCanal(Canal canal) throws ValidationException {
        if (canal == null) {
                throw new ValidationException("O Canal n\u00E3o pode ser nulo.");
        }
        if(StringUtils.isEmpty(canal.getNome()) || canal.getFlagAtivo() == null){
                throw new ValidationException("Favor preencher os campos brigat\u00F3rios!");
        }
    }

    @Override
    public void inativar(Canal canal) throws ValidationException, ServiceException {
        validaCanal(canal);
        canal.setFlagAtivo(Boolean.FALSE);
    }

    @Override
    public List<Canal> buscaCanalCadastroManualCaso() throws ServiceException {
        try {
            Canal canal = new Canal();
            canal.setFlagCasoManual(Boolean.TRUE);
            canal.setFlagAtivo(Boolean.TRUE);
            return getDAO().findByExample(canal, "Canal.NOME");
        } catch (DataException ex) {
            throw new ServiceException("Erro ao buscar os canais de cadastro de caso manual.",ex);
        }
    }

	@Override
	protected void validarSave(Canal object) throws ValidationException {
		validaCanal(object);
	}

	@Override
	protected void validarUpdate(Canal object) throws ValidationException {
		validaCanal(object);
	}

	@Override
	protected void validarDelete(Canal object) throws ValidationException {
		
	}

}
