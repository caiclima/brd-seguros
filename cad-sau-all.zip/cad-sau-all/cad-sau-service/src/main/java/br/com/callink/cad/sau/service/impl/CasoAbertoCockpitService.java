/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.sau.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.sau.dao.ICasoAbertoCockpitDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.CasoAbertoCockpit;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.pojo.TipoManifestacao;
import br.com.callink.cad.sau.service.ICasoAbertoCockpitService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 *
 * @author Rogerio Moreira de Andrade.
 */
@Stateless
public class CasoAbertoCockpitService extends GenericCadSauService<CasoAbertoCockpit, ICasoAbertoCockpitDAO> implements ICasoAbertoCockpitService {

	private static final long serialVersionUID = 6851009210043166213L;
	
	private static final String OUTROS = "OUTROS";
    private static final String TOTAL = "TOTAL";
    
    @Inject
    private ICasoAbertoCockpitDAO casoAbertoCockpitDAO;
    
    @Override
	protected ICasoAbertoCockpitDAO getDAO() {
		return casoAbertoCockpitDAO;
	}

    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void insert(List<CasoAbertoCockpit> casoAbertoCockpitList) throws ServiceException {
        try {
            Date dataBanco = getDataBanco();
            getDAO().delete(dataBanco);
            for (CasoAbertoCockpit kpt : casoAbertoCockpitList) {
                kpt.setDataProcessamento(dataBanco);
                getDAO().save(kpt);
            }
        } catch (DataException ex) {
            throw new ServiceException("Falha ao inserir lista CasoAbertoCockpit", ex);
        }
    }

    @Override
    public List<CasoAbertoCockpit> casosAbertos() throws ServiceException {
        try {
            return getDAO().casosAbertos();

        } catch (DataException ex) {
            throw new ServiceException("Falha selecionar lista de CasoAbertoCockpit", ex);
        }
    }

    @Override
    public List<CasoAbertoCockpit> casosAbertosFila() throws ServiceException {
        try {
            return getDAO().casosAbertosFila();

        } catch (DataException ex) {
            throw new ServiceException("Falha selecionar lista de CasoAbertoCockpit por Fila", ex);
        }
    }

    /**
     * Retora uma Lista de CasoAbertoCockpit separada pela lista de tipo de
     * manifestação enviada. Se a lista de tipo de manifestação for nula o
     * retorno será null.
     *
     * @param tipoManifestacaoList
     * @return
     */
    @Override
    public List<CasoAbertoCockpit> getCasoAbertoList(List<TipoManifestacao> tipoManifestacaoList) throws ServiceException {

        if (tipoManifestacaoList == null) {
            return null;
        }
        List<CasoAbertoCockpit> result = new ArrayList<CasoAbertoCockpit>();
        List<CasoAbertoCockpit> casoAbertoCockpitListt = casosAbertos();

        CasoAbertoCockpit casoAbertoCockpitOutros = null;
        CasoAbertoCockpit casoAbertoCockpitTodos = null;

        for (CasoAbertoCockpit value : casoAbertoCockpitListt) {

            Boolean naoAdicionado = Boolean.TRUE;

            for (TipoManifestacao tipoManifestacao : tipoManifestacaoList) {
                if (value.getTipoManifestacao().equals(tipoManifestacao.getNome())) {
                    result.add(value);
                    naoAdicionado = Boolean.FALSE;
                }
            }

            if (naoAdicionado && !value.getTipoManifestacao().equals(TOTAL)) {
                if (casoAbertoCockpitOutros == null) {
                    casoAbertoCockpitOutros = new CasoAbertoCockpit();
                    casoAbertoCockpitOutros.setTipoManifestacao(OUTROS);
                }
                casoAbertoCockpitOutros.adicionaOutros(value);
            } else if (value.getTipoManifestacao().equals(TOTAL)) {
                casoAbertoCockpitTodos = value;
                if (casoAbertoCockpitOutros != null) {
                    casoAbertoCockpitOutros.calculaTotalPercentual(casoAbertoCockpitTodos.getQtdTotal());

                }
            }

        }
        if (casoAbertoCockpitOutros != null) {
            result.add(casoAbertoCockpitOutros);
        }
        if(casoAbertoCockpitTodos!= null){
            result.add(casoAbertoCockpitTodos);
        }

        return result;
    }

    /**
     * Retora uma Lista de CasoAbertoCockpit separada pela lista de Fila de
     * configuracao enviada.
     *
     * @param configuracaoFilaList
     * @return
     */
    @Override
    public List<CasoAbertoCockpit> getCasoAbertoListPorFila(List<ConfiguracaoFila> configuracaoFilaList) throws ServiceException {

        if (configuracaoFilaList == null) {
            return null;
        }
        List<CasoAbertoCockpit> result = new ArrayList<CasoAbertoCockpit>();
        List<CasoAbertoCockpit> casoAbertoCockpitListt = casosAbertosFila();

        CasoAbertoCockpit casoAbertoCockpitOutros = null;
        CasoAbertoCockpit casoAbertoCockpitTodos = null;

        for (CasoAbertoCockpit value : casoAbertoCockpitListt) {

            Boolean naoAdicionado = Boolean.TRUE;


            for (ConfiguracaoFila configuracaoFila : configuracaoFilaList) {
                if (value.getNomeFilaAtendimento().equals(configuracaoFila.getNome())) {
                    result.add(value);
                    naoAdicionado = Boolean.FALSE;
                }
            }

            if (naoAdicionado && !value.getNomeFilaAtendimento().equals(TOTAL)) {
                if (casoAbertoCockpitOutros == null) {
                    casoAbertoCockpitOutros = new CasoAbertoCockpit();
                    casoAbertoCockpitOutros.setNomeFilaAtendimento(OUTROS);
                }
                casoAbertoCockpitOutros.adicionaOutros(value);
            } else if (value.getNomeFilaAtendimento().equals(TOTAL)) {
                casoAbertoCockpitTodos = value;
                if (casoAbertoCockpitOutros != null) {
                    casoAbertoCockpitOutros.calculaTotalPercentual(casoAbertoCockpitTodos.getQtdTotal());

                }
            }

        }
        if (casoAbertoCockpitOutros != null) {
            result.add(casoAbertoCockpitOutros);
        }
        if(casoAbertoCockpitTodos!= null){
            result.add(casoAbertoCockpitTodos);
        }

        return result;
    }

    /**
     * Separa a lista de caso por porcentagem da coluna 1 à 6 e o restante é
     * agrupado como sendo > que o valor da coluna 6; Sempre que esse método é
     * chamado ele executa o clean da sua variável e gera novamente a lista de
     * casos abertos. Os casos serão contados e separados por porcentagem.
     *
     * @param casoSauList
     */
    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void addRelatorioList(List<CasoSau> casoSauList, Properties propertiesApp) throws ServiceException {

        if (casoSauList == null || casoSauList.isEmpty()) {
            return;
        }

        Map<String, CasoAbertoCockpit> mapCasoAberto = new HashMap<String, CasoAbertoCockpit>();
        Map<String, CasoAbertoCockpit> mapCasoAbertoFila = new HashMap<String, CasoAbertoCockpit>();

        Double coluna1;
        Double coluna2;
        Double coluna3;
        Double coluna4;
        Double coluna5;
        Double coluna6;

        try {
            coluna1 = Double.valueOf(propertiesApp.getProperty("sla_coluna_1"));
            coluna2 = Double.valueOf(propertiesApp.getProperty("sla_coluna_2"));
            coluna3 = Double.valueOf(propertiesApp.getProperty("sla_coluna_3"));
            coluna4 = Double.valueOf(propertiesApp.getProperty("sla_coluna_4"));
            coluna5 = Double.valueOf(propertiesApp.getProperty("sla_coluna_5"));
            coluna6 = Double.valueOf(propertiesApp.getProperty("sla_coluna_6"));

        } catch (NumberFormatException ex) {
            logger4j.error(ex.getMessage(),ex);
            return;
        }

        CasoAbertoCockpit casoTotal = new CasoAbertoCockpit();
        CasoAbertoCockpit casoTotalFila = new CasoAbertoCockpit();
        casoTotal.setTipoManifestacao(TOTAL);
        casoTotal.setFlagFila(Boolean.FALSE);
        casoTotalFila.setNomeFilaAtendimento(TOTAL);
        casoTotalFila.setFlagFila(Boolean.TRUE);

        for (CasoSau casoSau : casoSauList) {
            Double porcentagemSla = casoSau.getCaso().getPorcentagemSla();
            CasoAbertoCockpit casoAbertoCockpit = mapCasoAberto.get(casoSau.getTipoManifestacao().getNome());
            CasoAbertoCockpit casoAbertoCockpitFila = mapCasoAbertoFila.get(casoSau.getCaso().getConfiguracaoFila().getNome());
            if (casoAbertoCockpit == null) {
                casoAbertoCockpit = new CasoAbertoCockpit();
                casoAbertoCockpit.setTipoManifestacao(casoSau.getTipoManifestacao().getNome());
                casoAbertoCockpit.setFlagFila(Boolean.FALSE);
            }

            if (casoAbertoCockpitFila == null) {
                casoAbertoCockpitFila = new CasoAbertoCockpit();
                casoAbertoCockpitFila.setNomeFilaAtendimento(casoSau.getCaso().getConfiguracaoFila().getNome());
                casoAbertoCockpitFila.setFlagFila(Boolean.TRUE);
            }


            //verifica a qual coluna pertence a porcentagem para relatorio por tipo manifestacao
            verificaPorcentagemPorColuna(coluna1, coluna2, coluna3, coluna4,
                    coluna5, coluna6, casoTotal, porcentagemSla,
                    casoAbertoCockpit);

            //verifica a qual coluna pertence a porcentagem para relatorio por fila atendimento
            verificaPorcentagemPorColuna(coluna1, coluna2, coluna3, coluna4,
                    coluna5, coluna6, casoTotalFila, porcentagemSla,
                    casoAbertoCockpitFila);

            casoAbertoCockpit.calculaTotalPercentual(casoTotal.getQtdTotal());
            casoAbertoCockpitFila.calculaTotalPercentual(casoTotalFila.getQtdTotal());

            mapCasoAberto.put(casoSau.getTipoManifestacao().getNome(), casoAbertoCockpit);
            mapCasoAbertoFila.put(casoSau.getCaso().getConfiguracaoFila().getNome(), casoAbertoCockpitFila);
        }
        casoTotal.calculaTotalPercentual(casoTotal.getQtdTotal());
        casoTotalFila.calculaTotalPercentual(casoTotalFila.getQtdTotal());
        mapCasoAberto.put(casoTotal.getTipoManifestacao(), casoTotal);
        mapCasoAbertoFila.put(casoTotalFila.getNomeFilaAtendimento(), casoTotalFila);

        ArrayList<CasoAbertoCockpit> salvaListCasoAbertoCockpit = new ArrayList<CasoAbertoCockpit>(mapCasoAberto.values());
        salvaListCasoAbertoCockpit.addAll(mapCasoAbertoFila.values());
        insert(salvaListCasoAbertoCockpit);
    }

    /**
     * Verifica a qual coluna pertence a porcentagem
     *
     * @param coluna1
     * @param coluna2
     * @param coluna3
     * @param coluna4
     * @param coluna5
     * @param coluna6
     * @param casoTotal
     * @param porcentagemSla
     * @param casoAbertoCockpit
     */
    private void verificaPorcentagemPorColuna(Double coluna1,
            Double coluna2, Double coluna3, Double coluna4, Double coluna5,
            Double coluna6, CasoAbertoCockpit casoTotal, Double porcentagemSla,
            CasoAbertoCockpit casoAbertoCockpit) {
        //Verifica a qual coluna pertence aquela porcentagem
        if (porcentagemSla <= coluna1) {
            casoAbertoCockpit.addQtdPrimeiroDia();
            casoTotal.addQtdPrimeiroDia();
        } else if (porcentagemSla <= coluna2) {
            casoAbertoCockpit.addQtdSegundoDia();
            casoTotal.addQtdSegundoDia();
        } else if (porcentagemSla <= coluna3) {
            casoAbertoCockpit.addQtdTerceiroDia();
            casoTotal.addQtdTerceiroDia();
        } else if (porcentagemSla <= coluna4) {
            casoAbertoCockpit.addQtdQuartoDia();
            casoTotal.addQtdQuartoDia();
        } else if (porcentagemSla <= coluna5) {
            casoAbertoCockpit.addQtdQuintoDia();
            casoTotal.addQtdQuintoDia();
        } else if (porcentagemSla <= coluna6) {
            casoAbertoCockpit.addQtdSextoDia();
            casoTotal.addQtdSextoDia();
        } else {
            casoAbertoCockpit.addQtdRestanteDia();
            casoTotal.addQtdRestanteDia();
        }

    }

	@Override
	protected void validarSave(CasoAbertoCockpit object)
			throws ValidationException {
		
	}

	@Override
	protected void validarUpdate(CasoAbertoCockpit object)
			throws ValidationException {
		
	}

	@Override
	protected void validarDelete(CasoAbertoCockpit object)
			throws ValidationException {
		
	}
}
