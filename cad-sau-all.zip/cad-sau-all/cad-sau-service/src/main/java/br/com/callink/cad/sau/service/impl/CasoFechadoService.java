package br.com.callink.cad.sau.service.impl;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.inject.Inject;

import br.com.callink.cad.sau.dao.ICasoFechadoDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.CasoFechado;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.service.ICasoFechadoService;
import br.com.callink.cad.sau.service.ICasoSauService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 * 
 * @author Ednando Caic [ednaldo@swb.com.br]
 * @since 16/01/2012
 * 
 */
@Stateless
public class CasoFechadoService extends GenericCadSauService<CasoFechado, ICasoFechadoDAO>
		implements ICasoFechadoService {
    
	private static final long serialVersionUID = 245628781640263940L;

	@Inject
	private ICasoFechadoDAO casoFechadoDAO;
	
	@EJB
	private ICasoSauService casoSauService;
	
	@Override
	protected ICasoFechadoDAO getDAO() {
		return casoFechadoDAO;
	}
	
    @Override
    public CasoFechado buscaPorManifestacao(String manifestacao) throws ServiceException {
        try {
            CasoFechado casoFechado =  getDAO().buscaPorManifestacao(manifestacao);
            
            if(casoFechado != null && casoFechado.getManifestacao() != null){
                CasoSau casoSau = new CasoSau();
                casoSau.setManifestacao(manifestacao);
                casoFechado.setCasoSau(casoSauService.load(casoSau));
            }
            return casoFechado;
            
            
        } catch (Exception e) {
            throw new ServiceException("Erro ao buscar Caso Fechado por manifesta\u00E7\u00E3o", e);
        }
    }
    
    @Override
    public List<CasoFechado> buscaCasosFechadosSpaAbertosGbo() throws ServiceException {
        try {
            return getDAO().buscaCasosFechadosSpaAbertosGbo();
        } catch (DataException ex) {
            throw  new ServiceException("Erro ao buscar casos fechados e abertos no gbo", ex);
        }
    }

	@Override
	protected void validarSave(CasoFechado object) throws ValidationException {
		
	}

	@Override
	protected void validarUpdate(CasoFechado object) throws ValidationException {
		
	}

	@Override
	protected void validarDelete(CasoFechado object) throws ValidationException {
		
	}
    
}