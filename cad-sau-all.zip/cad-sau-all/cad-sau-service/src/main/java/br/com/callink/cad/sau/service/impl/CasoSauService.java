package br.com.callink.cad.sau.service.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;
import org.apache.commons.lang.StringUtils;
import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.ConfiguracaoFila;
import br.com.callink.cad.pojo.EquipeFila;
import br.com.callink.cad.pojo.HistoricoDadosCaso;
import br.com.callink.cad.pojo.Log;
import br.com.callink.cad.pojo.ParametroGBO;
import br.com.callink.cad.pojo.Status;
import br.com.callink.cad.pojo.Telefone;
import br.com.callink.cad.repository.MarcacaoLogs;
import br.com.callink.cad.sau.dao.ICasoSauDAO;
import br.com.callink.cad.sau.enumeration.TipoAssocicaoCasoAtendente;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.Assunto;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.pojo.to.AcompanhamentoCasoFind;
import br.com.callink.cad.sau.repository.CasosClassificadosCockpit;
import br.com.callink.cad.sau.service.ICasoAbertoCockpitService;
import br.com.callink.cad.sau.service.ICasoSauService;
import br.com.callink.cad.sau.service.IEventoService;
import br.com.callink.cad.service.IAtendenteService;
import br.com.callink.cad.service.IAuthenticatorService;
import br.com.callink.cad.service.ICasoService;
import br.com.callink.cad.service.IEquipeFilaService;
import br.com.callink.cad.service.ILogService;
import br.com.callink.cad.service.IParametroGBOService;
import br.com.callink.cad.service.ISlaService;
import br.com.callink.cad.service.IStatusService;
import br.com.callink.cad.service.ITelefoneService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.service.impl.AuthenticatorService;
import br.com.callink.cad.util.Constantes;
import br.com.callink.cad.util.CpfCnpj;
import br.com.callink.cad.util.Data;
import com.google.gson.Gson;

/**
 * 
 * @author Ednando Caic [ednaldo@swb.com.br]
 * @since 16/01/2012
 * 
 */
@Stateless
public class CasoSauService extends GenericCadSauService<CasoSau, ICasoSauDAO> implements ICasoSauService {

	private static final long serialVersionUID = 1L;
    
    @Inject
    private ICasoSauDAO casoSauDAO;
    
    @EJB
    private ICasoService casoService;
    @EJB
    private IStatusService statusService;
    @EJB
    private ITelefoneService telefoneService;
    @EJB
    private IEventoService eventoService;
    @EJB
    private IEquipeFilaService equipeFilaService;
    @EJB(beanName="SlaTipoFilaService")
    private ISlaService slaService;
    @EJB
    private IParametroGBOService parametroService;
    @EJB
    private ICasoAbertoCockpitService casoAbertoCockpitService;
    @EJB
    private IAuthenticatorService authenticatorService;
    @EJB
    private IAtendenteService atendenteService;
    @EJB
    private ILogService logService;
    
    @Override
	protected ICasoSauDAO getDAO() {
		return casoSauDAO;
	}

    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void save(CasoSau casoSau, Atendente atendente) throws ValidationException, ServiceException {

        try {
            String erros = valida(casoSau);
            if (StringUtils.isNotBlank(erros)) {
                throw new ValidationException(erros);
            }

            if (!StringUtils.isBlank(casoSau.getManifestacao())
                    && getDAO().existeManifestacao(casoSau.getManifestacao())) {
                throw new ValidationException(
                        "Manifesta\u00E7\u00E3o informada j\u00E1 existe base de dados!");
            }
            if (casoSau.getCaso() != null
                    && getDAO().existeCasoGbo(casoSau.getCaso())) {
                throw new ValidationException(
                        "Erro : Caso informado j\u00E1 existe base de dados!");
            }
            
            if (casoSau.getDataAbertura() == null) {
            	casoSau.setDataAbertura(getDataBanco());
            }

            saveCasoGbo(casoSau);
            saveTelefones(casoSau);
            super.save(casoSau);

            Log log = new Log();
            log.setCaso(casoSau.getCaso());
            log.setStatus(casoSau.getCaso().getStatus());
            log.setAtendente(atendente);
            log.setDescricao("Caso cadastrado com sucesso.");

            MarcacaoLogs.offer(log);


        } catch (DataException e) {
            throw new ServiceException("Erro ao salvar Caso.", e);
        }
    }

    @Override
    public void update(CasoSau casoSau) throws ValidationException, ServiceException {

        String erros = valida(casoSau);
        if (StringUtils.isNotBlank(erros)) {
            throw new ServiceException(erros);
        }

        //Salvando o caso conforme o mesmo se encontrava antes do UPDATE. Pode ser utilizado para uma visualização futura.
        //Somente será salvo se for uma atualização feita por um atendente.
        HistoricoDadosCaso historicoDadosCaso = new HistoricoDadosCaso();
        historicoDadosCaso.setAtendente(casoSau.getCaso().getAtendente());
        historicoDadosCaso.setCaso(casoSau.getCaso());
        Gson gson = new Gson();
        historicoDadosCaso.setCasoJson(gson.toJson(casoSau));
        
        if (historicoDadosCaso.getAtendente() != null && historicoDadosCaso.getAtendente().getIdAtendente() != null) {
        	MarcacaoLogs.offer(historicoDadosCaso);
        }
        
        super.update(casoSau);
    }

    private String valida(CasoSau casoSau) throws ServiceException {

        StringBuilder erros = new StringBuilder();

        if (casoSau.getTipoManifestacao() == null
                || casoSau.getTipoManifestacao().getPK() == null) {
            erros.append("Campo Obrigat\u00F3rio : Tipo Manifesta\u00E7\u00E3o ").append(
                    Constantes.NOVA_LINHA);
        }
        if (casoSau.getCanal() == null || casoSau.getCanal().getPK() == null) {
            erros.append("Campo Obrigat\u00F3rio : Canal ").append(
                    Constantes.NOVA_LINHA);
        }
        if (casoSau.getIdCasoSau() == null) {
            if (casoSau.getEvento() == null || casoSau.getEvento().getPK() == null) {
                erros.append("Campo Obrigat\u00F3rio : Evento ").append(
                        Constantes.NOVA_LINHA);
            }
            if (StringUtils.isBlank(casoSau.getDescricao())) {
                erros.append("Campo Obrigat\u00F3rio : Descri\u00E7\u00E3o").append(
                        Constantes.NOVA_LINHA);
            }
            if (StringUtils.isBlank(casoSau.getCartao())) {
                erros.append("Campo Obrigat\u00F3rio : Cart\u00E3o").append(
                        Constantes.NOVA_LINHA);
            }
            if (StringUtils.isBlank(casoSau.getTipoCartao())) {
                erros.append("Campo Obrigat\u00F3rio : Tipo Cart\u00E3o").append(
                        Constantes.NOVA_LINHA);
            }
        }
        if (StringUtils.isBlank(casoSau.getNomeCliente())) {
            erros.append("Campo Obrigat\u00F3rio : Nome Cliente ").append(
                    Constantes.NOVA_LINHA);
        }
        if (StringUtils.isBlank(casoSau.getCpfCnpj()) && casoSau.getIdCasoSau() == null) {
            erros.append("Campo Obrigat\u00F3rio : Cpf/Cnpj ").append(
                    Constantes.NOVA_LINHA);
        }
        
        if ((casoSau.getFlagManual() == null || !casoSau.getFlagManual())&& StringUtils.isBlank(casoSau.getManifestacao())) {
            erros.append("Campo Obrigat\u00F3rio : Manifesta\u00E7\u00E3o ").append(
                    Constantes.NOVA_LINHA);
        }
        
        if (StringUtils.isNotBlank(casoSau.getCpfCnpj()) && casoSau.getIdCasoSau() == null) {

            String cpfCnpj = CpfCnpj.validaCpfCnpj(casoSau.getCpfCnpj());

            if (cpfCnpj == null) {
                StringBuilder string = new StringBuilder();
                string.append("Cpf/Cnpj inv\u00E1lido! Cpf/Cnpj: ");
                string.append(casoSau.getCpfCnpj());
                erros.append(string).append(Constantes.NOVA_LINHA);
            } else {
                casoSau.setCpfCnpj(cpfCnpj);
            }
        }

        return erros.toString();

    }

    private void carregaSlaCaso(List<CasoSau> casoSauList, List<Caso> casoList) throws ServiceException {
        for (CasoSau casoSau : casoSauList) {
            casoList.add(casoSau.getCaso());
        }
        
        casoService.carregaSlas(casoList);
    }

    @Override
    public Boolean juncaoForaPrazo(CasoSau caso)throws ServiceException{
    	ParametroGBO param = parametroService.findByParam(Constantes.PARAMETRO_JUNCAO_ATRAZO);
        Integer padrao = Integer.valueOf(param.getValor());
        
        Integer inicioContagem = Integer.valueOf(parametroService.findByParam(Constantes.INICIO_SLA).getValor());
		
		inicioContagem = inicioContagem == null ? Integer.valueOf(1) : inicioContagem;
        
        Long minutos = slaService.calculaSlaMinutos(caso.getDataAbertura(), caso.getCaso().getDataCadastro(), inicioContagem);
        
        if(minutos >= padrao){
            return Boolean.TRUE;
        }
        return Boolean.FALSE;
    } 
    
    private void saveCasoGbo(CasoSau casoSau) throws ValidationException, ServiceException {
        ParametroGBO idStatus = parametroService.findByParam(Constantes.ID_STATUS_CADASTRO_MANUAL);
        Status stats = new Status(Integer.valueOf(idStatus.getValor()));
        Status status = statusService.findByPk(stats);

        Caso caso = new Caso();
        caso.setDataAbertura(casoSau.getDataAbertura());
        caso.setDataCadastro(getDataBanco());
        caso.setStatus(status);
        caso.setFlagClassifica(Boolean.TRUE);
        caso.setFlagFinalizado(Boolean.FALSE);
        caso.setIdExterno(casoSau.getManifestacao());
        casoService.save(caso);
        casoSau.setCaso(caso);

        if (casoSau.getFlagManual() != null && casoSau.getFlagManual()) {
            String manifestacao = "M" + caso.getIdCaso();
            casoSau.setManifestacao(manifestacao);
            caso.setIdExterno(manifestacao);
            casoService.update(caso);
        }
    }

    private void saveTelefones(CasoSau casoSau) throws ValidationException, ServiceException {
        if (StringUtils.isNotBlank(casoSau.getTelefone())) {
            Telefone telefone01 = new Telefone();//TelefoneService.validaTelefone(casoSau.getTelefone());
            telefone01.setTelefone(casoSau.getTelefone());
            telefone01.setCaso(casoSau.getCaso());
            telefone01.setDataCadastro(casoSau.getDataAbertura());
            telefoneService.save(telefone01);
        }
        if (StringUtils.isNotBlank(casoSau.getTelefoneSegundo())) {
            Telefone telefone02 = new Telefone();
            telefone02.setTelefone(casoSau.getTelefoneSegundo());//TelefoneService.validaTelefone(casoSau.getTelefoneSegundo());
            telefone02.setCaso(casoSau.getCaso());
            telefone02.setDataCadastro(casoSau.getDataAbertura());
            telefoneService.save(telefone02);
        }
    }

    @Override
    public CasoSau findCasoSauByCaso(Caso caso) throws ServiceException {
        try {
            return getDAO().findCasoSauByCaso(caso);
        } catch (DataException ex) {
            throw new ServiceException("Erro ao buscar Caso.", ex);
        }
    }

    @Override
    public List<CasoSau> findCasoSauByCaso(List<Caso> casos)
            throws ServiceException {
        try {
            if (casos != null) {
                List<CasoSau> listCasoSau = new ArrayList<CasoSau>(casos.size());

                for (Caso caso : casos) {
                    CasoSau casoSau = getDAO().findCasoSauByCaso(caso);
                    casoSau.setCaso(caso);
                    listCasoSau.add(casoSau);
                }

                return listCasoSau;
            }

            return null;
        } catch (DataException ex) {
            throw new ServiceException("Erro ao buscar Caso.", ex);
        }

    }

    @Override
    public CasoSau load(CasoSau casoSau) throws ServiceException {
        try {
        	Caso caso = casoSau.getCaso();
        	
        	caso = casoService.load(caso);
        	casoService.carregaSlaEmailCaso(caso);
        	
        	casoSau.setCaso(caso);
        	
            CasoSau sau = getDAO().load(casoSau);
            if (sau.getCpfCnpj() != null) {
                String cpfCnpj = CpfCnpj.validaCpfCnpj(sau.getCpfCnpj());
                if (cpfCnpj != null && !cpfCnpj.equals(sau.getCpfCnpj())) {
                    sau.setCpfCnpj(cpfCnpj);
                    try {
						update(sau);
					} catch (ValidationException e) {
						throw new ServiceException(e);
					}
                }
            }
            return sau;
        } catch (DataException ex) {
            throw new ServiceException("Erro ao carregar Caso.", ex);
        }
    }

    @Override
    public List<CasoSau> buscaPorConfiguracaoFilaEAtendente(
            ConfiguracaoFila configuracaoFila, Atendente atendente)
            throws ServiceException {
        try {
            return getDAO().buscaPorConfiguracaoFilaEAtendente(
                    configuracaoFila, atendente);
        } catch (DataException e) {
            throw new ServiceException("Erro ao buscar Casos.", e);
        }
    }

    @Override
    public List<CasoSau> buscaPorFiltros(AcompanhamentoCasoFind acompanhamentoCasoFind) throws ServiceException {
        try {
            if ((acompanhamentoCasoFind.getEventoSelecionadoList() == null || acompanhamentoCasoFind.getEventoSelecionadoList().isEmpty()) 
            		&& (acompanhamentoCasoFind.getAssuntoSelecionadoList() != null && !acompanhamentoCasoFind.getAssuntoSelecionadoList().isEmpty())) {

                List<Assunto> assuntoSelecionado = new ArrayList<Assunto>();

                for (Assunto assunto : acompanhamentoCasoFind.getAssuntoSelecionadoList()) {
                    if (assunto.getSelecionado() != null && assunto.getSelecionado().equals(Boolean.TRUE)) {
                        assuntoSelecionado.add(assunto);
                    }
                }
                if (!assuntoSelecionado.isEmpty()) {
                	acompanhamentoCasoFind.setEventoSelecionadoList(eventoService.findByAssuntoList(assuntoSelecionado));
                }
            }

            if (acompanhamentoCasoFind.getCasoSau().getCpfCnpj() != null
                    && CpfCnpj.validaCpfCnpj(acompanhamentoCasoFind.getCasoSau().getCpfCnpj()) == null) {
            	acompanhamentoCasoFind.getCasoSau().setCpfCnpj(CpfCnpj.formataRemocaoCaracteresEspeciais(acompanhamentoCasoFind.getCasoSau().getCpfCnpj()));
            }
            if (acompanhamentoCasoFind.getDataInicio() != null && acompanhamentoCasoFind.getDataFim() != null
                    && Data.diferencaEmDias(acompanhamentoCasoFind.getDataFim(), acompanhamentoCasoFind.getDataInicio()) > 60) {
                throw new ValidationException(
                        "Per\u00EDodo de pesquisa n\u00E3o pode ser maior do que 60 dias.");
            }

            List<CasoSau> casoSauList = getDAO().buscaPorFiltroSQL(acompanhamentoCasoFind);

            if (acompanhamentoCasoFind.getSlaEmMinutos() != null || acompanhamentoCasoFind.getSlaEmMinutosMaior() != null ) {

                for (Iterator<CasoSau> iterator = casoSauList.iterator(); iterator.hasNext();) {
                    CasoSau casoSau2 = (CasoSau) iterator.next();
                    
                    if (acompanhamentoCasoFind.getSlaEmMinutos() != null && casoService.verificaSlaMaiorParametro(casoSau2.getCaso(), acompanhamentoCasoFind.getSlaEmMinutos()) == null) {
                        iterator.remove();
                        continue;
                    }
                    
                    if (acompanhamentoCasoFind.getSlaEmMinutosMaior() != null && casoService.verificaSlaMenorParametro(casoSau2.getCaso(), acompanhamentoCasoFind.getSlaEmMinutosMaior()) == null) {
                        iterator.remove();
                    }
                    
                }

            } else {
            	Date data = getDataBanco();
                for (CasoSau casoSauItem : casoSauList) {
                    casoService.calculaSla(casoSauItem.getCaso(), data);
                }
            }
            return casoSauList;
        } catch (DataException | ValidationException e) {
            throw new ServiceException("Erro ao buscar Casos.", e);
        }
    }

    @Override
    public List<CasoSau> buscaPorFilaOrAtendenteOrManifestacao(
                    ConfiguracaoFila configuracaoFila, Atendente atendente, String manifestacao)
                    throws ServiceException {
            try {
                    return getDAO().buscaPorFilaOrAtendenteOrManifestacao(configuracaoFila, atendente, manifestacao);
            } catch (DataException e) {
                    throw new ServiceException("Erro ao buscar Casos", e);
            }
    }

    @Override
    public List<CasoSau> buscaCasosFechadosNoDia() throws ServiceException {
        try {
            List<CasoSau> casoSauList = getDAO().buscaCasosFechadosNoDia();
            List<Caso> casoList = new ArrayList<Caso>();
                
            carregaSlaCaso(casoSauList, casoList);
            return casoSauList;
            
        } catch (DataException ex) {
            throw  new ServiceException("Erro ao buscar os casos fechados no dia.",ex);
        }
    }
    
    @Override
    public List<CasoSau> buscaCasosPendenteChecagem() throws ServiceException {
    	try {
    		Status status = new Status();
    		status.setNome(Constantes.STATUS_PENDENTE);
    		
    		List<Status> listStatus = statusService.findByExample(status);
    		List<Caso> casoList = new ArrayList<Caso>();
    		
    		List<CasoSau> casoSauList = new ArrayList<CasoSau>();
    		
    		if (listStatus != null && !listStatus.isEmpty()) {
    			casoSauList = getDAO().buscaCasosFechadosChecagemNoDia(listStatus.get(0));
    			
    			carregaSlaCaso(casoSauList, casoList);
    		}
    		
    		return casoSauList;
    		
    	} catch ( DataException e) {
			throw new ServiceException("Erro ao buscar casos fechados de pendencia checagem", e);
		}
    }
    
    @Override
    public List<CasoSau> buscaCasoReabertoDia() throws ServiceException {
        try {
            List<CasoSau> casoSauList = getDAO().buscaCasoReabertoDia();
            
            return casoSauList;
        } catch (DataException ex) {
            throw new ServiceException("Erro ao buscar os casos reabertos no dia.",ex);
        }
        
        
    }
    
    @Override
    public void geraCockpitCasosAbertos() throws ServiceException {
        try {
            List<CasoSau> casoSauList = buscaCasoAbertoSemPendencia();
            List<Caso> casoList = new ArrayList<Caso>();
            Properties propertiesApp = new Properties();
            
            propertiesApp.load(CasoSauService.class.getResourceAsStream("/config/gbo.properties"));
            
            carregaSlaCaso(casoSauList, casoList);

            casoAbertoCockpitService.addRelatorioList(casoSauList, propertiesApp);
        } catch (IOException ex) {
            throw  new ServiceException("Erro ao Gerar o Cockpit Casos Abertos.",ex);
        }
    }

    @Override
    public List<CasoSau> buscaCasoAberto() throws ServiceException {
        try {
            return getDAO().buscaCasoAberto();
        } catch (DataException ex) {
            throw new ServiceException("Erro ao buscar casos abertos.",ex);
        }
    }
    
    
    @Override
    public List<CasoSau> buscaCasoAbertoSemPendencia() throws ServiceException {
        try {
        	Status status = new Status();
        	status.setNome(Constantes.STATUS_PENDENTE);
        	List<Status> listStatus = statusService.findByExample(status);
        	
            return getDAO().buscaCasoAbertoSemPendencia(listStatus != null && !listStatus.isEmpty() ? listStatus.get(0).getIdStatus() : 0);
        
        } catch (DataException ex) {
            throw new ServiceException("Erro ao buscar casos abertos.",ex);
        }
    }
    

    @Override
    public List<CasoSau> buscaCasoAbertoAssunto() throws ServiceException {
        try {
            return getDAO().buscaCasoAbertoAssunto();
        } catch (DataException ex) {
            throw  new ServiceException("Erro ao buscar os casos abertos.",ex);
        }
    }
    
    @Override
    public void geraCockpitClassificacaoCasos() throws ServiceException {
        try {
            List<CasoSau> casoSauList = buscaCasoAbertoAssunto();
            List<Caso> casoList = new ArrayList<Caso>();
            carregaSlaCaso(casoSauList, casoList);
            ParametroGBO parametroGBO = parametroService.findByParam(Constantes.TEMPO_ESTOURADO);

            CasosClassificadosCockpit.addRelatorioList(casoSauList, Integer.valueOf(parametroGBO.getValor()) * 60);
        } catch (ServiceException ex) {
            throw  new ServiceException("Erro ao Gerar o Cockpit Classificacao Casos.",ex);
        }
    }

    @Override
    public List<CasoSau> buscaCasoEntranteDia() throws ServiceException {
        try {
            return getDAO().buscaCasoEntranteDia();
        } catch (DataException ex) {
            throw  new ServiceException("Erro ao buscar todos os casos abertos no dia.",ex);
        }
    }

    @Override
    public List<CasoSau> buscarCasoSauPorCpfCnpj(String cpfCnpj) throws ServiceException {
        try {
            List<Caso> casoList = new ArrayList<Caso>();
        	List<CasoSau> casoSauList = getDAO().buscarCasoSauPorCpfCnpj(cpfCnpj);
        	
            carregaSlaCaso(casoSauList, casoList);
            
            return casoSauList;
        } catch (DataException e) {
            throw new ServiceException("Erro ao buscar CasoSau Por CpfCnpj", e);
        }
    }
    
    @Override
    public List<CasoSau> buscarCasoSauPorCpfCnpjEFiltraAssociarCaso(String cpfCnpj, Atendente atendente) throws ServiceException {
        try {
            List<Caso> casoList = new ArrayList<Caso>();
        	List<CasoSau> casoSauList = getDAO().buscarCasoSauPorCpfCnpj(cpfCnpj);
        	
            carregaSlaCaso(casoSauList, casoList);
            
            casoSauList = filtrarCasoSauParaAssociarCaso(casoSauList, atendente);
            
            return casoSauList;
        } catch (DataException e) {
            throw new ServiceException("Erro ao buscar CasoSau Por CpfCnpj E FiltraAssociarCaso", e);
        }
    }
    
    public List<CasoSau> filtrarCasoSauParaAssociarCaso(List<CasoSau> listCasoSaus, Atendente atendente ) throws ServiceException{  
    	try {
	    	if(listCasoSaus != null) {
	    		
	    		for(CasoSau casoSau : listCasoSaus) {
	        		if(casoSau.getCaso().getFlagFinalizado() && casoSau.getCaso().getDataEncerramento() != null) {
	        			
	        			casoSau.setFlagCasoAssociar(Boolean.FALSE);
	        		} else if(casoSau.getCaso() != null 
	        				&& casoSau.getCaso().getAtendente() != null
	        				&& casoSau.getCaso().getAtendente().getIdAtendente() != null 
	        				&& casoSau.getCaso().getAtendente().getIdAtendente().equals(atendente.getIdAtendente())) {
	        			
	        			casoSau.setFlagCasoAssociar(Boolean.FALSE);
	        		} else if(!validaCasoComConfiguracaoFilaAtendente(casoSau.getCaso(), atendente)) {
	        			
	        			casoSau.setFlagCasoAssociar(Boolean.FALSE);
	        		} else {
	        			
	        			casoSau.setFlagCasoAssociar(Boolean.TRUE);
	        		}
	        	}
	    	}
    	} catch (Exception e) {
            throw new ServiceException("Erro ao buscar Casos por cpf ou cnpj", e);
        }
    	
    	return listCasoSaus;
    }
    
    private boolean validaCasoComConfiguracaoFilaAtendente(Caso caso, Atendente atendente) throws ServiceException {
    	
    	try {
	    	EquipeFila equipeFila = new EquipeFila();
	        equipeFila.setEquipe(atendente.getEquipe());
	
	        List<EquipeFila> equipeFilaList = equipeFilaService.findByExample(equipeFila);
	        
	        for(EquipeFila equipeFilaAtendente : equipeFilaList) {
	        	if(equipeFilaAtendente.getConfiguracaoFila().getIdConfiguracaoFila().equals(caso.getConfiguracaoFila().getIdConfiguracaoFila())) {
	        		return Boolean.TRUE;
	        	}
	        }
    	} catch (Exception e) {
            throw new ServiceException("Erro ao valida Caso Com ConfiguracaoFila Atendente", e);
        }
        return Boolean.FALSE;
    }
    
    public List<CasoSau> validaCasoParaAssociarCasoAtendente(List<CasoSau> listCasoSau, Integer idUsuarioLogado) throws ServiceException {
    	try {
    		
	    	if(listCasoSau != null) {
	    		for(CasoSau casoSau : listCasoSau) {
	    			validaCasoSauAtendimento(idUsuarioLogado, casoSau);
	    		}
	    	}
    	} catch (Exception e) {
            throw new ServiceException("Erro ao valida Caso Para Associar Caso Atendente", e);
        }
    	return listCasoSau;
    }

	private void validaCasoSauAtendimento(Integer idUsuarioLogado,
			CasoSau casoSau) {
		if(casoSau.getCaso() != null 
				&& casoSau.getCaso().getAtendente() != null 
				&& casoSau.getCaso().getAtendente().getIdAtendente() != null
				&& !casoSau.getCaso().getAtendente().getIdAtendente().equals(idUsuarioLogado) 
				&& casoSau.getCaso().getFlagEmAtendimento().equals(Boolean.TRUE)) {
			
			casoSau.setTipoAssociacaoCaso(TipoAssocicaoCasoAtendente.BLOQUEIO_OUTRO_ATENDENTE_EM_ATENDIMENTO.getTipoAssocicaoCasoAtendente());
			casoSau.setMotivo("O caso encontra-se em atendimento pelo atendente: "+casoSau.getCaso().getAtendente().getLogin());
			
		} else if(casoSau.getCaso() != null 
				&& casoSau.getCaso().getAtendente() != null 
				&& casoSau.getCaso().getAtendente().getIdAtendente() != null
				&& !casoSau.getCaso().getAtendente().getIdAtendente().equals(idUsuarioLogado) 
				&& casoSau.getCaso().getFlagEmAtendimento().equals(Boolean.FALSE)) {
			
			casoSau.setTipoAssociacaoCaso(TipoAssocicaoCasoAtendente.SENHA_OUTRO_ATENDENTE_NAO_ATENDIMENTO.getTipoAssocicaoCasoAtendente());
			casoSau.setMotivo("Exige senha do supervisor");
			
		} else if(casoSau.getCaso() != null && (casoSau.getCaso().getAtendente() == null || casoSau.getCaso().getAtendente().getIdAtendente() == null)){
			
			casoSau.setTipoAssociacaoCaso(TipoAssocicaoCasoAtendente.OK_NENHUM_OUTRO_ATENDENTE.getTipoAssocicaoCasoAtendente());
			casoSau.setMotivo("");
		}
	}
    
    public void confirmaDadosCasoSauAssociacao(List<CasoSau> listCasoSau, String loginSupervisor, String senhaSupervisor, Atendente atendente) throws ServiceException {
    	try {
    		
	    	List<CasoSau> listCasoSauAssociar = new ArrayList<CasoSau>();
	    	
			for(CasoSau casoSau :  listCasoSau) {
				
				Boolean selecionado = casoSau.getSelecionado() == null ? Boolean.FALSE : casoSau.getSelecionado();
				
				casoSau = getDAO().findByPk(casoSau);
				casoSau = getDAO().load(casoSau);
				casoSau.setSelecionado(selecionado);
				
				if(casoSau.getSelecionado()) {
					validaCasoSauAtendimento(atendente.getIdAtendente(), casoSau);	
					if(casoSau.getTipoAssociacaoCaso() != null && 
							casoSau.getTipoAssociacaoCaso().equals(TipoAssocicaoCasoAtendente.BLOQUEIO_OUTRO_ATENDENTE_EM_ATENDIMENTO.getTipoAssocicaoCasoAtendente())) {
						
						throw new ValidationException("Existem casos bloqueados para associa\u00E7\u00E3o");
					} else if(casoSau.getTipoAssociacaoCaso() != null && 
							casoSau.getTipoAssociacaoCaso().equals(TipoAssocicaoCasoAtendente.SENHA_OUTRO_ATENDENTE_NAO_ATENDIMENTO.getTipoAssocicaoCasoAtendente())) {
						
						if((loginSupervisor == null || StringUtils.isEmpty(loginSupervisor)) && (senhaSupervisor == null || StringUtils.isEmpty(senhaSupervisor))) {
							throw new ValidationException("Existem casos a serem liberados pelo supervisor");
						}
						
	                    if (!atendenteService.validaLoginSupervisor(loginSupervisor)) {
	                    	throw new ValidationException("O Login informado n\u00E3o pertence a um supervisor");
	                    }
		                try {
		                	authenticatorService.authentica(loginSupervisor, senhaSupervisor, AuthenticatorService.AD);
		                } catch (Exception e) {
		                    throw new ValidationException("Erro de Autentica\u00E7\u00E3o do supervisor", e);
		                }
		                
		                listCasoSauAssociar.add(casoSau);
					} else if(casoSau.getTipoAssociacaoCaso() != null && 
							casoSau.getTipoAssociacaoCaso().equals(TipoAssocicaoCasoAtendente.OK_NENHUM_OUTRO_ATENDENTE.getTipoAssocicaoCasoAtendente())) {
						
						listCasoSauAssociar.add(casoSau);
					}
				}
			}
			
			if(listCasoSauAssociar != null && !listCasoSauAssociar.isEmpty()) {
				
				this.associarCasoSauAtendente(listCasoSauAssociar, atendente);
			} else {
				throw new ValidationException("N\u00E3o existem caso selecionados a serem associados");
			}
	    } catch (DataException | ValidationException e) {
	        throw new ServiceException(e.getMessage(), e);
	    }
    }
    
    public void associarCasoSauAtendente(List<CasoSau> listCasoSauAssociar, Atendente atendente) throws ServiceException {
    	try {
    		if(listCasoSauAssociar != null) {
    			
	    		for(CasoSau casoSau : listCasoSauAssociar) {
	    			
		    		if(casoSau == null || casoSau.getCaso() == null) {
		    			throw new Exception("Caso esta nulo");
		    		}
		    		
		    		Caso caso = casoSau.getCaso();
		    		
		    		caso.setAtendente(atendente);
		    		caso.setFlagEmAtendimento(Boolean.TRUE);
		    		casoService.update(caso);
		
		    		
		    		Log log = new Log();
		    		log.setCaso(caso);
		    		log.setDescricao("Caso enviado para o atendente: " + atendente.getLogin());
		    		log.setConfiguracaoFila(caso.getConfiguracaoFila());
		    		logService.saveLogAnexos(log);
	    		}
    		}
    		
    	} catch (Exception e) {
            throw new ServiceException(e.getMessage(), e);
        }
    }

	@Override
	public void validaAtendimentoCasoAtendente(CasoSau casoSau,	Atendente atendente) throws ValidationException, ServiceException {
		CasoSau casoValida = load(casoSau);
		
		if (!casoValida.getCaso().getAtendente().getIdAtendente().equals(atendente.getIdAtendente())) {
			throw new ValidationException("O caso não pertence a este atendente, pois foi removido da lista de casos. Favor recarregar os casos para atendimento");
		}
		
		
	}
	
    @Override
    public Integer buscarQtdCasoAbertoPorCpfCnpj(String cpfCnpj) throws ServiceException {
        try {
            return getDAO().buscarQtdCasoAbertoPorCpfCnpj(cpfCnpj);
        } catch (DataException e) {
            throw new ServiceException("Erro ao buscar CasoSau Por CpfCnpj", e);
        }
    }

	@Override
	protected void validarSave(CasoSau object) throws ValidationException {
		
	}

	@Override
	protected void validarUpdate(CasoSau object) throws ValidationException {
		
	}

	@Override
	protected void validarDelete(CasoSau object) throws ValidationException {
		
	}

	@Override
	public void flush() {
		getDAO().flush();		
	}
	
	
}
