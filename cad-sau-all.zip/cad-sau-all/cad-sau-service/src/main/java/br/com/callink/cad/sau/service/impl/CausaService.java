package br.com.callink.cad.sau.service.impl;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.sau.dao.ICausaDAO;
import br.com.callink.cad.sau.pojo.Causa;
import br.com.callink.cad.sau.service.ICausaService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

@Stateless
public class CausaService extends GenericCadSauService<Causa, ICausaDAO>
		implements ICausaService {
	
	private static final long serialVersionUID = 1L;
	
	@Inject
	private ICausaDAO causaDAO;
	
	@Override
	protected ICausaDAO getDAO() {
		return causaDAO;
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void save(Causa causa) throws ValidationException, ServiceException {
		validarSave(causa);
		causa.setDataCriacao(getDataBanco());
		super.save(causa);
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void update(Causa causa) throws ValidationException, ServiceException {
		validarUpdate(causa);
		super.update(causa);
	}

	private boolean valida(Causa causa) throws ValidationException {

		if (causa == null) {
			throw new ValidationException("A Causa deve ser informada");
		}

		if (StringUtils.isBlank(causa.getNome())) {
			throw new ValidationException("Campo obrigat\u00F3rio : Nome");
		}

		return Boolean.TRUE;
	}

	@Override
	protected void validarSave(Causa object) throws ValidationException {
		valida(object);
	}

	@Override
	protected void validarUpdate(Causa object) throws ValidationException {
		valida(object);
	}

	@Override
	protected void validarDelete(Causa object) throws ValidationException {
		
	}

}
