package br.com.callink.cad.sau.service.impl;

import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.sau.dao.ICheckDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.Check;
import br.com.callink.cad.sau.pojo.Checklist;
import br.com.callink.cad.sau.service.ICheckService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

@Stateless
public class CheckService extends GenericCadSauService<Check, ICheckDAO>
        implements ICheckService {

    private static final long serialVersionUID = -351966589803704407L;
    
    @Inject
    private ICheckDAO checkDAO;
    
    @Override
	protected ICheckDAO getDAO() {
		return checkDAO;
	}

    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void save(List<Check> checks) throws ServiceException {
        try {
            for (Check object : checks) {
            	
            	if(object.getFlagEnabled() == null){
            		object.setFlagEnabled(Boolean.TRUE);
            	}
            	
                if (object.getIdCheck() == null) {
                    getDAO().save(object);
                } else {
                    getDAO().update(object);
                }
            }
        } catch (DataException e) {
            throw new ServiceException(e);
        }
    }
    
    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public List<Check> findAllCheckByChecklist(Checklist checklist) throws ServiceException {
    
    	try{
    		return getDAO().findAllCheckByChecklist(checklist);
    	} catch (DataException e) {
            throw new ServiceException(e);
        }
    }

    private void validarCampos(Check object) throws ValidationException{
    	
    	if(object==null){
    		throw new ValidationException("O Objeto nao pode ser nulo!");
    	}
    	if(object.getChecklist()==null || object.getChecklist().getIdChecklist()==null){
    		throw new ValidationException(" O checklist nao pode ser nulo! ");
    	}
    	if(StringUtils.isBlank(object.getRespostasPossiveis())){
    		throw new ValidationException("As RespostasPossiveis nao pode ser nulo!");
    	}
    	if(object.getFlagEnabled()==null){
    		throw new ValidationException(" O flagEnabled nao pode ser nulo!");
    	}
    	if(object.getOrdem()==null){
    		throw new ValidationException(" A ordem nao pode ser nulo! ");
    	}
    }
    
	@Override
	protected void validarSave(Check object) throws ValidationException {
		validarCampos(object);
	}

	@Override
	protected void validarUpdate(Check object) throws ValidationException {
		validarCampos(object);
	}

	@Override
	protected void validarDelete(Check object) throws ValidationException {
		
	}
	
}
