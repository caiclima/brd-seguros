package br.com.callink.cad.sau.service.impl;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.sau.dao.IChecklistDAO;
import br.com.callink.cad.sau.pojo.AssociaChecklist;
import br.com.callink.cad.sau.pojo.Check;
import br.com.callink.cad.sau.pojo.Checklist;
import br.com.callink.cad.sau.pojo.Evento;
import br.com.callink.cad.sau.service.IAssociaChecklistService;
import br.com.callink.cad.sau.service.ICheckService;
import br.com.callink.cad.sau.service.IChecklistService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

@Stateless
public class ChecklistService extends GenericCadSauService<Checklist, IChecklistDAO> implements
        IChecklistService {
    
	private static final long serialVersionUID = -6282232148186453934L;
	
	@Inject
	private IChecklistDAO checklistDAO;
	
	@EJB
	private ICheckService checkService;
	@EJB
	private IAssociaChecklistService associaChecklistService;
	
	@Override
	protected IChecklistDAO getDAO() {
		return checklistDAO;
	}

	@Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void save(Checklist object) throws ValidationException, ServiceException {
        try {
            validarSave(object);
            getDAO().save(object);
            
            if (object.getChecks() != null) {
	            for (Check check : object.getChecks()) {
	            	check.setChecklist(object);
	            }
            }
            
            checkService.save(object.getChecks());

        } catch (Exception ex) {
            throw new ServiceException(ex);
        }
    }
	
    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void update(Checklist object) throws ValidationException, ServiceException {
        try {
            
            Check checkOriginal = new Check();
            checkOriginal.setChecklist(object);
            
            List<Check> original = checkService.findByExample(checkOriginal);
            for (Check check : original) {
                if (!object.getChecks().contains(check)) {
                	checkService.delete(check);
                }
            }
            super.update(object);
            checkService.save(object.getChecks());
        
        } catch (ServiceException ex) {
            throw new ServiceException(ex);
        }
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void salvaChecklist(Checklist checklist, List<Evento> eventos, Acao acao) throws ValidationException, ServiceException {
    	
    	if(checklist!=null && checklist.getIdChecklist()!= null){
    		this.update(checklist);
    	}else{
    		this.save(checklist);
    	}
    	
    	associaChecklistService.deletaAssociacoes(checklist);
        
        if(eventos!= null && !eventos.isEmpty()){
        	for (Evento evt : eventos) {
                AssociaChecklist associado = new AssociaChecklist();
                associado.setEvento(evt);
                associado.setChecklist(checklist);
                associado.setFlagEnabled(Boolean.TRUE);
                associado.setAcao(acao);
                associaChecklistService.save(associado);
            }
        }else{
        	 AssociaChecklist associado = new AssociaChecklist();
             associado.setChecklist(checklist);
             associado.setFlagEnabled(Boolean.TRUE);
             associado.setAcao(acao);
             associaChecklistService.save(associado);
        }

    }
    
    @Override
    public void validarDelete(Checklist object) throws ValidationException {
    	
    }

    @Override
    public void validarSave(Checklist object) throws ValidationException {
    	if(object == null){
    		throw new ValidationException(" O Objeto nao pode ser nulo");
    	}
    	if(object.getFlagEnabled()== null){
    		throw new ValidationException(" O flagEnabled nao pode ser nulo");
    	}
    }

	@Override
	protected void validarUpdate(Checklist object) throws ValidationException {
		if(object == null){
    		throw new ValidationException(" O Objeto nao pode ser nulo");
    	}
    	if(object.getFlagEnabled()== null){
    		throw new ValidationException(" O flagEnabled nao pode ser nulo");
    	}
	}
    
}
