package br.com.callink.cad.sau.service.impl;

import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.sau.dao.IClassificacaoAutomaticaDAO;
import br.com.callink.cad.sau.pojo.ClassificacaoAutomatica;
import br.com.callink.cad.sau.service.IClassificacaoAutomaticaService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

@Stateless
public class ClassificacaoAutomaticaService
		extends
		GenericCadSauService<ClassificacaoAutomatica, IClassificacaoAutomaticaDAO>
		implements IClassificacaoAutomaticaService {

	private static final long serialVersionUID = 4068375591292165524L;
	private static final String SEPARATOR = ";";
	@Inject
	private IClassificacaoAutomaticaDAO dao;

	@Override
	protected IClassificacaoAutomaticaDAO getDAO() {
		return dao;
	}

	@Override
	protected void validarSave(ClassificacaoAutomatica classificacaoAutomatica)
			throws ValidationException {
		valida(classificacaoAutomatica);
	}

	@Override
	protected void validarUpdate(ClassificacaoAutomatica classificacaoAutomatica)
			throws ValidationException {
		valida(classificacaoAutomatica);
	}

	@Override
	protected void validarDelete(ClassificacaoAutomatica classificacaoAutomatica)
			throws ValidationException {

		if (classificacaoAutomatica == null) {
			throw new ValidationException(
					"A Classificação Automática deve ser preenchida.");
		}
		if (classificacaoAutomatica.getPK() == null) {
			throw new ValidationException("O id deve ser informado.");
		}
	}

	private void valida(ClassificacaoAutomatica classificacaoAutomatica)
			throws ValidationException {

		if (classificacaoAutomatica == null) {
			throw new ValidationException(
					"A Classificação Automática deve ser preenchida.");
		}
		if (StringUtils.isEmpty(classificacaoAutomatica.getAssunto())) {
			throw new ValidationException(
					"O campo Assunto deve ser preenchido.");
		}
		if (classificacaoAutomatica.getEvento() == null
				|| classificacaoAutomatica.getEvento().getIdEvento() == null) {
			throw new ValidationException("O campo Evento deve ser preenchido.");
		}
		if (StringUtils.isEmpty(classificacaoAutomatica.getTextoPadrao())) {
			throw new ValidationException(
					"O campo Texto Padrão deve ser preenchido.");
		}
		if (classificacaoAutomatica.getDataCriacao() == null) {
			throw new ValidationException(
					"O campo Configurado Em deve ser preenchido. Clique em Novo.");
		}
		if (StringUtils.isEmpty(classificacaoAutomatica.getLoginUsuario())) {
			throw new ValidationException(
					"O campo Configurado Por deve ser preenchido. Clique em Novo.");
		}
		
		try {
			List<ClassificacaoAutomatica> classificacoes = findAll();
			
			for (ClassificacaoAutomatica classificacao : classificacoes) {
				if(classificacao.getPK() == classificacaoAutomatica.getPK()){
					continue;
				}
				
				String[] textosExistentes = classificacao.getTextoPadrao().split(SEPARATOR);
				
				for (String textoExistente : textosExistentes) {
					String[] textos = classificacaoAutomatica.getTextoPadrao().split(SEPARATOR);
					
					for (String texto : textos) {
						String textoMin = texto.trim().toLowerCase();
						String textoExistenteMin = textoExistente.trim().toLowerCase();
						
						if(textoMin.contains(textoExistenteMin)){
							throw new ValidationException(getTextoErroValidacao(textoExistente, classificacao)
													+" que está contido ou é igual ao texto que "
													+ "está sendo cadastrado!");
						}
						
						if(textoExistenteMin.contains(textoMin)){
							throw new ValidationException(getTextoErroValidacao(textoExistente, classificacao)
													+" que contém ou é igual ao texto que está sendo "
													+ "cadastrado!");
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new ValidationException(e.getMessage());
		}
	}
	
	private String getTextoErroValidacao(String textoExistente, ClassificacaoAutomatica classificacao){
		return "Já existe o texto padrão ["	+ textoExistente.trim() 
				+ "] do assunto [" + classificacao.getAssunto() 
				+ "] e evento [" + classificacao.getEvento().getNome() + "]";
	}

}
