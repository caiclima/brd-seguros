package br.com.callink.cad.sau.service.impl;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.pojo.GrupoAnexo;
import br.com.callink.cad.sau.dao.IConteudoApoioDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.AssociaConteudoApoio;
import br.com.callink.cad.sau.pojo.ConteudoApoio;
import br.com.callink.cad.sau.pojo.ConteudoApoioCasoSau;
import br.com.callink.cad.sau.service.IAssociaConteudoApoioService;
import br.com.callink.cad.sau.service.ICasoSauService;
import br.com.callink.cad.sau.service.IConteudoApoioService;
import br.com.callink.cad.sau.service.IEventoService;
import br.com.callink.cad.service.IAnexoService;
import br.com.callink.cad.service.IGrupoAnexoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

@Stateless
public class ConteudoApoioService extends GenericCadSauService<ConteudoApoio, IConteudoApoioDAO>
        implements IConteudoApoioService {

    private static final long serialVersionUID = -351966589803704407L;

    @Inject
    private IConteudoApoioDAO conteudoApoioDAO;
    
    @EJB
    private IGrupoAnexoService grupoAnexoService;
    @EJB
    private IAnexoService anexoService;
    @EJB
    private ICasoSauService casoSauService;
    @EJB
    private IAssociaConteudoApoioService associaConteudoApoioService;
    @EJB
    private IEventoService eventoService;
    
    @Override
	protected IConteudoApoioDAO getDAO() {
		return conteudoApoioDAO;
	}
    
    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void save(ConteudoApoio conteudoApoio) throws ValidationException, ServiceException {
        String validaConteudoApoio = validaConteudoApoio(conteudoApoio);
        if (StringUtils.isNotBlank(validaConteudoApoio)) {
            throw new ServiceException(validaConteudoApoio);
        }

        saveGrupoAnexo(conteudoApoio.getGrupoAnexo());
        
        if(conteudoApoio.getGrupoAnexo()!=null && conteudoApoio.getGrupoAnexo().getIdGrupoAnexo()==null){
        	conteudoApoio.setGrupoAnexo(null);
        }
        
        super.save(conteudoApoio);
        saveConteudoApoioCasoSau(conteudoApoio.getConteudoApoioCasoSauList());
        saveAssociacaoEvento(conteudoApoio);
    }
    
    

    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void update(ConteudoApoio conteudoApoio) throws ValidationException, ServiceException {
        String validaConteudoApoio = validaConteudoApoio(conteudoApoio);
        if (StringUtils.isNotBlank(validaConteudoApoio)) {
            throw new ServiceException(validaConteudoApoio);
        }

        saveGrupoAnexo(conteudoApoio.getGrupoAnexo());
        
        if(conteudoApoio.getGrupoAnexo()!=null && conteudoApoio.getGrupoAnexo().getIdGrupoAnexo()==null){
        	conteudoApoio.setGrupoAnexo(null);
        }
        
        saveConteudoApoioCasoSau(conteudoApoio.getConteudoApoioCasoSauList());
        super.update(conteudoApoio);
        saveAssociacaoEvento(conteudoApoio);
    }

    private String validaConteudoApoio(ConteudoApoio conteudoApoio) throws ValidationException, ServiceException {

        StringBuffer erros = new StringBuffer();

        if (conteudoApoio == null) {
            throw new ValidationException("Conteudo de apoio nulo.");
        }
        if (StringUtils.isBlank(conteudoApoio.getNome())) {
            erros.append("Campo Obrigat\u00F3rio : Nome ");
        }
        if (StringUtils.isBlank(conteudoApoio.getDescricao())) {
            erros.append("Campo Obrigat\u00F3rio : Descricao ");
        }

        if (conteudoApoio.getDataCriacao() == null) {
            conteudoApoio.setDataCriacao(getDataBanco());
        }
        return erros.toString();
    }

    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void saveGrupoAnexo(GrupoAnexo grupoAnexo) throws ValidationException, ServiceException {
        if (grupoAnexo != null
                && grupoAnexo.getAnexoList() != null
                && !grupoAnexo.getAnexoList().isEmpty()) {
            grupoAnexoService.save(grupoAnexo);
        }
    }

    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void saveConteudoApoioCasoSau(List<ConteudoApoioCasoSau> conteudoApoioCasoSauList) throws ServiceException {

        if (conteudoApoioCasoSauList != null) {
            try {
                getDAO().associa(conteudoApoioCasoSauList);
            } catch (DataException e) {
                throw new ServiceException("Erro ao associar Conteudo Apoio a Caso", e);
            }
        }
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void saveAssociacao(ConteudoApoioCasoSau conteudoApoioCasoSau) throws ServiceException {
        try {
            getDAO().associa(conteudoApoioCasoSau);
        } catch (DataException e) {
            throw new ServiceException(e);
        }
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void saveAssociacao(List<ConteudoApoioCasoSau> conteudoApoioCasoSauList) throws ServiceException {
        try {
            if (conteudoApoioCasoSauList != null) {

                for (ConteudoApoioCasoSau conteudoApoioCasoSau : conteudoApoioCasoSauList) {
                    getDAO().associa(conteudoApoioCasoSau);
                }
            }

        } catch (DataException e) {
            throw new ServiceException(e);
        }
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void deleteAssociacao(ConteudoApoioCasoSau conteudoApoioCasoSau) throws ServiceException {
        try {
            getDAO().desassocia(conteudoApoioCasoSau);
        } catch (DataException e) {
            throw new ServiceException("Erro ao Remover associação entre ConteudoApoio e Caso", e);
        }
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void deleteAssociacao(List<ConteudoApoioCasoSau> conteudoApoioCasoSauList) throws ServiceException {
        try {
            getDAO().desassocia(conteudoApoioCasoSauList);
        } catch (DataException e) {
            throw new ServiceException("Erro ao Remover associação entre ConteudoApoio e Caso", e);
        }
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public ConteudoApoio load(ConteudoApoio conteudoApoio) throws ServiceException {
        try {
            conteudoApoio = getDAO().findByPk(conteudoApoio);
            if (conteudoApoio.getGrupoAnexo() != null && conteudoApoio.getGrupoAnexo().getPK() != null) {
                conteudoApoio.getGrupoAnexo().setAnexoList(anexoService.buscaPorGrupoAnexo(conteudoApoio.getGrupoAnexo()));
            }
            List<ConteudoApoioCasoSau> conteudoApoioCasoSauList = getDAO().buscaAssociacaoByConteudoApoioOuCasoSau(conteudoApoio, null);
            if (conteudoApoioCasoSauList != null) {
                for (ConteudoApoioCasoSau conteudoApoioCasoSau : conteudoApoioCasoSauList) {
                    conteudoApoioCasoSau.getConteudoApoioCasoSauId().setConteudoApoio(conteudoApoio);
                    conteudoApoioCasoSau.getConteudoApoioCasoSauId().setCasoSau(casoSauService.load(conteudoApoioCasoSau.getConteudoApoioCasoSauId().getCasoSau()));
                }
                conteudoApoio.setConteudoApoioCasoSauList(conteudoApoioCasoSauList);
            }
            AssociaConteudoApoio asscontApoio = new AssociaConteudoApoio();
            asscontApoio.setConteudoApoio(conteudoApoio);
            
            List<AssociaConteudoApoio> associacoes = associaConteudoApoioService.findByExample(asscontApoio);
            if(associacoes != null && !associacoes.isEmpty()){
                conteudoApoio.setAssociaConteudoApoioList(associacoes);
                for (AssociaConteudoApoio associaConteudoApoio : associacoes) {
                    associaConteudoApoio.setEvento(eventoService.findByPk(associaConteudoApoio.getEvento()));
                }
            }
            

            return conteudoApoio;
        } catch (DataException e) {
            throw new ServiceException(e);
        }
    }
    
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    private void saveAssociacaoEvento(ConteudoApoio conteudoApoio) throws ValidationException, ServiceException{
        try {
            AssociaConteudoApoio asscontApoio = new AssociaConteudoApoio();
            asscontApoio.setConteudoApoio(conteudoApoio);
            
            List<AssociaConteudoApoio> associacoes = associaConteudoApoioService.findByExample(asscontApoio);
            for (AssociaConteudoApoio associaConteudoApoio : associacoes) {
                associaConteudoApoioService.delete(associaConteudoApoio);
            }
            for (AssociaConteudoApoio associaConteudoApoio : conteudoApoio.getAssociaConteudoApoioList()) {
                associaConteudoApoioService.save(associaConteudoApoio);
            }
        } catch (ServiceException ex) {
            throw new ServiceException("Erro ao salvar associação de conteúdo de apoio a evento", ex);
        }
        
    }

	@Override
	protected void validarSave(ConteudoApoio object) throws ValidationException {
		
		if(object==null){
			throw new ValidationException("O objeto nao pode ser nulo!");
		}
	}

	@Override
	protected void validarUpdate(ConteudoApoio object)
			throws ValidationException {
		
		if(object==null){
			throw new ValidationException("O objeto nao pode ser nulo!");
		}
	}

	@Override
	protected void validarDelete(ConteudoApoio object)
			throws ValidationException {
		
	}
}
