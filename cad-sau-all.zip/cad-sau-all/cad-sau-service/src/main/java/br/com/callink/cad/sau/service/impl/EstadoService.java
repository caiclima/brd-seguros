package br.com.callink.cad.sau.service.impl;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.sau.dao.IEstadoDAO;
import br.com.callink.cad.sau.pojo.Estado;
import br.com.callink.cad.sau.service.IEstadoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

@Stateless
public class EstadoService extends GenericCadSauService<Estado, IEstadoDAO> implements IEstadoService{

	private static final long serialVersionUID = -5718649287686925034L;
	
	@Inject
	private IEstadoDAO estadoDAO;
	
	@Override
	protected IEstadoDAO getDAO() {
		return estadoDAO;
	}
	
	@Override
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void save(Estado estado) throws ValidationException, ServiceException{
		estado.setDataCriacao(getDataBanco());
		super.save(estado);
	}
	
	@Override
	public void inativa(Estado estado) throws ValidationException, ServiceException{
		if(estado != null && estado.getPK() != null){
			estado.setFlagAtivo(Boolean.FALSE);
			update(estado);
		}
	}

	@Override
	protected void validarSave(Estado object) throws ValidationException {
		if(StringUtils.isBlank(object.getNome())){
			throw new ValidationException("Campos obrigat\u00F3rios!");
		}
	}

	@Override
	protected void validarUpdate(Estado object) throws ValidationException {
		if(StringUtils.isBlank(object.getNome())){
			throw new ValidationException("Campos obrigat\u00F3rios!");
		}
	}

	@Override
	protected void validarDelete(Estado object) throws ValidationException {
		
	}
}
