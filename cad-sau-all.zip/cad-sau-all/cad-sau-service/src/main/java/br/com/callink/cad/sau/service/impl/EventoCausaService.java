package br.com.callink.cad.sau.service.impl;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import br.com.callink.cad.sau.dao.IEventoCausaDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.Causa;
import br.com.callink.cad.sau.pojo.Evento;
import br.com.callink.cad.sau.pojo.EventoCausa;
import br.com.callink.cad.sau.service.ICausaService;
import br.com.callink.cad.sau.service.IEventoCausaService;
import br.com.callink.cad.sau.service.IEventoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 * 
 * @author brunomt [brunoam@swb.com.br]
 *
 */
@Stateless
public class EventoCausaService extends GenericCadSauService<EventoCausa, IEventoCausaDAO> implements IEventoCausaService {

    private static final long serialVersionUID = 1L;

    @Inject
    private IEventoCausaDAO eventoCausaDAO;
    
    @EJB
    private IEventoService eventoService;
    
    @EJB
    private ICausaService causaService;
    
    @Override
	protected IEventoCausaDAO getDAO() {
		return eventoCausaDAO;
	}
    
    @Override
    @TransactionAttribute
    public void save(EventoCausa eventoCausa) throws ServiceException, ValidationException {

        if (eventoCausa == null || eventoCausa.getCausa() == null || eventoCausa.getEvento() == null) {
            throw new ValidationException("A causa e o evento devem ser preenchidos.");
        }
        try {
            if (getDAO().findByEventoCausa(eventoCausa.getEvento(), eventoCausa.getCausa()).isEmpty()) {
                validaEventoCausaFinalizaAutomatico(eventoCausa);
                super.save(eventoCausa);
            } else {
                throw new ValidationException("Associa\u00E7\u00E3o j\u00E1 cadastrada.");
            }
        } catch (DataException ex) {
            throw new ServiceException("Erro ao salvar Evento Causa", ex);
        }
    }
    
    /**
     * Metodo que valida se possui mais de uma causa associada a um evento c/ finalizacao automatica
     * @param object
     * @throws ServiceException 
     */
    private void validaEventoCausaFinalizaAutomatico(EventoCausa object) throws ValidationException, ServiceException {
        if (!object.getFinalizaCaso()) {
            return;
        }
        
        try {
            Causa causaFinalizaAutomatica = getDAO().findCausaFinalizaAutomaticaByEvento(object.getEvento());
            if (causaFinalizaAutomatica != null && causaFinalizaAutomatica.getIdCausa().equals(object.getCausa().getIdCausa())) {
                throw new ValidationException("Não pode haver mais de uma causa que finaliza caso associada a este evento.");
            }
        } catch (DataException e) {
            throw new ServiceException("Erro ao buscar causa que finaliza este caso automaticamente.",e);
        }
    }

    @Override
    public List<EventoCausa> findAllFinalizacaoAutomaticaByEvento(Evento evento) throws ServiceException {
        try {
            return getDAO().findFinalizacaoAutomaticaByEvento(evento);
        } catch (DataException e) {
            throw new ServiceException("Erro ao buscar causas para este evento.", e);
        }
    }
    
    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void update(EventoCausa object) throws ServiceException, ValidationException {
        validaEventoCausaFinalizaAutomatico(object);
        super.update(object);
    }

    @Override
    public List<EventoCausa> findByEventoCausa(Evento evento, Causa causa) throws ServiceException {
        try {
            return getDAO().findByEventoCausa(evento, causa);
        } catch (DataException ex) {
            throw new ServiceException("Erro ao buscar Evento Causa", ex);
        }
    }

    @Override
    public List<EventoCausa> findAll() throws ServiceException {
        return loadEventoCausa(super.findAll());
    }

    private List<EventoCausa> loadEventoCausa(List<EventoCausa> eventoCausaList) throws ServiceException {

        for (int i = 0; i < eventoCausaList.size(); i++) {
            Evento evt = eventoService.load(eventoCausaList.get(i).getEvento());
            Causa csa = causaService.load(eventoCausaList.get(i).getCausa());
            eventoCausaList.get(i).setCausa(csa);
            eventoCausaList.get(i).setEvento(evt);
        }
        
        return eventoCausaList;
    }
    
    @Override
    public Causa findCausaFinalizaAutomaticaByEvento(Evento evento) throws ServiceException, ValidationException {
        try {
            Causa causa = getDAO().findCausaFinalizaAutomaticaByEvento(evento);
            if (causa == null) { 
                throw new ValidationException("Não há causas cadastradas para a finalização automática deste evento. Verificar as configurações do sistema.");
            }
            return causa;
        } catch (DataException ex) {
            throw new ServiceException("Erro ao buscar a causa deste evento para finalização automática. Verificar as configurações do sistema.", ex);
        }
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void saveEventoCausas(Evento evento, List<Causa> causas) throws ServiceException, ValidationException {
        removeEvento(evento);
        
        for (Causa causa : causas) {
            EventoCausa eventoCausa = new EventoCausa();
            eventoCausa.setEvento(evento);
            eventoCausa.setCausa(causa);
            eventoCausa.setFinalizaCaso(causa.isFlagFinalizaAutomatico());
            
            save(eventoCausa);
        }
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void removeEvento(Evento evento) throws ServiceException {
        try {
            getDAO().removeEvento(evento);
        } catch (DataException ex) {
            throw new ServiceException("Erro ao remover os eventos/causa",ex);
        }
    }

    private void validarObjeto(EventoCausa object) throws ValidationException{
    	if(object==null){
			throw new ValidationException(" O eventoCausa nao pode ser nulo!");
		}
		if(object.getCausa()==null || object.getCausa().getIdCausa()==null){
			throw new ValidationException(" A causa nao pode ser nulo!");
		}
		if(object.getEvento()==null || object.getEvento().getIdEvento()==null){
			throw new ValidationException(" O evento nao pode ser nulo!");
		}
    }
    
	@Override
	protected void validarSave(EventoCausa object) throws ValidationException {
		validarObjeto(object);
	}

	@Override
	protected void validarUpdate(EventoCausa object) throws ValidationException {
		validarObjeto(object);
	}

	@Override
	protected void validarDelete(EventoCausa object) throws ValidationException {
		
	}
    
}
