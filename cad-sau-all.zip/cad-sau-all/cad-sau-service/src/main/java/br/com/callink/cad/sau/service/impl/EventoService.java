package br.com.callink.cad.sau.service.impl;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.sau.dao.IEventoDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.Assunto;
import br.com.callink.cad.sau.pojo.Evento;
import br.com.callink.cad.sau.pojo.EventoCausa;
import br.com.callink.cad.sau.service.IEventoCausaService;
import br.com.callink.cad.sau.service.IEventoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 * 
 * @author brunomt [brunoam@swb.com.br]
 *
 */
@Stateless
public class EventoService extends GenericCadSauService<Evento, IEventoDAO> implements IEventoService {

    private static final long serialVersionUID = 1L;
    
    @Inject
    private IEventoDAO eventoDAO;
    
    @EJB
    private  IEventoCausaService eventoCausaService; 
    
    @Override
	protected IEventoDAO getDAO() {
		return eventoDAO;
	}

    private void valida(Evento evento) throws ValidationException {
        if (evento == null) {
            throw new ValidationException("O evento deve ser preenchido.");
        }
        if (StringUtils.isEmpty(evento.getNome())) {
            throw new ValidationException("O nome do evento deve ser preenchido.");
        }
        if (evento.getAssunto() == null || evento.getAssunto().getIdAssunto() == null) {
            throw new ValidationException("O campo assunto deve ser selecionado.");
        }
        if (evento.getFlagFinalizacaoAutomatica() && StringUtils.isBlank(evento.getEmail())) {
            throw new ValidationException("O campo email é obrigatório para finalização automática.");
        }
    }

    @Override
    public List<Evento> findByExample(Evento object) throws ServiceException {
        try {
            return getDAO().findByExample(object);
        } catch (DataException ex) {
            throw new ServiceException("Erro ao buscar Evento", ex);
        }
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void save(Evento evento) throws ServiceException, ValidationException {
        evento.setDataCriacao(getDataBanco());
        super.save(evento);
    }

    private void validaFinalizacaoAutomatica(Evento evento) throws ValidationException, ServiceException {
        List<EventoCausa> eventoCausaList = eventoCausaService.findAllFinalizacaoAutomaticaByEvento(evento);
        if (eventoCausaList != null && eventoCausaList.size() > 1) {
            throw new ValidationException("Este evento deve estar associado somente a UMA causa/erro com finalização automática. Verifique as configuracoes.");
        }
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void update(Evento evento) throws ServiceException, ValidationException {
        if (evento.getFlagFinalizacaoAutomatica()) {
            validaFinalizacaoAutomatica(evento);
        }
        super.update(evento);
    }

    @Override
    public List<Evento> findByAssunto(Assunto assunto) throws ServiceException {
        try {
            return getDAO().findByAssunto(assunto);
        } catch (DataException ex) {
            throw new ServiceException("Erro ao buscar Evento", ex);
        }

    }

    @Override
    public List<Evento> findByAssuntoList(List<Assunto> assuntoList) throws ServiceException {
        try {
            return getDAO().findByAssuntoList(assuntoList);
        } catch (DataException ex) {
            throw new ServiceException("Erro ao buscar Evento", ex);
        }

    }

    @Override
    public List<Evento> findByAssuntoAndEvento(Assunto assunto, Evento evento) throws ServiceException {
        try {
            return getDAO().findByAssuntoAndEvento(assunto, evento);
        } catch (DataException e) {
            throw new ServiceException(e);
        }
    }

	@Override
	protected void validarSave(Evento object) throws ValidationException {
		valida(object);
	}

	@Override
	protected void validarUpdate(Evento object) throws ValidationException {
		valida(object);
	}

	@Override
	protected void validarDelete(Evento object) throws ValidationException {
		
	}
}
