package br.com.callink.cad.sau.service.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.sau.dao.IEvolucaoAtendimentoDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.pojo.EvolucaoAtendimento;
import br.com.callink.cad.sau.pojo.TipoManifestacao;
import br.com.callink.cad.sau.pojo.to.EvolucaoAtendimentoTO;
import br.com.callink.cad.sau.service.ICasoSauService;
import br.com.callink.cad.sau.service.IEvolucaoAtendimentoService;
import br.com.callink.cad.sau.service.ITipoManifestacaoService;
import br.com.callink.cad.service.ICasoService;
import br.com.callink.cad.service.IParametroGBOService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 *
 * @author brunomt
 */
@Stateless
public class EvolucaoAtendimentoService extends GenericCadSauService<EvolucaoAtendimento, IEvolucaoAtendimentoDAO>
        implements IEvolucaoAtendimentoService {

    private static final long serialVersionUID = 1L;
    
    @Inject
    private IEvolucaoAtendimentoDAO evolucaoAtendimentoDAO;
    
    @EJB
    private ICasoSauService casoSauService;
    
    @EJB
    private ICasoService casoService;
    
    @EJB
    private ITipoManifestacaoService tipoManifestacaoService;
    
    @EJB
    private IParametroGBOService parametroGBOService;
    
    @Override
	protected IEvolucaoAtendimentoDAO getDAO() {
		return evolucaoAtendimentoDAO;
	}

    @Override
    public void geraEvolucaoAtendimento() throws ServiceException {
        try {

            List<CasoSau> casosEntrantes = casoSauService.buscaCasoEntranteDia();
            List<CasoSau> casosReabertos = casoSauService.buscaCasoReabertoDia();
            List<CasoSau> casosPendentes = casoSauService.buscaCasoAbertoSemPendencia();
            List<Caso> casoList = new ArrayList<Caso>();
            for (CasoSau casoSau : casosPendentes) {
                casoList.add(casoSau.getCaso());
            }
            casoService.carregaSlas(casoList);

            List<CasoSau> casosFechados = casoSauService.buscaCasosFechadosNoDia();
            
            List<CasoSau> casosFechadosPendente = casoSauService.buscaCasosPendenteChecagem();
            if(casosFechadosPendente != null) {
            	casosFechados.addAll(casosFechadosPendente);
            }
            
            List<TipoManifestacao> tipoManifestacaoList = tipoManifestacaoService.findAtivos(null);

            List<EvolucaoAtendimento> evolucaoAtendimentos = new ArrayList<EvolucaoAtendimento>();
            Calendar calendar = new GregorianCalendar(Calendar.getInstance().get(Calendar.YEAR), Calendar.getInstance().get(
                    Calendar.MONTH), Calendar.getInstance().get(
                    Calendar.DAY_OF_MONTH));

            for (TipoManifestacao tipoManifestacao : tipoManifestacaoList) {
                EvolucaoAtendimento evolucaoAtendimento = new EvolucaoAtendimento();
                evolucaoAtendimento.setTipoManifestacao(tipoManifestacao.getNome());

                List<CasoSau> removeCasosSau = new ArrayList<CasoSau>();
                for (CasoSau casoSau : casosEntrantes) {
                    if (casoSau.getTipoManifestacao().equals(tipoManifestacao)) {
                        evolucaoAtendimento.addTotalEntrantes();
                        removeCasosSau.add(casoSau);
                    }
                }
                casosEntrantes.removeAll(removeCasosSau);
                
                removeCasosSau = new ArrayList<CasoSau>();
                for (CasoSau casoSau : casosReabertos) {
                    if (casoSau.getTipoManifestacao().equals(tipoManifestacao)) {
                        evolucaoAtendimento.addTotalReabertos();
                        removeCasosSau.add(casoSau);
                    }
                }
                casosReabertos.removeAll(removeCasosSau);
                

                removeCasosSau = new ArrayList<CasoSau>();
                for (CasoSau casoSau : casosPendentes) {
                    if (casoSau.getTipoManifestacao().equals(tipoManifestacao)) {
                        if (casoSau.getCaso().getPorcentagemSla() > 100) {
                            evolucaoAtendimento.addPendenteForaPrazo();
                        } else {
                            evolucaoAtendimento.addPendenteDentroPrazo();
                        }
                        removeCasosSau.add(casoSau);
                    }
                }
                casosPendentes.removeAll(removeCasosSau);

                removeCasosSau = new ArrayList<CasoSau>();
                for (CasoSau casoSau : casosFechados) {
                    if (casoSau.getTipoManifestacao().equals(tipoManifestacao)) {
                        if (casoSau.getCaso().getPorcentagemSla() > 100) {
                            evolucaoAtendimento.addFechadoForaPrazo();
                        } else {
                            evolucaoAtendimento.addFechadoDentroPrazo();
                        }
                        removeCasosSau.add(casoSau);
                    }
                }
                casosFechados.removeAll(removeCasosSau);

                evolucaoAtendimento.setDataRelatorio(calendar.getTime());
                evolucaoAtendimento.calculaSaldo();

                evolucaoAtendimentos.add(evolucaoAtendimento);

            }

            removeEvolucaoAtendimento();

            EvolucaoAtendimento evolucaoAtendimentoTotal = new EvolucaoAtendimento();
            evolucaoAtendimentoTotal.setTipoManifestacao("TOTAL");
            for (EvolucaoAtendimento evolAtendimento : evolucaoAtendimentos) {
                evolucaoAtendimentoTotal.preencheEvolucaoAtendimentoTotal(evolAtendimento);
                save(evolAtendimento);
            }

            evolucaoAtendimentoTotal.setDataRelatorio(calendar.getTime());
            save(evolucaoAtendimentoTotal);
        } catch (ValidationException ex) {
            throw new ServiceException("Erro ao gerar a evolução atendimento.",ex);
        }

    }

    @Override
    public void removeEvolucaoAtendimento() throws ServiceException {
        try {
            getDAO().removeEvolucaoAtendimento();
        } catch (DataException ex) {
            throw new ServiceException("Erro ao remover a evolução atendimento.", ex);
        }
    }

    @SuppressWarnings("unchecked")
	@Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public List<EvolucaoAtendimentoTO> recuperaEvolucaoAtendimento(
            List<TipoManifestacao> tipoManifestacaoList, Integer quantidadeDias)
            throws ServiceException {
        Calendar ultimoDia = Calendar.getInstance();
        List<EvolucaoAtendimento> evolucaoAtendimentoList;
        List<EvolucaoAtendimentoTO> evolucaoAtendimentoTOList = new ArrayList<EvolucaoAtendimentoTO>();
        Map<Date, List<EvolucaoAtendimento>> mapEvolucao = new HashMap<Date, List<EvolucaoAtendimento>>();
        Integer contadorDiaUtil = 0;
        Calendar primeiroDia = Calendar.getInstance();

        while (contadorDiaUtil < quantidadeDias) {
            primeiroDia.add(Calendar.DAY_OF_MONTH, -1);
            if (parametroGBOService.contabilizaData(primeiroDia)) {
                contadorDiaUtil++;
            }
        }

        try {
            evolucaoAtendimentoList = getDAO().buscaEvolucaoAtendimento(
                    primeiroDia.getTime(), ultimoDia.getTime());
        } catch (DataException ex) {
            throw new ServiceException(
                    "Erro ao buscar a EvolucaoAtendimento pela data solicitada.",
                    ex);
        }
        if (evolucaoAtendimentoList != null) {

            for (EvolucaoAtendimento evolucaoAtendimento : evolucaoAtendimentoList) {
                List<EvolucaoAtendimento> listaEvolucao = mapEvolucao.get(evolucaoAtendimento.getDataRelatorio());
                if (listaEvolucao != null) {
                    listaEvolucao.add(evolucaoAtendimento);
                } else {
                    List<EvolucaoAtendimento> listaEvolucaoNew = new ArrayList<EvolucaoAtendimento>();
                    listaEvolucaoNew.add(evolucaoAtendimento);
                    mapEvolucao.put(evolucaoAtendimento.getDataRelatorio(),
                            listaEvolucaoNew);
                }
            }
        }

        EvolucaoAtendimentoTO evolucaoAtendimentoTO = null;

        if (mapEvolucao != null) {
            Iterator it = mapEvolucao.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry pairs = (Map.Entry) it.next();
                EvolucaoAtendimento evolucaoAtendimentoOutros = null;
                EvolucaoAtendimento evolucaoAtendimentoTotal = null;

                evolucaoAtendimentoTO = new EvolucaoAtendimentoTO();
                evolucaoAtendimentoTO.setEvolucaoAtendimento(new ArrayList<EvolucaoAtendimento>());
                evolucaoAtendimentoTO.setDataRelatorio((Date) pairs.getKey());
                for (EvolucaoAtendimento evolucaoAtendimentoItem : (List<EvolucaoAtendimento>) pairs.getValue()) {
                    Boolean insereTipo = false;
                    for (TipoManifestacao tipoManifestacao : tipoManifestacaoList) {
                        if (tipoManifestacao.getNome().equals(
                                evolucaoAtendimentoItem.getTipoManifestacao())) {
                            insereTipo = true;
                            break;
                        }
                    }
                    if (insereTipo) {
                        evolucaoAtendimentoTO.getEvolucaoAtendimento().add(
                                evolucaoAtendimentoItem);
                    } else {
                        if (evolucaoAtendimentoItem.getTipoManifestacao().equals("TOTAL")) {
                            evolucaoAtendimentoTotal = evolucaoAtendimentoItem;
                        } else {
                            if (evolucaoAtendimentoOutros == null) {
                                evolucaoAtendimentoOutros = new EvolucaoAtendimento();
                                evolucaoAtendimentoOutros.setTipoManifestacao("OUTROS");
                                evolucaoAtendimentoOutros.preencheEvolucaoAtendimentoTotal(evolucaoAtendimentoItem);
                            } else {
                                evolucaoAtendimentoOutros.preencheEvolucaoAtendimentoTotal(evolucaoAtendimentoItem);
                            }
                        }
                    }
                }
                if (evolucaoAtendimentoOutros != null) {
                    evolucaoAtendimentoTO.getEvolucaoAtendimento().add(
                            evolucaoAtendimentoOutros);
                }

                evolucaoAtendimentoTO.getEvolucaoAtendimento().add(
                        evolucaoAtendimentoTotal);
                evolucaoAtendimentoTOList.add(evolucaoAtendimentoTO);
            }
        }

        // ordenando a lista
        Collections.sort(evolucaoAtendimentoTOList, new Comparator() {

            public int compare(Object o1, Object o2) {
                EvolucaoAtendimentoTO e1 = (EvolucaoAtendimentoTO) o1;
                EvolucaoAtendimentoTO e2 = (EvolucaoAtendimentoTO) o2;
                return e1.getDataRelatorio().compareTo(e2.getDataRelatorio());
            }
        });

        return evolucaoAtendimentoTOList;
    }

	@Override
	protected void validarSave(EvolucaoAtendimento object)
			throws ValidationException {
		
	}

	@Override
	protected void validarUpdate(EvolucaoAtendimento object)
			throws ValidationException {
		
	}

	@Override
	protected void validarDelete(EvolucaoAtendimento object)
			throws ValidationException {
		
	}
}
