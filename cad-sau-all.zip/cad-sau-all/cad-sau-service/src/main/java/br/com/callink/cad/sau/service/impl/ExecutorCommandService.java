package br.com.callink.cad.sau.service.impl;

import javax.ejb.Stateless;

import br.com.callink.cad.engine.command.executor.AbstractGBOExecutorCommandService;
import br.com.callink.cad.engine.command.executor.IExecutorCommandService;

@Stateless
public class ExecutorCommandService extends AbstractGBOExecutorCommandService implements IExecutorCommandService {

	private static final long serialVersionUID = 673452137337806969L;

}
