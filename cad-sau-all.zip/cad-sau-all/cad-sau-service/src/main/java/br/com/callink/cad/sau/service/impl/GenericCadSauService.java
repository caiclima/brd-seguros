package br.com.callink.cad.sau.service.impl;

import java.util.List;

import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import org.apache.log4j.Logger;

import br.com.callink.cad.dao.IGenericCadDAO;
import br.com.callink.cad.pojo.entity.IEntity;
import br.com.callink.cad.sau.dao.IGenericCadSauDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.service.impl.GenericGboService;


@SuppressWarnings("rawtypes")
public abstract class GenericCadSauService<T extends IEntity, DAO extends IGenericCadSauDAO<T>> extends GenericGboService<T , IGenericCadDAO<T>>{

	@Override
	protected abstract DAO getDAO();
	
	protected Logger logger4j = Logger.getLogger(getClass());
	
	/**
     * Validacao executada antes de saltar o objeto do tipo T.
     */
    protected abstract void validarSave(T object) throws ValidationException;

    /**
     * Validacao executada antes de atualizar o objeto do tipo T.
     */
    protected abstract void validarUpdate(T object) throws ValidationException;

    /**
     * Validacao executada antes de excluir o objeto do tipo T.
     */
    protected abstract void validarDelete(T object) throws ValidationException;
    
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<T> findAll(String order) throws ServiceException {
        try {
            return getDAO().findAll(order);
        } catch (DataException e) {
        	logger4j.error("Nao foi possivel buscar todos os registros", e);
            throw new ServiceException(e);
        }
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void save(T object) throws ServiceException, ValidationException {
        validarSave(object);
		super.save(object);
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void saveOrUpdate(T object) throws ServiceException, ValidationException {

        if (object.getPK() == null) {
            this.save(object);
        } else {
            this.update(object);
        }
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void update(T object) throws ServiceException, ValidationException {
        validarUpdate(object);
		super.update(object);
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void delete(T object) throws ServiceException, ValidationException {
        validarDelete(object);
		super.delete(object);
    }
    
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<T> findByExample(T object, String order) throws ServiceException {
        try {
            return getDAO().findByExample(object, order);
        } catch (DataException e) {
        	logger4j.error("Nao foi possivel buscar os registros por exemplos", e);
            throw new ServiceException(e);
        }
    }    
    
    @Override
    public List<T> findAtivos() throws ServiceException{
    	try {
                return getDAO().findAtivos();
        } catch (DataException e) {
                throw new ServiceException("Erro ao buscar registros ativos.", e);
        }
    }
    
	public final Logger getLogger4j() {
		return logger4j;
	}

	public final void setLogger4j(Logger logger4j) {
		this.logger4j = logger4j;
	}


}
