package br.com.callink.cad.sau.service.impl;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.sau.dao.IJuncaoDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.Juncao;
import br.com.callink.cad.sau.service.IJuncaoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

@Stateless
public class JuncaoService extends GenericCadSauService<Juncao, IJuncaoDAO> implements IJuncaoService {
	
	private static final long serialVersionUID = 1L;

	@Inject
	private IJuncaoDAO juncaoDAO;
	
	@Override
	protected IJuncaoDAO getDAO() {
		return juncaoDAO;
	}
	
	@Override
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void save(Juncao juncao) throws ServiceException, ValidationException {
		juncao.setDataCriacao(getDataBanco());
		super.save(juncao);
	}
	
	@Override
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void update(Juncao juncao) throws ServiceException, ValidationException {
		juncao.setDataCriacao(getDataBanco());
		super.update(juncao);
	}
	
	@Override
	public void inativar(Juncao juncao) throws ServiceException {
		juncao.setFlagAtivo(Boolean.FALSE);
		try {
			getDAO().update(juncao);
		} catch (DataException e) {
			throw new ServiceException("N\u00E3o foi poss\u00EDvel alterar a junção.",e);
		}
	}

	private void validaCampos(Juncao juncao) throws ValidationException {
		if (juncao == null) {
			throw new ValidationException("A jun\u00E7\u00E3o n\u00E3o pode ser nula.");
		}
		if (StringUtils.isEmpty(juncao.getNome())) {
			throw new ValidationException("Favor informar o nome.");
		}
	}
	
	
	@Override
	protected void validarSave(Juncao juncao) throws ValidationException {
		validaCampos(juncao);
	}

	@Override
	protected void validarUpdate(Juncao juncao) throws ValidationException {
		validaCampos(juncao);
	}

	@Override
	protected void validarDelete(Juncao object) throws ValidationException {
	}
}
