/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.sau.service.impl;

import javax.ejb.Stateless;
import javax.inject.Inject;

import br.com.callink.cad.sau.dao.IOutraAreaDAO;
import br.com.callink.cad.sau.pojo.OutraArea;
import br.com.callink.cad.sau.service.IOutraAreaService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 *
 * @author ubuntu
 */
@Stateless
public class OutraAreaService extends GenericCadSauService<OutraArea, IOutraAreaDAO> implements IOutraAreaService {

	private static final long serialVersionUID = -82194003111258388L;
	
	@Inject
    private IOutraAreaDAO outraAreaDAO;
	
	@Override
	protected IOutraAreaDAO getDAO() {
		return outraAreaDAO;
	}
	
	@Override
    public void saveOrUpdate(OutraArea object) throws ServiceException, ValidationException {
        object.setDataCriacao(getDataBanco());
        super.saveOrUpdate(object);
    }

	@Override
	protected void validarSave(OutraArea object) throws ValidationException {
		
	}

	@Override
	protected void validarUpdate(OutraArea object) throws ValidationException {
		
	}

	@Override
	protected void validarDelete(OutraArea object) throws ValidationException {
		
	}
    
}
