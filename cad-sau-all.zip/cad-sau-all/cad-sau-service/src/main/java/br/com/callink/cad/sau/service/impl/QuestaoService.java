package br.com.callink.cad.sau.service.impl;

import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import br.com.callink.cad.sau.dao.IQuestaoDAO;
import br.com.callink.cad.sau.enun.OperadorApresentacao;
import br.com.callink.cad.sau.enun.TipoConteudoResposta;
import br.com.callink.cad.sau.enun.TipoResposta;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.Questao;
import br.com.callink.cad.sau.pojo.Questionario;
import br.com.callink.cad.sau.service.IQuestaoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

@Stateless
public class QuestaoService extends GenericCadSauService<Questao, IQuestaoDAO>
        implements IQuestaoService {

    private static final long serialVersionUID = -351966589803704407L;

    @Inject
    private IQuestaoDAO questaoDAO;
    
    @Override
	protected IQuestaoDAO getDAO() {
		return questaoDAO;
	}
    
    @Override
    public List<Questao> findAllQuestaoByQuestionario(Questionario questionario) throws ServiceException {
        try {
            return populaTransientQuestao(getDAO().findAllQuestaoByQuestionario(questionario));
        } catch (DataException e) {
            throw new ServiceException(e);
        }
    }

    private List<Questao> populaTransientQuestao(List<Questao> questoes) {
        for (Questao qest : questoes) {
            if (qest.getOperadorApresentacao() != null) {
                qest.setOperadorAprsentacao(OperadorApresentacao.valueOf(qest.getOperadorApresentacao()));
            }
            if (qest.getTipoConteudo() != null) {
                qest.setTipoConteudoResposta(TipoConteudoResposta.valueOf(qest.getTipoConteudo()));
            }
            if (qest.getTipoResposta() != null) {
                qest.setTipoRespsta(TipoResposta.valueOf(qest.getTipoResposta()));
            }
        }
        return questoes;
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void save(List<Questao> questoes) throws ServiceException {
        try {
            for (Questao object : questoes) {
                if (object.getIdQuestao() == null) {
                    getDAO().save(object);
                } else {
                    getDAO().update(object);
                }
            }
        } catch (DataException e) {
            throw new ServiceException(e);
        }
    }

    private void validarCampos(Questao object) throws ValidationException {
    	
    	if(object==null){
    		throw new ValidationException("O objeto nao pode ser nulo!");
    	}
    	if(object.getQuestionario() == null || object.getQuestionario().getIdQuestionario()==null){
    		throw new ValidationException("O questionario nao pode ser nulo!");
    	}
    }
    
	@Override
	protected void validarSave(Questao object) throws ValidationException {
		validarCampos(object);
	}

	@Override
	protected void validarUpdate(Questao object) throws ValidationException {
		validarCampos(object);
	}

	@Override
	protected void validarDelete(Questao object) throws ValidationException {
	}
	
}
