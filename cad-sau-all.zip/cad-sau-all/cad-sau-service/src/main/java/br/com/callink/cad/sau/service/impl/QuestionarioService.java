package br.com.callink.cad.sau.service.impl;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.sau.dao.IQuestionarioDAO;
import br.com.callink.cad.sau.enun.OperadorApresentacao;
import br.com.callink.cad.sau.enun.TipoConteudoResposta;
import br.com.callink.cad.sau.enun.TipoResposta;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.AssociaQuestionario;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.pojo.Evento;
import br.com.callink.cad.sau.pojo.Questao;
import br.com.callink.cad.sau.pojo.Questionario;
import br.com.callink.cad.sau.service.IAssociaQuestionarioService;
import br.com.callink.cad.sau.service.IQuestaoService;
import br.com.callink.cad.sau.service.IQuestionarioService;
import br.com.callink.cad.sau.service.IRespostaService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

@Stateless
public class QuestionarioService extends GenericCadSauService<Questionario, IQuestionarioDAO> implements
        IQuestionarioService {

    private static final long serialVersionUID = -6924295868902179961L;

    @Inject
    private IQuestionarioDAO questionarioDAO;
    
    @EJB
    private IQuestaoService questaoService;
    
    @EJB
    private IRespostaService respostaService;
    
    @EJB
    private IAssociaQuestionarioService associaQuestionarioService;
    
    @Override
	protected IQuestionarioDAO getDAO() {
		return questionarioDAO;
	}
    
    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void save(Questionario object) throws ServiceException, ValidationException {
        try {

            validarSave(object);
            getDAO().save(object);
            
            if (object.getQuestaoList() != null) {
	            for (Questao questao : object.getQuestaoList()) {
	            	questao.setQuestionario(object);
	            }
            }
            
            questaoService.save(object.getQuestaoList());

        } catch (DataException ex) {
            throw new ServiceException(ex);
        }
    }

    @Override
    public void update(Questionario object) throws ServiceException, ValidationException {
        try {

            getDAO().update(object);
            List<Questao> original = questaoService.findAllQuestaoByQuestionario(object);
            for (Questao qest : original) {
                if (!object.getQuestaoList().contains(qest)) {
                    questaoService.delete(qest);
                }
            }
            questaoService.save(object.getQuestaoList());

        } catch (DataException ex) {
            throw new ServiceException(ex);
        }
    }

    @Override
    public Questionario editQuestionario(Questionario questionario) throws ServiceException {
        try {
            Questionario ret = getDAO().findByPk(questionario);
            ret.setQuestaoList(questaoService.findAllQuestaoByQuestionario(ret));
            for (Questao qest : ret.getQuestaoList()) {
                if (qest.getOperadorApresentacao() != null) {
                    qest.setOperadorAprsentacao(OperadorApresentacao.valueOf(qest.getOperadorApresentacao()));
                }
                if (qest.getTipoConteudo() != null) {
                    qest.setTipoConteudoResposta(TipoConteudoResposta.valueOf(qest.getTipoConteudo()));
                }
                if (qest.getTipoResposta() != null) {
                    qest.setTipoRespsta(TipoResposta.valueOf(qest.getTipoResposta()));
                }
                qest.setIsEditavel(respostaService.questaoEditavel(qest));
                
                if ((qest.getTipoResposta().equals(TipoResposta.MULTIPLA_ESCOLHA.toString()) || qest.getTipoResposta().equals(TipoResposta.UNICA_ESCOLHA.toString()))
                		&& !qest.getIsEditavel()) {
                	qest.setInserirResposta(Boolean.TRUE);
                }
                
                qest.setRendered(Boolean.TRUE);
            }
            return ret;
        } catch (DataException ex) {
            throw new ServiceException(ex);
        }
    }

    @Override
    public void validarDelete(Questionario object) throws ValidationException {
    }

    @Override
    public void validarSave(Questionario object) throws ValidationException {

        // Validar dados
        if (object.getFlagAtivo() == null) {
            throw new ValidationException("Campo Obrigat\u00F3rio : Ativo ");
        }
        if (StringUtils.isEmpty(object.getDescricao())) {
            throw new ValidationException("Campo Nome \u00E9 Obrigat\u00F3rio ");
        }
        if (object.getQuestaoList().isEmpty()) {
            throw new ValidationException("Questionario informado nao possui questao");
        }

    }

    /**
     * se não houver questionario para o caso, retorna um objeto questionario vazio
     * @param casoSau
     * @return
     * @throws ServiceException 
     */
    @Override
    public Questionario findByCasoSau(CasoSau casoSau) throws ServiceException {
        try {
            AssociaQuestionario associaQuestionario = new AssociaQuestionario();

            associaQuestionario.setEvento(casoSau.getEvento());

            List<AssociaQuestionario> result = associaQuestionarioService.findByExample(associaQuestionario);
            if (result.isEmpty()) {
                return new Questionario();
            }
            associaQuestionario = result.get(0);
            Questionario pojo = new Questionario();
            pojo.setIdQuestionario(associaQuestionario.getQuestionario().getIdQuestionario());
            pojo = getDAO().findByPk(pojo);
            pojo.setQuestaoList(questaoService.findAllQuestaoByQuestionario(pojo));
            for (Questao qest : pojo.getQuestaoList()) {
                if (qest.getOperadorApresentacao() != null) {
                    qest.setOperadorAprsentacao(OperadorApresentacao.valueOf(qest.getOperadorApresentacao()));
                }
                if (qest.getTipoConteudo() != null) {
                    qest.setTipoConteudoResposta(TipoConteudoResposta.valueOf(qest.getTipoConteudo()));
                }
                if (qest.getTipoResposta() != null) {
                    qest.setTipoRespsta(TipoResposta.valueOf(qest.getTipoResposta()));
                }
            }
            return pojo;
        } catch (DataException ex) {
            throw new ServiceException("Erro ao buscar questionario para este caso.", ex);
        }
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void salvaQuestionario(Questionario questionario, List<Evento> associa) throws ServiceException, ValidationException {
        this.saveOrUpdate(questionario);

        validaEventos(questionario, associa);
        associaQuestionarioService.deletaAssociacoes(questionario);
        for (Evento evt : associa) {
            AssociaQuestionario associado = new AssociaQuestionario();
            associado.setEvento(evt);
            associado.setQuestionario(questionario);
            associado.setFlagCheckList(Boolean.TRUE);
            associaQuestionarioService.save(associado);
        }

    }

    private void validaEventos(Questionario questionario, List<Evento> eventos) throws ServiceException {

        if (eventos != null && eventos.size() > 0) {

            List<AssociaQuestionario> result = associaQuestionarioService.buscaAssociacaoByListEvento(eventos);

            boolean invalido = false;

            StringBuilder sbr = new StringBuilder("J\u00E1 existem question\u00E1rios cadastrados para os eventos:;");

            for (AssociaQuestionario associacoes : result) {
                if (!associacoes.getQuestionario().equals(questionario)) {
                    invalido = true;
                    sbr.append(" Evento: ").append(associacoes.getEvento()).append(",");
                    sbr.append(" Question\u00E1rio: ");
                    sbr.append(associacoes.getQuestionario());
                    sbr.append(";");
                }
            }

            if (invalido) {
                throw new ServiceException(sbr.toString());
            }
        }
    }


	@Override
	protected void validarUpdate(Questionario object)
			throws ValidationException {
	}

}
