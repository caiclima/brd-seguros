package br.com.callink.cad.sau.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.sau.dao.IRespostaChecklistDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.Check;
import br.com.callink.cad.sau.pojo.RespostaChecklist;
import br.com.callink.cad.sau.pojo.ResultadoChecklist;
import br.com.callink.cad.sau.service.ICheckService;
import br.com.callink.cad.sau.service.IRespostaChecklistService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

@Stateless
public class RespostaChecklistService extends GenericCadSauService<RespostaChecklist, IRespostaChecklistDAO> implements IRespostaChecklistService {

	private static final long serialVersionUID = -2595564809384568649L;

	@Inject
	private IRespostaChecklistDAO respostaChecklistDAO;

	@EJB
	private ICheckService checkService;
	
	@Override
	protected IRespostaChecklistDAO getDAO() {
		return respostaChecklistDAO;
	}
	
	@Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void save(List<RespostaChecklist> respostas) throws ServiceException {
        try {
            validaRespostas(respostas);
            for (RespostaChecklist resp : respostas) {
                if (resp.getIdRespostaChecklist() != null) {
                	getDAO().update(resp);
                } else {
                	getDAO().save(resp);
                }
            }
        } catch (DataException ex) {
            throw new ServiceException(ex);
        }
    }

    private void validaRespostas(List<RespostaChecklist> respostas) throws ServiceException {
        StringBuilder sbr = new StringBuilder();

        for (RespostaChecklist resp : respostas) {

            if (resp.getRespostas() != null && resp.getRespostas().size() > 0) {
                String resposta = resp.getRespostas().toString();
                resp.setResposta(resposta.replace("[", "").replace("]", "").replace(", ", ";"));
            }
        }
        if (StringUtils.isNotEmpty(sbr.toString())) {
            throw new ServiceException(sbr.toString());
        }
    }

    @Override
    public List<RespostaChecklist> respostasByResultadoChecklist(ResultadoChecklist resultadoChecklist) throws ServiceException {
        try {

            List<RespostaChecklist> ret = getDAO().respostasByResultadoChecklist(resultadoChecklist);
            for (RespostaChecklist resp : ret) {
                resp.setRespostas(Arrays.asList(resp.getResposta().split(";")));
            }
            return ret;
        } catch (DataException ex) {
            throw new ServiceException("Falha ao recuperar respostas.", ex);
        }
    }
    
    @Override
    public List<RespostaChecklist> validaFilhos(List<RespostaChecklist> list){
       
    	try {	
	    	List<RespostaChecklist> listResult = new ArrayList<RespostaChecklist>();
	        
	        for (RespostaChecklist resposta : list) {
	        		
	        		Check pai = new Check();
	        		
	        		if(resposta.getCheck() != null && resposta.getCheck().getCheckPai() != null && 
	        				resposta.getCheck().getCheckPai().getIdCheck()!= 0){
	        			pai = checkService.load(resposta.getCheck().getCheckPai());
	        		}
	            
	            if (resposta.getIdRespostaChecklist() != null && (pai == null || pai.getIdCheck() == null)) {
	                listResult.add(resposta);
	                listResult.addAll(orderResp(list, resposta));
	            }
	        }
	        return listResult;
        
    	} catch (ServiceException e) {
			logger4j.error(e.getMessage(), e);
		}
    	return null;
    }

    private List<RespostaChecklist> orderResp(List<RespostaChecklist> list, RespostaChecklist resp) {
        List<RespostaChecklist> listReturn = new ArrayList<RespostaChecklist>();
        for (RespostaChecklist res : list) {
            if (res.getRespostas() != null && res.getRespostas().size() > 0) {
                String resposta = res.getRespostas().toString();
                res.setResposta(resposta.replace("[", "").replace("]", "").replace(", ", ";"));
            }
            if (resp.getCheck().equals(res.getCheck().getCheckPai())) {

                res.getCheck().setRendered(render(res, resp.getResposta()));
                listReturn.add(res);
                listReturn.addAll(orderResp(list, res));
            }
        }
        return listReturn;
    }

    public Boolean render(RespostaChecklist filho, String respostaPai) {
        try {
            if (filho == null) {
                return Boolean.FALSE;
            } else if (filho.getCheck() == null || filho.getCheck().getIdCheck() == null) {
                return Boolean.FALSE;
            } else if (StringUtils.isEmpty(respostaPai)) {
                return Boolean.FALSE;
            } else {
                if(filho.getCheck().getOperadorApresentacao().equals("IGUAL")) {
                   return respostaPai.equals(filho.getCheck().getRespostaApresentacao());
                }else{
                   return !respostaPai.equals(filho.getCheck().getRespostaApresentacao());
                }
            }
        } catch (Exception ex) {
            return Boolean.FALSE;
        }
    }

    private void validarCampos(RespostaChecklist object) throws ValidationException {
    	
    	if(object==null){
    		throw new ValidationException(" O objeto nao pode ser nulo!");
    	}
    	if(object.getCheck()==null || object.getCheck().getIdCheck() ==null){
    		throw new ValidationException("O check nao pode ser nulo! ");
    	}
    	if(object.getResultadoChecklist()==null || object.getResultadoChecklist().getIdResultadoChecklist() ==null){
    		throw new ValidationException("O check nao pode ser nulo! ");
    	}
    }
    
	@Override
	protected void validarSave(RespostaChecklist object)
			throws ValidationException {
		validarCampos(object);
	}

	@Override
	protected void validarUpdate(RespostaChecklist object)
			throws ValidationException {
		validarCampos(object);
	}

	@Override
	protected void validarDelete(RespostaChecklist object)
			throws ValidationException {
		
	}

}
