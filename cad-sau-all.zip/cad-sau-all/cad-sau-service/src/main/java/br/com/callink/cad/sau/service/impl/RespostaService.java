package br.com.callink.cad.sau.service.impl;

import java.text.DateFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.sau.dao.IRespostaDAO;
import br.com.callink.cad.sau.enun.OperadorApresentacao;
import br.com.callink.cad.sau.enun.TipoConteudoResposta;
import br.com.callink.cad.sau.enun.TipoResposta;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.Questao;
import br.com.callink.cad.sau.pojo.Resposta;
import br.com.callink.cad.sau.pojo.ResultadoQuestionario;
import br.com.callink.cad.sau.service.IRespostaService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

@Stateless
public class RespostaService extends GenericCadSauService<Resposta, IRespostaDAO> implements IRespostaService {

    private static final long serialVersionUID = 2757449036460436884L;

    @Inject
    private IRespostaDAO respostaDAO;
    
    @Override
	protected IRespostaDAO getDAO() {
		return respostaDAO;
	}
    
    @Override
    public boolean questaoEditavel(Questao questao) throws ServiceException {
        try {
            return getDAO().questaoEditavel(questao);
        } catch (DataException ex) {
            throw new ServiceException(ex);
        }

    }

    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void save(List<Resposta> respostas) throws ServiceException {
        try {
            validaRespostas(respostas);
            for (Resposta resp : respostas) {
                if (resp.getIdResposta() != null) {
                	getDAO().update(resp);
                } else {
                	getDAO().save(resp);
                }
            }
        } catch (DataException ex) {
            throw new ServiceException(ex);
        }
    }

    private void validaRespostas(List<Resposta> respostas) throws ServiceException {
        StringBuilder sbr = new StringBuilder();

        for (Resposta resp : respostas) {

            if (resp.getRespostas() != null && resp.getRespostas().size() > 0) {
                String resposta = resp.getRespostas().toString();
                resp.setResposta(resposta.replace("[", "").replace("]", "").replace(", ", ";"));
            }
            if (resp.getQuestao().getTipoConteudoResposta() == TipoConteudoResposta.DATA) {
                DateFormat df = DateFormat.getDateInstance();
                resp.setResposta(df.format(resp.getDataResposta()));
            }
            Questao qestao = resp.getQuestao();
            if (qestao.getRequerida() && StringUtils.isEmpty(resp.getResposta()) && qestao.getRendered()) {
                sbr.append(qestao.getMensagemRequerida());
                sbr.append(";");
            }
        }
        if (StringUtils.isNotEmpty(sbr.toString())) {
            throw new ServiceException(sbr.toString());
        }
    }

    @Override
    public List<Resposta> respostasByResultadoQuestionario(ResultadoQuestionario resultadoQuestionario) throws ServiceException {
        try {

            List<Resposta> ret = getDAO().respostasByResultadoQuestionario(resultadoQuestionario);
            for (Resposta resp : ret) {
                Questao qest = resp.getQuestao();
                if (qest.getOperadorApresentacao() != null) {
                    qest.setOperadorAprsentacao(OperadorApresentacao.valueOf(qest.getOperadorApresentacao()));
                }
                if (qest.getTipoConteudo() != null) {
                    qest.setTipoConteudoResposta(TipoConteudoResposta.valueOf(qest.getTipoConteudo()));
                }
                if (qest.getTipoResposta() != null) {
                    qest.setTipoRespsta(TipoResposta.valueOf(qest.getTipoResposta()));
                }
                if (qest.getTipoRespsta().equals(TipoResposta.MULTIPLA_ESCOLHA)) {
                    resp.setRespostas(Arrays.asList(resp.getResposta().split(";")));
                }
                if (qest.getTipoConteudoResposta() == TipoConteudoResposta.DATA) {
                    DateFormat df = DateFormat.getDateInstance();

                    resp.setDataResposta(df.parse(resp.getResposta()));
                }
            }
            return ret;
        } catch (ParseException ex) {
            throw new ServiceException("Falha ao recuperar respostas.", ex);
        } catch (DataException ex) {
            throw new ServiceException("Falha ao recuperar respostas.", ex);
        }
    }

    @Override
    public List<Resposta> validaFilhos(List<Resposta> respostas) {
        return ordenarResposta(respostas);
    }

    private List<Resposta> ordenarResposta(List<Resposta> list) {
        List<Resposta> listResult = new ArrayList<Resposta>();

        for (Resposta resposta : list) {
            Questao pai = resposta.getQuestao().getQuestaoPai();
            if (resposta.getIdResposta() != null && (pai == null || pai.getIdQuestao() == null)) {
                listResult.add(resposta);
                listResult.addAll(orderResp(list, resposta));
            }
        }
        return listResult;
    }

    private List<Resposta> orderResp(List<Resposta> list, Resposta resp) {
        List<Resposta> listReturn = new ArrayList<Resposta>();
        for (Resposta res : list) {
            if (res.getRespostas() != null && res.getRespostas().size() > 0) {
                String resposta = res.getRespostas().toString();
                res.setResposta(resposta.replace("[", "").replace("]", "").replace(", ", ";"));
            }
            if (res.getQuestao().getTipoConteudoResposta() == TipoConteudoResposta.DATA && res.getDataResposta() != null) {
                DateFormat df = DateFormat.getDateInstance();
                res.setResposta(df.format(res.getDataResposta()));
            }
            if (resp.getQuestao().equals(res.getQuestao().getQuestaoPai())) {

                res.getQuestao().setRendered(render(res, resp.getResposta()));
                listReturn.add(res);
                listReturn.addAll(orderResp(list, res));
            }
        }
        return listReturn;
    }

    public Boolean render(Resposta filho, String respostaPai) {
        try {
            if (filho == null) {
                return Boolean.FALSE;
            } else if (filho.getQuestao() == null || filho.getQuestao().getIdQuestao() == null) {
                return Boolean.FALSE;
            } else if (StringUtils.isEmpty(respostaPai)) {
                return Boolean.FALSE;
            } else {
                switch (filho.getQuestao().getOperadorAprsentacao()) {
                    case IGUAL:
                        return respostaPai.equals(filho.getQuestao().getRespostaApresentacao());
                    case CONTEM:
                        return respostaPai.contains(filho.getQuestao().getRespostaApresentacao());
                    case NAO_CONTEM:
                        return !respostaPai.contains(filho.getQuestao().getRespostaApresentacao());
                    case DIFERENTE:
                        return !respostaPai.equals(filho.getQuestao().getRespostaApresentacao());
                    default:
                        return operacao(filho, respostaPai);
                }
            }
        } catch (ParseException ex) {
            return Boolean.FALSE;
        }
    }

    private boolean operacao(Resposta filho, String respostaPai) throws ParseException {
        double respos;
        double quest;
        switch (filho.getQuestao().getTipoConteudoResposta()) {
            case DATA:
                DateFormat df = DateFormat.getDateInstance();
                respos = df.parse(respostaPai).getTime();
                quest = df.parse(filho.getQuestao().getRespostaApresentacao()).getTime();
                return calculosOperacao(respos, quest, filho.getQuestao().getOperadorAprsentacao());
            case INTEIRO:
                respos = Double.valueOf(respostaPai);
                quest = new Double(filho.getQuestao().getRespostaApresentacao());
                return calculosOperacao(respos, quest, filho.getQuestao().getOperadorAprsentacao());
            case DECIMAL:
            	respos = Double.valueOf(respostaPai);
                quest = Double.valueOf(filho.getQuestao().getRespostaApresentacao());
                return calculosOperacao(respos, quest, filho.getQuestao().getOperadorAprsentacao());
        }
        return false;
    }

    private boolean calculosOperacao(double resposta, double questao, OperadorApresentacao operacao) {
        if (resposta == questao && operacao == OperadorApresentacao.IGUAL) {
            return true;
        }
        if (resposta < questao && operacao == OperadorApresentacao.MENOR_QUE) {
            return true;
        }
        if (resposta > questao && operacao == OperadorApresentacao.MAIOR_QUE) {
            return true;
        }
        if (resposta >= questao && operacao == OperadorApresentacao.MAIOR_IGUAL) {
            return true;
        }
        if (resposta <= questao && operacao == OperadorApresentacao.MENOR_IGUAL) {
            return true;
        }
        return false;
    }

    protected void validarCampos(Resposta object) throws ValidationException {
    	
    	if(object == null){
    		throw new ValidationException(" O objeto nao pode ser nulo!");
    	}
    	if(object.getQuestao() == null || object.getQuestao().getIdQuestao() == null){
    		throw new ValidationException(" A questao nao pode ser nulo! ");
    	}
    	
    	if(object.getResultadoQuestionario() == null || object.getResultadoQuestionario().getIdResultadoQuestionario()== null){
    		throw new ValidationException(" O resultadoQuestionario nao pode ser nulo!");
    	}
    	
	}
    
	@Override
	protected void validarSave(Resposta object) throws ValidationException {
	}

	@Override
	protected void validarUpdate(Resposta object) throws ValidationException {
		
	}

	@Override
	protected void validarDelete(Resposta object) throws ValidationException {
		
	}
}
