package br.com.callink.cad.sau.service.impl;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.sau.dao.IResultadoChecklistDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.pojo.Evento;
import br.com.callink.cad.sau.pojo.RespostaChecklist;
import br.com.callink.cad.sau.pojo.ResultadoChecklist;
import br.com.callink.cad.sau.service.IRespostaChecklistService;
import br.com.callink.cad.sau.service.IResultadoChecklistService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

@Stateless
public class ResultadoChecklistService extends GenericCadSauService<ResultadoChecklist, IResultadoChecklistDAO>
        implements IResultadoChecklistService {

	private static final long serialVersionUID = 8189461437807760958L;
	
	@Inject
	private IResultadoChecklistDAO resultadoChecklistDAO;
	
	@EJB
	private IRespostaChecklistService respostaService;
	
	@Override
	protected IResultadoChecklistDAO getDAO() {
		return resultadoChecklistDAO;
	}

	@Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void save(ResultadoChecklist object) throws ServiceException, ValidationException {

        if (object != null) {
            object.setDataResposta(getDataBanco());
            super.save(object);

            for (RespostaChecklist resposta : object.getRespostaList()) {
                resposta.setResultadoChecklist(object);
            }

            respostaService.save(object.getRespostaList());
        }
    }
    
	@Override
    public List<ResultadoChecklist> buscaResultadoPorAgenteCasoSau(
			CasoSau casoSau, Evento evento , Acao acao) throws ServiceException {
    	
    	try {
    		if(casoSau ==null || acao ==null ){
    			return null;
    		}
			return getDAO().buscaResultadoPorAgenteCasoSau(casoSau, evento, acao);
		} catch (DataException e) {
			throw new ServiceException(e);
		}
    }

	@Override
	protected void validarSave(ResultadoChecklist object)
			throws ValidationException {
		if (object.getIdExterno() == null) {
            throw new ValidationException("Campo id externo deve ser preenchido");
        }
	}

	@Override
	protected void validarUpdate(ResultadoChecklist object)
			throws ValidationException {
		if (object.getIdExterno() == null) {
            throw new ValidationException("Campo id externo deve ser preenchido");
        }
	}

	@Override
	protected void validarDelete(ResultadoChecklist object)
			throws ValidationException {
	}

}
