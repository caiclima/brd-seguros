package br.com.callink.cad.sau.service.impl;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import br.com.callink.cad.sau.dao.IResultadoQuestionarioDAO;
import br.com.callink.cad.sau.exception.DataException;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.pojo.Questionario;
import br.com.callink.cad.sau.pojo.Resposta;
import br.com.callink.cad.sau.pojo.ResultadoQuestionario;
import br.com.callink.cad.sau.service.IQuestionarioService;
import br.com.callink.cad.sau.service.IRespostaService;
import br.com.callink.cad.sau.service.IResultadoQuestionarioService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

@Stateless
public class ResultadoQuestionarioService extends GenericCadSauService<ResultadoQuestionario, IResultadoQuestionarioDAO>
        implements IResultadoQuestionarioService {

	@Inject
	private IResultadoQuestionarioDAO resultadoQuestionarioDAO;
	
	@EJB
	private IRespostaService respostaService;
	
	@EJB
	private IQuestionarioService questionarioService;
	
	@Override
	protected IResultadoQuestionarioDAO getDAO() {
		return resultadoQuestionarioDAO;
	}
	
	
    private static final long serialVersionUID = -4038281987975268059L;

    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void save(ResultadoQuestionario object) throws ServiceException, ValidationException {

        if (object != null) {

            if (object.getIdExterno() == null) {
                throw new ValidationException("Campo id externo deve ser preenchido");
            }
            object.setDataResposta(getDataBanco());
            super.save(object);

            for (Resposta resposta : object.getRespostaList()) {
                resposta.setResultadoQuestionario(object);
            }
            respostaService.save(object.getRespostaList());
        }
    }

    @Override
    public void validaPreenchimentoQuestionario(CasoSau casoSau) throws ServiceException, ValidationException {
        if (casoSau.getEvento() == null || casoSau.getTipoManifestacao() == null) {
            throw new ValidationException("Este caso nao possui evento e tipo de manifestacao.");
        }
        Questionario questionario = questionarioService.findByCasoSau(casoSau);
        if (questionario.getIdQuestionario() == null) {
            return;
        }
        ResultadoQuestionario resultado = findByCasoSau(casoSau);
        if (resultado == null || resultado.getIdResultadoQuestionario() == null) {
            throw new ValidationException("É necessário preencher o questionario antes de finalizar este caso.");
        }
    }

    @Override
    public ResultadoQuestionario findByCasoSau(CasoSau casoSau) throws ServiceException {
        if (casoSau.getIdCasoSau() == null) {
            throw new ServiceException("Caso Sau nao pode ser vazio.");
        }
        ResultadoQuestionario resultadoQuestionario = new ResultadoQuestionario();
        resultadoQuestionario.setIdExterno(casoSau.getIdCasoSau());
        List<ResultadoQuestionario> result = findByExample(resultadoQuestionario);
        if (result.isEmpty()) {
            return null;
        } else {
            return result.get(0);
        }
    }

    @Override
    public List<Object[]> questionariosRespondidos(Integer idExterno) throws ServiceException {
        try {
            return getDAO().questionariosRespondidos(idExterno);
        } catch (DataException ex) {
            throw new ServiceException("Falha ao recuperar questionario.", ex);
        }
    }

	@Override
	protected void validarSave(ResultadoQuestionario object)
			throws ValidationException {
		
	}

	@Override
	protected void validarUpdate(ResultadoQuestionario object)
			throws ValidationException {
		
	}

	@Override
	protected void validarDelete(ResultadoQuestionario object)
			throws ValidationException {
		
	}
}
