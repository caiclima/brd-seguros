package br.com.callink.cad.sau.service.impl;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.sau.dao.ITipoManifestacaoDAO;
import br.com.callink.cad.sau.pojo.TipoManifestacao;
import br.com.callink.cad.sau.service.IEventoService;
import br.com.callink.cad.sau.service.ITipoManifestacaoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

@Stateless
public class TipoManifestacaoService extends GenericCadSauService<TipoManifestacao, ITipoManifestacaoDAO> implements ITipoManifestacaoService {

    private static final long serialVersionUID = 1L;

    @Inject
    private ITipoManifestacaoDAO tipoManifestacaoDAO;
    
    @EJB
    private IEventoService eventoService;
    
    @Override
	protected ITipoManifestacaoDAO getDAO() {
		return tipoManifestacaoDAO;
	}
    
    
    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void save(TipoManifestacao tipoManifestacao) throws ServiceException, ValidationException {
        validarSave(tipoManifestacao);
        tipoManifestacao.setDataCriacao(getDataBanco());
        super.save(tipoManifestacao);
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void update(TipoManifestacao tipoManifestacao) throws ServiceException, ValidationException {
        validarUpdate(tipoManifestacao);
        tipoManifestacao.setDataCriacao(getDataBanco());
        super.update(tipoManifestacao);
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.SUPPORTS)
    public List<TipoManifestacao> findByExample(TipoManifestacao object) throws ServiceException{
        List<TipoManifestacao> ret = super.findByExample(object);
        for (TipoManifestacao tipoManifest : ret) {
            if (tipoManifest.getEvento() != null && tipoManifest.getEvento().getIdEvento() != null) {
                tipoManifest.setEvento(eventoService.load(tipoManifest.getEvento()));
            }
        }
        return ret;
    }

    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void inativar(TipoManifestacao tipoManifestacao) throws ServiceException, ValidationException{
    	validarUpdate(tipoManifestacao);
        tipoManifestacao.setDataCriacao(getDataBanco());
        tipoManifestacao.setFlagAtivo(Boolean.FALSE);
        update(tipoManifestacao);
    }

	@Override
	protected void validarSave(TipoManifestacao object) throws ValidationException {
		validarTipoManifestacao(object);
	}

	@Override
	protected void validarUpdate(TipoManifestacao object)
			throws ValidationException {
		validarTipoManifestacao(object);
	}

	@Override
	protected void validarDelete(TipoManifestacao object)
			throws ValidationException {
		validarTipoManifestacao(object);
	}
	
	private void validarTipoManifestacao(TipoManifestacao object) throws ValidationException{
		if (object == null) {
            throw new ValidationException("O Tipo de manifesta\u00E7\u00E3o deve ser preenchido.");
        }
        if (StringUtils.isEmpty(object.getNome())) {
            throw new ValidationException("O Nome n\u00E3o pode ser nulo.");
        }
	}
	
	
}
