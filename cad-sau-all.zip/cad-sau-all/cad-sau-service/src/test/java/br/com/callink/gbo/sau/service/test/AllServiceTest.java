package br.com.callink.gbo.sau.service.test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;


@RunWith(Suite.class)
@Suite.SuiteClasses({ 
	
})
public class AllServiceTest {

}
