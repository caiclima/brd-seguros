/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.gbo.sau.service.test.qlikview.service.impl;

import br.com.callink.cad.sau.qlikview.pojo.QlikViewEnquete;
import br.com.callink.cad.sau.qlikview.service.IQlikViewEnqueteService;
import br.com.callink.coreutils.service.exception.ServiceException;
import br.com.callink.gbo.sau.service.test.service.GenericServiceTest;
import java.util.Calendar;
import java.util.GregorianCalendar;
import org.junit.Test;

/**
 *
 * @author brunomt
 */
public class QlikViewEnqueteServiceTest extends GenericServiceTest<IQlikViewEnqueteService> {
    @Override
    public Class<?> getClazz() {
        return QlikViewEnquete.class;
    }
    
    @Test
    public void getRelatorio() throws ServiceException {
        getServiceInstance().lipaDadosQlikViewEnquete();
        Calendar calendar = new GregorianCalendar(2012, 3, 12);
        getServiceInstance().geraNuvemEnquetesBetweenDatas(calendar.getTime(), getServiceInstance().getDataBanco());
    } 
    
    @Test
    public void geraNuvemPeloParametro() throws ServiceException {
        getServiceInstance().geraNuvemPeloParametro();
    }

}
