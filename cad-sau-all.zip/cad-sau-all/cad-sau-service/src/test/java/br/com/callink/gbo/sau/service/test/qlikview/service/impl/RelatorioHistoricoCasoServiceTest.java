package br.com.callink.gbo.sau.service.test.qlikview.service.impl;

import org.junit.Test;

import br.com.callink.cad.sau.qlikview.pojo.RelatorioHistoricoCaso;
import br.com.callink.cad.sau.qlikview.service.IRelatorioHistoricoCasoService;
import br.com.callink.coreutils.service.exception.ServiceException;
import br.com.callink.gbo.sau.service.test.service.GenericServiceTest;

public class RelatorioHistoricoCasoServiceTest extends GenericServiceTest<IRelatorioHistoricoCasoService> {

    @Override
    public Class<?> getClazz() {
        return RelatorioHistoricoCaso.class;
    }

    @Test
    public void getRelatorios() throws ServiceException {
        IRelatorioHistoricoCasoService service = getServiceInstance();
        service.gerarHistoricos(service.getDataUltimoRelatorio());
    }
}
