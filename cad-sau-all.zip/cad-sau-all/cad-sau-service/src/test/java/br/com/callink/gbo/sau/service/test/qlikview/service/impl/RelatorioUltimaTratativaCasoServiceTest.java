package br.com.callink.gbo.sau.service.test.qlikview.service.impl;

import org.junit.Test;

import br.com.callink.cad.sau.qlikview.pojo.RelatorioUltimaTratativaCaso;
import br.com.callink.cad.sau.qlikview.service.IRelatorioUltimaTratativaCasoService;
import br.com.callink.coreutils.service.exception.ServiceException;
import br.com.callink.gbo.sau.service.test.service.GenericServiceTest;

public class RelatorioUltimaTratativaCasoServiceTest extends GenericServiceTest<IRelatorioUltimaTratativaCasoService> {

    @Override
    public Class<?> getClazz() {
        return RelatorioUltimaTratativaCaso.class;
    }

    @Test
    public void getRelatorios() throws ServiceException {
        IRelatorioUltimaTratativaCasoService service = getServiceInstance();
        service.gerarHistoricos(service.getDataUltimoRelatorio());
    }
}
