package br.com.callink.gbo.sau.service.test.service.impl;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import br.com.callink.cad.sau.pojo.Assunto;
import br.com.callink.cad.sau.service.IAssuntoService;
import br.com.callink.coreutils.service.exception.ServiceException;
import br.com.callink.gbo.sau.service.test.service.GenericServiceTest;

public class AssuntoServiceTest extends GenericServiceTest<IAssuntoService> {

	private static Assunto assunto;
	
	@Override
	public Class<?> getClazz() {
		return Assunto.class;
	}

	@Before
	public void preparaObjeto() throws ServiceException {
		assunto = new Assunto();
		assunto.setNome("ASSUNTO TESTE SAVE");
		assunto.setFlagAtivo(true);
		
		getServiceInstance().save(assunto);
		
		Assert.assertNotNull("erro ao salvar o assunto",assunto.getIdAssunto());
	}
	
	@Test
	public void findById() throws ServiceException {
		Assunto assuntoValidar = getServiceInstance().findByPk(assunto);
		Assert.assertNotNull("erro ao buscar assunto por id",assuntoValidar);
	}
	
	@Test
	public void findAtivos() throws ServiceException {
		
		getServiceInstance().findAtivos(null);
		
	}
	
	@After
	public void deletaObjeto() throws ServiceException {
		getServiceInstance().delete(assunto);
	}
	
	
}
