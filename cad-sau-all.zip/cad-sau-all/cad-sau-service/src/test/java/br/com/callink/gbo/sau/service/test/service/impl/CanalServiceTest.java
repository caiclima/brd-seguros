package br.com.callink.gbo.sau.service.test.service.impl;

import java.util.Date;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import br.com.callink.cad.sau.pojo.Canal;
import br.com.callink.cad.sau.service.ICanalService;
import br.com.callink.coreutils.service.exception.ServiceException;
import br.com.callink.gbo.sau.service.test.service.GenericServiceTest;

public class CanalServiceTest extends GenericServiceTest<ICanalService> {

	private static Canal canal = null;

	@Override
	public Class<?> getClazz() {
		return Canal.class;
	}

	@Before
	public void insert() throws ServiceException {

		if (canal == null) {
			canal = new Canal();
			canal.setNome("Canal 01");
			canal.setFlagAtivo(Boolean.TRUE);
			canal.setDataCriacao(new Date());
		}

		getServiceInstance().save(canal);
		Assert.assertNotNull(canal.getPK());
	}

	@After
	public void delete() throws ServiceException {
		getServiceInstance().delete(canal);
	}
	
	@Test
	public void findAtivos() throws ServiceException {
		getServiceInstance().findAtivos(null);
	}
	
	@Test
	public void inativar() throws ServiceException {
		getServiceInstance().inativar(canal);
	}

}
