package br.com.callink.gbo.sau.service.test.service.impl;

import java.util.logging.Level;
import java.util.logging.Logger;
import org.junit.Assert;

import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.sau.pojo.CasoAbertoCockpit;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.pojo.TipoManifestacao;
import br.com.callink.cad.sau.service.ICasoAbertoCockpitService;
import br.com.callink.cad.sau.service.ICasoSauService;
import br.com.callink.cad.sau.service.ITipoManifestacaoService;
import br.com.callink.coreutils.service.exception.ServiceException;
import br.com.callink.gbo.sau.service.test.service.GenericServiceTest;
import br.com.callink.gbo.sau.service.test.util.FactoryUtil;
import br.com.callink.gbo.service.ICasoService;
import java.util.List;

public class CasoSauServiceTest extends GenericServiceTest<ICasoSauService> {

	private static CasoSau casoSau;
	
	@Override
	public Class<?> getClazz() {
		return CasoSau.class;
	}
	
//	@Before
	public void preparaObjeto() throws ServiceException {
				
//		casoSau = new CasoSau();
//		
//		casoSau.setDataAbertura(getServiceInstance().getDataBanco());
//		casoSau.setDataUltimaAcao(getServiceInstance().getDataBanco());
//		casoSau.setAgenciaDepartamento("BRADESCO FINANCEIRO");
//		casoSau.setNomeCliente("Cliente 01");
//		casoSau.setAgenciaConta("22-222");
//		casoSau.setCpfCnpj("01710743514");
//		casoSau.setEmail("meuEmail@callink.com.br");
//		casoSau.setTelefone("(34)2222-2222");
//		casoSau.setTelefoneSegundo("(34)3333-3333");
//		casoSau.setEndereco("Rua Beco sem Saida");
//		casoSau.setCep("38400-666");
//		casoSau.setEnvioProtocoloCliente("0000000");
//		casoSau.setViaEntrada("Carta");
//		casoSau.setDescricao("Minha descricao");
//		casoSau.setAssunto("Meu assunto");
//		casoSau.setGrupo("Meu grupo");
//		casoSau.setSubGrupo("Meu subgrupo");
//		
//		casoSau.setCausa(new CausaService().findAll().get(0));
//		casoSau.setEvento(new EventoService().findAll().get(0));
//		casoSau.setCanal(new CanalService().findAll().get(0));
//		casoSau.setTipoManifestacao(new TipoManifestacaoService().findAll().get(0));
//		casoSau.setEstado(new EstadoService().findAll().get(0));
//		
//		getServiceInstance().save(casoSau);
	}
	
//        @Test
        public void buscaCasosFechadosNoDia() {
            try {
                List<CasoSau> casoSauList = getServiceInstance().buscaCasosFechadosNoDia();
                Assert.assertNotNull(casoSauList);
            } catch (ServiceException ex) {
                Logger.getLogger(CasoSauServiceTest.class.getName()).log(Level.SEVERE, null, ex);
            }            
        }
        
//	@Test
	public void findById() throws ServiceException {
//		CasoSau casoSauu = getServiceInstance().findByPk(casoSau);
//		Assert.assertNotNull(casoSauu.getPK());
	}
        
//        @Test
        public void geraCockpitCasosAbertos() throws ServiceException {
            ITipoManifestacaoService tipoManifestacaoService = (ITipoManifestacaoService) FactoryUtil.getServiceFactory().getService(TipoManifestacao.class);
            getServiceInstance().geraCockpitCasosAbertos();
            ICasoAbertoCockpitService casoAbertoCockpitService = (ICasoAbertoCockpitService) FactoryUtil.getServiceFactory().getService(CasoAbertoCockpit.class);
            
            List<TipoManifestacao> tipoManifestacaoList = tipoManifestacaoService.findAtivos(null);
            tipoManifestacaoList.remove(0);
            tipoManifestacaoList.remove(0);
            tipoManifestacaoList.remove(0);
            List<CasoAbertoCockpit> casoAbertoCockpits = casoAbertoCockpitService.getCasoAbertoList(tipoManifestacaoList);
            Assert.assertNotNull(casoAbertoCockpits);
        }
        
//        @Test
        public void acertaDataAbertura() throws ServiceException {
            List<CasoSau> casoSauList = getServiceInstance().findAll();
            
            for (CasoSau casoSau : casoSauList) {
                ICasoService casoService = (ICasoService) FactoryUtil.getServiceFactory().getService(Caso.class);
                
                Caso caso = casoService.findByPk(casoSau.getCaso());
                caso.setDataAbertura(casoSau.getDataAbertura());
                
                casoService.update(caso);
            }
             
        }
        
//        @Test
        public void buscaCasoAbertoAssunto() throws ServiceException {
            List<CasoSau> casoSauList = getServiceInstance().buscaCasoAbertoAssunto();
            Assert.assertNotNull(casoSauList);
        }
//        @Test
        public void geraCockpitClassificacaoCasos() throws ServiceException {
            getServiceInstance().geraCockpitClassificacaoCasos();
        }
	
//	@Test
	public void findByExample() throws ServiceException {
		/*TipoManifestacao tpManifestacao = new TipoManifestacao();
		tpManifestacao.setNome(tipoManifestacao.getNome());
		List<TipoManifestacao> tpManifestacaoList = getServiceInstance().findByExample(tpManifestacao);
		Assert.assertNotNull(tpManifestacaoList);*/
	}
	
//	@Test
	public void salvaUm() throws ServiceException {
		/*deletaObjeto();
		List<TipoManifestacao> tpManifestacaoList = getServiceInstance().findAll();
		if (tpManifestacaoList == null || tpManifestacaoList.isEmpty()) {
			TipoManifestacao tipoManifestacao = new TipoManifestacao();
			tipoManifestacao.setFlagAtivo(true);
			tipoManifestacao.setNome("TIPO RECLAMAÇÃO");
			IEventoService eventoService = (IEventoService) FactoryUtil.getServiceFactory().getService(Evento.class);
			tipoManifestacao.setEvento(eventoService.findAll().get(0));
			
			getServiceInstance().save(tipoManifestacao);
			Assert.assertNotNull(tipoManifestacao.getIdTipoCaso());
		}*/
	}
//	@After
	public void deletaObjeto() throws ServiceException {
		/*getServiceInstance().delete(tipoManifestacao);*/
	}
	
//	@Test
	public void buscarCasosPorCpfCnpj() throws ServiceException {
		List<CasoSau> casoSauList = getServiceInstance().buscarCasoSauPorCpfCnpj("08259013673");

		 Assert.assertNotNull(casoSauList);
	}

}
