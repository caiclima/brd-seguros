package br.com.callink.gbo.sau.service.test.service.impl;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import br.com.callink.cad.sau.pojo.Causa;
import br.com.callink.cad.sau.service.ICausaService;
import br.com.callink.coreutils.service.exception.ServiceException;
import br.com.callink.gbo.sau.service.test.service.GenericServiceTest;

public class CausaServiceTest extends GenericServiceTest<ICausaService> {

	private static Causa causa;
	
	@Override
	public Class<?> getClazz() {
		return Causa.class;
	}

	@Before
	public void preparaObjeto() throws ServiceException {
		causa = new Causa();
		causa.setNome("CAUSA TESTE NEW");
		causa.setFlagAtivo(true);
		
		getServiceInstance().save(causa);
		Assert.assertNotNull(causa.getIdCausa());
	}
	
	@Test
	public void findById() throws ServiceException {
		Causa causaFind = getServiceInstance().findByPk(causa);
		Assert.assertNotNull(causaFind.getIdCausa());
	}
	
	@After
	public void deletaObjeto() throws ServiceException {
		getServiceInstance().delete(causa);
	}
	
}
