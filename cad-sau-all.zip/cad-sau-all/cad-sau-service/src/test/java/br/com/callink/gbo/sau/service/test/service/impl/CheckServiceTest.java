package br.com.callink.gbo.sau.service.test.service.impl;

import java.util.List;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import br.com.callink.cad.sau.pojo.Check;
import br.com.callink.cad.sau.pojo.Checklist;
import br.com.callink.cad.sau.service.ICheckService;
import br.com.callink.cad.sau.service.IChecklistService;
import br.com.callink.coreutils.service.exception.ServiceException;
import br.com.callink.gbo.sau.service.test.service.GenericServiceTest;
import br.com.callink.gbo.sau.service.test.util.FactoryUtil;

public class CheckServiceTest extends GenericServiceTest<ICheckService> {

	private static Check check;

	@Override
	public Class<?> getClazz() {
		return Check.class;
	}

	@Before
	public void preparaObjeto() throws ServiceException {
		Checklist checklist = retornaChecklist();
		check = retornaCheck(checklist);

		getServiceInstance().save(check);
		Assert.assertNotNull(check.getPK());
	}

	@Test
	public void findById() throws ServiceException {
		Check checkInterno = getServiceInstance().findByPk(check);
		Assert.assertNotNull(checkInterno.getPK());
	}

	@Test
	public void findByExample() throws ServiceException {
		Check checkInterno = new Check();
		checkInterno.setDescricao(check.getDescricao());
		List<Check> checks = getServiceInstance().findByExample(checkInterno);
		Assert.assertNotNull(checks);
	}

	@After
	public void deletaObjeto() throws ServiceException {
		getServiceInstance().delete(check);
	}

	private Checklist retornaChecklist() throws ServiceException {
		
		IChecklistService checklistService = (IChecklistService) FactoryUtil
				.getServiceFactory().getService(Checklist.class);
		List<Checklist> checklistList = checklistService.findAll();
		if (checklistList != null && !checklistList.isEmpty()) {
			return checklistList.get(0);
		}

		throw new ServiceException("Nao pode inserir null no campo checklist");
	}

	private Check retornaCheck() {
		Check checkInterno = new Check();
		checkInterno.setDescricao("Conhece Joao?");
		checkInterno.setRespostasPossiveis("SIM;NAO");
		checkInterno.setFlagEnabled(Boolean.TRUE);
		checkInterno.setOrdem(1);
		
		return checkInterno;
	}

	private Check retornaCheck(Checklist checklist) {
		Check checkInterno = retornaCheck();
		checkInterno.setChecklist(checklist);
		return checkInterno;
	}
}
