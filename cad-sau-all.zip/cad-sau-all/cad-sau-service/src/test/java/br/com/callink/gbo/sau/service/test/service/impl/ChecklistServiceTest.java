package br.com.callink.gbo.sau.service.test.service.impl;

import java.util.ArrayList;
import java.util.List;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import br.com.callink.cad.sau.pojo.Check;
import br.com.callink.cad.sau.pojo.Checklist;
import br.com.callink.cad.sau.service.ICheckService;
import br.com.callink.cad.sau.service.IChecklistService;
import br.com.callink.coreutils.service.exception.ServiceException;
import br.com.callink.gbo.sau.service.test.service.GenericServiceTest;
import br.com.callink.gbo.sau.service.test.util.FactoryUtil;

public class ChecklistServiceTest extends GenericServiceTest<IChecklistService> {

	private static final String checklistDescricao = "CHECKLIST TESTE 01";
	
	private static Checklist checklist;
	private static Check checkInterno;
	@Override
	public Class<?> getClazz() {
		return Checklist.class;
	}
	
	@Before
	public void preparaObjeto() throws ServiceException {
		checklist = retornaChecklist();
		
		getServiceInstance().save(checklist);
		Assert.assertNotNull(checklist.getPK());
	}

	private Checklist retornaChecklist() {
		Checklist checklistInterno = new Checklist();
		checklistInterno.setDescricao(checklistDescricao);
		checklistInterno.setFlagEnabled(Boolean.TRUE);
		
		checkInterno = new Check();
		checkInterno.setDescricao("Conhece NET?");
		checkInterno.setFlagEnabled(true);
		checkInterno.setRespostasPossiveis("SIM;NAO");
		checkInterno.setFlagEnabled(Boolean.TRUE);
		checkInterno.setOrdem(1);
		
		List<Check> questaoList = new ArrayList<Check>();
		questaoList.add(checkInterno);
		checklistInterno.setChecks(questaoList);
	
		return checklistInterno;
		
	}
	
	@Test
	public void findById() throws ServiceException {
		Checklist checklistInterno = getServiceInstance().findByPk(checklist);
		Assert.assertNotNull(checklistInterno.getPK());
	}
	
	@Test
	public void findByExample() throws ServiceException {
		Checklist checklistInterno = new Checklist();
		checklistInterno.setDescricao(checklist.getDescricao());
		List<Checklist> checklistList = getServiceInstance().findByExample(checklistInterno);
		Assert.assertNotNull(checklistList);
	}
	
	@After
	public void deletaObjeto() throws ServiceException {
		ICheckService checkService = (ICheckService) FactoryUtil.getServiceFactory().getService(Check.class);
		checkService.delete(checkInterno);
		getServiceInstance().delete(checklist);
	}

	public static final String getChecklistdescricao() {
		return checklistDescricao + "-FIXO";
	}

}
