package br.com.callink.gbo.sau.service.test.service.impl;

import java.util.ArrayList;
import java.util.List;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import br.com.callink.cad.sau.pojo.AssociaConteudoApoio;
import br.com.callink.cad.sau.pojo.ConteudoApoio;
import br.com.callink.cad.sau.pojo.Evento;
import br.com.callink.cad.sau.service.IConteudoApoioService;
import br.com.callink.cad.sau.service.IEventoService;
import br.com.callink.coreutils.service.exception.ServiceException;
import br.com.callink.gbo.sau.service.test.service.GenericServiceTest;
import br.com.callink.gbo.sau.service.test.util.FactoryUtil;

public class ConteudoApoioServiceTest extends GenericServiceTest<IConteudoApoioService> {

    private static ConteudoApoio conteudoApoio;
    private static List<Evento> eventoList;
    @Override
    public Class<?> getClazz() {
        return ConteudoApoio.class;
    }

    @Before
    public void preparaObjeto() throws ServiceException {

        conteudoApoio = retornaConteudoApoio();

        getServiceInstance().save(conteudoApoio);
        Assert.assertNotNull(conteudoApoio.getPK());
    }

    @Test
    public void findById() throws ServiceException {
        ConteudoApoio conteudoApoioInterno = getServiceInstance().findByPk(conteudoApoio);
        Assert.assertNotNull(conteudoApoioInterno.getPK());
    }

    @Test
    public void findByExample() throws ServiceException {
        ConteudoApoio conteudoApoioInterno = new ConteudoApoio();
        conteudoApoioInterno.setNome(conteudoApoio.getNome());
        List<ConteudoApoio> conteudoApoioList = getServiceInstance().findByExample(conteudoApoioInterno);
        Assert.assertNotNull(conteudoApoioList);
    }

    @After
    public void deletaObjeto() throws ServiceException {
        getServiceInstance().delete(conteudoApoio);
    }

    private ConteudoApoio retornaConteudoApoio() throws ServiceException {

        ConteudoApoio conteudoApoioInterno = new ConteudoApoio();
        conteudoApoioInterno.setNome("TESTE 01");
        conteudoApoioInterno.setDescricao("DESCRICAO TESTE 01");
        conteudoApoioInterno.setFlagAtivo(Boolean.TRUE);
        //conteudoApoioInterno.setGrupoAnexo(retornaGrupoAnexo());
        
        List<AssociaConteudoApoio> associaConteudoApoioList = new ArrayList<AssociaConteudoApoio>();
        AssociaConteudoApoio associaConteudoApoio = new AssociaConteudoApoio();
        
        if (eventoList == null) {
        	IEventoService eventoService = (IEventoService) FactoryUtil.getServiceFactory().getService(Evento.class);
        	eventoList = eventoService.findAll();
        }
        
        associaConteudoApoio.setEvento(eventoList.get(0));
        associaConteudoApoioList.add(associaConteudoApoio);
        
        conteudoApoioInterno.setAssociaConteudoApoioList(associaConteudoApoioList);
        
        return conteudoApoioInterno;

    }
}
