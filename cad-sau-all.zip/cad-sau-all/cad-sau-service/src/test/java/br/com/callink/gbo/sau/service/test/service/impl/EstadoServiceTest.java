package br.com.callink.gbo.sau.service.test.service.impl;

import java.util.Date;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import br.com.callink.cad.sau.pojo.Estado;
import br.com.callink.cad.sau.service.IEstadoService;
import br.com.callink.coreutils.service.exception.ServiceException;
import br.com.callink.gbo.sau.service.test.service.GenericServiceTest;

public class EstadoServiceTest extends GenericServiceTest<IEstadoService> {
	private static Estado estado;

	@Override
	public Class<?> getClazz() {
		return Estado.class;
	}

	@Before
	public void preparaObjeto() throws ServiceException {
		estado = new Estado();
		estado.setNome("NOME_ESTADO_TESTE SAVE");
		estado.setFlagAtivo(true);
		estado.setDataCriacao(new Date());

		getServiceInstance().save(estado);

		Assert.assertNotNull("erro ao salvar o estado", estado.getIdEstado());
	}

	@Test
	public void findById() throws ServiceException {
		Estado estadoFound = getServiceInstance().findByPk(estado);
		Assert.assertNotNull("erro ao buscar estado por id", estadoFound);
	}

	@Test
	public void findAtivos() throws ServiceException {
		getServiceInstance().findAtivos(null);
	}

	@After
	public void deletaObjeto() throws ServiceException {
		getServiceInstance().delete(estado);
	}

}
