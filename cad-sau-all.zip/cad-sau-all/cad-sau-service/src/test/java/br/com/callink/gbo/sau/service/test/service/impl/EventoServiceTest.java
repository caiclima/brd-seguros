package br.com.callink.gbo.sau.service.test.service.impl;

import java.util.List;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;

import br.com.callink.cad.sau.pojo.Assunto;
import br.com.callink.cad.sau.pojo.Evento;
import br.com.callink.cad.sau.service.IAssuntoService;
import br.com.callink.cad.sau.service.IEventoService;
import br.com.callink.coreutils.service.exception.ServiceException;
import br.com.callink.gbo.sau.service.test.service.GenericServiceTest;
import br.com.callink.gbo.sau.service.test.util.FactoryUtil;

public class EventoServiceTest extends GenericServiceTest<IEventoService> {

	private static Evento evento;
	
	@Override
	public Class<?> getClazz() {
		return Evento.class;
	}
	
	@Before
	public void preparaObjeto() throws ServiceException {
		evento =  new Evento();
		evento.setFlagAtivo(true);
		evento.setNome("Evento Teste");
		evento.setEmail("bruno.martins@callink.com.br");
		evento.setFlagFinalizacaoAutomatica(true);
		IAssuntoService assuntoService = (IAssuntoService) FactoryUtil.getServiceFactory().getService(Assunto.class);
		evento.setAssunto(assuntoService.findAll().get(0));
		
		getServiceInstance().save(evento);
		Assert.assertNotNull(evento.getIdEvento());
	}
	
	@Test
	public void findById() throws ServiceException {
		Evento eventoValida = getServiceInstance().findByPk(evento);
		Assert.assertNotNull(eventoValida.getIdEvento());
	}
	
	@Test
	public void findByExample() throws ServiceException {
		Evento eventoConsulta = new Evento();
		eventoConsulta.setNome(evento.getNome());
		List<Evento> eventoList = getServiceInstance().findByExample(eventoConsulta);
		Assert.assertNotNull(eventoList);
	}
	
	@Test
	public void deletaObjeto() throws ServiceException {
		getServiceInstance().delete(evento);
	}

}
