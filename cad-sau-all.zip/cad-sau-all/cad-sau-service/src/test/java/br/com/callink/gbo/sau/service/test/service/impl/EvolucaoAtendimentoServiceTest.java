/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.gbo.sau.service.test.service.impl;

import br.com.callink.cad.sau.pojo.EvolucaoAtendimento;
import br.com.callink.cad.sau.service.IEvolucaoAtendimentoService;
import br.com.callink.coreutils.service.exception.ServiceException;
import br.com.callink.gbo.sau.service.test.service.GenericServiceTest;
import org.junit.Test;

/**
 *
 * @author brunomt
 */
public class EvolucaoAtendimentoServiceTest extends GenericServiceTest<IEvolucaoAtendimentoService> {

    @Override
    public Class<?> getClazz() {
        return EvolucaoAtendimento.class;
    }
    
    @Test 
    public void geraEvolucaoAtendimento() throws ServiceException {
        getServiceInstance().geraEvolucaoAtendimento();
        
    }
    
}
