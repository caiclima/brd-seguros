package br.com.callink.gbo.sau.service.test.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;

import br.com.callink.cad.engine.command.executor.IExecutorCommandService;
import br.com.callink.cad.pojo.Status;
import br.com.callink.cad.pojo.StatusAcao;
import br.com.callink.coreutils.service.exception.ServiceException;
import br.com.callink.gbo.sau.service.test.util.FactoryUtil;
import br.com.callink.gbo.service.IStatusService;

public class ExecutorCommandServiceTest {
	private IExecutorCommandService getExecutorCommandServiceInstance() {
		return (IExecutorCommandService) FactoryUtil.getServiceFactory().getService("executorCommandService");
	}

	private IStatusService getStatusAcaoServiceInstance() {
		return (IStatusService) FactoryUtil.getServiceFactory().getService(Status.class);
	}

//	@Test
	public void executeCommandTest() {
		IExecutorCommandService serviceInstance = getExecutorCommandServiceInstance();
		IStatusService statusService = getStatusAcaoServiceInstance();

		List<StatusAcao> statusAcao;
		try {
			statusAcao = statusService.findAllStatusAcao();

			if (statusAcao.size() > 0) {
				try {
					Map<String, Object> params = new HashMap<String, Object>();
					params.put("acao", statusAcao.get(0).getIdAcao());
					serviceInstance.execute(params);

				} catch (ServiceException e) {
					if (!e.getMessage().contains("não implementado ainda!")) {
						throw new AssertionError("ExecutorCommandService failed to execute the not implemented services");
					}
				}
			}

		} catch (ServiceException e1) {
			System.out.println("associe um status a uma ação para efetuar o : " + ExecutorCommandServiceTest.class.getSimpleName());
		}

	}

}
