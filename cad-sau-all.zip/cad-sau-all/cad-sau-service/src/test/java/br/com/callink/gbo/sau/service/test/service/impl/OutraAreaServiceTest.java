/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.gbo.sau.service.test.service.impl;

import br.com.callink.cad.sau.pojo.OutraArea;
import br.com.callink.cad.sau.service.IOutraAreaService;
import br.com.callink.coreutils.service.exception.ServiceException;
import br.com.callink.gbo.sau.service.test.service.GenericServiceTest;
import java.util.Date;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 *
 * @author ubuntu
 */
public class OutraAreaServiceTest extends GenericServiceTest<IOutraAreaService> {

	private static OutraArea outraArea = null;

	@Override
	public Class<OutraArea> getClazz() {
		return OutraArea.class;
	}

	@Before
	public void insert() throws ServiceException {

		if (outraArea == null) {
			outraArea = new OutraArea();
			outraArea.setNome("OutraArea Teste");
			outraArea.setFlagAtivo(Boolean.TRUE);
			outraArea.setDataCriacao(new Date());
		}

		getServiceInstance().save(outraArea);
		Assert.assertNotNull(outraArea.getPK());
	}

	@After
	public void delete() throws ServiceException {
		getServiceInstance().delete(outraArea);
	}
	
	@Test
	public void findAtivos() throws ServiceException {
		getServiceInstance().findAtivos(null);
	}
}
