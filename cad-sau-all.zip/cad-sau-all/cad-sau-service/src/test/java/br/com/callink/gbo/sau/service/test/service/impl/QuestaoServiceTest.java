package br.com.callink.gbo.sau.service.test.service.impl;

import java.util.List;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import br.com.callink.cad.sau.pojo.Questao;
import br.com.callink.cad.sau.pojo.Questionario;
import br.com.callink.cad.sau.service.IQuestaoService;
import br.com.callink.cad.sau.service.IQuestionarioService;
import br.com.callink.coreutils.service.exception.ServiceException;
import br.com.callink.gbo.sau.service.test.service.GenericServiceTest;
import br.com.callink.gbo.sau.service.test.util.FactoryUtil;

public class QuestaoServiceTest extends GenericServiceTest<IQuestaoService> {

	private static Questao questao;

	@Override
	public Class<?> getClazz() {
		return Questao.class;
	}

	@Before
	public void preparaObjeto() throws ServiceException {
		Questionario questionario = retornaQuestionario();
		questao = retornaQuestao(questionario);

		getServiceInstance().save(questao);
		Assert.assertNotNull(questao.getPK());
	}

	@Test
	public void findById() throws ServiceException {
		Questao questaoInterno = getServiceInstance().findByPk(questao);
		Assert.assertNotNull(questaoInterno.getPK());
	}

	@Test
	public void findByExample() throws ServiceException {
		Questao questaoInterno = new Questao();
		questaoInterno.setDescricao(questao.getDescricao());
		List<Questao> questaoList = getServiceInstance().findByExample(
				questaoInterno);
		Assert.assertNotNull(questaoList);
	}

	@After
	public void deletaObjeto() throws ServiceException {
		getServiceInstance().delete(questao);
	}

	private Questionario retornaQuestionario() throws ServiceException {

		Questionario questionarioInterno = new Questionario();
		questionarioInterno.setDescricao(QuestionarioServiceTest
				.getQuestionariodescricao());
		questionarioInterno.setFlagAtivo(Boolean.TRUE);

		IQuestionarioService questionarioService = (IQuestionarioService) FactoryUtil
				.getServiceFactory().getService(Questionario.class);
		List<Questionario> questionarioList = questionarioService
				.findByExample(questionarioInterno);
		if (questionarioList != null && !questionarioList.isEmpty()) {
			return questionarioList.get(0);
		}

		throw new ServiceException(
				"Nao pode inserir null no campo questionario");
	}

	private Questao retornaQuestao() {
		Questao questaoInterno = new Questao();
		questaoInterno.setDescricao("Qual o seu nome?");
		
		return questaoInterno;
	}

	private Questao retornaQuestao(Questionario questionario) {
		Questao questaoInterno = retornaQuestao();
		questaoInterno.setQuestionario(questionario);
		return questaoInterno;
	}
}
