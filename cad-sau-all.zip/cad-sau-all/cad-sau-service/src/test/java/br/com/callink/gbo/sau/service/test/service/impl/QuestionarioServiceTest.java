package br.com.callink.gbo.sau.service.test.service.impl;

import java.util.ArrayList;
import java.util.List;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import br.com.callink.cad.sau.pojo.Questao;
import br.com.callink.cad.sau.pojo.Questionario;
import br.com.callink.cad.sau.service.IQuestaoService;
import br.com.callink.cad.sau.service.IQuestionarioService;
import br.com.callink.coreutils.service.exception.ServiceException;
import br.com.callink.gbo.sau.service.test.service.GenericServiceTest;
import br.com.callink.gbo.sau.service.test.util.FactoryUtil;

public class QuestionarioServiceTest extends GenericServiceTest<IQuestionarioService> {

	private static final String questionarioDescricao = "QUESTIONARIO TESTE 01";
	
	private static Questionario questionario;
	private static Questao questaoInterno;
	@Override
	public Class<?> getClazz() {
		return Questionario.class;
	}
	
	@Before
	public void preparaObjeto() throws ServiceException {
		questionario = retornaQuestionario();
		
		getServiceInstance().save(questionario);
		Assert.assertNotNull(questionario.getPK());
	}

	private Questionario retornaQuestionario() {
		Questionario questionarioInterno = new Questionario();
		questionarioInterno.setDescricao(questionarioDescricao);
		questionarioInterno.setFlagAtivo(Boolean.TRUE);
		
		questaoInterno = new Questao();
		questaoInterno.setDescricao("Qual o seu nome?");
		questaoInterno.setFlagAtivo(true);
		
		List<Questao> questaoList = new ArrayList<Questao>();
		questaoList.add(questaoInterno);
		questionarioInterno.setQuestaoList(questaoList);
	
		return questionarioInterno;
		
	}
	
	@Test
	public void findById() throws ServiceException {
		Questionario questionarioInterno = getServiceInstance().findByPk(questionario);
		Assert.assertNotNull(questionarioInterno.getPK());
	}
	
	@Test
	public void findByExample() throws ServiceException {
		Questionario questionarioInterno = new Questionario();
		questionarioInterno.setDescricao(questionario.getDescricao());
		List<Questionario> questionarioList = getServiceInstance().findByExample(questionarioInterno);
		Assert.assertNotNull(questionarioList);
	}
	
	@After
	public void deletaObjeto() throws ServiceException {
		IQuestaoService questaoService = (IQuestaoService) FactoryUtil.getServiceFactory().getService(Questao.class);
		questaoService.delete(questaoInterno);
		getServiceInstance().delete(questionario);
	}

	public static final String getQuestionariodescricao() {
		return questionarioDescricao + "-FIXO";
	}

}
