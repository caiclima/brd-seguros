package br.com.callink.gbo.sau.service.test.service.impl;

import java.util.List;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import br.com.callink.cad.sau.pojo.Check;
import br.com.callink.cad.sau.pojo.RespostaChecklist;
import br.com.callink.cad.sau.pojo.ResultadoChecklist;
import br.com.callink.cad.sau.service.ICheckService;
import br.com.callink.cad.sau.service.IRespostaChecklistService;
import br.com.callink.cad.sau.service.IResultadoChecklistService;
import br.com.callink.coreutils.service.exception.ServiceException;
import br.com.callink.gbo.sau.service.test.service.GenericServiceTest;
import br.com.callink.gbo.sau.service.test.util.FactoryUtil;

public class RespostaChecklistServiceTest extends GenericServiceTest<IRespostaChecklistService> {

	private static RespostaChecklist respostaChecklist;

	@Override
	public Class<?> getClazz() {
		return RespostaChecklist.class;
	}

	@Before
	public void preparaObjeto() throws ServiceException {
		respostaChecklist = retornaResposta();

		getServiceInstance().save(respostaChecklist);
		Assert.assertNotNull(respostaChecklist.getPK());
	}

	@Test
	public void findById() throws ServiceException {
		RespostaChecklist respostaChecklistInterno = getServiceInstance().findByPk(respostaChecklist);
		Assert.assertNotNull(respostaChecklistInterno.getPK());
	}

	@Test
	public void findByExample() throws ServiceException {
		RespostaChecklist respostaChecklistInterno = new RespostaChecklist();
		List<RespostaChecklist> checks = getServiceInstance().findByExample(respostaChecklistInterno);
		Assert.assertNotNull(checks);
	}

	@After
	public void deletaObjeto() throws ServiceException {
		getServiceInstance().delete(respostaChecklist);
	}

	private Check retornaCheck() throws ServiceException {
		ICheckService checkService = (ICheckService) FactoryUtil.getServiceFactory().getService(Check.class);
		List<Check> itens = checkService.findAll();
		if (itens != null && !itens.isEmpty()) {
			return itens.get(0);
		}
		throw new ServiceException("Nao existe nenhum ResultadoChecklist cadastrado");
	}

	private RespostaChecklist retornaResposta() throws ServiceException {

		RespostaChecklist respostaChecklistInterno = new RespostaChecklist();
		respostaChecklistInterno.setCheck(retornaCheck());
		respostaChecklistInterno.setResultadoChecklist(retornaResultadoChecklist());
		respostaChecklistInterno.setResposta("joao da Silva");
		return respostaChecklistInterno;
	}

	private ResultadoChecklist retornaResultadoChecklist() throws ServiceException {

		IResultadoChecklistService resultadoChecklistService = (IResultadoChecklistService) FactoryUtil.getServiceFactory().getService(ResultadoChecklist.class);
		List<ResultadoChecklist> resultadoChecklists= resultadoChecklistService.findAll();
		if (resultadoChecklists != null && !resultadoChecklists.isEmpty()) {
			return resultadoChecklists.get(0);
		}
		throw new ServiceException("Nao existe nenhum ResultadoQuestionario cadastrado");
	}
}
