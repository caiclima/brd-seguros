package br.com.callink.gbo.sau.service.test.service.impl;

import java.util.List;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import br.com.callink.cad.sau.pojo.Questao;
import br.com.callink.cad.sau.pojo.Resposta;
import br.com.callink.cad.sau.pojo.ResultadoQuestionario;
import br.com.callink.cad.sau.service.IQuestaoService;
import br.com.callink.cad.sau.service.IRespostaService;
import br.com.callink.cad.sau.service.IResultadoQuestionarioService;
import br.com.callink.coreutils.service.exception.ServiceException;
import br.com.callink.gbo.sau.service.test.service.GenericServiceTest;
import br.com.callink.gbo.sau.service.test.util.FactoryUtil;

public class RespostaServiceTest extends GenericServiceTest<IRespostaService> {

	private static Resposta resposta;

	@Override
	public Class<?> getClazz() {
		return Resposta.class;
	}

	@Before
	public void preparaObjeto() throws ServiceException {
		resposta = retornaResposta();

		getServiceInstance().save(resposta);
		Assert.assertNotNull(resposta.getPK());
	}

	@Test
	public void findById() throws ServiceException {
		Resposta respostaInterno = getServiceInstance().findByPk(resposta);
		Assert.assertNotNull(respostaInterno.getPK());
	}

	@Test
	public void findByExample() throws ServiceException {
		Resposta resposta = retornaResposta();
		List<Resposta> questaoList = getServiceInstance().findByExample(
				resposta);
		Assert.assertNotNull(questaoList);
	}

	@After
	public void deletaObjeto() throws ServiceException {
		getServiceInstance().delete(resposta);
	}

	private Questao retornaQuestao() throws ServiceException {
		IQuestaoService questaoService = (IQuestaoService) FactoryUtil
				.getServiceFactory().getService(Questao.class);
		List<Questao> itens = questaoService.findAll();
		if (itens != null && !itens.isEmpty()) {
			return itens.get(0);
		}
		throw new ServiceException(
				"Nao existe nenhum ResultadoQuestionario cadastrado");
	}

	private Resposta retornaResposta() throws ServiceException {

		Resposta resposta = new Resposta();
		resposta.setQuestao(retornaQuestao());
		resposta.setResultadoQuestionario(retornaResultadoQuestionario());
		resposta.setResposta("joao da Silva");
		return resposta;
	}

	private ResultadoQuestionario retornaResultadoQuestionario()
			throws ServiceException {

		IResultadoQuestionarioService resultadoQuestionarioService = (IResultadoQuestionarioService) FactoryUtil
				.getServiceFactory().getService(ResultadoQuestionario.class);
		List<ResultadoQuestionario> resultadoQuestionarios = resultadoQuestionarioService
				.findAll();
		if (resultadoQuestionarios != null && !resultadoQuestionarios.isEmpty()) {
			return resultadoQuestionarios.get(0);
		}
		throw new ServiceException(
				"Nao existe nenhum ResultadoQuestionario cadastrado");
	}
}
