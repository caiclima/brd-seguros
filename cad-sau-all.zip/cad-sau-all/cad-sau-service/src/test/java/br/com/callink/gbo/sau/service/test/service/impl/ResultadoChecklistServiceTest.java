package br.com.callink.gbo.sau.service.test.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import br.com.callink.cad.sau.pojo.Check;
import br.com.callink.cad.sau.pojo.RespostaChecklist;
import br.com.callink.cad.sau.pojo.ResultadoChecklist;
import br.com.callink.cad.sau.service.ICheckService;
import br.com.callink.cad.sau.service.IRespostaChecklistService;
import br.com.callink.cad.sau.service.IResultadoChecklistService;
import br.com.callink.coreutils.service.exception.ServiceException;
import br.com.callink.gbo.sau.service.test.service.GenericServiceTest;
import br.com.callink.gbo.sau.service.test.util.FactoryUtil;

public class ResultadoChecklistServiceTest extends GenericServiceTest<IResultadoChecklistService> {

	private static ResultadoChecklist resultadoChecklist;
	private static Date dataBanco;
	private static List<Check> checks;
	private static RespostaChecklist respostaChecklist;
	
	@Override
	public Class<?> getClazz() {
		return ResultadoChecklist.class;
	}
	
	@Before
	public void preparaObjeto() throws ServiceException {
		
		resultadoChecklist = retornaResultadoChecklist();
		resultadoChecklist.setDataResposta(new Date());
		
		getServiceInstance().save(resultadoChecklist);
		Assert.assertNotNull(resultadoChecklist.getPK());
	}

	@Test
	public void findById() throws ServiceException {
		ResultadoChecklist resultadoChecklistInterno = getServiceInstance().findByPk(resultadoChecklist);
		Assert.assertNotNull(resultadoChecklistInterno.getPK());
	}
	
	@Test
	public void findByExample() throws ServiceException {
		List<ResultadoChecklist> resultadoChecklistList = getServiceInstance().findByExample(resultadoChecklist);
		Assert.assertNotNull(resultadoChecklistList);
	}
	

	@After
	public void deletaObjeto() throws ServiceException {
		IRespostaChecklistService respostaChecklistService = (IRespostaChecklistService) FactoryUtil.getServiceFactory().getService(RespostaChecklist.class);
		respostaChecklistService.delete(respostaChecklist);
		getServiceInstance().delete(resultadoChecklist);
	}

	private ResultadoChecklist retornaResultadoChecklist() throws ServiceException {
		ResultadoChecklist resultadoInterno = new ResultadoChecklist();
		resultadoInterno.setIdExterno(1);
		resultadoInterno.setLogin("fulano");
		resultadoInterno.setTipoAtendimento("caso");
		
		List<RespostaChecklist> respostaList = new ArrayList<RespostaChecklist>();
		
		if (checks == null) {
			ICheckService checkService = (ICheckService) FactoryUtil.getServiceFactory().getService(Check.class);
			checks = checkService.findAll();
		}
		Check check = checks.get(0);
		
		respostaChecklist = new RespostaChecklist();
		respostaChecklist.setCheck(check);
		respostaChecklist.setResposta(check.getRespostaPadrao() != null ? check.getRespostaPadrao() : "TESTE");
		respostaChecklist.setDataResposta(dataBanco);
		respostaList.add(respostaChecklist);
		
		resultadoInterno.setRespostaList(respostaList);
		return resultadoInterno;
	}
	
}
