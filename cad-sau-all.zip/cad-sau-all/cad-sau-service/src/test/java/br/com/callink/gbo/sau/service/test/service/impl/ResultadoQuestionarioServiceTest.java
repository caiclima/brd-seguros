package br.com.callink.gbo.sau.service.test.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import br.com.callink.cad.sau.pojo.Questao;
import br.com.callink.cad.sau.pojo.Resposta;
import br.com.callink.cad.sau.pojo.ResultadoQuestionario;
import br.com.callink.cad.sau.service.IQuestaoService;
import br.com.callink.cad.sau.service.IRespostaService;
import br.com.callink.cad.sau.service.IResultadoQuestionarioService;
import br.com.callink.coreutils.service.exception.ServiceException;
import br.com.callink.gbo.sau.service.test.service.GenericServiceTest;
import br.com.callink.gbo.sau.service.test.util.FactoryUtil;

public class ResultadoQuestionarioServiceTest extends GenericServiceTest<IResultadoQuestionarioService> {

	private static ResultadoQuestionario resultadoQuestionario;
	private static Date dataBanco;
	private static List<Questao> questaoList;
	private static Resposta resposta;
	@Override
	public Class<?> getClazz() {
		return ResultadoQuestionario.class;
	}
	
	@Before
	public void preparaObjeto() throws ServiceException {
		
		if(dataBanco == null){
			dataBanco = getServiceInstance().getDataBanco();
		}
		
		resultadoQuestionario = retornaResultadoQuestionario();
		resultadoQuestionario.setDataResposta(dataBanco);
		
		getServiceInstance().save(resultadoQuestionario);
		Assert.assertNotNull(resultadoQuestionario.getPK());
	}

	@Test
	public void findById() throws ServiceException {
		ResultadoQuestionario resultadoQuestionarioInterno = getServiceInstance().findByPk(resultadoQuestionario);
		Assert.assertNotNull(resultadoQuestionarioInterno.getPK());
	}
	
	@Test
	public void findByExample() throws ServiceException {
		List<ResultadoQuestionario> resultadoQuestionarioList = getServiceInstance().findByExample(resultadoQuestionario);
		Assert.assertNotNull(resultadoQuestionarioList);
	}
	

	@After
	public void deletaObjeto() throws ServiceException {
		IRespostaService respostaService = (IRespostaService) FactoryUtil.getServiceFactory().getService(Resposta.class);
		respostaService.delete(resposta);
		getServiceInstance().delete(resultadoQuestionario);
	}

	private ResultadoQuestionario retornaResultadoQuestionario() throws ServiceException {
		ResultadoQuestionario resultadoQuestionario = new ResultadoQuestionario();
		resultadoQuestionario.setIdExterno(1);
		resultadoQuestionario.setLogin("ednaldo.lima");
		resultadoQuestionario.setTipoAtendimento("telefone");
		
		List<Resposta> respostaList = new ArrayList<Resposta>();
		
		if (questaoList == null) {
			IQuestaoService questaoService = (IQuestaoService) FactoryUtil.getServiceFactory().getService(Questao.class);
			questaoList = questaoService.findAll();
		}
		Questao questao = questaoList.get(0);
		
		resposta = new Resposta();
		resposta.setQuestao(questao);
		resposta.setResposta(questao.getRespostaPadrao() != null ? questao.getRespostaPadrao() : "TESTE");
		resposta.setDataResposta(dataBanco);
		respostaList.add(resposta);
		
 		resultadoQuestionario.setRespostaList(respostaList);
		return resultadoQuestionario;
	}
}
