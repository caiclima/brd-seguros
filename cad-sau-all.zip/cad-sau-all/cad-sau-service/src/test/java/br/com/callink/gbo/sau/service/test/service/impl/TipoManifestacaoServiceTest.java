package br.com.callink.gbo.sau.service.test.service.impl;

import java.util.List;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import br.com.callink.cad.sau.pojo.Evento;
import br.com.callink.cad.sau.pojo.TipoManifestacao;
import br.com.callink.cad.sau.service.IEventoService;
import br.com.callink.cad.sau.service.ITipoManifestacaoService;
import br.com.callink.coreutils.service.exception.ServiceException;
import br.com.callink.gbo.sau.service.test.service.GenericServiceTest;
import br.com.callink.gbo.sau.service.test.util.FactoryUtil;

public class TipoManifestacaoServiceTest extends GenericServiceTest<ITipoManifestacaoService> {

	private static TipoManifestacao tipoManifestacao;
	private static List<Evento> eventoList;
	@Override
	public Class<?> getClazz() {
		return TipoManifestacao.class;
	}
	
	@Before
	public void preparaObjeto() throws ServiceException {
		tipoManifestacao = new TipoManifestacao();
		tipoManifestacao.setFlagAtivo(true);
		tipoManifestacao.setNome("TIPO TESTE");
		if (eventoList == null) {
			IEventoService eventoService = (IEventoService) FactoryUtil.getServiceFactory().getService(Evento.class);
			eventoList = eventoService.findAll();
		}
		tipoManifestacao.setEvento(eventoList.get(0));
		
		getServiceInstance().save(tipoManifestacao);
		Assert.assertNotNull(tipoManifestacao.getIdTipoCaso());
	}
	
	@Test
	public void findById() throws ServiceException {
		TipoManifestacao tpManifestacao = getServiceInstance().findByPk(tipoManifestacao);
		Assert.assertNotNull(tpManifestacao.getIdTipoCaso());
	}
	
	@Test
	public void findByExample() throws ServiceException {
		TipoManifestacao tpManifestacao = new TipoManifestacao();
		tpManifestacao.setNome(tipoManifestacao.getNome());
		List<TipoManifestacao> tpManifestacaoList = getServiceInstance().findByExample(tpManifestacao);
		Assert.assertNotNull(tpManifestacaoList);
	}
	
	@After
	public void deletaObjeto() throws ServiceException {
		getServiceInstance().delete(tipoManifestacao);
	}

}
