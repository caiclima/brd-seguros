package br.com.callink.gbo.sau.service.test.util;

import br.com.callink.coreutils.dao.factory.impl.FactoryDAO;
import br.com.callink.coreutils.service.factory.impl.FactoryService;

public class FactoryUtil {
	private static final FactoryDAO factoryDAO = new FactoryDAO();
	private static final FactoryService factoryService = new FactoryService();

	private FactoryUtil() {
	}

	public static FactoryDAO getDaoFactory() {
		return factoryDAO;
	}

	public static FactoryService getServiceFactory() {
		return factoryService;
	}

}
