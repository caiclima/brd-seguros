package br.com.callink.cad.sau.cockpit;

import java.util.logging.Level;
import java.util.logging.Logger;

import br.com.callink.cad.pojo.ParametroGBO;
import br.com.callink.cad.sau.service.ICasoSauService;
import br.com.callink.cad.service.IParametroGBOService;
import br.com.callink.cad.util.Constantes;

/**
 *
 * @author brunomt
 */
public class ThreadCasoAbertoCockpit extends Thread {
    private static final Logger LOGGER = Logger.getLogger(ThreadCasoAbertoCockpit.class.getName());
    
    private IParametroGBOService parametroGBOService;
    private ICasoSauService casoAbertoCockpitService;
    private static boolean executa;
    
    
    public ThreadCasoAbertoCockpit(IParametroGBOService parametroGBOService,ICasoSauService casoAbertoCockpitService) {
    	this.parametroGBOService = parametroGBOService;
    	this.casoAbertoCockpitService = casoAbertoCockpitService;
    }
    
    @Override
    public void run() {
        try {
            Thread.sleep(Integer.valueOf(62000));
        } catch (InterruptedException ex) {
            Logger.getLogger(ThreadCasoAbertoCockpit.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        LOGGER.info("ThreadCasoAbertoCockpit iniciada");
        
        Integer valor=null;
        
        ThreadCasoAbertoCockpit.executa = Boolean.TRUE;
        
        while(executa) {
            try {
                casoAbertoCockpitService.geraCockpitCasosAbertos();

                ParametroGBO parametroGBO=null;
                try {
                    parametroGBO = parametroGBOService.findByParam(Constantes.TEMPO_SCHEDULE_CASOS_ABERTOS);
                    valor = Integer.valueOf(parametroGBO.getValor()) * 1000;
                } catch (Exception ex) {
                    valor = null;
                    Logger.getLogger(ThreadEvolucaoAtendimentoCaso.class.getName()).log(Level.SEVERE, null, ex);
                }
                
            } catch (Exception ex) {
                Logger.getLogger(ThreadCasoAbertoCockpit.class.getName()).log(Level.SEVERE, null, ex);
            }
            try {
                if (valor == null || valor.equals(0)) {
                    valor = 120000;
                }
                
                Thread.sleep(valor);
            } catch (InterruptedException ex) {
                Logger.getLogger(ThreadCasoAbertoCockpit.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        LOGGER.info("ThreadCasoAbertoCockpit finalizada");
    }

    public static boolean isExecuta() {
        return executa;
    }

    public static void setExecuta(boolean executa) {
        ThreadCasoAbertoCockpit.executa = executa;
    }
    
    

}
