package br.com.callink.cad.sau.cockpit;

import java.util.logging.Level;
import java.util.logging.Logger;

import br.com.callink.cad.pojo.ParametroGBO;
import br.com.callink.cad.sau.service.ICasoSauService;
import br.com.callink.cad.service.IParametroGBOService;
import br.com.callink.cad.util.Constantes;

/**
 *
 * @author brunomt
 */
public class ThreadCasosClassificadosCockpit extends Thread {
    private static final Logger LOGGER = Logger.getLogger(ThreadCasosClassificadosCockpit.class.getName());
    
    private IParametroGBOService parametroGBOService;
    private ICasoSauService casoSauService;
    private static boolean executa;
    public ThreadCasosClassificadosCockpit(IParametroGBOService parametroGBOService, ICasoSauService casoSauService) {
    	this.casoSauService = casoSauService;
    	this.parametroGBOService = parametroGBOService;
    }
    
    @Override
    public void run() {
        try {
            Thread.sleep(Integer.valueOf(63000));
        } catch (InterruptedException ex) {
            Logger.getLogger(ThreadCasosClassificadosCockpit.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        LOGGER.info("ThreadCasosClassificadosCockpit iniciada");
        
        Integer valor=null;
        
        ThreadCasosClassificadosCockpit.executa = Boolean.TRUE;
        
        while(executa) {
            try {
                casoSauService.geraCockpitClassificacaoCasos();
                ParametroGBO parametroGBO=null;
                try {
                    parametroGBO = parametroGBOService.findByParam(Constantes.TEMPO_SCHEDULE_CASOS_CLASSIFICADOS);
                    valor = Integer.valueOf(parametroGBO.getValor()) * 1000;
                } catch (Exception ex) {
                    valor = null;
                    Logger.getLogger(ThreadEvolucaoAtendimentoCaso.class.getName()).log(Level.SEVERE, null, ex);
                }
                
            } catch (Exception ex) {
                Logger.getLogger(ThreadCasosClassificadosCockpit.class.getName()).log(Level.SEVERE, null, ex);
            }
            try {
                if (valor == null || valor.equals(0)) {
                    valor = 120000;
                }
                
                Thread.sleep(valor);
            } catch (InterruptedException ex) {
                Logger.getLogger(ThreadCasosClassificadosCockpit.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        LOGGER.info("ThreadCasosClassificadosCockpit finalizada");
    }

    public static boolean isExecuta() {
        return executa;
    }

    public static void setExecuta(boolean executa) {
        ThreadCasosClassificadosCockpit.executa = executa;
    }
    
    

}
