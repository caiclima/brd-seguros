/*
 * and open the template in the editor.
 */
package br.com.callink.cad.sau.cockpit;

import java.util.logging.Level;
import java.util.logging.Logger;

import br.com.callink.cad.pojo.ParametroGBO;
import br.com.callink.cad.sau.service.IEvolucaoAtendimentoService;
import br.com.callink.cad.service.IParametroGBOService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.util.Constantes;

/**
 *
 * @author brunomt
 */
public class ThreadEvolucaoAtendimentoCaso extends Thread {
    private static final Logger LOGGER = Logger.getLogger(ThreadEvolucaoAtendimentoCaso.class.getName());

    private IParametroGBOService parametroGBOService;
    private IEvolucaoAtendimentoService evolucaoAtendimentoService;
    
    private static boolean executa;

    public ThreadEvolucaoAtendimentoCaso(IParametroGBOService parametroGBOService,IEvolucaoAtendimentoService evolucaoAtendimentoService ) {
    	this.parametroGBOService = parametroGBOService;
    	this.evolucaoAtendimentoService = evolucaoAtendimentoService;
    }
    
    @Override
    public void run(){
        try {
            Thread.sleep(Integer.valueOf(61000));
        } catch (InterruptedException ex) {
            Logger.getLogger(ThreadEvolucaoAtendimentoCaso.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        LOGGER.info("ThreadEvolucaoAtendimentoCaso iniciada");
        
        Integer valor=null;
        
        ThreadEvolucaoAtendimentoCaso.executa = Boolean.TRUE;
        
        while(executa) {
            try {
                if (parametroGBOService.contabilizaDataAtual()) {
                    try {
                        evolucaoAtendimentoService.geraEvolucaoAtendimento();
                    } catch (ServiceException ex) {
                        Logger.getLogger(ThreadEvolucaoAtendimentoCaso.class.getName()).log(Level.SEVERE, null, ex);
                    }

                    ParametroGBO parametroGBO=null;
                    try {
                        parametroGBO = parametroGBOService.findByParam(Constantes.TEMPO_SCHEDULE_EVOLUCAO_CASO);
                        valor = Integer.valueOf(parametroGBO.getValor()) * 1000;
                    } catch (Exception ex) {
                        valor = null;
                        Logger.getLogger(ThreadEvolucaoAtendimentoCaso.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                
            } catch (Exception ex) {
                Logger.getLogger(ThreadEvolucaoAtendimentoCaso.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            try {
                if (valor == null || valor.equals(0)) {
                    valor = 120000;
                }
                
                Thread.sleep(valor);
            } catch (InterruptedException ex) {
                Logger.getLogger(ThreadEvolucaoAtendimentoCaso.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        LOGGER.info("ThreadEvolucaoAtendimentoCaso finalizada");
    }

    public static boolean isExecuta() {
        return executa;
    }

    public static void setExecuta(boolean executa) {
        ThreadEvolucaoAtendimentoCaso.executa = executa;
    }    
}
