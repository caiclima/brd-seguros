/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.sau.task;

import br.com.callink.cad.sau.task.exception.TaskException;

/**
 *
 * @author luiz gustavo faria
 */
public interface ITask {
    void doTask() throws TaskException;
}
