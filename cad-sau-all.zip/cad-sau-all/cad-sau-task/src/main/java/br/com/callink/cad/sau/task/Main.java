/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.sau.task;

import br.com.callink.cad.sau.task.exception.TaskException;
import br.com.callink.coreutils.infra.util.BeanFactory;

/**
 *
 * @author luiz gustavo faria
 */
public final class Main {

	private Main(){}
	
    public static void main(String[] args) {
        try {
            if (args.length < 1) {
                throw new TaskException("Erro: Nenhum parametro foi passado!");
            }
            
            for (int i = 0; i < args.length; i++) {
                ITask task = (ITask) BeanFactory.getInstance().getBean(args[i]);
                task.doTask();
            }
            
        } catch (Exception e) {
            e.getMessage();
        }
        System.exit(0);
    }
}
