/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.sau.task.exception;

/**
 *
 * @author Luiz Gustavo F. (luizgf@swb.com.br)
 */
public class TaskException extends Exception {

    public TaskException(Throwable thrwbl) {
        super(thrwbl);
    }

    public TaskException(String string, Throwable thrwbl) {
        super(string, thrwbl);
    }

    public TaskException(String string) {
        super(string);
    }

    public TaskException() {
    }
    
}
