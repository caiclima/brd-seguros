/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.sau.task.impl;

import java.util.Properties;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.ejb.Schedule;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import br.com.callink.cad.engine.email.IEnvioEmailEngine;
import br.com.callink.cad.sau.task.ITask;
import br.com.callink.cad.sau.task.exception.TaskException;
import br.com.callink.cad.service.IEmailService;

/**
 * @author Ednaldo Caic [ednaldo.lima@callink.com.br]
 */
@Startup
@Singleton
public class EnviaEmailTask implements ITask {

	private static final Logger LOGGER = Logger.getLogger(EnviaEmailTask.class.getName());
	
	@EJB
	private IEnvioEmailEngine envioEmailEngine;
	
	@EJB
    private IEmailService emailService;
	
	private Properties properties;
	
	@Override
    @Schedule(minute = "*/5", hour = "*", info = "Task enviaEmailTask de 5 min")
    public void doTask() throws TaskException {
		LOGGER.info("EnviaEmailTask iniciada");
		
		if(properties==null){
			properties = emailService.enviaEmailProperties();
		}
		envioEmailEngine.run(properties);
		
		LOGGER.info("EnviaEmailTask finalizada");
    }
}
