/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.sau.task.impl;

import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.ejb.Schedule;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import br.com.callink.cad.sau.qlikview.service.IQlikViewEnqueteService;
import br.com.callink.cad.sau.task.ITask;
import br.com.callink.cad.sau.task.exception.TaskException;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 *
 * @author ubuntu
 */
@Startup
@Singleton
public class QlikViewEnqueteTask implements ITask {

	private static final Logger LOGGER = Logger.getLogger(QlikViewEnqueteTask.class.getName());
	
	@EJB
	private IQlikViewEnqueteService qlikView;
	
    @Override
    @Schedule(minute = "*/60", hour = "*", info = "Task QlikViewEnqueteTask de 30 min")
    public void doTask() throws TaskException {
    	LOGGER.info("QlikViewEnqueteTask iniciada");
    	
        try {
            qlikView.geraNuvemPeloParametro();
        } catch (ValidationException ex) {
            throw new TaskException("Erro ao executar task QlikViewEnqueteTask", ex);
        }catch (ServiceException ex) {
            throw new TaskException("Erro ao executar task QlikViewEnqueteTask", ex);
        }
        
        LOGGER.info("QlikViewEnqueteTask finalizada");
    }
}
