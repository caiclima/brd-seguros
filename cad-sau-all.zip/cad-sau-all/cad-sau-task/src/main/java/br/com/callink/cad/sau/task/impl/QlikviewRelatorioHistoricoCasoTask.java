/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.sau.task.impl;

import java.util.Date;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import javax.ejb.AccessTimeout;
import javax.ejb.EJB;
import javax.ejb.Schedule;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.jboss.ejb3.annotation.TransactionTimeout;

import br.com.callink.cad.sau.qlikview.service.IRelatorioHistoricoCasoService;
import br.com.callink.cad.sau.task.ITask;
import br.com.callink.cad.sau.task.exception.TaskException;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 *
 * @author luiz gustavo faria
 */
@Startup
@Singleton
@AccessTimeout(-1)
@TransactionManagement(TransactionManagementType.BEAN)
public class QlikviewRelatorioHistoricoCasoTask implements ITask {

	private static final Logger LOGGER = Logger.getLogger(QlikviewRelatorioHistoricoCasoTask.class.getName());
	
	@EJB
	private IRelatorioHistoricoCasoService relatorioService;
	
    @Override
    @Schedule(minute = "*/60", hour = "*", info = "Task QlikviewRelatorioHistoricoCasoTask de 60 min")
    @TransactionTimeout(unit=TimeUnit.HOURS, value=6)
    public void doTask() throws TaskException {
    	LOGGER.info("QlikviewRelatorioHistoricoCasoTask iniciada");
    	
        try {
        	relatorioService.gerarHistoricos(relatorioService.getDataUltimoRelatorio(), new Date());
        }catch (ValidationException e) {
            throw new TaskException("Erro ao executar task QlikviewRelatorioHistoricoCaso", e);
        }catch (ServiceException ex) {
            throw new TaskException("Erro ao executar task QlikviewRelatorioHistoricoCaso", ex);
        }
        
        LOGGER.info("QlikviewRelatorioHistoricoCasoTask finalizada");
    }
}
