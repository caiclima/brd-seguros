/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.sau.task.impl;

import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.ejb.Schedule;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import br.com.callink.cad.sau.task.ITask;
import br.com.callink.cad.sau.task.exception.TaskException;
import br.com.callink.cad.service.IRelatorioTempoOperacionalService;

/**
 *
 * @author luiz gustavo faria
 */
@Startup
@Singleton
public class QlikviewRelatorioTempoOperacionalTask implements ITask {

	private static final Logger LOGGER = Logger.getLogger(QlikviewRelatorioTempoOperacionalTask.class.getName());
	
	@EJB
	private IRelatorioTempoOperacionalService relatorioTempoOperacionalService;
	
    @Override
    @Schedule(minute = "30", hour = "01", info = "Task QlikviewRelatorioTempoOperacionalTask 1h da manha")
    public void doTask() throws TaskException {
    	LOGGER.info("QlikviewRelatorioTempoOperacionalTask iniciada");
    	
        try {
            relatorioTempoOperacionalService.geraRelatorioParametroTempoOperacional();
        } catch (Exception ex) {
            throw new TaskException("Erro ao executar task QlikviewRelatorioWorkflowCaso", ex);
        }
        
        LOGGER.info("QlikviewRelatorioTempoOperacionalTask finalizada");
    }
}
