/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.sau.task.impl;

import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import javax.ejb.AccessTimeout;
import javax.ejb.EJB;
import javax.ejb.Schedule;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.jboss.ejb3.annotation.TransactionTimeout;

import br.com.callink.cad.sau.qlikview.service.IRelatorioUltimaTratativaCasoService;
import br.com.callink.cad.sau.task.ITask;
import br.com.callink.cad.sau.task.exception.TaskException;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 *
 * @author Ednaldo Caic [ednaldo@swb.com.br]
 */
@Startup
@Singleton
@AccessTimeout(-1)
@TransactionManagement(TransactionManagementType.BEAN)
public class QlikviewRelatorioUltimaTratativaCasoTask implements ITask {

	private static final Logger LOGGER = Logger.getLogger(QlikviewRelatorioUltimaTratativaCasoTask.class.getName());
	
	@EJB
	private IRelatorioUltimaTratativaCasoService relatorioService;
	
    @Override
    @Schedule(minute = "*/60", hour = "*", info = "Task QlikviewRelatorioUltimaTratativaCasoTask de 30 min")
    @TransactionTimeout(unit=TimeUnit.HOURS, value=6)
    public void doTask() throws TaskException {
    	LOGGER.info("QlikviewRelatorioUltimaTratativaCasoTask iniciada");
    	
        try {
            relatorioService.gerarHistoricos(relatorioService.getDataUltimoRelatorio());
        }catch (ValidationException ex) {
            throw new TaskException("Erro ao executar task QlikviewRelatorioUltimaTratativaCaso", ex);
        }catch (ServiceException ex) {
            throw new TaskException("Erro ao executar task QlikviewRelatorioUltimaTratativaCaso", ex);
        }
        
        LOGGER.info("QlikviewRelatorioUltimaTratativaCasoTask finalizada");
    }
}
