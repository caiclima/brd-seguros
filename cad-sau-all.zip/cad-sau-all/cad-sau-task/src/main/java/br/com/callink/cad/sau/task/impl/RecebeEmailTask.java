/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.sau.task.impl;

import java.util.Properties;
import java.util.logging.Logger;

import javax.ejb.EJB;
import javax.ejb.Schedule;
import javax.ejb.Singleton;
import javax.ejb.Startup;

import br.com.callink.cad.engine.email.IRecebeEmailEngine;
import br.com.callink.cad.sau.task.ITask;
import br.com.callink.cad.sau.task.exception.TaskException;
import br.com.callink.cad.service.IEmailService;
import br.com.callink.cad.util.Constantes;

/**
 *
 * @author Ednaldo Caic [ednaldo.lima@callink.com.br]
 */
@Startup
@Singleton
public class RecebeEmailTask implements ITask {

	private static final Logger LOGGER = Logger.getLogger(RecebeEmailTask.class.getName());
	
	@EJB
	private IRecebeEmailEngine recebeEmailEngine;
	
	@EJB
	private IEmailService emailService;
	
	private Properties properties;
	
	@Override
    @Schedule(minute = "*/4", hour = "*", info = "Task RecebeEmailTask de 5 min")
    public void doTask() throws TaskException {
		
		if(properties==null){
			properties = emailService.recebeEmailProperties();
		}
		
		String executa = properties.getProperty(Constantes.PARAMETRO_RECEBIMENTO_EMAIL);
		
		if("1".equals(executa)){
			LOGGER.info("RecebeEmailTask iniciada");
			recebeEmailEngine.run(properties);
			LOGGER.info("RecebeEmailTask finalizada");
		}
        
    }
}
