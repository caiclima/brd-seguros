package br.com.callink.cad.sau.enumeration;

public enum TipoAssocicaoCasoAtendente {
	
	OK_NENHUM_OUTRO_ATENDENTE(1),
	SENHA_OUTRO_ATENDENTE_NAO_ATENDIMENTO(2),
	BLOQUEIO_OUTRO_ATENDENTE_EM_ATENDIMENTO(3);
	
	
	private TipoAssocicaoCasoAtendente(Integer tipoAssocicaoCasoAtendente) {
		this.tipoAssocicaoCasoAtendente = tipoAssocicaoCasoAtendente;
	}

	private Integer tipoAssocicaoCasoAtendente;

	public Integer getTipoAssocicaoCasoAtendente() {
		return tipoAssocicaoCasoAtendente;
	}

	public void setTipoAssocicaoCasoAtendente(Integer tipoAssocicaoCasoAtendente) {
		this.tipoAssocicaoCasoAtendente = tipoAssocicaoCasoAtendente;
	}
	
	

}
