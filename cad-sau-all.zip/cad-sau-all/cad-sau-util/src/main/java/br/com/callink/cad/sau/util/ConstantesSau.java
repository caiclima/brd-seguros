/**
 * 
 */
package br.com.callink.cad.sau.util;

/**
 * @author José Araújo (joseap@swb.com.br)
 *
 */
public final class ConstantesSau {

	private ConstantesSau(){
		
	}
	
	public static final String VARIAVEL_VISUALIZA_BOTAO_META_UPH = "visualizarMetaUphAtendente";
	public static final String PARAM_SEMAFORO_ULTIMA_TRATATIVA = "semaforoUltimaTratativa";
	public static final String PARAM_SEMAFORO_HISTORICO_CASO = "semaforoHistoricoCaso";
	
	public static final String TRUE = "true";
	public static final String FALSE = "false";
	public static final String PARAM_SEMAFORO_ENQUETE = "semaforoEnquete";
}
