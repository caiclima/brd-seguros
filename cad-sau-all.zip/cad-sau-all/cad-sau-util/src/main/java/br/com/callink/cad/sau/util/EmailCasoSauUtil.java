/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.sau.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author Luiz Gustavo F. (luizgf@swb.com.br)
 */
public final class EmailCasoSauUtil {

    private static String sinalMenor = "<";
    private static String sinalMaior = ">";
    private static String traco = "-";
    private static String urgente = "URGENTE";
    private static String espaco = " ";
    private static String textoFixo = "Importante: n&atilde;o alterar nenhuma informa&ccedil;&atilde;o no t&iacute;tulo/subject desse e-mail. <br /><br />";
    private static String dadosManifestacao = "<br />Dados da manifesta&ccedil;&atilde;o: <br />";
    private static String quebraLinha = "<br />";
    private static String protocolo = "Protocolo: ";
    private static String tel = "Tel.: ";
    private static String fechaDiv = "</div>";

    private EmailCasoSauUtil() {

    }
    
    public static String getAssuntoEmail(String manifestacao, String tipoManifestacao, String assunto) {
        StringBuilder retorno = new StringBuilder();
        retorno.append(sinalMenor).append(manifestacao).append(sinalMaior).append(espaco).append(tipoManifestacao).append(espaco).append(traco).append(espaco).append(assunto).append(espaco).append(traco).append(espaco).append(urgente);
        return retorno.toString();
    }

    public static String getCorpoEmail(String conteudo, String manifestacao, Date dataAbertura, String assunto, String evento) {
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        StringBuilder retorno = new StringBuilder();
        retorno.append(textoFixo).append(conteudo).append(dadosManifestacao).append(protocolo).append(manifestacao).append(quebraLinha).append(dataAbertura).append(dateFormat.format(dataAbertura)).append(quebraLinha).append(assunto).append(assunto).append(quebraLinha).append(evento).append(evento).append(quebraLinha);
        return retorno.toString();
    }

    public static String getAssinatura(String nome, String telefone, String ramal, String fax, String assinatura) {
        StringBuilder retorno = new StringBuilder();
        retorno.append(quebraLinha).append(assinatura).append(nome).append(quebraLinha);        
        if (telefone != null && !telefone.isEmpty()) {
            retorno.append(tel).append(telefone).append(espaco);
        }
        if (ramal != null && !ramal.isEmpty()) {
            retorno.append(ramal).append(ramal).append(espaco);
        }
        if (fax != null && !fax.isEmpty()) {
            retorno.append(fax).append(fax);
        }
        retorno.append(fechaDiv);
        return retorno.toString();
    }
}
