/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.sau.admin.web.backbean;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import br.com.callink.cad.backbean.AbstractAtendenteStatusLogadoBB;
import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.AtendenteStatus;
import br.com.callink.cad.sau.admin.web.backbean.caso.AtendenteCasoBB;
import br.com.callink.cad.service.IAtendenteService;
import br.com.callink.cad.service.IAtendenteStatusService;
import br.com.callink.cad.service.IStatusAtendenteService;
import br.com.callink.cad.service.exception.ServiceException;

/**
 *
 * @author brunomt
 */
@ManagedBean
@SessionScoped
public class AtendenteStatusLogadoBB extends AbstractAtendenteStatusLogadoBB<AtendenteStatus, IAtendenteStatusService> {
    
	private static final long serialVersionUID = -711474326324019481L;
	@EJB
	private IAtendenteService atendenteService;
	@EJB
	private IStatusAtendenteService statusAtendenteService;
	@EJB
	private IAtendenteStatusService atendenteStatusService;
	
    @Override
    public void retornarAtendimento() {
        try {
            Atendente atendente = atendenteService.findByLogin(getUserInfo().getUserLogin());
            AtendenteCasoBB atendenteCasoBB = (AtendenteCasoBB) getSessionMap().get("atendenteCasoBB");
            if (atendente != null && atendente.getIdAtendente() != null) {
            	statusAtendenteService.salvaStatusAtendimentoDisponivel(atendente);
                if (atendenteCasoBB != null) {
                    atendenteCasoBB.atualizaLista();
                }
                setAtendenteStatusSelecionado(new AtendenteStatus());
                setMostraModal(0);
                setPausado(0);
            }
        } catch (Exception ex) {
            error(ex);
        }
    }

    @Override
    public void verificaAtendenteCaso() throws ServiceException {
        AtendenteCasoBB atendenteCasoBB = (AtendenteCasoBB) getSessionMap().get("atendenteCasoBB");
        if (atendenteCasoBB != null && atendenteCasoBB.getCasoSau() != null && atendenteCasoBB.getCasoSau().getIdCasoSau() != null) {
            throw new ServiceException("Você possui um caso em atendimento. Favor dar andamento no mesmo.");
        }
    }

	@Override
	public void novo() {
		setPojo(new AtendenteStatus());
	}

	@Override
	protected IAtendenteStatusService getService() {
		return atendenteStatusService;
	}
    
}
