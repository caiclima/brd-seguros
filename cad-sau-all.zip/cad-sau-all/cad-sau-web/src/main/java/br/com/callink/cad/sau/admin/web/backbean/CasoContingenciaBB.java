package br.com.callink.cad.sau.admin.web.backbean;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.model.SelectItem;

import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.sau.pojo.Assunto;
import br.com.callink.cad.sau.pojo.Canal;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.pojo.Estado;
import br.com.callink.cad.sau.pojo.Evento;
import br.com.callink.cad.sau.pojo.TipoManifestacao;
import br.com.callink.cad.sau.service.IAssuntoService;
import br.com.callink.cad.sau.service.ICanalService;
import br.com.callink.cad.sau.service.ICasoSauService;
import br.com.callink.cad.sau.service.IEstadoService;
import br.com.callink.cad.sau.service.IEventoService;
import br.com.callink.cad.sau.service.ITipoManifestacaoService;
import br.com.callink.cad.service.IAcaoService;
import br.com.callink.cad.service.IAtendenteService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.util.JSFUtil;

/**
 *
 * @author Rogerio Moreira
 * @since 21/04/2013
 */
@ManagedBean
@ViewScoped
public class CasoContingenciaBB extends CadSauAdminGenericCrud<CasoSau, ICasoSauService> {

    private static final long serialVersionUID = 1L;
    private List<TipoManifestacao> tipoManifestacaoList;
    private List<Canal> canalList;
    private List<Assunto> assuntoList;
    private List<Estado> estadoList;
    private Assunto assunto;
    private List<Evento> eventoList;
    @EJB
    private ITipoManifestacaoService tipoManifestacaoService;
    @EJB
    private ICanalService canalService;
    @EJB
    private IAssuntoService assuntoService;
    @EJB
    private IEstadoService estadoService;
    @EJB
    private IAtendenteService atendenteService;
    @EJB
    private ICasoSauService casoSauService;
    @EJB
    private IAcaoService acaoService;
    @EJB
    private IEventoService eventoService;
   
    @PostConstruct
    public void init() {
        
        try {
            novo();
            tipoManifestacaoList = tipoManifestacaoService.findAtivos("TipoManifestacao.NOME");
            canalList = canalService.findAtivos("Canal.NOME");
            assuntoList = assuntoService.findAtivos("Assunto.NOME");
            estadoList = estadoService.findAtivos("Estado.NOME");
        } catch (ServiceException ex) {
            error(ex);
        }
    }
    
    @Override
	public void novo() {
    	assunto = new Assunto();
		setPojo(new CasoSau());
	}
    

    @Override
    public String salvar() {
        try {
            if (!atendenteService.findByLogin(getUserInfo().getUserLogin()).getFlagAtivo()) {
                error("Sua conta está inativada.");
                return null;
            }
        } catch (ServiceException e) {
            error(e);
            return null;
        }

        try {

            getPojo().setAssunto(assunto == null ? null : assunto.getNome());
            getService().save(getPojo(), getAtendente());

            if (getPojo() != null && getPojo().getPK() != null) {
                info("Registro salvo com sucesso. Manifesta\u00E7\u00E3o: " + getPojo().getManifestacao());
               novo();
            }
        }catch (ValidationException ex) {
            error(ex.getMessage());
        }catch (ServiceException ex) {
            error(ex);
        }
        return null;
    }

    public void alteraValorPojo(CasoSau caso) {
        super.setPojo(caso);
    }

    public void excluir(Acao acao) {
        try {
        	acaoService.delete(acao);
            filtrar();

        }catch (ValidationException ex) {
            error(ex.getMessage());
        }catch (ServiceException ex) {
            error(ex);
        }
    }

    public void filtrarCombos() {
        try {
            eventoList = eventoService.findByAssunto(assunto);
        } catch (ServiceException ex) {
            error(ex);
        }
    }

    private Atendente getAtendente() throws ServiceException {
        return atendenteService.findByLogin(getUserInfo().getUserLogin());
    }

    public final List<SelectItem> getTipoManifestacaoList() {
        return JSFUtil.toSelectItemConsulta(tipoManifestacaoList);
    }

    public final void setTipoManifestacaoList(List<TipoManifestacao> tipoManifestacaoList) {
        this.tipoManifestacaoList = tipoManifestacaoList;
    }

    public final List<SelectItem> getCanalList() {
        return JSFUtil.toSelectItemConsulta(canalList);
    }

    public final void setCanalList(List<Canal> canalList) {
        this.canalList = canalList;
    }

    public final List<SelectItem> getAssuntoList() {
        return JSFUtil.toSelectItemConsulta(assuntoList);
    }

    public final void setAssuntoList(List<Assunto> assuntoList) {
        this.assuntoList = assuntoList;
    }

    public final List<SelectItem> getEventoList() {
        return JSFUtil.toSelectItemConsulta(eventoList);
    }

    public void setEstadoList(List<Estado> estadoList) {
        this.estadoList = estadoList;
    }

    public List<SelectItem> getEstadoList() {
        return JSFUtil.toSelectItemConsulta(estadoList);
    }

    public final void setEventoList(List<Evento> eventoList) {
        this.eventoList = eventoList;
    }

    public Assunto getAssunto() {
        return assunto;
    }

    public void setAssunto(Assunto assunto) {
        this.assunto = assunto;
    }

	@Override
	protected ICasoSauService getService() {
		return casoSauService;
	}

}
