package br.com.callink.cad.sau.admin.web.backbean;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.model.SelectItem;

import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.sau.pojo.Assunto;
import br.com.callink.cad.sau.pojo.Canal;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.pojo.Evento;
import br.com.callink.cad.sau.pojo.TipoManifestacao;
import br.com.callink.cad.sau.service.IAssuntoService;
import br.com.callink.cad.sau.service.ICanalService;
import br.com.callink.cad.sau.service.ICasoSauService;
import br.com.callink.cad.sau.service.IEventoService;
import br.com.callink.cad.sau.service.ITipoManifestacaoService;
import br.com.callink.cad.service.IAcaoService;
import br.com.callink.cad.service.IAtendenteService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.util.JSFUtil;

/**
 * 
 * @author Ednaldo Caic [ednaldo@swb.com.br]
 * @since 14/01/2012
 */
@ManagedBean
@ViewScoped
public class CasoManualBB extends CadSauAdminGenericCrud<CasoSau,ICasoSauService> {

    private static final long serialVersionUID = 1L;
    private List<TipoManifestacao> tipoManifestacaoList;
    private List<Canal> canalList;
    private List<Assunto> assuntoList;
    private Assunto assunto;
    private List<Evento> eventoList;
    
    @EJB
    private ICasoSauService casoSauService;
    @EJB
    private ITipoManifestacaoService tipoManifestacaoService;
    @EJB
    private ICanalService canalService;
    @EJB
    private IAssuntoService assuntoService;
    @EJB
    private IAtendenteService atendenteService;
    @EJB
    private IEventoService eventoService;
    @EJB
    private IAcaoService acaoService;

    @PostConstruct
    public void init() {
        try {
            tipoManifestacaoList = tipoManifestacaoService.findAtivos("TipoManifestacao.NOME");
            canalList = canalService.buscaCanalCadastroManualCaso();
            assuntoList = assuntoService.findAtivos("Assunto.NOME");
            
            setPojo(new CasoSau());
        } catch (ServiceException ex) {
            error(ex);
        }
    }

    @Override
    public String salvar() {
        try {
            if (!atendenteService.findByLogin(getUserInfo().getUserLogin()).getFlagAtivo()) {
                error("Sua conta está inativada.");
                return null;
            }
        } catch (ServiceException e) {
            error(e);
            return null;
        }

        if (validaDados()) {
	        try {
	
	            getPojo().setAssunto(assunto == null ? null : assunto.getNome());
	            getPojo().setFlagManual(Boolean.TRUE);
	            getService().save(getPojo(),getAtendente());
	            
	            if (getPojo() != null && getPojo().getPK() != null) {
	                info("Registro salvo com sucesso. Manifesta\u00E7\u00E3o: " + getPojo().getManifestacao());
	                novo();
	            }
	        }catch (ValidationException ex) {
	            error(ex.getMessage());
	        } 
	        catch (ServiceException ex) {
	            error(ex);
	        }
        }
        return null;
    }

    private boolean validaDados() {
    	Boolean valida = true;
    	
    	if (getPojo().getDataAbertura() == null) {
	    	error("Informar a data de abertura.");
	    	valida = Boolean.FALSE;
    	}
		
		return valida;
	}

	public void alteraValorPojo(CasoSau caso) {
        super.setPojo(caso);
    }
    
    public void excluir(Acao acao) {
        try {
        	acaoService.delete(acao);
            filtrar();

        } catch (ValidationException ex) {
            error(ex.getMessage());
        } catch (ServiceException ex) {
            error(ex);
        }
    }

    public void filtrarCombos() {
        try {
            eventoList = eventoService.findByAssunto(assunto);
        } catch (ServiceException ex) {
            error(ex);
        }
    }
    
    private Atendente getAtendente() throws ServiceException {
        return atendenteService.findByLogin(getUserInfo().getUserLogin());
    }

    public final List<SelectItem> getTipoManifestacaoList() {
        return JSFUtil.toSelectItemConsulta(tipoManifestacaoList);
    }

    public final void setTipoManifestacaoList(List<TipoManifestacao> tipoManifestacaoList) {
        this.tipoManifestacaoList = tipoManifestacaoList;
    }

    public final List<SelectItem> getCanalList() {
        return JSFUtil.toSelectItemConsulta(canalList);
    }

    public final void setCanalList(List<Canal> canalList) {
        this.canalList = canalList;
    }

    public final List<SelectItem> getAssuntoList() {
        return JSFUtil.toSelectItemConsulta(assuntoList);
    }

    public final void setAssuntoList(List<Assunto> assuntoList) {
        this.assuntoList = assuntoList;
    }

    public final List<SelectItem> getEventoList() {
        return JSFUtil.toSelectItemConsulta(eventoList);
    }

    public final void setEventoList(List<Evento> eventoList) {
        this.eventoList = eventoList;
    }

    public Assunto getAssunto() {
        return assunto;
    }

    public void setAssunto(Assunto assunto) {
        this.assunto = assunto;
    }

	@Override
	protected ICasoSauService getService() {
		return casoSauService;
	}

	@Override
	public void novo() {
		setPojo(new CasoSau());
		setAssunto(new Assunto());
	}
}
