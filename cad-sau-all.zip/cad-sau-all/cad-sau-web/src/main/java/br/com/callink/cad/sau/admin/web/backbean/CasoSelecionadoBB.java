/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.sau.admin.web.backbean;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.Email;
import br.com.callink.cad.pojo.Log;
import br.com.callink.cad.pojo.LogLigacoes;
import br.com.callink.cad.pojo.ReaberturaCaso;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.pojo.Resposta;
import br.com.callink.cad.sau.pojo.ResultadoQuestionario;
import br.com.callink.cad.sau.service.ICasoSauService;
import br.com.callink.cad.sau.service.IRespostaService;
import br.com.callink.cad.sau.service.IResultadoQuestionarioService;
import br.com.callink.cad.service.ILogLigacoesService;
import br.com.callink.cad.service.ILogService;
import br.com.callink.cad.service.IReaberturaCasoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;

/**
 *
 * @author Luiz Gustavo (luizgf@swb.com.br)
 */
@ManagedBean
@ViewScoped
public class CasoSelecionadoBB extends CadSauAdminGenericCrud<CasoSau, ICasoSauService> {

	private static final long serialVersionUID = 3258923304761535429L;
	
	private List<Log> historicoCaso;
    private CasoSau casoSau;
    private Boolean temQuestionario;
    private List<Object[]> listQuestionario;
    private Integer idResultadoQuestionarioSelecionado;
    private List<Resposta> listaRespostas;
    private List<Log> logEmails;
    private Email emailSelecionado;
    private List<LogLigacoes> logLigacoesList;

    @EJB
    private ICasoSauService casoSauService;
    @EJB
    private IReaberturaCasoService reaberturaCasoService;
    @EJB
    private ILogService logService;
    @EJB
    private ILogLigacoesService logLigacoesService;
    @EJB
    private IResultadoQuestionarioService resultadoQuestionarioService;
    @EJB
    private IRespostaService respostaService;
    
    public CasoSelecionadoBB() {
        super();
        historicoCaso = new ArrayList<Log>();
        casoSau = new CasoSau();
        logEmails = new ArrayList<Log>();
        emailSelecionado = new Email();
    }

	@Override
	public void novo() {
		setPojo(new CasoSau());
		historicoCaso = new ArrayList<Log>();
		casoSau = new CasoSau();
		logEmails = new ArrayList<Log>();
		emailSelecionado = new Email();
	}
    
    public void clean() {
        getSessionMap().put("casoSelecionado", new CasoSau());
        casoSau = new CasoSau();
        historicoCaso = new ArrayList<Log>();
        emailSelecionado = new Email();
        if (listQuestionario != null) {
            listQuestionario.clear();
        }
        if (listaRespostas != null) {
            listaRespostas.clear();
        }
        if (logEmails != null) {
            logEmails.clear();
        }
    }
    
    public void visualizaCasoSauByCaso(Caso caso){
        try {
            setCasoSau(getService().findCasoSauByCaso(caso));
            getCasoSau().setCaso(caso);
            
        } catch (ServiceException ex) {
            error("Erro ao carregar caso.");
        }
    }

    public void atualiza() {
        CasoSau caso = (CasoSau) getSessionMap().get("casoSelecionado");
        if (caso != null && caso.getPK() != null) {
            casoSau = caso;
            atualizaHistorico();
            atualizaEmails();
            verificaRechamado();
            carregaQuestionarios();
        }
    }

    public boolean verificaRechamado() {
        try {
            List<ReaberturaCaso> reaberturaList = reaberturaCasoService.findByCaso(casoSau.getCaso());
            if (reaberturaList == null || reaberturaList.isEmpty()) {
                casoSau.setFlagRechamado(Boolean.FALSE);
            } else {
                casoSau.setFlagRechamado(Boolean.TRUE);
            }
        } catch (ServiceException ex) {
            error(ex);
        }
        return false;
    }

    public void atualizaHistorico() {
        try {
            historicoCaso = logService.findHistorico(casoSau.getCaso());
        } catch (ServiceException ex) {
            error(ex);
        }
    }
    
    public void atualizaHistoricoLigacoes() {
    	try {
            if (getPojo() != null) {
                this.setLogLigacoesList(logLigacoesService.findByFilters(casoSau.getManifestacao(), null, null, null, null));
            }
        }catch (ValidationException ex) {
            error(ex.getMessage());
        }catch (ServiceException ex) {
            error(ex);
        }
    }
    
    public void atualizaEmails() {
        try {
            logEmails = logService.findHistoricoEmail(casoSau.getCaso());
        } catch (ServiceException ex) {
            error(ex);
        }
    }

    public List<Log> getHistoricoCaso() {
        if (casoSau.getPK() == null) {
            atualiza();
        }
        return historicoCaso;
    }

    public void setHistoricoCaso(List<Log> historicoCaso) {
        this.historicoCaso = historicoCaso;
    }

    public CasoSau getCasoSau() {
        if (casoSau.getPK() == null) {
            atualiza();
        }
        return casoSau;
    }
    
    public void setCasoSau(CasoSau casoSau) {
        this.casoSau = casoSau;
    }
    
    

    public void carregaQuestionarios() {
        try {
            listQuestionario = resultadoQuestionarioService.questionariosRespondidos(casoSau.getIdCasoSau());
            if (listQuestionario != null && listQuestionario.size() > 0) {
                temQuestionario = true;
            } else {
                temQuestionario = false;
            }
        } catch (ServiceException ex) {
            error(ex);
        }
    }

    public void carregaRespostas(Integer idResultadoQuestionario) {
        try {
            this.listaRespostas = respostaService.respostasByResultadoQuestionario(new ResultadoQuestionario(idResultadoQuestionario));
            for(Resposta resposta:listaRespostas){
                resposta.getQuestao().setRendered(Boolean.TRUE);
            }
        } catch (ServiceException ex) {
            error(ex);
        }
    }

    public Integer getIdResultadoQuestionarioSelecionado() {
        return idResultadoQuestionarioSelecionado;
    }

    public void setIdResultadoQuestionarioSelecionado(Integer idResultadoQuestionarioSelecionado) {
        this.idResultadoQuestionarioSelecionado = idResultadoQuestionarioSelecionado;
    }

    public List<Object[]> getListQuestionario() {
        return listQuestionario;
    }

    public void setListQuestionario(List<Object[]> listQuestionario) {
        this.listQuestionario = listQuestionario;
    }

    public List<Resposta> getListaRespostas() {
        return listaRespostas;
    }

    public void setListaRespostas(List<Resposta> listaRespostas) {
        this.listaRespostas = listaRespostas;
    }

    public Boolean getTemQuestionario() {
        return temQuestionario;
    }

    public void setTemQuestionario(Boolean temQuestionario) {
        this.temQuestionario = temQuestionario;
    }

    public List<Log> getLogEmails() {
        if (casoSau.getPK() == null) {
            atualiza();
        }
        return logEmails;
    }

    public void setLogEmails(List<Log> emails) {
        this.logEmails = emails;
    }
    
    public void visualizarEmail(Email email) {
        emailSelecionado = email;
        buscaAnexos(emailSelecionado.getGrupoAnexo().getIdGrupoAnexo());
    }
    
    public String getRemetenteOuDestinatario(Email email) {
        if (email.getFlagEnvio() == null) {
            return null;
        }
        return email.getFlagEnvio() ? //foi enviado pelo gbo? 
                email.getDestinatarioParaExibicao() == null ? //mostra destinatario p/ exibiçao se houver
                email.getDestinatario() : email.getDestinatarioParaExibicao() //senao mostra o campo destinatario
                : email.getRemetente(); //se foi recebido mostra remetente
    }

    public Email getEmailSelecionado() {
        return emailSelecionado;
    }

    public void setEmailSelecionado(Email emailSelecionado) {
        this.emailSelecionado = emailSelecionado;
        if (emailSelecionado.getGrupoAnexo() != null && emailSelecionado.getGrupoAnexo().getIdGrupoAnexo() != null) {
        	buscaAnexos(emailSelecionado.getGrupoAnexo().getIdGrupoAnexo());
        }
    }
    
    public String getDestinatarioSelecionado() {
        if (emailSelecionado == null) {
            return null;
        }
        return emailSelecionado.getDestinatarioParaExibicao() == null ?
                emailSelecionado.getDestinatario() : emailSelecionado.getDestinatarioParaExibicao();
    }

	public List<LogLigacoes> getLogLigacoesList() {
		return logLigacoesList;
	}

	public void setLogLigacoesList(List<LogLigacoes> logLigacoesList) {
		this.logLigacoesList = logLigacoesList;
	}

	@Override
	protected ICasoSauService getService() {
		return casoSauService;
	}

}
