package br.com.callink.cad.sau.admin.web.backbean;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.event.ActionEvent;

import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.pojo.Check;
import br.com.callink.cad.sau.pojo.Checklist;
import br.com.callink.cad.sau.pojo.RespostaChecklist;
import br.com.callink.cad.sau.pojo.ResultadoChecklist;
import br.com.callink.cad.sau.service.ICasoSauService;
import br.com.callink.cad.sau.service.IRespostaChecklistService;
import br.com.callink.cad.sau.service.IResultadoChecklistService;
import br.com.callink.coreutils.util.string.StringHelper;

@ManagedBean
@ViewScoped
public class RespostaChecklistBB extends CadSauAdminGenericCrud<RespostaChecklist, IRespostaChecklistService> {


	private static final long serialVersionUID = -5549735038427697380L;

	@EJB
	private IRespostaChecklistService respostaChecklistService;
	@EJB
	private IResultadoChecklistService resultadoChecklistService; 
	
	@EJB
	private ICasoSauService casoSauService;
	
	public RespostaChecklistBB() {
    
	}
    
	private Checklist checklist;
    private ResultadoChecklist resultadoChecklist;
    private List<RespostaChecklist> checklistNaoExibidas;
    private List<Integer> controle;
    private int tempId;

    public void initRespostaChecklist() {
    	
    	List<Check> questaoRemoveList = new ArrayList<Check>();
    	checklist = getAtendenteCasoBB().getChecklist();

        List<RespostaChecklist> resposta = new ArrayList<RespostaChecklist>();
        
        resultadoChecklist = new ResultadoChecklist();
        resultadoChecklist.setTipoAtendimento("CASO");
        resultadoChecklist.setIdExterno(getAtendenteCasoBB().getCasoSau().getIdCasoSau());
        resultadoChecklist.setLogin(getLoginUsuario());
        controle = new ArrayList<Integer>();
        tempId = 0;
        if (checklist != null) {
            for (Check check : checklist.getChecks()) {
            	if (check.getFlagEnabled()) {
                    RespostaChecklist resp = new RespostaChecklist(++tempId);
                    controle.add(tempId);
                    resp.setCheck(check);
                    resp.setResultadoChecklist(resultadoChecklist);
                    resp.setResposta(check.getRespostaPadrao());
                    resposta.add(resp);
            	} else {
            		questaoRemoveList.add(check);
            	}
            }
            
           checklist.getChecks().removeAll(questaoRemoveList);  
        }
        
        if (checklistNaoExibidas == null) {
        	checklistNaoExibidas = new ArrayList<RespostaChecklist>();
        } else {
        	checklistNaoExibidas.clear();
        }
        setPojos(resposta);
        validaFilhosChecklist();
    }
    
    public void validaFilhosChecklist() {
        if (checklistNaoExibidas == null) {
        	checklistNaoExibidas = new ArrayList<RespostaChecklist>();
        } else {
            getPojos().addAll(checklistNaoExibidas);
            checklistNaoExibidas.clear();
        }
        setPojos(getService().validaFilhos(getPojos()));
        for (RespostaChecklist resp : getPojos()) {
            if (!resp.getCheck().getRendered()) {
            	checklistNaoExibidas.add(resp);
            }
        }
        getPojos().removeAll(checklistNaoExibidas);
    }
    
    public void salvar(ActionEvent event) {
        if (validaRespostas(getPojos())) {
            try {
            	
            	CasoSau casoSau = casoSauService.findByPk(getAtendenteCasoBB().getCasoSau());
            	
            	if(!validaTodasRespondidas(getPojos())){
                	error("Responda todo checklist para finalizar!");
                	return ;
                }
            	
                for (RespostaChecklist resposta : getPojos()) {
                    if (controle.contains(resposta.getIdRespostaChecklist())) {
                        resposta.setIdRespostaChecklist(null);
                    }
                }
                
                this.resultadoChecklist.setRespostaList(getPojos());
                this.resultadoChecklist.setCasoSau(casoSau);
                
                if(getAtendenteCasoBB().getStatusAcaoSelecionado()!= null){
                	this.resultadoChecklist.setAcao(getAtendenteCasoBB().getStatusAcaoSelecionado().getStatusAcaoId().getIdAcao());
                }
                
                if(casoSau!= null){
                	this.resultadoChecklist.setEvento(casoSau.getEvento());
                }
                
                resultadoChecklistService.save(resultadoChecklist);
                
            } catch (Exception ex) {
                error(ex, true);
            }
        }
        
        getAtendenteCasoBB().setIconeChecklist(false);
    }

    private boolean validaRespostas(List<RespostaChecklist> respostas) {
        boolean valido = true;
        
        List<RespostaChecklist> newInstance = new ArrayList<RespostaChecklist>(respostas);
        for (RespostaChecklist resp : newInstance) {

            if (resp.getRespostas() != null && resp.getRespostas().size() > 0) {
                String resposta = resp.getRespostas().toString();
                resp.setResposta(resposta.replace("[", "").replace("]", "").replace(", ", ";"));
            }
        }
        return valido;
    }

    private boolean validaTodasRespondidas(List<RespostaChecklist> respostas) {
    	
    	for (RespostaChecklist resp : respostas) {
			
    		if(StringHelper.isEmpty(resp.getResposta())){
    			return false;
    		}
    		
		}
    	return true;
    }
    
    
	public Checklist getChecklist() {
		return checklist;
	}

	public void setChecklist(Checklist checklist) {
		this.checklist = checklist;
	}

	public ResultadoChecklist getResultadoChecklist() {
		return resultadoChecklist;
	}

	public void setResultadoChecklist(ResultadoChecklist resultadoChecklist) {
		this.resultadoChecklist = resultadoChecklist;
	}

	public List<Integer> getControle() {
		return controle;
	}

	public void setControle(List<Integer> controle) {
		this.controle = controle;
	}

	@Override
	protected IRespostaChecklistService getService() {
		return respostaChecklistService;
	}

	@Override
	public void novo() {
		setPojo(new RespostaChecklist());
	}
	
}
