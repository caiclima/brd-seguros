package br.com.callink.cad.sau.admin.web.backbean;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.sau.enun.TipoConteudoResposta;
import br.com.callink.cad.sau.pojo.Questao;
import br.com.callink.cad.sau.pojo.Questionario;
import br.com.callink.cad.sau.pojo.Resposta;
import br.com.callink.cad.sau.pojo.ResultadoQuestionario;
import br.com.callink.cad.sau.service.IRespostaService;
import br.com.callink.cad.sau.service.IResultadoQuestionarioService;

/**
 * 
 * @author Rogerio Moreira de Andrade [rogeriom@swb.com.br]
 * 
 */
@ManagedBean
@ViewScoped
public class RespostaQuestionarioBB extends CadSauAdminGenericCrud<Resposta, IRespostaService> {

    private static final long serialVersionUID = 1L;

    @EJB
    private IRespostaService respostaService;
    
    @EJB
    private IResultadoQuestionarioService resultadoQuestionarioService;
    
    private Questionario questionario;
    private ResultadoQuestionario resultadoQuestionario;
    private List<Resposta> questoesNaoExibidas;
    private List<Integer> controle;
    private int tempId;

    @Override
	public void novo() {
		setPojo(new Resposta());
	}
    
    public RespostaQuestionarioBB() {
    }
    
    public void initRespostaQuestionario() {
    	List<Questao> questaoRemoveList = new ArrayList<Questao>();
        if (this.resultadoQuestionario == null
                || this.resultadoQuestionario.getIdExterno() == null
                || !this.resultadoQuestionario.getIdExterno().equals(getAtendenteCasoBB().getCasoSau().getIdCasoSau())) {

            List<Resposta> resposta = new ArrayList<Resposta>();
            questionario = getAtendenteCasoBB().getQuestionario();
            resultadoQuestionario = new ResultadoQuestionario();
            resultadoQuestionario.setTipoAtendimento("CASO");
            resultadoQuestionario.setIdExterno(getAtendenteCasoBB().getCasoSau().getIdCasoSau());
            resultadoQuestionario.setLogin(getLoginUsuario());
            controle = new ArrayList<Integer>();
            tempId = 0;
            if (questionario != null) {
                for (Questao questao : questionario.getQuestaoList()) {
                	if (questao.getFlagAtivo()) {
	                    Resposta resp = new Resposta(++tempId);
	                    controle.add(tempId);
	                    resp.setQuestao(questao);
	                    resp.setResultadoQuestionario(resultadoQuestionario);
	                    resposta.add(resp);
                	} else {
                		questaoRemoveList.add(questao);
                	}
                }
                
                questionario.getQuestaoList().removeAll(questaoRemoveList);
            }
            
            if (questoesNaoExibidas == null) {
                questoesNaoExibidas = new ArrayList<Resposta>();
            } else {
                questoesNaoExibidas.clear();
            }
            setPojos(resposta);
            validaFilhosQuestionario();
        }
    }

    public void validaFilhosQuestionario() {
        if (questoesNaoExibidas == null) {
            questoesNaoExibidas = new ArrayList<Resposta>();
        } else {
            getPojos().addAll(questoesNaoExibidas);
            questoesNaoExibidas.clear();
        }
        setPojos(getService().validaFilhos(getPojos()));
        for (Resposta resp : getPojos()) {
            if (!resp.getQuestao().getRendered()) {
                questoesNaoExibidas.add(resp);
            }
        }
        getPojos().removeAll(questoesNaoExibidas);
    }

    @Override
    public String salvar() {
        if (validaRespostas(getPojos())) {
            try {
                for (Resposta resposta : getPojos()) {
                    if (controle.contains(resposta.getIdResposta())) {
                        resposta.setIdResposta(null);
                    }
                }
                this.resultadoQuestionario.setRespostaList(getPojos());
                resultadoQuestionarioService.save(resultadoQuestionario);
            } catch (Exception ex) {
                error(ex, true);
            }
        }
        return null;
    }

    private boolean validaRespostas(List<Resposta> respostas) {
        boolean valido = true;
        
        List<Resposta> newInstance = new ArrayList<Resposta>(respostas);
        
        for (Resposta resp : newInstance) {

            if (resp.getRespostas() != null && resp.getRespostas().size() > 0) {
                String resposta = resp.getRespostas().toString();
                resp.setResposta(resposta.replace("[", "").replace("]", "").replace(", ", ";"));
            }
            if (resp.getQuestao().getTipoConteudoResposta() == TipoConteudoResposta.DATA) {
                DateFormat df = DateFormat.getDateInstance();
                resp.setResposta(df.format(resp.getDataResposta()));
            }
            Questao qestao = resp.getQuestao();
            if (qestao.getRequerida() && StringUtils.isEmpty(resp.getResposta()) && qestao.getRendered()) {
                error(qestao.getMensagemRequerida());
                if (valido) {
                    valido = false;
                }
            }
        }
        return valido;
    }

    public Questionario getQuestionario() {
        return questionario;
    }

    public void setQuestionario(Questionario questionario) {
        this.questionario = questionario;
    }

    public ResultadoQuestionario getResultadoQuestionario() {
        return resultadoQuestionario;
    }

    public void setResultadoQuestionario(ResultadoQuestionario resultadoQuestionario) {
        this.resultadoQuestionario = resultadoQuestionario;
    }

	@Override
	protected IRespostaService getService() {
		return respostaService;
	}
	
}
