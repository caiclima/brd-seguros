/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.sau.admin.web.backbean.caso;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.model.SelectItem;

import br.com.callink.cad.backbean.AbstractAtendenteCasoBB;
import br.com.callink.cad.engine.buffer.fila.atendimento.ICasoAtendimento;
import br.com.callink.cad.pojo.Acao;
import br.com.callink.cad.pojo.AcaoTipoAcao;
import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.pojo.Caso;
import br.com.callink.cad.pojo.Email;
import br.com.callink.cad.pojo.Log;
import br.com.callink.cad.pojo.ReaberturaCaso;
import br.com.callink.cad.pojo.Status;
import br.com.callink.cad.pojo.StatusAcao;
import br.com.callink.cad.pojo.StatusAcaoId;
import br.com.callink.cad.pojo.StatusAtendente;
import br.com.callink.cad.pojo.TipoAcao;
import br.com.callink.cad.repository.MetasUphCache;
import br.com.callink.cad.repository.RelatorioStatusAtendente;
import br.com.callink.cad.repository.to.CabMetaTO;
import br.com.callink.cad.repository.to.MetaFilaTO;
import br.com.callink.cad.sau.admin.web.backbean.AtendenteStatusLogadoBB;
import br.com.callink.cad.sau.pojo.Canal;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.pojo.Causa;
import br.com.callink.cad.sau.pojo.Checklist;
import br.com.callink.cad.sau.pojo.ConteudoApoio;
import br.com.callink.cad.sau.pojo.Estado;
import br.com.callink.cad.sau.pojo.Evento;
import br.com.callink.cad.sau.pojo.Questionario;
import br.com.callink.cad.sau.pojo.TipoManifestacao;
import br.com.callink.cad.sau.service.IAssociaChecklistService;
import br.com.callink.cad.sau.service.IAssociaConteudoApoioService;
import br.com.callink.cad.sau.service.IAssociaQuestionarioService;
import br.com.callink.cad.sau.service.IAssuntoService;
import br.com.callink.cad.sau.service.ICasoSauService;
import br.com.callink.cad.sau.service.IEventoService;
import br.com.callink.cad.sau.util.ConstantesSau;
import br.com.callink.cad.service.IAtendenteService;
import br.com.callink.cad.service.ICasoService;
import br.com.callink.cad.service.IParametroGBOService;
import br.com.callink.cad.service.IReaberturaCasoService;
import br.com.callink.cad.service.IStatusAtendenteService;
import br.com.callink.cad.service.IStatusService;
import br.com.callink.cad.service.ITempoAtendimentoCasoService;
import br.com.callink.cad.service.ITipoAcaoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.service.repository.ControleStatusAtendentes;
import br.com.callink.cad.util.Constantes;
import br.com.callink.cad.util.CpfCnpj;
import br.com.callink.cad.util.DateUtils;
import br.com.callink.cad.util.JSFUtil;

/**
 * 
 * @author Rogério Moreira de Andrade rogeriom@swb.com.br
 */
@ManagedBean
@SessionScoped
public class AtendenteCasoBB extends AbstractAtendenteCasoBB<Caso, ICasoService> {

    private static final long serialVersionUID = 87232835881583807L;

    @EJB
    private ICasoService casoService;
    
    private CasoSau casoSau;
    @EJB
    private ICasoSauService casoSauService;
    @EJB
    private IEventoService eventoService;
    @EJB
    private IAssuntoService assuntoService;
    @EJB
    private IAssociaQuestionarioService associaQuestionarioService;
    @EJB
    private IAssociaChecklistService associaChecklistService;
    @EJB
    private IReaberturaCasoService reaberturaCasoService;
    @EJB
    private IAssociaConteudoApoioService associaConteudoApoioService;
    @EJB
    private IAtendenteService atendenteService;
    @EJB
    private ITipoAcaoService tipoAcaoService;
    @EJB
    private IStatusService statusService;
    @EJB
    private ITempoAtendimentoCasoService tempoAtendimentoCasoService;
    @EJB
    private IStatusAtendenteService statusAtendenteService;
    @EJB
    private IParametroGBOService parametroGBOService;
    @EJB
    private ICasoAtendimento casoAtendimento;
    
    private List<CasoSau> casoSauList;
    private StatusAcao statusAcaoSelecionado;
    private List<StatusAcao> statusAcaoList;
    private List<StatusAcao> statusAcaoListSelecionar;
    private List<TipoAcao> tipoAcaoList;
    private TipoAcao tipoAcaoSelecionado;
    private Boolean cpfValido;
    private Boolean btnExecutarDesabled = true;
    private Boolean showModal = false;
    private Boolean exibeModalSolicitaCaso = true;
    private Boolean flagRechamado;
    private Boolean modalRespostaQuestionario;
    private Boolean iconeChecklist = false;
    private Questionario questionario;
    private ConteudoApoio conteudoApoio;
    private List<MetaFilaTO> listMetaFilaTo;
    private RelatorioStatusAtendente relatorioStatusAtendente;
    private Checklist checklist;
    
    public AtendenteCasoBB() {
        showModal = false;
        flagRechamado = Boolean.FALSE;
    }
    
    @PostConstruct
    public void init(){
    	limpaCampos();
        atualizaLista();
    }

    @Override
    public final void solicitaCaso() {
        try {
            AtendenteStatusLogadoBB atendenteStatusLogadoBB = (AtendenteStatusLogadoBB) getSessionMap().get("atendenteStatusLogadoBB");
            if (atendenteStatusLogadoBB.getAtendenteStatusSelecionado() != null && 
                    atendenteStatusLogadoBB.getAtendenteStatusSelecionado().getIdAtendenteStatus() != null) {
                atendenteStatusLogadoBB.alteraAtendenteStatus();
            } else {
                boolean temCasoAtendimento = true;
                for (CasoSau sau : casoSauList) {
                    if (sau.getCaso().getFlagEmAtendimento()) {
                        info("Vo\u00E7\u00EA precisa atender o caso " + sau.getManifestacao() + " para solicitar um novo caso.");
                        temCasoAtendimento = false;
                        break;
                    }
                }
                if (temCasoAtendimento) {
                    Atendente atende = getAtendente();
                    Caso caso = casoAtendimento.solicitaCasoAtendenteAtendimento(atende);

                    List<Caso> casosAtendente = casoService.buscaTodosCasosAtivosAtendente(atende);
                    limpaCampos();
                    casoSauList = casoSauService.findCasoSauByCaso(casosAtendente);

                    for (CasoSau csu : casoSauList) {
                        if (csu.getCaso().equals(caso)) {
                            visualizaCasoSau(csu);
                        }
                    }
                } else {
                    atualizaLista();
                }
            }
        } catch (Exception ex) {
            error(ex);
        }
    }

    @SuppressWarnings("unchecked")
	@Override
    public final void atualizaLista() {
        try {
            Atendente atendenteAtualiza = getAtendente();
            getSessionMap().put("cpfCnpjPesquisaCasos", "");
            if (atendenteAtualiza != null) {
                List<Caso> casosAtendente = casoService.buscaTodosCasosAtivosAtendente(atendenteAtualiza);
                limpaCampos();
                casoSauList = casoSauService.findCasoSauByCaso(casosAtendente);

                if (casoSauList != null && casoSauList.size() > 0) {

                    showModal = true;

                    for (CasoSau csu : casoSauList) {
                        if (csu.getCaso().getFlagEmAtendimento()) {
                            visualizaCasoSau(csu);
                            exibeModalSolicitaCaso = false;
                            break;
                        } else {
                            exibeModalSolicitaCaso = true;
                        }
                    }

                } else {
                    showModal = false;
                    exibeModalSolicitaCaso = false;
                    solicitaCaso();
                }
            } else {
                info("Não foi possível identificar o atendente. Esse usuário não pode atender um caso.");
            }
        } catch (Exception ex) {
            error(ex);
        }
    }
    
    public void metasUphUsuario()  {
        
    	CabMetaTO cabMeta = MetasUphCache.montaListaByUser(getLoginUsuario()) ;
    	
    	if(cabMeta != null) {
    		listMetaFilaTo = cabMeta.getListaMetaFilaTO();
    	}
    }

    public void visualizaCasoSau(CasoSau casoSau) {
        try {
            if (!atendenteService.validaAtendenteCaso(getAtendente())) {
                error("O analista possui perfil de supervisor. O mesmo n\u00E3o pode atender casos.");
                return;
            }
            
            casoSauService.validaAtendimentoCasoAtendente(casoSau, getAtendente());
            
            this.casoSau = casoSauService.load(casoSau);
            this.casoSau.setCaso(casoService.load(this.casoSau.getCaso()));
            if (this.casoSau.getEvento() != null && this.casoSau.getEvento().getIdEvento() != null) {
                this.casoSau.setEvento(eventoService.load(this.casoSau.getEvento()));
                this.casoSau.getEvento().setAssunto(assuntoService.load(this.casoSau.getEvento().getAssunto()));
            }

            this.questionario = associaQuestionarioService.getQuestionario(this.casoSau.getEvento());
            if (this.questionario == null) {
                modalRespostaQuestionario = false;
            } else {
                modalRespostaQuestionario = true;
            }

            this.cpfValido = CpfCnpj.validaCpfCnpj(casoSau.getCpfCnpj()) == null ? Boolean.FALSE : Boolean.TRUE;
            this.casoSau.setAtendenteAtualGBO(getUserInfo().getUserLogin());
            this.casoSau.setCaso(casoSau.getCaso());
            this.setPojo(casoSau.getCaso());

            this.tipoAcaoSelecionado = new TipoAcao();
            this.statusAcaoSelecionado = new StatusAcao();
            this.statusAcaoSelecionado.setStatusAcaoId(new StatusAcaoId(new Status(), new Acao()));
            setTipoAcaoList(tipoAcaoService.findTipoAcaoPeloStatus(getPojo().getStatus()));
            setStatusAcaoList(statusService.findByStatus(getPojo().getStatus()));

            for (CasoSau csu : casoSauList) {
                boolean updt = csu.getCaso().getFlagEmAtendimento()
                        && !csu.getCaso().equals(casoSau.getCaso());
                if (updt) {
                    csu.getCaso().setFlagEmAtendimento(Boolean.FALSE);
                    casoService.saveOrUpdate(csu.getCaso());
                }
            }

            if (!getPojo().getFlagEmAtendimento()) {
                getPojo().setFlagEmAtendimento(Boolean.TRUE);
                salvar();
            }

            verificaRechamado();
            
            carregaConteudoApoio();
            
            marcacaoStatusAtendente();

            StringBuilder stringMsg = new StringBuilder();

            stringMsg.append("Caso ").append(casoSau.getManifestacao()).append(" em atendimento. ");

            info(stringMsg.toString());

            if (casoSau.getCaso().getAtendente() != null && casoSau.getCaso().getAtendente().getIdAtendente() != null) {
                tempoAtendimentoCasoService.salvaMarcacaoAtendimento(casoSau.getCaso(), null, casoSau.getCaso().getAtendente(), Boolean.TRUE);
            }
        } catch (ValidationException ex) {
            error(ex.getMessage());
        } catch (ServiceException ex) {
            error(ex);
        }

    }

    private void verificaRechamado() {
        try {
            List<ReaberturaCaso> reaberturaList = reaberturaCasoService.findByCaso(casoSau.getCaso());

            if (reaberturaList == null || reaberturaList.isEmpty()) {
                setFlagRechamado(Boolean.FALSE);
            } else {
                setFlagRechamado(Boolean.TRUE);
            }

        } catch (ServiceException ex) {
            error(ex);
        }
    }

    public void carregaAcaoes() {
        statusAcaoListSelecionar = new ArrayList<StatusAcao>();
        btnExecutarDesabled = true;
        if (tipoAcaoSelecionado != null && tipoAcaoSelecionado.getIdTipoAcao() != null) {
            List<AcaoTipoAcao> acaoTipoAcaoList = null;
            try {
                acaoTipoAcaoList = tipoAcaoService.find(null, tipoAcaoSelecionado);
            }catch (ValidationException e) {
                error(e);
            }catch (ServiceException e) {
                error(e);
            }
            if (acaoTipoAcaoList != null) {
                for (AcaoTipoAcao acaoTipoAcao : acaoTipoAcaoList) {
                    for (StatusAcao statusAcao : statusAcaoList) {
                        if (statusAcao.getStatusAcaoId().getIdAcao().equals(acaoTipoAcao.getAcaoTipoAcaoId().getIdAcao())) {
                            statusAcaoListSelecionar.add(statusAcao);
                            break;
                        }
                    }
                }
            }
        }
    }

    public final void limpaCampos() {
        casoSau = new CasoSau();
        casoSau.setCausa(new Causa());
        casoSau.setEvento(new Evento());
        casoSau.setCanal(new Canal());
        casoSau.setTipoManifestacao(new TipoManifestacao());
        casoSau.setEstado(new Estado());
        casoSau.setCaso(new Caso());
        btnExecutarDesabled = true;
        statusAcaoSelecionado = new StatusAcao();
        tipoAcaoSelecionado = new TipoAcao();
        conteudoApoio = new ConteudoApoio();
        iconeChecklist = false;
        

        setHistoricoCaso(new ArrayList<Log>());
        setHistoricoEmailCaso(new ArrayList<Log>());
       
        if (statusAcaoList != null) {
            statusAcaoList.clear();
        } else {
            setStatusAcaoList(new ArrayList<StatusAcao>());
        }

        setStatusAcaoListSelecionar(new ArrayList<StatusAcao>());
        
        setEmailSelecionado(new Email());
        
    }
    
    public void validaAcaoSelecionada() {
        btnExecutarDesabled = this.statusAcaoSelecionado == null || this.statusAcaoSelecionado.getStatusAcaoId().getIdAcao() == null;
        carregaIconeChecklist();
    }
    
    /**
     * 
     * @return
     */
    public Boolean getBloquearBotaoMetaUphAtendente() {
    	boolean retorna = false;
    	try {
	    	String visualizarMetaUphAtendente = parametroGBOService.findByParam(
	    					ConstantesSau.VARIAVEL_VISUALIZA_BOTAO_META_UPH).getValor();
	    	
	    	if ("true".equals(visualizarMetaUphAtendente)) {
	    		retorna = true;
	    	}
    	} catch (Exception ex) {
    		error("Erro ao buscar parametro de ativação do botão metaUph");
    	}
    	return retorna;
    }
    
    
    public void geraRelatorioStatusAtendente(){
    	
    	try {
    		
    		Date dataAtual = new Date();
    		Atendente atendente = atendenteService.findByLogin(getUserInfo().getUserLogin());
	    	List<StatusAtendente> listStatusAtendentes = statusAtendenteService.buscaStatusAtendenteByAtendente(atendente, DateUtils.addFirstTimeInDate(dataAtual), DateUtils.addLastTimeInDate(dataAtual));
	    	relatorioStatusAtendente = ControleStatusAtendentes.getRelatorioStatusAtendente(atendente, listStatusAtendentes, dataAtual);
    	
    	} catch (Exception e) {
			error(e);
		}
    }

    public CasoSau getCasoSau() {
        return casoSau;
    }

    public void setCasoSau(CasoSau casoSau) {
        this.casoSau = casoSau;
    }

    public List<CasoSau> getCasoSauList() {
        return casoSauList;
    }

    public void setCasoSauList(List<CasoSau> casoSauList) {
        this.casoSauList = casoSauList;
    }

    public List<SelectItem> getStatusAcaoList() {
        return JSFUtil.toSelectItemConsulta(statusAcaoList);
    }

    public void setStatusAcaoList(List<StatusAcao> statusAcaoList) {
        this.statusAcaoList = statusAcaoList;
    }

    public StatusAcao getStatusAcaoSelecionado() {
        return statusAcaoSelecionado;
    }

    public void setStatusAcaoSelecionado(StatusAcao statusAcaoSelecionado) {
        this.statusAcaoSelecionado = statusAcaoSelecionado;
    }

    public Boolean getBtnExecutarDesabled() {
        return btnExecutarDesabled;
    }

    public void setBtnExecutarDesabled(Boolean btnExecutarDesabled) {
        this.btnExecutarDesabled = btnExecutarDesabled;
    }

    public Boolean getCpfValido() {
        return cpfValido;
    }

    public void setCpfValido(Boolean cpfValido) {
        this.cpfValido = cpfValido;
    }

    public Boolean getShowModal() {
        return showModal;
    }

    public void setShowModal(Boolean showModal) {
        this.showModal = showModal;
    }

    public Boolean getExibeModalSolicitaCaso() {
        return exibeModalSolicitaCaso;
    }

    public void setExibeModalSolicitaCaso(Boolean exibeModalSolicitaCaso) {
        this.exibeModalSolicitaCaso = exibeModalSolicitaCaso;
    }
    
    public void carregaConteudoApoio() {
        try {
            conteudoApoio = associaConteudoApoioService.getConteudoApoioFromCasoSau(casoSau);
        } catch (ServiceException ex) {
            error(ex);
        }
    }

    public ConteudoApoio getConteudoApoio() {
        return conteudoApoio;
    }

    public Boolean exibeIconeConteudoApoio() {
        return conteudoApoio.getIdConteudoApoio() == null ? Boolean.FALSE : Boolean.TRUE;
    }
    
    public Boolean processandoSPA(){
    	try {
			return Boolean.valueOf(parametroGBOService.findByParam(Constantes.FLAG_PROCESSANDO_SPA).getValor());
		} catch (ServiceException e) {
			error(e);
		}
		return false;
    }
    
    public void carregaIconeChecklist(){
    	try {
			
    		if(statusAcaoSelecionado!= null) {
    			setChecklist(associaChecklistService.getChecklist(casoSau.getEvento(),statusAcaoSelecionado.getStatusAcaoId().getIdAcao()));
    			if(getChecklist()!= null && getChecklist().getIdChecklist()!=null){
    				iconeChecklist = true;
    			}else{
    				iconeChecklist =  false;
    			}
    		}
		} catch (ServiceException e) {
			error(e);
		}
    }
    
    public Integer qtdCasosAbertosCpfCnpj(){
    	
    	try {
			return casoSauService.buscarQtdCasoAbertoPorCpfCnpj(casoSau.getCpfCnpj());
		} catch (ServiceException e) {
			error(e);
		}
    	return null;
    }
    

    @Override
    public Map<String, Object> getParamsGBO() {
        Map<String, Object> parametros = new HashMap<String, Object>();
        parametros.put("caso", getCasoSau().getCaso());
        parametros.put("acao", getStatusAcaoSelecionado().getStatusAcaoId().getIdAcao());
        return parametros;
    }

    public void setStatusAcaoListSelecionar(List<StatusAcao> statusAcaoListSelecionar) {
        this.statusAcaoListSelecionar = statusAcaoListSelecionar;
    }

    public List<SelectItem> getStatusAcaoListSelecionar() {
        return JSFUtil.toSelectItemConsulta(statusAcaoListSelecionar);
    }

    public void setTipoAcaoList(List<TipoAcao> tipoAcaoList) {
        this.tipoAcaoList = tipoAcaoList;
    }

    public List<SelectItem> getTipoAcaoList() {
        return JSFUtil.toSelectItemConsulta(tipoAcaoList);
    }

    /**
     * @param tipoAcaoSelecionado the tipoAcaoSelecionado to set
     */
    public void setTipoAcaoSelecionado(TipoAcao tipoAcaoSelecionado) {
        this.tipoAcaoSelecionado = tipoAcaoSelecionado;
    }

    /**
     * @return the tipoAcaoSelecionado
     */
    public TipoAcao getTipoAcaoSelecionado() {
        return tipoAcaoSelecionado;
    }

    public Boolean getFlagRechamado() {
        return flagRechamado;
    }

    public void setFlagRechamado(Boolean flagRechamado) {
        this.flagRechamado = flagRechamado;
    }

    public Boolean getModalRespostaQuestionario() {
        return modalRespostaQuestionario;
    }

    public void setModalRespostaQuestionario(Boolean modalRespostaQuestionario) {
        this.modalRespostaQuestionario = modalRespostaQuestionario;
    }

    public Questionario getQuestionario() {
        return questionario;
    }

    public void setQuestionario(Questionario questionario) {
        this.questionario = questionario;
    }
    
    @Override
    public Caso getCaso() {
        return casoSau.getCaso();
    }

    private void marcacaoStatusAtendente() {
        try {
            if (getAtendente() != null) {
                statusAtendenteService.salvaStatusAtendimentoAtendimento(getAtendente(), casoSau.getCaso());
            }
        }catch (ValidationException ex) {
            error(ex.getMessage());
        }catch (ServiceException ex) {
            error(ex);
        }
    }

	public List<MetaFilaTO> getListMetaFilaTo() {
		return listMetaFilaTo;
	}

	public void setListMetaFilaTo(List<MetaFilaTO> listMetaFilaTo) {
		this.listMetaFilaTo = listMetaFilaTo;
	}
	
	public RelatorioStatusAtendente getRelatorioStatusAtendente() {
		return relatorioStatusAtendente;
	}

	public void setRelatorioStatusAtendente(RelatorioStatusAtendente relatorioStatusAtendente) {
		this.relatorioStatusAtendente = relatorioStatusAtendente;
	}

	public Checklist getChecklist() {
		return checklist;
	}

	public void setChecklist(Checklist checklist) {
		this.checklist = checklist;
	}

	public Boolean getIconeChecklist() {
		return iconeChecklist;
	}

	public void setIconeChecklist(Boolean iconeChecklist) {
		this.iconeChecklist = iconeChecklist;
	}

	@Override
	public void novo() {
		limpaCampos();
	}

	@Override
	protected ICasoService getService() {
		return casoService;
	}
	
}
