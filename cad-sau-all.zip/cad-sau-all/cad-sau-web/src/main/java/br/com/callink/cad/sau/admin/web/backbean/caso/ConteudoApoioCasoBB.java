/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.callink.cad.sau.admin.web.backbean.caso;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import br.com.callink.cad.sau.admin.web.backbean.CadSauAdminGenericCrud;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.pojo.ConteudoApoio;
import br.com.callink.cad.sau.service.IConteudoApoioService;
import br.com.callink.cad.service.exception.ServiceException;

/**
 *
 * @author Luiz Gustavo (luizgf@swb.com.br)
 */
@ManagedBean
@ViewScoped
public class ConteudoApoioCasoBB extends CadSauAdminGenericCrud<ConteudoApoio, IConteudoApoioService> {
    
	private static final long serialVersionUID = -2799791122177737055L;
	
	@EJB
	private IConteudoApoioService conteudoApoioService;
	
    public ConteudoApoioCasoBB () {
    }
    
    public void atualiza() {
        try {
            setPojo(getService().load(getAtendenteCasoBB().getConteudoApoio()));
            
            if(getPojo().getGrupoAnexo() != null && getPojo().getGrupoAnexo().getIdGrupoAnexo() != null ) {
            	buscaAnexos(getPojo().getGrupoAnexo().getIdGrupoAnexo());
            	getPojo().setGrupoAnexo(getGrupoAnexo());
            }
        } catch (ServiceException ex) {
            error(ex);
        }
    }
    
    public void cleanData() {
        setPojo(new ConteudoApoio());
    }

    public void setCasoSauSelecionado(CasoSau casoSauSelecionado) {
        getSessionMap().put("casoSelecionado", casoSauSelecionado);
    }

	@Override
	protected IConteudoApoioService getService() {
		return conteudoApoioService;
	}

	@Override
	public void novo() {
		
	}
}
