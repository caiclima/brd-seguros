/**
 * Pacote de backbeans de caso
 */
package br.com.callink.cad.sau.admin.web.backbean.caso;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import br.com.callink.cad.backbean.CadGenericCrud;
import br.com.callink.cad.pojo.Atendente;
import br.com.callink.cad.sau.enumeration.TipoAssocicaoCasoAtendente;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.service.IAssuntoService;
import br.com.callink.cad.sau.service.ICasoSauService;
import br.com.callink.cad.sau.service.IEventoService;
import br.com.callink.cad.service.exception.ServiceException;

/**
 * @author José Araújo (joseap@swb.com.br)
 *
 */
@ManagedBean
@SessionScoped
public class OutrosCasosBB extends CadGenericCrud<CasoSau, ICasoSauService> {
	
	/**serial version uid*/
	private static final long serialVersionUID = -1777576357814017535L;
	
	@EJB
	private ICasoSauService casoSauService;
	@EJB
	private IEventoService eventoService;
	@EJB
	private IAssuntoService assuntoService;
	
	/**Lista de Casos Sau*/
	private List<CasoSau> casoSauList;
	
	/**Caso Sau Selecionado*/
	private CasoSau casoSauSelecionado;
	
	/**Map de casos selecionados para associacao*/
	private Map<Integer, CasoSau> mapAssociacaoCasoSausSelecionados;
	
	/**Lista de casos selecionados para associacao*/
	private List<CasoSau> listCasoSauAssociacao;
	
	
	private String loginSupervisor;
    private String senhaSupervisor;
	
	/** Construtor */
	public OutrosCasosBB() {
	}
	
	/**
	 * Metodo para buscar outros casos.
	 */
	@SuppressWarnings("unchecked")
	public void buscarCasosSauPorCpfCnpj() {
		try {
			AtendenteCasoBB atendenteCasoBB = (AtendenteCasoBB) getSessionMap().get("atendenteCasoBB");
			//Verifica se existe um caso sau
			if (atendenteCasoBB != null && atendenteCasoBB.getCasoSau() != null) {
				//Verifica se não existe um CPF ou CNPJ na sessão ou se o mesmo é diferente do utilizado na busca atual.
				if (getSessionMap().get("cpfCnpjPesquisaCasos") == null
						|| !getSessionMap().get("cpfCnpjPesquisaCasos").equals(
								atendenteCasoBB.getCasoSau().getCpfCnpj())) {
					
					Atendente atendente = atendenteCasoBB.getAtendente();
					this.casoSauList = this.casoSauService.buscarCasoSauPorCpfCnpjEFiltraAssociarCaso(atendenteCasoBB.getCasoSau().getCpfCnpj(), atendente);
					
					getSessionMap().put("cpfCnpjPesquisaCasos", atendenteCasoBB.getCasoSau().getCpfCnpj());
				}
			} else {
				error("Problema ao recuperar dados do caso.");
			}
		} catch (Exception e) {
			error(e);
		}
	}
	
	/**
	 * Método para vizualiar um determinado caso selecionado pelo usuário
	 * 
	 * @param CasoSau
	 */
	@SuppressWarnings("unchecked")
	public void visualizaCasoSau(CasoSau casoSau) {
		try {
            this.casoSauSelecionado = this.casoSauService.load(casoSau);
            //Verifica se existe um caso sau selecionado
            if (this.casoSauSelecionado != null) {
                getSessionMap().put("casoSelecionado", this.casoSauSelecionado);
            } else {
            	error("Erro ao selecionar caso para visualizar");
            }
            
        } catch (ServiceException ex) {
            error(ex);
        }
	}
	
	/**
	 * Método para selecionar casos a serem associados
	 * 
	 * @param CasoSau
	 */
	public void selecionaCasoAssociacao(CasoSau casoSau) {
		try {
			
			if(getMapAssociacaoCasoSausSelecionados() == null) {
				setMapAssociacaoCasoSausSelecionados(new HashMap<Integer, CasoSau>());
			}

			
			if(casoSau != null) {
				if(casoSau.getSelecionado()) {
					getMapAssociacaoCasoSausSelecionados().put(casoSau.getIdCasoSau(), casoSau);
				} else {
					if(getMapAssociacaoCasoSausSelecionados().containsKey(casoSau.getIdCasoSau())) {
						getMapAssociacaoCasoSausSelecionados().remove(casoSau.getIdCasoSau());
					}
				}
			}
			
		} catch (Exception e) {
			error(e);
		}
	}
	
	public void buscaDadosCasoSauAssociacao() {
		try {
			
			if(getMapAssociacaoCasoSausSelecionados() != null) {
				setListCasoSauAssociacao(new ArrayList<CasoSau>(getMapAssociacaoCasoSausSelecionados().values()));
			}
			
			Integer idAtendente = ((AtendenteCasoBB) getSessionMap().get("atendenteCasoBB")).getAtendente().getIdAtendente();
			setListCasoSauAssociacao(this.casoSauService.validaCasoParaAssociarCasoAtendente(getListCasoSauAssociacao(), idAtendente));
			
			for(CasoSau casoSau : getListCasoSauAssociacao()) {
				if(casoSau.getTipoAssociacaoCaso() != null && 
						casoSau.getTipoAssociacaoCaso().equals(TipoAssocicaoCasoAtendente.OK_NENHUM_OUTRO_ATENDENTE.getTipoAssocicaoCasoAtendente())) {
					
					casoSau.setSelecionado(Boolean.TRUE);
				} else if(casoSau.getTipoAssociacaoCaso() != null && 
						casoSau.getTipoAssociacaoCaso().equals(TipoAssocicaoCasoAtendente.SENHA_OUTRO_ATENDENTE_NAO_ATENDIMENTO.getTipoAssocicaoCasoAtendente())) {
					
					casoSau.setSelecionado(Boolean.TRUE);
				} else {
					
					casoSau.setSelecionado(Boolean.FALSE);
				}
				
			}
			
		} catch (Exception e) {
			error(e);
		}
	}
	
	public void confirmaDadosCasoSauAssociacao() {
		try {
			
			Atendente atendente = ((AtendenteCasoBB) getSessionMap().get("atendenteCasoBB")).getAtendente();
			casoSauService.confirmaDadosCasoSauAssociacao(getListCasoSauAssociacao(), loginSupervisor, senhaSupervisor, atendente);
			
			info("Casos associados com sucesso.");
			
		} catch (Exception e) {
			error(e);
		}
	}
	
	public boolean validaSupervisorAssocicaoCaso() {
		
		if(getListCasoSauAssociacao() != null) {
			for(CasoSau casoSau :  getListCasoSauAssociacao()) {
				if(casoSau.getTipoAssociacaoCaso() != null && 
						casoSau.getTipoAssociacaoCaso().equals(TipoAssocicaoCasoAtendente.SENHA_OUTRO_ATENDENTE_NAO_ATENDIMENTO.getTipoAssocicaoCasoAtendente())) {
					return Boolean.TRUE;
				}
			}
		}
		return Boolean.FALSE;
	}
	
	/**
	 * Método para selecionar casos a serem associados
	 * 
	 * @param CasoSau
	 */
	public void selecionaCasoAssociacaoJaSolicitado(CasoSau casoSau) {
		try {
			
			for(CasoSau casoSauLocal : getListCasoSauAssociacao()) {
				if(casoSauLocal.getIdCasoSau().equals(casoSau.getIdCasoSau())) {
					casoSauLocal.setSelecionado(casoSau.getSelecionado());
				}
			}
			
		} catch (Exception e) {
			error(e);
		}
	}
	
	public void cleanCasoAssociacao() {
		try {
		
			setListCasoSauAssociacao(new ArrayList<CasoSau>());
			
			setMapAssociacaoCasoSausSelecionados(new HashMap<Integer, CasoSau>());
			
			setLoginSupervisor("");
			setSenhaSupervisor("");
			
			AtendenteCasoBB atendenteCasoBB = (AtendenteCasoBB) getSessionMap().get("atendenteCasoBB");
			atendenteCasoBB.atualizaLista();
			this.casoSauList = this.casoSauService.buscarCasoSauPorCpfCnpjEFiltraAssociarCaso(atendenteCasoBB.getCasoSau().getCpfCnpj(), atendenteCasoBB.getAtendente());
			
			for(CasoSau casoSau : this.casoSauList) {
				casoSau.setSelecionado(Boolean.FALSE);
			}
			
		} catch (Exception e) {
			error(e);
		}
	}

	/**
	 * @return the casoSauService
	 */
	public ICasoSauService getCasoSauService() {
		return casoSauService;
	}

	/**
	 * @param casoSauService the casoSauService to set
	 */
	public void setCasoSauService(ICasoSauService casoSauService) {
		this.casoSauService = casoSauService;
	}

	/**
	 * @return the casoSauList
	 */
	public List<CasoSau> getCasoSauList() {
		return casoSauList;
	}

	/**
	 * @param casoSauList the casoSauList to set
	 */
	public void setCasoSauList(List<CasoSau> casoSauList) {
		this.casoSauList = casoSauList;
	}

	/**
	 * @return the casoSauSelecionado
	 */
	public CasoSau getCasoSauSelecionado() {
		return casoSauSelecionado;
	}

	/**
	 * @param casoSauSelecionado the casoSauSelecionado to set
	 */
	public void setCasoSauSelecionado(CasoSau casoSauSelecionado) {
		this.casoSauSelecionado = casoSauSelecionado;
	}

	/**
	 * @return the eventoService
	 */
	public IEventoService getEventoService() {
		return eventoService;
	}

	/**
	 * @param eventoService the eventoService to set
	 */
	public void setEventoService(IEventoService eventoService) {
		this.eventoService = eventoService;
	}

	/**
	 * @return the assuntoService
	 */
	public IAssuntoService getAssuntoService() {
		return assuntoService;
	}

	/**
	 * @param assuntoService the assuntoService to set
	 */
	public void setAssuntoService(IAssuntoService assuntoService) {
		this.assuntoService = assuntoService;
	}

	/**
	 * @return the mapAssociacaoCasoSausSelecionados
	 */
	public Map<Integer, CasoSau> getMapAssociacaoCasoSausSelecionados() {
		return mapAssociacaoCasoSausSelecionados;
	}

	/**
	 * @param mapAssociacaoCasoSausSelecionados the mapAssociacaoCasoSausSelecionados to set
	 */
	public void setMapAssociacaoCasoSausSelecionados(Map<Integer, CasoSau> mapAssociacaoCasoSausSelecionados) {
		this.mapAssociacaoCasoSausSelecionados = mapAssociacaoCasoSausSelecionados;
	}

	/**
	 * @return the listCasoSauAssociacao
	 */
	public List<CasoSau> getListCasoSauAssociacao() {
		if(listCasoSauAssociacao == null) {
			this.listCasoSauAssociacao = new ArrayList<CasoSau>();
		}
		return listCasoSauAssociacao;
	}

	/**
	 * @param listCasoSauAssociacao the listCasoSauAssociacao to set
	 */
	public void setListCasoSauAssociacao(List<CasoSau> listCasoSauAssociacao) {
		this.listCasoSauAssociacao = listCasoSauAssociacao;
	}

	public String getLoginSupervisor() {
		if(loginSupervisor == null) {
			loginSupervisor = "";
		}
		return loginSupervisor;
	}

	public void setLoginSupervisor(String loginSupervisor) {
		this.loginSupervisor = loginSupervisor;
	}

	public String getSenhaSupervisor() {
		if(senhaSupervisor == null) {
			senhaSupervisor = "";
		}
		return senhaSupervisor;
	}

	public void setSenhaSupervisor(String senhaSupervisor) {
		this.senhaSupervisor = senhaSupervisor;
	}

	@Override
	public void novo() {
		setPojo(new CasoSau());
	}

	@Override
	protected ICasoSauService getService() {
		return casoSauService;
	}

}
