package br.com.callink.cad.sau.admin.web.backbean.caso.acao;

import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.model.SelectItem;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.engine.command.ICommandScreen;
import br.com.callink.cad.engine.command.executor.IExecutorCommandService;
import br.com.callink.cad.sau.admin.web.backbean.CadSauAdminGenericCrud;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.pojo.Juncao;
import br.com.callink.cad.sau.service.ICasoSauService;
import br.com.callink.cad.sau.service.IJuncaoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.util.CpfCnpj;
import br.com.callink.cad.util.JSFUtil;

@ManagedBean
@ViewScoped
public class AtualizaDadosBB extends CadSauAdminGenericCrud<CasoSau, ICasoSauService> implements ICommandScreen {

    private static final long serialVersionUID = 1654532044105070574L;
    private String cpfAlterado;
    private String observacao;
    private List<Juncao> listaJuncao;
    private Boolean atrazoOutraArea;
    @EJB
    private ICasoSauService casoSauService;
    @EJB(beanName="ExecutorCommandService")
    private IExecutorCommandService executorCommandService;
    @EJB
    private IJuncaoService juncaoService;
    
    public AtualizaDadosBB() {
       
    }

    @PostConstruct
    public void init(){
    	cleanData();
    }
    
    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }

    @Override
    public void execute() {
        try {
            if (validaDadosTelas()) {
                Map<String, Object> parametros = getAtendenteCasoBB().getParamsGBO();
                parametros.put("observacao", getObservacao());

                parametros.put("casoSau", getPojo());

                executorCommandService.execute(parametros);
                getAtendenteCasoBB().atualizaLista();
                cleanData();
            }
        } catch (ServiceException ex) {
            getAtendenteCasoBB().getCasoSau().setCpfCnpj(cpfAlterado);
            error(ex);
        } catch (Exception e) {
            error(e);
        }
    }

    private boolean validaDadosTelas() {
        Boolean valida = Boolean.TRUE;

        if (StringUtils.isBlank(getPojo().getCpfCnpj())) {
            error("Campo Obrigat\u00F3rio : Cpf/Cnpj ");
            getAtendenteCasoBB().getCasoSau().setCpfCnpj(cpfAlterado);
            valida = Boolean.FALSE;
        }

        if (StringUtils.isNotBlank(getPojo().getCpfCnpj())) {

            String cpfCnpj = CpfCnpj.validaCpfCnpj(getPojo().getCpfCnpj());

            if (cpfCnpj == null) {
                StringBuilder string = new StringBuilder();
                string.append("Cpf/Cnpj inv\u00E1lido! Cpf/Cnpj: ");
                string.append(getPojo().getCpfCnpj());
                error(string.toString());
                getAtendenteCasoBB().getCasoSau().setCpfCnpj(cpfAlterado);
                valida = Boolean.FALSE;
            } else {
                getPojo().setCpfCnpj(cpfCnpj);
            }
        }

        return valida;
    }

    @Override
    public final void cleanData() {
        this.observacao = null;
        setPojo(getAtendenteCasoBB().getCasoSau());
        cpfAlterado = getAtendenteCasoBB().getCasoSau().getCpfCnpj();
        try {
            atrazoOutraArea = getService().juncaoForaPrazo(getPojo());
            if (atrazoOutraArea) {
                listaJuncao = juncaoService.findAtivos("Juncao.NOME");
            }
        } catch (ServiceException ex) {
            error(ex);
        }
    }

    public String getCpfAlterado() {
        return cpfAlterado;
    }

    public void setCpfAlterado(String cpfAlterado) {
        this.cpfAlterado = cpfAlterado;
    }

    public List<SelectItem> getListaJuncao() {
        return JSFUtil.toSelectItemConsulta(this.listaJuncao);
    }

    public void setListaJuncao(List<Juncao> listaJuncao) {
        this.listaJuncao = listaJuncao;
    }

    public Boolean getAtrazoOutraArea() {
        return atrazoOutraArea;
    }

    public void setAtrazoOutraArea(Boolean atrazoOutraArea) {
        this.atrazoOutraArea = atrazoOutraArea;
    }

	@Override
	protected ICasoSauService getService() {
		return casoSauService;
	}

	@Override
	public void novo() {
		setPojo(new CasoSau());
	}
}
