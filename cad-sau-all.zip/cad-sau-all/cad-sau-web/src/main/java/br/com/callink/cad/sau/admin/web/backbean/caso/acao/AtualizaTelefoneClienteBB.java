package br.com.callink.cad.sau.admin.web.backbean.caso.acao;

import java.util.List;
import java.util.Map;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import org.apache.commons.collections.CollectionUtils;
import br.com.callink.cad.backbean.GenericCrud;
import br.com.callink.cad.engine.command.ICommandScreen;
import br.com.callink.cad.engine.command.executor.IExecutorCommandService;
import br.com.callink.cad.pojo.ParametroGBO;
import br.com.callink.cad.pojo.Telefone;
import br.com.callink.cad.sau.admin.web.backbean.caso.AtendenteCasoBB;
import br.com.callink.cad.service.IAtendenteService;
import br.com.callink.cad.service.IAuthenticatorService;
import br.com.callink.cad.service.IParametroGBOService;
import br.com.callink.cad.service.ITelefoneService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.impl.AuthenticatorService;
import br.com.callink.cad.util.Constantes;

@ManagedBean
@ViewScoped
public class AtualizaTelefoneClienteBB extends GenericCrud implements ICommandScreen {

    private static final long serialVersionUID = 1654532044105070574L;
    
    private AtendenteCasoBB atendenteCasoBB;
    private Boolean validaSupervisor;
    private String loginSupervisor;
    private String senhaSupervisor;
    private List<Telefone> telefones;
    private Integer qtdMaximaEdicao;
    private Telefone telefoneSelecionado;
    private String novoTelefone;
    
    @EJB(beanName="ExecutorCommandService")
    private IExecutorCommandService executorCommandService;
    
    @EJB
    private ITelefoneService telefoneService;
    
    @EJB
    private IAtendenteService atendenteService;
    
    @EJB
    private IAuthenticatorService authenticatorService;
    
    @EJB
    private IParametroGBOService parametroGBOService;
    
    @PostConstruct
    public void init(){
    	cleanData();
    }
    
	private void loadTelefonesPorCaso() {
		try {
			if (getAtendenteCasoBB().getCasoSau() == null) {
				throw new IllegalArgumentException("Erro : Caso est\u00E1 nulo !");
			}
		
			telefones = telefoneService.buscaTelefoneCaso(getAtendenteCasoBB().getCaso());
			
		} catch (Exception e) {
			error(e);
		}
	}
	
	public boolean validaSupervisor() {
        Integer edicaoTelefoneCount = getAtendenteCasoBB().getCaso().getEdicaoTelefoneCount();
        edicaoTelefoneCount = edicaoTelefoneCount == null ? Integer.valueOf(0) : edicaoTelefoneCount;

        if (qtdMaximaEdicao == null) {
            try {
                ParametroGBO parametro = parametroGBOService.findByParam(Constantes.PARAMETRO_QTD_MAX_EDICAO_TELEFONE_CASO);
                qtdMaximaEdicao = Integer.valueOf(parametro.getValor());
                loginSupervisor = "";
            } catch (ServiceException ex) {
                error(ex);
            }
        }

        if (edicaoTelefoneCount >= qtdMaximaEdicao) {
            validaSupervisor = true;
        } else {
            validaSupervisor = false;
        }
        return validaSupervisor;
    }

	@Override
	public void execute() {
		try {
			if (getAtendenteCasoBB().getCasoSau() == null) {
				throw new IllegalArgumentException("Erro : Caso est\u00E1 nulo !");
			}

			if (validaSupervisor != null && validaSupervisor) {
				try {
					if (!atendenteService.validaLoginSupervisor(loginSupervisor)) {
						error("Erro : O Login informado n\u00E3o pertence a um supervisor. !");
						return;
					}

					IAuthenticatorService authentica = authenticatorService;
					authentica.authentica(loginSupervisor, senhaSupervisor, AuthenticatorService.AD);
				} catch (Exception e) {
					throw new ServiceException("Erro de Autentica\u00E7\u00E3o do supervisor.", e);
				}
			}

			if (validaCampos()) {
				Map<String, Object> parametros = atendenteCasoBB.getParamsGBO();
				parametros.put("casoSau", atendenteCasoBB.getCasoSau());
				parametros.put("telefones", telefones);
				executorCommandService.execute(parametros);
				getAtendenteCasoBB().atualizaLista();
				cleanData();
			}
		} catch (Exception e) {
			error(e);
		}
	}

    private boolean validaCampos() {
        if (CollectionUtils.isEmpty(telefones)) {
            return Boolean.FALSE;
        }

        return Boolean.TRUE;
    }
    
    public void alterarTel(Telefone tel) {
		setTelefoneSelecionado(tel);
	}
    
    public void newTelefone() {
		if (novoTelefone.isEmpty() || novoTelefone.length() < 3) {
			error("Informe um telefone válido.");
			return;
		}
		
		Telefone tel = new Telefone();
		tel.setTelefone(novoTelefone);
		tel.setCaso(getAtendenteCasoBB().getCasoSau().getCaso());
		
		telefones.add(tel);
		
		novoTelefone = "";
	}
    
    
	public AtendenteCasoBB getAtendenteCasoBB() {
		return (AtendenteCasoBB) getSessionMap().get("atendenteCasoBB");
	}
	
	public Boolean getValidaSupervisor() {
		return validaSupervisor;
	}

	public void setValidaSupervisor(Boolean validaSupervisor) {
		this.validaSupervisor = validaSupervisor;
	}
	
	public String getLoginSupervisor() {
		return loginSupervisor;
	}
	
	public void setLoginSupervisor(String loginSupervisor) {
		this.loginSupervisor = loginSupervisor;
	}
	
	public String getSenhaSupervisor() {
		return senhaSupervisor;
	}
	
	public void setSenhaSupervisor(String senhaSupervisor) {
		this.senhaSupervisor = senhaSupervisor;
	}
	
	public List<Telefone> getTelefones() {
		if(telefones == null){
			loadTelefonesPorCaso();
		}
		return telefones;
	}
	
	public void setTelefones(List<Telefone> telefones) {
		this.telefones = telefones	;
	}
	
	public Integer getQtdMaximaEdicao() {
		return qtdMaximaEdicao;
	}
	
	public void setQtdMaximaEdicao(Integer qtdMaximaEdicao) {
		this.qtdMaximaEdicao = qtdMaximaEdicao;
	}
	public Telefone getTelefoneSelecionado() {
		return telefoneSelecionado;
	}
	
	public void setTelefoneSelecionado(Telefone telefoneSelecionado) {
		this.telefoneSelecionado = telefoneSelecionado;
	}
	
	public String getNovoTelefone() {
		return novoTelefone;
	}
	
	public void setNovoTelefone(String novoTelefone) {
		this.novoTelefone = novoTelefone;
	}
	
	public String fechar(){
		cleanData();
		return "";
	}
	
	@Override
    public final void cleanData() {
		atendenteCasoBB = getAtendenteCasoBB();
		telefones = null;
		novoTelefone = "";
    	telefoneSelecionado = new Telefone();
		validaSupervisor = false;
	    loginSupervisor = null;
	    senhaSupervisor = null;
	    qtdMaximaEdicao = null;
    }
}
