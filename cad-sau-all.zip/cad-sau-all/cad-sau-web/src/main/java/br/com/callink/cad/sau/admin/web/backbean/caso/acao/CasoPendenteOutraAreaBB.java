package br.com.callink.cad.sau.admin.web.backbean.caso.acao;


import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.model.SelectItem;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.engine.command.ICommandScreen;
import br.com.callink.cad.engine.command.executor.IExecutorCommandService;
import br.com.callink.cad.pojo.Agendamento;
import br.com.callink.cad.sau.admin.web.backbean.CadSauAdminGenericCrud;
import br.com.callink.cad.sau.admin.web.backbean.caso.AtendenteCasoBB;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.pojo.OutraArea;
import br.com.callink.cad.sau.service.ICasoSauService;
import br.com.callink.cad.sau.service.IOutraAreaService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.util.JSFUtil;

@ManagedBean
@ViewScoped
public class CasoPendenteOutraAreaBB extends CadSauAdminGenericCrud<CasoSau, ICasoSauService> implements
        ICommandScreen {

    private static final long serialVersionUID = 1654532044105070574L;
    private String observacao;
    private Agendamento agendamento;
    private List<OutraArea> outraAreaList;
    private OutraArea outraAreaSelecionada;
    
    @EJB(beanName="ExecutorCommandService")
    private IExecutorCommandService executorCommandService;
    @EJB
    private IOutraAreaService outraAreaService;
    @EJB
    private ICasoSauService casoSauService;
    
    public CasoPendenteOutraAreaBB() {
        this.agendamento = new Agendamento();
    }

    @PostConstruct
    public void init(){
    	cleanData();
    }
    
    
    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }

    @Override
    public void execute() {
        try {

            if (validaSave()) {
                AtendenteCasoBB atendenteCasoBB = getAtendenteCasoBB();
                Map<String, Object> parametros = atendenteCasoBB.getParamsGBO();
                
                CasoSau casoSau = atendenteCasoBB.getCasoSau();
                casoSau.setOutraArea(outraAreaSelecionada);
                parametros.put("casoSau", casoSau);
                parametros.put("observacao", getObservacao());
                getAgendamento().setDescricao(getObservacao());
                parametros.put("agendamento", getAgendamento());
                parametros.put("grupoAnexo", getGrupoAnexo());
                parametros.put("detalhe", outraAreaSelecionada.getNome());
                
                
                executorCommandService.execute(parametros);
                atendenteCasoBB.atualizaLista();
                cleanData();
            }
        } catch (ValidationException ex) {
            error(ex.getMessage());
        } catch (ServiceException ex) {
            error(ex);
        }
    }

    private boolean validaSave() {

        boolean valido = Boolean.TRUE;
        try {
            if (StringUtils.isBlank(getObservacao())) {
                error("Campo Observa\u00E7\u00E3o \u00E9 obrigat\u00F3rio.");
                valido = Boolean.FALSE;
            }
            if (getAgendamento() == null || getAgendamento().getDataAgendamento() == null) {
                error("Campo Agendamento \u00E9 obrigat\u00F3rio.");
                valido = Boolean.FALSE;
            }

            if (getAgendamento() != null && getAgendamento().getDataAgendamento() != null && agendamento.getDataAgendamento().getTime() < getService().getDataBanco().getTime()) {
                error("Data do agendamento deve ser maior do que a data Atual.");
                valido = Boolean.FALSE;
            }
        } catch (ServiceException e) {
            error("Erro ao buscar datas.");
        }
        return valido;
    }

    @Override
    public void cleanData() {
        this.observacao = null;
        this.agendamento = new Agendamento();
        limpaAnexos();
        try {
            outraAreaSelecionada = new OutraArea();
            this.outraAreaList = outraAreaService.findAtivos("OutraArea.NOME");
        } catch (ServiceException e) {
            error("Erro ao carregar Lista de Outras \u00E1reas.");
        }
    }

    public Agendamento getAgendamento() {
        return agendamento;
    }

    public void setAgendamento(Agendamento agendamento) {
        this.agendamento = agendamento;
    }

    public List<SelectItem> getOutraAreaList() {
        return JSFUtil.toSelectItemConsulta(outraAreaList);
    }

    public void setOutraAreaList(List<OutraArea> outraAreaList) {
        this.outraAreaList = outraAreaList;
    }

    public OutraArea getOutraAreaSelecionada() {
        return outraAreaSelecionada;
    }

    public void setOutraAreaSelecionada(OutraArea outraAreaSelecionada) {
        this.outraAreaSelecionada = outraAreaSelecionada;
    }

	@Override
	protected ICasoSauService getService() {
		return casoSauService;
	}

	@Override
	public void novo() {
		this.agendamento = new Agendamento();
		setPojo(new CasoSau());
	}
}
