package br.com.callink.cad.sau.admin.web.backbean.caso.acao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.model.SelectItem;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.engine.command.ICommandScreen;
import br.com.callink.cad.engine.command.executor.IExecutorCommandService;
import br.com.callink.cad.pojo.ParametroGBO;
import br.com.callink.cad.pojo.Telefone;
import br.com.callink.cad.sau.admin.web.backbean.CadSauAdminGenericCrud;
import br.com.callink.cad.sau.admin.web.backbean.caso.AtendenteCasoBB;
import br.com.callink.cad.sau.pojo.Assunto;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.pojo.Evento;
import br.com.callink.cad.sau.pojo.TipoManifestacao;
import br.com.callink.cad.sau.service.IAssuntoService;
import br.com.callink.cad.sau.service.ICasoSauService;
import br.com.callink.cad.sau.service.IEventoService;
import br.com.callink.cad.sau.service.ITipoManifestacaoService;
import br.com.callink.cad.service.IAtendenteService;
import br.com.callink.cad.service.IAuthenticatorService;
import br.com.callink.cad.service.IParametroGBOService;
import br.com.callink.cad.service.ITelefoneService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.impl.AuthenticatorService;
import br.com.callink.cad.util.Constantes;
import br.com.callink.cad.util.JSFUtil;

@ManagedBean
@ViewScoped
public class ClassificaCasoBB extends CadSauAdminGenericCrud<CasoSau, ICasoSauService> implements
        ICommandScreen {

    private static final long serialVersionUID = 1381832044105070574L;
    private Assunto assunto;
    private List<Assunto> assuntos;
    private Evento evento;
    private List<Evento> eventos;
    private List<Evento> eventosCached;
    private TipoManifestacao tipoManifestacao;
    private List<TipoManifestacao> tiposManifestacao;
    private AtendenteCasoBB atendenteCasoBB;
    private String observacao;
    private String nomeAssunto;
    private boolean controleFindAssuntos;
    private Integer qtdMaximaClassificacao;
    private Boolean validaSupervisor;
    private String loginSupervisor;
    private String senhaSupervisor;
    private List<Telefone> telefoneList;
    private Telefone telefoneSelecionado;
    private String novoTelefone;
    private Boolean telefonesEditados;
    
    @EJB
    private IAssuntoService assuntoService;
    @EJB
    private ITipoManifestacaoService tipoManifestacaoService;
    @EJB
    private IAtendenteService atendenteService;
    @EJB
    private IAuthenticatorService authenticatorService;
    @EJB(beanName="ExecutorCommandService")
    private IExecutorCommandService executorCommandService;
    @EJB
    private IParametroGBOService parametroGBOService;
    @EJB
    private IEventoService eventoService;
    @EJB
    private ICasoSauService casoService;
    @EJB
    private ITelefoneService telefoneService;
    
    public ClassificaCasoBB() {
    	novoTelefone = "";
    	telefoneSelecionado = new Telefone();
    }
    
    @Override
    public void execute() {
        try {
            atendenteCasoBB = getAtendenteCasoBB();

            if (atendenteCasoBB.getCasoSau() == null) {
                throw new IllegalArgumentException("Erro : Caso est\u00E1 nulo !");
            }
            
            if (validaSupervisor != null && validaSupervisor) {
                try {
                    if (!atendenteService.validaLoginSupervisor(loginSupervisor)) {
                        error("Erro : O Login informado n\u00E3o pertence a um supervisor. !");
                        return;
                    }
                    
                    IAuthenticatorService authentica = authenticatorService;
                    authentica.authentica(loginSupervisor, senhaSupervisor, AuthenticatorService.AD);
                } catch (Exception e) {
                    throw new ServiceException("Erro de Autentica\u00E7\u00E3o do supervisor.", e);
                }
            }

            if (validaCampos()) {

                Map<String, Object> parametros = atendenteCasoBB.getParamsGBO();
                parametros.put("evento", evento);
                parametros.put("casoSau", atendenteCasoBB.getCasoSau());
                parametros.put("tipoManifestacao", tipoManifestacao);
                parametros.put("observacao", observacao);
                parametros.put("grupoAnexo", getGrupoAnexo());
                parametros.put("telefones", telefoneList);
                parametros.put("editTel", telefonesEditados);
                
                executorCommandService.execute(parametros);
                atendenteCasoBB.atualizaLista();
                cleanData();

            }
        } catch (Exception e) {
            error(e);
        }
    }

    @Override
    public void cleanData() {
        this.assunto = null;
        this.nomeAssunto = null;
        if (assuntos != null) {
            this.assuntos.clear();
            this.assuntos = null;
        }

        this.evento = null;
        if (eventos != null) {
            this.eventos.clear();
            this.eventos = null;
        }
        if (eventosCached != null) {
            this.eventosCached.clear();
            this.eventosCached = null;
        }

        this.tipoManifestacao = null;
        if (tiposManifestacao != null) {
            this.tiposManifestacao.clear();
            this.tiposManifestacao = null;
        }
        this.telefoneList = null;
        limpaAnexos();
        this.observacao = null;
        novoTelefone = "";
        telefoneSelecionado = new Telefone();
    }

    private boolean validaCampos() {

        boolean valido = true;

        if (atendenteCasoBB.getCasoSau().getCaso() == null
                || atendenteCasoBB.getCasoSau().getCaso().getPK() == null) {
            error("Erro : Campo Caso est\u00E1 nulo ");
            valido = Boolean.FALSE;
        }
        if (atendenteCasoBB.getCasoSau() == null
                || atendenteCasoBB.getCasoSau().getPK() == null) {
            error("Erro : Campo idExterno est\u00E1 nulo");
            valido = Boolean.FALSE;
        }
        if (atendenteCasoBB.getStatusAcaoSelecionado() == null
                || atendenteCasoBB.getStatusAcaoSelecionado().getStatusAcaoId().getIdAcao() == null) {
            error("Campo Obrigat\u00F3rio : A\u00E7\u00E3o");
        }
        if (evento == null || evento.getPK() == null) {
            error("Campo Obrigat\u00F3rio : Evento");
            valido = Boolean.FALSE;
        }
        if (tipoManifestacao == null || tipoManifestacao.getPK() == null) {
            error("Campo Obrigat\u00F3rio : Tipo Manifesta\u00E7\u00E3o ");
            valido = Boolean.FALSE;
        }
        //se caso estiver sendo reclassificado, campo observaçao eh obrigatorio, senao é opcional, 
        if (StringUtils.isBlank(observacao) 
                && (getAtendenteCasoBB().getCasoSau().getCaso().getClassificacaoCount() != null 
                && getAtendenteCasoBB().getCasoSau().getCaso().getClassificacaoCount() > 0)) {
                error("Campo Obrigat\u00F3rio : Observa\u00E7\u00E3o ");
                valido = Boolean.FALSE;
        }
        return valido;

    }

    /**
     * COMBO(S) BINDING
     */
    public Assunto getAssunto() {
        return assunto;
    }

    public void setAssunto(Assunto assunto) {
        this.assunto = assunto;
    }

    public boolean validaSupervisor() {
        Integer classificacaoCount = getAtendenteCasoBB().getCasoSau().getCaso().getClassificacaoCount();
        classificacaoCount = classificacaoCount == null ? Integer.valueOf(0) : classificacaoCount;

        if (qtdMaximaClassificacao == null) {
            try {
                ParametroGBO parametro = parametroGBOService.findByParam(Constantes.QTD_MAX_CLASSIFICACOES);
                qtdMaximaClassificacao = Integer.valueOf(parametro.getValor());
                loginSupervisor = "";
            } catch (ServiceException ex) {
                error(ex);
            }
        }

        if (classificacaoCount >= qtdMaximaClassificacao) {
            validaSupervisor = true;
        } else {
            validaSupervisor = false;
        }
        return validaSupervisor;
    }

    public List<SelectItem> getAssuntos() {
        if (assuntos == null) {
            try {
                this.assuntos = assuntoService.findAtivos("Assunto.NOME");
            } catch (Exception e) {
                error(e);
            }
        }

        return JSFUtil.toSelectItemConsulta(assuntos);
    }

    public void setAssuntos(List<Assunto> assuntos) {
        this.assuntos = assuntos;
    }

    public Evento getEvento() {
        return evento;
    }

    public void setEvento(Evento evento) {
        this.evento = evento;
    }

    public List<SelectItem> getEventos() {
        initEventosIfNecessary();

        return JSFUtil.toSelectItemConsulta(eventos);
    }

    private void initEventosIfNecessary() {
        if (eventos == null) {
            this.eventos = new ArrayList<Evento>();
        }
    }

    public void fillEventosComBaseNoAssunto() {
        initEventosIfNecessary();

        if (eventosCached == null) {
            try {
                this.eventosCached = eventoService.findAtivos("Evento.NOME");
            } catch (ServiceException e) {
                error(e);
            }
        }

        // busca em cache eventos com determinado assunto
        if (eventosCached != null && !eventosCached.isEmpty() && assunto != null) {
            List<Evento> evts = new ArrayList<Evento>();
            for (Evento eve : eventosCached) {
                if (eve.getAssunto().getIdAssunto().equals(assunto.getIdAssunto())) {
                    evts.add(eve);
                }
            }
            this.eventos.clear();
            this.eventos.addAll(evts);
        }
    }

    public void setEventos(List<Evento> eventos) {
        this.eventos = eventos;
    }

    public void filtraComboTipoManifestacao() {
        if (tipoManifestacao != null && tipoManifestacao.getPK() != null) {
            try {

                if (tipoManifestacao.getEvento() != null && tipoManifestacao.getEvento().getIdEvento() != null) {
                    getAssuntos();
                    getEventos();
                    
                    tipoManifestacaoService.load(tipoManifestacao);
                    if (!assuntos.contains(tipoManifestacao.getEvento().getAssunto())) {
                        assuntos.add(tipoManifestacao.getEvento().getAssunto());
                    }
//                  this.assuntos.clear();
                    this.assunto = assuntoService.load(tipoManifestacao.getEvento().getAssunto());
//                  this.assuntos.add(this.assunto);
                    
                    this.eventos.clear();
                    fillEventosComBaseNoAssunto();
                    this.evento = tipoManifestacao.getEvento();
                    
//                    this.eventos.add(this.evento);

                    controleFindAssuntos = true;
                } else {
                    if (controleFindAssuntos) {
                        this.assunto = new Assunto();
                        this.assuntos = assuntoService.findAtivos("Assunto.NOME");
                    }
                    if (eventos != null) {
                        this.eventos.clear();
                    }
                    controleFindAssuntos = false;
                }
            } catch (ServiceException ex) {
                error(ex);
            }
        }
    }

    public TipoManifestacao getTipoManifestacao() {
        if (tipoManifestacao == null) {
            getTiposManifestacao();
            Integer idTipoAcao = tiposManifestacao.indexOf(getAtendenteCasoBB().getCasoSau().getTipoManifestacao());
            if (idTipoAcao > 0) {
                tipoManifestacao = tiposManifestacao.get(idTipoAcao);
                filtraComboTipoManifestacao();
            }
        }

        return tipoManifestacao;
    }

    public void setTipoManifestacao(TipoManifestacao tipoManifestacao) {
        this.tipoManifestacao = tipoManifestacao;
    }

    public List<SelectItem> getTiposManifestacao() {
        if (tiposManifestacao == null) {
            try {
                this.tiposManifestacao = tipoManifestacaoService.findAll();
            } catch (ServiceException e) {
                error(e);
            }
        }

        return JSFUtil.toSelectItemConsulta(tiposManifestacao);
    }

    public void setTiposManifestacao(List<TipoManifestacao> tiposManifestacao) {
        this.tiposManifestacao = tiposManifestacao;
    }

    // FIM BINDING COMBOS
    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }

    public String getNomeAssunto() {
        if (nomeAssunto == null || nomeAssunto.isEmpty()) {
                this.nomeAssunto = getAtendenteCasoBB().getCasoSau().getAssunto();

                Assunto assuntoExample = new Assunto();
                assuntoExample.setNome(nomeAssunto);
                try {
                    List<Assunto> assuntosLocal = assuntoService.findByExample(assuntoExample);
                    if (assuntosLocal != null) {
                        this.assunto = assuntosLocal.get(0);
                    }
                } catch (ServiceException e) {
                    error(e);
                }
            if (assunto != null) {
                fillEventosComBaseNoAssunto();
            }
        }

        return nomeAssunto;
    }

    public void setNomeAssunto(String assunto) {
        this.nomeAssunto = assunto;
    }

    public String getSenhaSupervisor() {
        return senhaSupervisor;
    }

    public void setSenhaSupervisor(String senhaSupervisor) {
        this.senhaSupervisor = senhaSupervisor;
    }

    public String getLoginSupervisor() {
        return loginSupervisor;
    }

    public void setLoginSupervisor(String loginSupervisor) {
        this.loginSupervisor = loginSupervisor;
    }

	@Override
	protected ICasoSauService getService() {
		return casoService;
	}

	@Override
	public void novo() {
	}

	public List<Telefone> getTelefoneList() {
		if(telefoneList == null) {
			try {
				telefoneList = telefoneService.buscaTelefoneCaso(getAtendenteCasoBB().getCasoSau().getCaso());
				
				if (telefoneList == null) {
					telefoneList = new ArrayList<Telefone>();
				}
				
			} catch (ServiceException e) {
				error(e);
			}
		}
		
		return telefoneList;
	}

	public void setTelefoneList(List<Telefone> telefoneList) {
		this.telefoneList = telefoneList;
	}

	public void alterarTel(Telefone tel) {
		setTelefoneSelecionado(tel);
	}

	public Telefone getTelefoneSelecionado() {
		return telefoneSelecionado;
	}

	public void setTelefoneSelecionado(Telefone telefoneSelecionado) {
		telefonesEditados = true;
		this.telefoneSelecionado = telefoneSelecionado;
	}
	
	public void editTel() {
		
	}

	public String getNovoTelefone() {
		return novoTelefone;
	}

	public void setNovoTelefone(String novoTelefone) {
		this.novoTelefone = novoTelefone;
	}
	
	public void newTelefone() {
		if (novoTelefone.isEmpty() || novoTelefone.length() < 3) {
			error("Informe um telefone válido.");
			return;
		}
		
		Telefone tel = new Telefone();
		tel.setTelefone(novoTelefone);
		tel.setCaso(getAtendenteCasoBB().getCasoSau().getCaso());
		
		telefoneList.add(tel);
		
		novoTelefone = "";
		
		telefonesEditados = true;
	}
    
}
