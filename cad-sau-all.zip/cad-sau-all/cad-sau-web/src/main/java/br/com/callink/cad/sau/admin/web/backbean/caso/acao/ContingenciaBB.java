package br.com.callink.cad.sau.admin.web.backbean.caso.acao;

import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.model.SelectItem;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.engine.command.ICommandScreen;
import br.com.callink.cad.engine.command.executor.IExecutorCommandService;
import br.com.callink.cad.sau.admin.web.backbean.CadSauAdminGenericCrud;
import br.com.callink.cad.sau.pojo.Assunto;
import br.com.callink.cad.sau.pojo.Canal;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.pojo.Estado;
import br.com.callink.cad.sau.pojo.Evento;
import br.com.callink.cad.sau.pojo.TipoManifestacao;
import br.com.callink.cad.sau.service.IAssuntoService;
import br.com.callink.cad.sau.service.ICanalService;
import br.com.callink.cad.sau.service.ICasoSauService;
import br.com.callink.cad.sau.service.IEstadoService;
import br.com.callink.cad.sau.service.IEventoService;
import br.com.callink.cad.sau.service.ITipoManifestacaoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.util.CpfCnpj;
import br.com.callink.cad.util.JSFUtil;

@ManagedBean
@ViewScoped
public class ContingenciaBB extends CadSauAdminGenericCrud<CasoSau, ICasoSauService> implements ICommandScreen {

    private static final long serialVersionUID = 1654532044105070574L;
    private static final String CONTINGENCIA = "CONTINGENCIA";
    private String cpfAlterado;
    private String observacao;

    private List<TipoManifestacao> tipoManifestacaoList;
    private List<Canal> canalList;
    private List<Assunto> assuntoList;
    private List<Evento> eventoList;
    private List<Estado> estadoList;
    private Assunto assunto;
    
    @EJB
    private ICasoSauService casoSauService;
    @EJB
    private ITipoManifestacaoService tipoManifestacaoService;
    @EJB
    private ICanalService canalService;
    @EJB
    private IAssuntoService assuntoService;
    @EJB
    private IEstadoService estadoService;
    @EJB
    private IEventoService eventoService;
    @EJB(beanName="ExecutorCommandService")
    private IExecutorCommandService executorCommandService;
    
    @PostConstruct
    public void init(){
    	 cleanData();
         try {
 	        tipoManifestacaoList = tipoManifestacaoService.findAtivos("TipoManifestacao.NOME");
 	        canalList = canalService.findAtivos("Canal.NOME");
 	        assuntoList = assuntoService.findAtivos("Assunto.NOME");
 	        estadoList = estadoService.findAtivos("Estado.NOME");
         } catch (Exception e) {
 			error(e);
 		}
    }
    
    public ContingenciaBB() {
       
    }

    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }

    @Override
    public void execute() {
        try {
            if (validaDadosTelas()) {
                Map<String, Object> parametros = getAtendenteCasoBB().getParamsGBO();
                parametros.put("observacao", getObservacao());
                parametros.put("evento", getPojo().getEvento());
                parametros.put("casoSau", getPojo());
                parametros.put("tipoManifestacao", getPojo().getTipoManifestacao());
                parametros.put("casoSau", getPojo());

                executorCommandService.execute(parametros);
                getAtendenteCasoBB().atualizaLista();
                cleanData();
            }
        } catch (ServiceException ex) {
            getAtendenteCasoBB().getCasoSau().setCpfCnpj(cpfAlterado);
            error(ex);
        } catch (Exception e) {
            error(e);
        }
    }

    
    private boolean validaDadosTelas() {
        Boolean valida = Boolean.TRUE;

        if (StringUtils.isBlank(getPojo().getCpfCnpj())) {
            error("Campo Obrigat\u00F3rio : Cpf/Cnpj ");
            getAtendenteCasoBB().getCasoSau().setCpfCnpj(cpfAlterado);
            valida = Boolean.FALSE;
        }

        if (StringUtils.isNotBlank(getPojo().getCpfCnpj())) {

            String cpfCnpj = CpfCnpj.validaCpfCnpj(getPojo().getCpfCnpj());

            if ( cpfCnpj == null) {
                    StringBuilder string = new StringBuilder();
                    string.append("Cpf/Cnpj inv\u00E1lido! Cpf/Cnpj: ");
                    string.append(getPojo().getCpfCnpj());
                    error(string.toString());
                    getAtendenteCasoBB().getCasoSau().setCpfCnpj(cpfAlterado);
                    valida = Boolean.FALSE;
            } else {
                    getPojo().setCpfCnpj(cpfCnpj);
            }
        }
        
        if (getPojo().getNomeCliente().isEmpty() || getPojo().getNomeCliente().equals(CONTINGENCIA)) {
        	error("O nome deve ser informado");
        	valida = Boolean.FALSE;
        }
        if (getPojo().getTipoManifestacao() == null || getPojo().getTipoManifestacao().getNome() == null || getPojo().getTipoManifestacao().getNome().equals(CONTINGENCIA)) {
        	error("O tipo de manifestação deve ser informado");
        	valida = Boolean.FALSE;
        }
        if(getPojo().getCanal() == null || getPojo().getCanal().getNome() == null || getPojo().getCanal().getNome().equals(CONTINGENCIA)) {
        	error("O Canal deve ser informado.");
        	valida = Boolean.FALSE;
        }
        if(getPojo().getEstado() == null || getPojo().getEstado().getNome() == null || getPojo().getEstado().getNome().equals(CONTINGENCIA)) {
        	error("O Estado deve ser informado");
        	valida = Boolean.FALSE;
        }
        if(getPojo().getAgenciaDepartamento() != null && getPojo().getAgenciaDepartamento().equals(CONTINGENCIA)) {
        	error("Acertar o campo Agencia Departamento");
        	valida = Boolean.FALSE;
        }
        if(getPojo().getAgenciaConta() != null && getPojo().getAgenciaConta().equals(CONTINGENCIA)) {
        	error("Acertar o campo Agencia Conta");
        	valida = Boolean.FALSE;
        }
        if(getPojo().getGrupo() != null && getPojo().getGrupo().equals(CONTINGENCIA)) {
        	error("Acertar o campo Grupo");
        	valida = Boolean.FALSE;
        }
        if(getPojo().getSubGrupo() != null && getPojo().getSubGrupo().equals(CONTINGENCIA)) {
        	error("Acertar o campo SubGrupo");
        	valida = Boolean.FALSE;
        }
        if(getPojo().getViaEntrada().isEmpty() || getPojo().getViaEntrada().equals(CONTINGENCIA)) {
        	error("O campo Via de Entrada deve ser informado");
        	valida = Boolean.FALSE;
        }
        if(getPojo().getAssunto().isEmpty() || getPojo().getAssunto().equals(CONTINGENCIA)) {
        	error("O campo Assunto Ouvidoria deve ser informado.");
        	valida = Boolean.FALSE;
        }
        if(getPojo().getDescricao().isEmpty() || getPojo().getDescricao().equals(CONTINGENCIA)) {
        	error("O campo Descrição deve ser inforado.");
        	valida = Boolean.FALSE;
        }
        
        return valida;
    }
    
    
    @Override
    public final void cleanData() {
        this.observacao = null;
        setPojo(getAtendenteCasoBB().getCasoSau());
        cpfAlterado = getAtendenteCasoBB().getCasoSau().getCpfCnpj();
    }


    public void filtrarCombos() {
        try {
            eventoList = eventoService.findByAssunto(assunto);
        } catch (ServiceException ex) {
            error(ex);
        }
    }
    
    public String getCpfAlterado() {
        return cpfAlterado;
    }

    public void setCpfAlterado(String cpfAlterado) {
        this.cpfAlterado = cpfAlterado;
    }
    

    public final List<SelectItem> getTipoManifestacaoList() {
        return JSFUtil.toSelectItemConsulta(tipoManifestacaoList);
    }

    public final void setTipoManifestacaoList(List<TipoManifestacao> tipoManifestacaoList) {
        this.tipoManifestacaoList = tipoManifestacaoList;
    }

    public final List<SelectItem> getCanalList() {
        return JSFUtil.toSelectItemConsulta(canalList);
    }

    public final void setCanalList(List<Canal> canalList) {
        this.canalList = canalList;
    }

    public final List<SelectItem> getAssuntoList() {
        return JSFUtil.toSelectItemConsulta(assuntoList);
    }

    public final void setAssuntoList(List<Assunto> assuntoList) {
        this.assuntoList = assuntoList;
    }

    public final List<SelectItem> getEventoList() {
        return JSFUtil.toSelectItemConsulta(eventoList);
    }

    public final void setEventoList(List<Evento> eventoList) {
        this.eventoList = eventoList;
    }

    public Assunto getAssunto() {
        return assunto;
    }

    public void setAssunto(Assunto assunto) {
        this.assunto = assunto;
    }

	public List<SelectItem> getEstadoList() {
		return JSFUtil.toSelectItemConsulta(estadoList);
	}

	public void setEstadoList(List<Estado> estadoList) {
		this.estadoList = estadoList;
	}

	@Override
	protected ICasoSauService getService() {
		return casoSauService;
	}

	@Override
	public void novo() {
		setPojo(new CasoSau());
	}
}
