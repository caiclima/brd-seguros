package br.com.callink.cad.sau.admin.web.backbean.caso.acao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.model.SelectItem;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.engine.command.ICommandScreen;
import br.com.callink.cad.engine.command.executor.IExecutorCommandService;
import br.com.callink.cad.sau.admin.web.backbean.CadSauAdminGenericCrud;
import br.com.callink.cad.sau.admin.web.backbean.caso.AtendenteCasoBB;
import br.com.callink.cad.sau.pojo.CasoSau;
import br.com.callink.cad.sau.pojo.Causa;
import br.com.callink.cad.sau.pojo.EventoCausa;
import br.com.callink.cad.sau.pojo.Juncao;
import br.com.callink.cad.sau.service.ICasoSauService;
import br.com.callink.cad.sau.service.IEventoCausaService;
import br.com.callink.cad.sau.service.IJuncaoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.util.CpfCnpj;
import br.com.callink.cad.util.JSFUtil;

@ManagedBean
@ViewScoped
public class FinalizaAtualizaDadosCasoBB extends CadSauAdminGenericCrud<CasoSau, ICasoSauService> implements ICommandScreen {

	private static final long serialVersionUID = 802396526533423684L;
	private String observacao;
    private List<Causa> causaList;
    private Causa causaSelecionada;
    
    private String cpfAlterado;
    private List<Juncao> listaJuncao;
    private Boolean atrazoOutraArea;
    
    @EJB(beanName="ExecutorCommandService")
    private IExecutorCommandService executorCommandService;
    @EJB
    private IEventoCausaService eventoCausaService;
    @EJB
    private ICasoSauService casoSauService;
    @EJB
    private IJuncaoService juncaoService;

    @PostConstruct
    public void init() {
        cleanData();
    }

    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }

    @Override
    public void execute() {
        try {
            AtendenteCasoBB atendenteCasoBB = getAtendenteCasoBB();
            if (validaDadosTela()) {
                Map<String, Object> parametros = atendenteCasoBB.getParamsGBO();
                parametros.put("observacao", getObservacao());

                atendenteCasoBB.getCasoSau().setCausa(causaSelecionada);
                parametros.put("casoSau", getPojo());
                parametros.put("grupoAnexo", getGrupoAnexo());

                executorCommandService.execute(parametros);
                atendenteCasoBB.atualizaLista();
                cleanData();
            }
        } catch (ValidationException ex) {
            error(ex.getMessage());
        } catch (ServiceException ex) {
        	getAtendenteCasoBB().getCasoSau().setCpfCnpj(cpfAlterado);
            error(ex);
        } catch (Exception e) {
        	error(e);
		}
    }

    private boolean validaDadosTela() {
        Boolean valida = true;

        if (StringUtils.isBlank(observacao)) {
            error("Favor preencher o campo observa\u00E7\u00E3o. Este campo n\u00E3o pode ser nulo.");
            valida = false;
        }

        if (causaSelecionada == null || causaSelecionada.getIdCausa() == null) {
            error("Favor selecionar uma causa. Este campo n\u00E3o pode ser nulo.");
            valida = false;
        }
        
        if (StringUtils.isBlank(getPojo().getCpfCnpj())) {
            error("Campo Obrigat\u00F3rio : Cpf/Cnpj ");
            getAtendenteCasoBB().getCasoSau().setCpfCnpj(cpfAlterado);
            valida = Boolean.FALSE;
        }

        if (StringUtils.isNotBlank(getPojo().getCpfCnpj())) {

            String cpfCnpj = CpfCnpj.validaCpfCnpj(getPojo().getCpfCnpj());

            if (cpfCnpj == null) {
                StringBuilder string = new StringBuilder();
                string.append("Cpf/Cnpj inv\u00E1lido! Cpf/Cnpj: ");
                string.append(getPojo().getCpfCnpj());
                error(string.toString());
                getAtendenteCasoBB().getCasoSau().setCpfCnpj(cpfAlterado);
                valida = Boolean.FALSE;
            } else {
                getPojo().setCpfCnpj(cpfCnpj);
            }
        }

        return valida;
    }

    @Override
    public void cleanData() {
        this.observacao = null;
        this.causaSelecionada = new Causa();
        this.causaList = new ArrayList<Causa>();
        limpaAnexos();
        try {
            List<EventoCausa> eventocausaList = eventoCausaService.findByEventoCausa(getAtendenteCasoBB().getCasoSau().getEvento(), null);
            for (EventoCausa ca : eventocausaList) {
                this.causaList.add(ca.getCausa());
            }
        } catch (ServiceException ex) {
            error(ex);
        }
        
        setPojo(getAtendenteCasoBB().getCasoSau());
        cpfAlterado = getAtendenteCasoBB().getCasoSau().getCpfCnpj();
        try {
            atrazoOutraArea = getService().juncaoForaPrazo(getPojo());
            if (atrazoOutraArea) {
                listaJuncao = juncaoService.findAtivos("Juncao.NOME");
            }
        } catch (ServiceException ex) {
            error(ex);
        }
    }

    public List<SelectItem> getCausaList() {
        return JSFUtil.toSelectItemConsulta(this.causaList);
    }

    public void setCausaList(List<Causa> causaList) {
        this.causaList = causaList;
    }

    public Causa getCausaSelecionada() {
        return causaSelecionada;
    }

    public void setCausaSelecionada(Causa causaSelecionada) {
        this.causaSelecionada = causaSelecionada;
    }
    
    public String getCpfAlterado() {
        return cpfAlterado;
    }

    public void setCpfAlterado(String cpfAlterado) {
        this.cpfAlterado = cpfAlterado;
    }

    public List<SelectItem> getListaJuncao() {
        return JSFUtil.toSelectItemConsulta(this.listaJuncao);
    }

    public void setListaJuncao(List<Juncao> listaJuncao) {
        this.listaJuncao = listaJuncao;
    }

    public Boolean getAtrazoOutraArea() {
        return atrazoOutraArea;
    }

    public void setAtrazoOutraArea(Boolean atrazoOutraArea) {
        this.atrazoOutraArea = atrazoOutraArea;
    }

	@Override
	protected ICasoSauService getService() {
		return casoSauService;
	}

	@Override
	public void novo() {
		
	}
}
