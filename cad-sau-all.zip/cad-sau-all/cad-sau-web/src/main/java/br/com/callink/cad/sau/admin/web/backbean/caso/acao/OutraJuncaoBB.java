package br.com.callink.cad.sau.admin.web.backbean.caso.acao;

import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.model.SelectItem;

import org.apache.commons.lang.StringUtils;

import br.com.callink.cad.engine.command.ICommandScreen;
import br.com.callink.cad.engine.command.executor.IExecutorCommandService;
import br.com.callink.cad.sau.admin.web.backbean.CadSauAdminGenericCrud;
import br.com.callink.cad.sau.admin.web.backbean.caso.AtendenteCasoBB;
import br.com.callink.cad.sau.pojo.Juncao;
import br.com.callink.cad.sau.service.IJuncaoService;
import br.com.callink.cad.service.exception.ServiceException;
import br.com.callink.cad.service.exception.ValidationException;
import br.com.callink.cad.util.Constantes;
import br.com.callink.cad.util.JSFUtil;

@ManagedBean
@ViewScoped
public class OutraJuncaoBB extends CadSauAdminGenericCrud<Juncao, IJuncaoService> implements
        ICommandScreen {

    private static final long serialVersionUID = 1654532044105070574L;
    private String observacao;
    private List<Juncao> juncaoList;
    private Juncao juncaoSelecionada;
    
    @EJB
    private IJuncaoService juncaoService;
    @EJB(beanName="ExecutorCommandService")
    private IExecutorCommandService executorCommandService;

    @PostConstruct
    public void init() {
        cleanData();
        populaCausaList();
    }

    private void populaCausaList() {
        try {
            juncaoList = juncaoService.findAtivos("Juncao.NOME");
        } catch (ServiceException ex) {
            error(ex);
        }
    }

    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }

    @Override
    public void execute() {
        try {
            AtendenteCasoBB atendenteCasoBB = getAtendenteCasoBB();
            if (validaDadosTela()) {
                Map<String, Object> parametros = atendenteCasoBB.getParamsGBO();

                parametros.put("observacao", getObservacao());
                parametros.put("flagFinaliza", Boolean.TRUE);
                parametros.put("proximoStatus", Constantes.STATUS_OUTRA_JUNCAO);
                parametros.put("grupoAnexo", getGrupoAnexo());

                atendenteCasoBB.getCasoSau().setJuncao(juncaoSelecionada);
                parametros.put("casoSau", atendenteCasoBB.getCasoSau());
                parametros.put("detalhe", juncaoSelecionada.getNome());
                executorCommandService.execute(parametros);
                atendenteCasoBB.atualizaLista();
                cleanData();
                populaCausaList();
            }
        } catch (ValidationException ex) {
            error(ex);
        } catch (ServiceException ex) {
            error(ex);
        }
    }

    private boolean validaDadosTela() {
        Boolean valida = true;

        if (StringUtils.isBlank(observacao)) {
            error("Favor preencher o campo observa\u00E7\u00E3o. Este campo n\u00E3o pode ser nulo.");
            valida = false;
        }

        if (juncaoSelecionada == null
                || juncaoSelecionada.getIdJuncao() == null) {
            error("Favor selecionar uma jun\u00E7\u00E3o. Este campo n\u00E3o pode ser nulo.");
            valida = false;
        }

        return valida;
    }

    @Override
    public void cleanData() {
        this.observacao = null;
        this.juncaoSelecionada = new Juncao();
        limpaAnexos();
    }

    public List<SelectItem> getJuncaoList() {
        return JSFUtil.toSelectItemConsulta(this.juncaoList);
    }

    public void setJuncaoList(List<Juncao> juncaoList) {
        this.juncaoList = juncaoList;
    }

    /**
     * @return the juncaoSelecionada
     */
    public final Juncao getJuncaoSelecionada() {
        return juncaoSelecionada;
    }

    /**
     * @param juncaoSelecionada
     *            the juncaoSelecionada to set
     */
    public final void setJuncaoSelecionada(Juncao juncaoSelecionada) {
        this.juncaoSelecionada = juncaoSelecionada;
    }

	@Override
	protected IJuncaoService getService() {
		return juncaoService;
	}

	@Override
	public void novo() {
		
	}
}
