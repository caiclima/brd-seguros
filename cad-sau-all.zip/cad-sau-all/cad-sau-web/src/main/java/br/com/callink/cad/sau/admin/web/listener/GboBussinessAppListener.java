package br.com.callink.cad.sau.admin.web.listener;

import java.util.logging.Logger;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.ejb.EJB;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import br.com.callink.cad.engine.buffer.fila.atendimento.ICasoAtendimento;
import br.com.callink.cad.engine.buffer.fila.atendimento.ThreadDistribuiCasoAutomaticamenteAtendenteDisponivel;
import br.com.callink.cad.sau.toolbar.server.GboBussinessAppServer;
import br.com.callink.cad.service.IAtendenteService;
import br.com.callink.cad.service.IAtendenteStatusService;
import br.com.callink.cad.service.ICasoService;
import br.com.callink.cad.service.IGboToolbarBusinessAppService;
import br.com.callink.cad.service.ILogLigacoesService;
import br.com.callink.cad.service.IParametroGBOService;
import br.com.callink.cad.service.IStatusAtendenteService;
import br.com.callink.cad.service.ITempoAtendimentoCasoService;


public class GboBussinessAppListener implements ServletContextListener{

    private Logger logger = Logger.getLogger(GboBussinessAppListener.class.getName());
    
    @EJB
    private IParametroGBOService parametroGBOService;
    @EJB
    private ICasoService casoService;
    @EJB
    private IGboToolbarBusinessAppService gboToolbarBusinessAppService; 
    @EJB
    private IStatusAtendenteService statusAtendenteService; 
    @EJB
    private IAtendenteStatusService atendenteStatusService; 
    @EJB
    private IAtendenteService atendenteService;
    @EJB
	private ICasoAtendimento casoAtendimento;
    @EJB
    private ITempoAtendimentoCasoService tempoAtendimentoCasoService;
    @EJB
    private ILogLigacoesService logLigacoesService;
    
    @PreDestroy
    public void contextDestroyed(ServletContextEvent arg0) {
    	ThreadDistribuiCasoAutomaticamenteAtendenteDisponivel.setExecuta(Boolean.FALSE);
    }

    @PostConstruct
    public void contextInitialized(ServletContextEvent arg0) {
        logger.info("Inicia GboBussinessAppListener...");
        GboBussinessAppServer.getInstance().init(parametroGBOService, statusAtendenteService, tempoAtendimentoCasoService, 
        		atendenteService, logLigacoesService, casoService);
        logger.info("GboBussinessAppListener iniciado com sucesso...");
        logger.info("Inicia ThreadDistribuiCasoAutomaticamenteAtendenteDisponivel...");
        ThreadDistribuiCasoAutomaticamenteAtendenteDisponivel threadDistribuiCasoAutomaticamenteAtendenteDisponivel = 
        		new ThreadDistribuiCasoAutomaticamenteAtendenteDisponivel(parametroGBOService, casoService, 
        				gboToolbarBusinessAppService, statusAtendenteService, atendenteStatusService, 
        				atendenteService, casoAtendimento);
        
        threadDistribuiCasoAutomaticamenteAtendenteDisponivel.setName("ThreadDistribuiCasoAutomaticamenteAtendenteDisponivel");
        threadDistribuiCasoAutomaticamenteAtendenteDisponivel.start();
        logger.info("ThreadDistribuiCasoAutomaticamenteAtendenteDisponivel iniciado com sucesso...");
    }

}
