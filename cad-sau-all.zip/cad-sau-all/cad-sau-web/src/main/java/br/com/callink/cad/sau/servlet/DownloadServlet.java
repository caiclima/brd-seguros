package br.com.callink.cad.sau.servlet;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.callink.cad.pojo.Anexo;

/**
 * 
 * @author ednaldo
 * @since 27/01/2012
 * 
 */
@WebServlet(name = "DownloadAnexo", asyncSupported = false, urlPatterns = "/downloadAnexo")
public class DownloadServlet extends HttpServlet {

	private static final long serialVersionUID = 8257986392458351401L;

	@SuppressWarnings("unchecked")
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse response)
			throws ServletException, IOException {

		Object arquivo = req.getSession().getAttribute("arquivo");
		Object parametro = req.getParameter("idAnexo");
		Anexo anexo = null;

		List<Anexo> anexoList = null;
		Integer idAnexo = null;
		if (arquivo != null) {
			anexoList = (List<Anexo>) arquivo;
		}
		if (parametro != null) {
			idAnexo = Integer.valueOf(parametro.toString());
		}
		if (idAnexo != null && anexoList != null && !anexoList.isEmpty()) {

			for (Anexo item : anexoList) {
				if (item.getPK().equals(idAnexo)) {
					anexo = item;
					break;
				}
			}
		}

		try {

			if (anexo != null) {

				String filename = anexo.getDiretorio() + anexo.getNomeFake();
				response.setContentType("APPLICATION/OCTET-STREAM");
				response.setHeader("Content-Disposition", "Attachment");

				response.setContentType("application/force-download");
				response.setCharacterEncoding("UTF-8");
				response.setHeader("Content-Disposition", "inline; filename=\"" + anexo.getNomeReal() + "\"");

				File fileToDownload = null;
				FileInputStream fileInputStream = null;
				ServletOutputStream out = null;
				try {
					fileToDownload = new File(filename);
					fileInputStream = new FileInputStream(fileToDownload);
					out = response.getOutputStream();
					int i;
					while ((i = fileInputStream.read()) != -1) {
						out.write(i);
					}
				} finally {
					if (fileInputStream != null) {
						fileInputStream.close();
					}
					if (out != null) {
						out.close();
					}
				}
			}

		} catch (IOException e) {
		}

	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doGet(req, resp);
	}
}
